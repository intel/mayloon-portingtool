﻿$_L(["$wt.internal.SWTEventListener"],"$wt.browser.ProgressListener",null,function(){
$_I($wt.browser,"ProgressListener",$wt.internal.SWTEventListener);
});
