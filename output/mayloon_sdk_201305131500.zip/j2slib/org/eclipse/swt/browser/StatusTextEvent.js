﻿$_L(["$wt.events.TypedEvent"],"$wt.browser.StatusTextEvent",null,function(){
c$=$_C(function(){
this.text=null;
$_Z(this,arguments);
},$wt.browser,"StatusTextEvent",$wt.events.TypedEvent);
});
