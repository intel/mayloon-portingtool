﻿$_L(["$wt.internal.SWTEventListener"],"$wt.browser.StatusTextListener",null,function(){
$_I($wt.browser,"StatusTextListener",$wt.internal.SWTEventListener);
});
