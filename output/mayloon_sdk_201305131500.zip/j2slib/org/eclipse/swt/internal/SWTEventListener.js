﻿$_L(["java.util.EventListener"],"$wt.internal.SWTEventListener",null,function(){
$_I($wt.internal,"SWTEventListener",java.util.EventListener);
});
