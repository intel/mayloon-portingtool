﻿$_L(["$wt.internal.SWTEventListener"],"$wt.custom.BidiSegmentListener",null,function(){
$_I($wt.custom,"BidiSegmentListener",$wt.internal.SWTEventListener);
});
