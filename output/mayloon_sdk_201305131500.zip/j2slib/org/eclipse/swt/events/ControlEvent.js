﻿$_L(["$wt.events.TypedEvent"],"$wt.events.ControlEvent",null,function(){
c$=$_T($wt.events,"ControlEvent",$wt.events.TypedEvent);
});
