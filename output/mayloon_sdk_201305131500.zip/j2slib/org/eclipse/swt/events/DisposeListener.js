﻿$_L(["$wt.internal.SWTEventListener"],"$wt.events.DisposeListener",null,function(){
$_I($wt.events,"DisposeListener",$wt.internal.SWTEventListener);
});
