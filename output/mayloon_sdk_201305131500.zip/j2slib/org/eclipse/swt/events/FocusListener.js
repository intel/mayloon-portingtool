﻿$_L(["$wt.internal.SWTEventListener"],"$wt.events.FocusListener",null,function(){
$_I($wt.events,"FocusListener",$wt.internal.SWTEventListener);
});
