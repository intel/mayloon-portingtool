﻿$_L(["java.io.DataInput"],"java.io.ObjectInput",null,function(){
$_I(java.io,"ObjectInput",java.io.DataInput);
});
