﻿$_L(["java.lang.Exception"],"java.io.IOException",null,function(){
c$=$_T(java.io,"IOException",Exception);
$_K(c$,
function(cause){
$_R(this,java.io.IOException,[cause==null?null:cause.toString(),cause]);
},"Throwable");
});
