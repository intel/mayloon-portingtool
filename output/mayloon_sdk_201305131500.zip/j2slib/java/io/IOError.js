﻿$_L(["java.lang.Error"],"java.io.IOError",null,function(){
c$=$_T(java.io,"IOError",Error);
});
