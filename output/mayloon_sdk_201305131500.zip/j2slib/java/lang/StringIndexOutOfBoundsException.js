﻿$_L(["java.lang.IndexOutOfBoundsException"],"java.lang.StringIndexOutOfBoundsException",null,function(){
c$=$_T(java.lang,"StringIndexOutOfBoundsException",IndexOutOfBoundsException);
$_K(c$,
function(index){
$_R(this,StringIndexOutOfBoundsException,["String index out of range:"+index]);
},"~N");
});
