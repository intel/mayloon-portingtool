﻿Clazz.declarePackage ("android.net");
Clazz.load (["android.net.AbstractHierarchicalUri", "$.Uri"], "android.net.StringUri", ["java.lang.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.uriString = null;
this.cachedSsi = -2;
this.cachedFsi = -2;
this.scheme = null;
this.ssp = null;
this.authority = null;
this.path = null;
this.query = null;
this.fragment = null;
Clazz.instantialize (this, arguments);
}, android.net, "StringUri", android.net.AbstractHierarchicalUri);
Clazz.prepareFields (c$, function () {
this.scheme = android.net.Uri.NOT_CACHED;
});
Clazz.makeConstructor (c$, 
function (uriString) {
Clazz.superConstructor (this, android.net.StringUri, []);
if (uriString == null) {
throw  new NullPointerException ("uriString");
}this.uriString = uriString;
}, "~S");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "findSchemeSeparator", 
($fz = function () {
return this.cachedSsi == -2 ? this.cachedSsi = this.uriString.indexOf (':') : this.cachedSsi;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "findFragmentSeparator", 
($fz = function () {
return this.cachedFsi == -2 ? this.cachedFsi = this.uriString.indexOf ('#', this.findSchemeSeparator ()) : this.cachedFsi;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "isHierarchical", 
function () {
var ssi = this.findSchemeSeparator ();
if (ssi == -1) {
return true;
}if (this.uriString.length == ssi + 1) {
return false;
}return (this.uriString.charAt (ssi + 1)).charCodeAt (0) == ('/').charCodeAt (0);
});
Clazz.overrideMethod (c$, "isRelative", 
function () {
return this.findSchemeSeparator () == -1;
});
Clazz.overrideMethod (c$, "getScheme", 
function () {
var cached = (this.scheme !== android.net.Uri.NOT_CACHED);
return cached ? this.scheme : (this.scheme = this.parseScheme ());
});
Clazz.defineMethod (c$, "parseScheme", 
($fz = function () {
var ssi = this.findSchemeSeparator ();
return ssi == -1 ? null : this.uriString.substring (0, ssi);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getSsp", 
($fz = function () {
return this.ssp == null ? this.ssp = android.net.Uri.Part.fromEncoded (this.parseSsp ()) : this.ssp;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getEncodedSchemeSpecificPart", 
function () {
return this.getSsp ().getEncoded ();
});
Clazz.overrideMethod (c$, "getSchemeSpecificPart", 
function () {
return this.getSsp ().getDecoded ();
});
Clazz.defineMethod (c$, "parseSsp", 
($fz = function () {
var ssi = this.findSchemeSeparator ();
var fsi = this.findFragmentSeparator ();
return fsi == -1 ? this.uriString.substring (ssi + 1) : this.uriString.substring (ssi + 1, fsi);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getAuthorityPart", 
($fz = function () {
if (this.authority == null) {
var encodedAuthority = android.net.StringUri.parseAuthority (this.uriString, this.findSchemeSeparator ());
return this.authority = android.net.Uri.Part.fromEncoded (encodedAuthority);
}return this.authority;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getEncodedAuthority", 
function () {
return this.getAuthorityPart ().getEncoded ();
});
Clazz.overrideMethod (c$, "getAuthority", 
function () {
return this.getAuthorityPart ().getDecoded ();
});
Clazz.defineMethod (c$, "getPathPart", 
($fz = function () {
return this.path == null ? this.path = android.net.Uri.PathPart.fromEncoded (this.parsePath ()) : this.path;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getPath", 
function () {
return this.getPathPart ().getDecoded ();
});
Clazz.overrideMethod (c$, "getEncodedPath", 
function () {
return this.getPathPart ().getEncoded ();
});
Clazz.overrideMethod (c$, "getPathSegments", 
function () {
return this.getPathPart ().getPathSegments ();
});
Clazz.defineMethod (c$, "parsePath", 
($fz = function () {
var uriString = this.uriString;
var ssi = this.findSchemeSeparator ();
if (ssi > -1) {
var schemeOnly = ssi + 1 == uriString.length;
if (schemeOnly) {
return null;
}if ((uriString.charAt (ssi + 1)).charCodeAt (0) != ('/').charCodeAt (0)) {
return null;
}} else {
}return android.net.StringUri.parsePath (uriString, ssi);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getQueryPart", 
($fz = function () {
return this.query == null ? this.query = android.net.Uri.Part.fromEncoded (this.parseQuery ()) : this.query;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getEncodedQuery", 
function () {
return this.getQueryPart ().getEncoded ();
});
Clazz.defineMethod (c$, "parseQuery", 
($fz = function () {
var qsi = this.uriString.indexOf ('?', this.findSchemeSeparator ());
if (qsi == -1) {
return null;
}var fsi = this.findFragmentSeparator ();
if (fsi == -1) {
return this.uriString.substring (qsi + 1);
}if (fsi < qsi) {
return null;
}return this.uriString.substring (qsi + 1, fsi);
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getQuery", 
function () {
return this.getQueryPart ().getDecoded ();
});
Clazz.defineMethod (c$, "getFragmentPart", 
($fz = function () {
return this.fragment == null ? this.fragment = android.net.Uri.Part.fromEncoded (this.parseFragment ()) : this.fragment;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getEncodedFragment", 
function () {
return this.getFragmentPart ().getEncoded ();
});
Clazz.defineMethod (c$, "parseFragment", 
($fz = function () {
var fsi = this.findFragmentSeparator ();
return fsi == -1 ? null : this.uriString.substring (fsi + 1);
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getFragment", 
function () {
return this.getFragmentPart ().getDecoded ();
});
Clazz.overrideMethod (c$, "toString", 
function () {
return this.uriString;
});
c$.parseAuthority = Clazz.defineMethod (c$, "parseAuthority", 
function (uriString, ssi) {
var length = uriString.length;
if (length > ssi + 2 && (uriString.charAt (ssi + 1)).charCodeAt (0) == ('/').charCodeAt (0) && (uriString.charAt (ssi + 2)).charCodeAt (0) == ('/').charCodeAt (0)) {
var end = ssi + 3;
LOOP : while (end < length) {
switch (uriString.charAt (end)) {
case '/':
case '?':
case '#':
break LOOP;
}
end++;
}
return uriString.substring (ssi + 3, end);
} else {
return null;
}}, "~S,~N");
c$.parsePath = Clazz.defineMethod (c$, "parsePath", 
function (uriString, ssi) {
var length = uriString.length;
var pathStart;
if (length > ssi + 2 && (uriString.charAt (ssi + 1)).charCodeAt (0) == ('/').charCodeAt (0) && (uriString.charAt (ssi + 2)).charCodeAt (0) == ('/').charCodeAt (0)) {
pathStart = ssi + 3;
LOOP : while (pathStart < length) {
switch (uriString.charAt (pathStart)) {
case '?':
case '#':
return "";
case '/':
break LOOP;
}
pathStart++;
}
} else {
pathStart = ssi + 1;
}var pathEnd = pathStart;
LOOP : while (pathEnd < length) {
switch (uriString.charAt (pathEnd)) {
case '?':
case '#':
break LOOP;
}
pathEnd++;
}
return uriString.substring (pathStart, pathEnd);
}, "~S,~N");
Clazz.overrideMethod (c$, "buildUpon", 
function () {
if (this.isHierarchical ()) {
return  new android.net.Uri.Builder ().scheme (this.getScheme ()).authority (this.getAuthorityPart ()).path (this.getPathPart ()).query (this.getQueryPart ()).fragment (this.getFragmentPart ());
} else {
return  new android.net.Uri.Builder ().scheme (this.getScheme ()).opaquePart (this.getSsp ()).fragment (this.getFragmentPart ());
}});
Clazz.defineStatics (c$,
"TYPE_ID", 1);
});
