﻿Clazz.declarePackage ("android.net");
Clazz.load (["android.os.Parcelable", "java.util.AbstractList", "$.RandomAccess"], "android.net.Uri", ["java.io.ByteArrayOutputStream", "java.lang.AssertionError", "$.Character", "$.IndexOutOfBoundsException", "$.NullPointerException", "$.StringBuilder", "$.UnsupportedOperationException", "java.net.URLEncoder", "java.util.ArrayList", "$.Collections"], function () {
c$ = Clazz.declareType (android.net, "Uri", null, [android.os.Parcelable, Comparable]);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "isOpaque", 
function () {
return !this.isHierarchical ();
});
Clazz.defineMethod (c$, "isAbsolute", 
function () {
return !this.isRelative ();
});
Clazz.overrideMethod (c$, "equals", 
function (o) {
if (!(Clazz.instanceOf (o, android.net.Uri))) {
return false;
}var other = o;
return this.toString ().equals (other.toString ());
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.toString ().hashCode ();
});
Clazz.overrideMethod (c$, "compareTo", 
function (other) {
return this.toString ().compareTo (other.toString ());
}, "android.net.Uri");
c$.parse = Clazz.defineMethod (c$, "parse", 
function (uriString) {
var res = null;
try {
var cstr = Class.forName ("android.net.StringUri").getConstructor ([String]);
res = cstr.newInstance ([uriString]);
} catch (e$$) {
if (Clazz.instanceOf (e$$, ClassNotFoundException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, Exception)) {
var e = e$$;
{
e.printStackTrace ();
}
} else {
throw e$$;
}
}
return res;
}, "~S");
c$.fromFile = Clazz.defineMethod (c$, "fromFile", 
function (file) {
if (file == null) {
throw  new NullPointerException ("file");
}var path = android.net.Uri.PathPart.fromDecoded (file.getAbsolutePath ());
return  new android.net.HierarchicalUri ("file", android.net.Uri.Part.EMPTY, path, android.net.Uri.Part.NULL, android.net.Uri.Part.NULL);
}, "java.io.File");
c$.fromParts = Clazz.defineMethod (c$, "fromParts", 
function (scheme, ssp, fragment) {
if (scheme == null) {
throw  new NullPointerException ("scheme");
}if (ssp == null) {
throw  new NullPointerException ("ssp");
}return  new android.net.Uri.OpaqueUri (scheme, android.net.Uri.Part.fromDecoded (ssp), android.net.Uri.Part.fromDecoded (fragment));
}, "~S,~S,~S");
Clazz.defineMethod (c$, "getQueryParameters", 
function (key) {
if (this.isOpaque ()) {
throw  new UnsupportedOperationException ("This isn\'t a hierarchical URI.");
}var query = this.getEncodedQuery ();
if (query == null) {
return java.util.Collections.emptyList ();
}var encodedKey;
try {
encodedKey = java.net.URLEncoder.encode (key, "UTF-8");
} catch (e) {
if (Clazz.instanceOf (e, java.io.UnsupportedEncodingException)) {
throw  new AssertionError (e);
} else {
throw e;
}
}
query = "&" + query;
var prefix = "&" + encodedKey + "=";
var values =  new java.util.ArrayList ();
var start = 0;
var length = query.length;
while (start < length) {
start = query.indexOf (prefix, start);
if (start == -1) {
break;
}start += prefix.length;
var end = query.indexOf ('&', start);
if (end == -1) {
end = query.length;
}var value = query.substring (start, end);
values.add (android.net.Uri.decode (value));
start = end;
}
return java.util.Collections.unmodifiableList (values);
}, "~S");
Clazz.defineMethod (c$, "getQueryParameter", 
function (key) {
if (this.isOpaque ()) {
throw  new UnsupportedOperationException ("This isn\'t a hierarchical URI.");
}if (key == null) {
throw  new NullPointerException ("key");
}var query = this.getEncodedQuery ();
if (query == null) {
return null;
}var encodedKey = android.net.Uri.encode (key, null);
var encodedKeyLength = encodedKey.length;
var encodedKeySearchIndex = 0;
var encodedKeySearchEnd = query.length - (encodedKeyLength + 1);
while (encodedKeySearchIndex <= encodedKeySearchEnd) {
var keyIndex = query.indexOf (encodedKey, encodedKeySearchIndex);
if (keyIndex == -1) {
break;
}var equalsIndex = keyIndex + encodedKeyLength;
if (equalsIndex >= query.length) {
break;
}if ((query.charAt (equalsIndex)).charCodeAt (0) != ('=').charCodeAt (0)) {
encodedKeySearchIndex = equalsIndex + 1;
continue ;}if (keyIndex == 0 || (query.charAt (keyIndex - 1)).charCodeAt (0) == ('&').charCodeAt (0)) {
var end = query.indexOf ('&', equalsIndex);
if (end == -1) {
end = query.length;
}return android.net.Uri.decode (query.substring (equalsIndex + 1, end));
} else {
encodedKeySearchIndex = equalsIndex + 1;
}}
return null;
}, "~S");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s) {
return android.net.Uri.encode (s, null);
}, "~S");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (s, allow) {
if (s == null) {
return null;
}var encoded = null;
var oldLength = s.length;
var current = 0;
while (current < oldLength) {
var nextToEncode = current;
while (nextToEncode < oldLength && android.net.Uri.isAllowed (s.charAt (nextToEncode), allow)) {
nextToEncode++;
}
if (nextToEncode == oldLength) {
if (current == 0) {
return s;
} else {
encoded.append (s, current, oldLength);
return encoded.toString ();
}}if (encoded == null) {
encoded =  new StringBuilder ();
}if (nextToEncode > current) {
encoded.append (s, current, nextToEncode);
} else {
}current = nextToEncode;
var nextAllowed = current + 1;
while (nextAllowed < oldLength && !android.net.Uri.isAllowed (s.charAt (nextAllowed), allow)) {
nextAllowed++;
}
var toEncode = s.substring (current, nextAllowed);
try {
var bytes = toEncode.getBytes ("UTF-8");
var bytesLength = bytes.length;
for (var i = 0; i < bytesLength; i++) {
encoded.append ('%');
encoded.append (android.net.Uri.HEX_DIGITS[(bytes[i] & 0xf0) >> 4]);
encoded.append (android.net.Uri.HEX_DIGITS[bytes[i] & 0xf]);
}
} catch (e) {
if (Clazz.instanceOf (e, java.io.UnsupportedEncodingException)) {
throw  new AssertionError (e);
} else {
throw e;
}
}
current = nextAllowed;
}
return encoded == null ? s : encoded.toString ();
}, "~S,~S");
c$.isAllowed = Clazz.defineMethod (c$, "isAllowed", 
($fz = function (c, allow) {
return ((c).charCodeAt (0) >= ('A').charCodeAt (0) && (c).charCodeAt (0) <= ('Z').charCodeAt (0)) || ((c).charCodeAt (0) >= ('a').charCodeAt (0) && (c).charCodeAt (0) <= ('z').charCodeAt (0)) || ((c).charCodeAt (0) >= ('0').charCodeAt (0) && (c).charCodeAt (0) <= ('9').charCodeAt (0)) || "_-!.~'()*".indexOf (c) != -1 || (allow != null && allow.indexOf (c) != -1);
}, $fz.isPrivate = true, $fz), "~N,~S");
c$.decode = Clazz.defineMethod (c$, "decode", 
function (s) {
if (s == null) {
return null;
}var decoded = null;
var out = null;
var oldLength = s.length;
var current = 0;
while (current < oldLength) {
var nextEscape = s.indexOf ('%', current);
if (nextEscape == -1) {
if (decoded == null) {
return s;
} else {
decoded.append (s, current, oldLength);
return decoded.toString ();
}}if (decoded == null) {
decoded =  new StringBuilder (oldLength);
out =  new java.io.ByteArrayOutputStream (4);
} else {
out.reset ();
}if (nextEscape > current) {
decoded.append (s, current, nextEscape);
current = nextEscape;
} else {
}try {
do {
if (current + 2 >= oldLength) {
out.write (android.net.Uri.REPLACEMENT);
} else {
var a = Character.digit (s.charAt (current + 1), 16);
var b = Character.digit (s.charAt (current + 2), 16);
if (a == -1 || b == -1) {
out.write (android.net.Uri.REPLACEMENT);
} else {
out.write ((a << 4) + b);
}}current += 3;
} while (current < oldLength && (s.charAt (current)).charCodeAt (0) == ('%').charCodeAt (0));
decoded.append (out.toString ("UTF-8"));
} catch (e$$) {
if (Clazz.instanceOf (e$$, java.io.UnsupportedEncodingException)) {
var e = e$$;
{
throw  new AssertionError (e);
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var e = e$$;
{
throw  new AssertionError (e);
}
} else {
throw e$$;
}
}
}
return decoded == null ? s : decoded.toString ();
}, "~S");
c$.withAppendedPath = Clazz.defineMethod (c$, "withAppendedPath", 
function (baseUri, pathSegment) {
var builder = baseUri.buildUpon ();
builder = builder.appendEncodedPath (pathSegment);
return builder.build ();
}, "android.net.Uri,~S");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.scheme = null;
this.ssp = null;
this.fragment = null;
this.cachedString = null;
Clazz.instantialize (this, arguments);
}, android.net.Uri, "OpaqueUri", android.net.Uri);
Clazz.prepareFields (c$, function () {
this.cachedString = android.net.Uri.NOT_CACHED;
});
Clazz.makeConstructor (c$, 
($fz = function (a, b, c) {
Clazz.superConstructor (this, android.net.Uri.OpaqueUri, []);
this.scheme = a;
this.ssp = b;
this.fragment = c == null ? android.net.Uri.Part.NULL : c;
}, $fz.isPrivate = true, $fz), "~S,android.net.Uri.Part,android.net.Uri.Part");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.overrideMethod (c$, "isHierarchical", 
function () {
return false;
});
Clazz.overrideMethod (c$, "isRelative", 
function () {
return this.scheme == null;
});
Clazz.overrideMethod (c$, "getScheme", 
function () {
return this.scheme;
});
Clazz.overrideMethod (c$, "getEncodedSchemeSpecificPart", 
function () {
return this.ssp.getEncoded ();
});
Clazz.overrideMethod (c$, "getSchemeSpecificPart", 
function () {
return this.ssp.getDecoded ();
});
Clazz.overrideMethod (c$, "getAuthority", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getEncodedAuthority", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getPath", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getEncodedPath", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getQuery", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getEncodedQuery", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getFragment", 
function () {
return this.fragment.getDecoded ();
});
Clazz.overrideMethod (c$, "getEncodedFragment", 
function () {
return this.fragment.getEncoded ();
});
Clazz.overrideMethod (c$, "getPathSegments", 
function () {
return java.util.Collections.emptyList ();
});
Clazz.overrideMethod (c$, "getLastPathSegment", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getUserInfo", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getEncodedUserInfo", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getHost", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getPort", 
function () {
return -1;
});
Clazz.overrideMethod (c$, "toString", 
function () {
var a = this.cachedString !== android.net.Uri.NOT_CACHED;
if (a) {
return this.cachedString;
}var b =  new StringBuilder ();
b.append (this.scheme).append (':');
b.append (this.getEncodedSchemeSpecificPart ());
if (!this.fragment.isEmpty ()) {
b.append ('#').append (this.fragment.getEncoded ());
}return this.cachedString = b.toString ();
});
Clazz.overrideMethod (c$, "buildUpon", 
function () {
return  new android.net.Uri.Builder ().scheme (this.scheme).opaquePart (this.ssp).fragment (this.fragment);
});
Clazz.defineStatics (c$,
"TYPE_ID", 2);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.segments = null;
this.$size = 0;
Clazz.instantialize (this, arguments);
}, android.net.Uri, "PathSegments", java.util.AbstractList, java.util.RandomAccess);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.net.Uri.PathSegments, []);
this.segments = a;
this.$size = b;
}, "~A,~N");
Clazz.overrideMethod (c$, "get", 
function (a) {
if (a >= this.$size) {
throw  new IndexOutOfBoundsException ();
}return this.segments[a];
}, "~N");
Clazz.overrideMethod (c$, "size", 
function () {
return this.$size;
});
c$.EMPTY = c$.prototype.EMPTY =  new android.net.Uri.PathSegments (null, 0);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.segments = null;
this.size = 0;
Clazz.instantialize (this, arguments);
}, android.net.Uri, "PathSegmentsBuilder");
Clazz.defineMethod (c$, "add", 
function (a) {
if (this.segments == null) {
this.segments =  new Array (4);
} else if (this.size + 1 == this.segments.length) {
var b =  new Array (this.segments.length * 2);
System.arraycopy (this.segments, 0, b, 0, this.segments.length);
this.segments = b;
}this.segments[this.size++] = a;
}, "~S");
Clazz.defineMethod (c$, "build", 
function () {
if (this.segments == null) {
return android.net.Uri.PathSegments.EMPTY;
}try {
return  new android.net.Uri.PathSegments (this.segments, this.size);
} finally {
this.segments = null;
}
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.$scheme = null;
this.$opaquePart = null;
this.$authority = null;
this.$path = null;
this.$query = null;
this.$fragment = null;
Clazz.instantialize (this, arguments);
}, android.net.Uri, "Builder");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "scheme", 
function (a) {
this.$scheme = a;
return this;
}, "~S");
Clazz.defineMethod (c$, "opaquePart", 
function (a) {
this.$opaquePart = a;
return this;
}, "android.net.Uri.Part");
Clazz.defineMethod (c$, "opaquePart", 
function (a) {
return this.opaquePart (android.net.Uri.Part.fromDecoded (a));
}, "~S");
Clazz.defineMethod (c$, "encodedOpaquePart", 
function (a) {
return this.opaquePart (android.net.Uri.Part.fromEncoded (a));
}, "~S");
Clazz.defineMethod (c$, "authority", 
function (a) {
this.$opaquePart = null;
this.$authority = a;
return this;
}, "android.net.Uri.Part");
Clazz.defineMethod (c$, "authority", 
function (a) {
return this.authority (android.net.Uri.Part.fromDecoded (a));
}, "~S");
Clazz.defineMethod (c$, "encodedAuthority", 
function (a) {
return this.authority (android.net.Uri.Part.fromEncoded (a));
}, "~S");
Clazz.defineMethod (c$, "path", 
function (a) {
this.$opaquePart = null;
this.$path = a;
return this;
}, "android.net.Uri.PathPart");
Clazz.defineMethod (c$, "path", 
function (a) {
return this.path (android.net.Uri.PathPart.fromDecoded (a));
}, "~S");
Clazz.defineMethod (c$, "encodedPath", 
function (a) {
return this.path (android.net.Uri.PathPart.fromEncoded (a));
}, "~S");
Clazz.defineMethod (c$, "appendPath", 
function (a) {
return this.path (android.net.Uri.PathPart.appendDecodedSegment (this.$path, a));
}, "~S");
Clazz.defineMethod (c$, "appendEncodedPath", 
function (a) {
return this.path (android.net.Uri.PathPart.appendEncodedSegment (this.$path, a));
}, "~S");
Clazz.defineMethod (c$, "query", 
function (a) {
this.$opaquePart = null;
this.$query = a;
return this;
}, "android.net.Uri.Part");
Clazz.defineMethod (c$, "query", 
function (a) {
return this.query (android.net.Uri.Part.fromDecoded (a));
}, "~S");
Clazz.defineMethod (c$, "encodedQuery", 
function (a) {
return this.query (android.net.Uri.Part.fromEncoded (a));
}, "~S");
Clazz.defineMethod (c$, "fragment", 
function (a) {
this.$fragment = a;
return this;
}, "android.net.Uri.Part");
Clazz.defineMethod (c$, "fragment", 
function (a) {
return this.fragment (android.net.Uri.Part.fromDecoded (a));
}, "~S");
Clazz.defineMethod (c$, "encodedFragment", 
function (a) {
return this.fragment (android.net.Uri.Part.fromEncoded (a));
}, "~S");
Clazz.defineMethod (c$, "appendQueryParameter", 
function (a, b) {
this.$opaquePart = null;
var c = android.net.Uri.encode (a, null) + "=" + android.net.Uri.encode (b, null);
if (this.$query == null) {
this.$query = android.net.Uri.Part.fromEncoded (c);
return this;
}var d = this.$query.getEncoded ();
if (d == null || d.length == 0) {
this.$query = android.net.Uri.Part.fromEncoded (c);
} else {
this.$query = android.net.Uri.Part.fromEncoded (d + "&" + c);
}return this;
}, "~S,~S");
Clazz.defineMethod (c$, "build", 
function () {
if (this.$opaquePart != null) {
if (this.$scheme == null) {
throw  new UnsupportedOperationException ("An opaque URI must have a scheme.");
}return  new android.net.Uri.OpaqueUri (this.$scheme, this.$opaquePart, this.$fragment);
} else {
var a = this.$path;
if (a == null || a === android.net.Uri.PathPart.NULL) {
a = android.net.Uri.PathPart.EMPTY;
} else {
if (this.hasSchemeOrAuthority ()) {
a = android.net.Uri.PathPart.makeAbsolute (a);
}}try {
var b = Class.forName ("android.net.HierarchicalUri").getConstructor ([String, android.net.Uri.Part, android.net.Uri.PathPart, android.net.Uri.Part, android.net.Uri.Part]);
return b.newInstance ([this.$scheme, this.$authority, a, this.$query, this.$fragment]);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
System.out.println ("Fail to initialize HierarchicalUri");
return null;
} else {
throw e;
}
}
}});
Clazz.defineMethod (c$, "hasSchemeOrAuthority", 
($fz = function () {
return this.$scheme != null || (this.$authority != null && this.$authority !== android.net.Uri.Part.NULL);
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "toString", 
function () {
return this.build ().toString ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.encoded = null;
this.decoded = null;
Clazz.instantialize (this, arguments);
}, android.net.Uri, "AbstractPart");
Clazz.makeConstructor (c$, 
function (a, b) {
this.encoded = a;
this.decoded = b;
}, "~S,~S");
Clazz.defineMethod (c$, "getDecoded", 
function () {
var a = this.decoded !== android.net.Uri.NOT_CACHED;
return a ? this.decoded : (this.decoded = android.net.Uri.decode (this.encoded));
});
Clazz.pu$h ();
c$ = Clazz.declareType (android.net.Uri.AbstractPart, "Representation");
Clazz.defineStatics (c$,
"BOTH", 0,
"ENCODED", 1,
"DECODED", 2);
c$ = Clazz.p0p ();
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.net.Uri, "Part", android.net.Uri.AbstractPart);
Clazz.defineMethod (c$, "isEmpty", 
function () {
return false;
});
Clazz.overrideMethod (c$, "getEncoded", 
function () {
var a = this.encoded !== android.net.Uri.NOT_CACHED;
return a ? this.encoded : (this.encoded = android.net.Uri.encode (this.decoded));
});
c$.nonNull = Clazz.defineMethod (c$, "nonNull", 
function (a) {
return a == null ? android.net.Uri.Part.NULL : a;
}, "android.net.Uri.Part");
c$.fromEncoded = Clazz.defineMethod (c$, "fromEncoded", 
function (a) {
return android.net.Uri.Part.from (a, android.net.Uri.NOT_CACHED);
}, "~S");
c$.fromDecoded = Clazz.defineMethod (c$, "fromDecoded", 
function (a) {
return android.net.Uri.Part.from (android.net.Uri.NOT_CACHED, a);
}, "~S");
c$.from = Clazz.defineMethod (c$, "from", 
function (a, b) {
if (a == null) {
return android.net.Uri.Part.NULL;
}if (a.length == 0) {
return android.net.Uri.Part.EMPTY;
}if (b == null) {
return android.net.Uri.Part.NULL;
}if (b.length == 0) {
return android.net.Uri.Part.EMPTY;
}return  new android.net.Uri.Part (a, b);
}, "~S,~S");
Clazz.pu$h ();
c$ = Clazz.declareType (android.net.Uri.Part, "EmptyPart", android.net.Uri.Part);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.net.Uri.Part.EmptyPart, [a, a]);
}, "~S");
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return true;
});
c$ = Clazz.p0p ();
c$.NULL = c$.prototype.NULL =  new android.net.Uri.Part.EmptyPart (null);
c$.EMPTY = c$.prototype.EMPTY =  new android.net.Uri.Part.EmptyPart ("");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.pathSegments = null;
Clazz.instantialize (this, arguments);
}, android.net.Uri, "PathPart", android.net.Uri.AbstractPart);
Clazz.overrideMethod (c$, "getEncoded", 
function () {
var a = this.encoded !== android.net.Uri.NOT_CACHED;
return a ? this.encoded : (this.encoded = android.net.Uri.encode (this.decoded, "/"));
});
Clazz.defineMethod (c$, "getPathSegments", 
function () {
if (this.pathSegments != null) {
return this.pathSegments;
}var a = this.getEncoded ();
if (a == null) {
return this.pathSegments = android.net.Uri.PathSegments.EMPTY;
}var b =  new android.net.Uri.PathSegmentsBuilder ();
var c = 0;
var d;
while ((d = a.indexOf ('/', c)) > -1) {
if (c < d) {
var e = android.net.Uri.decode (a.substring (c, d));
b.add (e);
}c = d + 1;
}
if (c < a.length) {
b.add (android.net.Uri.decode (a.substring (c)));
}return this.pathSegments = b.build ();
});
c$.appendEncodedSegment = Clazz.defineMethod (c$, "appendEncodedSegment", 
function (a, b) {
if (a == null) {
return android.net.Uri.PathPart.fromEncoded ("/" + b);
}var c = a.getEncoded ();
if (c == null) {
c = "";
}var d = c.length;
var e;
if (d == 0) {
e = "/" + b;
} else if ((c.charAt (d - 1)).charCodeAt (0) == ('/').charCodeAt (0)) {
e = c + b;
} else {
e = c + "/" + b;
}return android.net.Uri.PathPart.fromEncoded (e);
}, "android.net.Uri.PathPart,~S");
c$.appendDecodedSegment = Clazz.defineMethod (c$, "appendDecodedSegment", 
function (a, b) {
var c = android.net.Uri.encode (b);
return android.net.Uri.PathPart.appendEncodedSegment (a, c);
}, "android.net.Uri.PathPart,~S");
c$.fromEncoded = Clazz.defineMethod (c$, "fromEncoded", 
function (a) {
return android.net.Uri.PathPart.from (a, android.net.Uri.NOT_CACHED);
}, "~S");
c$.fromDecoded = Clazz.defineMethod (c$, "fromDecoded", 
function (a) {
return android.net.Uri.PathPart.from (android.net.Uri.NOT_CACHED, a);
}, "~S");
c$.from = Clazz.defineMethod (c$, "from", 
function (a, b) {
if (a == null) {
return android.net.Uri.PathPart.NULL;
}if (a.length == 0) {
return android.net.Uri.PathPart.EMPTY;
}return  new android.net.Uri.PathPart (a, b);
}, "~S,~S");
c$.makeAbsolute = Clazz.defineMethod (c$, "makeAbsolute", 
function (a) {
var b = a.encoded !== android.net.Uri.NOT_CACHED;
var c = b ? a.encoded : a.decoded;
if (c == null || c.length == 0 || c.startsWith ("/")) {
return a;
}var d = b ? "/" + a.encoded : android.net.Uri.NOT_CACHED;
var e = a.decoded !== android.net.Uri.NOT_CACHED;
var f = e ? "/" + a.decoded : android.net.Uri.NOT_CACHED;
return  new android.net.Uri.PathPart (d, f);
}, "android.net.Uri.PathPart");
c$.NULL = c$.prototype.NULL =  new android.net.Uri.PathPart (null, null);
c$.EMPTY = c$.prototype.EMPTY =  new android.net.Uri.PathPart ("", "");
c$ = Clazz.p0p ();
c$.NOT_CACHED = c$.prototype.NOT_CACHED =  String.instantialize ("NOT CACHED");
Clazz.defineStatics (c$,
"NOT_FOUND", -1,
"NOT_CALCULATED", -2,
"NOT_HIERARCHICAL", "This isn't a hierarchical URI.",
"DEFAULT_ENCODING", "UTF-8",
"NULL_TYPE_ID", 0);
c$.HEX_DIGITS = c$.prototype.HEX_DIGITS = "0123456789ABCDEF".toCharArray ();
Clazz.defineStatics (c$,
"REPLACEMENT", [0xFF, 0xFD]);
});
