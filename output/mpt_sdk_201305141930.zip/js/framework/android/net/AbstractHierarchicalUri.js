﻿Clazz.declarePackage ("android.net");
Clazz.load (["android.net.Uri"], "android.net.AbstractHierarchicalUri", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.userInfo = null;
this.host = null;
this.port = -2;
Clazz.instantialize (this, arguments);
}, android.net, "AbstractHierarchicalUri", android.net.Uri);
Clazz.prepareFields (c$, function () {
this.host = android.net.Uri.NOT_CACHED;
});
Clazz.overrideMethod (c$, "getLastPathSegment", 
function () {
var segments = this.getPathSegments ();
var size = segments.size ();
if (size == 0) {
return null;
}return segments.get (size - 1);
});
Clazz.defineMethod (c$, "getUserInfoPart", 
($fz = function () {
return this.userInfo == null ? this.userInfo = android.net.Uri.Part.fromEncoded (this.parseUserInfo ()) : this.userInfo;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getEncodedUserInfo", 
function () {
return this.getUserInfoPart ().getEncoded ();
});
Clazz.defineMethod (c$, "parseUserInfo", 
($fz = function () {
var authority = this.getEncodedAuthority ();
if (authority == null) {
return null;
}var end = authority.indexOf ('@');
return end == -1 ? null : authority.substring (0, end);
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getUserInfo", 
function () {
return this.getUserInfoPart ().getDecoded ();
});
Clazz.overrideMethod (c$, "getHost", 
function () {
var cached = (this.host !== android.net.Uri.NOT_CACHED);
return cached ? this.host : (this.host = this.parseHost ());
});
Clazz.defineMethod (c$, "parseHost", 
($fz = function () {
var authority = this.getEncodedAuthority ();
if (authority == null) {
return null;
}var userInfoSeparator = authority.indexOf ('@');
var portSeparator = authority.indexOf (':', userInfoSeparator);
var encodedHost = portSeparator == -1 ? authority.substring (userInfoSeparator + 1) : authority.substring (userInfoSeparator + 1, portSeparator);
return android.net.Uri.decode (encodedHost);
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getPort", 
function () {
return this.port == -2 ? this.port = this.parsePort () : this.port;
});
Clazz.defineMethod (c$, "parsePort", 
($fz = function () {
var authority = this.getEncodedAuthority ();
if (authority == null) {
return -1;
}var userInfoSeparator = authority.indexOf ('@');
var portSeparator = authority.indexOf (':', userInfoSeparator);
if (portSeparator == -1) {
return -1;
}var portString = android.net.Uri.decode (authority.substring (portSeparator + 1));
try {
return Integer.parseInt (portString);
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
return -1;
} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz));
});
