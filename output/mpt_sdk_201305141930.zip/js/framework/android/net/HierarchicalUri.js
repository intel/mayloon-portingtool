﻿Clazz.declarePackage ("android.net");
Clazz.load (["android.net.AbstractHierarchicalUri", "$.Uri"], "android.net.HierarchicalUri", ["java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.scheme = null;
this.authority = null;
this.path = null;
this.query = null;
this.fragment = null;
this.ssp = null;
this.uriString = null;
Clazz.instantialize (this, arguments);
}, android.net, "HierarchicalUri", android.net.AbstractHierarchicalUri);
Clazz.prepareFields (c$, function () {
this.uriString = android.net.Uri.NOT_CACHED;
});
Clazz.makeConstructor (c$, 
function (scheme, authority, path, query, fragment) {
Clazz.superConstructor (this, android.net.HierarchicalUri, []);
System.out.println ("???");
this.scheme = scheme;
this.authority = android.net.Uri.Part.nonNull (authority);
this.path = path == null ? android.net.Uri.PathPart.NULL : path;
this.query = android.net.Uri.Part.nonNull (query);
this.fragment = android.net.Uri.Part.nonNull (fragment);
System.out.println ("!!!");
}, "~S,android.net.Uri.Part,android.net.Uri.PathPart,android.net.Uri.Part,android.net.Uri.Part");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.overrideMethod (c$, "isHierarchical", 
function () {
return true;
});
Clazz.overrideMethod (c$, "isRelative", 
function () {
return this.scheme == null;
});
Clazz.overrideMethod (c$, "getScheme", 
function () {
return this.scheme;
});
Clazz.defineMethod (c$, "getSsp", 
($fz = function () {
return this.ssp == null ? this.ssp = android.net.Uri.Part.fromEncoded (this.makeSchemeSpecificPart ()) : this.ssp;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getEncodedSchemeSpecificPart", 
function () {
return this.getSsp ().getEncoded ();
});
Clazz.overrideMethod (c$, "getSchemeSpecificPart", 
function () {
return this.getSsp ().getDecoded ();
});
Clazz.defineMethod (c$, "makeSchemeSpecificPart", 
($fz = function () {
var builder =  new StringBuilder ();
this.appendSspTo (builder);
return builder.toString ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "appendSspTo", 
($fz = function (builder) {
var encodedAuthority = this.authority.getEncoded ();
if (encodedAuthority != null) {
builder.append ("//").append (encodedAuthority);
}var encodedPath = this.path.getEncoded ();
if (encodedPath != null) {
builder.append (encodedPath);
}if (!this.query.isEmpty ()) {
builder.append ('?').append (this.query.getEncoded ());
}}, $fz.isPrivate = true, $fz), "StringBuilder");
Clazz.overrideMethod (c$, "getAuthority", 
function () {
return this.authority.getDecoded ();
});
Clazz.overrideMethod (c$, "getEncodedAuthority", 
function () {
return this.authority.getEncoded ();
});
Clazz.overrideMethod (c$, "getEncodedPath", 
function () {
return this.path.getEncoded ();
});
Clazz.overrideMethod (c$, "getPath", 
function () {
return this.path.getDecoded ();
});
Clazz.overrideMethod (c$, "getQuery", 
function () {
return this.query.getDecoded ();
});
Clazz.overrideMethod (c$, "getEncodedQuery", 
function () {
return this.query.getEncoded ();
});
Clazz.overrideMethod (c$, "getFragment", 
function () {
return this.fragment.getDecoded ();
});
Clazz.overrideMethod (c$, "getEncodedFragment", 
function () {
return this.fragment.getEncoded ();
});
Clazz.overrideMethod (c$, "getPathSegments", 
function () {
return this.path.getPathSegments ();
});
Clazz.overrideMethod (c$, "toString", 
function () {
var cached = (this.uriString !== android.net.Uri.NOT_CACHED);
return cached ? this.uriString : (this.uriString = this.makeUriString ());
});
Clazz.defineMethod (c$, "makeUriString", 
($fz = function () {
var builder =  new StringBuilder ();
if (this.scheme != null) {
builder.append (this.scheme).append (':');
}this.appendSspTo (builder);
if (!this.fragment.isEmpty ()) {
builder.append ('#').append (this.fragment.getEncoded ());
}return builder.toString ();
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "buildUpon", 
function () {
return  new android.net.Uri.Builder ().scheme (this.scheme).authority (this.authority).path (this.path).query (this.query).fragment (this.fragment);
});
Clazz.defineStatics (c$,
"TYPE_ID", 3);
});
