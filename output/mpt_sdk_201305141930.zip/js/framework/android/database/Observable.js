﻿Clazz.declarePackage ("android.database");
Clazz.load (["java.util.ArrayList"], "android.database.Observable", ["java.lang.IllegalArgumentException", "$.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mObservers = null;
Clazz.instantialize (this, arguments);
}, android.database, "Observable");
Clazz.prepareFields (c$, function () {
this.mObservers =  new java.util.ArrayList ();
});
Clazz.defineMethod (c$, "registerObserver", 
function (observer) {
if (observer == null) {
throw  new IllegalArgumentException ("The observer is null.");
}{
if (this.mObservers.contains (observer)) {
throw  new IllegalStateException ("Observer " + observer + " is already registered.");
}this.mObservers.add (observer);
}}, "~O");
Clazz.defineMethod (c$, "unregisterObserver", 
function (observer) {
if (observer == null) {
throw  new IllegalArgumentException ("The observer is null.");
}{
var index = this.mObservers.indexOf (observer);
if (index == -1) {
throw  new IllegalStateException ("Observer " + observer + " was not registered.");
}this.mObservers.remove (index);
}}, "~O");
Clazz.defineMethod (c$, "unregisterAll", 
function () {
{
this.mObservers.clear ();
}});
});
