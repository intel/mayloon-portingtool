﻿Clazz.declarePackage ("android.database");
Clazz.load (["android.database.Observable"], "android.database.ContentObservable", null, function () {
c$ = Clazz.declareType (android.database, "ContentObservable", android.database.Observable);
Clazz.defineMethod (c$, "dispatchChange", 
function (selfChange) {
{
for (var observer, $observer = this.mObservers.iterator (); $observer.hasNext () && ((observer = $observer.next ()) || true);) {
if (!selfChange || observer.deliverSelfNotifications ()) {
observer.dispatchChange (selfChange);
}}
}}, "~B");
Clazz.defineMethod (c$, "notifyChange", 
function (selfChange) {
{
for (var observer, $observer = this.mObservers.iterator (); $observer.hasNext () && ((observer = $observer.next ()) || true);) {
observer.onChange (selfChange);
}
}}, "~B");
});
