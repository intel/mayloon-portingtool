﻿Clazz.declarePackage ("android.database");
Clazz.load (["android.database.ContentObserver", "$.CrossProcessCursor", "$.ContentObservable", "$.DataSetObservable"], "android.database.AbstractCursor", ["android.database.CursorIndexOutOfBoundsException", "android.os.Bundle", "android.util.Log", "java.lang.Double", "$.Exception", "$.Float", "$.IllegalArgumentException", "$.IllegalStateException", "$.Long", "$.Short", "$.UnsupportedOperationException", "java.lang.ref.WeakReference", "java.util.HashMap"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDataSetObservable = null;
this.mContentObservable = null;
this.mUpdatedRows = null;
this.mRowIdColumnIndex = 0;
this.mPos = 0;
this.mCurrentRowID = null;
this.mContentResolver = null;
this.mClosed = false;
this.mNotifyUri = null;
this.mSelfObserver = null;
this.mSelfObserverLock = null;
this.mSelfObserverRegistered = false;
Clazz.instantialize (this, arguments);
}, android.database, "AbstractCursor", null, android.database.CrossProcessCursor);
Clazz.prepareFields (c$, function () {
this.mDataSetObservable =  new android.database.DataSetObservable ();
this.mContentObservable =  new android.database.ContentObservable ();
this.mSelfObserverLock =  new JavaObject ();
});
Clazz.overrideMethod (c$, "getBlob", 
function (column) {
throw  new UnsupportedOperationException ("getBlob is not supported");
}, "~N");
Clazz.overrideMethod (c$, "getWindow", 
function () {
return null;
});
Clazz.overrideMethod (c$, "getColumnCount", 
function () {
return this.getColumnNames ().length;
});
Clazz.overrideMethod (c$, "deactivate", 
function () {
this.deactivateInternal ();
});
Clazz.defineMethod (c$, "deactivateInternal", 
function () {
if (this.mSelfObserver != null) {
this.mContentResolver.unregisterContentObserver (this.mSelfObserver);
this.mSelfObserverRegistered = false;
}this.mDataSetObservable.notifyInvalidated ();
});
Clazz.overrideMethod (c$, "requery", 
function () {
if (this.mSelfObserver != null && this.mSelfObserverRegistered == false) {
this.mContentResolver.registerContentObserver (this.mNotifyUri, true, this.mSelfObserver);
this.mSelfObserverRegistered = true;
}this.mDataSetObservable.notifyChanged ();
return true;
});
Clazz.overrideMethod (c$, "isClosed", 
function () {
return this.mClosed;
});
Clazz.overrideMethod (c$, "close", 
function () {
this.mClosed = true;
this.mContentObservable.unregisterAll ();
this.deactivateInternal ();
});
Clazz.defineMethod (c$, "commitUpdates", 
function (values) {
return false;
}, "java.util.Map");
Clazz.overrideMethod (c$, "deleteRow", 
function () {
return false;
});
Clazz.overrideMethod (c$, "onMove", 
function (oldPosition, newPosition) {
return true;
}, "~N,~N");
Clazz.overrideMethod (c$, "copyStringToBuffer", 
function (columnIndex, buffer) {
var result = this.getString (columnIndex);
if (result != null) {
var data = buffer.data;
if (data == null || data.length < result.length) {
buffer.data = result.toCharArray ();
} else {
result.getChars (0, result.length, data, 0);
}buffer.sizeCopied = result.length;
}}, "~N,android.database.CharArrayBuffer");
Clazz.makeConstructor (c$, 
function () {
this.mPos = -1;
this.mRowIdColumnIndex = -1;
this.mCurrentRowID = null;
this.mUpdatedRows =  new java.util.HashMap ();
});
Clazz.overrideMethod (c$, "getPosition", 
function () {
return this.mPos;
});
Clazz.overrideMethod (c$, "moveToPosition", 
function (position) {
var count = this.getCount ();
if (position >= count) {
this.mPos = count;
return false;
}if (position < 0) {
this.mPos = -1;
return false;
}if (position == this.mPos) {
return true;
}var result = this.onMove (this.mPos, position);
if (result == false) {
this.mPos = -1;
} else {
this.mPos = position;
if (this.mRowIdColumnIndex != -1) {
this.mCurrentRowID = Long.$valueOf (this.getLong (this.mRowIdColumnIndex));
}}return result;
}, "~N");
Clazz.overrideMethod (c$, "fillWindow", 
function (position, window) {
if (position < 0 || position >= this.getCount ()) {
return ;
}window.acquireReference ();
try {
var oldpos = this.mPos;
this.mPos = position - 1;
window.clear ();
window.setStartPosition (position);
var columnNum = this.getColumnCount ();
window.setNumColumns (columnNum);
while (this.moveToNext () && window.allocRow ()) {
for (var i = 0; i < columnNum; i++) {
var field = this.getString (i);
if (field != null) {
if (!window.putString (field, this.mPos, i)) {
window.freeLastRow ();
break;
}} else {
if (!window.putNull (this.mPos, i)) {
window.freeLastRow ();
break;
}}}
}
this.mPos = oldpos;
} catch (e) {
if (Clazz.instanceOf (e, IllegalStateException)) {
} else {
throw e;
}
} finally {
window.releaseReference ();
}
}, "~N,android.database.CursorWindow");
Clazz.overrideMethod (c$, "move", 
function (offset) {
return this.moveToPosition (this.mPos + offset);
}, "~N");
Clazz.overrideMethod (c$, "moveToFirst", 
function () {
return this.moveToPosition (0);
});
Clazz.overrideMethod (c$, "moveToLast", 
function () {
return this.moveToPosition (this.getCount () - 1);
});
Clazz.overrideMethod (c$, "moveToNext", 
function () {
return this.moveToPosition (this.mPos + 1);
});
Clazz.overrideMethod (c$, "moveToPrevious", 
function () {
return this.moveToPosition (this.mPos - 1);
});
Clazz.overrideMethod (c$, "isFirst", 
function () {
return this.mPos == 0 && this.getCount () != 0;
});
Clazz.overrideMethod (c$, "isLast", 
function () {
var cnt = this.getCount ();
return this.mPos == (cnt - 1) && cnt != 0;
});
Clazz.overrideMethod (c$, "isBeforeFirst", 
function () {
if (this.getCount () == 0) {
return true;
}return this.mPos == -1;
});
Clazz.overrideMethod (c$, "isAfterLast", 
function () {
if (this.getCount () == 0) {
return true;
}return this.mPos == this.getCount ();
});
Clazz.overrideMethod (c$, "getColumnIndex", 
function (columnName) {
var periodIndex = columnName.lastIndexOf ('.');
if (periodIndex != -1) {
var e =  new Exception ();
android.util.Log.e ("Cursor", "requesting column name with table name -- " + columnName, e);
columnName = columnName.substring (periodIndex + 1);
}var columnNames = this.getColumnNames ();
var length = columnNames.length;
for (var i = 0; i < length; i++) {
if (columnNames[i].equalsIgnoreCase (columnName)) {
return i;
}}
if (false) {
if (this.getCount () > 0) {
android.util.Log.w ("AbstractCursor", "Unknown column " + columnName);
}}return -1;
}, "~S");
Clazz.overrideMethod (c$, "getColumnIndexOrThrow", 
function (columnName) {
var index = this.getColumnIndex (columnName);
if (index < 0) {
throw  new IllegalArgumentException ("column '" + columnName + "' does not exist");
}return index;
}, "~S");
Clazz.overrideMethod (c$, "getColumnName", 
function (columnIndex) {
var columnNames = this.getColumnNames ();
var length = columnNames.length;
if (columnIndex < 0 || columnIndex >= length) {
throw  new IllegalArgumentException ("columnIndex is out of columns");
}return this.getColumnNames ()[columnIndex];
}, "~N");
Clazz.overrideMethod (c$, "updateBlob", 
function (columnIndex, value) {
return this.update (columnIndex, value);
}, "~N,~A");
Clazz.overrideMethod (c$, "updateString", 
function (columnIndex, value) {
return this.update (columnIndex, value);
}, "~N,~S");
Clazz.overrideMethod (c$, "updateShort", 
function (columnIndex, value) {
return this.update (columnIndex, Short.$valueOf (value));
}, "~N,~N");
Clazz.overrideMethod (c$, "updateInt", 
function (columnIndex, value) {
return this.update (columnIndex, Integer.$valueOf (value));
}, "~N,~N");
Clazz.overrideMethod (c$, "updateLong", 
function (columnIndex, value) {
return this.update (columnIndex, Long.$valueOf (value));
}, "~N,~N");
Clazz.overrideMethod (c$, "updateFloat", 
function (columnIndex, value) {
return this.update (columnIndex, Float.$valueOf (value));
}, "~N,~N");
Clazz.overrideMethod (c$, "updateDouble", 
function (columnIndex, value) {
return this.update (columnIndex, Double.$valueOf (value));
}, "~N,~N");
Clazz.overrideMethod (c$, "updateToNull", 
function (columnIndex) {
return this.update (columnIndex, null);
}, "~N");
Clazz.defineMethod (c$, "update", 
function (columnIndex, obj) {
if (!this.supportsUpdates ()) {
return false;
}var rowid =  new Long (this.getLong (this.mRowIdColumnIndex));
if (rowid == null) {
throw  new IllegalStateException ("null rowid. mRowIdColumnIndex = " + this.mRowIdColumnIndex);
}{
var row = this.mUpdatedRows.get (rowid);
if (row == null) {
row =  new java.util.HashMap ();
this.mUpdatedRows.put (rowid, row);
}row.put (this.getColumnNames ()[columnIndex], obj);
}return true;
}, "~N,~O");
Clazz.overrideMethod (c$, "hasUpdates", 
function () {
{
return this.mUpdatedRows.size () > 0;
}});
Clazz.overrideMethod (c$, "abortUpdates", 
function () {
{
this.mUpdatedRows.clear ();
}});
Clazz.defineMethod (c$, "commitUpdates", 
function () {
return this.commitUpdates (null);
});
Clazz.overrideMethod (c$, "supportsUpdates", 
function () {
return this.mRowIdColumnIndex != -1;
});
Clazz.overrideMethod (c$, "registerContentObserver", 
function (observer) {
this.mContentObservable.registerObserver (observer);
}, "android.database.ContentObserver");
Clazz.overrideMethod (c$, "unregisterContentObserver", 
function (observer) {
if (!this.mClosed) {
this.mContentObservable.unregisterObserver (observer);
}}, "android.database.ContentObserver");
Clazz.defineMethod (c$, "notifyDataSetChange", 
function () {
this.mDataSetObservable.notifyChanged ();
});
Clazz.defineMethod (c$, "getDataSetObservable", 
function () {
return this.mDataSetObservable;
});
Clazz.overrideMethod (c$, "registerDataSetObserver", 
function (observer) {
this.mDataSetObservable.registerObserver (observer);
}, "android.database.DataSetObserver");
Clazz.overrideMethod (c$, "unregisterDataSetObserver", 
function (observer) {
this.mDataSetObservable.unregisterObserver (observer);
}, "android.database.DataSetObserver");
Clazz.defineMethod (c$, "onChange", 
function (selfChange) {
{
this.mContentObservable.dispatchChange (selfChange);
if (this.mNotifyUri != null && selfChange) {
this.mContentResolver.notifyChange (this.mNotifyUri, this.mSelfObserver);
}}}, "~B");
Clazz.overrideMethod (c$, "setNotificationUri", 
function (cr, notifyUri) {
{
this.mNotifyUri = notifyUri;
this.mContentResolver = cr;
if (this.mSelfObserver != null) {
this.mContentResolver.unregisterContentObserver (this.mSelfObserver);
}this.mSelfObserver =  new android.database.AbstractCursor.SelfContentObserver (this);
this.mContentResolver.registerContentObserver (this.mNotifyUri, true, this.mSelfObserver);
this.mSelfObserverRegistered = true;
}}, "android.content.ContentResolver,android.net.Uri");
Clazz.overrideMethod (c$, "getWantsAllOnMoveCalls", 
function () {
return false;
});
Clazz.overrideMethod (c$, "getExtras", 
function () {
return android.os.Bundle.EMPTY;
});
Clazz.overrideMethod (c$, "respond", 
function (extras) {
return android.os.Bundle.EMPTY;
}, "android.os.Bundle");
Clazz.defineMethod (c$, "isFieldUpdated", 
function (columnIndex) {
if (this.mRowIdColumnIndex != -1 && this.mUpdatedRows.size () > 0) {
var updates = this.mUpdatedRows.get (this.mCurrentRowID);
if (updates != null && updates.containsKey (this.getColumnNames ()[columnIndex])) {
return true;
}}return false;
}, "~N");
Clazz.defineMethod (c$, "getUpdatedField", 
function (columnIndex) {
var updates = this.mUpdatedRows.get (this.mCurrentRowID);
return updates.get (this.getColumnNames ()[columnIndex]);
}, "~N");
Clazz.defineMethod (c$, "checkPosition", 
function () {
if (-1 == this.mPos || this.getCount () == this.mPos) {
throw  new android.database.CursorIndexOutOfBoundsException (this.mPos, this.getCount ());
}});
Clazz.overrideMethod (c$, "finalize", 
function () {
if (this.mSelfObserver != null && this.mSelfObserverRegistered == true) {
this.mContentResolver.unregisterContentObserver (this.mSelfObserver);
}});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mCursor = null;
Clazz.instantialize (this, arguments);
}, android.database.AbstractCursor, "SelfContentObserver", android.database.ContentObserver);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.database.AbstractCursor.SelfContentObserver, [null]);
this.mCursor =  new java.lang.ref.WeakReference (a);
}, "android.database.AbstractCursor");
Clazz.overrideMethod (c$, "deliverSelfNotifications", 
function () {
return false;
});
Clazz.overrideMethod (c$, "onChange", 
function (a) {
var b = this.mCursor.get ();
if (b != null) {
b.onChange (false);
}}, "~B");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "Cursor");
});
