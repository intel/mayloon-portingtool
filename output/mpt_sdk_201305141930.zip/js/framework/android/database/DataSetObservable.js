﻿Clazz.declarePackage ("android.database");
Clazz.load (["android.database.Observable"], "android.database.DataSetObservable", null, function () {
c$ = Clazz.declareType (android.database, "DataSetObservable", android.database.Observable);
Clazz.defineMethod (c$, "notifyChanged", 
function () {
{
for (var observer, $observer = this.mObservers.iterator (); $observer.hasNext () && ((observer = $observer.next ()) || true);) {
observer.onChanged ();
}
}});
Clazz.defineMethod (c$, "notifyInvalidated", 
function () {
{
for (var observer, $observer = this.mObservers.iterator (); $observer.hasNext () && ((observer = $observer.next ()) || true);) {
observer.onInvalidated ();
}
}});
});
