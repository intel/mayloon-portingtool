﻿Clazz.declarePackage ("android.database");
Clazz.load (["java.lang.RuntimeException"], "android.database.StaleDataException", null, function () {
c$ = Clazz.declareType (android.database, "StaleDataException", RuntimeException);
});
