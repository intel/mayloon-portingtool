﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (["android.database.sqlite.SQLiteClosable", "java.util.HashMap", "$.Random", "java.util.regex.Pattern"], "android.database.sqlite.SQLiteDatabase", ["android.database.sqlite.SQLiteDirectCursorDriver", "$.SQLiteQueryBuilder", "android.util.Log", "java.io.File", "java.lang.IllegalArgumentException", "$.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mInnerTransactionIsSuccessful = false;
this.mTransactionIsSuccessful = false;
this.mRandom = null;
this.mLastSqlStatement = null;
this.mNativeHandle = 0;
this.mTempTableSequence = 0;
this.mPath = null;
this.mPathForLogs = null;
this.mFlags = 0;
this.mFactory = null;
this.mPrograms = null;
this.mCompiledQueries = null;
this.mMaxSqlCacheSize = 250;
this.mCacheFullWarnings = 0;
this.mNumCacheHits = 0;
this.mNumCacheMisses = 0;
this.mTimeOpened = null;
this.mTimeClosed = null;
this.mStackTrace = null;
Clazz.instantialize (this, arguments);
}, android.database.sqlite, "SQLiteDatabase", android.database.sqlite.SQLiteClosable);
Clazz.prepareFields (c$, function () {
{
// var indexedDB = null;
var webdatabase = null;
}this.mRandom =  new java.util.Random ();
this.mCompiledQueries =  new java.util.HashMap ();
});
c$.openDatabase = Clazz.defineMethod (c$, "openDatabase", 
function (path, factory, flags) {
var sqliteDatabase = null;
try {
sqliteDatabase =  new android.database.sqlite.SQLiteDatabase (path, factory, flags);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.e ("Database", "Deleting and re-creating corrupt database " + path, e);
if (!path.equalsIgnoreCase (":memory")) {
 new java.io.File (path).$delete ();
}sqliteDatabase =  new android.database.sqlite.SQLiteDatabase (path, factory, flags);
} else {
throw e;
}
}
return sqliteDatabase;
}, "~S,android.database.sqlite.SQLiteDatabase.CursorFactory,~N");
c$.openOrCreateDatabase = Clazz.defineMethod (c$, "openOrCreateDatabase", 
function (file, factory) {
return android.database.sqlite.SQLiteDatabase.openOrCreateDatabase (file.getPath (), factory);
}, "java.io.File,android.database.sqlite.SQLiteDatabase.CursorFactory");
c$.openOrCreateDatabase = Clazz.defineMethod (c$, "openOrCreateDatabase", 
function (path, factory) {
return android.database.sqlite.SQLiteDatabase.openDatabase (path, factory, 268435456);
}, "~S,android.database.sqlite.SQLiteDatabase.CursorFactory");
Clazz.defineMethod (c$, "close", 
function () {
});
Clazz.defineMethod (c$, "getVersion", 
function () {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return 1;
var version = 0;
var sqlversion = webdatabase.version;
version = parseInt(sqlversion);
return version;
});
Clazz.defineMethod (c$, "setVersion", 
function (version) {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return ;
var temp, notifier;
var newversion = version;
var oldversion = webdatabase.version;
webdatabase.changeVersion(oldversion, newversion, function() {} , function(e) {
throw(e.message);
notifier = false; }, function() {
notifier = true;
alert("success to change the Database version!");	});
while ( notifier === undefined) {
yield();
}
temp = notifier;
}, "~N");
Clazz.defineMethod (c$, "getMaximumSize", 
function () {
return this.mCacheFullWarnings;
});
Clazz.defineMethod (c$, "setMaximumSize", 
function (numBytes) {
return numBytes;
}, "~N");
Clazz.defineMethod (c$, "getPageSize", 
function () {
return this.mCacheFullWarnings;
});
Clazz.defineMethod (c$, "setPageSize", 
function (numBytes) {
this.execSQL ("PRAGMA page_size = " + numBytes);
}, "~N");
c$.findEditTable = Clazz.defineMethod (c$, "findEditTable", 
function (tables) {
var spacepos = tables.indexOf (' ');
var commapos = tables.indexOf (',');
if (spacepos > 0 && (spacepos < commapos || commapos < 0)) {
return tables.substring (0, spacepos);
} else if (commapos > 0 && (commapos < spacepos || spacepos < 0)) {
return tables.substring (0, commapos);
}return tables;
}, "~S");
Clazz.defineMethod (c$, "query", 
function (distinct, table, columns, selection, selectionArgs, groupBy, having, orderBy, limit) {
return this.queryWithFactory (null, distinct, table, columns, selection, selectionArgs, groupBy, having, orderBy, limit);
}, "~B,~S,~A,~S,~A,~S,~S,~S,~S");
Clazz.defineMethod (c$, "queryWithFactory", 
function (cursorFactory, distinct, table, columns, selection, selectionArgs, groupBy, having, orderBy, limit) {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return null;
var sql = android.database.sqlite.SQLiteQueryBuilder.buildQueryString (distinct, table, columns, selection, groupBy, having, orderBy, limit);
return this.rawQueryWithFactory (cursorFactory, sql, selectionArgs, android.database.sqlite.SQLiteDatabase.findEditTable (table));
}, "android.database.sqlite.SQLiteDatabase.CursorFactory,~B,~S,~A,~S,~A,~S,~S,~S,~S");
Clazz.defineMethod (c$, "query", 
function (table, columns, selection, selectionArgs, groupBy, having, orderBy) {
return this.query (false, table, columns, selection, selectionArgs, groupBy, having, orderBy, null);
}, "~S,~A,~S,~A,~S,~S,~S");
Clazz.defineMethod (c$, "query", 
function (table, columns, selection, selectionArgs, groupBy, having, orderBy, limit) {
return this.query (false, table, columns, selection, selectionArgs, groupBy, having, orderBy, limit);
}, "~S,~A,~S,~A,~S,~S,~S,~S");
Clazz.defineMethod (c$, "rawQuery", 
function (sql, selectionArgs) {
return this.rawQueryWithFactory (null, sql, selectionArgs, null);
}, "~S,~A");
Clazz.defineMethod (c$, "rawQueryWithFactory", 
function (cursorFactory, sql, selectionArgs, editTable) {
var driver =  new android.database.sqlite.SQLiteDirectCursorDriver (this, sql, editTable);
var cursor = null;
try {
cursor = driver.query (cursorFactory != null ? cursorFactory : this.mFactory, selectionArgs);
} finally {
}
return cursor;
}, "android.database.sqlite.SQLiteDatabase.CursorFactory,~S,~A,~S");
Clazz.defineMethod (c$, "rawQuery", 
function (sql, selectionArgs, initialRead, maxRead) {
var c = this.rawQueryWithFactory (null, sql, selectionArgs, null);
return c;
}, "~S,~A,~N,~N");
Clazz.defineMethod (c$, "insert", 
function (table, nullColumnHack, values) {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return 1;
try {
var temp = 0;
temp = this.insertWithOnConflict (table, nullColumnHack, values, this.CONFLICT_NONE);
return temp;
} catch (e) {
if (Clazz.instanceOf (e, android.database.SQLException)) {
android.util.Log.e ("Database", "Error inserting " + values, e);
return -1;
} else {
throw e;
}
}
}, "~S,~S,android.content.ContentValues");
Clazz.defineMethod (c$, "insertOrThrow", 
function (table, nullColumnHack, values) {
return this.insertWithOnConflict (table, nullColumnHack, values, 0);
}, "~S,~S,android.content.ContentValues");
Clazz.defineMethod (c$, "replace", 
function (table, nullColumnHack, initialValues) {
try {
return this.insertWithOnConflict (table, nullColumnHack, initialValues, 5);
} catch (e) {
if (Clazz.instanceOf (e, android.database.SQLException)) {
android.util.Log.e ("Database", "Error inserting " + initialValues, e);
return -1;
} else {
throw e;
}
}
}, "~S,~S,android.content.ContentValues");
Clazz.defineMethod (c$, "replaceOrThrow", 
function (table, nullColumnHack, initialValues) {
return this.insertWithOnConflict (table, nullColumnHack, initialValues, 5);
}, "~S,~S,android.content.ContentValues");
Clazz.defineMethod (c$, "insertWithOnConflict", 
function (table, nullColumnHack, initialValues, conflictAlgorithm) {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return 1;
var sql =  new StringBuilder (152);
sql.append ("INSERT");
sql.append (android.database.sqlite.SQLiteDatabase.CONFLICT_VALUES[conflictAlgorithm]);
sql.append (" INTO ");
sql.append (table);
var values =  new StringBuilder (40);
var entrySet = null;
if (initialValues != null && initialValues.size () > 0) {
entrySet = initialValues.valueSet ();
var entriesIter = entrySet.iterator ();
sql.append ('(');
var needSeparator = false;
while (entriesIter.hasNext ()) {
if (needSeparator) {
sql.append (", ");
values.append (", ");
}needSeparator = true;
var entry = entriesIter.next ();
sql.append ("'" + entry.getKey () + "'");
values.append ("'" + entry.getValue () + "'");
}
sql.append (')');
} else {
sql.append ("(" + nullColumnHack + ") ");
values.append ("NULL");
}sql.append (" VALUES(");
sql.append (values);
sql.append (");");
var insertId = 0;
var notifier;
webdatabase.transaction(
function(tx){
tx.executeSql(sql,[],function(tx, data){
notifier=data.insertId;
}, function(tx,e) {notifier = -1;
throw(e.message);  } );
});
while (notifier === undefined) {
yield();
}
insertId = parseInt(notifier);
alert(insertId);
android.util.Log.v ("insertedId", "" + insertId);
return insertId;
}, "~S,~S,android.content.ContentValues,~N");
Clazz.defineMethod (c$, "$delete", 
function (table, whereClause, whereArgs) {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return 1;
var sql = "DELETE FROM " + table + " WHERE " + whereClause;
var result = 0;
if (whereArgs != null) {
var notifier;
webdatabase.transaction(function(tx){
tx.executeSql(sql,whereArgs,function(tx, data){
alert("delete rows numbers:"+data.rowsAffected);
notifier=data.rowsAffected;
}, function(tx,e) {notifier = -1; throw(e.message);  }  );
});
while (notifier === undefined) {
yield();
}
result = parseInt(notifier);
} else {
var notifier;
webdatabase.transaction(function(tx){
tx.executeSql(sql,[],function(tx, data){
notifier=data.rowsAffected;
}, function(tx,e) {notifier = -1; throw(e.message);  } );
});
while (notifier === undefined) {
yield();
}
result = parseInt(notifier);
}return result;
}, "~S,~S,~A");
Clazz.defineMethod (c$, "update", 
function (table, values, whereClause, whereArgs) {
return this.updateWithOnConflict (table, values, whereClause, whereArgs, 0);
}, "~S,android.content.ContentValues,~S,~A");
Clazz.defineMethod (c$, "updateWithOnConflict", 
function (table, values, whereClause, whereArgs, conflictAlgorithm) {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return 0;
if (values == null || values.size () == 0) {
throw  new IllegalArgumentException ("Empty values");
}var result = 0;
var sql =  new StringBuilder (120);
sql.append ("UPDATE ");
sql.append (android.database.sqlite.SQLiteDatabase.CONFLICT_VALUES[conflictAlgorithm]);
sql.append (table);
sql.append (" SET ");
var entrySet = values.valueSet ();
var entriesIter = entrySet.iterator ();
while (entriesIter.hasNext ()) {
var entry = entriesIter.next ();
sql.append (entry.getKey ());
sql.append ("='" + entry.getValue () + "'");
if (entriesIter.hasNext ()) {
sql.append (", ");
}}
if (String(whereClause).length > 0);
{
sql.append (" WHERE ");
sql.append (whereClause);
}
if (whereArgs != null) {
var notifier;
webdatabase.transaction(function(tx){
tx.executeSql(sql,whereArgs,function(tx, data){
alert("update rows numbers:"+data.rowsAffected);
notifier=data.rowsAffected;
}, function(tx, e) {notifier = -1; throw(e.message);  });
});
while (notifier === undefined) {
yield();
}
result = parseInt(notifier);
} else {
var notifier;
webdatabase.transaction(function(tx){
tx.executeSql(sql,null,function(tx, data){
notifier=data.rowsAffected;
}, function(tx, e) {notifier = -1; throw(e.message);  });
alert("Sql:" + sql);
});
while (notifier === undefined) {
yield();
}
result = parseInt(notifier);
}return result;
}, "~S,android.content.ContentValues,~S,~A,~N");
Clazz.defineMethod (c$, "execSQL", 
function (sql) {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return ;
webdatabase.transaction(function(tx){
tx.executeSql(sql,null,null,function(tx, e) {throw(e.message);});},
function(e) {throw(e.message); }
);
}, "~S");
Clazz.defineMethod (c$, "execSQL", 
function (sql, bindArgs) {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return ;
if (bindArgs == null) {
throw  new IllegalArgumentException ("Empty bindArgs");
}webdatabase.transaction(function(tx){
tx.executeSql(sql,bindArgs,null,function(tx,e){throw(e.message);} );
}, function(e) {throw(e.message); });
}, "~S,~A");
Clazz.overrideMethod (c$, "finalize", 
function () {
if (this.isOpen ()) {
android.util.Log.e ("Database", "close() was never explicitly called on database '" + this.mPath + "' ", this.mStackTrace);
this.onAllReferencesReleased ();
}});
Clazz.makeConstructor (c$, 
($fz = function (path, factory, flags) {
Clazz.superConstructor (this, android.database.sqlite.SQLiteDatabase, []);
if (path == null) {
throw  new IllegalArgumentException ("path should not be null");
}this.mFlags = flags;
this.mPath = path;
this.mFactory = factory;
var name = null;
var temp = path;
var names = temp.split("/");
name = names[3]+"_"+names[5];
if (name == null) throw  new IllegalArgumentException ("Name should not be null");
($t$ = android.database.sqlite.SQLiteDatabase.mName = name, android.database.sqlite.SQLiteDatabase.prototype.mName = android.database.sqlite.SQLiteDatabase.mName, $t$);
if(!window.openDatabase) {
alert("Your browser do not support web database, sorry~~~~");}
else {
webdatabase = window.openDatabase(name, "", name, 1*1024*1024);}
if (!webdatabase.version)
{
var temp, notifier;;
webdatabase.changeVersion("", "0", function() {} , function() {
notifier = false; }, function() {
notifier = true;});
while ( notifier === undefined) {
yield();
}
temp = notifier;
}
}, $fz.isPrivate = true, $fz), "~S,android.database.sqlite.SQLiteDatabase.CursorFactory,~N");
Clazz.defineMethod (c$, "isReadOnly", 
function () {
return (this.mFlags & 1) == 1;
});
Clazz.defineMethod (c$, "isOpen", 
function () {
return this.mNativeHandle != 0;
});
Clazz.defineMethod (c$, "needUpgrade", 
function (newVersion) {
return newVersion > this.getVersion ();
}, "~N");
Clazz.defineMethod (c$, "getPath", 
function () {
return this.mPath;
});
Clazz.defineMethod (c$, "getMaxSqlCacheSize", 
function () {
return this.mMaxSqlCacheSize;
});
Clazz.overrideMethod (c$, "onAllReferencesReleased", 
function () {
});
Clazz.defineMethod (c$, "onUpgrade", 
function (version, mNewVersion) {
if (android.database.sqlite.SQLiteDatabase.DEBUG_NODB) return ;
var temp, notifier;
webdatabase.changeVersion(version, mNewversion, function() {} , function() {
alert("Error when changing the Database version!");
notifier = false; }, function() {
notifier = true;
alert("success to change the Database version!");	});
while ( notifier === undefined) {
yield();
}
temp = notifier;
}, "~N,~N");
Clazz.defineMethod (c$, "GetWebDataBase", 
function () {
var db = null;
db = webdatabase;
return db;
});
Clazz.defineMethod (c$, "compileStatement", 
function (sql) {
console.log("Missing method: compileStatement");
}, "~S");
Clazz.defineMethod (c$, "yieldIfContendedSafely", 
function () {
console.log("Missing method: yieldIfContendedSafely");
});
Clazz.defineMethod (c$, "endTransaction", 
function () {
console.log("Missing method: endTransaction");
});
Clazz.defineMethod (c$, "getSyncedTables", 
function () {
console.log("Missing method: getSyncedTables");
});
Clazz.defineMethod (c$, "inTransaction", 
function () {
console.log("Missing method: inTransaction");
});
Clazz.defineMethod (c$, "setLocale", 
function (locale) {
console.log("Missing method: setLocale");
}, "java.util.Locale");
c$.releaseMemory = Clazz.defineMethod (c$, "releaseMemory", 
function () {
console.log("Missing method: releaseMemory");
});
Clazz.defineMethod (c$, "isDbLockedByCurrentThread", 
function () {
console.log("Missing method: isDbLockedByCurrentThread");
});
Clazz.defineMethod (c$, "yieldIfContended", 
function () {
console.log("Missing method: yieldIfContended");
});
Clazz.defineMethod (c$, "setTransactionSuccessful", 
function () {
console.log("Missing method: setTransactionSuccessful");
});
c$.create = Clazz.defineMethod (c$, "create", 
function (factory) {
console.log("Missing method: create");
}, "android.database.sqlite.SQLiteDatabase.CursorFactory");
Clazz.defineMethod (c$, "isDbLockedByOtherThreads", 
function () {
console.log("Missing method: isDbLockedByOtherThreads");
});
Clazz.defineMethod (c$, "setLockingEnabled", 
function (lockingEnabled) {
console.log("Missing method: setLockingEnabled");
}, "~B");
Clazz.defineMethod (c$, "beginTransaction", 
function () {
console.log("Missing method: beginTransaction");
});
Clazz.defineMethod (c$, "yieldIfContendedSafely", 
function (sleepAfterYieldDelay) {
console.log("Missing method: yieldIfContendedSafely");
}, "~N");
Clazz.declareInterface (android.database.sqlite.SQLiteDatabase, "CursorFactory");
Clazz.defineStatics (c$,
"TAG", "Database",
"DEBUG_NODB", false,
"EVENT_DB_OPERATION", 52000,
"EVENT_DB_CORRUPT", 75004);
Clazz.defineStatics (c$,
"mName", null,
"CONFLICT_ROLLBACK", 1,
"CONFLICT_ABORT", 2,
"CONFLICT_FAIL", 3,
"CONFLICT_IGNORE", 4,
"CONFLICT_REPLACE", 5,
"CONFLICT_NONE", 0);
c$.CONFLICT_VALUES = c$.prototype.CONFLICT_VALUES = ["", " OR ROLLBACK ", " OR ABORT ", " OR FAIL ", " OR IGNORE ", " OR REPLACE "];
Clazz.defineStatics (c$,
"SQLITE_MAX_LIKE_PATTERN_LENGTH", 50000,
"OPEN_READWRITE", 0x00000000,
"OPEN_READONLY", 0x00000001,
"OPEN_READ_MASK", 0x00000001,
"NO_LOCALIZED_COLLATORS", 0x00000010,
"CREATE_IF_NECESSARY", 0x10000000,
"LOCK_WARNING_WINDOW_IN_MS", 20000,
"LOCK_ACQUIRED_WARNING_TIME_IN_MS", 300,
"LOCK_ACQUIRED_WARNING_THREAD_TIME_IN_MS", 100,
"LOCK_ACQUIRED_WARNING_TIME_IN_MS_ALWAYS_PRINT", 2000,
"SLEEP_AFTER_YIELD_QUANTUM", 1000);
c$.EMAIL_IN_DB_PATTERN = c$.prototype.EMAIL_IN_DB_PATTERN = java.util.regex.Pattern.compile ("[\\w\\.\\-]+@[\\w\\.\\-]+");
Clazz.defineStatics (c$,
"sQueryLogTimeInMillis", 0,
"QUERY_LOG_SQL_LENGTH", 64,
"COMMIT_SQL", "COMMIT;",
"GET_LOCK_LOG_PREFIX", "GETLOCK:",
"MAX_SQL_CACHE_SIZE", 250,
"MAX_WARNINGS_ON_CACHESIZE_CONDITION", 1,
"LOG_SLOW_QUERIES_PROPERTY", "db.log.slow_query_threshold");
});
