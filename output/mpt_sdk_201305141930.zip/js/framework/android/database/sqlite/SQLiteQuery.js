﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (["android.database.sqlite.SQLiteProgram"], "android.database.sqlite.SQLiteQuery", ["android.os.SystemClock", "java.lang.Double", "$.IllegalStateException", "$.Long", "$.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mOffsetIndex = 0;
this.mBindArgs = null;
this.mClosed = false;
Clazz.instantialize (this, arguments);
}, android.database.sqlite, "SQLiteQuery", android.database.sqlite.SQLiteProgram);
Clazz.makeConstructor (c$, 
function (db, query, offsetIndex, bindArgs) {
Clazz.superConstructor (this, android.database.sqlite.SQLiteQuery, [db, query]);
this.mOffsetIndex = offsetIndex;
this.mBindArgs = bindArgs;
}, "android.database.sqlite.SQLiteDatabase,~S,~N,~A");
Clazz.defineMethod (c$, "fillWindow", 
function (window, maxRead, lastPos) {
var timeStart = android.os.SystemClock.uptimeMillis ();
try {
this.acquireReference ();
try {
window.acquireReference ();
var numRows = 0;
numRows = window.Length;
return numRows;
} catch (e$$) {
if (Clazz.instanceOf (e$$, IllegalStateException)) {
var e = e$$;
{
return 0;
}
} else if (Clazz.instanceOf (e$$, android.database.sqlite.SQLiteDatabaseCorruptException)) {
var e = e$$;
{
throw e;
}
} else {
throw e$$;
}
} finally {
numRows = window.Length;
}
} finally {
numRows = window.Length;
}
}, "android.database.CursorWindow,~N,~N");
Clazz.defineMethod (c$, "columnCountLocked", 
function () {
this.acquireReference ();
try {
return this.native_column_count ();
} finally {
this.releaseReference ();
}
});
Clazz.defineMethod (c$, "columnNameLocked", 
function (columnIndex) {
this.acquireReference ();
try {
return this.native_column_name (columnIndex);
} finally {
this.releaseReference ();
}
}, "~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return "SQLiteQuery: " + this.mSql;
});
Clazz.defineMethod (c$, "close", 
function () {
Clazz.superCall (this, android.database.sqlite.SQLiteQuery, "close", []);
this.mClosed = true;
});
Clazz.defineMethod (c$, "requery", 
function () {
if (this.mBindArgs != null) {
var len = this.mBindArgs.length;
try {
for (var i = 0; i < len; i++) {
Clazz.superCall (this, android.database.sqlite.SQLiteQuery, "bindString", [i + 1, this.mBindArgs[i]]);
}
} catch (e) {
if (Clazz.instanceOf (e, android.database.sqlite.SQLiteMisuseException)) {
var errMsg =  new StringBuilder ("mSql " + this.mSql);
for (var i = 0; i < len; i++) {
errMsg.append (" ");
errMsg.append (this.mBindArgs[i]);
}
errMsg.append (" ");
var leakProgram =  new IllegalStateException (errMsg.toString (), e);
throw leakProgram;
} else {
throw e;
}
}
}});
Clazz.defineMethod (c$, "bindNull", 
function (index) {
this.mBindArgs[index - 1] = null;
if (!this.mClosed) Clazz.superCall (this, android.database.sqlite.SQLiteQuery, "bindNull", [index]);
}, "~N");
Clazz.defineMethod (c$, "bindLong", 
function (index, value) {
this.mBindArgs[index - 1] = Long.toString (value);
if (!this.mClosed) Clazz.superCall (this, android.database.sqlite.SQLiteQuery, "bindLong", [index, value]);
}, "~N,~N");
Clazz.defineMethod (c$, "bindDouble", 
function (index, value) {
this.mBindArgs[index - 1] = Double.toString (value);
if (!this.mClosed) Clazz.superCall (this, android.database.sqlite.SQLiteQuery, "bindDouble", [index, value]);
}, "~N,~N");
Clazz.defineMethod (c$, "bindString", 
function (index, value) {
this.mBindArgs[index - 1] = value;
if (!this.mClosed) Clazz.superCall (this, android.database.sqlite.SQLiteQuery, "bindString", [index, value]);
}, "~N,~S");
Clazz.defineMethod (c$, "getBindArgs", 
function () {
return this.mBindArgs;
});
Clazz.defineMethod (c$, "getmSql", 
function () {
return this.mSql;
});
Clazz.defineStatics (c$,
"$TAG", "Cursor");
});
