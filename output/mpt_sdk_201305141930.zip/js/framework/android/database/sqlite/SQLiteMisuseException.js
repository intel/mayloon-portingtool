﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (["android.database.sqlite.SQLiteException"], "android.database.sqlite.SQLiteMisuseException", null, function () {
c$ = Clazz.declareType (android.database.sqlite, "SQLiteMisuseException", android.database.sqlite.SQLiteException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.database.sqlite.SQLiteMisuseException, []);
});
});
