﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (["android.database.SQLException"], "android.database.sqlite.SQLiteException", null, function () {
c$ = Clazz.declareType (android.database.sqlite, "SQLiteException", android.database.SQLException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.database.sqlite.SQLiteException, []);
});
});
