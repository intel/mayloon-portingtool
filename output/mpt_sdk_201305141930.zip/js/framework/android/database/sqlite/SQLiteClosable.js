﻿Clazz.declarePackage ("android.database.sqlite");
c$ = Clazz.decorateAsClass (function () {
this.mReferenceCount = 1;
this.mLock = null;
Clazz.instantialize (this, arguments);
}, android.database.sqlite, "SQLiteClosable");
Clazz.prepareFields (c$, function () {
this.mLock =  new JavaObject ();
});
Clazz.defineMethod (c$, "onAllReferencesReleasedFromContainer", 
function () {
});
Clazz.defineMethod (c$, "acquireReference", 
function () {
{
if (this.mReferenceCount <= 0) {
}this.mReferenceCount++;
}});
Clazz.defineMethod (c$, "releaseReference", 
function () {
{
this.mReferenceCount--;
if (this.mReferenceCount == 0) {
this.onAllReferencesReleased ();
}}});
Clazz.defineMethod (c$, "releaseReferenceFromContainer", 
function () {
{
this.mReferenceCount--;
if (this.mReferenceCount == 0) {
this.onAllReferencesReleasedFromContainer ();
}}});
