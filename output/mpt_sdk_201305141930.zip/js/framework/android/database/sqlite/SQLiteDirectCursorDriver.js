﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (["android.database.sqlite.SQLiteCursorDriver"], "android.database.sqlite.SQLiteDirectCursorDriver", ["android.database.sqlite.SQLiteCursor", "$.SQLiteQuery"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mEditTable = null;
this.mDatabase = null;
this.mCursor = null;
this.mSql = null;
this.mQuery = null;
Clazz.instantialize (this, arguments);
}, android.database.sqlite, "SQLiteDirectCursorDriver", null, android.database.sqlite.SQLiteCursorDriver);
Clazz.makeConstructor (c$, 
function (db, sql, editTable) {
this.mDatabase = db;
this.mEditTable = editTable;
this.mSql = sql;
}, "android.database.sqlite.SQLiteDatabase,~S,~S");
Clazz.overrideMethod (c$, "query", 
function (factory, selectionArgs) {
var query =  new android.database.sqlite.SQLiteQuery (this.mDatabase, this.mSql, 0, selectionArgs);
try {
if (factory == null) {
this.mCursor =  new android.database.sqlite.SQLiteCursor (this.mDatabase, this, this.mEditTable, query);
} else {
this.mCursor = factory.newCursor (this.mDatabase, this, this.mEditTable, query);
}this.mQuery = query;
query = null;
return this.mCursor;
} finally {
}
}, "android.database.sqlite.SQLiteDatabase.CursorFactory,~A");
Clazz.overrideMethod (c$, "cursorClosed", 
function () {
this.mCursor = null;
});
Clazz.overrideMethod (c$, "setBindArguments", 
function (bindArgs) {
var numArgs = bindArgs.length;
for (var i = 0; i < numArgs; i++) {
this.mQuery.bindString (i + 1, bindArgs[i]);
}
}, "~A");
Clazz.overrideMethod (c$, "cursorDeactivated", 
function () {
});
Clazz.overrideMethod (c$, "cursorRequeried", 
function (cursor) {
}, "android.database.Cursor");
Clazz.overrideMethod (c$, "toString", 
function () {
return "SQLiteDirectCursorDriver: " + this.mSql;
});
});
