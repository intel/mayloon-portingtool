﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (["android.database.AbstractWindowedCursor", "android.os.Handler"], "android.database.sqlite.SQLiteCursor", ["android.database.CursorWindow", "android.database.sqlite.DatabaseObjectNotClosedException", "android.text.TextUtils", "android.util.Log", "java.lang.Exception", "$.IllegalStateException", "$.StringBuilder", "$.Thread", "java.util.HashMap", "java.util.concurrent.locks.ReentrantLock"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mEditTable = null;
this.mColumns = null;
this.mQuery = null;
this.mDatabase = null;
this.mDriver = null;
this.mCount = -1;
this.mColumnNameMap = null;
this.mStackTrace = null;
this.mMaxRead = 2147483647;
this.mInitialRead = 2147483647;
this.mCursorState = 0;
this.mLock = null;
this.mPendingData = false;
if (!Clazz.isClassDefined ("android.database.sqlite.SQLiteCursor.QueryThread")) {
android.database.sqlite.SQLiteCursor.$SQLiteCursor$QueryThread$ ();
}
if (!Clazz.isClassDefined ("android.database.sqlite.SQLiteCursor.MainThreadNotificationHandler")) {
android.database.sqlite.SQLiteCursor.$SQLiteCursor$MainThreadNotificationHandler$ ();
}
this.mNotificationHandler = null;
Clazz.instantialize (this, arguments);
}, android.database.sqlite, "SQLiteCursor", android.database.AbstractWindowedCursor);
Clazz.defineMethod (c$, "setLoadStyle", 
function (initialRead, maxRead) {
this.mMaxRead = maxRead;
this.mInitialRead = initialRead;
this.mLock =  new java.util.concurrent.locks.ReentrantLock (true);
}, "~N,~N");
Clazz.defineMethod (c$, "queryThreadLock", 
($fz = function () {
if (this.mLock != null) {
this.mLock.lock ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "queryThreadUnlock", 
($fz = function () {
if (this.mLock != null) {
this.mLock.unlock ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "registerDataSetObserver", 
function (observer) {
Clazz.superCall (this, android.database.sqlite.SQLiteCursor, "registerDataSetObserver", [observer]);
if ((2147483647 != this.mMaxRead || 2147483647 != this.mInitialRead) && this.mNotificationHandler == null) {
this.queryThreadLock ();
try {
this.mNotificationHandler = Clazz.innerTypeInstance (android.database.sqlite.SQLiteCursor.MainThreadNotificationHandler, this, null);
if (this.mPendingData) {
this.notifyDataSetChange ();
this.mPendingData = false;
}} finally {
this.queryThreadUnlock ();
}
}}, "android.database.DataSetObserver");
Clazz.makeConstructor (c$, 
function (db, driver, editTable, query) {
Clazz.superConstructor (this, android.database.sqlite.SQLiteCursor);
this.mStackTrace =  new android.database.sqlite.DatabaseObjectNotClosedException ().fillInStackTrace ();
this.mDatabase = db;
this.mDriver = driver;
this.mEditTable = editTable;
this.mColumnNameMap = null;
this.mQuery = query;
var temp_window =  new android.database.CursorWindow (true);
var tableName = null;
var sql = this.mQuery.getmSql ();
var BindArgs = this.mQuery.getBindArgs ();
var notifier;
var notifier2;
var columns_query;
var WebDB = this.mDatabase.GetWebDataBase();
WebDB.transaction(function(tx){
tx.executeSql(sql,BindArgs,function(tx, data){
var keys;
if(!data.rows||data.rows.length==0){
var DISTINCT_index = sql.indexOf("DISTINCT");
var FROM_index = sql.indexOf("FROM");
if(DISTINCT_index >= 0)
{
var temp_columns = sql.substring(DISTINCT_index+8,FROM_index-1);
var sql_left = sql.slice(FROM_index+5);
if(sql_left.indexOf(" ")>=0)
{
var sql_left_parts = sql_left.split(" ");
tableName = sql_left_parts[0];
}
else
tableName = sql_left;
}
else
{
var temp_columns = sql.substring(7,FROM_index-1);
var sql_left = sql.slice(FROM_index+5);
if(sql_left.indexOf(" ")>=0)
{
var sql_left_parts = sql_left.split(" ");
tableName = sql_left_parts[0];
}
else
tableName = sql_left;
}
if(temp_columns.indexOf("*")<0)
columns_query = temp_columns.split(", ");
else
columns_query = "*";
this.mColumns = columns_query;
temp_window.column = columns_query;
notifier = this.mColumns;
}
else{
keys = Object.keys(data.rows.item(0));
this.mColumns = keys;
temp_window.QueryResult = data.rows;
temp_window.column = keys;
temp_window.Length = data.rows.length;
notifier = this.mColumns;
}}, function(tx,e){
throw(e.message);
notifier = null;});
}, function(e){
throw(e.message);
notifier = null;});
while (notifier === undefined)
{
yield();
}
this.mColumns = notifier;
if((columns_query == "*")&&(tableName!=null))
{
WebDB.transaction(function(tx){
tx.executeSql("SELECT sql FROM sqlite_master WHERE tbl_name = '"+tableName+"'",null,function(tx, data){
var sql_create = data.rows.item(0).sql;
var position1 = sql_create.indexOf("(");
var position2 = sql_create.lastIndexOf(")");
var sql_key = sql_create.substring(position1+1,position2);
var arr = new Array();
var column = new Array();
var flag = 0;
var count = 0;
var pre = 0;
var length = sql_key.length;
var i = 0;
for(i=0;i<length;i++)
{
if(flag==0&&sql_key.charAt(i)==",")
{
arr[count] = sql_key.substring(pre,i);
pre = i + 1;
count++;
}
if(sql_key.charAt(i)=="(")
flag++;
if(sql_key.charAt(i)==")")
flag--;
}
arr[count] = sql_key.slice(pre);
i = 0;
var length_column = 0;
while(i<=count)
{
while(arr[i].charAt(0) == " ")
arr[i] = arr[i].slice(1);
var temp_sql = arr[i].split(" ");
if(temp_sql[0]!="PRIMARY KEY"&&temp_sql[0]!="UNIQUE"&&temp_sql[0]!="CHECK"&&temp_sql[0]!="DEFAUL"&&temp_sql[0]!="COLLATE")
{
column[length_column] = temp_sql[0];
length_column++;
}
i++;
}
this.mColumns = column;
temp_window.column = column;
notifier2 = this.mColumns;   //Notice! There might be a Bug  ****  mColumns and notifier2 get the real values
})});
while (notifier2 === undefined)
{
yield();
}                               //Notice! Run to here,  ****  mColumns become null
this.mColumns = notifier2;
}
this.setWindow (temp_window);
}, "android.database.sqlite.SQLiteDatabase,android.database.sqlite.SQLiteCursorDriver,~S,android.database.sqlite.SQLiteQuery");
Clazz.defineMethod (c$, "getDatabase", 
function () {
return this.mDatabase;
});
Clazz.overrideMethod (c$, "onMove", 
function (oldPosition, newPosition) {
if (this.mWindow == null || newPosition < this.mWindow.getStartPosition () || newPosition >= (this.mWindow.getStartPosition () + this.mWindow.getNumRows ())) {
this.fillWindow (newPosition);
}return true;
}, "~N,~N");
Clazz.overrideMethod (c$, "getCount", 
function () {
if (this.mCount == -1) {
this.fillWindow (0);
}return this.mCount;
});
Clazz.defineMethod (c$, "fillWindow", 
($fz = function (startPos) {
if (this.mWindow == null) {
this.mWindow =  new android.database.CursorWindow (true);
} else {
this.mCursorState++;
this.queryThreadLock ();
try {
this.mWindow.clear ();
} finally {
this.queryThreadUnlock ();
}
}this.mWindow.setStartPosition (startPos);
this.mCount = this.mQuery.fillWindow (this.mWindow, this.mInitialRead, 0);
if (this.mCount == -1) {
this.mCount = startPos + this.mInitialRead;
var t =  new Thread (Clazz.innerTypeInstance (android.database.sqlite.SQLiteCursor.QueryThread, this, null, this.mCursorState), "query thread");
t.start ();
}}, $fz.isPrivate = true, $fz), "~N");
Clazz.overrideMethod (c$, "getColumnIndex", 
function (columnName) {
if (this.mColumnNameMap == null) {
var columns = this.mColumns;
var columnCount = columns.length;
var map =  new java.util.HashMap (columnCount, 1);
for (var i = 0; i < columnCount; i++) {
map.put (columns[i], new Integer (i));
}
this.mColumnNameMap = map;
}var periodIndex = columnName.lastIndexOf ('.');
if (periodIndex != -1) {
var e =  new Exception ();
android.util.Log.e ("Cursor", "requesting column name with table name -- " + columnName, e);
columnName = columnName.substring (periodIndex + 1);
}var i = this.mColumnNameMap.get (columnName);
if (i != null) {
return i.intValue ();
} else {
return -1;
}}, "~S");
Clazz.overrideMethod (c$, "deleteRow", 
function () {
this.checkPosition ();
if (this.mRowIdColumnIndex == -1 || this.mCurrentRowID == null) {
android.util.Log.e ("Cursor", "Could not delete row because either the row ID column is not available or ithas not been read.");
return false;
}var success;
try {
try {
this.mDatabase.$delete (this.mEditTable, this.mColumns[this.mRowIdColumnIndex] + "=?", [this.mCurrentRowID.toString ()]);
success = true;
} catch (e) {
if (Clazz.instanceOf (e, android.database.SQLException)) {
success = false;
} else {
throw e;
}
}
var pos = this.mPos;
this.requery ();
this.moveToPosition (pos);
} finally {
}
if (success) {
this.onChange (true);
return true;
} else {
return false;
}});
Clazz.overrideMethod (c$, "getColumnNames", 
function () {
return this.mColumns;
});
Clazz.defineMethod (c$, "supportsUpdates", 
function () {
return Clazz.superCall (this, android.database.sqlite.SQLiteCursor, "supportsUpdates", []) && !android.text.TextUtils.isEmpty (this.mEditTable);
});
Clazz.defineMethod (c$, "commitUpdates", 
function (additionalValues) {
if (!this.supportsUpdates ()) {
android.util.Log.e ("Cursor", "commitUpdates not supported on this cursor, did you include the _id column?");
return false;
}{
if (additionalValues != null) {
this.mUpdatedRows.putAll (additionalValues);
}if (this.mUpdatedRows.size () == 0) {
return true;
}try {
var sql =  new StringBuilder (128);
for (var rowEntry, $rowEntry = this.mUpdatedRows.entrySet ().iterator (); $rowEntry.hasNext () && ((rowEntry = $rowEntry.next ()) || true);) {
var values = rowEntry.getValue ();
var rowIdObj = rowEntry.getKey ();
if (rowIdObj == null || values == null) {
throw  new IllegalStateException ("null rowId or values found! rowId = " + rowIdObj + ", values = " + values);
}if (values.size () == 0) {
continue ;}var rowId = rowIdObj.longValue ();
var valuesIter = values.entrySet ().iterator ();
sql.setLength (0);
sql.append ("UPDATE " + this.mEditTable + " SET ");
var bindings =  new Array (values.size ());
var i = 0;
while (valuesIter.hasNext ()) {
var entry = valuesIter.next ();
sql.append (entry.getKey ());
sql.append ("=?");
bindings[i] = entry.getValue ();
if (valuesIter.hasNext ()) {
sql.append (", ");
}i++;
}
sql.append (" WHERE " + this.mColumns[this.mRowIdColumnIndex] + '=' + rowId);
sql.append (';');
this.mDatabase.execSQL (sql.toString (), bindings);
}
} finally {
}
this.mUpdatedRows.clear ();
}this.onChange (true);
return true;
}, "java.util.Map");
Clazz.defineMethod (c$, "deactivateCommon", 
($fz = function () {
if (false) android.util.Log.v ("Cursor", "<<< Releasing cursor " + this);
this.mCursorState = 0;
if (this.mWindow != null) {
this.mWindow.close ();
this.mWindow = null;
}if (false) android.util.Log.v ("DatabaseWindow", "closing window in release()");
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "deactivate", 
function () {
Clazz.superCall (this, android.database.sqlite.SQLiteCursor, "deactivate", []);
this.deactivateCommon ();
this.mDriver.cursorDeactivated ();
});
Clazz.defineMethod (c$, "close", 
function () {
Clazz.superCall (this, android.database.sqlite.SQLiteCursor, "close", []);
this.deactivateCommon ();
this.mQuery.close ();
this.mDriver.cursorClosed ();
});
Clazz.defineMethod (c$, "requery", 
function () {
if (this.isClosed ()) {
return false;
}var timeStart = 0;
if (false) {
timeStart = System.currentTimeMillis ();
}try {
if (this.mWindow != null) {
this.mWindow.clear ();
}this.mPos = -1;
this.mDriver.cursorRequeried (this);
this.mCount = -1;
this.mCursorState++;
this.queryThreadLock ();
try {
this.mQuery.requery ();
} finally {
this.queryThreadUnlock ();
}
} finally {
}
if (false) {
android.util.Log.v ("DatabaseWindow", "closing window in requery()");
android.util.Log.v ("Cursor", "--- Requery()ed cursor " + this + ": " + this.mQuery);
}var result = Clazz.superCall (this, android.database.sqlite.SQLiteCursor, "requery", []);
if (false) {
var timeEnd = System.currentTimeMillis ();
android.util.Log.v ("Cursor", "requery (" + (timeEnd - timeStart) + " ms): " + this.mDriver.toString ());
}return result;
});
Clazz.overrideMethod (c$, "setWindow", 
function (window) {
if (this.mWindow != null) {
this.mCursorState++;
this.queryThreadLock ();
try {
this.mWindow.close ();
} finally {
this.queryThreadUnlock ();
}
this.mCount = -1;
}this.mWindow = window;
}, "android.database.CursorWindow");
Clazz.defineMethod (c$, "setSelectionArguments", 
function (selectionArgs) {
this.mDriver.setBindArguments (selectionArgs);
}, "~A");
Clazz.overrideMethod (c$, "finalize", 
function () {
});
c$.$SQLiteCursor$QueryThread$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mThreadState = 0;
Clazz.instantialize (this, arguments);
}, android.database.sqlite.SQLiteCursor, "QueryThread", null, Runnable);
Clazz.makeConstructor (c$, 
function (a) {
this.mThreadState = a;
}, "~N");
Clazz.defineMethod (c$, "sendMessage", 
($fz = function () {
if (this.b$["android.database.sqlite.SQLiteCursor"].mNotificationHandler != null) {
this.b$["android.database.sqlite.SQLiteCursor"].mNotificationHandler.sendEmptyMessage (1);
this.b$["android.database.sqlite.SQLiteCursor"].mPendingData = false;
} else {
this.b$["android.database.sqlite.SQLiteCursor"].mPendingData = true;
}}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "run", 
function () {
var a = this.b$["android.database.sqlite.SQLiteCursor"].mWindow;
while (true) {
this.b$["android.database.sqlite.SQLiteCursor"].mLock.lock ();
try {
if (this.b$["android.database.sqlite.SQLiteCursor"].mCursorState != this.mThreadState) {
break;
}var b = this.b$["android.database.sqlite.SQLiteCursor"].mQuery.fillWindow (a, this.b$["android.database.sqlite.SQLiteCursor"].mMaxRead, this.b$["android.database.sqlite.SQLiteCursor"].mCount);
if (b != 0) {
if (b == -1) {
this.b$["android.database.sqlite.SQLiteCursor"].mCount += this.b$["android.database.sqlite.SQLiteCursor"].mMaxRead;
this.sendMessage ();
} else {
this.b$["android.database.sqlite.SQLiteCursor"].mCount = b;
this.sendMessage ();
break;
}} else {
break;
}} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
break;
} else {
throw e;
}
} finally {
this.b$["android.database.sqlite.SQLiteCursor"].mLock.unlock ();
}
}
});
c$ = Clazz.p0p ();
};
c$.$SQLiteCursor$MainThreadNotificationHandler$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.database.sqlite.SQLiteCursor, "MainThreadNotificationHandler", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
this.b$["android.database.sqlite.SQLiteCursor"].notifyDataSetChange ();
}, "android.os.Message");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"$TAG", "Cursor",
"NO_COUNT", -1);
});
