﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (["java.lang.RuntimeException"], "android.database.sqlite.DatabaseObjectNotClosedException", null, function () {
c$ = Clazz.declareType (android.database.sqlite, "DatabaseObjectNotClosedException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.database.sqlite.DatabaseObjectNotClosedException, ["Application did not close the cursor or database object that was opened here"]);
});
Clazz.defineStatics (c$,
"s", "Application did not close the cursor or database object that was opened here");
});
