﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (["java.util.regex.Pattern"], "android.database.sqlite.SQLiteQueryBuilder", ["android.database.DatabaseUtils", "android.database.sqlite.SQLiteDatabase", "android.text.TextUtils", "java.lang.IllegalArgumentException", "$.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mProjectionMap = null;
this.mTables = "";
this.mWhereClause = null;
this.mDistinct = false;
this.mFactory = null;
this.mStrictProjectionMap = false;
Clazz.instantialize (this, arguments);
}, android.database.sqlite, "SQLiteQueryBuilder");
Clazz.makeConstructor (c$, 
function () {
this.mDistinct = false;
this.mFactory = null;
});
Clazz.defineMethod (c$, "setDistinct", 
function (distinct) {
this.mDistinct = distinct;
}, "~B");
Clazz.defineMethod (c$, "getTables", 
function () {
return this.mTables;
});
Clazz.defineMethod (c$, "setTables", 
function (inTables) {
this.mTables = inTables;
}, "~S");
Clazz.defineMethod (c$, "appendWhere", 
function (inWhere) {
if (this.mWhereClause == null) {
this.mWhereClause =  new StringBuilder (android.text.TextUtils.getLength (inWhere) + 16);
}if (android.text.TextUtils.getLength (this.mWhereClause) == 0) {
this.mWhereClause.append ('(');
}this.mWhereClause.append (inWhere);
}, "CharSequence");
Clazz.defineMethod (c$, "appendWhereEscapeString", 
function (inWhere) {
if (this.mWhereClause == null) {
this.mWhereClause =  new StringBuilder (inWhere.length + 16);
}if (this.mWhereClause.length () == 0) {
this.mWhereClause.append ('(');
}android.database.DatabaseUtils.appendEscapedSQLString (this.mWhereClause, inWhere);
}, "~S");
Clazz.defineMethod (c$, "setProjectionMap", 
function (columnMap) {
this.mProjectionMap = columnMap;
}, "java.util.Map");
Clazz.defineMethod (c$, "setCursorFactory", 
function (factory) {
this.mFactory = factory;
}, "android.database.sqlite.SQLiteDatabase.CursorFactory");
Clazz.defineMethod (c$, "setStrictProjectionMap", 
function (flag) {
this.mStrictProjectionMap = flag;
}, "~B");
c$.buildQueryString = Clazz.defineMethod (c$, "buildQueryString", 
function (distinct, tables, columns, where, groupBy, having, orderBy, limit) {
if (android.text.TextUtils.isEmpty (groupBy) && !android.text.TextUtils.isEmpty (having)) {
throw  new IllegalArgumentException ("HAVING clauses are only permitted when using a groupBy clause");
}var query =  new StringBuilder (120);
query.append ("SELECT ");
if (distinct) {
query.append ("DISTINCT ");
}if (columns != null && columns.length != 0) {
android.database.sqlite.SQLiteQueryBuilder.appendColumns (query, columns);
} else {
query.append ("* ");
}query.append ("FROM ");
query.append (tables);
android.database.sqlite.SQLiteQueryBuilder.appendClause (query, " WHERE ", where);
android.database.sqlite.SQLiteQueryBuilder.appendClause (query, " GROUP BY ", groupBy);
android.database.sqlite.SQLiteQueryBuilder.appendClause (query, " HAVING ", having);
android.database.sqlite.SQLiteQueryBuilder.appendClause (query, " ORDER BY ", orderBy);
android.database.sqlite.SQLiteQueryBuilder.appendClause (query, " LIMIT ", limit);
return query.toString ();
}, "~B,~S,~A,~S,~S,~S,~S,~S");
c$.appendClause = Clazz.defineMethod (c$, "appendClause", 
($fz = function (s, name, clause) {
if (!android.text.TextUtils.isEmpty (clause)) {
s.append (name);
s.append (clause);
}}, $fz.isPrivate = true, $fz), "StringBuilder,~S,~S");
c$.appendColumns = Clazz.defineMethod (c$, "appendColumns", 
function (s, columns) {
var n = columns.length;
for (var i = 0; i < n; i++) {
var column = columns[i];
if (column != null) {
if (i > 0) {
s.append (", ");
}s.append (column);
}}
s.append (' ');
}, "StringBuilder,~A");
Clazz.defineMethod (c$, "query", 
function (db, projectionIn, selection, selectionArgs, groupBy, having, sortOrder) {
return this.query (db, projectionIn, selection, selectionArgs, groupBy, having, sortOrder, null);
}, "android.database.sqlite.SQLiteDatabase,~A,~S,~A,~S,~S,~S");
Clazz.defineMethod (c$, "query", 
function (db, projectionIn, selection, selectionArgs, groupBy, having, sortOrder, limit) {
if (this.mTables == null) {
return null;
}var sql = this.buildQuery (projectionIn, selection, groupBy, having, sortOrder, limit);
return db.rawQueryWithFactory (this.mFactory, sql, selectionArgs, android.database.sqlite.SQLiteDatabase.findEditTable (this.mTables));
}, "android.database.sqlite.SQLiteDatabase,~A,~S,~A,~S,~S,~S,~S");
Clazz.defineMethod (c$, "buildQuery", 
function (projectionIn, selection, groupBy, having, sortOrder, limit) {
var projection = this.computeProjection (projectionIn);
var where =  new StringBuilder ();
var hasBaseWhereClause = this.mWhereClause != null && this.mWhereClause.length () > 0;
if (hasBaseWhereClause) {
where.append (this.mWhereClause.toString ());
where.append (')');
}if (selection != null && selection.length > 0) {
if (hasBaseWhereClause) {
where.append (" AND ");
}where.append ('(');
where.append (selection);
where.append (')');
}return android.database.sqlite.SQLiteQueryBuilder.buildQueryString (this.mDistinct, this.mTables, projection, where.toString (), groupBy, having, sortOrder, limit);
}, "~A,~S,~S,~S,~S,~S");
Clazz.defineMethod (c$, "buildQuery", 
function (projectionIn, selection, selectionArgs, groupBy, having, sortOrder, limit) {
return this.buildQuery (projectionIn, selection, groupBy, having, sortOrder, limit);
}, "~A,~S,~A,~S,~S,~S,~S");
Clazz.defineMethod (c$, "buildUnionSubQuery", 
function (typeDiscriminatorColumn, unionColumns, columnsPresentInTable, computedColumnsOffset, typeDiscriminatorValue, selection, groupBy, having) {
var unionColumnsCount = unionColumns.length;
var projectionIn =  new Array (unionColumnsCount);
for (var i = 0; i < unionColumnsCount; i++) {
var unionColumn = unionColumns[i];
if (unionColumn.equals (typeDiscriminatorColumn)) {
projectionIn[i] = "'" + typeDiscriminatorValue + "' AS " + typeDiscriminatorColumn;
} else if (i <= computedColumnsOffset || columnsPresentInTable.contains (unionColumn)) {
projectionIn[i] = unionColumn;
} else {
projectionIn[i] = "NULL AS " + unionColumn;
}}
return this.buildQuery (projectionIn, selection, groupBy, having, null, null);
}, "~S,~A,java.util.Set,~N,~S,~S,~S,~S");
Clazz.defineMethod (c$, "buildUnionSubQuery", 
function (typeDiscriminatorColumn, unionColumns, columnsPresentInTable, computedColumnsOffset, typeDiscriminatorValue, selection, selectionArgs, groupBy, having) {
return this.buildUnionSubQuery (typeDiscriminatorColumn, unionColumns, columnsPresentInTable, computedColumnsOffset, typeDiscriminatorValue, selection, groupBy, having);
}, "~S,~A,java.util.Set,~N,~S,~S,~A,~S,~S");
Clazz.defineMethod (c$, "buildUnionQuery", 
function (subQueries, sortOrder, limit) {
var query =  new StringBuilder (128);
var subQueryCount = subQueries.length;
var unionOperator = this.mDistinct ? " UNION " : " UNION ALL ";
for (var i = 0; i < subQueryCount; i++) {
if (i > 0) {
query.append (unionOperator);
}query.append (subQueries[i]);
}
android.database.sqlite.SQLiteQueryBuilder.appendClause (query, " ORDER BY ", sortOrder);
android.database.sqlite.SQLiteQueryBuilder.appendClause (query, " LIMIT ", limit);
return query.toString ();
}, "~A,~S,~S");
Clazz.defineMethod (c$, "computeProjection", 
($fz = function (projectionIn) {
if (projectionIn != null && projectionIn.length > 0) {
if (this.mProjectionMap != null) {
var projection =  new Array (projectionIn.length);
var length = projectionIn.length;
for (var i = 0; i < length; i++) {
var userColumn = projectionIn[i];
var column = this.mProjectionMap.get (userColumn);
if (column != null) {
projection[i] = column;
continue ;}if (!this.mStrictProjectionMap && (userColumn.contains (" AS ") || userColumn.contains (" as "))) {
projection[i] = userColumn;
continue ;}throw  new IllegalArgumentException ("Invalid column " + projectionIn[i]);
}
return projection;
} else {
return projectionIn;
}} else if (this.mProjectionMap != null) {
var entrySet = this.mProjectionMap.entrySet ();
var projection =  new Array (entrySet.size ());
var entryIter = entrySet.iterator ();
var i = 0;
while (entryIter.hasNext ()) {
var entry = entryIter.next ();
projection[i++] = entry.getValue ();
}
return projection;
}return null;
}, $fz.isPrivate = true, $fz), "~A");
Clazz.defineStatics (c$,
"TAG", "SQLiteQueryBuilder");
c$.sLimitPattern = c$.prototype.sLimitPattern = java.util.regex.Pattern.compile ("\\s*\\d+\\s*(,\\s*\\d+\\s*)?");
});
