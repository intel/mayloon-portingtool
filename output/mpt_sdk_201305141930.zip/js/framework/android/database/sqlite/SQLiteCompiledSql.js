﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (null, "android.database.sqlite.SQLiteCompiledSql", ["android.database.sqlite.DatabaseObjectNotClosedException", "java.lang.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDatabase = null;
this.nHandle = 0;
this.nStatement = 0;
this.mSqlStmt = null;
this.mStackTrace = null;
this.mInUse = false;
Clazz.instantialize (this, arguments);
}, android.database.sqlite, "SQLiteCompiledSql");
Clazz.makeConstructor (c$, 
function (db, sql) {
if (!db.isOpen ()) {
throw  new IllegalStateException ("database " + db.getPath () + " already closed");
}this.mDatabase = db;
this.mSqlStmt = sql;
this.mStackTrace =  new android.database.sqlite.DatabaseObjectNotClosedException ().fillInStackTrace ();
this.nHandle = db.mNativeHandle;
this.compile (sql, true);
}, "android.database.sqlite.SQLiteDatabase,~S");
Clazz.defineMethod (c$, "compile", 
($fz = function (sql, forceCompilation) {
if (!this.mDatabase.isOpen ()) {
throw  new IllegalStateException ("database " + this.mDatabase.getPath () + " already closed");
}if (forceCompilation) {
try {
} finally {
}
}}, $fz.isPrivate = true, $fz), "~S,~B");
Clazz.defineMethod (c$, "releaseSqlStatement", 
function () {
if (this.nStatement != 0) {
try {
} finally {
}
}});
Clazz.defineMethod (c$, "acquire", 
function () {
if (this.mInUse) {
return false;
}this.mInUse = true;
return true;
});
Clazz.defineMethod (c$, "release", 
function () {
this.mInUse = false;
});
Clazz.defineMethod (c$, "finalize", 
function () {
try {
if (this.nStatement == 0) return ;
this.releaseSqlStatement ();
} finally {
Clazz.superCall (this, android.database.sqlite.SQLiteCompiledSql, "finalize", []);
}
});
Clazz.defineStatics (c$,
"TAG", "SQLiteCompiledSql");
});
