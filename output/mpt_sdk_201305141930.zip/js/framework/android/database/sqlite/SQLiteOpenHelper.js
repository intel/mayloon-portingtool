﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (null, "android.database.sqlite.SQLiteOpenHelper", ["android.database.sqlite.SQLiteDatabase", "$.SQLiteException", "android.util.Log", "java.lang.IllegalArgumentException", "$.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mContext = null;
this.mName = null;
this.mFactory = null;
this.mNewVersion = 0;
this.mPath = null;
this.mDatabase = null;
this.mIsInitializing = false;
Clazz.instantialize (this, arguments);
}, android.database.sqlite, "SQLiteOpenHelper");
Clazz.makeConstructor (c$, 
function (context, name, factory, version) {
if (version < 1) throw  new IllegalArgumentException ("Version must be >= 1, was " + version);
this.mContext = context;
this.mName = name;
this.mFactory = factory;
this.mNewVersion = version;
this.mPath = "/data/data/" + context.getPackageName () + "/data/" + name;
}, "android.content.Context,~S,android.database.sqlite.SQLiteDatabase.CursorFactory,~N");
Clazz.defineMethod (c$, "onCreate", 
function (db) {
}, "android.database.sqlite.SQLiteDatabase");
Clazz.defineMethod (c$, "onUpgrade", 
function (db, oldVersion, newVersion) {
}, "android.database.sqlite.SQLiteDatabase,~N,~N");
Clazz.defineMethod (c$, "getWritableDatabase", 
function () {
if (this.mDatabase != null && this.mDatabase.isOpen () && !this.mDatabase.isReadOnly ()) {
return this.mDatabase;
}if (this.mIsInitializing) {
throw  new IllegalStateException ("getWritableDatabase called recursively");
}var success = false;
var db = null;
try {
this.mIsInitializing = true;
if (this.mName == null) {
throw  new IllegalArgumentException ("Database's name can not be null!");
} else {
db = this.mContext.openOrCreateDatabase (this.mName, 0, this.mFactory);
}var version = db.getVersion ();
System.out.println ("old:" + version + ",new:" + this.mNewVersion);
if (version != this.mNewVersion) {
try {
if (version == 0) {
this.onCreate (db);
} else {
this.onUpgrade (db, version, this.mNewVersion);
}db.setVersion (this.mNewVersion);
} finally {
}
}this.onOpen (db);
success = true;
return db;
} finally {
this.mIsInitializing = false;
if (success) {
if (this.mDatabase != null) {
try {
this.mDatabase.close ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
}this.mDatabase = db;
} else {
if (db != null) db.close ();
}}
});
Clazz.defineMethod (c$, "getReadableDatabase", 
function () {
if (this.mDatabase != null && this.mDatabase.isOpen ()) {
return this.mDatabase;
}if (this.mIsInitializing) {
throw  new IllegalStateException ("getReadableDatabase called recursively");
}try {
return this.getWritableDatabase ();
} catch (e) {
if (Clazz.instanceOf (e, android.database.sqlite.SQLiteException)) {
if (this.mName == null) throw e;
android.util.Log.e ("sqliteopenhelper", "Couldn't open " + this.mName + " for writing (will try read-only):", e);
} else {
throw e;
}
}
var db = null;
try {
this.mIsInitializing = true;
db = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase (this.mPath, this.mFactory);
if (db.getVersion () != this.mNewVersion) {
throw  new android.database.sqlite.SQLiteException ("Can't upgrade read-only database from version " + db.getVersion () + " to " + this.mNewVersion);
}this.onOpen (db);
android.util.Log.w ("sqliteopenhelper", "Opened " + this.mName + " in read-only mode");
this.mDatabase = db;
return this.mDatabase;
} finally {
this.mIsInitializing = false;
if (db != null && db !== this.mDatabase) db.close ();
}
});
Clazz.defineMethod (c$, "close", 
function () {
if (this.mIsInitializing) throw  new IllegalStateException ("Closed during initialization");
if (this.mDatabase != null && this.mDatabase.isOpen ()) {
this.mDatabase.close ();
this.mDatabase = null;
}});
Clazz.defineMethod (c$, "onOpen", 
function (db) {
}, "android.database.sqlite.SQLiteDatabase");
Clazz.defineStatics (c$,
"TAG", "sqliteopenhelper");
});
