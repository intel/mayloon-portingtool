﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.load (["android.database.sqlite.SQLiteClosable"], "android.database.sqlite.SQLiteProgram", ["java.lang.IllegalArgumentException", "$.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDatabase = null;
this.mSql = null;
this.nHandle = 0;
this.mCompiledSql = null;
this.nStatement = 0;
Clazz.instantialize (this, arguments);
}, android.database.sqlite, "SQLiteProgram", android.database.sqlite.SQLiteClosable);
Clazz.makeConstructor (c$, 
function (db, sql) {
Clazz.superConstructor (this, android.database.sqlite.SQLiteProgram, []);
this.mDatabase = db;
this.mSql = sql.trim ();
this.nHandle = db.mNativeHandle;
var prefixSql = this.mSql.substring (0, 6);
if (!prefixSql.equalsIgnoreCase ("INSERT") && !prefixSql.equalsIgnoreCase ("UPDATE") && !prefixSql.equalsIgnoreCase ("REPLAC") && !prefixSql.equalsIgnoreCase ("DELETE") && !prefixSql.equalsIgnoreCase ("SELECT")) {
return ;
}if (this.mCompiledSql == null) {
} else {
}}, "android.database.sqlite.SQLiteDatabase,~S");
Clazz.overrideMethod (c$, "onAllReferencesReleased", 
function () {
});
Clazz.overrideMethod (c$, "onAllReferencesReleasedFromContainer", 
function () {
this.releaseCompiledSqlIfNotInCache ();
this.mDatabase.releaseReference ();
});
Clazz.defineMethod (c$, "releaseCompiledSqlIfNotInCache", 
($fz = function () {
if (this.mCompiledSql == null) {
return ;
}{
if (!this.mDatabase.mCompiledQueries.containsValue (this.mCompiledSql)) {
this.mCompiledSql.releaseSqlStatement ();
this.mCompiledSql = null;
this.nStatement = 0;
} else {
this.mCompiledSql.release ();
}}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getUniqueId", 
function () {
return this.nStatement;
});
Clazz.defineMethod (c$, "getSqlString", 
function () {
return this.mSql;
});
Clazz.defineMethod (c$, "compile", 
function (sql, forceCompilation) {
}, "~S,~B");
Clazz.defineMethod (c$, "bindNull", 
function (index) {
if (!this.mDatabase.isOpen ()) {
throw  new IllegalStateException ("database " + this.mDatabase.getPath () + " already closed");
}this.acquireReference ();
try {
this.native_bind_null (index);
} finally {
this.releaseReference ();
}
}, "~N");
Clazz.defineMethod (c$, "bindLong", 
function (index, value) {
if (!this.mDatabase.isOpen ()) {
throw  new IllegalStateException ("database " + this.mDatabase.getPath () + " already closed");
}this.acquireReference ();
try {
this.native_bind_long (index, value);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "bindDouble", 
function (index, value) {
if (!this.mDatabase.isOpen ()) {
throw  new IllegalStateException ("database " + this.mDatabase.getPath () + " already closed");
}this.acquireReference ();
try {
this.native_bind_double (index, value);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "bindString", 
function (index, value) {
if (value == null) {
throw  new IllegalArgumentException ("the bind value at index " + index + " is null");
}if (!this.mDatabase.isOpen ()) {
throw  new IllegalStateException ("database " + this.mDatabase.getPath () + " already closed");
}this.acquireReference ();
try {
} finally {
}
}, "~N,~S");
Clazz.defineMethod (c$, "bindBlob", 
function (index, value) {
if (value == null) {
throw  new IllegalArgumentException ("the bind value at index " + index + " is null");
}if (!this.mDatabase.isOpen ()) {
throw  new IllegalStateException ("database " + this.mDatabase.getPath () + " already closed");
}this.acquireReference ();
try {
this.native_bind_blob (index, value);
} finally {
this.releaseReference ();
}
}, "~N,~A");
Clazz.defineMethod (c$, "clearBindings", 
function () {
if (!this.mDatabase.isOpen ()) {
throw  new IllegalStateException ("database " + this.mDatabase.getPath () + " already closed");
}this.acquireReference ();
try {
this.native_clear_bindings ();
} finally {
this.releaseReference ();
}
});
Clazz.defineMethod (c$, "close", 
function () {
if (!this.mDatabase.isOpen ()) {
return ;
}try {
this.releaseReference ();
} finally {
}
});
Clazz.defineStatics (c$,
"TAG", "SQLiteProgram");
});
