﻿Clazz.declarePackage ("android.database.sqlite");
Clazz.declareInterface (android.database.sqlite, "SQLiteCursorDriver");
