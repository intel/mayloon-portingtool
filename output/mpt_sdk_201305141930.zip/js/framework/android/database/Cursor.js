﻿Clazz.declarePackage ("android.database");
Clazz.declareInterface (android.database, "Cursor");
