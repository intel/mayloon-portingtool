﻿Clazz.declarePackage ("android.database");
Clazz.load (["java.lang.RuntimeException"], "android.database.SQLException", null, function () {
c$ = Clazz.declareType (android.database, "SQLException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.database.SQLException, []);
});
});
