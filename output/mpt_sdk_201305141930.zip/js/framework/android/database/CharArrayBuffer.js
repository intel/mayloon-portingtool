﻿Clazz.declarePackage ("android.database");
c$ = Clazz.decorateAsClass (function () {
this.data = null;
this.sizeCopied = 0;
Clazz.instantialize (this, arguments);
}, android.database, "CharArrayBuffer");
Clazz.makeConstructor (c$, 
function (size) {
this.data =  Clazz.newArray (size, '\0');
}, "~N");
Clazz.makeConstructor (c$, 
function (buf) {
this.data = buf;
}, "~A");
