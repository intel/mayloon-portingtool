﻿Clazz.declarePackage ("android.database");
Clazz.load (["android.database.AbstractCursor"], "android.database.MatrixCursor", ["android.database.CursorIndexOutOfBoundsException", "java.lang.Double", "$.Float", "$.IllegalArgumentException", "$.Long", "$.Short"], function () {
c$ = Clazz.decorateAsClass (function () {
this.columnNames = null;
this.data = null;
this.rowCount = 0;
this.columnCount = 0;
if (!Clazz.isClassDefined ("android.database.MatrixCursor.RowBuilder")) {
android.database.MatrixCursor.$MatrixCursor$RowBuilder$ ();
}
Clazz.instantialize (this, arguments);
}, android.database, "MatrixCursor", android.database.AbstractCursor);
Clazz.makeConstructor (c$, 
function (columnNames, initialCapacity) {
Clazz.superConstructor (this, android.database.MatrixCursor, []);
this.columnNames = columnNames;
this.columnCount = columnNames.length;
if (initialCapacity < 1) {
initialCapacity = 1;
}this.data =  new Array (this.columnCount * initialCapacity);
}, "~A,~N");
Clazz.makeConstructor (c$, 
function (columnNames) {
this.construct (columnNames, 16);
}, "~A");
Clazz.defineMethod (c$, "get", 
($fz = function (column) {
if (column < 0 || column >= this.columnCount) {
throw  new android.database.CursorIndexOutOfBoundsException ("Requested column: " + column + ", # of columns: " + this.columnCount);
}if (this.mPos < 0) {
throw  new android.database.CursorIndexOutOfBoundsException ("Before first row.");
}if (this.mPos >= this.rowCount) {
throw  new android.database.CursorIndexOutOfBoundsException ("After last row.");
}return this.data[this.mPos * this.columnCount + column];
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "newRow", 
function () {
this.rowCount++;
var endIndex = this.rowCount * this.columnCount;
this.ensureCapacity (endIndex);
var start = endIndex - this.columnCount;
return Clazz.innerTypeInstance (android.database.MatrixCursor.RowBuilder, this, null, start, endIndex);
});
Clazz.defineMethod (c$, "addRow", 
function (columnValues) {
if (columnValues.length != this.columnCount) {
throw  new IllegalArgumentException ("columnNames.length = " + this.columnCount + ", columnValues.length = " + columnValues.length);
}var start = this.rowCount++ * this.columnCount;
this.ensureCapacity (start + this.columnCount);
System.arraycopy (columnValues, 0, this.data, start, this.columnCount);
}, "~A");
Clazz.defineMethod (c$, "addRow", 
function (columnValues) {
var start = this.rowCount * this.columnCount;
var end = start + this.columnCount;
this.ensureCapacity (end);
if (Clazz.instanceOf (columnValues, java.util.ArrayList)) {
this.addRow (columnValues, start);
return ;
}var current = start;
var localData = this.data;
for (var columnValue, $columnValue = columnValues.iterator (); $columnValue.hasNext () && ((columnValue = $columnValue.next ()) || true);) {
if (current == end) {
throw  new IllegalArgumentException ("columnValues.size() > columnNames.length");
}localData[current++] = columnValue;
}
if (current != end) {
throw  new IllegalArgumentException ("columnValues.size() < columnNames.length");
}this.rowCount++;
}, "Iterable");
Clazz.defineMethod (c$, "addRow", 
($fz = function (columnValues, start) {
var size = columnValues.size ();
if (size != this.columnCount) {
throw  new IllegalArgumentException ("columnNames.length = " + this.columnCount + ", columnValues.size() = " + size);
}this.rowCount++;
var localData = this.data;
for (var i = 0; i < size; i++) {
localData[start + i] = columnValues.get (i);
}
}, $fz.isPrivate = true, $fz), "java.util.ArrayList,~N");
Clazz.defineMethod (c$, "ensureCapacity", 
($fz = function (size) {
if (size > this.data.length) {
var oldData = this.data;
var newSize = this.data.length * 2;
if (newSize < size) {
newSize = size;
}this.data =  new Array (newSize);
System.arraycopy (oldData, 0, this.data, 0, oldData.length);
}}, $fz.isPrivate = true, $fz), "~N");
Clazz.overrideMethod (c$, "getCount", 
function () {
return this.rowCount;
});
Clazz.overrideMethod (c$, "getColumnNames", 
function () {
return this.columnNames;
});
Clazz.overrideMethod (c$, "getString", 
function (column) {
var value = this.get (column);
if (value == null) return null;
return value.toString ();
}, "~N");
Clazz.overrideMethod (c$, "getShort", 
function (column) {
var value = this.get (column);
if (value == null) return 0;
if (Clazz.instanceOf (value, Number)) return (value).shortValue ();
return Short.parseShort (value.toString ());
}, "~N");
Clazz.overrideMethod (c$, "getInt", 
function (column) {
var value = this.get (column);
if (value == null) return 0;
if (Clazz.instanceOf (value, Number)) return (value).intValue ();
return Integer.parseInt (value.toString ());
}, "~N");
Clazz.overrideMethod (c$, "getLong", 
function (column) {
var value = this.get (column);
if (value == null) return 0;
if (Clazz.instanceOf (value, Number)) return (value).longValue ();
return Long.parseLong (value.toString ());
}, "~N");
Clazz.overrideMethod (c$, "getFloat", 
function (column) {
var value = this.get (column);
if (value == null) return 0.0;
if (Clazz.instanceOf (value, Number)) return (value).floatValue ();
return Float.parseFloat (value.toString ());
}, "~N");
Clazz.overrideMethod (c$, "getDouble", 
function (column) {
var value = this.get (column);
if (value == null) return 0.0;
if (Clazz.instanceOf (value, Number)) return (value).doubleValue ();
return Double.parseDouble (value.toString ());
}, "~N");
Clazz.overrideMethod (c$, "isNull", 
function (column) {
return this.get (column) == null;
}, "~N");
c$.$MatrixCursor$RowBuilder$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.index = 0;
this.endIndex = 0;
Clazz.instantialize (this, arguments);
}, android.database.MatrixCursor, "RowBuilder");
Clazz.makeConstructor (c$, 
function (a, b) {
this.index = a;
this.endIndex = b;
}, "~N,~N");
Clazz.defineMethod (c$, "add", 
function (a) {
if (this.index == this.endIndex) {
throw  new android.database.CursorIndexOutOfBoundsException ("No more columns left.");
}this.b$["android.database.MatrixCursor"].data[this.index++] = a;
return this;
}, "~O");
c$ = Clazz.p0p ();
};
});
