﻿Clazz.declarePackage ("android.database");
Clazz.load (["android.database.Cursor"], "android.database.CursorWrapper", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mCursor = null;
Clazz.instantialize (this, arguments);
}, android.database, "CursorWrapper", null, android.database.Cursor);
Clazz.makeConstructor (c$, 
function (cursor) {
this.mCursor = cursor;
}, "android.database.Cursor");
Clazz.defineMethod (c$, "abortUpdates", 
function () {
this.mCursor.abortUpdates ();
});
Clazz.defineMethod (c$, "close", 
function () {
this.mCursor.close ();
});
Clazz.defineMethod (c$, "isClosed", 
function () {
return this.mCursor.isClosed ();
});
Clazz.defineMethod (c$, "commitUpdates", 
function () {
return this.mCursor.commitUpdates ();
});
Clazz.defineMethod (c$, "commitUpdates", 
function (values) {
return this.mCursor.commitUpdates (values);
}, "java.util.Map");
Clazz.defineMethod (c$, "getCount", 
function () {
return this.mCursor.getCount ();
});
Clazz.defineMethod (c$, "deactivate", 
function () {
this.mCursor.deactivate ();
});
Clazz.defineMethod (c$, "deleteRow", 
function () {
return this.mCursor.deleteRow ();
});
Clazz.defineMethod (c$, "moveToFirst", 
function () {
return this.mCursor.moveToFirst ();
});
Clazz.defineMethod (c$, "getColumnCount", 
function () {
return this.mCursor.getColumnCount ();
});
Clazz.defineMethod (c$, "getColumnIndex", 
function (columnName) {
return this.mCursor.getColumnIndex (columnName);
}, "~S");
Clazz.defineMethod (c$, "getColumnIndexOrThrow", 
function (columnName) {
return this.mCursor.getColumnIndexOrThrow (columnName);
}, "~S");
Clazz.defineMethod (c$, "getColumnName", 
function (columnIndex) {
return this.mCursor.getColumnName (columnIndex);
}, "~N");
Clazz.defineMethod (c$, "getColumnNames", 
function () {
return this.mCursor.getColumnNames ();
});
Clazz.defineMethod (c$, "getDouble", 
function (columnIndex) {
return this.mCursor.getDouble (columnIndex);
}, "~N");
Clazz.defineMethod (c$, "getExtras", 
function () {
return this.mCursor.getExtras ();
});
Clazz.defineMethod (c$, "getFloat", 
function (columnIndex) {
return this.mCursor.getFloat (columnIndex);
}, "~N");
Clazz.defineMethod (c$, "getInt", 
function (columnIndex) {
return this.mCursor.getInt (columnIndex);
}, "~N");
Clazz.defineMethod (c$, "getLong", 
function (columnIndex) {
return this.mCursor.getLong (columnIndex);
}, "~N");
Clazz.defineMethod (c$, "getShort", 
function (columnIndex) {
return this.mCursor.getShort (columnIndex);
}, "~N");
Clazz.defineMethod (c$, "getString", 
function (columnIndex) {
return this.mCursor.getString (columnIndex);
}, "~N");
Clazz.defineMethod (c$, "copyStringToBuffer", 
function (columnIndex, buffer) {
this.mCursor.copyStringToBuffer (columnIndex, buffer);
}, "~N,android.database.CharArrayBuffer");
Clazz.defineMethod (c$, "getBlob", 
function (columnIndex) {
return this.mCursor.getBlob (columnIndex);
}, "~N");
Clazz.defineMethod (c$, "getWantsAllOnMoveCalls", 
function () {
return this.mCursor.getWantsAllOnMoveCalls ();
});
Clazz.defineMethod (c$, "hasUpdates", 
function () {
return this.mCursor.hasUpdates ();
});
Clazz.defineMethod (c$, "isAfterLast", 
function () {
return this.mCursor.isAfterLast ();
});
Clazz.defineMethod (c$, "isBeforeFirst", 
function () {
return this.mCursor.isBeforeFirst ();
});
Clazz.defineMethod (c$, "isFirst", 
function () {
return this.mCursor.isFirst ();
});
Clazz.defineMethod (c$, "isLast", 
function () {
return this.mCursor.isLast ();
});
Clazz.defineMethod (c$, "isNull", 
function (columnIndex) {
return this.mCursor.isNull (columnIndex);
}, "~N");
Clazz.defineMethod (c$, "moveToLast", 
function () {
return this.mCursor.moveToLast ();
});
Clazz.defineMethod (c$, "move", 
function (offset) {
return this.mCursor.move (offset);
}, "~N");
Clazz.defineMethod (c$, "moveToPosition", 
function (position) {
return this.mCursor.moveToPosition (position);
}, "~N");
Clazz.defineMethod (c$, "moveToNext", 
function () {
return this.mCursor.moveToNext ();
});
Clazz.defineMethod (c$, "getPosition", 
function () {
return this.mCursor.getPosition ();
});
Clazz.defineMethod (c$, "moveToPrevious", 
function () {
return this.mCursor.moveToPrevious ();
});
Clazz.defineMethod (c$, "registerContentObserver", 
function (observer) {
this.mCursor.registerContentObserver (observer);
}, "android.database.ContentObserver");
Clazz.defineMethod (c$, "registerDataSetObserver", 
function (observer) {
this.mCursor.registerDataSetObserver (observer);
}, "android.database.DataSetObserver");
Clazz.defineMethod (c$, "requery", 
function () {
return this.mCursor.requery ();
});
Clazz.defineMethod (c$, "respond", 
function (extras) {
return this.mCursor.respond (extras);
}, "android.os.Bundle");
Clazz.defineMethod (c$, "setNotificationUri", 
function (cr, uri) {
this.mCursor.setNotificationUri (cr, uri);
}, "android.content.ContentResolver,android.net.Uri");
Clazz.defineMethod (c$, "supportsUpdates", 
function () {
return this.mCursor.supportsUpdates ();
});
Clazz.defineMethod (c$, "unregisterContentObserver", 
function (observer) {
this.mCursor.unregisterContentObserver (observer);
}, "android.database.ContentObserver");
Clazz.defineMethod (c$, "unregisterDataSetObserver", 
function (observer) {
this.mCursor.unregisterDataSetObserver (observer);
}, "android.database.DataSetObserver");
Clazz.defineMethod (c$, "updateDouble", 
function (columnIndex, value) {
return this.mCursor.updateDouble (columnIndex, value);
}, "~N,~N");
Clazz.defineMethod (c$, "updateFloat", 
function (columnIndex, value) {
return this.mCursor.updateFloat (columnIndex, value);
}, "~N,~N");
Clazz.defineMethod (c$, "updateInt", 
function (columnIndex, value) {
return this.mCursor.updateInt (columnIndex, value);
}, "~N,~N");
Clazz.defineMethod (c$, "updateLong", 
function (columnIndex, value) {
return this.mCursor.updateLong (columnIndex, value);
}, "~N,~N");
Clazz.defineMethod (c$, "updateShort", 
function (columnIndex, value) {
return this.mCursor.updateShort (columnIndex, value);
}, "~N,~N");
Clazz.defineMethod (c$, "updateString", 
function (columnIndex, value) {
return this.mCursor.updateString (columnIndex, value);
}, "~N,~S");
Clazz.defineMethod (c$, "updateBlob", 
function (columnIndex, value) {
return this.mCursor.updateBlob (columnIndex, value);
}, "~N,~A");
Clazz.defineMethod (c$, "updateToNull", 
function (columnIndex) {
return this.mCursor.updateToNull (columnIndex);
}, "~N");
});
