﻿Clazz.declarePackage ("android.database");
Clazz.load (["android.database.AbstractCursor"], "android.database.AbstractWindowedCursor", ["android.database.StaleDataException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mWindow = null;
Clazz.instantialize (this, arguments);
}, android.database, "AbstractWindowedCursor", android.database.AbstractCursor);
Clazz.overrideMethod (c$, "getBlob", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
return this.getUpdatedField (columnIndex);
}}return this.mWindow.getBlob (this.mPos, columnIndex);
}, "~N");
Clazz.overrideMethod (c$, "getString", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
return this.getUpdatedField (columnIndex);
}}return this.mWindow.getString (this.mPos, columnIndex);
}, "~N");
Clazz.defineMethod (c$, "copyStringToBuffer", 
function (columnIndex, buffer) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
Clazz.superCall (this, android.database.AbstractWindowedCursor, "copyStringToBuffer", [columnIndex, buffer]);
}}this.mWindow.copyStringToBuffer (this.mPos, columnIndex, buffer);
}, "~N,android.database.CharArrayBuffer");
Clazz.overrideMethod (c$, "getShort", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
var value = this.getUpdatedField (columnIndex);
return value.shortValue ();
}}return this.mWindow.getShort (this.mPos, columnIndex);
}, "~N");
Clazz.overrideMethod (c$, "getInt", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
var value = this.getUpdatedField (columnIndex);
return value.intValue ();
}}return this.mWindow.getInt (this.mPos, columnIndex);
}, "~N");
Clazz.overrideMethod (c$, "getLong", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
var value = this.getUpdatedField (columnIndex);
return value.longValue ();
}}return this.mWindow.getLong (this.mPos, columnIndex);
}, "~N");
Clazz.overrideMethod (c$, "getFloat", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
var value = this.getUpdatedField (columnIndex);
return value.floatValue ();
}}return this.mWindow.getFloat (this.mPos, columnIndex);
}, "~N");
Clazz.overrideMethod (c$, "getDouble", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
var value = this.getUpdatedField (columnIndex);
return value.doubleValue ();
}}return this.mWindow.getDouble (this.mPos, columnIndex);
}, "~N");
Clazz.overrideMethod (c$, "isNull", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
return this.getUpdatedField (columnIndex) == null;
}}return this.mWindow.isNull (this.mPos, columnIndex);
}, "~N");
Clazz.defineMethod (c$, "isBlob", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
var object = this.getUpdatedField (columnIndex);
return object == null || Clazz.instanceOf (object, Array);
}}return this.mWindow.isBlob (this.mPos, columnIndex);
}, "~N");
Clazz.defineMethod (c$, "isString", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
var object = this.getUpdatedField (columnIndex);
return object == null || Clazz.instanceOf (object, String);
}}return this.mWindow.isString (this.mPos, columnIndex);
}, "~N");
Clazz.defineMethod (c$, "isLong", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
var object = this.getUpdatedField (columnIndex);
return object != null && (Clazz.instanceOf (object, Integer) || Clazz.instanceOf (object, Long));
}}return this.mWindow.isLong (this.mPos, columnIndex);
}, "~N");
Clazz.defineMethod (c$, "isFloat", 
function (columnIndex) {
this.checkPosition ();
{
if (this.isFieldUpdated (columnIndex)) {
var object = this.getUpdatedField (columnIndex);
return object != null && (Clazz.instanceOf (object, Float) || Clazz.instanceOf (object, Double));
}}return this.mWindow.isFloat (this.mPos, columnIndex);
}, "~N");
Clazz.defineMethod (c$, "checkPosition", 
function () {
Clazz.superCall (this, android.database.AbstractWindowedCursor, "checkPosition", []);
if (this.mWindow == null) {
throw  new android.database.StaleDataException ("Access closed cursor");
}});
Clazz.overrideMethod (c$, "getWindow", 
function () {
return this.mWindow;
});
Clazz.defineMethod (c$, "setWindow", 
function (window) {
if (this.mWindow != null) {
this.mWindow.close ();
}this.mWindow = window;
}, "android.database.CursorWindow");
Clazz.defineMethod (c$, "hasWindow", 
function () {
return this.mWindow != null;
});
});
