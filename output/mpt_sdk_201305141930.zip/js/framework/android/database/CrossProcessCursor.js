﻿Clazz.declarePackage ("android.database");
Clazz.load (["android.database.Cursor"], "android.database.CrossProcessCursor", null, function () {
Clazz.declareInterface (android.database, "CrossProcessCursor", android.database.Cursor);
});
