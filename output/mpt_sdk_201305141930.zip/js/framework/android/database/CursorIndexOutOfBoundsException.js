﻿Clazz.declarePackage ("android.database");
Clazz.load (["java.lang.IndexOutOfBoundsException"], "android.database.CursorIndexOutOfBoundsException", null, function () {
c$ = Clazz.declareType (android.database, "CursorIndexOutOfBoundsException", IndexOutOfBoundsException);
Clazz.makeConstructor (c$, 
function (index, size) {
Clazz.superConstructor (this, android.database.CursorIndexOutOfBoundsException, ["Index " + index + " requested, with a size of " + size]);
}, "~N,~N");
});
