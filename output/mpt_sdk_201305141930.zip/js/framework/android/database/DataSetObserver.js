﻿Clazz.declarePackage ("android.database");
c$ = Clazz.declareType (android.database, "DataSetObserver");
Clazz.defineMethod (c$, "onChanged", 
function () {
});
Clazz.defineMethod (c$, "onInvalidated", 
function () {
});
