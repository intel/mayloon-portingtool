﻿Clazz.declarePackage ("android.database");
c$ = Clazz.decorateAsClass (function () {
this.mTransport = null;
this.lock = null;
this.mHandler = null;
if (!Clazz.isClassDefined ("android.database.ContentObserver.NotificationRunnable")) {
android.database.ContentObserver.$ContentObserver$NotificationRunnable$ ();
}
Clazz.instantialize (this, arguments);
}, android.database, "ContentObserver");
Clazz.prepareFields (c$, function () {
this.lock =  new JavaObject ();
});
Clazz.makeConstructor (c$, 
function (handler) {
this.mHandler = handler;
}, "android.os.Handler");
Clazz.defineMethod (c$, "getContentObserver", 
function () {
return this;
});
Clazz.defineMethod (c$, "releaseContentObserver", 
function () {
return this;
});
Clazz.defineMethod (c$, "deliverSelfNotifications", 
function () {
return false;
});
Clazz.defineMethod (c$, "onChange", 
function (selfChange) {
}, "~B");
Clazz.defineMethod (c$, "dispatchChange", 
function (selfChange) {
if (this.mHandler == null) {
this.onChange (selfChange);
} else {
this.mHandler.post (Clazz.innerTypeInstance (android.database.ContentObserver.NotificationRunnable, this, null, selfChange));
}}, "~B");
c$.$ContentObserver$NotificationRunnable$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mSelf = false;
Clazz.instantialize (this, arguments);
}, android.database.ContentObserver, "NotificationRunnable", null, Runnable);
Clazz.makeConstructor (c$, 
function (a) {
this.mSelf = a;
}, "~B");
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["android.database.ContentObserver"].onChange (this.mSelf);
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mContentObserver = null;
Clazz.instantialize (this, arguments);
}, android.database.ContentObserver, "Transport");
Clazz.makeConstructor (c$, 
function (a) {
this.mContentObserver = a;
}, "android.database.ContentObserver");
Clazz.defineMethod (c$, "deliverSelfNotifications", 
function () {
var a = this.mContentObserver;
if (a != null) {
return a.deliverSelfNotifications ();
}return false;
});
Clazz.defineMethod (c$, "onChange", 
function (a) {
var b = this.mContentObserver;
if (b != null) {
b.dispatchChange (a);
}}, "~B");
Clazz.defineMethod (c$, "releaseContentObserver", 
function () {
this.mContentObserver = null;
});
c$ = Clazz.p0p ();
