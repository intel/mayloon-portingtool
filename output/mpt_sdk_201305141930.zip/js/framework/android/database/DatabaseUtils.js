﻿Clazz.declarePackage ("android.database");
Clazz.load (null, "android.database.DatabaseUtils", ["android.text.TextUtils", "java.lang.StringBuilder"], function () {
c$ = Clazz.declareType (android.database, "DatabaseUtils");
c$.readExceptionFromParcel = Clazz.defineMethod (c$, "readExceptionFromParcel", 
function (reply) {
}, "android.os.Parcel");
c$.readExceptionWithFileNotFoundExceptionFromParcel = Clazz.defineMethod (c$, "readExceptionWithFileNotFoundExceptionFromParcel", 
function (reply) {
}, "android.os.Parcel");
c$.readExceptionWithOperationApplicationExceptionFromParcel = Clazz.defineMethod (c$, "readExceptionWithOperationApplicationExceptionFromParcel", 
function (reply) {
}, "android.os.Parcel");
c$.appendEscapedSQLString = Clazz.defineMethod (c$, "appendEscapedSQLString", 
function (sb, sqlString) {
sb.append ('\'');
if (sqlString.indexOf ('\'') != -1) {
var length = sqlString.length;
for (var i = 0; i < length; i++) {
var c = sqlString.charAt (i);
if ((c).charCodeAt (0) == ('\'').charCodeAt (0)) {
sb.append ('\'');
}sb.append (c);
}
} else sb.append (sqlString);
sb.append ('\'');
}, "StringBuilder,~S");
c$.sqlEscapeString = Clazz.defineMethod (c$, "sqlEscapeString", 
function (value) {
var escaper =  new StringBuilder ();
android.database.DatabaseUtils.appendEscapedSQLString (escaper, value);
return escaper.toString ();
}, "~S");
c$.appendValueToSql = Clazz.defineMethod (c$, "appendValueToSql", 
function (sql, value) {
if (value == null) {
sql.append ("NULL");
} else if (Clazz.instanceOf (value, Boolean)) {
var bool = value;
if ((bool).booleanValue ()) {
sql.append ('1');
} else {
sql.append ('0');
}} else {
android.database.DatabaseUtils.appendEscapedSQLString (sql, value.toString ());
}}, "StringBuilder,~O");
c$.concatenateWhere = Clazz.defineMethod (c$, "concatenateWhere", 
function (a, b) {
if (android.text.TextUtils.isEmpty (a)) {
return b;
}if (android.text.TextUtils.isEmpty (b)) {
return a;
}return "(" + a + ") AND (" + b + ")";
}, "~S,~S");
c$.dumpCurrentRowToString = Clazz.defineMethod (c$, "dumpCurrentRowToString", 
function (cursor) {
console.log("Missing method: dumpCurrentRowToString");
}, "android.database.Cursor");
c$.getCollationKey = Clazz.defineMethod (c$, "getCollationKey", 
function (name) {
console.log("Missing method: getCollationKey");
}, "~S");
c$.getHexCollationKey = Clazz.defineMethod (c$, "getHexCollationKey", 
function (name) {
console.log("Missing method: getHexCollationKey");
}, "~S");
Clazz.defineStatics (c$,
"TAG", "DatabaseUtils",
"DEBUG", false,
"LOCAL_LOGV", false ? true : false);
});
