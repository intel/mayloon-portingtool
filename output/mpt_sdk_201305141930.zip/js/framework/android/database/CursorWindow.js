﻿Clazz.declarePackage ("android.database");
Clazz.load (["android.database.sqlite.SQLiteClosable", "android.os.Parcelable", "android.os.Parcelable.Creator"], "android.database.CursorWindow", ["android.util.Base64", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.nWindow = 0;
this.mStartPos = 0;
this.Length = 0;
Clazz.instantialize (this, arguments);
}, android.database, "CursorWindow", android.database.sqlite.SQLiteClosable, android.os.Parcelable);
Clazz.prepareFields (c$, function () {
{
this.QueryResult = null;
this.column = null;
}});
Clazz.makeConstructor (c$, 
function (localWindow) {
Clazz.superConstructor (this, android.database.CursorWindow, []);
this.mStartPos = 0;
}, "~B");
Clazz.defineMethod (c$, "getStartPosition", 
function () {
return this.mStartPos;
});
Clazz.defineMethod (c$, "setStartPosition", 
function (pos) {
this.mStartPos = pos;
}, "~N");
Clazz.defineMethod (c$, "getNumRows", 
function () {
this.acquireReference ();
try {
return this.getNumRows_native ();
} finally {
this.releaseReference ();
}
});
Clazz.defineMethod (c$, "getNumRows_native", 
($fz = function () {
var NumRows = 0;
NumRows = this.Length;
return NumRows;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setNumColumns", 
function (columnNum) {
this.acquireReference ();
try {
return this.setNumColumns_native (columnNum);
} finally {
this.releaseReference ();
}
}, "~N");
Clazz.defineMethod (c$, "setNumColumns_native", 
($fz = function (columnNum) {
this.Length = columnNum;
return true;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "allocRow", 
function () {
this.acquireReference ();
try {
return this.allocRow_native ();
} finally {
this.releaseReference ();
}
});
Clazz.defineMethod (c$, "freeLastRow", 
function () {
this.acquireReference ();
try {
this.freeLastRow_native ();
} finally {
this.releaseReference ();
}
});
Clazz.defineMethod (c$, "putBlob", 
function (value, row, col) {
this.acquireReference ();
try {
return this.putBlob_native (value, row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~A,~N,~N");
Clazz.defineMethod (c$, "putBlob_native", 
($fz = function (value, row, col) {
var temp = android.util.Base64.encodeToString (value, 0);
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
this.QueryResult.item(row)[columnname] = temp;
}
else
throw new IllegalArgumentException("Failed to put into window.");
return true;
}}, $fz.isPrivate = true, $fz), "~A,~N,~N");
Clazz.defineMethod (c$, "putString", 
function (value, row, col) {
this.acquireReference ();
try {
return this.putString_native (value, row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~S,~N,~N");
Clazz.defineMethod (c$, "putString_native", 
($fz = function (value, row, col) {
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
this.QueryResult.item(row)[columnname] = value;
}
else
throw new IllegalArgumentException("Failed to put into window.");
return true;
}}, $fz.isPrivate = true, $fz), "~S,~N,~N");
Clazz.defineMethod (c$, "putLong", 
function (value, row, col) {
this.acquireReference ();
try {
return this.putLong_native (value, row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N,~N");
Clazz.defineMethod (c$, "putLong_native", 
($fz = function (value, row, col) {
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
this.QueryResult.item(row)[columnname] = value;
}
else
throw new IllegalArgumentException("Failed to put into window.");
return true;
}}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "putDouble", 
function (value, row, col) {
this.acquireReference ();
try {
return this.putDouble_native (value, row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N,~N");
Clazz.defineMethod (c$, "putDouble_native", 
($fz = function (value, row, col) {
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
this.QueryResult.item(row)[columnname] = value;
}
else
throw new IllegalArgumentException("Failed to put into window.");
return true;
}}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "putNull", 
function (row, col) {
this.acquireReference ();
try {
return this.putNull_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "putNull_native", 
($fz = function (row, col) {
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
this.QueryResult.item(row)[columnname] = null;
}
else
throw new IllegalArgumentException("Failed to put into window.");
return true;
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "isNull", 
function (row, col) {
this.acquireReference ();
try {
return this.isNull_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "isNull_native", 
($fz = function (row, col) {
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
var count = 0;
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
if(this.QueryResult.item(row)[columnname] == undefined)
count++;
}
if (count > 0) return true;
 else return false;
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "getBlob", 
function (row, col) {
this.acquireReference ();
try {
return this.getBlob_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "getBlob_native", 
($fz = function (row, col) {
var value = null;
var temp = null;
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
temp = this.QueryResult.item(row)[columnname];
if(temp != null) {
value = android.util.Base64.decode (temp, 0);
}
}
else
throw new IllegalArgumentException("The Query result is empty.");
return value;
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "isBlob", 
function (row, col) {
this.acquireReference ();
try {
return this.isBlob_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "isLong", 
function (row, col) {
this.acquireReference ();
try {
return this.isInteger_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "isFloat", 
function (row, col) {
this.acquireReference ();
try {
return this.isFloat_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "isString", 
function (row, col) {
this.acquireReference ();
try {
return this.isString_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "getString", 
function (row, col) {
this.acquireReference ();
try {
return this.getString_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "getString_native", 
($fz = function (row, col) {
var value = null;
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
value = this.QueryResult.item(row)[columnname];
}
else
throw new IllegalArgumentException("The Query result is empty.");
return value;
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "copyStringToBuffer", 
function (row, col, buffer) {
if (buffer == null) {
throw  new IllegalArgumentException ("CharArrayBuffer should not be null");
}if (buffer.data == null) {
buffer.data =  Clazz.newArray (64, '\0');
}this.acquireReference ();
try {
var newbuf = this.copyStringToBuffer_native (row - this.mStartPos, col, buffer.data.length, buffer);
if (newbuf != null) {
buffer.data = newbuf;
}} finally {
this.releaseReference ();
}
}, "~N,~N,android.database.CharArrayBuffer");
Clazz.defineMethod (c$, "getLong", 
function (row, col) {
this.acquireReference ();
try {
return this.getLong_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "getLong_native", 
($fz = function (row, col) {
var value = 0;
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
var temp = this.QueryResult.item(row)[columnname];
value = parseInt(temp);
}
else
throw new IllegalArgumentException("The Query result is empty.");
return value;
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "getDouble", 
function (row, col) {
this.acquireReference ();
try {
return this.getDouble_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "getDouble_native", 
($fz = function (row, col) {
var value = 0;
if (row <= -1 || row >= this.Length) throw  new IllegalArgumentException ("CurrentPosiztion doesn't point to the Query result");
 else {
if(this.column !== undefined)
{
var columnname =  this.column[col].toString();
var temp = this.QueryResult.item(row)[columnname];
value = parseInt(temp);
}
else
throw new IllegalArgumentException("The Query result is empty.");
return value;
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "getShort", 
function (row, col) {
this.acquireReference ();
try {
return this.getLong_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "getInt", 
function (row, col) {
this.acquireReference ();
try {
return this.getLong_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "getFloat", 
function (row, col) {
this.acquireReference ();
try {
return this.getDouble_native (row - this.mStartPos, col);
} finally {
this.releaseReference ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "clear", 
function () {
this.acquireReference ();
try {
this.mStartPos = 0;
this.native_clear ();
} finally {
this.releaseReference ();
}
});
Clazz.defineMethod (c$, "native_clear", 
($fz = function () {
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "close", 
function () {
this.releaseReference ();
});
Clazz.overrideMethod (c$, "finalize", 
function () {
this.close_native ();
});
c$.newFromParcel = Clazz.defineMethod (c$, "newFromParcel", 
function (p) {
return android.database.CursorWindow.CREATOR.createFromParcel (p);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeStrongBinder (this.native_getBinder ());
dest.writeInt (this.mStartPos);
}, "android.os.Parcel,~N");
Clazz.makeConstructor (c$, 
($fz = function (source) {
Clazz.superConstructor (this, android.database.CursorWindow, []);
var nativeBinder = source.readStrongBinder ();
this.mStartPos = source.readInt ();
}, $fz.isPrivate = true, $fz), "android.os.Parcel");
Clazz.overrideMethod (c$, "onAllReferencesReleased", 
function () {
this.close_native ();
});
c$.$CursorWindow$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.database, "CursorWindow$1", null, android.os.Parcelable.Creator);
Clazz.defineMethod (c$, "createFromParcel", 
function (source) {
return  new android.database.CursorWindow (source);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.database.CursorWindow$1") ? 0 : android.database.CursorWindow.$CursorWindow$1$ ()), Clazz.innerTypeInstance (android.database.CursorWindow$1, this, null));
});
