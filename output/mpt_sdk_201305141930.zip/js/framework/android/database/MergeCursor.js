﻿Clazz.declarePackage ("android.database");
Clazz.load (["android.database.AbstractCursor", "$.DataSetObserver"], "android.database.MergeCursor", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mObserver = null;
this.mCursor = null;
this.mCursors = null;
Clazz.instantialize (this, arguments);
}, android.database, "MergeCursor", android.database.AbstractCursor);
Clazz.prepareFields (c$, function () {
this.mObserver = ((Clazz.isClassDefined ("android.database.MergeCursor$1") ? 0 : android.database.MergeCursor.$MergeCursor$1$ ()), Clazz.innerTypeInstance (android.database.MergeCursor$1, this, null));
});
Clazz.makeConstructor (c$, 
function (cursors) {
Clazz.superConstructor (this, android.database.MergeCursor, []);
this.mCursors = cursors;
this.mCursor = cursors[0];
for (var i = 0; i < this.mCursors.length; i++) {
if (this.mCursors[i] == null) continue ;this.mCursors[i].registerDataSetObserver (this.mObserver);
}
}, "~A");
Clazz.overrideMethod (c$, "getCount", 
function () {
var count = 0;
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] != null) {
count += this.mCursors[i].getCount ();
}}
return count;
});
Clazz.overrideMethod (c$, "onMove", 
function (oldPosition, newPosition) {
this.mCursor = null;
var cursorStartPos = 0;
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] == null) {
continue ;}if (newPosition < (cursorStartPos + this.mCursors[i].getCount ())) {
this.mCursor = this.mCursors[i];
break;
}cursorStartPos += this.mCursors[i].getCount ();
}
if (this.mCursor != null) {
var ret = this.mCursor.moveToPosition (newPosition - cursorStartPos);
return ret;
}return false;
}, "~N,~N");
Clazz.overrideMethod (c$, "deleteRow", 
function () {
return this.mCursor.deleteRow ();
});
Clazz.defineMethod (c$, "commitUpdates", 
function () {
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] != null) {
this.mCursors[i].commitUpdates ();
}}
this.onChange (true);
return true;
});
Clazz.overrideMethod (c$, "getString", 
function (column) {
return this.mCursor.getString (column);
}, "~N");
Clazz.overrideMethod (c$, "getShort", 
function (column) {
return this.mCursor.getShort (column);
}, "~N");
Clazz.overrideMethod (c$, "getInt", 
function (column) {
return this.mCursor.getInt (column);
}, "~N");
Clazz.overrideMethod (c$, "getLong", 
function (column) {
return this.mCursor.getLong (column);
}, "~N");
Clazz.overrideMethod (c$, "getFloat", 
function (column) {
return this.mCursor.getFloat (column);
}, "~N");
Clazz.overrideMethod (c$, "getDouble", 
function (column) {
return this.mCursor.getDouble (column);
}, "~N");
Clazz.overrideMethod (c$, "isNull", 
function (column) {
return this.mCursor.isNull (column);
}, "~N");
Clazz.overrideMethod (c$, "getBlob", 
function (column) {
return this.mCursor.getBlob (column);
}, "~N");
Clazz.overrideMethod (c$, "getColumnNames", 
function () {
if (this.mCursor != null) {
return this.mCursor.getColumnNames ();
} else {
return  new Array (0);
}});
Clazz.defineMethod (c$, "deactivate", 
function () {
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] != null) {
this.mCursors[i].deactivate ();
}}
Clazz.superCall (this, android.database.MergeCursor, "deactivate", []);
});
Clazz.defineMethod (c$, "close", 
function () {
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] == null) continue ;this.mCursors[i].close ();
}
Clazz.superCall (this, android.database.MergeCursor, "close", []);
});
Clazz.overrideMethod (c$, "registerContentObserver", 
function (observer) {
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] != null) {
this.mCursors[i].registerContentObserver (observer);
}}
}, "android.database.ContentObserver");
Clazz.overrideMethod (c$, "unregisterContentObserver", 
function (observer) {
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] != null) {
this.mCursors[i].unregisterContentObserver (observer);
}}
}, "android.database.ContentObserver");
Clazz.overrideMethod (c$, "registerDataSetObserver", 
function (observer) {
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] != null) {
this.mCursors[i].registerDataSetObserver (observer);
}}
}, "android.database.DataSetObserver");
Clazz.overrideMethod (c$, "unregisterDataSetObserver", 
function (observer) {
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] != null) {
this.mCursors[i].unregisterDataSetObserver (observer);
}}
}, "android.database.DataSetObserver");
Clazz.overrideMethod (c$, "requery", 
function () {
var length = this.mCursors.length;
for (var i = 0; i < length; i++) {
if (this.mCursors[i] == null) {
continue ;}if (this.mCursors[i].requery () == false) {
return false;
}}
return true;
});
c$.$MergeCursor$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.database, "MergeCursor$1", android.database.DataSetObserver);
Clazz.overrideMethod (c$, "onChanged", 
function () {
this.b$["android.database.MergeCursor"].mPos = -1;
});
Clazz.overrideMethod (c$, "onInvalidated", 
function () {
this.b$["android.database.MergeCursor"].mPos = -1;
});
c$ = Clazz.p0p ();
};
});
