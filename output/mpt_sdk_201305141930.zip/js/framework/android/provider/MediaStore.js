﻿Clazz.declarePackage ("android.provider");
Clazz.load (["android.provider.BaseColumns", "android.content.ContentUris", "$.ContentValues", "android.graphics.Bitmap", "$.BitmapFactory", "$.Matrix", "android.net.Uri", "android.os.Environment", "android.util.Log", "java.io.FileInputStream"], "android.provider.MediaStore", ["android.media.MiniThumbFile", "$.ThumbnailUtils", "java.lang.IllegalArgumentException", "$.StringBuilder"], function () {
c$ = Clazz.declareType (android.provider, "MediaStore");
c$.getMediaScannerUri = Clazz.defineMethod (c$, "getMediaScannerUri", 
function () {
return android.net.Uri.parse ("content://media/none/media_scanner");
});
Clazz.pu$h ();
c$ = Clazz.declareInterface (android.provider.MediaStore, "MediaColumns", android.provider.BaseColumns);
Clazz.defineStatics (c$,
"DATA", "_data",
"SIZE", "_size",
"DISPLAY_NAME", "_display_name",
"TITLE", "title",
"DATE_ADDED", "date_added",
"DATE_MODIFIED", "date_modified",
"MIME_TYPE", "mime_type");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore, "InternalThumbnails", null, android.provider.BaseColumns);
c$.getMiniThumbFromFile = Clazz.defineMethod (c$, "getMiniThumbFromFile", 
($fz = function (a, b, c, d) {
var e = null;
var f = null;
try {
var g = a.getLong (0);
var h = a.getString (1);
f = android.content.ContentUris.withAppendedId (b, g);
var i = c.openFileDescriptor (f, "r");
e = android.graphics.BitmapFactory.decodeFileDescriptor (i.getFileDescriptor (), null, d);
i.close ();
} catch (e$$) {
if (Clazz.instanceOf (e$$, java.io.FileNotFoundException)) {
var ex = e$$;
{
android.util.Log.e ("MediaStore", "couldn't open thumbnail " + f + "; " + ex);
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
android.util.Log.e ("MediaStore", "couldn't open thumbnail " + f + "; " + ex);
}
} else if (Clazz.instanceOf (e$$, OutOfMemoryError)) {
var ex = e$$;
{
android.util.Log.e ("MediaStore", "failed to allocate memory for thumbnail " + f + "; " + ex);
}
} else {
throw e$$;
}
}
return e;
}, $fz.isPrivate = true, $fz), "android.database.Cursor,android.net.Uri,android.content.ContentResolver,android.graphics.BitmapFactory.Options");
c$.cancelThumbnailRequest = Clazz.defineMethod (c$, "cancelThumbnailRequest", 
function (a, b, c, d) {
var e = c.buildUpon ().appendQueryParameter ("cancel", "1").appendQueryParameter ("orig_id", String.valueOf (b)).appendQueryParameter ("group_id", String.valueOf (d)).build ();
var f = null;
try {
f = a.query (e, android.provider.MediaStore.InternalThumbnails.PROJECTION, null, null, null);
} finally {
if (f != null) f.close ();
}
}, "android.content.ContentResolver,~N,android.net.Uri,~N");
c$.getThumbnail = Clazz.defineMethod (c$, "getThumbnail", 
function (a, b, c, d, e, f, g) {
var h = null;
var i = null;
var j = android.media.MiniThumbFile.instance (f);
var k = j.getMagic (b);
if (k != 0) {
if (d == 3) {
{
if (android.provider.MediaStore.InternalThumbnails.sThumbBuf == null) {
($t$ = android.provider.MediaStore.InternalThumbnails.sThumbBuf =  Clazz.newArray (10000, 0), android.provider.MediaStore.InternalThumbnails.prototype.sThumbBuf = android.provider.MediaStore.InternalThumbnails.sThumbBuf, $t$);
}if (j.getMiniThumbFromFile (b, android.provider.MediaStore.InternalThumbnails.sThumbBuf) != null) {
h = android.graphics.BitmapFactory.decodeByteArray (android.provider.MediaStore.InternalThumbnails.sThumbBuf, 0, android.provider.MediaStore.InternalThumbnails.sThumbBuf.length);
if (h == null) {
android.util.Log.w ("MediaStore", "couldn't decode byte array.");
}}}return h;
} else if (d == 1) {
var l = g ? "video_id=" : "image_id=";
var m = null;
try {
m = a.query (f, android.provider.MediaStore.InternalThumbnails.PROJECTION, l + b, null, null);
if (m != null && m.moveToFirst ()) {
h = android.provider.MediaStore.InternalThumbnails.getMiniThumbFromFile (m, f, a, e);
if (h != null) {
return h;
}}} finally {
if (m != null) m.close ();
}
}}var l = null;
try {
var m = f.buildUpon ().appendQueryParameter ("blocking", "1").appendQueryParameter ("orig_id", String.valueOf (b)).appendQueryParameter ("group_id", String.valueOf (c)).build ();
l = a.query (m, android.provider.MediaStore.InternalThumbnails.PROJECTION, null, null, null);
if (l == null) return null;
if (d == 3) {
{
if (android.provider.MediaStore.InternalThumbnails.sThumbBuf == null) {
($t$ = android.provider.MediaStore.InternalThumbnails.sThumbBuf =  Clazz.newArray (10000, 0), android.provider.MediaStore.InternalThumbnails.prototype.sThumbBuf = android.provider.MediaStore.InternalThumbnails.sThumbBuf, $t$);
}if (j.getMiniThumbFromFile (b, android.provider.MediaStore.InternalThumbnails.sThumbBuf) != null) {
h = android.graphics.BitmapFactory.decodeByteArray (android.provider.MediaStore.InternalThumbnails.sThumbBuf, 0, android.provider.MediaStore.InternalThumbnails.sThumbBuf.length);
if (h == null) {
android.util.Log.w ("MediaStore", "couldn't decode byte array.");
}}}} else if (d == 1) {
if (l.moveToFirst ()) {
h = android.provider.MediaStore.InternalThumbnails.getMiniThumbFromFile (l, f, a, e);
}} else {
throw  new IllegalArgumentException ("Unsupported kind: " + d);
}if (h == null) {
android.util.Log.v ("MediaStore", "Create the thumbnail in memory: origId=" + b + ", kind=" + d + ", isVideo=" + g);
var n = android.net.Uri.parse (f.buildUpon ().appendPath (String.valueOf (b)).toString ().replaceFirst ("thumbnails", "media"));
if (i == null) {
if (l != null) l.close ();
l = a.query (n, android.provider.MediaStore.InternalThumbnails.PROJECTION, null, null, null);
if (l == null || !l.moveToFirst ()) {
return null;
}i = l.getString (1);
}if (g) {
h = android.media.ThumbnailUtils.createVideoThumbnail (i, d);
} else {
h = android.media.ThumbnailUtils.createImageThumbnail (i, d);
}}} catch (ex) {
if (Clazz.instanceOf (ex, android.database.sqlite.SQLiteException)) {
android.util.Log.w ("MediaStore", ex);
} else {
throw ex;
}
} finally {
if (l != null) l.close ();
}
return h;
}, "android.content.ContentResolver,~N,~N,~N,android.graphics.BitmapFactory.Options,android.net.Uri,~B");
Clazz.defineStatics (c$,
"MINI_KIND", 1,
"FULL_SCREEN_KIND", 2,
"MICRO_KIND", 3);
c$.PROJECTION = c$.prototype.PROJECTION = ["_id", "_data"];
Clazz.defineStatics (c$,
"DEFAULT_GROUP_ID", 0);
c$.sThumbBufLock = c$.prototype.sThumbBufLock =  new JavaObject ();
Clazz.defineStatics (c$,
"sThumbBuf", null);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore, "Images");
Clazz.pu$h ();
c$ = Clazz.declareInterface (android.provider.MediaStore.Images, "ImageColumns", android.provider.MediaStore.MediaColumns);
Clazz.defineStatics (c$,
"DESCRIPTION", "description",
"PICASA_ID", "picasa_id",
"IS_PRIVATE", "isprivate",
"LATITUDE", "latitude",
"LONGITUDE", "longitude",
"DATE_TAKEN", "datetaken",
"ORIENTATION", "orientation",
"MINI_THUMB_MAGIC", "mini_thumb_magic",
"BUCKET_ID", "bucket_id",
"BUCKET_DISPLAY_NAME", "bucket_display_name");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Images, "Media", null, android.provider.MediaStore.Images.ImageColumns);
c$.query = Clazz.defineMethod (c$, "query", 
function (a, b, c) {
return a.query (b, c, null, null, "bucket_display_name");
}, "android.content.ContentResolver,android.net.Uri,~A");
c$.query = Clazz.defineMethod (c$, "query", 
function (a, b, c, d, e) {
return a.query (b, c, d, null, e == null ? "bucket_display_name" : e);
}, "android.content.ContentResolver,android.net.Uri,~A,~S,~S");
c$.query = Clazz.defineMethod (c$, "query", 
function (a, b, c, d, e, f) {
return a.query (b, c, d, e, f == null ? "bucket_display_name" : f);
}, "android.content.ContentResolver,android.net.Uri,~A,~S,~A,~S");
c$.getBitmap = Clazz.defineMethod (c$, "getBitmap", 
function (a, b) {
var c = a.openInputStream (b);
var d = android.graphics.BitmapFactory.decodeStream (c);
c.close ();
return d;
}, "android.content.ContentResolver,android.net.Uri");
c$.insertImage = Clazz.defineMethod (c$, "insertImage", 
function (a, b, c, d) {
var e =  new java.io.FileInputStream (b);
try {
var f = android.graphics.BitmapFactory.decodeFile (b);
var g = android.provider.MediaStore.Images.Media.insertImage (a, f, c, d);
f.recycle ();
return g;
} finally {
try {
e.close ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
}
}, "android.content.ContentResolver,~S,~S,~S");
c$.StoreThumbnail = Clazz.defineMethod (c$, "StoreThumbnail", 
($fz = function (a, b, c, d, e, f) {
var g =  new android.graphics.Matrix ();
var h = d / b.getWidth ();
var i = e / b.getHeight ();
g.setScale (h, i);
var j = android.graphics.Bitmap.createBitmap (b, 0, 0, b.getWidth (), b.getHeight (), g, true);
var k =  new android.content.ContentValues (4);
k.put ("kind", new Integer (f));
k.put ("image_id", new Integer (c));
k.put ("height", new Integer (j.getHeight ()));
k.put ("width", new Integer (j.getWidth ()));
var l = a.insert (android.provider.MediaStore.Images.Images.Thumbnails.EXTERNAL_CONTENT_URI, k);
try {
var m = a.openOutputStream (l);
j.compress (android.graphics.Bitmap.CompressFormat.JPEG, 100, m);
m.close ();
return j;
} catch (e$$) {
if (Clazz.instanceOf (e$$, java.io.FileNotFoundException)) {
var ex = e$$;
{
return null;
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
return null;
}
} else {
throw e$$;
}
}
}, $fz.isPrivate = true, $fz), "android.content.ContentResolver,android.graphics.Bitmap,~N,~N,~N,~N");
c$.insertImage = Clazz.defineMethod (c$, "insertImage", 
function (a, b, c, d) {
var e =  new android.content.ContentValues ();
e.put ("title", c);
e.put ("description", d);
e.put ("mime_type", "image/jpeg");
var f = null;
var g = null;
try {
f = a.insert (android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, e);
if (b != null) {
var h = a.openOutputStream (f);
try {
b.compress (android.graphics.Bitmap.CompressFormat.JPEG, 50, h);
} finally {
h.close ();
}
var i = android.content.ContentUris.parseId (f);
var j = android.provider.MediaStore.Images.Thumbnails.getThumbnail (a, i, 1, null);
var k = android.provider.MediaStore.Images.Media.StoreThumbnail (a, j, i, 50, 50, 3);
} else {
android.util.Log.e ("MediaStore", "Failed to create thumbnail, removing original");
a.$delete (f, null, null);
f = null;
}} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.e ("MediaStore", "Failed to insert image", e);
if (f != null) {
a.$delete (f, null, null);
f = null;
}} else {
throw e;
}
}
if (f != null) {
g = f.toString ();
}return g;
}, "android.content.ContentResolver,android.graphics.Bitmap,~S,~S");
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a) {
return android.net.Uri.parse ("content://media/" + a + "/images/media");
}, "~S");
c$.INTERNAL_CONTENT_URI = c$.prototype.INTERNAL_CONTENT_URI = android.provider.MediaStore.Images.Media.getContentUri ("internal");
c$.EXTERNAL_CONTENT_URI = c$.prototype.EXTERNAL_CONTENT_URI = android.provider.MediaStore.Images.Media.getContentUri ("external");
Clazz.defineStatics (c$,
"CONTENT_TYPE", "vnd.android.cursor.dir/image");
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "bucket_display_name";
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Images, "Thumbnails", null, android.provider.BaseColumns);
c$.query = Clazz.defineMethod (c$, "query", 
function (a, b, c) {
return a.query (b, c, null, null, "image_id ASC");
}, "android.content.ContentResolver,android.net.Uri,~A");
c$.queryMiniThumbnails = Clazz.defineMethod (c$, "queryMiniThumbnails", 
function (a, b, c, d) {
return a.query (b, d, "kind = " + c, null, "image_id ASC");
}, "android.content.ContentResolver,android.net.Uri,~N,~A");
c$.queryMiniThumbnail = Clazz.defineMethod (c$, "queryMiniThumbnail", 
function (a, b, c, d) {
return a.query (android.provider.MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, d, "image_id" + " = " + b + " AND " + "kind" + " = " + c, null, null);
}, "android.content.ContentResolver,~N,~N,~A");
c$.cancelThumbnailRequest = Clazz.defineMethod (c$, "cancelThumbnailRequest", 
function (a, b) {
android.provider.MediaStore.InternalThumbnails.cancelThumbnailRequest (a, b, android.provider.MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, 0);
}, "android.content.ContentResolver,~N");
c$.getThumbnail = Clazz.defineMethod (c$, "getThumbnail", 
function (a, b, c, d) {
return android.provider.MediaStore.InternalThumbnails.getThumbnail (a, b, 0, c, d, android.provider.MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, false);
}, "android.content.ContentResolver,~N,~N,android.graphics.BitmapFactory.Options");
c$.cancelThumbnailRequest = Clazz.defineMethod (c$, "cancelThumbnailRequest", 
function (a, b, c) {
android.provider.MediaStore.InternalThumbnails.cancelThumbnailRequest (a, b, android.provider.MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, c);
}, "android.content.ContentResolver,~N,~N");
c$.getThumbnail = Clazz.defineMethod (c$, "getThumbnail", 
function (a, b, c, d, e) {
return android.provider.MediaStore.InternalThumbnails.getThumbnail (a, b, c, d, e, android.provider.MediaStore.Images.Thumbnails.EXTERNAL_CONTENT_URI, false);
}, "android.content.ContentResolver,~N,~N,~N,android.graphics.BitmapFactory.Options");
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a) {
return android.net.Uri.parse ("content://media/" + a + "/images/thumbnails");
}, "~S");
c$.INTERNAL_CONTENT_URI = c$.prototype.INTERNAL_CONTENT_URI = android.provider.MediaStore.Images.Thumbnails.getContentUri ("internal");
c$.EXTERNAL_CONTENT_URI = c$.prototype.EXTERNAL_CONTENT_URI = android.provider.MediaStore.Images.Thumbnails.getContentUri ("external");
Clazz.defineStatics (c$,
"DEFAULT_SORT_ORDER", "image_id ASC",
"DATA", "_data",
"IMAGE_ID", "image_id",
"KIND", "kind",
"MINI_KIND", 1,
"FULL_SCREEN_KIND", 2,
"MICRO_KIND", 3,
"THUMB_DATA", "thumb_data",
"WIDTH", "width",
"HEIGHT", "height");
c$ = Clazz.p0p ();
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore, "Audio");
c$.keyFor = Clazz.defineMethod (c$, "keyFor", 
function (a) {
if (a != null) {
var b = false;
if (a.equals ("<unknown>")) {
return "\001";
}if (a.startsWith ("\001")) {
b = true;
}a = a.trim ().toLowerCase ();
if (a.startsWith ("the ")) {
a = a.substring (4);
}if (a.startsWith ("an ")) {
a = a.substring (3);
}if (a.startsWith ("a ")) {
a = a.substring (2);
}if (a.endsWith (", the") || a.endsWith (",the") || a.endsWith (", an") || a.endsWith (",an") || a.endsWith (", a") || a.endsWith (",a")) {
a = a.substring (0, a.lastIndexOf (','));
}a = a.replaceAll ("[\\[\\]\\(\\)\"'.,?!]", "").trim ();
if (a.length > 0) {
var c =  new StringBuilder ();
c.append ('.');
var d = a.length;
for (var e = 0; e < d; e++) {
c.append (a.charAt (e));
c.append ('.');
}
a = c.toString ();
var f = a;
if (b) {
f = "\001" + f;
}return f;
} else {
return "";
}}return null;
}, "~S");
Clazz.pu$h ();
c$ = Clazz.declareInterface (android.provider.MediaStore.Audio, "AudioColumns", android.provider.MediaStore.MediaColumns);
Clazz.defineStatics (c$,
"TITLE_KEY", "title_key",
"DURATION", "duration",
"BOOKMARK", "bookmark",
"ARTIST_ID", "artist_id",
"ARTIST", "artist",
"ALBUM_ARTIST", "album_artist",
"COMPILATION", "compilation",
"ARTIST_KEY", "artist_key",
"COMPOSER", "composer",
"ALBUM_ID", "album_id",
"ALBUM", "album",
"ALBUM_KEY", "album_key",
"ALBUM_ART", "album_art",
"TRACK", "track",
"YEAR", "year",
"IS_MUSIC", "is_music",
"IS_PODCAST", "is_podcast",
"IS_RINGTONE", "is_ringtone",
"IS_ALARM", "is_alarm",
"IS_NOTIFICATION", "is_notification");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Audio, "Media", null, android.provider.MediaStore.Audio.AudioColumns);
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a) {
return android.net.Uri.parse ("content://media/" + a + "/audio/media");
}, "~S");
c$.getContentUriForPath = Clazz.defineMethod (c$, "getContentUriForPath", 
function (a) {
return (a.startsWith (android.os.Environment.getExternalStorageDirectory ().getPath ()) ? android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI : android.provider.MediaStore.Audio.Media.INTERNAL_CONTENT_URI);
}, "~S");
c$.INTERNAL_CONTENT_URI = c$.prototype.INTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Media.getContentUri ("internal");
c$.EXTERNAL_CONTENT_URI = c$.prototype.EXTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Media.getContentUri ("external");
Clazz.defineStatics (c$,
"CONTENT_TYPE", "vnd.android.cursor.dir/audio");
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "title_key";
Clazz.defineStatics (c$,
"RECORD_SOUND_ACTION", "android.provider.MediaStore.RECORD_SOUND",
"EXTRA_MAX_BYTES", "android.provider.MediaStore.extra.MAX_BYTES");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareInterface (android.provider.MediaStore.Audio, "GenresColumns");
Clazz.defineStatics (c$,
"NAME", "name");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Audio, "Genres", null, [android.provider.BaseColumns, android.provider.MediaStore.Audio.GenresColumns]);
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a) {
return android.net.Uri.parse ("content://media/" + a + "/audio/genres");
}, "~S");
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Audio.Genres, "Members", null, android.provider.MediaStore.Audio.AudioColumns);
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a, b) {
return android.net.Uri.parse ("content://media/" + a + "/audio/genres/" + b + "/members");
}, "~S,~N");
Clazz.defineStatics (c$,
"CONTENT_DIRECTORY", "members");
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "title_key";
Clazz.defineStatics (c$,
"AUDIO_ID", "audio_id",
"GENRE_ID", "genre_id");
c$ = Clazz.p0p ();
c$.INTERNAL_CONTENT_URI = c$.prototype.INTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Genres.getContentUri ("internal");
c$.EXTERNAL_CONTENT_URI = c$.prototype.EXTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Genres.getContentUri ("external");
Clazz.defineStatics (c$,
"CONTENT_TYPE", "vnd.android.cursor.dir/genre",
"ENTRY_CONTENT_TYPE", "vnd.android.cursor.item/genre");
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "name";
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareInterface (android.provider.MediaStore.Audio, "PlaylistsColumns");
Clazz.defineStatics (c$,
"NAME", "name",
"DATA", "_data",
"DATE_ADDED", "date_added",
"DATE_MODIFIED", "date_modified");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Audio, "Playlists", null, [android.provider.BaseColumns, android.provider.MediaStore.Audio.PlaylistsColumns]);
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a) {
return android.net.Uri.parse ("content://media/" + a + "/audio/playlists");
}, "~S");
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Audio.Playlists, "Members", null, android.provider.MediaStore.Audio.AudioColumns);
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a, b) {
return android.net.Uri.parse ("content://media/" + a + "/audio/playlists/" + b + "/members");
}, "~S,~N");
c$.moveItem = Clazz.defineMethod (c$, "moveItem", 
function (a, b, c, d) {
var e = android.provider.MediaStore.MediaStore.Audio.Playlists.Members.getContentUri ("external", b).buildUpon ().appendEncodedPath (String.valueOf (c)).appendQueryParameter ("move", "true").build ();
var f =  new android.content.ContentValues ();
f.put ("play_order", new Integer (d));
return a.update (e, f, null, null) != 0;
}, "android.content.ContentResolver,~N,~N,~N");
Clazz.defineStatics (c$,
"_ID", "_id",
"CONTENT_DIRECTORY", "members",
"AUDIO_ID", "audio_id",
"PLAYLIST_ID", "playlist_id",
"PLAY_ORDER", "play_order");
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "play_order";
c$ = Clazz.p0p ();
c$.INTERNAL_CONTENT_URI = c$.prototype.INTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Playlists.getContentUri ("internal");
c$.EXTERNAL_CONTENT_URI = c$.prototype.EXTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Playlists.getContentUri ("external");
Clazz.defineStatics (c$,
"CONTENT_TYPE", "vnd.android.cursor.dir/playlist",
"ENTRY_CONTENT_TYPE", "vnd.android.cursor.item/playlist");
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "name";
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareInterface (android.provider.MediaStore.Audio, "ArtistColumns");
Clazz.defineStatics (c$,
"ARTIST", "artist",
"ARTIST_KEY", "artist_key",
"NUMBER_OF_ALBUMS", "number_of_albums",
"NUMBER_OF_TRACKS", "number_of_tracks");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Audio, "Artists", null, [android.provider.BaseColumns, android.provider.MediaStore.Audio.ArtistColumns]);
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a) {
return android.net.Uri.parse ("content://media/" + a + "/audio/artists");
}, "~S");
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Audio.Artists, "Albums", null, android.provider.MediaStore.Audio.AlbumColumns);
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a, b) {
return android.net.Uri.parse ("content://media/" + a + "/audio/artists/" + b + "/albums");
}, "~S,~N");
c$ = Clazz.p0p ();
c$.INTERNAL_CONTENT_URI = c$.prototype.INTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Artists.getContentUri ("internal");
c$.EXTERNAL_CONTENT_URI = c$.prototype.EXTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Artists.getContentUri ("external");
Clazz.defineStatics (c$,
"CONTENT_TYPE", "vnd.android.cursor.dir/artists",
"ENTRY_CONTENT_TYPE", "vnd.android.cursor.item/artist");
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "artist_key";
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareInterface (android.provider.MediaStore.Audio, "AlbumColumns");
Clazz.defineStatics (c$,
"ALBUM_ID", "album_id",
"ALBUM", "album",
"ARTIST", "artist",
"NUMBER_OF_SONGS", "numsongs",
"NUMBER_OF_SONGS_FOR_ARTIST", "numsongs_by_artist",
"FIRST_YEAR", "minyear",
"LAST_YEAR", "maxyear",
"ALBUM_KEY", "album_key",
"ALBUM_ART", "album_art");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Audio, "Albums", null, [android.provider.BaseColumns, android.provider.MediaStore.Audio.AlbumColumns]);
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a) {
return android.net.Uri.parse ("content://media/" + a + "/audio/albums");
}, "~S");
c$.INTERNAL_CONTENT_URI = c$.prototype.INTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Albums.getContentUri ("internal");
c$.EXTERNAL_CONTENT_URI = c$.prototype.EXTERNAL_CONTENT_URI = android.provider.MediaStore.Audio.Albums.getContentUri ("external");
Clazz.defineStatics (c$,
"CONTENT_TYPE", "vnd.android.cursor.dir/albums",
"ENTRY_CONTENT_TYPE", "vnd.android.cursor.item/album");
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "album_key";
c$ = Clazz.p0p ();
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore, "Video");
c$.query = Clazz.defineMethod (c$, "query", 
function (a, b, c) {
return a.query (b, c, null, null, "_display_name");
}, "android.content.ContentResolver,android.net.Uri,~A");
Clazz.pu$h ();
c$ = Clazz.declareInterface (android.provider.MediaStore.Video, "VideoColumns", android.provider.MediaStore.MediaColumns);
Clazz.defineStatics (c$,
"DURATION", "duration",
"ARTIST", "artist",
"ALBUM", "album",
"RESOLUTION", "resolution",
"DESCRIPTION", "description",
"IS_PRIVATE", "isprivate",
"TAGS", "tags",
"CATEGORY", "category",
"LANGUAGE", "language",
"LATITUDE", "latitude",
"LONGITUDE", "longitude",
"DATE_TAKEN", "datetaken",
"MINI_THUMB_MAGIC", "mini_thumb_magic",
"BUCKET_ID", "bucket_id",
"BUCKET_DISPLAY_NAME", "bucket_display_name",
"BOOKMARK", "bookmark");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Video, "Media", null, android.provider.MediaStore.Video.VideoColumns);
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a) {
return android.net.Uri.parse ("content://media/" + a + "/video/media");
}, "~S");
c$.INTERNAL_CONTENT_URI = c$.prototype.INTERNAL_CONTENT_URI = android.provider.MediaStore.Video.Media.getContentUri ("internal");
c$.EXTERNAL_CONTENT_URI = c$.prototype.EXTERNAL_CONTENT_URI = android.provider.MediaStore.Video.Media.getContentUri ("external");
Clazz.defineStatics (c$,
"CONTENT_TYPE", "vnd.android.cursor.dir/video");
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "title";
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.MediaStore.Video, "Thumbnails", null, android.provider.BaseColumns);
c$.cancelThumbnailRequest = Clazz.defineMethod (c$, "cancelThumbnailRequest", 
function (a, b) {
android.provider.MediaStore.InternalThumbnails.cancelThumbnailRequest (a, b, android.provider.MediaStore.Video.Thumbnails.EXTERNAL_CONTENT_URI, 0);
}, "android.content.ContentResolver,~N");
c$.getThumbnail = Clazz.defineMethod (c$, "getThumbnail", 
function (a, b, c, d) {
return android.provider.MediaStore.InternalThumbnails.getThumbnail (a, b, 0, c, d, android.provider.MediaStore.Video.Thumbnails.EXTERNAL_CONTENT_URI, true);
}, "android.content.ContentResolver,~N,~N,android.graphics.BitmapFactory.Options");
c$.getThumbnail = Clazz.defineMethod (c$, "getThumbnail", 
function (a, b, c, d, e) {
return android.provider.MediaStore.InternalThumbnails.getThumbnail (a, b, c, d, e, android.provider.MediaStore.Video.Thumbnails.EXTERNAL_CONTENT_URI, true);
}, "android.content.ContentResolver,~N,~N,~N,android.graphics.BitmapFactory.Options");
c$.cancelThumbnailRequest = Clazz.defineMethod (c$, "cancelThumbnailRequest", 
function (a, b, c) {
android.provider.MediaStore.InternalThumbnails.cancelThumbnailRequest (a, b, android.provider.MediaStore.Video.Thumbnails.EXTERNAL_CONTENT_URI, c);
}, "android.content.ContentResolver,~N,~N");
c$.getContentUri = Clazz.defineMethod (c$, "getContentUri", 
function (a) {
return android.net.Uri.parse ("content://media/" + a + "/video/thumbnails");
}, "~S");
c$.INTERNAL_CONTENT_URI = c$.prototype.INTERNAL_CONTENT_URI = android.provider.MediaStore.Video.Thumbnails.getContentUri ("internal");
c$.EXTERNAL_CONTENT_URI = c$.prototype.EXTERNAL_CONTENT_URI = android.provider.MediaStore.Video.Thumbnails.getContentUri ("external");
Clazz.defineStatics (c$,
"DEFAULT_SORT_ORDER", "video_id ASC",
"DATA", "_data",
"VIDEO_ID", "video_id",
"KIND", "kind",
"MINI_KIND", 1,
"FULL_SCREEN_KIND", 2,
"MICRO_KIND", 3,
"WIDTH", "width",
"HEIGHT", "height");
c$ = Clazz.p0p ();
c$.DEFAULT_SORT_ORDER = c$.prototype.DEFAULT_SORT_ORDER = "_display_name";
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "MediaStore",
"AUTHORITY", "media");
c$.CONTENT_AUTHORITY_SLASH = c$.prototype.CONTENT_AUTHORITY_SLASH = "content://media/";
Clazz.defineStatics (c$,
"INTENT_ACTION_MUSIC_PLAYER", "android.intent.action.MUSIC_PLAYER",
"INTENT_ACTION_MEDIA_SEARCH", "android.intent.action.MEDIA_SEARCH",
"INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH", "android.media.action.MEDIA_PLAY_FROM_SEARCH",
"EXTRA_MEDIA_ARTIST", "android.intent.extra.artist",
"EXTRA_MEDIA_ALBUM", "android.intent.extra.album",
"EXTRA_MEDIA_TITLE", "android.intent.extra.title",
"EXTRA_MEDIA_FOCUS", "android.intent.extra.focus",
"EXTRA_SCREEN_ORIENTATION", "android.intent.extra.screenOrientation",
"EXTRA_FULL_SCREEN", "android.intent.extra.fullScreen",
"EXTRA_SHOW_ACTION_ICONS", "android.intent.extra.showActionIcons",
"EXTRA_FINISH_ON_COMPLETION", "android.intent.extra.finishOnCompletion",
"INTENT_ACTION_STILL_IMAGE_CAMERA", "android.media.action.STILL_IMAGE_CAMERA",
"INTENT_ACTION_VIDEO_CAMERA", "android.media.action.VIDEO_CAMERA",
"ACTION_IMAGE_CAPTURE", "android.media.action.IMAGE_CAPTURE",
"ACTION_VIDEO_CAPTURE", "android.media.action.VIDEO_CAPTURE",
"EXTRA_VIDEO_QUALITY", "android.intent.extra.videoQuality",
"EXTRA_SIZE_LIMIT", "android.intent.extra.sizeLimit",
"EXTRA_DURATION_LIMIT", "android.intent.extra.durationLimit",
"EXTRA_OUTPUT", "output",
"UNKNOWN_STRING", "<unknown>",
"MEDIA_SCANNER_VOLUME", "volume",
"MEDIA_IGNORE_FILENAME", ".nomedia");
});
