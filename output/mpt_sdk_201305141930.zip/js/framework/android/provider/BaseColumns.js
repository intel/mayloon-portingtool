﻿Clazz.declarePackage ("android.provider");
c$ = Clazz.declareInterface (android.provider, "BaseColumns");
Clazz.defineStatics (c$,
"_ID", "_id",
"_COUNT", "_count");
