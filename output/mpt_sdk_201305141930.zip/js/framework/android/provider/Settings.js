﻿Clazz.declarePackage ("android.provider");
Clazz.load (["android.provider.BaseColumns", "android.util.AndroidException", "android.net.Uri", "java.util.HashMap"], "android.provider.Settings", ["android.content.ContentValues", "$.Intent", "android.os.SystemProperties", "android.text.TextUtils", "android.util.Log", "java.lang.Float", "$.IllegalArgumentException", "$.Long", "java.util.HashSet"], function () {
c$ = Clazz.declareType (android.provider, "Settings");
c$.getGTalkDeviceId = Clazz.defineMethod (c$, "getGTalkDeviceId", 
function (androidId) {
return "android-" + Long.toHexString (androidId);
}, "~N");
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.Settings, "SettingNotFoundException", android.util.AndroidException);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.Settings, "NameValueTable", null, android.provider.BaseColumns);
c$.putString = Clazz.defineMethod (c$, "putString", 
function (a, b, c, d) {
try {
var e =  new android.content.ContentValues ();
e.put ("name", c);
e.put ("value", d);
a.insert (b, e);
return true;
} catch (e) {
if (Clazz.instanceOf (e, android.database.SQLException)) {
android.util.Log.w ("Settings", "Can't set key " + c + " in " + b, e);
return false;
} else {
throw e;
}
}
}, "android.content.ContentResolver,android.net.Uri,~S,~S");
c$.getUriFor = Clazz.defineMethod (c$, "getUriFor", 
function (a, b) {
return android.net.Uri.withAppendedPath (a, b);
}, "android.net.Uri,~S");
Clazz.defineStatics (c$,
"NAME", "name",
"VALUE", "value");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mVersionSystemProperty = null;
this.mUri = null;
this.mValues = null;
this.mValuesVersion = 0;
this.mContentProvider = null;
this.mCallCommand = null;
Clazz.instantialize (this, arguments);
}, android.provider.Settings, "NameValueCache");
Clazz.prepareFields (c$, function () {
this.mValues =  new java.util.HashMap ();
});
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.mVersionSystemProperty = a;
this.mUri = b;
this.mCallCommand = c;
}, "~S,android.net.Uri,~S");
Clazz.defineMethod (c$, "getString", 
function (a, b) {
var c = android.os.SystemProperties.getLong (this.mVersionSystemProperty, 0);
{
if (this.mValuesVersion != c) {
if (false) {
android.util.Log.v ("Settings", "invalidate [" + this.mUri.getLastPathSegment () + "]: current " + c + " != cached " + this.mValuesVersion);
}this.mValues.clear ();
this.mValuesVersion = c;
}if (this.mValues.containsKey (b)) {
return this.mValues.get (b);
}}var d = null;
{
d = this.mContentProvider;
if (d == null) {
d = this.mContentProvider = a.acquireProvider (this.mUri.getAuthority ());
}}if (this.mCallCommand != null) {
var e = d.call (this.mCallCommand, b, null);
if (e != null) {
var f = e.getPairValue ();
{
this.mValues.put (b, f);
}return f;
}}var e = null;
try {
e = d.query (this.mUri, android.provider.Settings.NameValueCache.SELECT_VALUE, "name=?", [b], null);
if (e == null) {
android.util.Log.w ("Settings", "Can't get key " + b + " from " + this.mUri);
return null;
}var f = e.moveToNext () ? e.getString (0) : null;
{
this.mValues.put (b, f);
}if (false) {
android.util.Log.v ("Settings", "cache miss [" + this.mUri.getLastPathSegment () + "]: " + b + " = " + (f == null ? "(null)" : f));
}return f;
} finally {
if (e != null) e.close ();
}
}, "android.content.ContentResolver,~S");
c$.SELECT_VALUE = c$.prototype.SELECT_VALUE = ["value"];
Clazz.defineStatics (c$,
"NAME_EQ_PLACEHOLDER", "name=?");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.Settings, "System", android.provider.Settings.NameValueTable);
c$.getString = Clazz.defineMethod (c$, "getString", 
function (a, b) {
if (android.provider.Settings.System.MOVED_TO_SECURE.contains (b)) {
android.util.Log.w ("Settings", "Setting " + b + " has moved from android.provider.Settings.System" + " to android.provider.Settings.Secure, returning read-only value.");
return android.provider.Settings.Secure.getString (a, b);
}if (android.provider.Settings.System.sNameValueCache == null) {
($t$ = android.provider.Settings.System.sNameValueCache =  new android.provider.Settings.NameValueCache ("sys.settings_system_version", android.provider.Settings.System.CONTENT_URI, "GET_system"), android.provider.Settings.System.prototype.sNameValueCache = android.provider.Settings.System.sNameValueCache, $t$);
}return android.provider.Settings.System.sNameValueCache.getString (a, b);
}, "android.content.ContentResolver,~S");
c$.putString = Clazz.defineMethod (c$, "putString", 
function (a, b, c) {
if (android.provider.Settings.System.MOVED_TO_SECURE.contains (b)) {
android.util.Log.w ("Settings", "Setting " + b + " has moved from android.provider.Settings.System" + " to android.provider.Settings.Secure, value is unchanged.");
return false;
}return android.provider.Settings.NameValueTable.putString (a, android.provider.Settings.System.CONTENT_URI, b, c);
}, "android.content.ContentResolver,~S,~S");
c$.getUriFor = Clazz.defineMethod (c$, "getUriFor", 
function (a) {
if (android.provider.Settings.System.MOVED_TO_SECURE.contains (a)) {
android.util.Log.w ("Settings", "Setting " + a + " has moved from android.provider.Settings.System" + " to android.provider.Settings.Secure, returning Secure URI.");
return android.provider.Settings.Secure.getUriFor (android.provider.Settings.Secure.CONTENT_URI, a);
}return android.provider.Settings.NameValueTable.getUriFor (android.provider.Settings.System.CONTENT_URI, a);
}, "~S");
c$.getInt = Clazz.defineMethod (c$, "getInt", 
function (a, b, c) {
var d = android.provider.Settings.System.getString (a, b);
try {
return d != null ? Integer.parseInt (d) : c;
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
return c;
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S,~N");
c$.getInt = Clazz.defineMethod (c$, "getInt", 
function (a, b) {
var c = android.provider.Settings.System.getString (a, b);
try {
return Integer.parseInt (c);
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
throw  new android.provider.Settings.SettingNotFoundException (b);
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S");
c$.putInt = Clazz.defineMethod (c$, "putInt", 
function (a, b, c) {
return android.provider.Settings.System.putString (a, b, Integer.toString (c));
}, "android.content.ContentResolver,~S,~N");
c$.getLong = Clazz.defineMethod (c$, "getLong", 
function (a, b, c) {
var d = android.provider.Settings.System.getString (a, b);
var e;
try {
e = d != null ? Long.parseLong (d) : c;
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
e = c;
} else {
throw e;
}
}
return e;
}, "android.content.ContentResolver,~S,~N");
c$.getLong = Clazz.defineMethod (c$, "getLong", 
function (a, b) {
var c = android.provider.Settings.System.getString (a, b);
try {
return Long.parseLong (c);
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
throw  new android.provider.Settings.SettingNotFoundException (b);
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S");
c$.putLong = Clazz.defineMethod (c$, "putLong", 
function (a, b, c) {
return android.provider.Settings.System.putString (a, b, Long.toString (c));
}, "android.content.ContentResolver,~S,~N");
c$.getFloat = Clazz.defineMethod (c$, "getFloat", 
function (a, b, c) {
var d = android.provider.Settings.System.getString (a, b);
try {
return d != null ? Float.parseFloat (d) : c;
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
return c;
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S,~N");
c$.getFloat = Clazz.defineMethod (c$, "getFloat", 
function (a, b) {
var c = android.provider.Settings.System.getString (a, b);
try {
return Float.parseFloat (c);
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
throw  new android.provider.Settings.SettingNotFoundException (b);
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S");
c$.putFloat = Clazz.defineMethod (c$, "putFloat", 
function (a, b, c) {
return android.provider.Settings.System.putString (a, b, Float.toString (c));
}, "android.content.ContentResolver,~S,~N");
c$.getConfiguration = Clazz.defineMethod (c$, "getConfiguration", 
function (a, b) {
b.fontScale = android.provider.Settings.System.getFloat (a, "font_scale", b.fontScale);
if (b.fontScale < 0) {
b.fontScale = 1;
}}, "android.content.ContentResolver,android.content.res.Configuration");
c$.putConfiguration = Clazz.defineMethod (c$, "putConfiguration", 
function (a, b) {
return android.provider.Settings.System.putFloat (a, "font_scale", b.fontScale);
}, "android.content.ContentResolver,android.content.res.Configuration");
c$.hasInterestingConfigurationChanges = Clazz.defineMethod (c$, "hasInterestingConfigurationChanges", 
function (a) {
return (a & 1073741824) != 0;
}, "~N");
c$.getShowGTalkServiceStatus = Clazz.defineMethod (c$, "getShowGTalkServiceStatus", 
function (a) {
return android.provider.Settings.System.getInt (a, "SHOW_GTALK_SERVICE_STATUS", 0) != 0;
}, "android.content.ContentResolver");
c$.setShowGTalkServiceStatus = Clazz.defineMethod (c$, "setShowGTalkServiceStatus", 
function (a, b) {
android.provider.Settings.System.putInt (a, "SHOW_GTALK_SERVICE_STATUS", b ? 1 : 0);
}, "android.content.ContentResolver,~B");
Clazz.defineStatics (c$,
"SYS_PROP_SETTING_VERSION", "sys.settings_system_version",
"sNameValueCache", null,
"MOVED_TO_SECURE", null);
{
($t$ = android.provider.Settings.System.MOVED_TO_SECURE =  new java.util.HashSet (30), android.provider.Settings.System.prototype.MOVED_TO_SECURE = android.provider.Settings.System.MOVED_TO_SECURE, $t$);
android.provider.Settings.System.MOVED_TO_SECURE.add ("adb_enabled");
android.provider.Settings.System.MOVED_TO_SECURE.add ("android_id");
android.provider.Settings.System.MOVED_TO_SECURE.add ("bluetooth_on");
android.provider.Settings.System.MOVED_TO_SECURE.add ("data_roaming");
android.provider.Settings.System.MOVED_TO_SECURE.add ("device_provisioned");
android.provider.Settings.System.MOVED_TO_SECURE.add ("http_proxy");
android.provider.Settings.System.MOVED_TO_SECURE.add ("install_non_market_apps");
android.provider.Settings.System.MOVED_TO_SECURE.add ("location_providers_allowed");
android.provider.Settings.System.MOVED_TO_SECURE.add ("lock_pattern_autolock");
android.provider.Settings.System.MOVED_TO_SECURE.add ("lock_pattern_visible_pattern");
android.provider.Settings.System.MOVED_TO_SECURE.add ("lock_pattern_tactile_feedback_enabled");
android.provider.Settings.System.MOVED_TO_SECURE.add ("logging_id");
android.provider.Settings.System.MOVED_TO_SECURE.add ("parental_control_enabled");
android.provider.Settings.System.MOVED_TO_SECURE.add ("parental_control_last_update");
android.provider.Settings.System.MOVED_TO_SECURE.add ("parental_control_redirect_url");
android.provider.Settings.System.MOVED_TO_SECURE.add ("settings_classname");
android.provider.Settings.System.MOVED_TO_SECURE.add ("usb_mass_storage_enabled");
android.provider.Settings.System.MOVED_TO_SECURE.add ("use_google_mail");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_networks_available_notification_on");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_networks_available_repeat_delay");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_num_open_networks_kept");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_on");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_acceptable_packet_loss_percentage");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_ap_count");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_background_check_delay_ms");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_background_check_enabled");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_background_check_timeout_ms");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_initial_ignored_ping_count");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_max_ap_checks");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_on");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_ping_count");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_ping_delay_ms");
android.provider.Settings.System.MOVED_TO_SECURE.add ("wifi_watchdog_ping_timeout_ms");
}c$.CONTENT_URI = c$.prototype.CONTENT_URI = android.net.Uri.parse ("content://settings/system");
Clazz.defineStatics (c$,
"STAY_ON_WHILE_PLUGGED_IN", "stay_on_while_plugged_in",
"END_BUTTON_BEHAVIOR", "end_button_behavior",
"END_BUTTON_BEHAVIOR_HOME", 0x1,
"END_BUTTON_BEHAVIOR_SLEEP", 0x2,
"END_BUTTON_BEHAVIOR_DEFAULT", 2,
"AIRPLANE_MODE_ON", "airplane_mode_on",
"RADIO_BLUETOOTH", "bluetooth",
"RADIO_WIFI", "wifi",
"RADIO_CELL", "cell",
"RADIO_WIMAX", "wimax",
"AIRPLANE_MODE_RADIOS", "airplane_mode_radios",
"AIRPLANE_MODE_TOGGLEABLE_RADIOS", "airplane_mode_toggleable_radios",
"WIFI_SLEEP_POLICY", "wifi_sleep_policy",
"WIFI_SLEEP_POLICY_DEFAULT", 0,
"WIFI_SLEEP_POLICY_NEVER_WHILE_PLUGGED", 1,
"WIFI_SLEEP_POLICY_NEVER", 2,
"WIFI_USE_STATIC_IP", "wifi_use_static_ip",
"WIFI_STATIC_IP", "wifi_static_ip",
"WIFI_STATIC_GATEWAY", "wifi_static_gateway",
"WIFI_STATIC_NETMASK", "wifi_static_netmask",
"WIFI_STATIC_DNS1", "wifi_static_dns1",
"WIFI_STATIC_DNS2", "wifi_static_dns2",
"WIFI_NUM_ALLOWED_CHANNELS", "wifi_num_allowed_channels",
"BLUETOOTH_DISCOVERABILITY", "bluetooth_discoverability",
"BLUETOOTH_DISCOVERABILITY_TIMEOUT", "bluetooth_discoverability_timeout");
c$.LOCK_PATTERN_ENABLED = c$.prototype.LOCK_PATTERN_ENABLED = "lock_pattern_autolock";
Clazz.defineStatics (c$,
"LOCK_PATTERN_VISIBLE", "lock_pattern_visible_pattern",
"LOCK_PATTERN_TACTILE_FEEDBACK_ENABLED", "lock_pattern_tactile_feedback_enabled",
"NEXT_ALARM_FORMATTED", "next_alarm_formatted",
"FONT_SCALE", "font_scale",
"DEBUG_APP", "debug_app",
"WAIT_FOR_DEBUGGER", "wait_for_debugger",
"DIM_SCREEN", "dim_screen",
"SCREEN_OFF_TIMEOUT", "screen_off_timeout",
"COMPATIBILITY_MODE", "compatibility_mode",
"SCREEN_BRIGHTNESS", "screen_brightness",
"SCREEN_BRIGHTNESS_MODE", "screen_brightness_mode",
"SCREEN_BRIGHTNESS_MODE_MANUAL", 0,
"SCREEN_BRIGHTNESS_MODE_AUTOMATIC", 1,
"SHOW_PROCESSES", "show_processes",
"ALWAYS_FINISH_ACTIVITIES", "always_finish_activities",
"MODE_RINGER", "mode_ringer",
"MODE_RINGER_STREAMS_AFFECTED", "mode_ringer_streams_affected",
"MUTE_STREAMS_AFFECTED", "mute_streams_affected",
"VIBRATE_ON", "vibrate_on",
"VOLUME_RING", "volume_ring",
"VOLUME_SYSTEM", "volume_system",
"VOLUME_VOICE", "volume_voice",
"VOLUME_MUSIC", "volume_music",
"VOLUME_ALARM", "volume_alarm",
"VOLUME_NOTIFICATION", "volume_notification",
"VOLUME_BLUETOOTH_SCO", "volume_bluetooth_sco",
"NOTIFICATIONS_USE_RING_VOLUME", "notifications_use_ring_volume",
"VIBRATE_IN_SILENT", "vibrate_in_silent");
c$.VOLUME_SETTINGS = c$.prototype.VOLUME_SETTINGS = ["volume_voice", "volume_system", "volume_ring", "volume_music", "volume_alarm", "volume_notification", "volume_bluetooth_sco"];
Clazz.defineStatics (c$,
"APPEND_FOR_LAST_AUDIBLE", "_last_audible",
"RINGTONE", "ringtone");
c$.DEFAULT_RINGTONE_URI = c$.prototype.DEFAULT_RINGTONE_URI = android.provider.Settings.System.getUriFor ("ringtone");
Clazz.defineStatics (c$,
"NOTIFICATION_SOUND", "notification_sound");
c$.DEFAULT_NOTIFICATION_URI = c$.prototype.DEFAULT_NOTIFICATION_URI = android.provider.Settings.System.getUriFor ("notification_sound");
Clazz.defineStatics (c$,
"ALARM_ALERT", "alarm_alert");
c$.DEFAULT_ALARM_ALERT_URI = c$.prototype.DEFAULT_ALARM_ALERT_URI = android.provider.Settings.System.getUriFor ("alarm_alert");
Clazz.defineStatics (c$,
"TEXT_AUTO_REPLACE", "auto_replace",
"TEXT_AUTO_CAPS", "auto_caps",
"TEXT_AUTO_PUNCTUATE", "auto_punctuate",
"TEXT_SHOW_PASSWORD", "show_password",
"SHOW_GTALK_SERVICE_STATUS", "SHOW_GTALK_SERVICE_STATUS",
"WALLPAPER_ACTIVITY", "wallpaper_activity",
"AUTO_TIME", "auto_time",
"TIME_12_24", "time_12_24",
"DATE_FORMAT", "date_format",
"SETUP_WIZARD_HAS_RUN", "setup_wizard_has_run",
"WINDOW_ANIMATION_SCALE", "window_animation_scale",
"TRANSITION_ANIMATION_SCALE", "transition_animation_scale",
"FANCY_IME_ANIMATIONS", "fancy_ime_animations",
"ACCELEROMETER_ROTATION", "accelerometer_rotation",
"DTMF_TONE_WHEN_DIALING", "dtmf_tone",
"DTMF_TONE_TYPE_WHEN_DIALING", "dtmf_tone_type",
"EMERGENCY_TONE", "emergency_tone",
"CALL_AUTO_RETRY", "call_auto_retry",
"HEARING_AID", "hearing_aid",
"TTY_MODE", "tty_mode",
"SOUND_EFFECTS_ENABLED", "sound_effects_enabled",
"HAPTIC_FEEDBACK_ENABLED", "haptic_feedback_enabled",
"SHOW_WEB_SUGGESTIONS", "show_web_suggestions",
"NOTIFICATION_LIGHT_PULSE", "notification_light_pulse",
"POINTER_LOCATION", "pointer_location",
"POWER_SOUNDS_ENABLED", "power_sounds_enabled",
"DOCK_SOUNDS_ENABLED", "dock_sounds_enabled",
"LOCKSCREEN_SOUNDS_ENABLED", "lockscreen_sounds_enabled",
"LOW_BATTERY_SOUND", "low_battery_sound",
"DESK_DOCK_SOUND", "desk_dock_sound",
"DESK_UNDOCK_SOUND", "desk_undock_sound",
"CAR_DOCK_SOUND", "car_dock_sound",
"CAR_UNDOCK_SOUND", "car_undock_sound",
"LOCK_SOUND", "lock_sound",
"UNLOCK_SOUND", "unlock_sound",
"SIP_RECEIVE_CALLS", "sip_receive_calls",
"SIP_CALL_OPTIONS", "sip_call_options",
"SIP_ALWAYS", "SIP_ALWAYS",
"SIP_ADDRESS_ONLY", "SIP_ADDRESS_ONLY",
"SIP_ASK_ME_EACH_TIME", "SIP_ASK_ME_EACH_TIME");
c$.SETTINGS_TO_BACKUP = c$.prototype.SETTINGS_TO_BACKUP = ["stay_on_while_plugged_in", "wifi_sleep_policy", "wifi_use_static_ip", "wifi_static_ip", "wifi_static_gateway", "wifi_static_netmask", "wifi_static_dns1", "wifi_static_dns2", "bluetooth_discoverability", "bluetooth_discoverability_timeout", "dim_screen", "screen_off_timeout", "screen_brightness", "screen_brightness_mode", "vibrate_on", "notifications_use_ring_volume", "mode_ringer", "mode_ringer_streams_affected", "mute_streams_affected", "volume_voice", "volume_system", "volume_ring", "volume_music", "volume_alarm", "volume_notification", "volume_bluetooth_sco", "volume_voice_last_audible", "volume_system_last_audible", "volume_ring_last_audible", "volume_music_last_audible", "volume_alarm_last_audible", "volume_notification_last_audible", "volume_bluetooth_sco_last_audible", "vibrate_in_silent", "auto_replace", "auto_caps", "auto_punctuate", "show_password", "auto_time", "time_12_24", "date_format", "accelerometer_rotation", "dtmf_tone", "dtmf_tone_type", "emergency_tone", "call_auto_retry", "hearing_aid", "tty_mode", "sound_effects_enabled", "haptic_feedback_enabled", "power_sounds_enabled", "dock_sounds_enabled", "lockscreen_sounds_enabled", "show_web_suggestions", "notification_light_pulse", "sip_call_options", "sip_receive_calls"];
c$.ADB_ENABLED = c$.prototype.ADB_ENABLED = "adb_enabled";
c$.ANDROID_ID = c$.prototype.ANDROID_ID = "android_id";
c$.BLUETOOTH_ON = c$.prototype.BLUETOOTH_ON = "bluetooth_on";
c$.DATA_ROAMING = c$.prototype.DATA_ROAMING = "data_roaming";
c$.DEVICE_PROVISIONED = c$.prototype.DEVICE_PROVISIONED = "device_provisioned";
c$.HTTP_PROXY = c$.prototype.HTTP_PROXY = "http_proxy";
c$.INSTALL_NON_MARKET_APPS = c$.prototype.INSTALL_NON_MARKET_APPS = "install_non_market_apps";
c$.LOCATION_PROVIDERS_ALLOWED = c$.prototype.LOCATION_PROVIDERS_ALLOWED = "location_providers_allowed";
c$.LOGGING_ID = c$.prototype.LOGGING_ID = "logging_id";
c$.NETWORK_PREFERENCE = c$.prototype.NETWORK_PREFERENCE = "network_preference";
c$.PARENTAL_CONTROL_ENABLED = c$.prototype.PARENTAL_CONTROL_ENABLED = "parental_control_enabled";
c$.PARENTAL_CONTROL_LAST_UPDATE = c$.prototype.PARENTAL_CONTROL_LAST_UPDATE = "parental_control_last_update";
c$.PARENTAL_CONTROL_REDIRECT_URL = c$.prototype.PARENTAL_CONTROL_REDIRECT_URL = "parental_control_redirect_url";
c$.SETTINGS_CLASSNAME = c$.prototype.SETTINGS_CLASSNAME = "settings_classname";
c$.USB_MASS_STORAGE_ENABLED = c$.prototype.USB_MASS_STORAGE_ENABLED = "usb_mass_storage_enabled";
c$.USE_GOOGLE_MAIL = c$.prototype.USE_GOOGLE_MAIL = "use_google_mail";
c$.WIFI_MAX_DHCP_RETRY_COUNT = c$.prototype.WIFI_MAX_DHCP_RETRY_COUNT = "wifi_max_dhcp_retry_count";
c$.WIFI_MOBILE_DATA_TRANSITION_WAKELOCK_TIMEOUT_MS = c$.prototype.WIFI_MOBILE_DATA_TRANSITION_WAKELOCK_TIMEOUT_MS = "wifi_mobile_data_transition_wakelock_timeout_ms";
c$.WIFI_NETWORKS_AVAILABLE_NOTIFICATION_ON = c$.prototype.WIFI_NETWORKS_AVAILABLE_NOTIFICATION_ON = "wifi_networks_available_notification_on";
c$.WIFI_NETWORKS_AVAILABLE_REPEAT_DELAY = c$.prototype.WIFI_NETWORKS_AVAILABLE_REPEAT_DELAY = "wifi_networks_available_repeat_delay";
c$.WIFI_NUM_OPEN_NETWORKS_KEPT = c$.prototype.WIFI_NUM_OPEN_NETWORKS_KEPT = "wifi_num_open_networks_kept";
c$.WIFI_ON = c$.prototype.WIFI_ON = "wifi_on";
c$.WIFI_WATCHDOG_ACCEPTABLE_PACKET_LOSS_PERCENTAGE = c$.prototype.WIFI_WATCHDOG_ACCEPTABLE_PACKET_LOSS_PERCENTAGE = "wifi_watchdog_acceptable_packet_loss_percentage";
c$.WIFI_WATCHDOG_AP_COUNT = c$.prototype.WIFI_WATCHDOG_AP_COUNT = "wifi_watchdog_ap_count";
c$.WIFI_WATCHDOG_BACKGROUND_CHECK_DELAY_MS = c$.prototype.WIFI_WATCHDOG_BACKGROUND_CHECK_DELAY_MS = "wifi_watchdog_background_check_delay_ms";
c$.WIFI_WATCHDOG_BACKGROUND_CHECK_ENABLED = c$.prototype.WIFI_WATCHDOG_BACKGROUND_CHECK_ENABLED = "wifi_watchdog_background_check_enabled";
c$.WIFI_WATCHDOG_BACKGROUND_CHECK_TIMEOUT_MS = c$.prototype.WIFI_WATCHDOG_BACKGROUND_CHECK_TIMEOUT_MS = "wifi_watchdog_background_check_timeout_ms";
c$.WIFI_WATCHDOG_INITIAL_IGNORED_PING_COUNT = c$.prototype.WIFI_WATCHDOG_INITIAL_IGNORED_PING_COUNT = "wifi_watchdog_initial_ignored_ping_count";
c$.WIFI_WATCHDOG_MAX_AP_CHECKS = c$.prototype.WIFI_WATCHDOG_MAX_AP_CHECKS = "wifi_watchdog_max_ap_checks";
c$.WIFI_WATCHDOG_ON = c$.prototype.WIFI_WATCHDOG_ON = "wifi_watchdog_on";
c$.WIFI_WATCHDOG_PING_COUNT = c$.prototype.WIFI_WATCHDOG_PING_COUNT = "wifi_watchdog_ping_count";
c$.WIFI_WATCHDOG_PING_DELAY_MS = c$.prototype.WIFI_WATCHDOG_PING_DELAY_MS = "wifi_watchdog_ping_delay_ms";
c$.WIFI_WATCHDOG_PING_TIMEOUT_MS = c$.prototype.WIFI_WATCHDOG_PING_TIMEOUT_MS = "wifi_watchdog_ping_timeout_ms";
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.Settings, "Secure", android.provider.Settings.NameValueTable);
c$.getString = Clazz.defineMethod (c$, "getString", 
function (a, b) {
if (android.provider.Settings.Secure.sNameValueCache == null) {
($t$ = android.provider.Settings.Secure.sNameValueCache =  new android.provider.Settings.NameValueCache ("sys.settings_secure_version", android.provider.Settings.Secure.CONTENT_URI, "GET_secure"), android.provider.Settings.Secure.prototype.sNameValueCache = android.provider.Settings.Secure.sNameValueCache, $t$);
}return android.provider.Settings.Secure.sNameValueCache.getString (a, b);
}, "android.content.ContentResolver,~S");
c$.putString = Clazz.defineMethod (c$, "putString", 
function (a, b, c) {
return android.provider.Settings.NameValueTable.putString (a, android.provider.Settings.Secure.CONTENT_URI, b, c);
}, "android.content.ContentResolver,~S,~S");
c$.getUriFor = Clazz.defineMethod (c$, "getUriFor", 
function (a) {
return android.provider.Settings.NameValueTable.getUriFor (android.provider.Settings.Secure.CONTENT_URI, a);
}, "~S");
c$.getInt = Clazz.defineMethod (c$, "getInt", 
function (a, b, c) {
var d = android.provider.Settings.Secure.getString (a, b);
try {
return d != null ? Integer.parseInt (d) : c;
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
return c;
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S,~N");
c$.getInt = Clazz.defineMethod (c$, "getInt", 
function (a, b) {
var c = android.provider.Settings.Secure.getString (a, b);
try {
return Integer.parseInt (c);
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
throw  new android.provider.Settings.SettingNotFoundException (b);
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S");
c$.putInt = Clazz.defineMethod (c$, "putInt", 
function (a, b, c) {
return android.provider.Settings.Secure.putString (a, b, Integer.toString (c));
}, "android.content.ContentResolver,~S,~N");
c$.getLong = Clazz.defineMethod (c$, "getLong", 
function (a, b, c) {
var d = android.provider.Settings.Secure.getString (a, b);
var e;
try {
e = d != null ? Long.parseLong (d) : c;
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
e = c;
} else {
throw e;
}
}
return e;
}, "android.content.ContentResolver,~S,~N");
c$.getLong = Clazz.defineMethod (c$, "getLong", 
function (a, b) {
var c = android.provider.Settings.Secure.getString (a, b);
try {
return Long.parseLong (c);
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
throw  new android.provider.Settings.SettingNotFoundException (b);
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S");
c$.putLong = Clazz.defineMethod (c$, "putLong", 
function (a, b, c) {
return android.provider.Settings.Secure.putString (a, b, Long.toString (c));
}, "android.content.ContentResolver,~S,~N");
c$.getFloat = Clazz.defineMethod (c$, "getFloat", 
function (a, b, c) {
var d = android.provider.Settings.Secure.getString (a, b);
try {
return d != null ? Float.parseFloat (d) : c;
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
return c;
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S,~N");
c$.getFloat = Clazz.defineMethod (c$, "getFloat", 
function (a, b) {
var c = android.provider.Settings.Secure.getString (a, b);
try {
return Float.parseFloat (c);
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
throw  new android.provider.Settings.SettingNotFoundException (b);
} else {
throw e;
}
}
}, "android.content.ContentResolver,~S");
c$.putFloat = Clazz.defineMethod (c$, "putFloat", 
function (a, b, c) {
return android.provider.Settings.Secure.putString (a, b, Float.toString (c));
}, "android.content.ContentResolver,~S,~N");
c$.getBluetoothHeadsetPriorityKey = Clazz.defineMethod (c$, "getBluetoothHeadsetPriorityKey", 
function (a) {
return ("bluetooth_headset_priority_" + a.toUpperCase ());
}, "~S");
c$.getBluetoothA2dpSinkPriorityKey = Clazz.defineMethod (c$, "getBluetoothA2dpSinkPriorityKey", 
function (a) {
return ("bluetooth_a2dp_sink_priority_" + a.toUpperCase ());
}, "~S");
c$.setLocationProviderEnabled = Clazz.defineMethod (c$, "setLocationProviderEnabled", 
function (a, b, c) {
if (c) {
b = "+" + b;
} else {
b = "-" + b;
}android.provider.Settings.Secure.putString (a, "location_providers_allowed", b);
}, "android.content.ContentResolver,~S,~B");
Clazz.defineStatics (c$,
"SYS_PROP_SETTING_VERSION", "sys.settings_secure_version",
"sNameValueCache", null);
c$.CONTENT_URI = c$.prototype.CONTENT_URI = android.net.Uri.parse ("content://settings/secure");
Clazz.defineStatics (c$,
"ADB_ENABLED", "adb_enabled",
"ALLOW_MOCK_LOCATION", "mock_location",
"ANDROID_ID", "android_id",
"BLUETOOTH_ON", "bluetooth_on",
"DATA_ROAMING", "data_roaming",
"DEFAULT_INPUT_METHOD", "default_input_method",
"DEVICE_PROVISIONED", "device_provisioned",
"ENABLED_INPUT_METHODS", "enabled_input_methods",
"DISABLED_SYSTEM_INPUT_METHODS", "disabled_system_input_methods",
"HTTP_PROXY", "http_proxy",
"INSTALL_NON_MARKET_APPS", "install_non_market_apps",
"LOCATION_PROVIDERS_ALLOWED", "location_providers_allowed",
"LOCK_PATTERN_ENABLED", "lock_pattern_autolock",
"LOCK_PATTERN_VISIBLE", "lock_pattern_visible_pattern",
"LOCK_PATTERN_TACTILE_FEEDBACK_ENABLED", "lock_pattern_tactile_feedback_enabled",
"ASSISTED_GPS_ENABLED", "assisted_gps_enabled",
"LOGGING_ID", "logging_id",
"NETWORK_PREFERENCE", "network_preference",
"TETHER_SUPPORTED", "tether_supported",
"TETHER_DUN_REQUIRED", "tether_dun_required",
"TETHER_DUN_APN", "tether_dun_apn",
"PARENTAL_CONTROL_ENABLED", "parental_control_enabled",
"PARENTAL_CONTROL_LAST_UPDATE", "parental_control_last_update",
"PARENTAL_CONTROL_REDIRECT_URL", "parental_control_redirect_url",
"SETTINGS_CLASSNAME", "settings_classname",
"USB_MASS_STORAGE_ENABLED", "usb_mass_storage_enabled",
"USE_GOOGLE_MAIL", "use_google_mail",
"ACCESSIBILITY_ENABLED", "accessibility_enabled",
"ENABLED_ACCESSIBILITY_SERVICES", "enabled_accessibility_services",
"TTS_USE_DEFAULTS", "tts_use_defaults",
"TTS_DEFAULT_RATE", "tts_default_rate",
"TTS_DEFAULT_PITCH", "tts_default_pitch",
"TTS_DEFAULT_SYNTH", "tts_default_synth",
"TTS_DEFAULT_LANG", "tts_default_lang",
"TTS_DEFAULT_COUNTRY", "tts_default_country",
"TTS_DEFAULT_VARIANT", "tts_default_variant",
"TTS_ENABLED_PLUGINS", "tts_enabled_plugins",
"WIFI_NETWORKS_AVAILABLE_NOTIFICATION_ON", "wifi_networks_available_notification_on",
"WIFI_NETWORKS_AVAILABLE_REPEAT_DELAY", "wifi_networks_available_repeat_delay",
"WIMAX_NETWORKS_AVAILABLE_NOTIFICATION_ON", "wimax_networks_available_notification_on",
"WIFI_NUM_ALLOWED_CHANNELS", "wifi_num_allowed_channels",
"WIFI_NUM_OPEN_NETWORKS_KEPT", "wifi_num_open_networks_kept",
"WIFI_ON", "wifi_on",
"WIFI_SAVED_STATE", "wifi_saved_state",
"WIFI_AP_SSID", "wifi_ap_ssid",
"WIFI_AP_SECURITY", "wifi_ap_security",
"WIFI_AP_PASSWD", "wifi_ap_passwd",
"WIFI_WATCHDOG_ACCEPTABLE_PACKET_LOSS_PERCENTAGE", "wifi_watchdog_acceptable_packet_loss_percentage",
"WIFI_WATCHDOG_AP_COUNT", "wifi_watchdog_ap_count",
"WIFI_WATCHDOG_BACKGROUND_CHECK_DELAY_MS", "wifi_watchdog_background_check_delay_ms",
"WIFI_WATCHDOG_BACKGROUND_CHECK_ENABLED", "wifi_watchdog_background_check_enabled",
"WIFI_WATCHDOG_BACKGROUND_CHECK_TIMEOUT_MS", "wifi_watchdog_background_check_timeout_ms",
"WIFI_WATCHDOG_INITIAL_IGNORED_PING_COUNT", "wifi_watchdog_initial_ignored_ping_count",
"WIFI_WATCHDOG_MAX_AP_CHECKS", "wifi_watchdog_max_ap_checks",
"WIFI_WATCHDOG_ON", "wifi_watchdog_on",
"WIFI_WATCHDOG_WATCH_LIST", "wifi_watchdog_watch_list",
"WIFI_WATCHDOG_PING_COUNT", "wifi_watchdog_ping_count",
"WIFI_WATCHDOG_PING_DELAY_MS", "wifi_watchdog_ping_delay_ms",
"WIFI_WATCHDOG_PING_TIMEOUT_MS", "wifi_watchdog_ping_timeout_ms",
"WIFI_MAX_DHCP_RETRY_COUNT", "wifi_max_dhcp_retry_count",
"WIFI_MOBILE_DATA_TRANSITION_WAKELOCK_TIMEOUT_MS", "wifi_mobile_data_transition_wakelock_timeout_ms",
"WIMAX_ON", "wimax_on",
"BACKGROUND_DATA", "background_data",
"ALLOWED_GEOLOCATION_ORIGINS", "allowed_geolocation_origins",
"MOBILE_DATA", "mobile_data",
"CDMA_ROAMING_MODE", "roaming_settings",
"CDMA_SUBSCRIPTION_MODE", "subscription_mode",
"PREFERRED_NETWORK_MODE", "preferred_network_mode",
"PREFERRED_TTY_MODE", "preferred_tty_mode",
"CDMA_CELL_BROADCAST_SMS", "cdma_cell_broadcast_sms",
"PREFERRED_CDMA_SUBSCRIPTION", "preferred_cdma_subscription",
"ENHANCED_VOICE_PRIVACY_ENABLED", "enhanced_voice_privacy_enabled",
"TTY_MODE_ENABLED", "tty_mode_enabled",
"BACKUP_ENABLED", "backup_enabled",
"BACKUP_AUTO_RESTORE", "backup_auto_restore",
"BACKUP_PROVISIONED", "backup_provisioned",
"BACKUP_TRANSPORT", "backup_transport",
"LAST_SETUP_SHOWN", "last_setup_shown",
"MEMCHECK_INTERVAL", "memcheck_interval",
"MEMCHECK_LOG_REALTIME_INTERVAL", "memcheck_log_realtime_interval",
"MEMCHECK_SYSTEM_ENABLED", "memcheck_system_enabled",
"MEMCHECK_SYSTEM_SOFT_THRESHOLD", "memcheck_system_soft",
"MEMCHECK_SYSTEM_HARD_THRESHOLD", "memcheck_system_hard",
"MEMCHECK_PHONE_SOFT_THRESHOLD", "memcheck_phone_soft",
"MEMCHECK_PHONE_HARD_THRESHOLD", "memcheck_phone_hard",
"MEMCHECK_PHONE_ENABLED", "memcheck_phone_enabled",
"MEMCHECK_EXEC_START_TIME", "memcheck_exec_start_time",
"MEMCHECK_EXEC_END_TIME", "memcheck_exec_end_time",
"MEMCHECK_MIN_SCREEN_OFF", "memcheck_min_screen_off",
"MEMCHECK_MIN_ALARM", "memcheck_min_alarm",
"MEMCHECK_RECHECK_INTERVAL", "memcheck_recheck_interval",
"REBOOT_INTERVAL", "reboot_interval",
"REBOOT_START_TIME", "reboot_start_time",
"REBOOT_WINDOW", "reboot_window",
"BATTERY_DISCHARGE_DURATION_THRESHOLD", "battery_discharge_duration_threshold",
"BATTERY_DISCHARGE_THRESHOLD", "battery_discharge_threshold",
"SEND_ACTION_APP_ERROR", "send_action_app_error",
"WTF_IS_FATAL", "wtf_is_fatal",
"DROPBOX_AGE_SECONDS", "dropbox_age_seconds",
"DROPBOX_MAX_FILES", "dropbox_max_files",
"DROPBOX_QUOTA_KB", "dropbox_quota_kb",
"DROPBOX_QUOTA_PERCENT", "dropbox_quota_percent",
"DROPBOX_RESERVE_PERCENT", "dropbox_reserve_percent",
"DROPBOX_TAG_PREFIX", "dropbox:",
"ERROR_LOGCAT_PREFIX", "logcat_for_",
"SHORT_KEYLIGHT_DELAY_MS", "short_keylight_delay_ms",
"SYS_FREE_STORAGE_LOG_INTERVAL", "sys_free_storage_log_interval",
"DISK_FREE_CHANGE_REPORTING_THRESHOLD", "disk_free_change_reporting_threshold",
"SYS_STORAGE_THRESHOLD_PERCENTAGE", "sys_storage_threshold_percentage",
"SYS_STORAGE_FULL_THRESHOLD_BYTES", "sys_storage_full_threshold_bytes",
"WIFI_IDLE_MS", "wifi_idle_ms",
"PDP_WATCHDOG_POLL_INTERVAL_MS", "pdp_watchdog_poll_interval_ms",
"PDP_WATCHDOG_LONG_POLL_INTERVAL_MS", "pdp_watchdog_long_poll_interval_ms",
"PDP_WATCHDOG_ERROR_POLL_INTERVAL_MS", "pdp_watchdog_error_poll_interval_ms",
"PDP_WATCHDOG_TRIGGER_PACKET_COUNT", "pdp_watchdog_trigger_packet_count",
"PDP_WATCHDOG_ERROR_POLL_COUNT", "pdp_watchdog_error_poll_count",
"PDP_WATCHDOG_MAX_PDP_RESET_FAIL_COUNT", "pdp_watchdog_max_pdp_reset_fail_count",
"PDP_WATCHDOG_PING_ADDRESS", "pdp_watchdog_ping_address",
"PDP_WATCHDOG_PING_DEADLINE", "pdp_watchdog_ping_deadline",
"GPRS_REGISTER_CHECK_PERIOD_MS", "gprs_register_check_period_ms",
"NITZ_UPDATE_SPACING", "nitz_update_spacing",
"NITZ_UPDATE_DIFF", "nitz_update_diff",
"SYNC_MAX_RETRY_DELAY_IN_SECONDS", "sync_max_retry_delay_in_seconds",
"SMS_OUTGOING_CHECK_INTERVAL_MS", "sms_outgoing_check_interval_ms",
"SMS_OUTGOING_CHECK_MAX_COUNT", "sms_outgoing_check_max_count",
"SEARCH_NUM_PROMOTED_SOURCES", "search_num_promoted_sources",
"SEARCH_MAX_RESULTS_TO_DISPLAY", "search_max_results_to_display",
"SEARCH_MAX_RESULTS_PER_SOURCE", "search_max_results_per_source",
"SEARCH_WEB_RESULTS_OVERRIDE_LIMIT", "search_web_results_override_limit",
"SEARCH_PROMOTED_SOURCE_DEADLINE_MILLIS", "search_promoted_source_deadline_millis",
"SEARCH_SOURCE_TIMEOUT_MILLIS", "search_source_timeout_millis",
"SEARCH_PREFILL_MILLIS", "search_prefill_millis",
"SEARCH_MAX_STAT_AGE_MILLIS", "search_max_stat_age_millis",
"SEARCH_MAX_SOURCE_EVENT_AGE_MILLIS", "search_max_source_event_age_millis",
"SEARCH_MIN_IMPRESSIONS_FOR_SOURCE_RANKING", "search_min_impressions_for_source_ranking",
"SEARCH_MIN_CLICKS_FOR_SOURCE_RANKING", "search_min_clicks_for_source_ranking",
"SEARCH_MAX_SHORTCUTS_RETURNED", "search_max_shortcuts_returned",
"SEARCH_QUERY_THREAD_CORE_POOL_SIZE", "search_query_thread_core_pool_size",
"SEARCH_QUERY_THREAD_MAX_POOL_SIZE", "search_query_thread_max_pool_size",
"SEARCH_SHORTCUT_REFRESH_CORE_POOL_SIZE", "search_shortcut_refresh_core_pool_size",
"SEARCH_SHORTCUT_REFRESH_MAX_POOL_SIZE", "search_shortcut_refresh_max_pool_size",
"SEARCH_THREAD_KEEPALIVE_SECONDS", "search_thread_keepalive_seconds",
"SEARCH_PER_SOURCE_CONCURRENT_QUERY_LIMIT", "search_per_source_concurrent_query_limit",
"MOUNT_PLAY_NOTIFICATION_SND", "mount_play_not_snd",
"MOUNT_UMS_AUTOSTART", "mount_ums_autostart",
"MOUNT_UMS_PROMPT", "mount_ums_prompt",
"MOUNT_UMS_NOTIFY_ENABLED", "mount_ums_notify_enabled",
"ANR_SHOW_BACKGROUND", "anr_show_background",
"VOICE_RECOGNITION_SERVICE", "voice_recognition_service",
"INCALL_POWER_BUTTON_BEHAVIOR", "incall_power_button_behavior",
"INCALL_POWER_BUTTON_BEHAVIOR_SCREEN_OFF", 0x1,
"INCALL_POWER_BUTTON_BEHAVIOR_HANGUP", 0x2,
"INCALL_POWER_BUTTON_BEHAVIOR_DEFAULT", 1,
"UI_NIGHT_MODE", "ui_night_mode",
"SET_INSTALL_LOCATION", "set_install_location",
"DEFAULT_INSTALL_LOCATION", "default_install_location",
"THROTTLE_POLLING_SEC", "throttle_polling_sec",
"THROTTLE_THRESHOLD_BYTES", "throttle_threshold_bytes",
"THROTTLE_VALUE_KBITSPS", "throttle_value_kbitsps",
"THROTTLE_RESET_DAY", "throttle_reset_day",
"THROTTLE_NOTIFICATION_TYPE", "throttle_notification_type",
"THROTTLE_HELP_URI", "throttle_help_uri",
"THROTTLE_MAX_NTP_CACHE_AGE_SEC", "throttle_max_ntp_cache_age_sec",
"DOWNLOAD_MAX_BYTES_OVER_MOBILE", "download_manager_max_bytes_over_mobile",
"DOWNLOAD_RECOMMENDED_MAX_BYTES_OVER_MOBILE", "download_manager_recommended_max_bytes_over_mobile",
"INET_CONDITION_DEBOUNCE_UP_DELAY", "inet_condition_debounce_up_delay",
"INET_CONDITION_DEBOUNCE_DOWN_DELAY", "inet_condition_debounce_down_delay");
c$.SETTINGS_TO_BACKUP = c$.prototype.SETTINGS_TO_BACKUP = ["adb_enabled", "mock_location", "parental_control_enabled", "parental_control_redirect_url", "usb_mass_storage_enabled", "accessibility_enabled", "backup_auto_restore", "enabled_accessibility_services", "tts_use_defaults", "tts_default_rate", "tts_default_pitch", "tts_default_synth", "tts_default_lang", "tts_default_country", "tts_enabled_plugins", "wifi_networks_available_notification_on", "wifi_networks_available_repeat_delay", "wifi_num_allowed_channels", "wifi_num_open_networks_kept", "mount_play_not_snd", "mount_ums_autostart", "mount_ums_prompt", "mount_ums_notify_enabled", "ui_night_mode"];
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.provider.Settings, "Bookmarks", null, android.provider.BaseColumns);
c$.getLabelForFolder = Clazz.defineMethod (c$, "getLabelForFolder", 
function (a, b) {
return b;
}, "android.content.res.Resources,~S");
c$.getTitle = Clazz.defineMethod (c$, "getTitle", 
function (a, b) {
var c = b.getColumnIndex ("title");
var d = b.getColumnIndex ("intent");
if (c == -1 || d == -1) {
throw  new IllegalArgumentException ("The cursor must contain the TITLE and INTENT columns.");
}var e = b.getString (c);
if (!android.text.TextUtils.isEmpty (e)) {
return e;
}var f = b.getString (d);
if (android.text.TextUtils.isEmpty (f)) {
return "";
}var g;
g = android.content.Intent.parseUri (f, 0);
var h = a.getPackageManager ();
var i = h.resolveActivity (g, 0);
return i != null ? i.loadLabel (h) : "";
}, "android.content.Context,android.database.Cursor");
Clazz.defineStatics (c$,
"TAG", "Bookmarks");
c$.CONTENT_URI = c$.prototype.CONTENT_URI = android.net.Uri.parse ("content://settings/bookmarks");
Clazz.defineStatics (c$,
"ID", "_id",
"TITLE", "title",
"FOLDER", "folder",
"INTENT", "intent",
"SHORTCUT", "shortcut",
"ORDERING", "ordering");
c$.sIntentProjection = c$.prototype.sIntentProjection = ["intent"];
c$.sShortcutProjection = c$.prototype.sShortcutProjection = ["_id", "shortcut"];
c$.sShortcutSelection = c$.prototype.sShortcutSelection = "shortcut=?";
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"ACTION_SETTINGS", "android.settings.SETTINGS",
"ACTION_APN_SETTINGS", "android.settings.APN_SETTINGS",
"ACTION_LOCATION_SOURCE_SETTINGS", "android.settings.LOCATION_SOURCE_SETTINGS",
"ACTION_WIRELESS_SETTINGS", "android.settings.WIRELESS_SETTINGS",
"ACTION_AIRPLANE_MODE_SETTINGS", "android.settings.AIRPLANE_MODE_SETTINGS",
"ACTION_ACCESSIBILITY_SETTINGS", "android.settings.ACCESSIBILITY_SETTINGS",
"ACTION_SECURITY_SETTINGS", "android.settings.SECURITY_SETTINGS",
"ACTION_PRIVACY_SETTINGS", "android.settings.PRIVACY_SETTINGS",
"ACTION_WIFI_SETTINGS", "android.settings.WIFI_SETTINGS",
"ACTION_WIFI_IP_SETTINGS", "android.settings.WIFI_IP_SETTINGS",
"ACTION_BLUETOOTH_SETTINGS", "android.settings.BLUETOOTH_SETTINGS",
"ACTION_DATE_SETTINGS", "android.settings.DATE_SETTINGS",
"ACTION_SOUND_SETTINGS", "android.settings.SOUND_SETTINGS",
"ACTION_DISPLAY_SETTINGS", "android.settings.DISPLAY_SETTINGS",
"ACTION_LOCALE_SETTINGS", "android.settings.LOCALE_SETTINGS",
"ACTION_INPUT_METHOD_SETTINGS", "android.settings.INPUT_METHOD_SETTINGS",
"ACTION_USER_DICTIONARY_SETTINGS", "android.settings.USER_DICTIONARY_SETTINGS",
"ACTION_APPLICATION_SETTINGS", "android.settings.APPLICATION_SETTINGS",
"ACTION_APPLICATION_DEVELOPMENT_SETTINGS", "android.settings.APPLICATION_DEVELOPMENT_SETTINGS",
"ACTION_QUICK_LAUNCH_SETTINGS", "android.settings.QUICK_LAUNCH_SETTINGS",
"ACTION_MANAGE_APPLICATIONS_SETTINGS", "android.settings.MANAGE_APPLICATIONS_SETTINGS",
"ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS", "android.settings.MANAGE_ALL_APPLICATIONS_SETTINGS",
"ACTION_APPLICATION_DETAILS_SETTINGS", "android.settings.APPLICATION_DETAILS_SETTINGS",
"ACTION_SYSTEM_UPDATE_SETTINGS", "android.settings.SYSTEM_UPDATE_SETTINGS",
"ACTION_SYNC_SETTINGS", "android.settings.SYNC_SETTINGS",
"ACTION_ADD_ACCOUNT", "android.settings.ADD_ACCOUNT_SETTINGS",
"ACTION_NETWORK_OPERATOR_SETTINGS", "android.settings.NETWORK_OPERATOR_SETTINGS",
"ACTION_DATA_ROAMING_SETTINGS", "android.settings.DATA_ROAMING_SETTINGS",
"ACTION_INTERNAL_STORAGE_SETTINGS", "android.settings.INTERNAL_STORAGE_SETTINGS",
"ACTION_MEMORY_CARD_SETTINGS", "android.settings.MEMORY_CARD_SETTINGS",
"ACTION_SEARCH_SETTINGS", "android.search.action.SEARCH_SETTINGS",
"ACTION_DEVICE_INFO_SETTINGS", "android.settings.DEVICE_INFO_SETTINGS",
"CALL_METHOD_GET_SYSTEM", "GET_system",
"CALL_METHOD_GET_SECURE", "GET_secure",
"EXTRA_AUTHORITIES", "authorities",
"JID_RESOURCE_PREFIX", "android",
"AUTHORITY", "settings",
"TAG", "Settings",
"LOCAL_LOGV", false);
});
