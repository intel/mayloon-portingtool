﻿Clazz.declarePackage ("android.util");
c$ = Clazz.declareType (android.util, "FloatMath");
c$.floor = Clazz.defineMethod (c$, "floor", 
function (value) {
return Math.floor (value);
}, "~N");
c$.ceil = Clazz.defineMethod (c$, "ceil", 
function (value) {
return Math.ceil (value);
}, "~N");
c$.sin = Clazz.defineMethod (c$, "sin", 
function (angle) {
return Math.sin (angle);
}, "~N");
c$.cos = Clazz.defineMethod (c$, "cos", 
function (angle) {
return Math.cos (angle);
}, "~N");
c$.sqrt = Clazz.defineMethod (c$, "sqrt", 
function (value) {
return Math.sqrt (value);
}, "~N");
