﻿Clazz.declarePackage ("android.util");
Clazz.load (["java.lang.RuntimeException"], "android.util.ActivityNotFoundException", null, function () {
c$ = Clazz.declareType (android.util, "ActivityNotFoundException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.util.ActivityNotFoundException, []);
});
});
