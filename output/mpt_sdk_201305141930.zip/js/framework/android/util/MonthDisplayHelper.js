﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.MonthDisplayHelper", ["java.lang.IllegalArgumentException", "java.util.Calendar"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mWeekStartDay = 0;
this.mCalendar = null;
this.mNumDaysInMonth = 0;
this.mNumDaysInPrevMonth = 0;
this.mOffset = 0;
Clazz.instantialize (this, arguments);
}, android.util, "MonthDisplayHelper");
Clazz.makeConstructor (c$, 
function (year, month, weekStartDay) {
if (weekStartDay < 1 || weekStartDay > 7) {
throw  new IllegalArgumentException ();
}this.mWeekStartDay = weekStartDay;
this.mCalendar = java.util.Calendar.getInstance ();
this.mCalendar.set (1, year);
this.mCalendar.set (2, month);
this.mCalendar.set (5, 1);
this.mCalendar.set (11, 0);
this.mCalendar.set (12, 0);
this.mCalendar.set (13, 0);
this.mCalendar.getTimeInMillis ();
this.recalculate ();
}, "~N,~N,~N");
Clazz.makeConstructor (c$, 
function (year, month) {
this.construct (year, month, 1);
}, "~N,~N");
Clazz.defineMethod (c$, "getYear", 
function () {
return this.mCalendar.get (1);
});
Clazz.defineMethod (c$, "getMonth", 
function () {
return this.mCalendar.get (2);
});
Clazz.defineMethod (c$, "getWeekStartDay", 
function () {
return this.mWeekStartDay;
});
Clazz.defineMethod (c$, "getFirstDayOfMonth", 
function () {
return this.mCalendar.get (7);
});
Clazz.defineMethod (c$, "getNumberOfDaysInMonth", 
function () {
return this.mNumDaysInMonth;
});
Clazz.defineMethod (c$, "getOffset", 
function () {
return this.mOffset;
});
Clazz.defineMethod (c$, "getDigitsForRow", 
function (row) {
if (row < 0 || row > 5) {
throw  new IllegalArgumentException ("row " + row + " out of range (0-5)");
}var result =  Clazz.newArray (7, 0);
for (var column = 0; column < 7; column++) {
result[column] = this.getDayAt (row, column);
}
return result;
}, "~N");
Clazz.defineMethod (c$, "getDayAt", 
function (row, column) {
if (row == 0 && column < this.mOffset) {
return this.mNumDaysInPrevMonth + column - this.mOffset + 1;
}var day = 7 * row + column - this.mOffset + 1;
return (day > this.mNumDaysInMonth) ? day - this.mNumDaysInMonth : day;
}, "~N,~N");
Clazz.defineMethod (c$, "getRowOf", 
function (day) {
return Math.floor ((day + this.mOffset - 1) / 7);
}, "~N");
Clazz.defineMethod (c$, "getColumnOf", 
function (day) {
return (day + this.mOffset - 1) % 7;
}, "~N");
Clazz.defineMethod (c$, "previousMonth", 
function () {
this.mCalendar.add (2, -1);
this.recalculate ();
});
Clazz.defineMethod (c$, "nextMonth", 
function () {
this.mCalendar.add (2, 1);
this.recalculate ();
});
Clazz.defineMethod (c$, "isWithinCurrentMonth", 
function (row, column) {
if (row < 0 || column < 0 || row > 5 || column > 6) {
return false;
}if (row == 0 && column < this.mOffset) {
return false;
}var day = 7 * row + column - this.mOffset + 1;
if (day > this.mNumDaysInMonth) {
return false;
}return true;
}, "~N,~N");
Clazz.defineMethod (c$, "recalculate", 
($fz = function () {
this.mNumDaysInMonth = this.mCalendar.getActualMaximum (5);
this.mCalendar.add (2, -1);
this.mNumDaysInPrevMonth = this.mCalendar.getActualMaximum (5);
this.mCalendar.add (2, 1);
var firstDayOfMonth = this.getFirstDayOfMonth ();
var offset = firstDayOfMonth - this.mWeekStartDay;
if (offset < 0) {
offset += 7;
}this.mOffset = offset;
}, $fz.isPrivate = true, $fz));
});
