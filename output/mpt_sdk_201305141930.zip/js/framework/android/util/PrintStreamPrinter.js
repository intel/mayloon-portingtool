﻿Clazz.declarePackage ("android.util");
Clazz.load (["android.util.Printer"], "android.util.PrintStreamPrinter", null, function () {
c$ = Clazz.declareType (android.util, "PrintStreamPrinter", null, android.util.Printer);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.overrideMethod (c$, "println", 
function (x) {
System.out.println (x);
}, "~S");
});
