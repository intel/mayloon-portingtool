﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.CharsetUtils", ["java.nio.charset.Charset"], function () {
c$ = Clazz.declareType (android.util, "CharsetUtils");
c$.nameForVendor = Clazz.defineMethod (c$, "nameForVendor", 
function (charsetName, vendor) {
if (vendor.equalsIgnoreCase ("docomo") && android.util.CharsetUtils.isShiftJis (charsetName)) {
return "docomo-shift_jis-2007";
}return charsetName;
}, "~S,~S");
c$.nameForDefaultVendor = Clazz.defineMethod (c$, "nameForDefaultVendor", 
function (charsetName) {
return android.util.CharsetUtils.nameForVendor (charsetName, android.util.CharsetUtils.getDefaultVendor ());
}, "~S");
c$.charsetForVendor = Clazz.defineMethod (c$, "charsetForVendor", 
function (charsetName, vendor) {
charsetName = android.util.CharsetUtils.nameForVendor (charsetName, vendor);
return java.nio.charset.Charset.forName (charsetName);
}, "~S,~S");
c$.charsetForVendor = Clazz.defineMethod (c$, "charsetForVendor", 
function (charsetName) {
return android.util.CharsetUtils.charsetForVendor (charsetName, android.util.CharsetUtils.getDefaultVendor ());
}, "~S");
c$.isShiftJis = Clazz.defineMethod (c$, "isShiftJis", 
($fz = function (charsetName) {
if (charsetName == null) {
return false;
}var length = charsetName.length;
if (length != 4 && length != 9) {
return false;
}return charsetName.equalsIgnoreCase ("shift_jis") || charsetName.equalsIgnoreCase ("shift-jis") || charsetName.equalsIgnoreCase ("sjis");
}, $fz.isPrivate = true, $fz), "~S");
c$.getDefaultVendor = Clazz.defineMethod (c$, "getDefaultVendor", 
($fz = function () {
return null;
}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"VENDOR_DOCOMO", "docomo");
});
