﻿Clazz.declarePackage ("android.util");
Clazz.load (["android.util.Pool"], "android.util.FinitePool", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mManager = null;
this.mLimit = 0;
this.mInfinite = false;
this.mRoot = null;
this.mPoolCount = 0;
Clazz.instantialize (this, arguments);
}, android.util, "FinitePool", null, android.util.Pool);
Clazz.makeConstructor (c$, 
function (manager) {
this.mManager = manager;
this.mLimit = 0;
this.mInfinite = true;
}, "android.util.PoolableManager");
Clazz.makeConstructor (c$, 
function (manager, limit) {
if (limit <= 0) throw  new IllegalArgumentException ("The pool limit must be > 0");
this.mManager = manager;
this.mLimit = limit;
this.mInfinite = false;
}, "android.util.PoolableManager,~N");
Clazz.overrideMethod (c$, "acquire", 
function () {
var element;
if (this.mRoot != null) {
element = this.mRoot;
this.mRoot = element.getNextPoolable ();
this.mPoolCount--;
} else {
element = this.mManager.newInstance ();
}if (element != null) {
element.setNextPoolable (null);
this.mManager.onAcquired (element);
}return element;
});
Clazz.overrideMethod (c$, "release", 
function (element) {
if (this.mInfinite || this.mPoolCount < this.mLimit) {
this.mPoolCount++;
element.setNextPoolable (this.mRoot);
this.mRoot = element;
}this.mManager.onReleased (element);
}, "~O");
});
