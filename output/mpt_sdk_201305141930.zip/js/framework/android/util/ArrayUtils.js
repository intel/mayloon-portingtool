﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.ArrayUtils", ["java.lang.reflect.Array"], function () {
c$ = Clazz.declareType (android.util, "ArrayUtils");
c$.idealByteArraySize = Clazz.defineMethod (c$, "idealByteArraySize", 
function (need) {
for (var i = 4; i < 32; i++) if (need <= (1 << i) - 12) return (1 << i) - 12;

return need;
}, "~N");
c$.idealBooleanArraySize = Clazz.defineMethod (c$, "idealBooleanArraySize", 
function (need) {
return android.util.ArrayUtils.idealByteArraySize (need);
}, "~N");
c$.idealShortArraySize = Clazz.defineMethod (c$, "idealShortArraySize", 
function (need) {
return Math.floor (android.util.ArrayUtils.idealByteArraySize (need * 2) / 2);
}, "~N");
c$.idealCharArraySize = Clazz.defineMethod (c$, "idealCharArraySize", 
function (need) {
return Math.floor (android.util.ArrayUtils.idealByteArraySize (need * 2) / 2);
}, "~N");
c$.idealIntArraySize = Clazz.defineMethod (c$, "idealIntArraySize", 
function (need) {
return Math.floor (android.util.ArrayUtils.idealByteArraySize (need * 4) / 4);
}, "~N");
c$.idealFloatArraySize = Clazz.defineMethod (c$, "idealFloatArraySize", 
function (need) {
return Math.floor (android.util.ArrayUtils.idealByteArraySize (need * 4) / 4);
}, "~N");
c$.idealObjectArraySize = Clazz.defineMethod (c$, "idealObjectArraySize", 
function (need) {
return Math.floor (android.util.ArrayUtils.idealByteArraySize (need * 4) / 4);
}, "~N");
c$.idealLongArraySize = Clazz.defineMethod (c$, "idealLongArraySize", 
function (need) {
return Math.floor (android.util.ArrayUtils.idealByteArraySize (need * 8) / 8);
}, "~N");
c$.equals = Clazz.defineMethod (c$, "equals", 
function (array1, array2, length) {
if (array1 === array2) {
return true;
}if (array1 == null || array2 == null || array1.length < length || array2.length < length) {
return false;
}for (var i = 0; i < length; i++) {
if (array1[i] != array2[i]) {
return false;
}}
return true;
}, "~A,~A,~N");
c$.emptyArray = Clazz.defineMethod (c$, "emptyArray", 
function (kind) {
if (kind === JavaObject) {
return android.util.ArrayUtils.EMPTY;
}var bucket = 32;
var cache = android.util.ArrayUtils.sCache[bucket];
if (cache == null || cache.getClass ().getComponentType () !== kind) {
cache = java.lang.reflect.Array.newInstance (kind, 0);
android.util.ArrayUtils.sCache[bucket] = cache;
}return cache;
}, "Class");
c$.contains = Clazz.defineMethod (c$, "contains", 
function (array, value) {
for (var element, $element = 0, $$element = array; $element < $$element.length && ((element = $$element[$element]) || true); $element++) {
if (element == null) {
if (value == null) return true;
} else {
if (value != null && element.equals (value)) return true;
}}
return false;
}, "~A,~O");
c$.EMPTY = c$.prototype.EMPTY =  new Array (0);
Clazz.defineStatics (c$,
"CACHE_SIZE", 73);
c$.sCache = c$.prototype.sCache =  new Array (73);
});
