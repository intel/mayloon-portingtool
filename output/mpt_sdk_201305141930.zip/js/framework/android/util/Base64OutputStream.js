﻿Clazz.declarePackage ("android.util");
Clazz.load (["java.io.FilterOutputStream"], "android.util.Base64OutputStream", ["android.util.Base64", "java.io.IOException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.coder = null;
this.flags = 0;
this.buffer = null;
this.bpos = 0;
Clazz.instantialize (this, arguments);
}, android.util, "Base64OutputStream", java.io.FilterOutputStream);
Clazz.makeConstructor (c$, 
function (out, flags) {
this.construct (out, flags, true);
}, "java.io.OutputStream,~N");
Clazz.makeConstructor (c$, 
function (out, flags, encode) {
Clazz.superConstructor (this, android.util.Base64OutputStream, [out]);
this.flags = flags;
if (encode) {
this.coder =  new android.util.Base64.Encoder (flags, null);
} else {
this.coder =  new android.util.Base64.Decoder (flags, null);
}}, "java.io.OutputStream,~N,~B");
Clazz.defineMethod (c$, "write", 
function (b) {
if (this.buffer == null) {
this.buffer =  Clazz.newArray (1024, 0);
}if (this.bpos >= this.buffer.length) {
this.internalWrite (this.buffer, 0, this.bpos, false);
this.bpos = 0;
}this.buffer[this.bpos++] = b;
}, "~N");
Clazz.defineMethod (c$, "flushBuffer", 
($fz = function () {
if (this.bpos > 0) {
this.internalWrite (this.buffer, 0, this.bpos, false);
this.bpos = 0;
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "write", 
function (b, off, len) {
if (len <= 0) return ;
this.flushBuffer ();
this.internalWrite (b, off, len, false);
}, "~A,~N,~N");
Clazz.overrideMethod (c$, "close", 
function () {
var thrown = null;
try {
this.flushBuffer ();
this.internalWrite (android.util.Base64OutputStream.EMPTY, 0, 0, true);
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
thrown = e;
} else {
throw e;
}
}
try {
if ((this.flags & 16) == 0) {
this.out.close ();
} else {
this.out.flush ();
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
if (thrown != null) {
thrown = e;
}} else {
throw e;
}
}
if (thrown != null) {
throw thrown;
}});
Clazz.defineMethod (c$, "internalWrite", 
($fz = function (b, off, len, finish) {
this.coder.output = this.embiggen (this.coder.output, this.coder.maxOutputSize (len));
if (!this.coder.process (b, off, len, finish)) {
throw  new java.io.IOException ("bad base-64");
}this.out.write (this.coder.output, 0, this.coder.op);
}, $fz.isPrivate = true, $fz), "~A,~N,~N,~B");
Clazz.defineMethod (c$, "embiggen", 
($fz = function (b, len) {
if (b == null || b.length < len) {
return  Clazz.newArray (len, 0);
} else {
return b;
}}, $fz.isPrivate = true, $fz), "~A,~N");
Clazz.defineStatics (c$,
"EMPTY",  Clazz.newArray (0, 0));
});
