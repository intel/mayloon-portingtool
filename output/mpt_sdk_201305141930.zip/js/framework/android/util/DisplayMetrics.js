﻿Clazz.declarePackage ("android.util");
c$ = Clazz.decorateAsClass (function () {
this.widthPixels = 0;
this.heightPixels = 0;
this.density = 0;
this.densityDpi = 0;
this.scaledDensity = 0;
this.xdpi = 0;
this.ydpi = 0;
Clazz.instantialize (this, arguments);
}, android.util, "DisplayMetrics");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "setTo", 
function (o) {
this.widthPixels = o.widthPixels;
this.heightPixels = o.heightPixels;
this.density = o.density;
this.densityDpi = o.densityDpi;
this.scaledDensity = o.scaledDensity;
this.xdpi = o.xdpi;
this.ydpi = o.ydpi;
}, "android.util.DisplayMetrics");
Clazz.defineMethod (c$, "setToDefaults", 
function () {
this.widthPixels = 0;
this.heightPixels = 0;
this.density = android.util.DisplayMetrics.DENSITY_DEVICE / 160;
this.densityDpi = android.util.DisplayMetrics.DENSITY_DEVICE;
this.scaledDensity = this.density;
this.xdpi = android.util.DisplayMetrics.DENSITY_DEVICE;
this.ydpi = android.util.DisplayMetrics.DENSITY_DEVICE;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return "DisplayMetrics{density=" + this.density + ", width=" + this.widthPixels + ", height=" + this.heightPixels + ", scaledDensity=" + this.scaledDensity + ", xdpi=" + this.xdpi + ", ydpi=" + this.ydpi + "}";
});
c$.getDeviceDensity = Clazz.defineMethod (c$, "getDeviceDensity", 
($fz = function () {
var density = 160;
if (window.innerWidth > 1024) {
density = this.DENSITY_HIGH;
}
return density;
}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"DENSITY_LOW", 120,
"DENSITY_MEDIUM", 160,
"DENSITY_HIGH", 240,
"DENSITY_XHIGH", 320,
"DENSITY_DEFAULT", 160);
c$.DENSITY_DEVICE = c$.prototype.DENSITY_DEVICE = android.util.DisplayMetrics.getDeviceDensity ();
