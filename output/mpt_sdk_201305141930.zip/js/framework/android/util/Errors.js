﻿Clazz.declarePackage ("android.util");
c$ = Clazz.declareType (android.util, "Errors");
Clazz.defineStatics (c$,
"NO_ERROR", 0,
"NO_INIT", -1,
"NAME_NOT_FOUND", -2,
"BAD_TYPE", -3,
"UNKNOWN_ERROR", -4,
"BAD_INDEX", -5,
"NO_MEMORY", -6,
"BAD_VALUE", -7);
