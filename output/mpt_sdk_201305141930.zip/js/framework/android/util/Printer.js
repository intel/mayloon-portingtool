﻿Clazz.declarePackage ("android.util");
Clazz.declareInterface (android.util, "Printer");
