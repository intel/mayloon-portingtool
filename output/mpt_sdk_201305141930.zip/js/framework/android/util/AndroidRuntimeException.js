﻿Clazz.declarePackage ("android.util");
Clazz.load (["java.lang.RuntimeException"], "android.util.AndroidRuntimeException", null, function () {
c$ = Clazz.declareType (android.util, "AndroidRuntimeException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.util.AndroidRuntimeException, []);
});
});
