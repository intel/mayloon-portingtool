﻿Clazz.declarePackage ("android.util");
Clazz.load (["android.util.Printer"], "android.util.StringBuilderPrinter", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mBuilder = null;
Clazz.instantialize (this, arguments);
}, android.util, "StringBuilderPrinter", null, android.util.Printer);
Clazz.makeConstructor (c$, 
function (builder) {
this.mBuilder = builder;
}, "StringBuilder");
Clazz.overrideMethod (c$, "println", 
function (x) {
this.mBuilder.append (x);
var len = x.length;
if (len <= 0 || (x.charAt (len - 1)).charCodeAt (0) != ('\n').charCodeAt (0)) {
this.mBuilder.append ('\n');
}}, "~S");
});
