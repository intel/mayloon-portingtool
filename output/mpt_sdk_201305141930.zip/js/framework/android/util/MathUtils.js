﻿Clazz.declarePackage ("android.util");
Clazz.load (["java.util.Random"], "android.util.MathUtils", null, function () {
c$ = Clazz.declareType (android.util, "MathUtils");
c$.myIntBitsToFloat = Clazz.defineMethod (c$, "myIntBitsToFloat", 
function (bits) {
var s = ((bits >> 31) == 0) ? 1 : -1;
var e = ((bits >> 23) & 0xff);
var m = (e == 0) ? (bits & 0x7fffff) << 1 : (bits & 0x7fffff) | 0x800000;
var ret = s * m;
var times = e - 150;
if (times < 0) for (var i = 0; i < -times; ++i) ret = ret / 2;

 else for (var i = 0; i < times; ++i) ret = ret * 2;

return ret;
}, "~N");
c$.abs = Clazz.defineMethod (c$, "abs", 
function (v) {
return v > 0 ? v : -v;
}, "~N");
c$.constrain = Clazz.defineMethod (c$, "constrain", 
function (amount, low, high) {
return amount < low ? low : (amount > high ? high : amount);
}, "~N,~N,~N");
c$.constrain = Clazz.defineMethod (c$, "constrain", 
function (amount, low, high) {
return amount < low ? low : (amount > high ? high : amount);
}, "~N,~N,~N");
c$.log = Clazz.defineMethod (c$, "log", 
function (a) {
return Math.log (a);
}, "~N");
c$.exp = Clazz.defineMethod (c$, "exp", 
function (a) {
return Math.exp (a);
}, "~N");
c$.pow = Clazz.defineMethod (c$, "pow", 
function (a, b) {
return Math.pow (a, b);
}, "~N,~N");
c$.max = Clazz.defineMethod (c$, "max", 
function (a, b) {
return a > b ? a : b;
}, "~N,~N");
c$.max = Clazz.defineMethod (c$, "max", 
function (a, b) {
return a > b ? a : b;
}, "~N,~N");
c$.max = Clazz.defineMethod (c$, "max", 
function (a, b, c) {
return a > b ? (a > c ? a : c) : (b > c ? b : c);
}, "~N,~N,~N");
c$.max = Clazz.defineMethod (c$, "max", 
function (a, b, c) {
return a > b ? (a > c ? a : c) : (b > c ? b : c);
}, "~N,~N,~N");
c$.min = Clazz.defineMethod (c$, "min", 
function (a, b) {
return a < b ? a : b;
}, "~N,~N");
c$.min = Clazz.defineMethod (c$, "min", 
function (a, b) {
return a < b ? a : b;
}, "~N,~N");
c$.min = Clazz.defineMethod (c$, "min", 
function (a, b, c) {
return a < b ? (a < c ? a : c) : (b < c ? b : c);
}, "~N,~N,~N");
c$.min = Clazz.defineMethod (c$, "min", 
function (a, b, c) {
return a < b ? (a < c ? a : c) : (b < c ? b : c);
}, "~N,~N,~N");
c$.dist = Clazz.defineMethod (c$, "dist", 
function (x1, y1, x2, y2) {
var x = (x2 - x1);
var y = (y2 - y1);
return Math.sqrt (x * x + y * y);
}, "~N,~N,~N,~N");
c$.dist = Clazz.defineMethod (c$, "dist", 
function (x1, y1, z1, x2, y2, z2) {
var x = (x2 - x1);
var y = (y2 - y1);
var z = (z2 - z1);
return Math.sqrt (x * x + y * y + z * z);
}, "~N,~N,~N,~N,~N,~N");
c$.mag = Clazz.defineMethod (c$, "mag", 
function (a, b) {
return Math.sqrt (a * a + b * b);
}, "~N,~N");
c$.mag = Clazz.defineMethod (c$, "mag", 
function (a, b, c) {
return Math.sqrt (a * a + b * b + c * c);
}, "~N,~N,~N");
c$.sq = Clazz.defineMethod (c$, "sq", 
function (v) {
return v * v;
}, "~N");
c$.radians = Clazz.defineMethod (c$, "radians", 
function (degrees) {
return degrees * 0.017453292519943295;
}, "~N");
c$.degrees = Clazz.defineMethod (c$, "degrees", 
function (radians) {
return radians * 57.29577951308232;
}, "~N");
c$.acos = Clazz.defineMethod (c$, "acos", 
function (value) {
return Math.acos (value);
}, "~N");
c$.asin = Clazz.defineMethod (c$, "asin", 
function (value) {
return Math.asin (value);
}, "~N");
c$.atan = Clazz.defineMethod (c$, "atan", 
function (value) {
return Math.atan (value);
}, "~N");
c$.atan2 = Clazz.defineMethod (c$, "atan2", 
function (a, b) {
return Math.atan2 (a, b);
}, "~N,~N");
c$.tan = Clazz.defineMethod (c$, "tan", 
function (angle) {
return Math.tan (angle);
}, "~N");
c$.lerp = Clazz.defineMethod (c$, "lerp", 
function (start, stop, amount) {
return start + (stop - start) * amount;
}, "~N,~N,~N");
c$.norm = Clazz.defineMethod (c$, "norm", 
function (start, stop, value) {
return (value - start) / (stop - start);
}, "~N,~N,~N");
c$.map = Clazz.defineMethod (c$, "map", 
function (minStart, minStop, maxStart, maxStop, value) {
return maxStart + (maxStart - maxStop) * ((value - minStart) / (minStop - minStart));
}, "~N,~N,~N,~N,~N");
c$.random = Clazz.defineMethod (c$, "random", 
function (howbig) {
return Math.round ((android.util.MathUtils.sRandom.nextFloat () * howbig));
}, "~N");
c$.random = Clazz.defineMethod (c$, "random", 
function (howsmall, howbig) {
if (howsmall >= howbig) return howsmall;
return Math.round ((android.util.MathUtils.sRandom.nextFloat () * (howbig - howsmall) + howsmall));
}, "~N,~N");
c$.random = Clazz.defineMethod (c$, "random", 
function (howbig) {
return android.util.MathUtils.sRandom.nextFloat () * howbig;
}, "~N");
c$.random = Clazz.defineMethod (c$, "random", 
function (howsmall, howbig) {
if (howsmall >= howbig) return howsmall;
return android.util.MathUtils.sRandom.nextFloat () * (howbig - howsmall) + howsmall;
}, "~N,~N");
c$.randomSeed = Clazz.defineMethod (c$, "randomSeed", 
function (seed) {
android.util.MathUtils.sRandom.setSeed (seed);
}, "~N");
c$.sRandom = c$.prototype.sRandom =  new java.util.Random ();
Clazz.defineStatics (c$,
"DEG_TO_RAD", 0.017453292,
"RAD_TO_DEG", 57.295784);
});
