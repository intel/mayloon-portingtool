﻿Clazz.declarePackage ("android.util");
c$ = Clazz.decorateAsClass (function () {
this.first = null;
this.second = null;
Clazz.instantialize (this, arguments);
}, android.util, "Pair");
Clazz.makeConstructor (c$, 
function (first, second) {
this.first = first;
this.second = second;
}, "~O,~O");
Clazz.defineMethod (c$, "equals", 
function (o) {
if (o === this) return true;
if (!(Clazz.instanceOf (o, android.util.Pair))) return false;
var other;
try {
other = o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
return false;
} else {
throw e;
}
}
return this.first.equals (other.first) && this.second.equals (other.second);
}, "~O");
Clazz.defineMethod (c$, "hashCode", 
function () {
var result = 17;
result = 31 * result + this.first.hashCode ();
result = 31 * result + this.second.hashCode ();
return result;
});
c$.create = Clazz.defineMethod (c$, "create", 
function (a, b) {
return  new android.util.Pair (a, b);
}, "~O,~O");
