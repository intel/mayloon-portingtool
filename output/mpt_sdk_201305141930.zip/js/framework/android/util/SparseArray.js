﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.SparseArray", ["android.util.Log", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mGarbage = false;
this.mKeys = null;
this.mValues = null;
this.mSize = 0;
Clazz.instantialize (this, arguments);
}, android.util, "SparseArray");
Clazz.makeConstructor (c$, 
function () {
this.construct (10);
});
Clazz.makeConstructor (c$, 
function (initialCapacity) {
initialCapacity = android.util.SparseArray.idealIntArraySize (initialCapacity);
this.mKeys =  Clazz.newArray (initialCapacity, 0);
this.mValues =  new Array (initialCapacity);
this.mSize = 0;
}, "~N");
c$.idealIntArraySize = Clazz.defineMethod (c$, "idealIntArraySize", 
($fz = function (need) {
return Math.floor (android.util.SparseArray.idealByteArraySize (need * 4) / 4);
}, $fz.isPrivate = true, $fz), "~N");
c$.idealByteArraySize = Clazz.defineMethod (c$, "idealByteArraySize", 
($fz = function (need) {
for (var i = 4; i < 32; i++) if (need <= (1 << i) - 12) return (1 << i) - 12;

return need;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "get", 
function (key) {
return this.get (key, null);
}, "~N");
Clazz.defineMethod (c$, "get", 
function (key, valueIfKeyNotFound) {
var i = android.util.SparseArray.binarySearch (this.mKeys, 0, this.mSize, key);
if (i < 0 || this.mValues[i] === android.util.SparseArray.DELETED) {
return valueIfKeyNotFound;
} else {
return this.mValues[i];
}}, "~N,~O");
Clazz.defineMethod (c$, "$delete", 
function (key) {
var i = android.util.SparseArray.binarySearch (this.mKeys, 0, this.mSize, key);
if (i >= 0) {
if (this.mValues[i] !== android.util.SparseArray.DELETED) {
this.mValues[i] = android.util.SparseArray.DELETED;
this.mGarbage = true;
}}}, "~N");
Clazz.defineMethod (c$, "remove", 
function (key) {
this.$delete (key);
}, "~N");
Clazz.defineMethod (c$, "gc", 
($fz = function () {
var n = this.mSize;
var o = 0;
var keys = this.mKeys;
var values = this.mValues;
for (var i = 0; i < n; i++) {
var val = values[i];
if (val !== android.util.SparseArray.DELETED) {
if (i != o) {
keys[o] = keys[i];
values[o] = val;
}o++;
}}
this.mGarbage = false;
this.mSize = o;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "put", 
function (key, value) {
var i = android.util.SparseArray.binarySearch (this.mKeys, 0, this.mSize, key);
if (i >= 0) {
this.mValues[i] = value;
} else {
i = ~i;
if (i < this.mSize && this.mValues[i] === android.util.SparseArray.DELETED) {
this.mKeys[i] = key;
this.mValues[i] = value;
return ;
}if (this.mGarbage && this.mSize >= this.mKeys.length) {
this.gc ();
i = ~android.util.SparseArray.binarySearch (this.mKeys, 0, this.mSize, key);
}if (this.mSize >= this.mKeys.length) {
var n = android.util.SparseArray.idealIntArraySize (this.mSize + 1);
var nkeys =  Clazz.newArray (n, 0);
var nvalues =  new Array (n);
System.arraycopy (this.mKeys, 0, nkeys, 0, this.mKeys.length);
System.arraycopy (this.mValues, 0, nvalues, 0, this.mValues.length);
this.mKeys = nkeys;
this.mValues = nvalues;
}if (this.mSize - i != 0) {
System.arraycopy (this.mKeys, i, this.mKeys, i + 1, this.mSize - i);
System.arraycopy (this.mValues, i, this.mValues, i + 1, this.mSize - i);
}this.mKeys[i] = key;
this.mValues[i] = value;
this.mSize++;
}}, "~N,~O");
Clazz.defineMethod (c$, "size", 
function () {
if (this.mGarbage) {
this.gc ();
}return this.mSize;
});
Clazz.defineMethod (c$, "keyAt", 
function (index) {
if (this.mGarbage) {
this.gc ();
}return this.mKeys[index];
}, "~N");
Clazz.defineMethod (c$, "valueAt", 
function (index) {
if (this.mGarbage) {
this.gc ();
}return this.mValues[index];
}, "~N");
Clazz.defineMethod (c$, "setValueAt", 
function (index, value) {
if (this.mGarbage) {
this.gc ();
}this.mValues[index] = value;
}, "~N,~O");
Clazz.defineMethod (c$, "indexOfKey", 
function (key) {
if (this.mGarbage) {
this.gc ();
}return android.util.SparseArray.binarySearch (this.mKeys, 0, this.mSize, key);
}, "~N");
Clazz.defineMethod (c$, "indexOfValue", 
function (value) {
if (this.mGarbage) {
this.gc ();
}for (var i = 0; i < this.mSize; i++) if (this.mValues[i] === value) return i;

return -1;
}, "~O");
Clazz.defineMethod (c$, "clear", 
function () {
var n = this.mSize;
var values = this.mValues;
for (var i = 0; i < n; i++) {
values[i] = null;
}
this.mSize = 0;
this.mGarbage = false;
});
Clazz.defineMethod (c$, "append", 
function (key, value) {
if (this.mSize != 0 && key <= this.mKeys[this.mSize - 1]) {
this.put (key, value);
return ;
}if (this.mGarbage && this.mSize >= this.mKeys.length) {
this.gc ();
}var pos = this.mSize;
if (pos >= this.mKeys.length) {
var n = android.util.SparseArray.idealIntArraySize (pos + 1);
var nkeys =  Clazz.newArray (n, 0);
var nvalues =  new Array (n);
System.arraycopy (this.mKeys, 0, nkeys, 0, this.mKeys.length);
System.arraycopy (this.mValues, 0, nvalues, 0, this.mValues.length);
this.mKeys = nkeys;
this.mValues = nvalues;
}this.mKeys[pos] = key;
this.mValues[pos] = value;
this.mSize = pos + 1;
}, "~N,~O");
c$.binarySearch = Clazz.defineMethod (c$, "binarySearch", 
($fz = function (a, start, len, key) {
var high = start + len;
var low = start - 1;
var guess;
while (high - low > 1) {
guess = Math.floor ((high + low) / 2);
if (a[guess] < key) low = guess;
 else high = guess;
}
if (high == start + len) return ~(start + len);
 else if (a[high] == key) return high;
 else return ~high;
}, $fz.isPrivate = true, $fz), "~A,~N,~N,~N");
c$.DELETED = c$.prototype.DELETED =  new JavaObject ();
});
