﻿Clazz.declarePackage ("android.util");
Clazz.load (["java.lang.RuntimeException"], "android.util.TimeFormatException", null, function () {
c$ = Clazz.declareType (android.util, "TimeFormatException", RuntimeException);
});
