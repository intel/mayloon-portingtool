﻿Clazz.declarePackage ("android.util");
c$ = Clazz.declareType (android.util, "Config");
Clazz.defineStatics (c$,
"DEBUG", false,
"RELEASE", true,
"PROFILE", false,
"LOGV", false,
"LOGD", true);
