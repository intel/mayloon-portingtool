﻿Clazz.declarePackage ("android.util");
Clazz.load (["java.io.FilterInputStream"], "android.util.Base64InputStream", ["android.util.Base64", "java.io.IOException", "java.lang.UnsupportedOperationException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.coder = null;
this.eof = false;
this.inputBuffer = null;
this.outputStart = 0;
this.outputEnd = 0;
Clazz.instantialize (this, arguments);
}, android.util, "Base64InputStream", java.io.FilterInputStream);
Clazz.makeConstructor (c$, 
function ($in, flags) {
this.construct ($in, flags, false);
}, "java.io.InputStream,~N");
Clazz.makeConstructor (c$, 
function ($in, flags, encode) {
Clazz.superConstructor (this, android.util.Base64InputStream, [$in]);
this.eof = false;
this.inputBuffer =  Clazz.newArray (2048, 0);
if (encode) {
this.coder =  new android.util.Base64.Encoder (flags, null);
} else {
this.coder =  new android.util.Base64.Decoder (flags, null);
}this.coder.output =  Clazz.newArray (this.coder.maxOutputSize (2048), 0);
this.outputStart = 0;
this.outputEnd = 0;
}, "java.io.InputStream,~N,~B");
Clazz.overrideMethod (c$, "markSupported", 
function () {
return false;
});
Clazz.overrideMethod (c$, "mark", 
function (readlimit) {
throw  new UnsupportedOperationException ();
}, "~N");
Clazz.overrideMethod (c$, "reset", 
function () {
throw  new UnsupportedOperationException ();
});
Clazz.overrideMethod (c$, "close", 
function () {
this.$in.close ();
this.inputBuffer = null;
});
Clazz.overrideMethod (c$, "available", 
function () {
return this.outputEnd - this.outputStart;
});
Clazz.overrideMethod (c$, "skip", 
function (n) {
if (this.outputStart >= this.outputEnd) {
this.refill ();
}if (this.outputStart >= this.outputEnd) {
return 0;
}var bytes = Math.min (n, this.outputEnd - this.outputStart);
this.outputStart += bytes;
return bytes;
}, "~N");
Clazz.defineMethod (c$, "read", 
function () {
if (this.outputStart >= this.outputEnd) {
this.refill ();
}if (this.outputStart >= this.outputEnd) {
return -1;
} else {
return this.coder.output[this.outputStart++] & 0xff;
}});
Clazz.defineMethod (c$, "read", 
function (b, off, len) {
if (this.outputStart >= this.outputEnd) {
this.refill ();
}if (this.outputStart >= this.outputEnd) {
return -1;
}var bytes = Math.min (len, this.outputEnd - this.outputStart);
System.arraycopy (this.coder.output, this.outputStart, b, off, bytes);
this.outputStart += bytes;
return bytes;
}, "~A,~N,~N");
Clazz.defineMethod (c$, "refill", 
($fz = function () {
if (this.eof) return ;
var bytesRead = this.$in.read (this.inputBuffer);
var success;
if (bytesRead == -1) {
this.eof = true;
success = this.coder.process (android.util.Base64InputStream.EMPTY, 0, 0, true);
} else {
success = this.coder.process (this.inputBuffer, 0, bytesRead, false);
}if (!success) {
throw  new java.io.IOException ("bad base-64");
}this.outputEnd = this.coder.op;
this.outputStart = 0;
}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"EMPTY",  Clazz.newArray (0, 0),
"BUFFER_SIZE", 2048);
});
