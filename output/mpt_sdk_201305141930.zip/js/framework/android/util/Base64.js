﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.Base64", ["java.lang.AssertionError", "$.IllegalArgumentException"], function () {
c$ = Clazz.declareType (android.util, "Base64");
c$.decode = Clazz.defineMethod (c$, "decode", 
function (str, flags) {
return android.util.Base64.decode (str.getBytes (), flags);
}, "~S,~N");
c$.decode = Clazz.defineMethod (c$, "decode", 
function (input, flags) {
return android.util.Base64.decode (input, 0, input.length, flags);
}, "~A,~N");
c$.decode = Clazz.defineMethod (c$, "decode", 
function (input, offset, len, flags) {
var decoder =  new android.util.Base64.Decoder (flags,  Clazz.newArray (Math.floor (len * 3 / 4), 0));
if (!decoder.process (input, offset, len, true)) {
throw  new IllegalArgumentException ("bad base-64");
}if (decoder.op == decoder.output.length) {
return decoder.output;
}var temp =  Clazz.newArray (decoder.op, 0);
System.arraycopy (decoder.output, 0, temp, 0, decoder.op);
return temp;
}, "~A,~N,~N,~N");
c$.encodeToString = Clazz.defineMethod (c$, "encodeToString", 
function (input, flags) {
try {
return  String.instantialize (android.util.Base64.encode (input, flags), "US-ASCII");
} catch (e) {
if (Clazz.instanceOf (e, java.io.UnsupportedEncodingException)) {
throw  new AssertionError (e);
} else {
throw e;
}
}
}, "~A,~N");
c$.encodeToString = Clazz.defineMethod (c$, "encodeToString", 
function (input, offset, len, flags) {
try {
return  String.instantialize (android.util.Base64.encode (input, offset, len, flags), "US-ASCII");
} catch (e) {
if (Clazz.instanceOf (e, java.io.UnsupportedEncodingException)) {
throw  new AssertionError (e);
} else {
throw e;
}
}
}, "~A,~N,~N,~N");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (input, flags) {
return android.util.Base64.encode (input, 0, input.length, flags);
}, "~A,~N");
c$.encode = Clazz.defineMethod (c$, "encode", 
function (input, offset, len, flags) {
var encoder =  new android.util.Base64.Encoder (flags, null);
var output_len = Math.floor (len / 3) * 4;
if (encoder.do_padding) {
if (len % 3 > 0) {
output_len += 4;
}} else {
switch (len % 3) {
case 0:
break;
case 1:
output_len += 2;
break;
case 2:
output_len += 3;
break;
}
}if (encoder.do_newline && len > 0) {
output_len += ((Math.floor ((len - 1) / (57))) + 1) * (encoder.do_cr ? 2 : 1);
}encoder.output =  Clazz.newArray (output_len, 0);
encoder.process (input, offset, len, true);
return encoder.output;
}, "~A,~N,~N,~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.output = null;
this.op = 0;
Clazz.instantialize (this, arguments);
}, android.util.Base64, "Coder");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.state = 0;
this.value = 0;
this.alphabet = null;
Clazz.instantialize (this, arguments);
}, android.util.Base64, "Decoder", android.util.Base64.Coder);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.util.Base64.Decoder, []);
this.output = b;
this.alphabet = ((a & 8) == 0) ? android.util.Base64.Decoder.DECODE : android.util.Base64.Decoder.DECODE_WEBSAFE;
this.state = 0;
this.value = 0;
}, "~N,~A");
Clazz.overrideMethod (c$, "maxOutputSize", 
function (a) {
return Math.floor (a * 3 / 4) + 10;
}, "~N");
Clazz.overrideMethod (c$, "process", 
function (a, b, c, d) {
if (this.state == 6) return false;
var e = b;
c += b;
var f = this.state;
var g = this.value;
var h = 0;
var i = this.output;
var j = this.alphabet;
while (e < c) {
if (f == 0) {
while (e + 4 <= c && (g = ((j[a[e] & 0xff] << 18) | (j[a[e + 1] & 0xff] << 12) | (j[a[e + 2] & 0xff] << 6) | (j[a[e + 3] & 0xff]))) >= 0) {
i[h + 2] = (g & 0xFF);
i[h + 1] = ((g >> 8) & 0xFF);
i[h] = ((g >> 16) & 0xFF);
h += 3;
e += 4;
}
if (e >= c) break;
}var k = j[a[e++] & 0xff];
switch (f) {
case 0:
if (k >= 0) {
g = k;
++f;
} else if (k != -1) {
this.state = 6;
return false;
}break;
case 1:
if (k >= 0) {
g = (g << 6) | k;
++f;
} else if (k != -1) {
this.state = 6;
return false;
}break;
case 2:
if (k >= 0) {
g = (g << 6) | k;
++f;
} else if (k == -2) {
i[h++] = ((g >> 4) & 0xFF);
f = 4;
} else if (k != -1) {
this.state = 6;
return false;
}break;
case 3:
if (k >= 0) {
g = (g << 6) | k;
i[h + 2] = (g & 0xFF);
i[h + 1] = ((g >> 8) & 0xFF);
i[h] = ((g >> 16) & 0xFF);
h += 3;
f = 0;
} else if (k == -2) {
i[h + 1] = ((g >> 2) & 0xFF);
i[h] = ((g >> 10) & 0xFF);
h += 2;
f = 5;
} else if (k != -1) {
this.state = 6;
return false;
}break;
case 4:
if (k == -2) {
++f;
} else if (k != -1) {
this.state = 6;
return false;
}break;
case 5:
if (k != -1) {
this.state = 6;
return false;
}break;
}
}
if (!d) {
this.state = f;
this.value = g;
this.op = h;
return true;
}switch (f) {
case 0:
break;
case 1:
this.state = 6;
return false;
case 2:
i[h++] = ((g >> 4) & 0xFF);
break;
case 3:
i[h++] = ((g >> 10) & 0xFF);
i[h++] = ((g >> 2) & 0xFF);
break;
case 4:
this.state = 6;
return false;
case 5:
break;
}
this.state = f;
this.op = h;
return true;
}, "~A,~N,~N,~B");
Clazz.defineStatics (c$,
"DECODE", [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -2, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
"DECODE_WEBSAFE", [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -2, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, 63, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
"SKIP", -1,
"EQUALS", -2);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.tail = null;
this.tailLen = 0;
this.count = 0;
this.do_padding = false;
this.do_newline = false;
this.do_cr = false;
this.alphabet = null;
Clazz.instantialize (this, arguments);
}, android.util.Base64, "Encoder", android.util.Base64.Coder);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.util.Base64.Encoder, []);
this.output = b;
this.do_padding = (a & 1) == 0;
this.do_newline = (a & 2) == 0;
this.do_cr = (a & 4) != 0;
this.alphabet = ((a & 8) == 0) ? android.util.Base64.Encoder.ENCODE : android.util.Base64.Encoder.ENCODE_WEBSAFE;
this.tail =  Clazz.newArray (2, 0);
this.tailLen = 0;
this.count = this.do_newline ? 19 : -1;
}, "~N,~A");
Clazz.overrideMethod (c$, "maxOutputSize", 
function (a) {
return Math.floor (a * 8 / 5) + 10;
}, "~N");
Clazz.overrideMethod (c$, "process", 
function (a, b, c, d) {
var e = this.alphabet;
var f = this.output;
var g = 0;
var h = this.count;
var i = b;
c += b;
var j = -1;
switch (this.tailLen) {
case 0:
break;
case 1:
if (i + 2 <= c) {
j = ((this.tail[0] & 0xff) << 16) | ((a[i++] & 0xff) << 8) | (a[i++] & 0xff);
this.tailLen = 0;
};break;
case 2:
if (i + 1 <= c) {
j = ((this.tail[0] & 0xff) << 16) | ((this.tail[1] & 0xff) << 8) | (a[i++] & 0xff);
this.tailLen = 0;
}break;
}
if (j != -1) {
f[g++] = e[(j >> 18) & 0x3f];
f[g++] = e[(j >> 12) & 0x3f];
f[g++] = e[(j >> 6) & 0x3f];
f[g++] = e[j & 0x3f];
if (--h == 0) {
if (this.do_cr) f[g++] = ('\r').charCodeAt (0);
f[g++] = ('\n').charCodeAt (0);
h = 19;
}}while (i + 3 <= c) {
j = ((a[i] & 0xff) << 16) | ((a[i + 1] & 0xff) << 8) | (a[i + 2] & 0xff);
f[g] = e[(j >> 18) & 0x3f];
f[g + 1] = e[(j >> 12) & 0x3f];
f[g + 2] = e[(j >> 6) & 0x3f];
f[g + 3] = e[j & 0x3f];
i += 3;
g += 4;
if (--h == 0) {
if (this.do_cr) f[g++] = ('\r').charCodeAt (0);
f[g++] = ('\n').charCodeAt (0);
h = 19;
}}
if (d) {
if (i - this.tailLen == c - 1) {
var k = 0;
j = ((this.tailLen > 0 ? this.tail[k++] : a[i++]) & 0xff) << 4;
this.tailLen -= k;
f[g++] = e[(j >> 6) & 0x3f];
f[g++] = e[j & 0x3f];
if (this.do_padding) {
f[g++] = ('=').charCodeAt (0);
f[g++] = ('=').charCodeAt (0);
}if (this.do_newline) {
if (this.do_cr) f[g++] = ('\r').charCodeAt (0);
f[g++] = ('\n').charCodeAt (0);
}} else if (i - this.tailLen == c - 2) {
var k = 0;
j = (((this.tailLen > 1 ? this.tail[k++] : a[i++]) & 0xff) << 10) | (((this.tailLen > 0 ? this.tail[k++] : a[i++]) & 0xff) << 2);
this.tailLen -= k;
f[g++] = e[(j >> 12) & 0x3f];
f[g++] = e[(j >> 6) & 0x3f];
f[g++] = e[j & 0x3f];
if (this.do_padding) {
f[g++] = ('=').charCodeAt (0);
}if (this.do_newline) {
if (this.do_cr) f[g++] = ('\r').charCodeAt (0);
f[g++] = ('\n').charCodeAt (0);
}} else if (this.do_newline && g > 0 && h != 19) {
if (this.do_cr) f[g++] = ('\r').charCodeAt (0);
f[g++] = ('\n').charCodeAt (0);
}} else {
if (i == c - 1) {
this.tail[this.tailLen++] = a[i];
} else if (i == c - 2) {
this.tail[this.tailLen++] = a[i];
this.tail[this.tailLen++] = a[i + 1];
}}this.op = g;
this.count = h;
return true;
}, "~A,~N,~N,~B");
Clazz.defineStatics (c$,
"LINE_GROUPS", 19,
"ENCODE", ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'],
"ENCODE_WEBSAFE", ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '_']);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DEFAULT", 0,
"NO_PADDING", 1,
"NO_WRAP", 2,
"CRLF", 4,
"URL_SAFE", 8,
"NO_CLOSE", 16);
});
