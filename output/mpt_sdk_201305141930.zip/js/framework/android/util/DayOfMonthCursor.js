﻿Clazz.declarePackage ("android.util");
Clazz.load (["android.util.MonthDisplayHelper"], "android.util.DayOfMonthCursor", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mRow = 0;
this.mColumn = 0;
Clazz.instantialize (this, arguments);
}, android.util, "DayOfMonthCursor", android.util.MonthDisplayHelper);
Clazz.makeConstructor (c$, 
function (year, month, dayOfMonth, weekStartDay) {
Clazz.superConstructor (this, android.util.DayOfMonthCursor, [year, month, weekStartDay]);
this.mRow = this.getRowOf (dayOfMonth);
this.mColumn = this.getColumnOf (dayOfMonth);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "getSelectedRow", 
function () {
return this.mRow;
});
Clazz.defineMethod (c$, "getSelectedColumn", 
function () {
return this.mColumn;
});
Clazz.defineMethod (c$, "setSelectedRowColumn", 
function (row, col) {
this.mRow = row;
this.mColumn = col;
}, "~N,~N");
Clazz.defineMethod (c$, "getSelectedDayOfMonth", 
function () {
return this.getDayAt (this.mRow, this.mColumn);
});
Clazz.defineMethod (c$, "getSelectedMonthOffset", 
function () {
if (this.isWithinCurrentMonth (this.mRow, this.mColumn)) {
return 0;
}if (this.mRow == 0) {
return -1;
}return 1;
});
Clazz.defineMethod (c$, "setSelectedDayOfMonth", 
function (dayOfMonth) {
this.mRow = this.getRowOf (dayOfMonth);
this.mColumn = this.getColumnOf (dayOfMonth);
}, "~N");
Clazz.defineMethod (c$, "isSelected", 
function (row, column) {
return (this.mRow == row) && (this.mColumn == column);
}, "~N,~N");
Clazz.defineMethod (c$, "up", 
function () {
if (this.isWithinCurrentMonth (this.mRow - 1, this.mColumn)) {
this.mRow--;
return false;
}this.previousMonth ();
this.mRow = 5;
while (!this.isWithinCurrentMonth (this.mRow, this.mColumn)) {
this.mRow--;
}
return true;
});
Clazz.defineMethod (c$, "down", 
function () {
if (this.isWithinCurrentMonth (this.mRow + 1, this.mColumn)) {
this.mRow++;
return false;
}this.nextMonth ();
this.mRow = 0;
while (!this.isWithinCurrentMonth (this.mRow, this.mColumn)) {
this.mRow++;
}
return true;
});
Clazz.defineMethod (c$, "left", 
function () {
if (this.mColumn == 0) {
this.mRow--;
this.mColumn = 6;
} else {
this.mColumn--;
}if (this.isWithinCurrentMonth (this.mRow, this.mColumn)) {
return false;
}this.previousMonth ();
var lastDay = this.getNumberOfDaysInMonth ();
this.mRow = this.getRowOf (lastDay);
this.mColumn = this.getColumnOf (lastDay);
return true;
});
Clazz.defineMethod (c$, "right", 
function () {
if (this.mColumn == 6) {
this.mRow++;
this.mColumn = 0;
} else {
this.mColumn++;
}if (this.isWithinCurrentMonth (this.mRow, this.mColumn)) {
return false;
}this.nextMonth ();
this.mRow = 0;
this.mColumn = 0;
while (!this.isWithinCurrentMonth (this.mRow, this.mColumn)) {
this.mColumn++;
}
return true;
});
});
