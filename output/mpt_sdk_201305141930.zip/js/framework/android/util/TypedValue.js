﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.TypedValue", ["android.util.MathUtils", "java.lang.Float", "$.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.type = 0;
this.string = null;
this.data = 0;
this.assetCookie = 0;
this.resourceId = 0;
this.changingConfigurations = -1;
this.density = 0;
Clazz.instantialize (this, arguments);
}, android.util, "TypedValue");
Clazz.defineMethod (c$, "getFloat", 
function () {
return android.util.MathUtils.myIntBitsToFloat (this.data);
});
c$.complexToFloat = Clazz.defineMethod (c$, "complexToFloat", 
function (complex) {
return (complex & (-256)) * android.util.TypedValue.RADIX_MULTS[(complex >> 4) & 3];
}, "~N");
c$.complexToDimension = Clazz.defineMethod (c$, "complexToDimension", 
function (data, metrics) {
return android.util.TypedValue.applyDimension ((data >> 0) & 15, android.util.TypedValue.complexToFloat (data), metrics);
}, "~N,android.util.DisplayMetrics");
c$.complexToDimensionPixelOffset = Clazz.defineMethod (c$, "complexToDimensionPixelOffset", 
function (data, metrics) {
return Math.round (Math.floor (android.util.TypedValue.applyDimension ((data >> 0) & 15, android.util.TypedValue.complexToFloat (data), metrics)));
}, "~N,android.util.DisplayMetrics");
c$.complexToDimensionPixelSize = Clazz.defineMethod (c$, "complexToDimensionPixelSize", 
function (data, metrics) {
var value = android.util.TypedValue.complexToFloat (data);
var f = android.util.TypedValue.applyDimension ((data >> 0) & 15, value, metrics);
var res = Math.round (Math.floor (f + 0.5));
if (res != 0) return res;
if (value == 0) return 0;
if (value > 0) return 1;
return -1;
}, "~N,android.util.DisplayMetrics");
c$.applyDimension = Clazz.defineMethod (c$, "applyDimension", 
function (unit, value, metrics) {
switch (unit) {
case 0:
return value;
case 1:
return value * metrics.density;
case 2:
return value * metrics.scaledDensity;
case 3:
return value * metrics.xdpi * (0.013888889);
case 4:
return value * metrics.xdpi;
case 5:
return value * metrics.xdpi * (0.03937008);
}
return 0;
}, "~N,~N,android.util.DisplayMetrics");
c$.complexToFraction = Clazz.defineMethod (c$, "complexToFraction", 
function (data, base, pbase) {
switch ((data >> 0) & 15) {
case 0:
return android.util.TypedValue.complexToFloat (data) * base;
case 1:
return android.util.TypedValue.complexToFloat (data) * pbase;
}
return 0;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "getFraction", 
function (base, pbase) {
return android.util.TypedValue.complexToFraction (this.data, base, pbase);
}, "~N,~N");
Clazz.defineMethod (c$, "coerceToString", 
function () {
var t = this.type;
if (t == 3) {
return this.string;
}return android.util.TypedValue.coerceToString (t, this.data);
});
c$.coerceToString = Clazz.defineMethod (c$, "coerceToString", 
function (type, data) {
switch (type) {
case 0:
return null;
case 1:
return "@" + data;
case 2:
return "?" + data;
case 4:
return Float.toString (android.util.MathUtils.myIntBitsToFloat (data));
case 5:
return Float.toString (android.util.TypedValue.complexToFloat (data)) + android.util.TypedValue.DIMENSION_UNIT_STRS[(data >> 0) & 15];
case 6:
return Float.toString (android.util.TypedValue.complexToFloat (data) * 100) + android.util.TypedValue.FRACTION_UNIT_STRS[(data >> 0) & 15];
case 17:
return "0x" + Integer.toHexString (data);
case 18:
return data != 0 ? "true" : "false";
}
if (type >= 28 && type <= 31) {
return "#" + Integer.toHexString (data);
} else if (type >= 16 && type <= 31) {
return Integer.toString (data);
}return null;
}, "~N,~N");
Clazz.defineMethod (c$, "setTo", 
function (other) {
this.type = other.type;
this.string = other.string;
this.data = other.data;
this.assetCookie = other.assetCookie;
this.resourceId = other.resourceId;
this.density = other.density;
}, "android.util.TypedValue");
Clazz.overrideMethod (c$, "toString", 
function () {
var sb =  new StringBuilder ();
sb.append ("TypedValue{t=0x").append (Integer.toHexString (this.type));
sb.append ("/d=0x").append (Integer.toHexString (this.data));
if (this.type == 3) {
sb.append (" \"").append (this.string != null ? this.string : "<null>").append ("\"");
}if (this.assetCookie != 0) {
sb.append (" a=").append (this.assetCookie);
}if (this.resourceId != 0) {
sb.append (" r=0x").append (Integer.toHexString (this.resourceId));
}sb.append ("}");
return sb.toString ();
});
Clazz.defineMethod (c$, "getDimension", 
function (metrics) {
console.log("Missing method: getDimension");
}, "android.util.DisplayMetrics");
Clazz.defineStatics (c$,
"TYPE_NULL", 0x00,
"TYPE_REFERENCE", 0x01,
"TYPE_ATTRIBUTE", 0x02,
"TYPE_STRING", 0x03,
"TYPE_FLOAT", 0x04,
"TYPE_DIMENSION", 0x05,
"TYPE_FRACTION", 0x06,
"TYPE_FIRST_INT", 0x10,
"TYPE_INT_DEC", 0x10,
"TYPE_INT_HEX", 0x11,
"TYPE_INT_BOOLEAN", 0x12,
"TYPE_FIRST_COLOR_INT", 0x1c,
"TYPE_INT_COLOR_ARGB8", 0x1c,
"TYPE_INT_COLOR_RGB8", 0x1d,
"TYPE_INT_COLOR_ARGB4", 0x1e,
"TYPE_INT_COLOR_RGB4", 0x1f,
"TYPE_LAST_COLOR_INT", 0x1f,
"TYPE_LAST_INT", 0x1f,
"COMPLEX_UNIT_SHIFT", 0,
"COMPLEX_UNIT_MASK", 0xf,
"COMPLEX_UNIT_PX", 0,
"COMPLEX_UNIT_DIP", 1,
"COMPLEX_UNIT_SP", 2,
"COMPLEX_UNIT_PT", 3,
"COMPLEX_UNIT_IN", 4,
"COMPLEX_UNIT_MM", 5,
"COMPLEX_UNIT_FRACTION", 0,
"COMPLEX_UNIT_FRACTION_PARENT", 1,
"COMPLEX_RADIX_SHIFT", 4,
"COMPLEX_RADIX_MASK", 0x3,
"COMPLEX_RADIX_23p0", 0,
"COMPLEX_RADIX_16p7", 1,
"COMPLEX_RADIX_8p15", 2,
"COMPLEX_RADIX_0p23", 3,
"COMPLEX_MANTISSA_SHIFT", 8,
"COMPLEX_MANTISSA_MASK", 0xffffff,
"DENSITY_DEFAULT", 0,
"DENSITY_NONE", 0xffff,
"MANTISSA_MULT", 0.00390625,
"RADIX_MULTS", [0.00390625, 3.0517578E-5, 1.1920929E-7, 4.656613E-10]);
c$.DIMENSION_UNIT_STRS = c$.prototype.DIMENSION_UNIT_STRS = ["px", "dip", "sp", "pt", "in", "mm"];
c$.FRACTION_UNIT_STRS = c$.prototype.FRACTION_UNIT_STRS = ["%", "%p"];
});
