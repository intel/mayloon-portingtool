﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.TimingLogger", ["android.os.SystemClock", "android.util.Log", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mTag = null;
this.mLabel = null;
this.mDisabled = false;
this.mSplits = null;
this.mSplitLabels = null;
Clazz.instantialize (this, arguments);
}, android.util, "TimingLogger");
Clazz.makeConstructor (c$, 
function (tag, label) {
this.reset (tag, label);
}, "~S,~S");
Clazz.defineMethod (c$, "reset", 
function (tag, label) {
this.mTag = tag;
this.mLabel = label;
this.reset ();
}, "~S,~S");
Clazz.defineMethod (c$, "reset", 
function () {
this.mDisabled = !android.util.Log.isLoggable (this.mTag, 2);
if (this.mDisabled) return ;
if (this.mSplits == null) {
this.mSplits =  new java.util.ArrayList ();
this.mSplitLabels =  new java.util.ArrayList ();
} else {
this.mSplits.clear ();
this.mSplitLabels.clear ();
}this.addSplit (null);
});
Clazz.defineMethod (c$, "addSplit", 
function (splitLabel) {
if (this.mDisabled) return ;
var now = android.os.SystemClock.elapsedRealtime ();
this.mSplits.add (new Long (now));
this.mSplitLabels.add (splitLabel);
}, "~S");
Clazz.defineMethod (c$, "dumpToLog", 
function () {
if (this.mDisabled) return ;
android.util.Log.d (this.mTag, this.mLabel + ": begin");
var first = (this.mSplits.get (0)).longValue ();
var now = first;
for (var i = 1; i < this.mSplits.size (); i++) {
now = (this.mSplits.get (i)).longValue ();
var splitLabel = this.mSplitLabels.get (i);
var prev = (this.mSplits.get (i - 1)).longValue ();
android.util.Log.d (this.mTag, this.mLabel + ":      " + (now - prev) + " ms, " + splitLabel);
}
android.util.Log.d (this.mTag, this.mLabel + ": end, " + (now - first) + " ms");
});
});
