﻿Clazz.declarePackage ("android.util");
c$ = Clazz.declareType (android.util, "EventLogTags");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (input) {
}, "java.io.BufferedReader");
Clazz.defineMethod (c$, "get", 
function (name) {
return null;
}, "~S");
Clazz.defineMethod (c$, "get", 
function (tag) {
return null;
}, "~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mTag = 0;
this.mName = null;
Clazz.instantialize (this, arguments);
}, android.util.EventLogTags, "Description");
Clazz.makeConstructor (c$, 
function (a, b) {
this.mTag = a;
this.mName = b;
}, "~N,~S");
c$ = Clazz.p0p ();
