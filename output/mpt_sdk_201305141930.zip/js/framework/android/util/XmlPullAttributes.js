﻿Clazz.declarePackage ("android.util");
Clazz.load (["android.util.AttributeSet"], "android.util.XmlPullAttributes", ["com.android.internal.util.XmlUtils", "java.lang.Float"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mParser = null;
Clazz.instantialize (this, arguments);
}, android.util, "XmlPullAttributes", null, android.util.AttributeSet);
Clazz.makeConstructor (c$, 
function (parser) {
this.mParser = parser;
}, "org.xmlpull.v1.XmlPullParser");
Clazz.overrideMethod (c$, "getAttributeCount", 
function () {
return this.mParser.getAttributeCount ();
});
Clazz.overrideMethod (c$, "getAttributeName", 
function (index) {
return this.mParser.getAttributeName (index);
}, "~N");
Clazz.defineMethod (c$, "getAttributeValue", 
function (index) {
return this.mParser.getAttributeValue (index);
}, "~N");
Clazz.defineMethod (c$, "getAttributeValue", 
function (namespace, name) {
return this.mParser.getAttributeValue (namespace, name);
}, "~S,~S");
Clazz.overrideMethod (c$, "getPositionDescription", 
function () {
return this.mParser.getPositionDescription ();
});
Clazz.overrideMethod (c$, "getAttributeNameResource", 
function (index) {
return 0;
}, "~N");
Clazz.defineMethod (c$, "getAttributeListValue", 
function (namespace, attribute, options, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToList (this.getAttributeValue (namespace, attribute), options, defaultValue);
}, "~S,~S,~A,~N");
Clazz.defineMethod (c$, "getAttributeBooleanValue", 
function (namespace, attribute, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToBoolean (this.getAttributeValue (namespace, attribute), defaultValue);
}, "~S,~S,~B");
Clazz.defineMethod (c$, "getAttributeResourceValue", 
function (namespace, attribute, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToInt (this.getAttributeValue (namespace, attribute), defaultValue);
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getAttributeIntValue", 
function (namespace, attribute, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToInt (this.getAttributeValue (namespace, attribute), defaultValue);
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getAttributeUnsignedIntValue", 
function (namespace, attribute, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToUnsignedInt (this.getAttributeValue (namespace, attribute), defaultValue);
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getAttributeFloatValue", 
function (namespace, attribute, defaultValue) {
var s = this.getAttributeValue (namespace, attribute);
if (s != null) {
return Float.parseFloat (s);
}return defaultValue;
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getAttributeListValue", 
function (index, options, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToList (this.getAttributeValue (index), options, defaultValue);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "getAttributeBooleanValue", 
function (index, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToBoolean (this.getAttributeValue (index), defaultValue);
}, "~N,~B");
Clazz.defineMethod (c$, "getAttributeResourceValue", 
function (index, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToInt (this.getAttributeValue (index), defaultValue);
}, "~N,~N");
Clazz.defineMethod (c$, "getAttributeIntValue", 
function (index, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToInt (this.getAttributeValue (index), defaultValue);
}, "~N,~N");
Clazz.defineMethod (c$, "getAttributeUnsignedIntValue", 
function (index, defaultValue) {
return com.android.internal.util.XmlUtils.convertValueToUnsignedInt (this.getAttributeValue (index), defaultValue);
}, "~N,~N");
Clazz.defineMethod (c$, "getAttributeFloatValue", 
function (index, defaultValue) {
var s = this.getAttributeValue (index);
if (s != null) {
return Float.parseFloat (s);
}return defaultValue;
}, "~N,~N");
Clazz.overrideMethod (c$, "getIdAttribute", 
function () {
return this.getAttributeValue (null, "id");
});
Clazz.overrideMethod (c$, "getClassAttribute", 
function () {
return this.getAttributeValue (null, "class");
});
Clazz.overrideMethod (c$, "getIdAttributeResourceValue", 
function (defaultValue) {
return this.getAttributeResourceValue (null, "id", defaultValue);
}, "~N");
Clazz.overrideMethod (c$, "getStyleAttribute", 
function () {
return this.getAttributeResourceValue (null, "style", 0);
});
});
