﻿Clazz.declarePackage ("android.util");
c$ = Clazz.declareType (android.util, "DebugUtils");
c$.isObjectSelected = Clazz.defineMethod (c$, "isObjectSelected", 
function (object) {
var match = false;
var s = System.getenv ("ANDROID_OBJECT_FILTER");
if (s != null && s.length > 0) {
var selectors = s.$plit ("@");
if (object.getClass ().getSimpleName ().matches (selectors[0])) {
for (var i = 1; i < selectors.length; i++) {
var pair = selectors[i].$plit ("=");
var klass = object.getClass ();
try {
var declaredMethod = null;
var parent = klass;
do {
declaredMethod = parent.getDeclaredMethod ("get" + pair[0].substring (0, 1).toUpperCase () + pair[0].substring (1), [null]);
} while ((parent = klass.getSuperclass ()) != null && declaredMethod == null);
if (declaredMethod != null) {
var value = declaredMethod.invoke (object, [null]);
match = new Boolean (match | (value != null ? value.toString () : "null").matches (pair[1])).valueOf ();
}} catch (e$$) {
if (Clazz.instanceOf (e$$, NoSuchMethodException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, IllegalAccessException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, java.lang.reflect.InvocationTargetException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else {
throw e$$;
}
}
}
}}return match;
}, "~O");
Clazz.defineStatics (c$,
"DEBUG_VIEW_IN_BROWSER", false);
