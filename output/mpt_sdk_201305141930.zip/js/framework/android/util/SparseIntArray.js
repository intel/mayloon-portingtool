﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.SparseIntArray", ["android.util.Log", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mKeys = null;
this.mValues = null;
this.mSize = 0;
Clazz.instantialize (this, arguments);
}, android.util, "SparseIntArray");
Clazz.makeConstructor (c$, 
function () {
this.construct (10);
});
c$.idealIntArraySize = Clazz.defineMethod (c$, "idealIntArraySize", 
($fz = function (need) {
return Math.floor (android.util.SparseIntArray.idealByteArraySize (need * 4) / 4);
}, $fz.isPrivate = true, $fz), "~N");
c$.idealByteArraySize = Clazz.defineMethod (c$, "idealByteArraySize", 
($fz = function (need) {
for (var i = 4; i < 32; i++) if (need <= (1 << i) - 12) return (1 << i) - 12;

return need;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.makeConstructor (c$, 
function (initialCapacity) {
initialCapacity = android.util.SparseIntArray.idealIntArraySize (initialCapacity);
this.mKeys =  Clazz.newArray (initialCapacity, 0);
this.mValues =  Clazz.newArray (initialCapacity, 0);
this.mSize = 0;
}, "~N");
Clazz.defineMethod (c$, "get", 
function (key) {
return this.get (key, 0);
}, "~N");
Clazz.defineMethod (c$, "get", 
function (key, valueIfKeyNotFound) {
var i = android.util.SparseIntArray.binarySearch (this.mKeys, 0, this.mSize, key);
if (i < 0) {
return valueIfKeyNotFound;
} else {
return this.mValues[i];
}}, "~N,~N");
Clazz.defineMethod (c$, "$delete", 
function (key) {
var i = android.util.SparseIntArray.binarySearch (this.mKeys, 0, this.mSize, key);
if (i >= 0) {
this.removeAt (i);
}}, "~N");
Clazz.defineMethod (c$, "removeAt", 
function (index) {
System.arraycopy (this.mKeys, index + 1, this.mKeys, index, this.mSize - (index + 1));
System.arraycopy (this.mValues, index + 1, this.mValues, index, this.mSize - (index + 1));
this.mSize--;
}, "~N");
Clazz.defineMethod (c$, "put", 
function (key, value) {
var i = android.util.SparseIntArray.binarySearch (this.mKeys, 0, this.mSize, key);
if (i >= 0) {
this.mValues[i] = value;
} else {
i = ~i;
if (this.mSize >= this.mKeys.length) {
var n = android.util.SparseIntArray.idealIntArraySize (this.mSize + 1);
var nkeys =  Clazz.newArray (n, 0);
var nvalues =  Clazz.newArray (n, 0);
System.arraycopy (this.mKeys, 0, nkeys, 0, this.mKeys.length);
System.arraycopy (this.mValues, 0, nvalues, 0, this.mValues.length);
this.mKeys = nkeys;
this.mValues = nvalues;
}if (this.mSize - i != 0) {
System.arraycopy (this.mKeys, i, this.mKeys, i + 1, this.mSize - i);
System.arraycopy (this.mValues, i, this.mValues, i + 1, this.mSize - i);
}this.mKeys[i] = key;
this.mValues[i] = value;
this.mSize++;
}}, "~N,~N");
Clazz.defineMethod (c$, "size", 
function () {
return this.mSize;
});
Clazz.defineMethod (c$, "keyAt", 
function (index) {
return this.mKeys[index];
}, "~N");
Clazz.defineMethod (c$, "valueAt", 
function (index) {
return this.mValues[index];
}, "~N");
Clazz.defineMethod (c$, "indexOfKey", 
function (key) {
return android.util.SparseIntArray.binarySearch (this.mKeys, 0, this.mSize, key);
}, "~N");
Clazz.defineMethod (c$, "indexOfValue", 
function (value) {
for (var i = 0; i < this.mSize; i++) if (this.mValues[i] == value) return i;

return -1;
}, "~N");
Clazz.defineMethod (c$, "clear", 
function () {
this.mSize = 0;
});
Clazz.defineMethod (c$, "append", 
function (key, value) {
if (this.mSize != 0 && key <= this.mKeys[this.mSize - 1]) {
this.put (key, value);
return ;
}var pos = this.mSize;
if (pos >= this.mKeys.length) {
var n = android.util.SparseIntArray.idealIntArraySize (pos + 1);
var nkeys =  Clazz.newArray (n, 0);
var nvalues =  Clazz.newArray (n, 0);
System.arraycopy (this.mKeys, 0, nkeys, 0, this.mKeys.length);
System.arraycopy (this.mValues, 0, nvalues, 0, this.mValues.length);
this.mKeys = nkeys;
this.mValues = nvalues;
}this.mKeys[pos] = key;
this.mValues[pos] = value;
this.mSize = pos + 1;
}, "~N,~N");
c$.binarySearch = Clazz.defineMethod (c$, "binarySearch", 
($fz = function (a, start, len, key) {
var high = start + len;
var low = start - 1;
var guess;
while (high - low > 1) {
guess = Math.floor ((high + low) / 2);
if (a[guess] < key) low = guess;
 else high = guess;
}
if (high == start + len) return ~(start + len);
 else if (a[high] == key) return high;
 else return ~high;
}, $fz.isPrivate = true, $fz), "~A,~N,~N,~N");
});
