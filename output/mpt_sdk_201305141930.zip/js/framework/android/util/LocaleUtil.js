﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.LocaleUtil", ["java.lang.Character", "java.util.Locale"], function () {
c$ = Clazz.declareType (android.util, "LocaleUtil");
c$.getLayoutDirectionFromLocale = Clazz.defineMethod (c$, "getLayoutDirectionFromLocale", 
function (locale) {
if (locale != null && !locale.equals (java.util.Locale.ROOT)) {
var scriptSubtag = null;
if (scriptSubtag == null) return android.util.LocaleUtil.getLayoutDirectionFromFirstChar (locale);
}return 0;
}, "java.util.Locale");
c$.getLayoutDirectionFromFirstChar = Clazz.defineMethod (c$, "getLayoutDirectionFromFirstChar", 
($fz = function (locale) {
switch (Character.getDirectionality (locale.getDisplayName (locale).charAt (0))) {
case 1:
case 2:
return 1;
case 0:
default:
return 0;
}
}, $fz.isPrivate = true, $fz), "java.util.Locale");
Clazz.defineStatics (c$,
"TEXT_LAYOUT_DIRECTION_LTR_DO_NOT_USE", 0,
"TEXT_LAYOUT_DIRECTION_RTL_DO_NOT_USE", 1,
"UNDERSCORE_CHAR", '_',
"ARAB_SCRIPT_SUBTAG", "Arab",
"HEBR_SCRIPT_SUBTAG", "Hebr");
});
