﻿Clazz.declarePackage ("android.util");
Clazz.load (["android.util.Printer"], "android.util.LogPrinter", ["android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPriority = 0;
this.mTag = null;
this.mBuffer = 0;
Clazz.instantialize (this, arguments);
}, android.util, "LogPrinter", null, android.util.Printer);
Clazz.makeConstructor (c$, 
function (priority, tag) {
this.mPriority = priority;
this.mTag = tag;
this.mBuffer = 0;
}, "~N,~S");
Clazz.makeConstructor (c$, 
function (priority, tag, buffer) {
this.mPriority = priority;
this.mTag = tag;
this.mBuffer = buffer;
}, "~N,~S,~N");
Clazz.overrideMethod (c$, "println", 
function (x) {
android.util.Log.println_native (this.mBuffer, this.mPriority, this.mTag, x);
}, "~S");
});
