﻿Clazz.declarePackage ("android.util");
Clazz.load (["android.util.Pool"], "android.util.SynchronizedPool", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mPool = null;
Clazz.instantialize (this, arguments);
}, android.util, "SynchronizedPool", null, android.util.Pool);
Clazz.makeConstructor (c$, 
function (pool) {
this.mPool = pool;
}, "android.util.Pool");
Clazz.makeConstructor (c$, 
function (pool, lock) {
this.mPool = pool;
}, "android.util.Pool,~O");
Clazz.defineMethod (c$, "acquire", 
function () {
return this.mPool.acquire ();
});
Clazz.defineMethod (c$, "release", 
function (element) {
this.mPool.release (element);
}, "~O");
});
