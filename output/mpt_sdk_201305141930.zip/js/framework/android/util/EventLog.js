﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.EventLog", ["android.util.Log", "java.io.BufferedReader", "$.FileReader", "java.lang.IllegalArgumentException", "java.nio.ByteBuffer", "$.ByteOrder", "java.util.HashMap", "java.util.regex.Pattern"], function () {
c$ = Clazz.declareType (android.util, "EventLog");
c$.getTagName = Clazz.defineMethod (c$, "getTagName", 
function (tag) {
android.util.EventLog.readTagsFile ();
return android.util.EventLog.sTagNames.get (new Integer (tag));
}, "~N");
c$.getTagCode = Clazz.defineMethod (c$, "getTagCode", 
function (name) {
android.util.EventLog.readTagsFile ();
var code = android.util.EventLog.sTagCodes.get (name);
return code != null ? code : -1;
}, "~S");
c$.readTagsFile = Clazz.defineMethod (c$, "readTagsFile", 
($fz = function () {
if (android.util.EventLog.sTagCodes != null && android.util.EventLog.sTagNames != null) return ;
($t$ = android.util.EventLog.sTagCodes =  new java.util.HashMap (), android.util.EventLog.prototype.sTagCodes = android.util.EventLog.sTagCodes, $t$);
($t$ = android.util.EventLog.sTagNames =  new java.util.HashMap (), android.util.EventLog.prototype.sTagNames = android.util.EventLog.sTagNames, $t$);
var comment = java.util.regex.Pattern.compile ("^\\s*(#.*)?$");
var tag = java.util.regex.Pattern.compile ("^\\s*(\\d+)\\s+(\\w+)\\s*(\\(.*\\))?\\s*$");
var reader = null;
var line;
try {
reader =  new java.io.BufferedReader ( new java.io.FileReader ("/system/etc/event-log-tags"), 256);
while ((line = reader.readLine ()) != null) {
if (comment.matcher (line).matches ()) continue ;var m = tag.matcher (line);
if (!m.matches ()) {
android.util.Log.wtf ("EventLog", "Bad entry in " + "/system/etc/event-log-tags" + ": " + line);
continue ;}try {
var num = Integer.parseInt (m.group (1));
var name = m.group (2);
android.util.EventLog.sTagCodes.put (name, new Integer (num));
android.util.EventLog.sTagNames.put (new Integer (num), name);
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
android.util.Log.wtf ("EventLog", "Error in " + "/system/etc/event-log-tags" + ": " + line, e);
} else {
throw e;
}
}
}
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
android.util.Log.wtf ("EventLog", "Error reading /system/etc/event-log-tags", e);
} else {
throw e;
}
} finally {
try {
if (reader != null) reader.close ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
}
}, $fz.isPrivate = true, $fz));
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mBuffer = null;
Clazz.instantialize (this, arguments);
}, android.util.EventLog, "Event");
Clazz.makeConstructor (c$, 
function (a) {
this.mBuffer = java.nio.ByteBuffer.wrap (a);
this.mBuffer.order (java.nio.ByteOrder.nativeOrder ());
}, "~A");
Clazz.defineMethod (c$, "getProcessId", 
function () {
return this.mBuffer.getInt (4);
});
Clazz.defineMethod (c$, "getThreadId", 
function () {
return this.mBuffer.getInt (8);
});
Clazz.defineMethod (c$, "getTimeNanos", 
function () {
return this.mBuffer.getInt (12) * 1000000000 + this.mBuffer.getInt (16);
});
Clazz.defineMethod (c$, "getTag", 
function () {
return this.mBuffer.getInt (20);
});
Clazz.defineMethod (c$, "getData", 
function () {
try {
this.mBuffer.limit (20 + this.mBuffer.getShort (0));
this.mBuffer.position (24);
return this.decodeObject ();
} catch (e$$) {
if (Clazz.instanceOf (e$$, IllegalArgumentException)) {
var e = e$$;
{
android.util.Log.wtf ("EventLog", "Illegal entry payload: tag=" + this.getTag (), e);
return null;
}
} else if (Clazz.instanceOf (e$$, java.nio.BufferUnderflowException)) {
var e = e$$;
{
android.util.Log.wtf ("EventLog", "Truncated entry payload: tag=" + this.getTag (), e);
return null;
}
} else {
throw e$$;
}
}
});
Clazz.defineMethod (c$, "decodeObject", 
($fz = function () {
var a = this.mBuffer.get ();
switch (a) {
case 0:
return this.mBuffer.getInt ();
case 1:
return this.mBuffer.getLong ();
case 2:
try {
var b = this.mBuffer.getInt ();
var c = this.mBuffer.position ();
this.mBuffer.position (c + b);
return  String.instantialize (this.mBuffer.array (), c, b, "UTF-8");
} catch (e) {
if (Clazz.instanceOf (e, java.io.UnsupportedEncodingException)) {
android.util.Log.wtf ("EventLog", "UTF-8 is not supported", e);
return null;
} else {
throw e;
}
}
case 3:
var b = this.mBuffer.get ();
if (b < 0) b += 256;
var c =  new Array (b);
for (var d = 0; d < b; ++d) c[d] = this.decodeObject ();

return c;
default:
throw  new IllegalArgumentException ("Unknown entry type: " + a);
}
}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"LENGTH_OFFSET", 0,
"PROCESS_OFFSET", 4,
"THREAD_OFFSET", 8,
"SECONDS_OFFSET", 12,
"NANOSECONDS_OFFSET", 16,
"PAYLOAD_START", 20,
"TAG_OFFSET", 20,
"DATA_START", 24,
"INT_TYPE", 0,
"LONG_TYPE", 1,
"STRING_TYPE", 2,
"LIST_TYPE", 3);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "EventLog",
"TAGS_FILE", "/system/etc/event-log-tags",
"COMMENT_PATTERN", "^\\s*(#.*)?$",
"TAG_PATTERN", "^\\s*(\\d+)\\s+(\\w+)\\s*(\\(.*\\))?\\s*$",
"sTagCodes", null,
"sTagNames", null);
});
