﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.Pools", ["android.util.FinitePool", "$.SynchronizedPool"], function () {
c$ = Clazz.declareType (android.util, "Pools");
c$.simplePool = Clazz.defineMethod (c$, "simplePool", 
function (manager) {
return  new android.util.FinitePool (manager);
}, "android.util.PoolableManager");
c$.finitePool = Clazz.defineMethod (c$, "finitePool", 
function (manager, limit) {
return  new android.util.FinitePool (manager, limit);
}, "android.util.PoolableManager,~N");
c$.synchronizedPool = Clazz.defineMethod (c$, "synchronizedPool", 
function (pool) {
return  new android.util.SynchronizedPool (pool);
}, "android.util.Pool");
c$.synchronizedPool = Clazz.defineMethod (c$, "synchronizedPool", 
function (pool, lock) {
return  new android.util.SynchronizedPool (pool, lock);
}, "android.util.Pool,~O");
});
