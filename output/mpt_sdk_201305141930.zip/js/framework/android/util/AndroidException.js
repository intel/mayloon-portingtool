﻿Clazz.declarePackage ("android.util");
Clazz.load (["java.lang.Exception"], "android.util.AndroidException", null, function () {
c$ = Clazz.declareType (android.util, "AndroidException", Exception);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.util.AndroidException, []);
});
});
