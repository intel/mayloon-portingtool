﻿Clazz.declarePackage ("android.util");
Clazz.load (["java.lang.Enum"], "android.util.Xml", ["android.util.XmlPullAttributes", "java.io.UnsupportedEncodingException", "java.lang.AssertionError"], function () {
c$ = Clazz.declareType (android.util, "Xml");
c$.parse = Clazz.defineMethod (c$, "parse", 
function (xml, contentHandler) {
}, "~S,org.xml.sax.ContentHandler");
c$.parse = Clazz.defineMethod (c$, "parse", 
function ($in, contentHandler) {
}, "java.io.Reader,org.xml.sax.ContentHandler");
c$.parse = Clazz.defineMethod (c$, "parse", 
function ($in, encoding, contentHandler) {
}, "java.io.InputStream,android.util.Xml.Encoding,org.xml.sax.ContentHandler");
c$.newPullParser = Clazz.defineMethod (c$, "newPullParser", 
function () {
return null;
});
c$.newSerializer = Clazz.defineMethod (c$, "newSerializer", 
function () {
try {
return android.util.Xml.XmlSerializerFactory.instance.newSerializer ();
} catch (e) {
if (Clazz.instanceOf (e, org.xmlpull.v1.XmlPullParserException)) {
throw  new AssertionError (e);
} else {
throw e;
}
}
});
c$.findEncodingByName = Clazz.defineMethod (c$, "findEncodingByName", 
function (encodingName) {
if (encodingName == null) {
return android.util.Xml.Encoding.UTF_8;
}for (var encoding, $encoding = 0, $$encoding = android.util.Xml.Encoding.values (); $encoding < $$encoding.length && ((encoding = $$encoding[$encoding]) || true); $encoding++) {
if (encoding.expatName.equalsIgnoreCase (encodingName)) return encoding;
}
throw  new java.io.UnsupportedEncodingException (encodingName);
}, "~S");
c$.asAttributeSet = Clazz.defineMethod (c$, "asAttributeSet", 
function (parser) {
return (Clazz.instanceOf (parser, android.util.AttributeSet)) ? parser :  new android.util.XmlPullAttributes (parser);
}, "org.xmlpull.v1.XmlPullParser");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.expatName = null;
Clazz.instantialize (this, arguments);
}, android.util.Xml, "Encoding", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.expatName = a;
}, "~S");
Clazz.defineEnumConstant (c$, "US_ASCII", 0, ["US-ASCII"]);
Clazz.defineEnumConstant (c$, "UTF_8", 1, ["UTF-8"]);
Clazz.defineEnumConstant (c$, "UTF_16", 2, ["UTF-16"]);
Clazz.defineEnumConstant (c$, "ISO_8859_1", 3, ["ISO-8859-1"]);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.util.Xml, "XmlSerializerFactory");
Clazz.defineStatics (c$,
"TYPE", "org.kxml2.io.KXmlParser,org.kxml2.io.KXmlSerializer",
"instance", null);
{
($t$ = android.util.Xml.XmlSerializerFactory.instance = null, android.util.Xml.XmlSerializerFactory.prototype.instance = android.util.Xml.XmlSerializerFactory.instance, $t$);
}c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"FEATURE_RELAXED", "http://xmlpull.org/v1/doc/features.html#relaxed");
});
