﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.StateSet", ["java.lang.StringBuilder"], function () {
c$ = Clazz.declareType (android.util, "StateSet");
c$.isWildCard = Clazz.defineMethod (c$, "isWildCard", 
function (stateSetOrSpec) {
return stateSetOrSpec.length == 0 || stateSetOrSpec[0] == 0;
}, "~A");
c$.stateSetMatches = Clazz.defineMethod (c$, "stateSetMatches", 
function (stateSpec, stateSet) {
if (stateSet == null) {
return (stateSpec == null || android.util.StateSet.isWildCard (stateSpec));
}var stateSpecSize = stateSpec.length;
var stateSetSize = stateSet.length;
for (var i = 0; i < stateSpecSize; i++) {
var stateSpecState = stateSpec[i];
if (stateSpecState == 0) {
return true;
}var mustMatch;
if (stateSpecState > 0) {
mustMatch = true;
} else {
mustMatch = false;
stateSpecState = -stateSpecState;
}var found = false;
for (var j = 0; j < stateSetSize; j++) {
var state = stateSet[j];
if (state == 0) {
if (mustMatch) {
return false;
} else {
break;
}}if (state == stateSpecState) {
if (mustMatch) {
found = true;
break;
} else {
return false;
}}}
if (mustMatch && !found) {
return false;
}}
return true;
}, "~A,~A");
c$.stateSetMatches = Clazz.defineMethod (c$, "stateSetMatches", 
function (stateSpec, state) {
var stateSpecSize = stateSpec.length;
for (var i = 0; i < stateSpecSize; i++) {
var stateSpecState = stateSpec[i];
if (stateSpecState == 0) {
return true;
}if (stateSpecState > 0) {
if (state != stateSpecState) {
return false;
}} else {
if (state == -stateSpecState) {
return false;
}}}
return true;
}, "~A,~N");
c$.trimStateSet = Clazz.defineMethod (c$, "trimStateSet", 
function (states, newSize) {
if (states.length == newSize) {
return states;
}var trimmedStates =  Clazz.newArray (newSize, 0);
System.arraycopy (states, 0, trimmedStates, 0, newSize);
return trimmedStates;
}, "~A,~N");
c$.dump = Clazz.defineMethod (c$, "dump", 
function (states) {
var sb =  new StringBuilder ();
var count = states.length;
for (var i = 0; i < count; i++) {
switch (states[i]) {
case 16842909:
sb.append ("W ");
break;
case 16842919:
sb.append ("P ");
break;
case 16842913:
sb.append ("S ");
break;
case 16842908:
sb.append ("F ");
break;
case 16842910:
sb.append ("E ");
break;
}
}
return sb.toString ();
}, "~A");
Clazz.defineStatics (c$,
"WILD_CARD",  Clazz.newArray (0, 0));
});
