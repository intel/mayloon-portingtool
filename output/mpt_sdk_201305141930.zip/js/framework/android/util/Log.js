﻿Clazz.declarePackage ("android.util");
Clazz.load (["java.lang.Exception"], "android.util.Log", ["java.lang.NullPointerException"], function () {
c$ = Clazz.declareType (android.util, "Log");
c$.v = Clazz.defineMethod (c$, "v", 
function (tag, msg) {
return android.util.Log.println_native (0, 2, tag, msg);
}, "~S,~S");
c$.v = Clazz.defineMethod (c$, "v", 
function (tag, msg, tr) {
return android.util.Log.println_native (0, 2, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.d = Clazz.defineMethod (c$, "d", 
function (tag, msg) {
return android.util.Log.println_native (0, 3, tag, msg);
}, "~S,~S");
c$.d = Clazz.defineMethod (c$, "d", 
function (tag, msg, tr) {
return android.util.Log.println_native (0, 3, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.i = Clazz.defineMethod (c$, "i", 
function (tag, msg) {
return android.util.Log.println_native (0, 4, tag, msg);
}, "~S,~S");
c$.i = Clazz.defineMethod (c$, "i", 
function (tag, msg, tr) {
return android.util.Log.println_native (0, 4, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.w = Clazz.defineMethod (c$, "w", 
function (tag, msg) {
return android.util.Log.println_native (0, 5, tag, msg);
}, "~S,~S");
c$.w = Clazz.defineMethod (c$, "w", 
function (tag, msg, tr) {
return android.util.Log.println_native (0, 5, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.isLoggable = Clazz.defineMethod (c$, "isLoggable", 
function (tag, level) {
return true;
}, "~S,~N");
c$.w = Clazz.defineMethod (c$, "w", 
function (tag, tr) {
return android.util.Log.println_native (0, 5, tag, android.util.Log.getStackTraceString (tr));
}, "~S,Throwable");
c$.e = Clazz.defineMethod (c$, "e", 
function (tag, msg) {
return android.util.Log.println_native (0, 6, tag, msg);
}, "~S,~S");
c$.e = Clazz.defineMethod (c$, "e", 
function (tag, msg, tr) {
return android.util.Log.println_native (0, 6, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.wtf = Clazz.defineMethod (c$, "wtf", 
function (tag, msg) {
return android.util.Log.wtf (tag, msg, null);
}, "~S,~S");
c$.wtf = Clazz.defineMethod (c$, "wtf", 
function (tag, tr) {
return android.util.Log.wtf (tag, tr.getMessage (), tr);
}, "~S,Throwable");
c$.wtf = Clazz.defineMethod (c$, "wtf", 
function (tag, msg, tr) {
var what =  new android.util.Log.TerribleFailure (msg, tr);
var bytes = android.util.Log.println_native (0, 7, tag, android.util.Log.getStackTraceString (tr));
android.util.Log.sWtfHandler.onTerribleFailure (tag, what);
return bytes;
}, "~S,~S,Throwable");
c$.setWtfHandler = Clazz.defineMethod (c$, "setWtfHandler", 
function (handler) {
if (handler == null) {
throw  new NullPointerException ("handler == null");
}var oldHandler = android.util.Log.sWtfHandler;
($t$ = android.util.Log.sWtfHandler = handler, android.util.Log.prototype.sWtfHandler = android.util.Log.sWtfHandler, $t$);
return oldHandler;
}, "android.util.Log.TerribleFailureHandler");
c$.getStackTraceString = Clazz.defineMethod (c$, "getStackTraceString", 
function (tr) {
if (tr == null) {
return "";
}tr.printStackTrace ();
return null;
}, "Throwable");
c$.println = Clazz.defineMethod (c$, "println", 
function (priority, tag, msg) {
return android.util.Log.println_native (0, priority, tag, msg);
}, "~N,~S,~S");
c$.println_native = Clazz.defineMethod (c$, "println_native", 
function (bufID, priority, tag, msg) {
if (priority < 5) return 0;
switch (priority) {
case 2:
{
console.log(tag + ": " + msg);
}break;
case 3:
{
console.debug(tag + ": " + msg);
}break;
case 4:
{
console.info(tag + ": " + msg);
}break;
case 5:
{
console.warn(tag + ": " + msg);
}break;
case 6:
{
console.error(tag + ": " + msg);
}break;
case 7:
{
console.assert(tag + ": " + msg);
}break;
default:
break;
}
return 0;
}, "~N,~N,~S,~S");
c$.$Log$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.util, "Log$1", null, android.util.Log.TerribleFailureHandler);
Clazz.defineMethod (c$, "onTerribleFailure", 
function (tag, what) {
}, "~S,android.util.Log.TerribleFailure");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.declareType (android.util.Log, "TerribleFailure", Exception);
c$ = Clazz.p0p ();
Clazz.declareInterface (android.util.Log, "TerribleFailureHandler");
Clazz.defineStatics (c$,
"VERBOSE", 2,
"DEBUG", 3,
"INFO", 4,
"WARN", 5,
"ERROR", 6,
"ASSERT", 7,
"DEFAULT", 5);
c$.sWtfHandler = c$.prototype.sWtfHandler = ((Clazz.isClassDefined ("android.util.Log$1") ? 0 : android.util.Log.$Log$1$ ()), Clazz.innerTypeInstance (android.util.Log$1, this, null));
Clazz.defineStatics (c$,
"LOG_ID_MAIN", 0,
"LOG_ID_RADIO", 1,
"LOG_ID_EVENTS", 2,
"LOG_ID_SYSTEM", 3);
});
