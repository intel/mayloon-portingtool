﻿Clazz.declarePackage ("android.util");
Clazz.load (["android.util.Printer"], "android.util.PrintWriterPrinter", null, function () {
c$ = Clazz.declareType (android.util, "PrintWriterPrinter", null, android.util.Printer);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.overrideMethod (c$, "println", 
function (x) {
System.out.println (x);
}, "~S");
});
