﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.Time", ["java.util.Date"], function () {
c$ = Clazz.declareType (android.util, "Time");
c$.getCurrentTime = Clazz.defineMethod (c$, "getCurrentTime", 
function () {
var d =  new java.util.Date ();
var mYear = d.getYear () + 1900;
var mMonth = d.getMonth () + 1;
var mDay = d.getDate ();
var mHour = d.getHours ();
var mMinute = d.getMinutes ();
var mSecond = d.getSeconds ();
return mYear + "-" + mMonth + "-" + mDay + " " + android.util.Time.pad (mHour) + ":" + android.util.Time.pad (mMinute) + ":" + android.util.Time.pad (mSecond);
});
c$.pad = Clazz.defineMethod (c$, "pad", 
($fz = function (c) {
if (c >= 10) return String.valueOf (c);
 else return "0" + String.valueOf (c);
}, $fz.isPrivate = true, $fz), "~N");
});
