﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.SparseBooleanArray", ["android.util.ArrayUtils", "$.Log", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mKeys = null;
this.mValues = null;
this.mSize = 0;
Clazz.instantialize (this, arguments);
}, android.util, "SparseBooleanArray");
Clazz.makeConstructor (c$, 
function () {
this.construct (10);
});
Clazz.makeConstructor (c$, 
function (initialCapacity) {
initialCapacity = android.util.ArrayUtils.idealIntArraySize (initialCapacity);
this.mKeys =  Clazz.newArray (initialCapacity, 0);
this.mValues =  Clazz.newArray (initialCapacity, false);
this.mSize = 0;
}, "~N");
Clazz.defineMethod (c$, "get", 
function (key) {
return this.get (key, false);
}, "~N");
Clazz.defineMethod (c$, "get", 
function (key, valueIfKeyNotFound) {
var i = android.util.SparseBooleanArray.binarySearch (this.mKeys, 0, this.mSize, key);
if (i < 0) {
return valueIfKeyNotFound;
} else {
return this.mValues[i];
}}, "~N,~B");
Clazz.defineMethod (c$, "$delete", 
function (key) {
var i = android.util.SparseBooleanArray.binarySearch (this.mKeys, 0, this.mSize, key);
if (i >= 0) {
System.arraycopy (this.mKeys, i + 1, this.mKeys, i, this.mSize - (i + 1));
System.arraycopy (this.mValues, i + 1, this.mValues, i, this.mSize - (i + 1));
this.mSize--;
}}, "~N");
Clazz.defineMethod (c$, "put", 
function (key, value) {
var i = android.util.SparseBooleanArray.binarySearch (this.mKeys, 0, this.mSize, key);
if (i >= 0) {
this.mValues[i] = value;
} else {
i = ~i;
if (this.mSize >= this.mKeys.length) {
var n = android.util.ArrayUtils.idealIntArraySize (this.mSize + 1);
var nkeys =  Clazz.newArray (n, 0);
var nvalues =  Clazz.newArray (n, false);
System.arraycopy (this.mKeys, 0, nkeys, 0, this.mKeys.length);
System.arraycopy (this.mValues, 0, nvalues, 0, this.mValues.length);
this.mKeys = nkeys;
this.mValues = nvalues;
}if (this.mSize - i != 0) {
System.arraycopy (this.mKeys, i, this.mKeys, i + 1, this.mSize - i);
System.arraycopy (this.mValues, i, this.mValues, i + 1, this.mSize - i);
}this.mKeys[i] = key;
this.mValues[i] = value;
this.mSize++;
}}, "~N,~B");
Clazz.defineMethod (c$, "size", 
function () {
return this.mSize;
});
Clazz.defineMethod (c$, "keyAt", 
function (index) {
return this.mKeys[index];
}, "~N");
Clazz.defineMethod (c$, "valueAt", 
function (index) {
return this.mValues[index];
}, "~N");
Clazz.defineMethod (c$, "indexOfKey", 
function (key) {
return android.util.SparseBooleanArray.binarySearch (this.mKeys, 0, this.mSize, key);
}, "~N");
Clazz.defineMethod (c$, "indexOfValue", 
function (value) {
for (var i = 0; i < this.mSize; i++) if (this.mValues[i] == value) return i;

return -1;
}, "~B");
Clazz.defineMethod (c$, "clear", 
function () {
this.mSize = 0;
});
Clazz.defineMethod (c$, "append", 
function (key, value) {
if (this.mSize != 0 && key <= this.mKeys[this.mSize - 1]) {
this.put (key, value);
return ;
}var pos = this.mSize;
if (pos >= this.mKeys.length) {
var n = android.util.ArrayUtils.idealIntArraySize (pos + 1);
var nkeys =  Clazz.newArray (n, 0);
var nvalues =  Clazz.newArray (n, false);
System.arraycopy (this.mKeys, 0, nkeys, 0, this.mKeys.length);
System.arraycopy (this.mValues, 0, nvalues, 0, this.mValues.length);
this.mKeys = nkeys;
this.mValues = nvalues;
}this.mKeys[pos] = key;
this.mValues[pos] = value;
this.mSize = pos + 1;
}, "~N,~B");
c$.binarySearch = Clazz.defineMethod (c$, "binarySearch", 
($fz = function (a, start, len, key) {
var high = start + len;
var low = start - 1;
var guess;
while (high - low > 1) {
guess = Math.floor ((high + low) / 2);
if (a[guess] < key) low = guess;
 else high = guess;
}
if (high == start + len) return ~(start + len);
 else if (a[high] == key) return high;
 else return ~high;
}, $fz.isPrivate = true, $fz), "~A,~N,~N,~N");
});
