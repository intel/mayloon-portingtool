﻿Clazz.declarePackage ("android.util");
Clazz.load (null, "android.util.Slog", ["android.util.Log"], function () {
c$ = Clazz.declareType (android.util, "Slog");
c$.v = Clazz.defineMethod (c$, "v", 
function (tag, msg) {
return android.util.Log.println_native (3, 2, tag, msg);
}, "~S,~S");
c$.v = Clazz.defineMethod (c$, "v", 
function (tag, msg, tr) {
return android.util.Log.println_native (3, 2, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.d = Clazz.defineMethod (c$, "d", 
function (tag, msg) {
return android.util.Log.println_native (3, 3, tag, msg);
}, "~S,~S");
c$.d = Clazz.defineMethod (c$, "d", 
function (tag, msg, tr) {
return android.util.Log.println_native (3, 3, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.i = Clazz.defineMethod (c$, "i", 
function (tag, msg) {
return android.util.Log.println_native (3, 4, tag, msg);
}, "~S,~S");
c$.i = Clazz.defineMethod (c$, "i", 
function (tag, msg, tr) {
return android.util.Log.println_native (3, 4, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.w = Clazz.defineMethod (c$, "w", 
function (tag, msg) {
return android.util.Log.println_native (3, 5, tag, msg);
}, "~S,~S");
c$.w = Clazz.defineMethod (c$, "w", 
function (tag, msg, tr) {
return android.util.Log.println_native (3, 5, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.w = Clazz.defineMethod (c$, "w", 
function (tag, tr) {
return android.util.Log.println_native (3, 5, tag, android.util.Log.getStackTraceString (tr));
}, "~S,Throwable");
c$.e = Clazz.defineMethod (c$, "e", 
function (tag, msg) {
return android.util.Log.println_native (3, 6, tag, msg);
}, "~S,~S");
c$.e = Clazz.defineMethod (c$, "e", 
function (tag, msg, tr) {
return android.util.Log.println_native (3, 6, tag, msg + '\n' + android.util.Log.getStackTraceString (tr));
}, "~S,~S,Throwable");
c$.println = Clazz.defineMethod (c$, "println", 
function (priority, tag, msg) {
return android.util.Log.println_native (3, priority, tag, msg);
}, "~N,~S,~S");
});
