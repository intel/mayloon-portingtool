﻿Clazz.declarePackage ("android.util");
c$ = Clazz.declareType (android.util, "TimeUtils");
c$.getTimeZone = Clazz.defineMethod (c$, "getTimeZone", 
function (offset, dst, when, country) {
if (country == null) {
return null;
}var best = null;
return best;
}, "~N,~B,~N,~S");
c$.getTimeZoneDatabaseVersion = Clazz.defineMethod (c$, "getTimeZoneDatabaseVersion", 
function () {
return "";
});
c$.accumField = Clazz.defineMethod (c$, "accumField", 
($fz = function (amt, suffix, always, zeropad) {
if (amt > 99 || (always && zeropad >= 3)) {
return 3 + suffix;
}if (amt > 9 || (always && zeropad >= 2)) {
return 2 + suffix;
}if (always || amt > 0) {
return 1 + suffix;
}return 0;
}, $fz.isPrivate = true, $fz), "~N,~N,~B,~N");
c$.printField = Clazz.defineMethod (c$, "printField", 
($fz = function (formatStr, amt, suffix, pos, always, zeropad) {
if (always || amt > 0) {
if ((always && zeropad >= 3) || amt > 99) {
var dig = Math.floor (amt / 100);
formatStr[pos] = String.fromCharCode ((dig + ('0').charCodeAt (0)));
pos++;
always = true;
amt -= (dig * 100);
}if ((always && zeropad >= 2) || amt > 9) {
var dig = Math.floor (amt / 10);
formatStr[pos] = String.fromCharCode ((dig + ('0').charCodeAt (0)));
pos++;
always = true;
amt -= (dig * 10);
}formatStr[pos] = String.fromCharCode ((amt + ('0').charCodeAt (0)));
pos++;
formatStr[pos] = suffix;
pos++;
}return pos;
}, $fz.isPrivate = true, $fz), "~A,~N,~N,~N,~B,~N");
c$.formatDurationLocked = Clazz.defineMethod (c$, "formatDurationLocked", 
($fz = function (duration, fieldLen) {
if (android.util.TimeUtils.sFormatStr.length < fieldLen) {
($t$ = android.util.TimeUtils.sFormatStr =  Clazz.newArray (fieldLen, '\0'), android.util.TimeUtils.prototype.sFormatStr = android.util.TimeUtils.sFormatStr, $t$);
}var formatStr = android.util.TimeUtils.sFormatStr;
if (duration == 0) {
var pos = 0;
fieldLen -= 1;
while (pos < fieldLen) {
formatStr[pos] = ' ';
}
formatStr[pos] = '0';
return pos + 1;
}var prefix;
if (duration > 0) {
prefix = '+';
} else {
prefix = '-';
duration = -duration;
}var millis = (duration % 1000);
var seconds = Math.round (Math.floor (Math.floor (duration / 1000)));
var days = 0;
var hours = 0;
var minutes = 0;
if (seconds > 86400) {
days = Math.floor (seconds / 86400);
seconds -= days * 86400;
}if (seconds > 3600) {
hours = Math.floor (seconds / 3600);
seconds -= hours * 3600;
}if (seconds > 60) {
minutes = Math.floor (seconds / 60);
seconds -= minutes * 60;
}var pos = 0;
if (fieldLen != 0) {
var myLen = android.util.TimeUtils.accumField (days, 1, false, 0);
myLen += android.util.TimeUtils.accumField (hours, 1, myLen > 0, 2);
myLen += android.util.TimeUtils.accumField (minutes, 1, myLen > 0, 2);
myLen += android.util.TimeUtils.accumField (seconds, 1, myLen > 0, 2);
myLen += android.util.TimeUtils.accumField (millis, 2, true, myLen > 0 ? 3 : 0) + 1;
while (myLen < fieldLen) {
formatStr[pos] = ' ';
pos++;
myLen++;
}
}formatStr[pos] = prefix;
pos++;
var start = pos;
var zeropad = fieldLen != 0;
pos = android.util.TimeUtils.printField (formatStr, days, 'd', pos, false, 0);
pos = android.util.TimeUtils.printField (formatStr, hours, 'h', pos, pos != start, zeropad ? 2 : 0);
pos = android.util.TimeUtils.printField (formatStr, minutes, 'm', pos, pos != start, zeropad ? 2 : 0);
pos = android.util.TimeUtils.printField (formatStr, seconds, 's', pos, pos != start, zeropad ? 2 : 0);
pos = android.util.TimeUtils.printField (formatStr, millis, 'm', pos, true, (zeropad && pos != start) ? 3 : 0);
formatStr[pos] = 's';
return pos + 1;
}, $fz.isPrivate = true, $fz), "~N,~N");
c$.formatDuration = Clazz.defineMethod (c$, "formatDuration", 
function (duration, builder) {
{
var len = android.util.TimeUtils.formatDurationLocked (duration, 0);
builder.append (android.util.TimeUtils.sFormatStr, 0, len);
}}, "~N,StringBuilder");
c$.formatDuration = Clazz.defineMethod (c$, "formatDuration", 
function (duration, fieldLen) {
{
var len = android.util.TimeUtils.formatDurationLocked (duration, fieldLen);
System.out.println ( String.instantialize (android.util.TimeUtils.sFormatStr, 0, len));
}}, "~N,~N");
c$.formatDuration = Clazz.defineMethod (c$, "formatDuration", 
function (duration) {
android.util.TimeUtils.formatDuration (duration, 0);
}, "~N");
c$.formatDuration = Clazz.defineMethod (c$, "formatDuration", 
function (time, now) {
if (time == 0) {
System.out.println ("--");
return ;
}android.util.TimeUtils.formatDuration (time - now, 0);
}, "~N,~N");
Clazz.defineStatics (c$,
"TAG", "TimeUtils",
"HUNDRED_DAY_FIELD_LEN", 19,
"SECONDS_PER_MINUTE", 60,
"SECONDS_PER_HOUR", 3600,
"SECONDS_PER_DAY", 86400);
c$.sFormatSync = c$.prototype.sFormatSync =  new JavaObject ();
Clazz.defineStatics (c$,
"sFormatStr",  Clazz.newArray (24, '\0'));
