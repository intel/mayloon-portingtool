﻿Clazz.declarePackage ("android.test");
Clazz.declareInterface (android.test, "PerformanceTestCase");
Clazz.declareInterface (android.test.PerformanceTestCase, "Intermediates");
