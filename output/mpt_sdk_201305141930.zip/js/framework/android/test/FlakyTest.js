﻿Clazz.declarePackage ("android.test");
