﻿Clazz.declarePackage ("android.test.suitebuilder.annotation");
