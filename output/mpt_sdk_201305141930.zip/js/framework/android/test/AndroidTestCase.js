﻿Clazz.declarePackage ("android.test");
Clazz.load (["junit.framework.TestCase"], "android.test.AndroidTestCase", ["android.content.ContentValues", "$.Intent", "android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mContext = null;
this.mTestContext = null;
Clazz.instantialize (this, arguments);
}, android.test, "AndroidTestCase", junit.framework.TestCase);
Clazz.defineMethod (c$, "testAndroidTestCaseSetupProperly", 
function () {
junit.framework.Assert.assertNotNull ("Context is null. setContext should be called before tests are run", this.mContext);
});
Clazz.defineMethod (c$, "setContext", 
function (context) {
this.mContext = context;
}, "android.content.Context");
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.defineMethod (c$, "setTestContext", 
function (context) {
this.mTestContext = context;
}, "android.content.Context");
Clazz.defineMethod (c$, "getTestContext", 
function () {
return this.mTestContext;
});
Clazz.defineMethod (c$, "assertActivityRequiresPermission", 
function (packageName, className, permission) {
var intent =  new android.content.Intent ();
intent.setClassName (packageName, className);
intent.addFlags (268435456);
try {
this.getContext ().startActivity (intent);
junit.framework.Assert.fail ("expected security exception for " + permission);
} catch (expected) {
if (Clazz.instanceOf (expected, SecurityException)) {
junit.framework.Assert.assertNotNull ("security exception's error message.", expected.getMessage ());
junit.framework.Assert.assertTrue ("error message should contain " + permission + ".", expected.getMessage ().contains (permission));
} else {
throw expected;
}
}
}, "~S,~S,~S");
Clazz.defineMethod (c$, "assertReadingContentUriRequiresPermission", 
function (uri, permission) {
try {
this.getContext ().getContentResolver ().query (uri, null, null, null, null);
junit.framework.Assert.fail ("expected SecurityException requiring " + permission);
} catch (expected) {
if (Clazz.instanceOf (expected, SecurityException)) {
junit.framework.Assert.assertNotNull ("security exception's error message.", expected.getMessage ());
junit.framework.Assert.assertTrue ("error message should contain " + permission + ".", expected.getMessage ().contains (permission));
} else {
throw expected;
}
}
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "assertWritingContentUriRequiresPermission", 
function (uri, permission) {
try {
this.getContext ().getContentResolver ().insert (uri,  new android.content.ContentValues ());
junit.framework.Assert.fail ("expected SecurityException requiring " + permission);
} catch (expected) {
if (Clazz.instanceOf (expected, SecurityException)) {
junit.framework.Assert.assertNotNull ("security exception's error message.", expected.getMessage ());
junit.framework.Assert.assertTrue ("error message should contain " + permission + ".", expected.getMessage ().contains (permission));
} else {
throw expected;
}
}
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "scrubClass", 
function (testCaseClass) {
var fields = this.getClass ().getDeclaredFields ();
for (var field, $field = 0, $$field = fields; $field < $$field.length && ((field = $$field[$field]) || true); $field++) {
var fieldClass = field.getDeclaringClass ();
if (testCaseClass.isAssignableFrom (fieldClass) && !field.getType ().isPrimitive ()) {
try {
field.setAccessible (true);
field.set (this, null);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.d ("TestCase", "Error: Could not nullify field!");
} else {
throw e;
}
}
if (field.get (this) != null) {
android.util.Log.d ("TestCase", "Error: Could not nullify field!");
}}}
}, "Class");
});
