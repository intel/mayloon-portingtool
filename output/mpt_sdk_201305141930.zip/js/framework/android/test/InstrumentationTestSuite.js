﻿Clazz.declarePackage ("android.test");
Clazz.load (["junit.framework.TestSuite"], "android.test.InstrumentationTestSuite", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mInstrumentation = null;
Clazz.instantialize (this, arguments);
}, android.test, "InstrumentationTestSuite", junit.framework.TestSuite);
Clazz.makeConstructor (c$, 
function (instr) {
Clazz.superConstructor (this, android.test.InstrumentationTestSuite, []);
this.mInstrumentation = instr;
}, "android.app.Instrumentation");
Clazz.makeConstructor (c$, 
function (name, instr) {
Clazz.superConstructor (this, android.test.InstrumentationTestSuite, [name]);
this.mInstrumentation = instr;
}, "~S,android.app.Instrumentation");
Clazz.makeConstructor (c$, 
function (theClass, instr) {
Clazz.superConstructor (this, android.test.InstrumentationTestSuite, [theClass]);
this.mInstrumentation = instr;
}, "Class,android.app.Instrumentation");
Clazz.overrideMethod (c$, "addTestSuite", 
function (testClass) {
this.addTest ( new android.test.InstrumentationTestSuite (testClass, this.mInstrumentation));
}, "Class");
Clazz.defineMethod (c$, "runTest", 
function (test, result) {
if (Clazz.instanceOf (test, android.test.InstrumentationTestCase)) {
(test).injectInstrumentation (this.mInstrumentation);
}Clazz.superCall (this, android.test.InstrumentationTestSuite, "runTest", [test, result]);
}, "junit.framework.Test,junit.framework.TestResult");
});
