﻿Clazz.declarePackage ("android.test");
Clazz.load (["junit.framework.TestCase"], "android.test.InstrumentationTestCase", ["android.content.Intent", "android.test.FlakyTest", "$.UiThreadTest", "android.util.Log", "android.view.KeyEvent", "java.lang.IllegalArgumentException", "java.lang.reflect.Modifier"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mInstrumentation = null;
Clazz.instantialize (this, arguments);
}, android.test, "InstrumentationTestCase", junit.framework.TestCase);
Clazz.defineMethod (c$, "injectInstrumentation", 
function (instrumentation) {
this.mInstrumentation = instrumentation;
}, "android.app.Instrumentation");
Clazz.defineMethod (c$, "injectInsrumentation", 
function (instrumentation) {
this.injectInstrumentation (instrumentation);
}, "android.app.Instrumentation");
Clazz.defineMethod (c$, "getInstrumentation", 
function () {
return this.mInstrumentation;
});
Clazz.defineMethod (c$, "launchActivity", 
function (pkg, activityCls, extras) {
var intent =  new android.content.Intent ("android.intent.action.MAIN");
if (extras != null) {
intent.putExtras (extras);
}return this.launchActivityWithIntent (pkg, activityCls, intent);
}, "~S,Class,android.os.Bundle");
Clazz.defineMethod (c$, "launchActivityWithIntent", 
function (pkg, activityCls, intent) {
intent.setClassName (pkg, activityCls.getName ());
intent.addFlags (268435456);
var activity = this.getInstrumentation ().startActivitySync (intent);
return activity;
}, "~S,Class,android.content.Intent");
Clazz.defineMethod (c$, "runTestOnUiThread", 
function (r) {
var exceptions =  new Array (1);
this.getInstrumentation ().runOnMainSync (((Clazz.isClassDefined ("android.test.InstrumentationTestCase$1") ? 0 : android.test.InstrumentationTestCase.$InstrumentationTestCase$1$ ()), Clazz.innerTypeInstance (android.test.InstrumentationTestCase$1, this, Clazz.cloneFinals ("r", r, "exceptions", exceptions))));
if (exceptions[0] != null) {
throw exceptions[0];
}}, "Runnable");
Clazz.overrideMethod (c$, "runTest", 
function () {
var fName = this.getName ();
junit.framework.Assert.assertNotNull (fName);
var method = null;
try {
method = this.getClass ().getMethod (fName, [null]);
} catch (e) {
if (Clazz.instanceOf (e, NoSuchMethodException)) {
junit.framework.Assert.fail ("Method \"" + fName + "\" not found");
} else {
throw e;
}
}
if (!java.lang.reflect.Modifier.isPublic (method.getModifiers ())) {
junit.framework.Assert.fail ("Method \"" + fName + "\" should be public");
}var runCount = 1;
if (method.isAnnotationPresent (android.test.FlakyTest)) {
runCount = method.getAnnotation (android.test.FlakyTest).tolerance ();
}if (method.isAnnotationPresent (android.test.UiThreadTest)) {
var tolerance = runCount;
var testMethod = method;
var exceptions =  new Array (1);
this.getInstrumentation ().runOnMainSync (((Clazz.isClassDefined ("android.test.InstrumentationTestCase$2") ? 0 : android.test.InstrumentationTestCase.$InstrumentationTestCase$2$ ()), Clazz.innerTypeInstance (android.test.InstrumentationTestCase$2, this, Clazz.cloneFinals ("testMethod", testMethod, "tolerance", tolerance, "exceptions", exceptions))));
if (exceptions[0] != null) {
throw exceptions[0];
}} else {
this.runMethod (method, runCount);
}});
Clazz.defineMethod (c$, "runMethod", 
($fz = function (runMethod, tolerance) {
var exception = null;
var runCount = 0;
do {
try {
runMethod.invoke (this, [null]);
exception = null;
} catch (e$$) {
if (Clazz.instanceOf (e$$, java.lang.reflect.InvocationTargetException)) {
var e = e$$;
{
e.fillInStackTrace ();
exception = e.getTargetException ();
}
} else if (Clazz.instanceOf (e$$, IllegalAccessException)) {
var e = e$$;
{
e.fillInStackTrace ();
exception = e;
}
} else {
throw e$$;
}
} finally {
runCount++;
}
} while ((runCount < tolerance) && (exception != null));
if (exception != null) {
throw exception;
}}, $fz.isPrivate = true, $fz), "java.lang.reflect.Method,~N");
Clazz.defineMethod (c$, "sendKeys", 
function (keysSequence) {
var keys = keysSequence.$plit (" ");
var count = keys.length;
var instrumentation = this.getInstrumentation ();
for (var i = 0; i < count; i++) {
var key = keys[i];
var repeater = key.indexOf ('*');
var keyCount;
try {
keyCount = repeater == -1 ? 1 : Integer.parseInt (key.substring (0, repeater));
} catch (e) {
if (Clazz.instanceOf (e, NumberFormatException)) {
android.util.Log.w ("ActivityTestCase", "Invalid repeat count: " + key);
continue ;} else {
throw e;
}
}
if (repeater != -1) {
key = key.substring (repeater + 1);
}for (var j = 0; j < keyCount; j++) {
try {
var keyCodeField = android.view.KeyEvent.getField ("KEYCODE_" + key);
var keyCode = keyCodeField.getInt (null);
try {
instrumentation.sendKeyDownUpSync (keyCode, 0);
} catch (e) {
if (Clazz.instanceOf (e, SecurityException)) {
} else {
throw e;
}
}
} catch (e$$) {
if (Clazz.instanceOf (e$$, NoSuchFieldException)) {
var e = e$$;
{
android.util.Log.w ("ActivityTestCase", "Unknown keycode: KEYCODE_" + key);
break;
}
} else if (Clazz.instanceOf (e$$, IllegalAccessException)) {
var e = e$$;
{
android.util.Log.w ("ActivityTestCase", "Unknown keycode: KEYCODE_" + key);
break;
}
} else {
throw e$$;
}
}
}
}
instrumentation.waitForIdleSync ();
}, "~S");
Clazz.defineMethod (c$, "sendKeys", 
function (keys) {
var count = keys.length;
var instrumentation = this.getInstrumentation ();
for (var i = 0; i < count; i++) {
try {
instrumentation.sendKeyDownUpSync (keys[i], 0);
} catch (e) {
if (Clazz.instanceOf (e, SecurityException)) {
} else {
throw e;
}
}
}
instrumentation.waitForIdleSync ();
}, "~A");
Clazz.defineMethod (c$, "sendRepeatedKeys", 
function (keys) {
var count = keys.length;
if ((count & 0x1) == 0x1) {
throw  new IllegalArgumentException ("The size of the keys array must be a multiple of 2");
}var instrumentation = this.getInstrumentation ();
for (var i = 0; i < count; i += 2) {
var keyCount = keys[i];
var keyCode = keys[i + 1];
for (var j = 0; j < keyCount; j++) {
try {
instrumentation.sendKeyDownUpSync (keyCode, 0);
} catch (e) {
if (Clazz.instanceOf (e, SecurityException)) {
} else {
throw e;
}
}
}
}
instrumentation.waitForIdleSync ();
}, "~A");
c$.$InstrumentationTestCase$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.test, "InstrumentationTestCase$1", null, Runnable);
Clazz.defineMethod (c$, "run", 
function () {
try {
this.f$.r.run ();
} catch (throwable) {
this.f$.exceptions[0] = throwable;
}
});
c$ = Clazz.p0p ();
};
c$.$InstrumentationTestCase$2$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.test, "InstrumentationTestCase$2", null, Runnable);
Clazz.defineMethod (c$, "run", 
function () {
try {
this.b$["android.test.InstrumentationTestCase"].runMethod (this.f$.testMethod, this.f$.tolerance);
} catch (throwable) {
this.f$.exceptions[0] = throwable;
}
});
c$ = Clazz.p0p ();
};
});
