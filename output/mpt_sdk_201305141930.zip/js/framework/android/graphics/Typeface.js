﻿Clazz.declarePackage ("android.graphics");
Clazz.load (null, "android.graphics.Typeface", ["java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.familyName = null;
this.style = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "Typeface");
Clazz.defineMethod (c$, "getStyle", 
function () {
return this.style;
});
Clazz.defineMethod (c$, "getStyleName", 
function () {
switch (this.getStyle ()) {
case 0:
return "normal";
case 1:
return "bold";
case 2:
return "italic";
case 3:
default:
return "bold-italic";
}
});
Clazz.defineMethod (c$, "getFamilyName", 
function () {
return this.familyName;
});
Clazz.defineMethod (c$, "isBold", 
function () {
return (this.getStyle () & 1) != 0;
});
Clazz.defineMethod (c$, "isItalic", 
function () {
return (this.getStyle () & 2) != 0;
});
Clazz.makeConstructor (c$, 
function (familyName, style) {
this.familyName = familyName;
this.style = style;
}, "~S,~N");
c$.create = Clazz.defineMethod (c$, "create", 
function (familyName, style) {
return  new android.graphics.Typeface (familyName, style);
}, "~S,~N");
c$.create = Clazz.defineMethod (c$, "create", 
function (family, style) {
return android.graphics.Typeface.create (family.familyName, style);
}, "android.graphics.Typeface,~N");
c$.defaultFromStyle = Clazz.defineMethod (c$, "defaultFromStyle", 
function (style) {
return android.graphics.Typeface.sDefaults[style];
}, "~N");
c$.createFromFile = Clazz.defineMethod (c$, "createFromFile", 
function (path) {
console.log("Missing method: createFromFile");
}, "~S");
Clazz.overrideMethod (c$, "finalize", 
function () {
console.log("Missing method: finalize");
});
c$.createFromFile = Clazz.defineMethod (c$, "createFromFile", 
function (path) {
console.log("Missing method: createFromFile");
}, "java.io.File");
Clazz.defineStatics (c$,
"DEFAULT", null,
"DEFAULT_BOLD", null,
"SANS_SERIF", null,
"SERIF", null,
"MONOSPACE", null,
"sDefaults", null,
"NORMAL", 0,
"BOLD", 1,
"ITALIC", 2,
"BOLD_ITALIC", 3);
{
($t$ = android.graphics.Typeface.DEFAULT = android.graphics.Typeface.create (Clazz.castNullAs ("String"), 0), android.graphics.Typeface.prototype.DEFAULT = android.graphics.Typeface.DEFAULT, $t$);
($t$ = android.graphics.Typeface.DEFAULT_BOLD = android.graphics.Typeface.create (Clazz.castNullAs ("String"), 1), android.graphics.Typeface.prototype.DEFAULT_BOLD = android.graphics.Typeface.DEFAULT_BOLD, $t$);
($t$ = android.graphics.Typeface.SANS_SERIF = android.graphics.Typeface.create ("sans-serif", 0), android.graphics.Typeface.prototype.SANS_SERIF = android.graphics.Typeface.SANS_SERIF, $t$);
($t$ = android.graphics.Typeface.SERIF = android.graphics.Typeface.create ("serif", 0), android.graphics.Typeface.prototype.SERIF = android.graphics.Typeface.SERIF, $t$);
($t$ = android.graphics.Typeface.MONOSPACE = android.graphics.Typeface.create ("monospace", 0), android.graphics.Typeface.prototype.MONOSPACE = android.graphics.Typeface.MONOSPACE, $t$);
($t$ = android.graphics.Typeface.sDefaults = [android.graphics.Typeface.DEFAULT, android.graphics.Typeface.DEFAULT_BOLD, android.graphics.Typeface.create (Clazz.castNullAs ("String"), 2), android.graphics.Typeface.create (Clazz.castNullAs ("String"), 3)], android.graphics.Typeface.prototype.sDefaults = android.graphics.Typeface.sDefaults, $t$);
}});
