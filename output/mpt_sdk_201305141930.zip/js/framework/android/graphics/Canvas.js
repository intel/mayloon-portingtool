﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["java.lang.Enum", "android.graphics.Rect", "java.util.ArrayList", "$.HashMap"], "android.graphics.Canvas", ["android.graphics.Color", "$.Matrix", "$.Paint", "$.Path", "$.PorterDuff", "android.util.Log", "java.lang.ArrayIndexOutOfBoundsException", "$.IllegalArgumentException", "$.IllegalStateException", "$.IndexOutOfBoundsException", "$.NullPointerException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDensity = 0;
this.saveCount = 0;
this.transList = null;
this._ddx = 0;
this._ddy = 0;
this._width = 0;
this._height = 0;
this.ctm = null;
this.mClipBounds = null;
if (!Clazz.isClassDefined ("android.graphics.Canvas.CanvasState")) {
android.graphics.Canvas.$Canvas$CanvasState$ ();
}
this.mBM = null;
this.appCanvasID = null;
this.surfaceViewCanvasID = null;
this.canvasType = 0;
this.activeCanvas = null;
this.opaqueFlag = false;
Clazz.instantialize (this, arguments);
}, android.graphics, "Canvas");
Clazz.prepareFields (c$, function () {
this.transList =  new java.util.ArrayList ();
this.mClipBounds =  new android.graphics.Rect ();
});
Clazz.defineMethod (c$, "getCanvasID", 
function () {
return this.appCanvasID;
});
Clazz.defineMethod (c$, "getSurfaceViewCanvasID", 
function () {
return this.surfaceViewCanvasID;
});
Clazz.defineMethod (c$, "initPaintCapAndJoinMap", 
($fz = function () {
android.graphics.Canvas.paintCapAndJoinMap.put (android.graphics.Paint.Cap.BUTT, "butt");
android.graphics.Canvas.paintCapAndJoinMap.put (android.graphics.Paint.Cap.ROUND, "round");
android.graphics.Canvas.paintCapAndJoinMap.put (android.graphics.Paint.Cap.SQUARE, "square");
android.graphics.Canvas.paintCapAndJoinMap.put (android.graphics.Paint.Join.MITER, "miter");
android.graphics.Canvas.paintCapAndJoinMap.put (android.graphics.Paint.Join.ROUND, "round");
android.graphics.Canvas.paintCapAndJoinMap.put (android.graphics.Paint.Join.BEVEL, "bevel");
android.graphics.Canvas.paintCapAndJoinMap.put (android.graphics.Paint.Align.LEFT, "left");
android.graphics.Canvas.paintCapAndJoinMap.put (android.graphics.Paint.Align.CENTER, "center");
android.graphics.Canvas.paintCapAndJoinMap.put (android.graphics.Paint.Align.RIGHT, "right");
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "initSave", 
($fz = function () {
this.saveCount++;
var state = Clazz.innerTypeInstance (android.graphics.Canvas.CanvasState, this, null);
state._rect =  new android.graphics.Rect (this._ddx, this._ddy, this._ddx + this._width, this._ddy + this._height);
state._clipBounds =  new android.graphics.Rect (this.mClipBounds);
state._ctm =  new android.graphics.Matrix (this.ctm);
this.transList.add (state);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "chooseCanvas", 
function (_canvasType) {
this.canvasType = _canvasType;
if (this.canvasType == android.graphics.Canvas.APP_CANVAS) {
this.activeCanvas = this.appCanvasID;
} else if (this.canvasType == android.graphics.Canvas.SURFACEVIEW_CANVAS) {
this.activeCanvas = this.surfaceViewCanvasID;
}}, "~N");
Clazz.defineMethod (c$, "getHTML5CanvasID", 
function () {
return this.activeCanvas;
});
Clazz.makeConstructor (c$, 
function (bitmap) {
if (!bitmap.isMutable ()) {
throw  new IllegalStateException ("Immutable bitmap passed to Canvas constructor");
}android.graphics.Canvas.throwIfRecycled (bitmap);
this.mBM = bitmap;
this.appCanvasID = null;
this.surfaceViewCanvasID = null;
this.ctm =  new android.graphics.Matrix ();
this.mBM.ensureCachedCanvas (new Boolean (false), new Boolean (false));
this.initPaintCapAndJoinMap ();
this.initSave ();
}, "android.graphics.Bitmap");
Clazz.makeConstructor (c$, 
function (canvasID) {
this.appCanvasID = canvasID;
this.surfaceViewCanvasID = null;
this.ctm =  new android.graphics.Matrix ();
this.chooseCanvas (android.graphics.Canvas.APP_CANVAS);
this.initPaintCapAndJoinMap ();
this.initSave ();
}, "~S");
Clazz.makeConstructor (c$, 
function (canvasID, surfaceViewCanvasID) {
this.appCanvasID = canvasID;
this.surfaceViewCanvasID = surfaceViewCanvasID;
this.ctm =  new android.graphics.Matrix ();
this.initPaintCapAndJoinMap ();
this.initSave ();
}, "~S,~S");
Clazz.makeConstructor (c$, 
function () {
this.appCanvasID = null;
this.surfaceViewCanvasID = null;
this.ctm =  new android.graphics.Matrix ();
this.clipRect (0, 0, this.getWidth (), this.getHeight ());
this.initPaintCapAndJoinMap ();
this.initSave ();
});
Clazz.defineMethod (c$, "setOpaque", 
function (opaque) {
this.opaqueFlag = opaque;
}, "~B");
Clazz.defineMethod (c$, "isOpaque", 
function () {
return this.opaqueFlag;
});
Clazz.defineMethod (c$, "setHTML5CanvasContext", 
($fz = function (paint) {
var rgb = android.graphics.Color.toString (paint.getColor ());
var strokeWidth = paint.getStrokeWidth ();
var strokeCap = android.graphics.Canvas.paintCapAndJoinMap.get (paint.getStrokeCap ());
var strokeJoin = android.graphics.Canvas.paintCapAndJoinMap.get (paint.getStrokeJoin ());
var strokeMiter = paint.getStrokeMiter ();
var typeface = paint.getTypeface ();
var textAlign = android.graphics.Canvas.paintCapAndJoinMap.get (paint.getTextAlign ());
var font = null;
typeface = null;
if (typeface != null) {
font = typeface.getStyleName ();
font += " ";
font += paint.getTextSize ();
font += " ";
font += typeface.getFamilyName ();
} else {
font = paint.setFontCanvasProperties ();
}var shader = paint.getShader ();
var shaderType = paint.getShaderType ();
var canvas = null;
if (this.mBM != null) {
canvas = this.mBM.mCachedCanvas;
} else {
canvas  = document.getElementById(this.activeCanvas);
}
var context = canvas.getContext("2d");
// line style setting
context.fillStyle   = rgb;
context.strokeStyle = rgb;
context.lineWidth   = strokeWidth;
context.lineCap     = strokeCap;
context.lineJoin    = strokeJoin;
context.miterLimit  = strokeMiter;
// font setting
if (font != null) {
context.font = font;
}
context.textAlign   = textAlign;
// set Shader if we have.
var gradient = null;
if (shader != null) {
if (shaderType == shaderType.BITMAPSHADER) {
// We should detect whether browser supports Pattern now.
if (context.createPattern == null) {
android.util.Log.e(this.TAG, "This browser doesn't support createPattern");
return;
}
if (!shader.mBitmap.ensureCachedCanvas(false, true)) return;
if (shader.mTileMode == null) return; // only repeat mode is supported.
var bitmapshader = context.createPattern(shader.mBitmap.mCachedCanvas, shader.mTileMode);
context.fillStyle   = bitmapshader;
context.strokeStyle = bitmapshader;
}
if (shaderType == shaderType.COMPOSESHADER) {
android.util.Log.e(this.TAG, "ComposeShader is not implemented!");
}
if (shaderType == shaderType.LINEARGRADIENT) {
gradient = context.createLinearGradient(shader.m_pts0.x, shader.m_pts0.y,
shader.m_pts1.x, shader.m_pts1.y);
}
if (shaderType == shaderType.RADIALGRADIENT) {
gradient = context.createRadialGradient(shader.m_center.x, shader.m_center.y, 0,
shader.m_center.x, shader.m_center.y, shader.m_radius);
}
if (shaderType == shaderType.SWEEPGRADIENT) {
android.util.Log.e(this.TAG, "SweepGradient is not implemented!");
}
if (gradient != null) {
if (shader.m_positions != null) {
for (var i = 0; i < shader.m_positions.length; i++) {
gradient.addColorStop(shader.m_positions[i], android.graphics.Color.toString(shader.m_colors[i]));
}
} else {
// Add color stop evenly.
for (var i = 0; i < shader.m_colors.length; i++) {
gradient.addColorStop(i/(shader.m_colors.length-1), android.graphics.Color.toString(shader.m_colors[i]));
}
}
context.fillStyle   = gradient;
context.strokeStyle = gradient;
}
}
}, $fz.isPrivate = true, $fz), "android.graphics.Paint");
Clazz.defineMethod (c$, "drawRGB", 
function (r, g, b) {
this.drawARGB (0xFF, r, g, b);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "drawARGB", 
function (a, r, g, b) {
var paint =  new android.graphics.Paint ();
paint.setARGB (a, r, g, b);
this.setHTML5CanvasContext (paint);
var _canvas = null;
if (this.mBM != null) {
_canvas = this.mBM.mCachedCanvas;
// Update the bitmap cached canvas dirty flag
this.mBM.mIsCachedCanvasDirty = true;
} else {
_canvas = document.getElementById(this.activeCanvas);
}
var _context = _canvas.getContext("2d");
_context.fillRect(0, 0, _canvas.width, _canvas.height);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "drawText", 
function (text, index, count, x, y, paint) {
if ((index | count | (index + count) | (text.length - index - count)) < 0) {
throw  new IndexOutOfBoundsException ();
}this.drawText ( String.instantialize (text), index, index + count, x, y, paint);
}, "~A,~N,~N,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "drawText", 
function (text, start, end, x, y, paint) {
if ((start | end | (end - start) | (text.length - end)) < 0) {
throw  new IndexOutOfBoundsException ();
}var subText = text.substring (start, end);
this.setHTML5CanvasContext (paint);
var _canvas = null;
if (this.mBM != null) {
_canvas = this.mBM.mCachedCanvas;
// Update the bitmap cached canvas dirty flag
this.mBM.mIsCachedCanvasDirty = true;
} else {
_canvas = document.getElementById(this.activeCanvas);
}
var _context = _canvas.getContext("2d");
_context.fillText(subText, x, y);
}, "~S,~N,~N,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "drawText", 
function (text, start, end, x, y, paint) {
this.drawText (text.toString (), start, end, x, y, paint);
}, "CharSequence,~N,~N,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "drawText", 
function (text, x, y, paint) {
this.drawText (text, 0, text.length, x, y, paint);
}, "~S,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "drawColor", 
function (color) {
this.drawARGB (android.graphics.Color.alpha (color), android.graphics.Color.red (color), android.graphics.Color.green (color), android.graphics.Color.blue (color));
}, "~N");
Clazz.defineMethod (c$, "drawColor", 
function (color, mode) {
if (mode === android.graphics.PorterDuff.Mode.CLEAR) {
this.drawColor (color);
} else {
android.util.Log.e ("Canvas", "Only Mode.CLEAR is implemented now!");
}}, "~N,android.graphics.PorterDuff.Mode");
Clazz.defineMethod (c$, "drawGradient", 
function (startColor, endColor, angle) {
var start = android.graphics.Color.toString (startColor);
var end = android.graphics.Color.toString (endColor);
var _canvas = null;
if (this.mBM != null) {
_canvas = this.mBM.mCachedCanvas;
// Update the bitmap cached canvas dirty flag
this.mBM.mIsCachedCanvasDirty = true;
} else {
_canvas = document.getElementById(this.activeCanvas);
}
var _context = _canvas.getContext("2d");
var grad = _context.createLinearGradient(0, 0, 0, this._height);
grad.addColorStop(0, start);
grad.addColorStop(1, end);
_context.fillStyle = grad;
_context.fillRect(0, 0, this._width, this._height);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "drawLine", 
function (startX, startY, stopX, stopY, paint) {
this.setHTML5CanvasContext (paint);
var _canvas = null;
if (this.mBM != null) {
_canvas = this.mBM.mCachedCanvas;
// Update the bitmap cached canvas dirty flag
this.mBM.mIsCachedCanvasDirty = true;
} else {
_canvas = document.getElementById(this.activeCanvas);
}
var _context = _canvas.getContext("2d");
_context.beginPath();
_context.moveTo(startX,startY);
_context.lineTo(stopX,stopY);
_context.stroke();
if (false) {
android.util.Log.d ("Canvas", "Draw line from (" + startX + "," + startY + ") to (" + stopX + "," + stopY + ")");
}}, "~N,~N,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "drawLines", 
function (pts, paint) {
for (var i = 0; (i + 3) < pts.length; i += 4) {
this.drawLine (pts[i], pts[i + 1], pts[i + 2], pts[i + 3], paint);
}
}, "~A,android.graphics.Paint");
Clazz.defineMethod (c$, "drawBitmap", 
function (bitmap, matrix, paint) {
var tmp =  new android.graphics.Matrix ();
tmp.setConcat (this.ctm, matrix);
this.setHTML5CanvasMatrix (tmp);
this.drawBitmap (bitmap, 0, 0, paint);
this.setHTML5CanvasMatrix (this.ctm);
}, "android.graphics.Bitmap,android.graphics.Matrix,android.graphics.Paint");
Clazz.defineMethod (c$, "drawBitmap", 
function (bitmap, left, top, paint) {
android.graphics.Canvas.throwIfRecycled (bitmap);
if (this.activeCanvas == null && this.mBM == null) {
return ;
}if (paint != null) {
this.setHTML5CanvasContext (paint);
}if (!bitmap.ensureCachedCanvas(false, true)) return;
// draw offscreen canvas into onscreen canvas
var _activeCanvas = null;
if (this.mBM != null) {
_activeCanvas = this.mBM.mCachedCanvas;
// Update the bitmap cached canvas dirty flag
this.mBM.mIsCachedCanvasDirty = true;
} else {
_activeCanvas = document.getElementById(this.activeCanvas);
}
var activeContext = _activeCanvas.getContext("2d");
activeContext.drawImage(bitmap.mCachedCanvas, left, top);
}, "android.graphics.Bitmap,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "drawBitmap", 
function (bitmap, src, dst, paint) {
if (dst == null) {
throw  new NullPointerException ();
}android.graphics.Canvas.throwIfRecycled (bitmap);
if (src == null) {
src =  new android.graphics.Rect (0, 0, bitmap.getWidth (), bitmap.getHeight ());
}if (src.isEmpty () || dst.isEmpty ()) {
return ;
}if (this.activeCanvas == null && this.mBM == null) {
return ;
}if (paint != null) this.setHTML5CanvasContext (paint);
if (!bitmap.ensureCachedCanvas(false, true)) return;
// draw offscreen canvas into onscreen canvas
var _activeCanvas = null;
if (this.mBM != null) {
_activeCanvas = this.mBM.mCachedCanvas;
// Update the bitmap cached canvas dirty flag
this.mBM.mIsCachedCanvasDirty = true;
} else {
_activeCanvas = document.getElementById(this.activeCanvas);
}
var activeContext = _activeCanvas.getContext("2d");
activeContext.drawImage(bitmap.mCachedCanvas, src.left, src.top, src.width(), src.height(),
dst.left, dst.top, dst.width(), dst.height());
}, "android.graphics.Bitmap,android.graphics.Rect,android.graphics.RectF,android.graphics.Paint");
Clazz.defineMethod (c$, "drawBitmap", 
function (bitmap, src, dst, paint) {
if (dst == null) {
throw  new NullPointerException ();
}android.graphics.Canvas.throwIfRecycled (bitmap);
if (src == null) {
src =  new android.graphics.Rect (0, 0, bitmap.getWidth (), bitmap.getHeight ());
}if (src.isEmpty () || dst.isEmpty ()) {
return ;
}if (this.activeCanvas == null && this.mBM == null) {
return ;
}if (paint != null) this.setHTML5CanvasContext (paint);
if (!bitmap.ensureCachedCanvas(false, true)) return;
// draw offscreen canvas into onscreen canvas
var _activeCanvas = null;
if (this.mBM != null) {
_activeCanvas = this.mBM.mCachedCanvas;
// Update the bitmap cached canvas dirty flag
this.mBM.mIsCachedCanvasDirty = true;
} else {
_activeCanvas = document.getElementById(this.activeCanvas);
}
var activeContext = _activeCanvas.getContext("2d");
activeContext.drawImage(bitmap.mCachedCanvas, src.left, src.top, src.width(), src.height(),
dst.left, dst.top, dst.width(), dst.height());
}, "android.graphics.Bitmap,android.graphics.Rect,android.graphics.Rect,android.graphics.Paint");
Clazz.defineMethod (c$, "setDimension", 
function (width, height) {
this._width = width;
this._height = height;
}, "~N,~N");
Clazz.defineMethod (c$, "translate", 
function (dx, dy) {
this._ddx += dx;
this._ddy += dy;
if (this.mBM != null) {
var context = this.mBM.mCachedCanvas.getContext("2d");
context.translate(dx, dy);
this.ctm.preTranslate (dx, dy);
return ;
}var _canvas = document.getElementById(this.activeCanvas);
if (_canvas != null) {
var _context = _canvas.getContext("2d");
_context.translate(dx, dy);
}
this.ctm.preTranslate (dx, dy);
}, "~N,~N");
Clazz.defineMethod (c$, "scale", 
function (sx, sy) {
if (this.mBM != null) {
var context = this.mBM.mCachedCanvas.getContext("2d");
context.scale(sx, sy);
this.ctm.preScale (sx, sy);
return ;
}var _canvas = document.getElementById(this.activeCanvas);
var _context = _canvas.getContext("2d");
_context.scale(sx, sy);
this.ctm.preScale (sx, sy);
}, "~N,~N");
Clazz.defineMethod (c$, "scale", 
function (sx, sy, px, py) {
this.translate (px, py);
this.scale (sx, sy);
this.translate (-px, -py);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "clear", 
function () {
var _activeCanvas = null;
if (this.mBM != null) {
_activeCanvas = this.mBM.mCachedCanvas;
// Update the bitmap cached canvas dirty flag
this.mBM.mIsCachedCanvasDirty = true;
} else {
_activeCanvas = document.getElementById(this.activeCanvas);
}
if(!_activeCanvas){
return;
}
//MayLoon: Please refer to
//http://jsperf.com/ctx-clearrect-vs-canvas-width-canvas-width/2
//http://www.html5rocks.com/en/tutorials/canvas/performance/
//for more detail about redraw a canvas
//_canvas.width = _canvas.width;
var _context = _activeCanvas.getContext("2d");
_context.clearRect(0,0,_activeCanvas.width,_activeCanvas.height);
});
Clazz.defineMethod (c$, "rotate", 
function (degrees, px, py) {
this.translate (px, py);
this.rotate (degrees);
this.translate (-px, -py);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "rotate", 
function (degrees) {
if (this.mBM != null) {
var context = this.mBM.mCachedCanvas.getContext("2d");
context.rotate(degrees * Math.PI / 180);
this.ctm.preRotate (degrees);
return ;
}var _canvas = document.getElementById(this.activeCanvas);
var _context = _canvas.getContext("2d");
_context.rotate(degrees * Math.PI / 180);
this.ctm.preRotate (degrees);
}, "~N");
Clazz.defineMethod (c$, "setHTML5CanvasMatrix", 
function (ctm) {
var mt =  Clazz.newArray (9, 0);
ctm.getValues (mt);
if (mt[6] != 0 || mt[7] != 0 || mt[8] != 1) {
android.util.Log.e ("Canvas", "Not support perspective matrix!");
}var MSCALE_X = mt[0];
var MSKEW_Y = mt[3];
var MSKEW_X = mt[1];
var MSCALE_Y = mt[4];
var MTRANS_X = mt[2];
var MTRANS_Y = mt[5];
if (this.mBM != null) {
var context = this.mBM.mCachedCanvas.getContext("2d");
context.setTransform(MSCALE_X, MSKEW_Y, MSKEW_X,
MSCALE_Y, MTRANS_X, MTRANS_Y);
return ;
}var _canvas = document.getElementById(this.activeCanvas);
var _context = _canvas.getContext("2d");
_context.setTransform(MSCALE_X, MSKEW_Y, MSKEW_X,
MSCALE_Y, MTRANS_X, MTRANS_Y);
}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "skew", 
function (sx, sy) {
this.ctm.preSkew (sx, sy);
this.setHTML5CanvasMatrix (this.ctm);
}, "~N,~N");
Clazz.defineMethod (c$, "concat", 
function (matrix) {
this.ctm.preConcat (matrix);
this.setHTML5CanvasMatrix (this.ctm);
}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "setMatrix", 
function (matrix) {
if (matrix == null) {
this.ctm.reset ();
} else {
this.ctm.set (matrix);
}this.setHTML5CanvasMatrix (this.ctm);
}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "getMatrix", 
function (ctm) {
ctm.set (this.ctm);
}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "getMatrix", 
function () {
var m =  new android.graphics.Matrix ();
this.getMatrix (m);
return m;
});
Clazz.defineMethod (c$, "save", 
function () {
var canvas = null;
if (this.mBM != null) {
canvas = this.mBM.mCachedCanvas;
} else {
canvas = document.getElementById(this.activeCanvas);
}
if (canvas != null) {
var context = canvas.getContext("2d");
context.save();
}
this.saveCount++;
var state = Clazz.innerTypeInstance (android.graphics.Canvas.CanvasState, this, null);
state._rect =  new android.graphics.Rect (this._ddx, this._ddy, this._ddx + this._width, this._ddy + this._height);
state._clipBounds =  new android.graphics.Rect (this.mClipBounds);
state._ctm =  new android.graphics.Matrix (this.ctm);
this.transList.add (state);
return this.saveCount;
});
Clazz.defineMethod (c$, "restore", 
function () {
if (this.saveCount <= 1) {
throw  new IllegalStateException ("Underflow in restore");
}var canvas = null;
if (this.mBM != null) {
canvas = this.mBM.mCachedCanvas;
} else {
canvas = document.getElementById(this.activeCanvas);
}
if (canvas != null) {
var context = canvas.getContext("2d");
context.restore();
}
var cache = (this.transList.get (this.saveCount - 1))._rect;
this._ddx = cache.left;
this._ddy = cache.top;
this._width = cache.right - cache.left;
this._height = cache.bottom - cache.top;
var clip = (this.transList.get (this.saveCount - 1))._clipBounds;
this.mClipBounds.copyFrom (clip);
var mt = (this.transList.get (this.saveCount - 1))._ctm;
this.ctm.set (mt);
this.transList.remove (this.saveCount - 1);
this.saveCount--;
});
Clazz.defineMethod (c$, "getSaveCount", 
function () {
return this.saveCount;
});
Clazz.defineMethod (c$, "restoreToCount", 
function (count) {
if (count < 1) {
throw  new IllegalArgumentException ("Underflow in restoreToCount");
}while (this.saveCount >= count) {
this.restore ();
}
}, "~N");
Clazz.defineMethod (c$, "clipRect", 
function (left, top, right, bottom) {
var canvas = null;
if (this.mBM != null) {
canvas = this.mBM.mCachedCanvas;
} else {
canvas = document.getElementById(this.activeCanvas);
}
if (canvas != null) {
var _context = canvas.getContext("2d");
_context.beginPath();
_context.rect(left,top,right-left,bottom-top);
_context.closePath();
_context.clip();
}
this.mClipBounds.set (Math.round (left), Math.round (top), Math.round (right), Math.round (bottom));
return true;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "clipRect", 
function (rect) {
return this.clipRect (rect.left, rect.top, rect.right, rect.bottom);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "drawRect", 
function (r, paint) {
this.drawRect (r.left, r.top, r.right, r.bottom, paint);
}, "android.graphics.Rect,android.graphics.Paint");
Clazz.defineMethod (c$, "drawRect", 
function (rect, paint) {
this.drawRect (rect.left, rect.top, rect.right, rect.bottom, paint);
}, "android.graphics.RectF,android.graphics.Paint");
Clazz.defineMethod (c$, "drawRect", 
function (left, top, right, bottom, paint) {
var path =  new android.graphics.Path ();
path.addRect (left, top, right, bottom, android.graphics.Path.Direction.CW);
this.drawPath (path, paint);
}, "~N,~N,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "drawCircle", 
function (cx, cy, radius, paint) {
var path =  new android.graphics.Path ();
path.addCircle (cx, cy, radius, android.graphics.Path.Direction.CW);
this.drawPath (path, paint);
}, "~N,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "drawOval", 
function (oval, paint) {
if (oval == null) {
throw  new NullPointerException ();
}var path =  new android.graphics.Path ();
path.addOval (oval, android.graphics.Path.Direction.CW);
this.drawPath (path, paint);
}, "android.graphics.RectF,android.graphics.Paint");
Clazz.defineMethod (c$, "drawArc", 
function (oval, startAngle, sweepAngle, useCenter, paint) {
if (oval == null) {
throw  new NullPointerException ();
}if (sweepAngle >= 360) {
this.drawOval (oval, paint);
} else {
var path =  new android.graphics.Path ();
if (useCenter) {
path.moveTo (oval.centerX (), oval.centerY ());
}path.arcTo (oval, startAngle, sweepAngle, !useCenter);
if (useCenter) {
path.close ();
}this.drawPath (path, paint);
}}, "android.graphics.RectF,~N,~N,~B,android.graphics.Paint");
Clazz.defineMethod (c$, "drawRoundRect", 
function (rect, rx, ry, paint) {
if (rect == null) {
throw  new NullPointerException ();
}if (rx > 0 && ry > 0) {
var path =  new android.graphics.Path ();
path.addRoundRect (rect, rx, ry, android.graphics.Path.Direction.CW);
this.drawPath (path, paint);
} else {
this.drawRect (rect, paint);
}}, "android.graphics.RectF,~N,~N,android.graphics.Paint");
c$.throwIfRecycled = Clazz.defineMethod (c$, "throwIfRecycled", 
($fz = function (bitmap) {
if (bitmap.isRecycled ()) {
throw  new RuntimeException ("Canvas: trying to use a recycled bitmap " + bitmap);
}}, $fz.isPrivate = true, $fz), "android.graphics.Bitmap");
Clazz.defineMethod (c$, "drawPath", 
function (path, paint) {
this.setHTML5CanvasContext (paint);
if (this.mBM != null) {
path.drawOnCanvas (null, this.mBM, paint);
} else {
path.drawOnCanvas (this.activeCanvas, null, paint);
}}, "android.graphics.Path,android.graphics.Paint");
Clazz.defineMethod (c$, "drawPoints", 
function (pts, offset, count, paint) {
if ((offset | count) < 0 || offset + count > pts.length) {
throw  new ArrayIndexOutOfBoundsException ();
}for (var i = offset; i < pts.length; i = i + 2) {
this.drawPoint (pts[i], pts[i + 1], paint);
}
}, "~A,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "drawPoints", 
function (pts, paint) {
this.drawPoints (pts, 0, pts.length, paint);
}, "~A,android.graphics.Paint");
Clazz.defineMethod (c$, "drawPoint", 
function (x, y, paint) {
this.setHTML5CanvasContext (paint);
var diameter = paint.getStrokeWidth ();
var path =  new android.graphics.Path ();
var radius = diameter / 2;
if (paint.getStrokeCap ().equals (android.graphics.Paint.Cap.ROUND)) {
path.addCircle (x, y, radius, android.graphics.Path.Direction.CW);
} else {
path.addRect (x - radius, y - radius, x + radius, y + radius, android.graphics.Path.Direction.CW);
}this.drawPath (path, paint);
}, "~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "getWidth", 
function () {
var _canvas = null;
if (this.mBM != null) {
_canvas = this.mBM.mCachedCanvas;
} else {
_canvas = document.getElementById(this.activeCanvas);
}
if (_canvas != null) {
this._width = _canvas.width;
} else {
this._width = 0;
}
return this._width;
});
Clazz.defineMethod (c$, "getHeight", 
function () {
var _canvas = null;
if (this.mBM != null) {
_canvas = this.mBM.mCachedCanvas;
} else {
_canvas = document.getElementById(this.activeCanvas);
}
if (_canvas != null) {
this._height = _canvas.width;
} else {
this._height = 0;
}
return this._height;
});
Clazz.defineMethod (c$, "getDensity", 
function () {
return this.mDensity;
});
Clazz.defineMethod (c$, "setBitmap", 
function (bm) {
this.mBM = bm;
if (this.mBM != null) {
this.mBM.ensureCachedCanvas (new Boolean (false), new Boolean (false));
}}, "android.graphics.Bitmap");
Clazz.defineMethod (c$, "getClipBounds", 
function (bounds) {
if (this.mClipBounds != null) {
if (bounds != null) {
bounds.copyFrom (this.mClipBounds);
}return true;
}return false;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "drawPicture", 
function (picture, dst) {
console.log("Missing method: drawPicture");
}, "~O,android.graphics.Rect");
Clazz.defineMethod (c$, "clipRegion", 
function (region, op) {
console.log("Missing method: clipRegion");
}, "android.graphics.Region,android.graphics.Region.Op");
Clazz.defineMethod (c$, "clipRegion", 
function (region) {
console.log("Missing method: clipRegion");
}, "android.graphics.Region");
Clazz.overrideMethod (c$, "finalize", 
function () {
console.log("Missing method: finalize");
});
Clazz.defineMethod (c$, "getClipBounds", 
function () {
console.log("Missing method: getClipBounds");
});
Clazz.defineMethod (c$, "setDensity", 
function (density) {
console.log("Missing method: setDensity");
}, "~N");
Clazz.defineMethod (c$, "drawPaint", 
function (paint) {
console.log("Missing method: drawPaint");
}, "android.graphics.Paint");
Clazz.defineMethod (c$, "clipRect", 
function (rect) {
console.log("Missing method: clipRect");
}, "android.graphics.RectF");
Clazz.defineMethod (c$, "clipRect", 
function (rect, op) {
console.log("Missing method: clipRect");
}, "android.graphics.Rect,android.graphics.Region.Op");
Clazz.defineMethod (c$, "clipRect", 
function (rect, op) {
console.log("Missing method: clipRect");
}, "android.graphics.RectF,android.graphics.Region.Op");
Clazz.defineMethod (c$, "clipRect", 
function (left, top, right, bottom, op) {
console.log("Missing method: clipRect");
}, "~N,~N,~N,~N,android.graphics.Region.Op");
Clazz.defineMethod (c$, "save", 
function (saveFlags) {
console.log("Missing method: save");
}, "~N");
c$.freeGlCaches = Clazz.defineMethod (c$, "freeGlCaches", 
function () {
console.log("Missing method: freeGlCaches");
});
c$.$Canvas$CanvasState$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this._rect = null;
this._clipBounds = null;
this._ctm = null;
Clazz.instantialize (this, arguments);
}, android.graphics.Canvas, "CanvasState");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Canvas, "EdgeType", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
Clazz.defineEnumConstant (c$, "BW", 0, [0]);
Clazz.defineEnumConstant (c$, "AA", 1, [1]);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Canvas, "VertexMode", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
Clazz.defineEnumConstant (c$, "TRIANGLES", 0, [0]);
Clazz.defineEnumConstant (c$, "TRIANGLE_STRIP", 1, [1]);
Clazz.defineEnumConstant (c$, "TRIANGLE_FAN", 2, [2]);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "Canvas",
"DEBUG", false,
"APP_CANVAS", 0,
"SURFACEVIEW_CANVAS", 2);
c$.paintCapAndJoinMap = c$.prototype.paintCapAndJoinMap =  new java.util.HashMap ();
});
