﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["android.graphics.Shader"], "android.graphics.SweepGradient", ["android.graphics.PointF", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.m_center = null;
this.m_colors = null;
this.m_positions = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "SweepGradient", android.graphics.Shader);
Clazz.makeConstructor (c$, 
function (cx, cy, colors, positions) {
Clazz.superConstructor (this, android.graphics.SweepGradient, []);
if (colors.length < 2) {
throw  new IllegalArgumentException ("needs >= 2 number of colors");
}if (positions != null && colors.length != positions.length) {
throw  new IllegalArgumentException ("color and position arrays must be of equal length");
}this.m_center =  new android.graphics.PointF (cx, cy);
this.m_colors =  Clazz.newArray (colors.length, 0);
for (var i = 0; i < colors.length; i++) {
this.m_colors[i] = colors[i];
}
if (positions != null) {
this.m_positions =  Clazz.newArray (positions.length, 0);
for (var i = 0; i < positions.length; i++) {
this.m_positions[i] = positions[i];
}
}}, "~N,~N,~A,~A");
Clazz.makeConstructor (c$, 
function (cx, cy, color0, color1) {
Clazz.superConstructor (this, android.graphics.SweepGradient, []);
this.m_center =  new android.graphics.PointF (cx, cy);
this.m_colors =  Clazz.newArray (2, 0);
this.m_colors[0] = color0;
this.m_colors[1] = color1;
}, "~N,~N,~N,~N");
});
