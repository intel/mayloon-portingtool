﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["android.os.Parcelable"], "android.graphics.RectF", ["android.util.FloatMath", "java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.left = 0;
this.top = 0;
this.right = 0;
this.bottom = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "RectF", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (left, top, right, bottom) {
this.left = left;
this.top = top;
this.right = right;
this.bottom = bottom;
}, "~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (r) {
this.left = r.left;
this.top = r.top;
this.right = r.right;
this.bottom = r.bottom;
}, "android.graphics.RectF");
Clazz.makeConstructor (c$, 
function (r) {
this.left = r.left;
this.top = r.top;
this.right = r.right;
this.bottom = r.bottom;
}, "android.graphics.Rect");
Clazz.overrideMethod (c$, "toString", 
function () {
return "RectF(" + this.left + ", " + this.top + ", " + this.right + ", " + this.bottom + ")";
});
Clazz.defineMethod (c$, "toShortString", 
function () {
return this.toShortString ( new StringBuilder (32));
});
Clazz.defineMethod (c$, "toShortString", 
function (sb) {
sb.setLength (0);
sb.append ('[');
sb.append (this.left);
sb.append (',');
sb.append (this.top);
sb.append ("][");
sb.append (this.right);
sb.append (',');
sb.append (this.bottom);
sb.append (']');
return sb.toString ();
}, "StringBuilder");
Clazz.defineMethod (c$, "printShortString", 
function (pw) {
pw.print ('[');
pw.print (this.left);
pw.print (',');
pw.print (this.top);
pw.print ("][");
pw.print (this.right);
pw.print (',');
pw.print (this.bottom);
pw.print (']');
}, "java.io.PrintWriter");
Clazz.defineMethod (c$, "isEmpty", 
function () {
return this.left >= this.right || this.top >= this.bottom;
});
Clazz.defineMethod (c$, "width", 
function () {
return this.right - this.left;
});
Clazz.defineMethod (c$, "height", 
function () {
return this.bottom - this.top;
});
Clazz.defineMethod (c$, "centerX", 
function () {
return (this.left + this.right) * 0.5;
});
Clazz.defineMethod (c$, "centerY", 
function () {
return (this.top + this.bottom) * 0.5;
});
Clazz.defineMethod (c$, "setEmpty", 
function () {
this.left = this.right = this.top = this.bottom = 0;
});
Clazz.defineMethod (c$, "set", 
function (left, top, right, bottom) {
this.left = left;
this.top = top;
this.right = right;
this.bottom = bottom;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "set", 
function (src) {
this.left = src.left;
this.top = src.top;
this.right = src.right;
this.bottom = src.bottom;
}, "android.graphics.RectF");
Clazz.defineMethod (c$, "set", 
function (src) {
this.left = src.left;
this.top = src.top;
this.right = src.right;
this.bottom = src.bottom;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "offset", 
function (dx, dy) {
this.left += dx;
this.top += dy;
this.right += dx;
this.bottom += dy;
}, "~N,~N");
Clazz.defineMethod (c$, "offsetTo", 
function (newLeft, newTop) {
this.right += newLeft - this.left;
this.bottom += newTop - this.top;
this.left = newLeft;
this.top = newTop;
}, "~N,~N");
Clazz.defineMethod (c$, "inset", 
function (dx, dy) {
this.left += dx;
this.top += dy;
this.right -= dx;
this.bottom -= dy;
}, "~N,~N");
Clazz.defineMethod (c$, "contains", 
function (x, y) {
return this.left < this.right && this.top < this.bottom && x >= this.left && x < this.right && y >= this.top && y < this.bottom;
}, "~N,~N");
Clazz.defineMethod (c$, "contains", 
function (left, top, right, bottom) {
return this.left < this.right && this.top < this.bottom && this.left <= left && this.top <= top && this.right >= right && this.bottom >= bottom;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "contains", 
function (r) {
return this.left < this.right && this.top < this.bottom && this.left <= r.left && this.top <= r.top && this.right >= r.right && this.bottom >= r.bottom;
}, "android.graphics.RectF");
Clazz.defineMethod (c$, "intersect", 
function (left, top, right, bottom) {
if (this.left < right && left < this.right && this.top < bottom && top < this.bottom) {
if (this.left < left) {
this.left = left;
}if (this.top < top) {
this.top = top;
}if (this.right > right) {
this.right = right;
}if (this.bottom > bottom) {
this.bottom = bottom;
}return true;
}return false;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "intersect", 
function (r) {
return this.intersect (r.left, r.top, r.right, r.bottom);
}, "android.graphics.RectF");
Clazz.defineMethod (c$, "setIntersect", 
function (a, b) {
if (a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom) {
this.left = Math.max (a.left, b.left);
this.top = Math.max (a.top, b.top);
this.right = Math.min (a.right, b.right);
this.bottom = Math.min (a.bottom, b.bottom);
return true;
}return false;
}, "android.graphics.RectF,android.graphics.RectF");
Clazz.defineMethod (c$, "intersects", 
function (left, top, right, bottom) {
return this.left < right && left < this.right && this.top < bottom && top < this.bottom;
}, "~N,~N,~N,~N");
c$.intersects = Clazz.defineMethod (c$, "intersects", 
function (a, b) {
return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
}, "android.graphics.RectF,android.graphics.RectF");
Clazz.defineMethod (c$, "round", 
function (dst) {
dst.set (Math.round (this.left), Math.round (this.top), Math.round (this.right), Math.round (this.bottom));
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "roundOut", 
function (dst) {
dst.set (Math.round (android.util.FloatMath.floor (this.left)), Math.round (android.util.FloatMath.floor (this.top)), Math.round (android.util.FloatMath.ceil (this.right)), Math.round (android.util.FloatMath.ceil (this.bottom)));
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "union", 
function (left, top, right, bottom) {
if ((left < right) && (top < bottom)) {
if ((this.left < this.right) && (this.top < this.bottom)) {
if (this.left > left) this.left = left;
if (this.top > top) this.top = top;
if (this.right < right) this.right = right;
if (this.bottom < bottom) this.bottom = bottom;
} else {
this.left = left;
this.top = top;
this.right = right;
this.bottom = bottom;
}}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "union", 
function (r) {
this.union (r.left, r.top, r.right, r.bottom);
}, "android.graphics.RectF");
Clazz.defineMethod (c$, "union", 
function (x, y) {
if (x < this.left) {
this.left = x;
} else if (x > this.right) {
this.right = x;
}if (y < this.top) {
this.top = y;
} else if (y > this.bottom) {
this.bottom = y;
}}, "~N,~N");
Clazz.defineMethod (c$, "sort", 
function () {
if (this.left > this.right) {
var temp = this.left;
this.left = this.right;
this.right = temp;
}if (this.top > this.bottom) {
var temp = this.top;
this.top = this.bottom;
this.bottom = temp;
}});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (out, flags) {
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "readFromParcel", 
function ($in) {
}, "android.os.Parcel");
});
