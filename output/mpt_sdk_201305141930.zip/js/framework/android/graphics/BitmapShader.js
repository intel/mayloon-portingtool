﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["android.graphics.Shader"], "android.graphics.BitmapShader", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mBitmap = null;
this.m_tileX = null;
this.m_tileY = null;
this.mTileMode = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "BitmapShader", android.graphics.Shader);
Clazz.makeConstructor (c$, 
function (bitmap, tileX, tileY) {
Clazz.superConstructor (this, android.graphics.BitmapShader, []);
this.mBitmap = bitmap;
this.m_tileX = tileX;
this.m_tileY = tileY;
if (tileX === android.graphics.Shader.TileMode.REPEAT && tileY === android.graphics.Shader.TileMode.REPEAT) {
this.mTileMode = "repeat";
} else if (tileX === android.graphics.Shader.TileMode.REPEAT && tileY === android.graphics.Shader.TileMode.CLAMP) {
this.mTileMode = "repeat-x";
} else if (tileX === android.graphics.Shader.TileMode.CLAMP && tileY === android.graphics.Shader.TileMode.REPEAT) {
this.mTileMode = "repeat-y";
} else if (tileX === android.graphics.Shader.TileMode.CLAMP && tileY === android.graphics.Shader.TileMode.CLAMP) {
this.mTileMode = "no-repeat";
}}, "android.graphics.Bitmap,android.graphics.Shader.TileMode,android.graphics.Shader.TileMode");
});
