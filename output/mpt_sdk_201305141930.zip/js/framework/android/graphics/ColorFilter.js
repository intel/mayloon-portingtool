﻿Clazz.declarePackage ("android.graphics");
c$ = Clazz.decorateAsClass (function () {
this.native_instance = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "ColorFilter");
Clazz.overrideMethod (c$, "finalize", 
function () {
});
