﻿Clazz.declarePackage ("android.graphics");
c$ = Clazz.decorateAsClass (function () {
this.x = 0;
this.y = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "Point");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (x, y) {
this.x = x;
this.y = y;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (src) {
this.x = src.x;
this.y = src.y;
}, "android.graphics.Point");
Clazz.defineMethod (c$, "set", 
function (x, y) {
this.x = x;
this.y = y;
}, "~N,~N");
Clazz.defineMethod (c$, "negate", 
function () {
this.x = -this.x;
this.y = -this.y;
});
Clazz.defineMethod (c$, "offset", 
function (dx, dy) {
this.x += dx;
this.y += dy;
}, "~N,~N");
Clazz.defineMethod (c$, "equals", 
function (x, y) {
return this.x == x && this.y == y;
}, "~N,~N");
Clazz.defineMethod (c$, "equals", 
function (o) {
if (Clazz.instanceOf (o, android.graphics.Point)) {
var p = o;
return this.x == p.x && this.y == p.y;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.x * 32713 + this.y;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return "Point(" + this.x + ", " + this.y + ")";
});
