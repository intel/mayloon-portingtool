﻿Clazz.declarePackage ("android.graphics");
Clazz.load (null, "android.graphics.Bitmap", ["android.graphics.Canvas", "$.Paint", "$.Rect", "$.RectF", "android.util.Base64", "$.DisplayMetrics", "$.Log", "java.lang.ArrayIndexOutOfBoundsException", "$.IllegalArgumentException", "$.IllegalStateException", "$.NullPointerException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mIsMutable = false;
this.mNinePatch = null;
this.mWidth = -1;
this.mHeight = -1;
this.mRecycled = false;
this.mImageData = null;
this.mRawData = null;
this.mIsImageDataDirty = false;
this.mNeedUpdateIntoCachedCanvas = false;
this.mIsCachedCanvasDirty = false;
this.mDataURL = null;
this.mConfig = null;
this.fileName = null;
this.resID = 0;
this.mDensity = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "Bitmap");
Clazz.prepareFields (c$, function () {
{
this.mCachedCanvas = null;    // save data into this canvas
this.mCachedImageData = null; // all setPixel/getPixel will get data from it as read from cached canvas
// may be too slow every time.
}this.mDensity = ($t$ = android.graphics.Bitmap.sDefaultDensity = android.graphics.Bitmap.getDefaultDensity (), android.graphics.Bitmap.prototype.sDefaultDensity = android.graphics.Bitmap.sDefaultDensity, $t$);
});
c$.setDefaultDensity = Clazz.defineMethod (c$, "setDefaultDensity", 
function (density) {
($t$ = android.graphics.Bitmap.sDefaultDensity = density, android.graphics.Bitmap.prototype.sDefaultDensity = android.graphics.Bitmap.sDefaultDensity, $t$);
}, "~N");
c$.getDefaultDensity = Clazz.defineMethod (c$, "getDefaultDensity", 
function () {
if (android.graphics.Bitmap.sDefaultDensity >= 0) {
return android.graphics.Bitmap.sDefaultDensity;
}($t$ = android.graphics.Bitmap.sDefaultDensity = android.util.DisplayMetrics.DENSITY_DEVICE, android.graphics.Bitmap.prototype.sDefaultDensity = android.graphics.Bitmap.sDefaultDensity, $t$);
return android.graphics.Bitmap.sDefaultDensity;
});
Clazz.defineMethod (c$, "getDensity", 
function () {
return this.mDensity;
});
Clazz.defineMethod (c$, "setDensity", 
function (density) {
this.mDensity = density;
}, "~N");
Clazz.defineMethod (c$, "setNinePatch", 
function (chunk) {
this.mNinePatch = chunk;
}, "android.graphics.BitmapFactory.Res_png_9patch");
Clazz.defineMethod (c$, "recycle", 
function () {
if (!this.mRecycled) {
this.mNinePatch = null;
this.mRecycled = true;
}});
Clazz.defineMethod (c$, "isRecycled", 
function () {
return this.mRecycled;
});
Clazz.defineMethod (c$, "checkRecycled", 
($fz = function (errorMessage) {
if (this.mRecycled) {
throw  new IllegalStateException (errorMessage);
}}, $fz.isPrivate = true, $fz), "~S");
c$.checkXYSign = Clazz.defineMethod (c$, "checkXYSign", 
($fz = function (x, y) {
if (x < 0) {
throw  new IllegalArgumentException ("x must be >= 0");
}if (y < 0) {
throw  new IllegalArgumentException ("y must be >= 0");
}}, $fz.isPrivate = true, $fz), "~N,~N");
c$.checkWidthHeight = Clazz.defineMethod (c$, "checkWidthHeight", 
($fz = function (width, height) {
if (width <= 0) {
throw  new IllegalArgumentException ("width must be > 0");
}if (height <= 0) {
throw  new IllegalArgumentException ("height must be > 0");
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "copyPixelsToBuffer", 
function (dst) {
var elements = dst.remaining ();
var shift;
if (Clazz.instanceOf (dst, java.nio.ByteBuffer)) {
shift = 0;
} else if (Clazz.instanceOf (dst, java.nio.ShortBuffer)) {
shift = 1;
} else if (Clazz.instanceOf (dst, java.nio.IntBuffer)) {
shift = 2;
} else {
throw  new RuntimeException ("unsupported Buffer subclass");
}var bufferSize = elements << shift;
var pixelSize = this.getRowBytes () * this.getHeight ();
if (bufferSize < pixelSize) {
throw  new RuntimeException ("Buffer not large enough for pixels");
}var position = dst.position ();
position += pixelSize >> shift;
dst.position (position);
}, "java.nio.Buffer");
Clazz.defineMethod (c$, "copyPixelsFromBuffer", 
function (src) {
this.checkRecycled ("copyPixelsFromBuffer called on recycled bitmap");
var elements = src.remaining ();
var shift;
if (Clazz.instanceOf (src, java.nio.ByteBuffer)) {
shift = 0;
} else if (Clazz.instanceOf (src, java.nio.ShortBuffer)) {
shift = 1;
} else if (Clazz.instanceOf (src, java.nio.IntBuffer)) {
shift = 2;
} else {
throw  new RuntimeException ("unsupported Buffer subclass");
}var bufferBytes = elements << shift;
var bitmapBytes = this.getRowBytes () * this.getHeight ();
if (bufferBytes < bitmapBytes) {
throw  new RuntimeException ("Buffer not large enough for pixels");
}}, "java.nio.Buffer");
Clazz.defineMethod (c$, "copy", 
function (config, isMutable) {
this.checkRecycled ("Can't copy a recycled bitmap");
var bitmap = android.graphics.Bitmap.createBitmap (this.getWidth (), this.getHeight (), config);
if (!this.ensureCachedCanvas (new Boolean (false), new Boolean (true))) return null;
if (!bitmap.ensureCachedCanvas (new Boolean (true), new Boolean (false))) return null;
var activeCanvas = bitmap.mCachedCanvas;
var activeContext = activeCanvas.getContext("2d");
activeContext.drawImage(this.mCachedCanvas, 0, 0);
bitmap.mDensity = this.mDensity;
return bitmap;
}, "android.graphics.Bitmap.Config,~B");
Clazz.defineMethod (c$, "ensureCachedCanvas", 
function (changeCachedCanvas, needUpdateIntoCachedCanvas) {
if (this.mCachedCanvas == null) {
var canvas = document.createElement('canvas');
canvas.width = this.getWidth();
canvas.height = this.getHeight();
this.mCachedCanvas = canvas;
if (this.mCachedCanvas == null) {
console.error("Fail to create cached canvas for this bitmap");
return false;
}
var context = this.mCachedCanvas.getContext('2d');
var imageData = context.createImageData(this.mCachedCanvas.width, this.mCachedCanvas.height);
this.mCachedImageData = imageData;
if (this.mRawData) {
// Decode the RawData into cachedCanvas
// Decode the image data into canvas
var png = new PNG(this.mRawData);
png.copyToImageData(imageData, png.decodePixels());
this.mIsImageDataDirty = true;
needUpdateIntoCachedCanvas = true;
this.mDataURL = this.mCachedCanvas.toDataURL(); // not needed, will remove it
this.mCachedCanvas = canvas;
} else {
context.clearRect(0, 0, this.getWidth(), this.getHeight());
}
}
// update the ImageData into CachedCanvas if we need to update and data is dirty.
if (needUpdateIntoCachedCanvas == true && this.mIsImageDataDirty == true) {
this.mCachedCanvas.getContext("2d").putImageData(this.mCachedImageData,0,0);
this.mIsImageDataDirty = false;
}
if (changeCachedCanvas == true) {
// If the cached canvas is changed. Next time we read the pixels from mCachedImageData,
// we need to get the latest data from cached canvas.
this.mIsCachedCanvasDirty = true;
}
return true;
}, "Boolean,Boolean");
Clazz.defineMethod (c$, "checkCachedCanvasDirty", 
function () {
if (this.mIsCachedCanvasDirty) {
this.mCachedImageData = this.mCachedCanvas.getContext("2d").getImageData(0, 0, this.getWidth(), this.getHeight());
this.mIsCachedCanvasDirty = false;
}});
c$.createBitmap = Clazz.defineMethod (c$, "createBitmap", 
function (src) {
return android.graphics.Bitmap.createBitmap (src, 0, 0, src.getWidth (), src.getHeight ());
}, "android.graphics.Bitmap");
c$.createBitmap = Clazz.defineMethod (c$, "createBitmap", 
function (source, x, y, width, height) {
return android.graphics.Bitmap.createBitmap (source, x, y, width, height, null, false);
}, "android.graphics.Bitmap,~N,~N,~N,~N");
c$.createBitmap = Clazz.defineMethod (c$, "createBitmap", 
function (width, height, config) {
var bm = android.graphics.Bitmap.nativeCreateBitmap (null, 0, width, width, height, config, true);
return bm;
}, "~N,~N,android.graphics.Bitmap.Config");
c$.createBitmap = Clazz.defineMethod (c$, "createBitmap", 
function (source, x, y, width, height, m, filter) {
android.graphics.Bitmap.checkXYSign (x, y);
android.graphics.Bitmap.checkWidthHeight (width, height);
if (x + width > source.getWidth ()) {
throw  new IllegalArgumentException ("x + width must be <= bitmap.width()");
}if (y + height > source.getHeight ()) {
throw  new IllegalArgumentException ("y + height must be <= bitmap.height()");
}if (!source.isMutable () && x == 0 && y == 0 && width == source.getWidth () && height == source.getHeight () && (m == null || m.isIdentity ())) {
return source;
}var neww = width;
var newh = height;
var canvas =  new android.graphics.Canvas ();
var bitmap;
var paint;
var srcR =  new android.graphics.Rect (x, y, x + width, y + height);
var dstR =  new android.graphics.RectF (0, 0, width, height);
if (m == null || m.isIdentity ()) {
bitmap = android.graphics.Bitmap.createBitmap (neww, newh, source.hasAlpha () ? android.graphics.Bitmap.Config.ARGB_8888 : android.graphics.Bitmap.Config.RGB_565);
canvas.setBitmap (bitmap);
paint = null;
} else {
var hasAlpha = source.hasAlpha () || !m.rectStaysRect ();
var deviceR =  new android.graphics.RectF ();
m.mapRect (deviceR, dstR);
neww = Math.round (deviceR.width ());
newh = Math.round (deviceR.height ());
bitmap = android.graphics.Bitmap.createBitmap (neww, newh, hasAlpha ? android.graphics.Bitmap.Config.ARGB_8888 : android.graphics.Bitmap.Config.RGB_565);
canvas.setBitmap (bitmap);
canvas.translate (-deviceR.left, -deviceR.top);
canvas.concat (m);
paint =  new android.graphics.Paint ();
paint.setFilterBitmap (filter);
if (!m.rectStaysRect ()) {
paint.setAntiAlias (true);
}}bitmap.mDensity = source.mDensity;
canvas.drawBitmap (source, srcR, dstR, paint);
return bitmap;
}, "android.graphics.Bitmap,~N,~N,~N,~N,android.graphics.Matrix,~B");
c$.createScaledBitmap = Clazz.defineMethod (c$, "createScaledBitmap", 
function (src, dstWidth, dstHeight, filter) {
if (!src.ensureCachedCanvas (new Boolean (false), new Boolean (true))) return null;
var bitmap = android.graphics.Bitmap.createBitmap (dstWidth, dstHeight, android.graphics.Bitmap.Config.ARGB_8888);
bitmap.mDensity = src.mDensity;
if (!bitmap.ensureCachedCanvas (new Boolean (false), new Boolean (false))) return null;
var activeCanvas = bitmap.mCachedCanvas;
var activeContext = activeCanvas.getContext("2d");
activeContext.drawImage(src.mCachedCanvas, 0, 0, bitmap.getWidth(), bitmap.getHeight());
bitmap.mIsCachedCanvasDirty = true;
return bitmap;
}, "android.graphics.Bitmap,~N,~N,~B");
c$.createBitmap = Clazz.defineMethod (c$, "createBitmap", 
function (colors, offset, stride, width, height, config) {
android.graphics.Bitmap.checkWidthHeight (width, height);
if (Math.abs (stride) < width) {
throw  new IllegalArgumentException ("abs(stride) must be >= width");
}var lastScanline = offset + (height - 1) * stride;
var length = colors.length;
if (offset < 0 || (offset + width > length) || lastScanline < 0 || (lastScanline + width > length)) {
throw  new ArrayIndexOutOfBoundsException ();
}return android.graphics.Bitmap.nativeCreateBitmap (colors, offset, stride, width, height, config, false);
}, "~A,~N,~N,~N,~N,android.graphics.Bitmap.Config");
c$.createBitmap = Clazz.defineMethod (c$, "createBitmap", 
function (colors, width, height, config) {
return android.graphics.Bitmap.createBitmap (colors, 0, width, width, height, config);
}, "~A,~N,~N,android.graphics.Bitmap.Config");
c$.createBitmap = Clazz.defineMethod (c$, "createBitmap", 
function (dataURL) {
var bm =  new android.graphics.Bitmap ();
bm.mDataURL = dataURL;
return bm;
}, "~S");
Clazz.defineMethod (c$, "getNinePatch", 
function () {
return this.mNinePatch;
});
Clazz.defineMethod (c$, "getNinePatchChunk", 
function () {
if (this.mNinePatch != null) {
return this.mNinePatch.chunk;
} else {
return null;
}});
Clazz.defineMethod (c$, "compress", 
function (formater, quality, stream) {
this.checkRecycled ("Can't compress a recycled bitmap");
if (stream == null) {
throw  new NullPointerException ();
}if (quality < 0 || quality > 100) {
throw  new IllegalArgumentException ("quality must be 0..100");
}if (!this.ensureCachedCanvas (new Boolean (false), new Boolean (true))) return false;
var data = "";
var format = formater.nativeInt;
switch(format){
case 0: //jpeg
data=this.mCachedCanvas.toDataURL("image/jpeg",quality/100);
data=data.substring(23); // "data:image/jpeg;base64,"
break;
case 1: //png
data=this.mCachedCanvas.toDataURL("image/png");
data=data.substring(22); // "data:image/png;base64,"
break;
}
if ("".equals (data)) return false;
var imageByte = android.util.Base64.decode (data, 0);
try {
stream.write (imageByte);
return true;
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
android.util.Log.e ("Bitmap", "compress error");
} else {
throw e;
}
}
return false;
}, "android.graphics.Bitmap.CompressFormat,~N,java.io.OutputStream");
Clazz.defineMethod (c$, "isMutable", 
function () {
return this.mIsMutable;
});
Clazz.defineMethod (c$, "getWidth", 
function () {
return this.mWidth;
});
Clazz.defineMethod (c$, "getHeight", 
function () {
return this.mHeight;
});
Clazz.defineMethod (c$, "setWidth", 
function (width) {
this.mWidth = width;
}, "~N");
Clazz.defineMethod (c$, "setHeight", 
function (height) {
this.mHeight = height;
}, "~N");
Clazz.defineMethod (c$, "getScaledWidth", 
function (targetDensity) {
return android.graphics.Bitmap.scaleFromDensity (this.getWidth (), this.mDensity, targetDensity);
}, "~N");
Clazz.defineMethod (c$, "getScaledHeight", 
function (targetDensity) {
return android.graphics.Bitmap.scaleFromDensity (this.getHeight (), this.mDensity, targetDensity);
}, "~N");
c$.scaleFromDensity = Clazz.defineMethod (c$, "scaleFromDensity", 
function (size, sdensity, tdensity) {
if (false) {
if (sdensity == 0 || sdensity == tdensity) {
return size;
}return Math.floor (((size * tdensity) + (sdensity >> 1)) / sdensity);
} else return size;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "getRowBytes", 
function () {
var pixelSize = 0;
switch (this.mConfig.nativeInt) {
case 4:
case 5:
pixelSize = 2;
break;
case 6:
pixelSize = 4;
break;
case 2:
pixelSize = 1;
break;
}
return pixelSize * this.mWidth;
});
Clazz.defineMethod (c$, "getConfig", 
function () {
return this.mConfig;
});
Clazz.defineMethod (c$, "hasAlpha", 
function () {
switch (this.mConfig.nativeInt) {
case 4:
return false;
case 5:
case 6:
case 2:
return true;
}
return false;
});
Clazz.defineMethod (c$, "setHasAlpha", 
function (hasAlpha) {
}, "~B");
Clazz.defineMethod (c$, "eraseColor", 
function (c) {
this.checkRecycled ("Can't erase a recycled bitmap");
if (!this.isMutable ()) {
throw  new IllegalStateException ("cannot erase immutable bitmaps");
}if (!this.ensureCachedCanvas (new Boolean (false), new Boolean (false))) return ;
this.nativeErase (c);
this.mIsImageDataDirty = true;
}, "~N");
Clazz.defineMethod (c$, "getPixel", 
function (x, y) {
this.checkRecycled ("Can't call getPixel() on a recycled bitmap");
this.checkPixelAccess (x, y);
if (!this.ensureCachedCanvas (new Boolean (false), new Boolean (false))) {
return 0;
}this.checkCachedCanvasDirty();
var data = this.mCachedImageData.data;
var index = y * 4 * this.mWidth + x * 4;
return android.graphics.Color.argb(data[index+3], data[index], data[index+1], data[index+2]);
return 0;
}, "~N,~N");
Clazz.defineMethod (c$, "getPixels", 
function (pixels, offset, stride, x, y, width, height) {
this.checkRecycled ("Can't call getPixels() on a recycled bitmap");
if (width == 0 || height == 0) {
return ;
}this.checkPixelsAccess (x, y, width, height, offset, stride, pixels);
if (!this.ensureCachedCanvas (new Boolean (false), new Boolean (false))) return ;
this.nativeGetPixels (pixels, offset, stride, x, y, width, height);
}, "~A,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "checkPixelAccess", 
($fz = function (x, y) {
android.graphics.Bitmap.checkXYSign (x, y);
if (x >= this.getWidth ()) {
throw  new IllegalArgumentException ("x must be < bitmap.width()");
}if (y >= this.getHeight ()) {
throw  new IllegalArgumentException ("y must be < bitmap.height()");
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "checkPixelsAccess", 
($fz = function (x, y, width, height, offset, stride, pixels) {
android.graphics.Bitmap.checkXYSign (x, y);
if (width < 0) {
throw  new IllegalArgumentException ("width must be >= 0");
}if (height < 0) {
throw  new IllegalArgumentException ("height must be >= 0");
}if (x + width > this.getWidth ()) {
throw  new IllegalArgumentException ("x + width must be <= bitmap.width()");
}if (y + height > this.getHeight ()) {
throw  new IllegalArgumentException ("y + height must be <= bitmap.height()");
}if (Math.abs (stride) < width) {
throw  new IllegalArgumentException ("abs(stride) must be >= width");
}var lastScanline = offset + (height - 1) * stride;
var length = pixels.length;
if (offset < 0 || (offset + width > length) || lastScanline < 0 || (lastScanline + width > length)) {
throw  new ArrayIndexOutOfBoundsException ();
}}, $fz.isPrivate = true, $fz), "~N,~N,~N,~N,~N,~N,~A");
Clazz.defineMethod (c$, "setPixel", 
function (x, y, color) {
this.checkRecycled ("Can't call setPixel() on a recycled bitmap");
if (!this.isMutable ()) {
throw  new IllegalStateException ();
}this.checkPixelAccess (x, y);
if (!this.ensureCachedCanvas (new Boolean (false), new Boolean (false))) return ;
var data = this.mCachedImageData.data;
var index = y * 4 * this.mWidth + x * 4;
data[index] = android.graphics.Color.red(color);;
data[index+1] = android.graphics.Color.green(color);
data[index+2] = android.graphics.Color.blue(color);
data[index+3] = android.graphics.Color.alpha(color);;
this.mIsImageDataDirty = true;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "setPixels", 
function (pixels, offset, stride, x, y, width, height) {
this.checkRecycled ("Can't call setPixels() on a recycled bitmap");
if (!this.isMutable ()) {
throw  new IllegalStateException ();
}if (width == 0 || height == 0) {
return ;
}this.checkPixelsAccess (x, y, width, height, offset, stride, pixels);
if (!this.ensureCachedCanvas (new Boolean (false), new Boolean (false))) return ;
this.nativeSetPixels (pixels, offset, stride, x, y, width, height);
this.mIsImageDataDirty = true;
}, "~A,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "extractAlpha", 
function () {
return this.extractAlpha (null, null);
});
Clazz.defineMethod (c$, "extractAlpha", 
function (paint, offsetXY) {
this.checkRecycled ("Can't extractAlpha on a recycled bitmap");
return null;
}, "android.graphics.Paint,~A");
Clazz.defineMethod (c$, "sameAs", 
function (other) {
return false;
}, "android.graphics.Bitmap");
Clazz.defineMethod (c$, "prepareToDraw", 
function () {
});
Clazz.defineMethod (c$, "finalize", 
function () {
try {
} finally {
Clazz.superCall (this, android.graphics.Bitmap, "finalize", []);
}
});
c$.nativeCreateBitmap = Clazz.defineMethod (c$, "nativeCreateBitmap", 
function (colors, offset, stride, width, height, config, mutable) {
var bm =  new android.graphics.Bitmap ();
bm.mConfig = config;
bm.mIsMutable = mutable;
bm.setWidth (width);
bm.setHeight (height);
return bm;
}, "~A,~N,~N,~N,~N,android.graphics.Bitmap.Config,~B");
Clazz.defineMethod (c$, "nativeErase", 
function (color) {
for (var i = 0; i < this.getHeight (); i++) {
for (var j = 0; j < this.getWidth (); j++) {
this.setPixel (i, j, color);
}
}
}, "~N");
Clazz.defineMethod (c$, "nativeSetPixels", 
function (colors, offset, stride, x, y, width, height) {
for (var i = 0; i < height; i++) {
for (var j = 0; (j < width) && (i * stride + j + offset < colors.length); j++) {
this.setPixel (x + j, y + i, colors[i * stride + j + offset]);
}
}
}, "~A,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "nativeGetPixels", 
function (pixels, offset, stride, x, y, width, height) {
for (var i = 0; i < height; i++) {
for (var j = 0; (j < width) && (i * stride + j + offset < pixels.length); j++) {
pixels[i * stride + j + offset] = this.getPixel (x + j, y + i);
}
}
}, "~A,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "getScaledHeight", 
function (metrics) {
console.log("Missing method: getScaledHeight");
}, "android.util.DisplayMetrics");
Clazz.defineMethod (c$, "describeContents", 
function () {
console.log("Missing method: describeContents");
});
Clazz.defineMethod (c$, "getScaledWidth", 
function (canvas) {
console.log("Missing method: getScaledWidth");
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "getScaledHeight", 
function (canvas) {
console.log("Missing method: getScaledHeight");
}, "android.graphics.Canvas");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Bitmap, "Config");
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
c$.nativeToConfig = Clazz.defineMethod (c$, "nativeToConfig", 
function (a) {
return android.graphics.Bitmap.Config.sConfigs[a];
}, "~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (a) {
if ("ALPHA_8".equals (a)) {
return android.graphics.Bitmap.Config.ALPHA_8;
} else if ("RGB_565".equals (a)) {
return android.graphics.Bitmap.Config.RGB_565;
} else if ("ARGB_4444".equals (a)) {
return android.graphics.Bitmap.Config.ARGB_4444;
} else if ("ARGB_8888".equals (a)) {
return android.graphics.Bitmap.Config.ARGB_8888;
} else {
return null;
}}, "~S");
c$.values = Clazz.defineMethod (c$, "values", 
function () {
var a =  new Array (4);
a[0] = android.graphics.Bitmap.Config.ALPHA_8;
a[1] = android.graphics.Bitmap.Config.RGB_565;
a[2] = android.graphics.Bitmap.Config.ARGB_4444;
a[3] = android.graphics.Bitmap.Config.ARGB_8888;
return a;
});
c$.ALPHA_8 = c$.prototype.ALPHA_8 =  new android.graphics.Bitmap.Config (2);
c$.RGB_565 = c$.prototype.RGB_565 =  new android.graphics.Bitmap.Config (4);
c$.ARGB_4444 = c$.prototype.ARGB_4444 =  new android.graphics.Bitmap.Config (5);
c$.ARGB_8888 = c$.prototype.ARGB_8888 =  new android.graphics.Bitmap.Config (6);
Clazz.defineStatics (c$,
"CONFIG_ALPHA_8", 2,
"CONFIG_RGB_565", 4,
"CONFIG_ARGB_4444", 5,
"CONFIG_ARGB_8888", 6);
c$.sConfigs = c$.prototype.sConfigs = [null, null, android.graphics.Bitmap.Config.ALPHA_8, null, android.graphics.Bitmap.Config.RGB_565, android.graphics.Bitmap.Config.ARGB_4444, android.graphics.Bitmap.Config.ARGB_8888];
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Bitmap, "CompressFormat");
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (a) {
if ("JPEG".equals (a)) {
return android.graphics.Bitmap.CompressFormat.JPEG;
} else if ("PNG".equals (a)) {
return android.graphics.Bitmap.CompressFormat.PNG;
} else {
return null;
}}, "~S");
c$.values = Clazz.defineMethod (c$, "values", 
function () {
var a =  new Array (2);
a[0] = android.graphics.Bitmap.CompressFormat.JPEG;
a[1] = android.graphics.Bitmap.CompressFormat.PNG;
return a;
});
c$.JPEG = c$.prototype.JPEG =  new android.graphics.Bitmap.CompressFormat (0);
c$.PNG = c$.prototype.PNG =  new android.graphics.Bitmap.CompressFormat (1);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DENSITY_NONE", 0);
Clazz.defineStatics (c$,
"sDefaultDensity", -1,
"WORKING_COMPRESS_STORAGE", 4096);
});
