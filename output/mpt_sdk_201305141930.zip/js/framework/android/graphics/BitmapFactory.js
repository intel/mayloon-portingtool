﻿Clazz.declarePackage ("android.graphics");
Clazz.load (null, "android.graphics.BitmapFactory", ["android.graphics.Bitmap", "$.BitmapDecoder", "android.util.TypedValue", "java.io.BufferedInputStream", "$.FileInputStream", "java.lang.ArrayIndexOutOfBoundsException", "$.RuntimeException", "java.nio.ByteBuffer", "$.ByteOrder"], function () {
c$ = Clazz.declareType (android.graphics, "BitmapFactory");
c$.decodeFile = Clazz.defineMethod (c$, "decodeFile", 
function (pathName, opts) {
var bm = null;
var stream = null;
try {
stream =  new java.io.FileInputStream (pathName);
bm = android.graphics.BitmapFactory.decodeStream (stream, null, opts);
bm.fileName = pathName;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
} finally {
if (stream != null) {
try {
stream.close ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
}}
return bm;
}, "~S,android.graphics.BitmapFactory.Options");
c$.decodeFile = Clazz.defineMethod (c$, "decodeFile", 
function (pathName) {
return android.graphics.BitmapFactory.decodeFile (pathName, null);
}, "~S");
c$.decodeResourceStream = Clazz.defineMethod (c$, "decodeResourceStream", 
function (res, value, is, pad, opts) {
if (opts == null) {
opts =  new android.graphics.BitmapFactory.Options ();
}if (opts.inDensity == 0 && value != null) {
var density = value.density;
if (density == 0) {
opts.inDensity = 160;
} else if (density != 65535) {
opts.inDensity = density;
}}if (opts.inTargetDensity == 0 && res != null) {
opts.inTargetDensity = res.getDisplayMetrics ().densityDpi;
}return android.graphics.BitmapFactory.decodeStream (is, pad, opts);
}, "android.content.res.Resources,android.util.TypedValue,java.io.InputStream,android.graphics.Rect,android.graphics.BitmapFactory.Options");
c$.decodeResource = Clazz.defineMethod (c$, "decodeResource", 
function (res, id, opts) {
var bm = null;
var is = null;
try {
var value =  new android.util.TypedValue ();
is = res.openRawResource (id, value);
bm = android.graphics.BitmapFactory.decodeResourceStream (res, value, is, null, opts);
bm.resID = id;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
} finally {
try {
if (is != null) is.close ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
}
return bm;
}, "android.content.res.Resources,~N,android.graphics.BitmapFactory.Options");
c$.decodeResourceFd = Clazz.defineMethod (c$, "decodeResourceFd", 
function (afd, id) {
var bm = null;
try {
var imagePath = afd.getRealPath ();
var width = -1;
var height = -1;
var img = document.createElement("img");
var loaded = false;
img.onload = function() {
loaded = true;
width = this.width;
height = this.height;
console.log("Image " + imagePath + " loaded.");
}
img.onerror = function() {
loaded = true; // finish the loading.
console.log("Image " + imagePath + " can't be loaded!");
return bm;
}
try {
img.src = imagePath;
} catch (e) {
console.log("Image " + imagePath + " does not exist!");
return bm;
}
console.log("Image " + imagePath + " begin to be loaded:" + new Date());
while (!loaded) {
window.yield();
console.log("yielding...");
}
console.log("Image " + imagePath + " loaded:" + new Date());
bm = android.graphics.Bitmap.createBitmap (width, height, android.graphics.Bitmap.Config.ARGB_8888);
bm.resID = id;
if (bm.ensureCachedCanvas()) {
var _context = bm.mCachedCanvas.getContext("2d");
_context.drawImage(img, 0, 0);
bm.mIsImageDataDirty = true;
} else {
bm = null;
}
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
return bm;
}, "android.content.res.AssetFileDescriptor,~N");
c$.decodeResource = Clazz.defineMethod (c$, "decodeResource", 
function (res, id) {
return android.graphics.BitmapFactory.decodeResource (res, id, null);
}, "android.content.res.Resources,~N");
c$.decodeByteArray = Clazz.defineMethod (c$, "decodeByteArray", 
function (data, offset, length, opts) {
if ((offset | length) < 0 || data.length < offset + length) {
throw  new ArrayIndexOutOfBoundsException ();
}return android.graphics.BitmapDecoder.nativeDecodeByteArray (data, offset, length, opts);
}, "~A,~N,~N,android.graphics.BitmapFactory.Options");
c$.decodeByteArray = Clazz.defineMethod (c$, "decodeByteArray", 
function (data, offset, length) {
return android.graphics.BitmapFactory.decodeByteArray (data, offset, length, null);
}, "~A,~N,~N");
c$.decodeStream = Clazz.defineMethod (c$, "decodeStream", 
function (is, outPadding, opts) {
if (is == null) {
return null;
}if (!is.markSupported ()) {
is =  new java.io.BufferedInputStream (is, 16384);
}is.mark (1024);
var bm;
if (Clazz.instanceOf (is, android.content.res.AssetManager.AssetInputStream)) {
System.out.println ("decoding asset");
bm = android.graphics.BitmapDecoder.nativeDecodeAsset ((is).getAssetInt (), outPadding, opts);
} else {
var tempStorage = null;
if (opts != null) tempStorage = opts.inTempStorage;
if (tempStorage == null) tempStorage =  Clazz.newArray (16384, 0);
bm = android.graphics.BitmapDecoder.nativeDecodeStream (is, tempStorage, outPadding, opts);
}return android.graphics.BitmapFactory.finishDecode (bm, outPadding, opts);
}, "java.io.InputStream,android.graphics.Rect,android.graphics.BitmapFactory.Options");
c$.finishDecode = Clazz.defineMethod (c$, "finishDecode", 
($fz = function (bm, outPadding, opts) {
if (bm == null || opts == null) {
return bm;
}var density = opts.inDensity;
if (density == 0) {
return bm;
}bm.setDensity (density);
var targetDensity = opts.inTargetDensity;
if (targetDensity == 0 || density == targetDensity || density == opts.inScreenDensity) {
return bm;
}var np = bm.getNinePatch ();
var isNinePatch = np != null;
if (opts.inScaled || isNinePatch) {
var scale = targetDensity / density;
var oldBitmap = bm;
bm = android.graphics.Bitmap.createScaledBitmap (oldBitmap, Math.round ((bm.getWidth () * scale + 0.5)), Math.round ((bm.getHeight () * scale + 0.5)), true);
oldBitmap.recycle ();
if (isNinePatch) {
np = android.graphics.BitmapFactory.nativeScaleNinePatch (np, scale, outPadding);
bm.setNinePatch (np);
}bm.setDensity (targetDensity);
}return bm;
}, $fz.isPrivate = true, $fz), "android.graphics.Bitmap,android.graphics.Rect,android.graphics.BitmapFactory.Options");
c$.nativeScaleNinePatch = Clazz.defineMethod (c$, "nativeScaleNinePatch", 
($fz = function (np, scale, outPadding) {
if (np != null) {
np.paddingLeft = Math.round ((np.paddingLeft * scale));
np.paddingTop = Math.round ((np.paddingTop * scale));
np.paddingRight = Math.round ((np.paddingRight * scale));
np.paddingBottom = Math.round ((np.paddingBottom * scale));
for (var i = 0; i < np.numXDivs; i++) {
np.xDivs[i] = Math.round ((np.xDivs[i] * scale));
if (i > 0 && np.xDivs[i] == np.xDivs[i - 1]) {
np.xDivs[i]++;
}}
for (var i = 0; i < np.numYDivs; i++) {
np.yDivs[i] = Math.round ((np.yDivs[i] * scale));
if (i > 0 && np.yDivs[i] == np.yDivs[i - 1]) {
np.yDivs[i]++;
}}
if (outPadding != null) {
outPadding.left = np.paddingLeft;
outPadding.top = np.paddingTop;
outPadding.right = np.paddingRight;
outPadding.bottom = np.paddingBottom;
}}return np;
}, $fz.isPrivate = true, $fz), "android.graphics.BitmapFactory.Res_png_9patch,~N,android.graphics.Rect");
c$.decodeStream = Clazz.defineMethod (c$, "decodeStream", 
function (is) {
return android.graphics.BitmapFactory.decodeStream (is, null, null);
}, "java.io.InputStream");
c$.decodeFileDescriptor = Clazz.defineMethod (c$, "decodeFileDescriptor", 
function (fd, outPadding, opts) {
var bm = android.graphics.BitmapDecoder.nativeDecodeFileDescriptor (fd, outPadding, opts);
return android.graphics.BitmapFactory.finishDecode (bm, outPadding, opts);
}, "java.io.FileDescriptor,android.graphics.Rect,android.graphics.BitmapFactory.Options");
c$.decodeFileDescriptor = Clazz.defineMethod (c$, "decodeFileDescriptor", 
function (fd) {
return android.graphics.BitmapFactory.decodeFileDescriptor (fd, null, null);
}, "java.io.FileDescriptor");
c$.setDefaultConfig = Clazz.defineMethod (c$, "setDefaultConfig", 
function (config) {
if (config == null) {
android.graphics.BitmapDecoder.nativeSetDefaultConfig (android.graphics.Bitmap.Config.RGB_565);
}}, "android.graphics.Bitmap.Config");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.inJustDecodeBounds = false;
this.inSampleSize = 0;
this.inPreferredConfig = null;
this.inDither = false;
this.inDensity = 0;
this.inTargetDensity = 0;
this.inScreenDensity = 0;
this.inScaled = false;
this.inPurgeable = false;
this.inInputShareable = false;
this.inNativeAlloc = false;
this.outWidth = 0;
this.outHeight = 0;
this.outMimeType = null;
this.inTempStorage = null;
this.mCancel = false;
Clazz.instantialize (this, arguments);
}, android.graphics.BitmapFactory, "Options");
Clazz.makeConstructor (c$, 
function () {
this.inDither = false;
this.inScaled = true;
});
Clazz.defineMethod (c$, "requestCancelDecode", 
function () {
this.mCancel = true;
this.requestCancel ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.chunk = null;
this.wasDeserialized = 0;
this.numXDivs = 0;
this.numYDivs = 0;
this.numColors = 0;
this.xDivs = null;
this.yDivs = null;
this.paddingLeft = 0;
this.paddingRight = 0;
this.paddingTop = 0;
this.paddingBottom = 0;
this.colors = null;
Clazz.instantialize (this, arguments);
}, android.graphics.BitmapFactory, "Res_png_9patch");
Clazz.makeConstructor (c$, 
function () {
this.chunk = null;
this.wasDeserialized = 0;
this.xDivs = null;
this.yDivs = null;
this.colors = null;
});
Clazz.defineMethod (c$, "deviceToFile", 
function () {
});
Clazz.defineMethod (c$, "fileToDevice", 
function (a) {
}, "~A");
Clazz.defineMethod (c$, "serialize", 
function () {
throw  new RuntimeException ("Not supported!");
});
Clazz.defineMethod (c$, "serialize", 
function (a) {
throw  new RuntimeException ("Not supported!");
}, "~A");
c$.deserialize = Clazz.defineMethod (c$, "deserialize", 
function (a) {
var b =  new android.graphics.BitmapFactory.Res_png_9patch ();
var c = java.nio.ByteBuffer.wrap (a);
c.order (java.nio.ByteOrder.BIG_ENDIAN).position (0);
b.wasDeserialized = c.get (0);
b.numXDivs = c.get (1);
b.numYDivs = c.get (2);
b.numColors = c.get (3);
b.wasDeserialized = 1;
b.paddingLeft = c.getInt (12);
b.paddingRight = c.getInt (16);
b.paddingTop = c.getInt (20);
b.paddingBottom = c.getInt (24);
var d = 32;
b.xDivs =  Clazz.newArray (b.numXDivs, 0);
for (var e = 0; e < b.numXDivs; e++) {
b.xDivs[e] = c.getInt (d + e * 4);
}
d += b.numXDivs * 4;
b.yDivs =  Clazz.newArray (b.numYDivs, 0);
for (var f = 0; f < b.numYDivs; f++) {
b.yDivs[f] = c.getInt (d + f * 4);
}
d += b.numYDivs * 4;
b.colors =  Clazz.newArray (b.numColors, 0);
for (var g = 0; g < b.numColors; g++) {
b.colors[g] = c.getInt (d + g * 4);
}
b.chunk = a;
return b;
}, "~A");
Clazz.defineMethod (c$, "serializedSize", 
function () {
return 32 + this.numXDivs * 4 + this.numYDivs * 4 + this.numColors * 4;
});
Clazz.defineStatics (c$,
"NO_COLOR", 0x00000001,
"TRANSPARENT_COLOR", 0x00000000);
c$ = Clazz.p0p ();
});
