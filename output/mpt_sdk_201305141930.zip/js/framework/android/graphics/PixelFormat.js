﻿Clazz.declarePackage ("android.graphics");
Clazz.load (null, "android.graphics.PixelFormat", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.bytesPerPixel = 0;
this.bitsPerPixel = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "PixelFormat");
c$.nativeClassInit = Clazz.defineMethod (c$, "nativeClassInit", 
($fz = function () {
}, $fz.isPrivate = true, $fz));
c$.getPixelFormatInfo = Clazz.defineMethod (c$, "getPixelFormatInfo", 
function (format, info) {
if (format <= 0) throw  new IllegalArgumentException ("BAD_VALUE");
switch (format) {
case 1:
info.bytesPerPixel = 4;
info.bitsPerPixel = 32;
break;
case 2:
info.bytesPerPixel = 4;
info.bitsPerPixel = 24;
break;
case 3:
info.bytesPerPixel = 3;
info.bitsPerPixel = 24;
break;
case 4:
case 6:
case 7:
case 10:
info.bytesPerPixel = 2;
info.bitsPerPixel = 16;
break;
case 8:
case 9:
case 11:
info.bytesPerPixel = 1;
info.bitsPerPixel = 8;
break;
default:
throw  new IllegalArgumentException ("BAD_INDEX");
}
}, "~N,android.graphics.PixelFormat");
c$.formatHasAlpha = Clazz.defineMethod (c$, "formatHasAlpha", 
function (format) {
switch (format) {
case 8:
case 10:
case 7:
case 6:
case 1:
case -3:
case -2:
return true;
}
return false;
}, "~N");
Clazz.defineStatics (c$,
"UNKNOWN", 0,
"TRANSLUCENT", -3,
"TRANSPARENT", -2,
"OPAQUE", -1,
"RGBA_8888", 1,
"RGBX_8888", 2,
"RGB_888", 3,
"RGB_565", 4,
"RGBA_5551", 6,
"RGBA_4444", 7,
"A_8", 8,
"L_8", 9,
"LA_88", 0xA,
"RGB_332", 0xB,
"YCbCr_422_SP", 0x10,
"YCbCr_420_SP", 0x11,
"YCbCr_422_I", 0x14,
"JPEG", 0x100);
{
android.graphics.PixelFormat.nativeClassInit ();
}});
