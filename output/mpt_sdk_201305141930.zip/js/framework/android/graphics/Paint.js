﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["java.lang.Enum"], "android.graphics.Paint", ["android.graphics.Rect", "java.lang.ArrayIndexOutOfBoundsException", "$.IndexOutOfBoundsException", "$.NullPointerException", "$.RuntimeException", "java.util.regex.Pattern"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mStyle = null;
this.mColor = 0;
this.mShader = null;
this.mShaderType = null;
this.mStrokeWidth = 0;
this.mStrokeCap = null;
this.mStrokeMiter = 0;
this.mStrokeJoin = null;
this.mTextAlign = null;
this.mTextSize = 0;
this.mTextSkewX = 0;
this.mTextScaleX = 1.0;
this.mHasCompatScaling = false;
this.mCompatScaling = 0;
this.mInvCompatScaling = 0;
this.mFlags = 0;
this.mTypeface = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "Paint");
Clazz.makeConstructor (c$, 
function () {
this.construct (0);
});
Clazz.makeConstructor (c$, 
function (flags) {
this.setFlags (flags | 256);
this.mCompatScaling = this.mInvCompatScaling = 1;
var hashCode = String.valueOf (this.hashCode ());
var _canvas = document.getElementById(hashCode);
if (_canvas == null) {
_canvas = document.createElement("canvas");
_canvas.id = hashCode;
document.body.appendChild(_canvas);
}
this.init ();
}, "~N");
Clazz.makeConstructor (c$, 
function (paint) {
this.construct (0);
this.mHasCompatScaling = paint.mHasCompatScaling;
this.mCompatScaling = paint.mCompatScaling;
this.mInvCompatScaling = paint.mInvCompatScaling;
}, "android.graphics.Paint");
Clazz.defineMethod (c$, "reset", 
function () {
this.init ();
this.setFlags (256);
this.mHasCompatScaling = false;
this.mCompatScaling = this.mInvCompatScaling = 1;
});
Clazz.defineMethod (c$, "set", 
function (src) {
if (this !== src) {
this.mHasCompatScaling = src.mHasCompatScaling;
this.mCompatScaling = src.mCompatScaling;
this.mInvCompatScaling = src.mInvCompatScaling;
this.mTypeface = src.mTypeface;
this.mTextSize = src.mTextSize;
this.setTextSize (this.mTextSize);
this.mTextAlign = src.mTextAlign;
this.mTextScaleX = src.mTextScaleX;
this.mTextSkewX = src.mTextSkewX;
this.mStrokeWidth = src.mStrokeWidth;
this.mColor = src.mColor;
this.mStyle = src.mStyle;
this.mStrokeCap = src.mStrokeCap;
this.mStrokeJoin = src.mStrokeJoin;
this.mStrokeMiter = src.mStrokeMiter;
}}, "android.graphics.Paint");
Clazz.defineMethod (c$, "init", 
($fz = function () {
this.mTextSize = 12;
this.setTextSize (this.mTextSize);
this.mTextAlign = android.graphics.Paint.Align.LEFT;
this.mTextScaleX = 1.0;
this.mTextSkewX = 0.0;
this.mStrokeWidth = 1.0;
this.mColor = 0xFF000000;
this.mStyle = android.graphics.Paint.Style.FILL;
this.mStrokeCap = android.graphics.Paint.Cap.BUTT;
this.mStrokeJoin = android.graphics.Paint.Join.MITER;
this.mStrokeMiter = 4.0;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setCompatibilityScaling", 
function (factor) {
if (factor == 1.0) {
this.mHasCompatScaling = false;
this.mCompatScaling = this.mInvCompatScaling = 1.0;
} else {
this.mHasCompatScaling = true;
this.mCompatScaling = factor;
this.mInvCompatScaling = 1.0 / factor;
}}, "~N");
Clazz.defineMethod (c$, "getFlags", 
function () {
return this.mFlags;
});
Clazz.defineMethod (c$, "setFlags", 
function (flags) {
this.mFlags = flags;
}, "~N");
Clazz.defineMethod (c$, "isAntiAlias", 
function () {
return (this.getFlags () & 1) != 0;
});
Clazz.defineMethod (c$, "setAntiAlias", 
function (aa) {
if (aa == true) {
this.mFlags |= 1;
} else this.mFlags = this.mFlags & -2;
}, "~B");
Clazz.defineMethod (c$, "isDither", 
function () {
return (this.getFlags () & 4) != 0;
});
Clazz.defineMethod (c$, "setDither", 
function (dither) {
if (dither == true) {
this.mFlags |= 4;
} else this.mFlags = this.mFlags & -5;
}, "~B");
Clazz.defineMethod (c$, "isLinearText", 
function () {
return (this.getFlags () & 64) != 0;
});
Clazz.defineMethod (c$, "setLinearText", 
function (linearText) {
if (linearText == true) {
this.mFlags |= 64;
} else this.mFlags = this.mFlags & -65;
}, "~B");
Clazz.defineMethod (c$, "isSubpixelText", 
function () {
return (this.getFlags () & 128) != 0;
});
Clazz.defineMethod (c$, "setSubpixelText", 
function (subpixelText) {
if (subpixelText == true) {
this.mFlags |= 128;
} else this.mFlags = this.mFlags & -129;
}, "~B");
Clazz.defineMethod (c$, "isUnderlineText", 
function () {
return (this.getFlags () & 8) != 0;
});
Clazz.defineMethod (c$, "setUnderlineText", 
function (underlineText) {
if (underlineText == true) {
this.mFlags |= 8;
} else this.mFlags = this.mFlags & -9;
}, "~B");
Clazz.defineMethod (c$, "isStrikeThruText", 
function () {
return (this.getFlags () & 16) != 0;
});
Clazz.defineMethod (c$, "setStrikeThruText", 
function (strikeThruText) {
if (strikeThruText == true) {
this.mFlags |= 16;
} else this.mFlags = this.mFlags & -17;
}, "~B");
Clazz.defineMethod (c$, "isFakeBoldText", 
function () {
return (this.getFlags () & 32) != 0;
});
Clazz.defineMethod (c$, "setFakeBoldText", 
function (fakeBoldText) {
if (fakeBoldText == true) {
this.mFlags |= 32;
} else this.mFlags = this.mFlags & -33;
}, "~B");
Clazz.defineMethod (c$, "isFilterBitmap", 
function () {
return (this.getFlags () & 2) != 0;
});
Clazz.defineMethod (c$, "setFilterBitmap", 
function (filter) {
if (filter == true) {
this.mFlags |= 2;
} else this.mFlags = this.mFlags & -3;
}, "~B");
Clazz.defineMethod (c$, "getStyle", 
function () {
return this.mStyle;
});
Clazz.defineMethod (c$, "setStyle", 
function (style) {
this.mStyle = style;
}, "android.graphics.Paint.Style");
Clazz.defineMethod (c$, "getColor", 
function () {
return this.mColor;
});
Clazz.defineMethod (c$, "setColor", 
function (color) {
this.mColor = color;
}, "~N");
Clazz.defineMethod (c$, "getAlpha", 
function () {
return (this.getColor () >> 24) & 0xff;
});
Clazz.defineMethod (c$, "setAlpha", 
function (a) {
this.mColor = this.mColor | a << 24;
}, "~N");
Clazz.defineMethod (c$, "setARGB", 
function (a, r, g, b) {
this.setColor ((a << 24) | (r << 16) | (g << 8) | b);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "getStrokeWidth", 
function () {
return this.mStrokeWidth;
});
Clazz.defineMethod (c$, "setStrokeWidth", 
function (width) {
if (width > 0) {
this.mStrokeWidth = width;
}}, "~N");
Clazz.defineMethod (c$, "getStrokeMiter", 
function () {
return this.mStrokeMiter;
});
Clazz.defineMethod (c$, "setStrokeMiter", 
function (miter) {
if (miter > 0) {
this.mStrokeMiter = miter;
}}, "~N");
Clazz.defineMethod (c$, "getStrokeCap", 
function () {
return this.mStrokeCap;
});
Clazz.defineMethod (c$, "setStrokeCap", 
function (cap) {
this.mStrokeCap = cap;
}, "android.graphics.Paint.Cap");
Clazz.defineMethod (c$, "getStrokeJoin", 
function () {
return this.mStrokeJoin;
});
Clazz.defineMethod (c$, "setStrokeJoin", 
function (join) {
this.mStrokeJoin = join;
}, "android.graphics.Paint.Join");
Clazz.defineMethod (c$, "getShader", 
function () {
return this.mShader;
});
Clazz.defineMethod (c$, "getShaderType", 
function () {
return this.mShaderType;
});
Clazz.defineMethod (c$, "setShader", 
function (shader) {
this.mShader = shader;
if (Clazz.instanceOf (shader, android.graphics.BitmapShader)) {
this.mShaderType = android.graphics.Paint.ShaderType.BITMAPSHADER;
}if (Clazz.instanceOf (shader, android.graphics.LinearGradient)) {
this.mShaderType = android.graphics.Paint.ShaderType.LINEARGRADIENT;
}if (Clazz.instanceOf (shader, android.graphics.RadialGradient)) {
this.mShaderType = android.graphics.Paint.ShaderType.RADIALGRADIENT;
}if (Clazz.instanceOf (shader, android.graphics.SweepGradient)) {
this.mShaderType = android.graphics.Paint.ShaderType.SWEEPGRADIENT;
}return shader;
}, "android.graphics.Shader");
Clazz.defineMethod (c$, "clearShadowLayer", 
function () {
throw  new RuntimeException ("Not implemented!");
});
Clazz.defineMethod (c$, "getTextAlign", 
function () {
return this.mTextAlign;
});
Clazz.defineMethod (c$, "setTextAlign", 
function (align) {
this.mTextAlign = align;
}, "android.graphics.Paint.Align");
Clazz.defineMethod (c$, "getTextSize", 
function () {
return this.mTextSize;
});
Clazz.defineMethod (c$, "setTextSize", 
function (textSize) {
this.mTextSize = textSize;
}, "~N");
Clazz.defineMethod (c$, "getTextScaleX", 
function () {
return this.mTextScaleX;
});
Clazz.defineMethod (c$, "setTextScaleX", 
function (scaleX) {
this.mTextScaleX = scaleX;
}, "~N");
Clazz.defineMethod (c$, "getTextSkewX", 
function () {
return this.mTextSkewX;
});
Clazz.defineMethod (c$, "setTextSkewX", 
function (skewX) {
this.mTextSkewX = skewX;
}, "~N");
Clazz.defineMethod (c$, "ascent", 
function () {
var bounds =  new android.graphics.Rect ();
this.measureText ("0", bounds);
return -bounds.height () * 3 / 4.0;
});
Clazz.defineMethod (c$, "descent", 
function () {
var bounds =  new android.graphics.Rect ();
this.measureText ("0", bounds);
return bounds.height () / 4.0;
});
Clazz.defineMethod (c$, "getTypeface", 
function () {
return this.mTypeface;
});
Clazz.defineMethod (c$, "setTypeface", 
function (typeface) {
this.mTypeface = typeface;
return typeface;
}, "android.graphics.Typeface");
Clazz.defineMethod (c$, "getFontMetrics", 
function (metrics) {
if (metrics != null) {
metrics.top = metrics.ascent = this.ascent ();
metrics.bottom = metrics.descent = this.descent ();
}return 0;
}, "android.graphics.Paint.FontMetrics");
Clazz.defineMethod (c$, "getFontMetrics", 
function () {
var fm =  new android.graphics.Paint.FontMetrics ();
this.getFontMetrics (fm);
return fm;
});
Clazz.defineMethod (c$, "getFontSpacing", 
function () {
return this.getFontMetrics (null);
});
Clazz.defineMethod (c$, "measureText", 
function (text, start, end) {
if (Clazz.instanceOf (text, String)) {
return this.measureText (text, start, end);
}return 1;
}, "CharSequence,~N,~N");
Clazz.defineMethod (c$, "measureText", 
function (text, start, end) {
var strText =  String.instantialize (text);
return this.measureText (strText, start, end);
}, "~A,~N,~N");
Clazz.defineMethod (c$, "measureText", 
function (text) {
if (!this.mHasCompatScaling) return this.measureText (text, null);
var oldSize = this.getTextSize ();
this.setTextSize (oldSize * this.mCompatScaling);
var w = this.measureText (text, null);
this.setTextSize (oldSize);
return w * this.mInvCompatScaling;
}, "~S");
Clazz.defineMethod (c$, "setFontCanvasProperties", 
function () {
var hashCode = String.valueOf (this.hashCode ());
var font = null;
var _canvas = document.getElementById(hashCode);
if (_canvas == null) console.e("Cant't get Paint's font canvas!");
var _context = _canvas.getContext("2d");
font = _context.font;
var p = java.util.regex.Pattern.compile ("\\d+\\.?\\d*");
var m = p.matcher (font);
var result = null;
if (m.find ()) {
result = font.substring (0, m.start () - 1);
result += this.getTextSize ();
result += font.substring (m.end ());
}if (result != null) {
_context.font = result;
}
return _context.font;
return font;
});
Clazz.defineMethod (c$, "measureText", 
($fz = function (string, bounds) {
var width = 10;
var height = 0;
var hashCode = String.valueOf (this.hashCode ());
this.setFontCanvasProperties();
var _canvas = document.getElementById(hashCode);
if (_canvas == null) return width;
var _context = _canvas.getContext("2d");
var _textMetrics = _context.measureText(string);
width = _textMetrics.width;
// Browser may have not implemented full TextMetrics yet.
if (bounds != null && _textMetrics.actualBoundingBoxLeft != null) {
bounds.left  = _textMetrics.actualBoundingBoxLeft;
bounds.right = _textMetrics.actualBoundingBoxRight;
bounds.top = _textMetrics.actualBoundingBoxAscent; // Not sure it can map directly
bounds.bottom = _textMetrics.actualBoundingBoxDescent; // Not sure it can map directly
} else if (bounds != null) {
// We create a div to measure the height of the string.
var div = document.createElement("div");
document.body.appendChild(div);
div.id = "measure_div";
div.style.visibility = "hidden";
div.style.position = "absolute";
div.style.display = "inline-block";
div.style.border = "none";
div.textContent = string;
div.style.fontSize = this.mTextSize + "px";
div.style.width = "auto";
div.style.height = "auto";
height = div.clientHeight;
div.parentNode.removeChild(div);
bounds.left = bounds.top = 0;
bounds.right = _textMetrics.width;
bounds.bottom = height;
}
return width;
}, $fz.isPrivate = true, $fz), "~S,android.graphics.Rect");
Clazz.defineMethod (c$, "getTextWidths", 
function (text, start, end, widths) {
if (Clazz.instanceOf (text, String)) {
return this.getTextWidths (text, start, end, widths);
}return 1;
}, "CharSequence,~N,~N,~A");
Clazz.defineMethod (c$, "getTextWidths", 
function (text, start, end, widths) {
var strText =  String.instantialize (text);
return this.getTextWidths (strText, start, end, widths);
}, "~A,~N,~N,~A");
Clazz.defineMethod (c$, "getTextWidths", 
function (text, widths) {
return this.getTextWidths (text, 0, text.length, widths);
}, "~S,~A");
Clazz.defineMethod (c$, "getTextBounds", 
function (text, start, end, bounds) {
if ((start | end | (end - start) | (text.length - end)) < 0) {
throw  new IndexOutOfBoundsException ();
}if (bounds == null) {
throw  new NullPointerException ("need bounds Rect");
}this.measureText (text.substring (start, end + 1), bounds);
}, "~S,~N,~N,android.graphics.Rect");
Clazz.defineMethod (c$, "getTextBounds", 
function (text, index, count, bounds) {
if ((index | count) < 0 || index + count > text.length) {
throw  new ArrayIndexOutOfBoundsException ();
}if (bounds == null) {
throw  new NullPointerException ("need bounds Rect");
}}, "~A,~N,~N,android.graphics.Rect");
Clazz.defineMethod (c$, "getFontMetricsInt", 
function () {
var fm =  new android.graphics.Paint.FontMetricsInt ();
this.getFontMetricsInt (fm);
return fm;
});
Clazz.defineMethod (c$, "setRasterizer", 
function (rasterizer) {
console.log("Missing method: setRasterizer");
}, "~O");
Clazz.overrideMethod (c$, "finalize", 
function () {
console.log("Missing method: finalize");
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Paint, "ShaderType", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
Clazz.defineEnumConstant (c$, "BITMAPSHADER", 0, [0]);
Clazz.defineEnumConstant (c$, "COMPOSESHADER", 1, [1]);
Clazz.defineEnumConstant (c$, "LINEARGRADIENT", 2, [2]);
Clazz.defineEnumConstant (c$, "RADIALGRADIENT", 3, [3]);
Clazz.defineEnumConstant (c$, "SWEEPGRADIENT", 4, [4]);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Paint, "Align");
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (a) {
if ("LEFT".equals (a)) {
return android.graphics.Paint.Align.LEFT;
} else if ("CENTER".equals (a)) {
return android.graphics.Paint.Align.CENTER;
} else if ("RIGHT".equals (a)) {
return android.graphics.Paint.Align.RIGHT;
} else {
return null;
}}, "~S");
c$.values = Clazz.defineMethod (c$, "values", 
function () {
var a =  new Array (3);
a[0] = android.graphics.Paint.Align.LEFT;
a[1] = android.graphics.Paint.Align.CENTER;
a[2] = android.graphics.Paint.Align.RIGHT;
return a;
});
c$.LEFT = c$.prototype.LEFT =  new android.graphics.Paint.Align (0);
c$.CENTER = c$.prototype.CENTER =  new android.graphics.Paint.Align (1);
c$.RIGHT = c$.prototype.RIGHT =  new android.graphics.Paint.Align (2);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Paint, "Join");
Clazz.makeConstructor (c$, 
($fz = function (a) {
this.nativeInt = a;
}, $fz.isPrivate = true, $fz), "~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (a) {
if ("MITER".equals (a)) {
return android.graphics.Paint.Join.MITER;
} else if ("ROUND".equals (a)) {
return android.graphics.Paint.Join.ROUND;
} else if ("BEVEL".equals (a)) {
return android.graphics.Paint.Join.BEVEL;
} else {
return null;
}}, "~S");
c$.values = Clazz.defineMethod (c$, "values", 
function () {
var a =  new Array (3);
a[0] = android.graphics.Paint.Join.MITER;
a[1] = android.graphics.Paint.Join.ROUND;
a[2] = android.graphics.Paint.Join.BEVEL;
return a;
});
c$.MITER = c$.prototype.MITER =  new android.graphics.Paint.Join (0);
c$.ROUND = c$.prototype.ROUND =  new android.graphics.Paint.Join (1);
c$.BEVEL = c$.prototype.BEVEL =  new android.graphics.Paint.Join (2);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Paint, "Cap");
Clazz.makeConstructor (c$, 
($fz = function (a) {
this.nativeInt = a;
}, $fz.isPrivate = true, $fz), "~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (a) {
if ("BUTT".equals (a)) {
return android.graphics.Paint.Cap.BUTT;
} else if ("ROUND".equals (a)) {
return android.graphics.Paint.Cap.ROUND;
} else if ("SQUARE".equals (a)) {
return android.graphics.Paint.Cap.SQUARE;
} else {
return null;
}}, "~S");
c$.values = Clazz.defineMethod (c$, "values", 
function () {
var a =  new Array (3);
a[0] = android.graphics.Paint.Cap.BUTT;
a[1] = android.graphics.Paint.Cap.ROUND;
a[2] = android.graphics.Paint.Cap.SQUARE;
return a;
});
c$.BUTT = c$.prototype.BUTT =  new android.graphics.Paint.Cap (0);
c$.ROUND = c$.prototype.ROUND =  new android.graphics.Paint.Cap (1);
c$.SQUARE = c$.prototype.SQUARE =  new android.graphics.Paint.Cap (2);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Paint, "Style");
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (a) {
if ("FILL".equals (a)) {
return android.graphics.Paint.Style.FILL;
} else if ("STROKE".equals (a)) {
return android.graphics.Paint.Style.STROKE;
} else if ("FILL_AND_STROKE".equals (a)) {
return android.graphics.Paint.Style.FILL_AND_STROKE;
} else {
return null;
}}, "~S");
c$.values = Clazz.defineMethod (c$, "values", 
function () {
var a =  new Array (3);
a[0] = android.graphics.Paint.Style.FILL;
a[1] = android.graphics.Paint.Style.STROKE;
a[2] = android.graphics.Paint.Style.FILL_AND_STROKE;
return a;
});
c$.FILL = c$.prototype.FILL =  new android.graphics.Paint.Style (0);
c$.STROKE = c$.prototype.STROKE =  new android.graphics.Paint.Style (1);
c$.FILL_AND_STROKE = c$.prototype.FILL_AND_STROKE =  new android.graphics.Paint.Style (2);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.top = 0;
this.ascent = 0;
this.descent = 0;
this.bottom = 0;
this.leading = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Paint, "FontMetrics");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.top = 0;
this.ascent = 0;
this.descent = 0;
this.bottom = 0;
this.leading = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Paint, "FontMetricsInt");
Clazz.overrideMethod (c$, "toString", 
function () {
return "FontMetricsInt: top=" + this.top + " ascent=" + this.ascent + " descent=" + this.descent + " bottom=" + this.bottom + " leading=" + this.leading;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"ANTI_ALIAS_FLAG", 0x01,
"FILTER_BITMAP_FLAG", 0x02,
"DITHER_FLAG", 0x04,
"UNDERLINE_TEXT_FLAG", 0x08,
"STRIKE_THRU_TEXT_FLAG", 0x10,
"FAKE_BOLD_TEXT_FLAG", 0x20,
"LINEAR_TEXT_FLAG", 0x40,
"SUBPIXEL_TEXT_FLAG", 0x80,
"DEV_KERN_TEXT_FLAG", 0x100,
"DEFAULT_PAINT_FLAGS", 256);
});
