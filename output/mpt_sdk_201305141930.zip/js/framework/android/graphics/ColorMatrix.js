﻿Clazz.declarePackage ("android.graphics");
Clazz.load (null, "android.graphics.ColorMatrix", ["android.util.FloatMath", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mArray = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "ColorMatrix");
Clazz.prepareFields (c$, function () {
this.mArray =  Clazz.newArray (20, 0);
});
Clazz.makeConstructor (c$, 
function () {
this.reset ();
});
Clazz.makeConstructor (c$, 
function (src) {
System.arraycopy (src, 0, this.mArray, 0, 20);
}, "~A");
Clazz.makeConstructor (c$, 
function (src) {
System.arraycopy (src.mArray, 0, this.mArray, 0, 20);
}, "android.graphics.ColorMatrix");
Clazz.defineMethod (c$, "getArray", 
function () {
return this.mArray;
});
Clazz.defineMethod (c$, "reset", 
function () {
var a = this.mArray;
for (var i = 19; i > 0; --i) {
a[i] = 0;
}
a[0] = a[6] = a[12] = a[18] = 1;
});
Clazz.defineMethod (c$, "set", 
function (src) {
System.arraycopy (src.mArray, 0, this.mArray, 0, 20);
}, "android.graphics.ColorMatrix");
Clazz.defineMethod (c$, "set", 
function (src) {
System.arraycopy (src, 0, this.mArray, 0, 20);
}, "~A");
Clazz.defineMethod (c$, "setScale", 
function (rScale, gScale, bScale, aScale) {
var a = this.mArray;
for (var i = 19; i > 0; --i) {
a[i] = 0;
}
a[0] = rScale;
a[6] = gScale;
a[12] = bScale;
a[18] = aScale;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setRotate", 
function (axis, degrees) {
this.reset ();
var radians = degrees * 3.141592653589793 / 180;
var cosine = android.util.FloatMath.cos (radians);
var sine = android.util.FloatMath.sin (radians);
switch (axis) {
case 0:
this.mArray[6] = this.mArray[12] = cosine;
this.mArray[7] = sine;
this.mArray[11] = -sine;
break;
case 1:
this.mArray[0] = this.mArray[12] = cosine;
this.mArray[2] = -sine;
this.mArray[10] = sine;
break;
case 2:
this.mArray[0] = this.mArray[6] = cosine;
this.mArray[1] = sine;
this.mArray[5] = -sine;
break;
default:
throw  new RuntimeException ();
}
}, "~N,~N");
Clazz.defineMethod (c$, "setConcat", 
function (matA, matB) {
var tmp = null;
if (matA === this || matB === this) {
tmp =  Clazz.newArray (20, 0);
} else {
tmp = this.mArray;
}var a = matA.mArray;
var b = matB.mArray;
var index = 0;
for (var j = 0; j < 20; j += 5) {
for (var i = 0; i < 4; i++) {
tmp[index++] = a[j + 0] * b[i + 0] + a[j + 1] * b[i + 5] + a[j + 2] * b[i + 10] + a[j + 3] * b[i + 15];
}
tmp[index++] = a[j + 0] * b[4] + a[j + 1] * b[9] + a[j + 2] * b[14] + a[j + 3] * b[19] + a[j + 4];
}
if (tmp !== this.mArray) {
System.arraycopy (tmp, 0, this.mArray, 0, 20);
}}, "android.graphics.ColorMatrix,android.graphics.ColorMatrix");
Clazz.defineMethod (c$, "preConcat", 
function (prematrix) {
this.setConcat (this, prematrix);
}, "android.graphics.ColorMatrix");
Clazz.defineMethod (c$, "postConcat", 
function (postmatrix) {
this.setConcat (postmatrix, this);
}, "android.graphics.ColorMatrix");
Clazz.defineMethod (c$, "setSaturation", 
function (sat) {
this.reset ();
var m = this.mArray;
var invSat = 1 - sat;
var R = 0.213 * invSat;
var G = 0.715 * invSat;
var B = 0.072 * invSat;
m[0] = R + sat;
m[1] = G;
m[2] = B;
m[5] = R;
m[6] = G + sat;
m[7] = B;
m[10] = R;
m[11] = G;
m[12] = B + sat;
}, "~N");
Clazz.defineMethod (c$, "setRGB2YUV", 
function () {
this.reset ();
var m = this.mArray;
m[0] = 0.299;
m[1] = 0.587;
m[2] = 0.114;
m[5] = -0.16874;
m[6] = -0.33126;
m[7] = 0.5;
m[10] = 0.5;
m[11] = -0.41869;
m[12] = -0.08131;
});
Clazz.defineMethod (c$, "setYUV2RGB", 
function () {
this.reset ();
var m = this.mArray;
m[2] = 1.402;
m[5] = 1;
m[6] = -0.34414;
m[7] = -0.71414;
m[10] = 1;
m[11] = 1.772;
m[12] = 0;
});
});
