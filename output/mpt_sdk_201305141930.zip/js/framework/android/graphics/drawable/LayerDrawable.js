﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Drawable", "android.graphics.Rect"], "android.graphics.drawable.LayerDrawable", ["com.android.internal.R", "org.xmlpull.v1.XmlPullParserException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mLayerState = null;
this.mPaddingL = null;
this.mPaddingT = null;
this.mPaddingR = null;
this.mPaddingB = null;
this.mTmpRect = null;
this.mMutated = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "LayerDrawable", android.graphics.drawable.Drawable, android.graphics.drawable.Drawable.Callback);
Clazz.prepareFields (c$, function () {
this.mTmpRect =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function (layers) {
this.construct (layers, null);
}, "~A");
Clazz.makeConstructor (c$, 
function (layers, state) {
this.construct (state, null);
var length = layers.length;
var r =  new Array (length);
for (var i = 0; i < length; i++) {
r[i] =  new android.graphics.drawable.LayerDrawable.ChildDrawable ();
r[i].mDrawable = layers[i];
layers[i].setCallback (this);
this.mLayerState.mChildrenChangingConfigurations |= layers[i].getChangingConfigurations ();
}
this.mLayerState.mNum = length;
this.mLayerState.mChildren = r;
this.ensurePadding ();
}, "~A,android.graphics.drawable.LayerDrawable.LayerState");
Clazz.makeConstructor (c$, 
function () {
this.construct (Clazz.castNullAs ("android.graphics.drawable.LayerDrawable.LayerState"), null);
});
Clazz.makeConstructor (c$, 
function (state, res) {
Clazz.superConstructor (this, android.graphics.drawable.LayerDrawable, []);
var as = this.createConstantState (state, res);
this.mLayerState = as;
if (as.mNum > 0) {
this.ensurePadding ();
}}, "android.graphics.drawable.LayerDrawable.LayerState,android.content.res.Resources");
Clazz.defineMethod (c$, "createConstantState", 
function (state, res) {
return  new android.graphics.drawable.LayerDrawable.LayerState (state, this, res);
}, "android.graphics.drawable.LayerDrawable.LayerState,android.content.res.Resources");
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
Clazz.superCall (this, android.graphics.drawable.LayerDrawable, "inflate", [r, parser, attrs]);
var type;
var innerDepth = parser.getDepth () + 1;
var depth;
while ((type = parser.next ()) != 1 && ((depth = parser.getDepth ()) >= innerDepth || type != 3)) {
if (type != 2) {
continue ;}if (depth > innerDepth || !parser.getName ().equals ("item")) {
continue ;}var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.LayerDrawableItem);
var left = a.getDimensionPixelOffset (2, 0);
var top = a.getDimensionPixelOffset (3, 0);
var right = a.getDimensionPixelOffset (4, 0);
var bottom = a.getDimensionPixelOffset (5, 0);
var drawableRes = a.getResourceId (1, 0);
var id = a.getResourceId (0, -1);
a.recycle ();
var dr;
if (drawableRes != 0) {
dr = r.getDrawable (drawableRes);
} else {
while ((type = parser.next ()) == 4) {
}
if (type != 2) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <item> tag requires a 'drawable' attribute or " + "child tag defining a drawable");
}dr = android.graphics.drawable.Drawable.createFromXmlInner (r, parser, attrs);
}this.addLayer (dr, id, left, top, right, bottom);
}
this.ensurePadding ();
this.onStateChange (this.getState ());
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "addLayer", 
($fz = function (layer, id, left, top, right, bottom) {
var st = this.mLayerState;
var N = st.mChildren != null ? st.mChildren.length : 0;
var i = st.mNum;
if (i >= N) {
var nu =  new Array (N + 10);
if (i > 0) {
System.arraycopy (st.mChildren, 0, nu, 0, i);
}st.mChildren = nu;
}this.mLayerState.mChildrenChangingConfigurations |= layer.getChangingConfigurations ();
var childDrawable =  new android.graphics.drawable.LayerDrawable.ChildDrawable ();
st.mChildren[i] = childDrawable;
childDrawable.mId = id;
childDrawable.mDrawable = layer;
childDrawable.mInsetL = left;
childDrawable.mInsetT = top;
childDrawable.mInsetR = right;
childDrawable.mInsetB = bottom;
st.mNum++;
layer.setCallback (this);
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.Drawable,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "findDrawableByLayerId", 
function (id) {
var layers = this.mLayerState.mChildren;
for (var i = this.mLayerState.mNum - 1; i >= 0; i--) {
if (layers[i].mId == id) {
return layers[i].mDrawable;
}}
return null;
}, "~N");
Clazz.defineMethod (c$, "setId", 
function (index, id) {
this.mLayerState.mChildren[index].mId = id;
}, "~N,~N");
Clazz.defineMethod (c$, "getNumberOfLayers", 
function () {
return this.mLayerState.mNum;
});
Clazz.defineMethod (c$, "getDrawable", 
function (index) {
return this.mLayerState.mChildren[index].mDrawable;
}, "~N");
Clazz.defineMethod (c$, "getId", 
function (index) {
return this.mLayerState.mChildren[index].mId;
}, "~N");
Clazz.defineMethod (c$, "setDrawableByLayerId", 
function (id, drawable) {
var layers = this.mLayerState.mChildren;
for (var i = this.mLayerState.mNum - 1; i >= 0; i--) {
if (layers[i].mId == id) {
layers[i].mDrawable = drawable;
return true;
}}
return false;
}, "~N,android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setLayerInset", 
function (index, l, t, r, b) {
var childDrawable = this.mLayerState.mChildren[index];
childDrawable.mInsetL = l;
childDrawable.mInsetT = t;
childDrawable.mInsetR = r;
childDrawable.mInsetB = b;
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "invalidateDrawable", 
function (who) {
if (this.mCallback != null) {
this.mCallback.invalidateDrawable (this);
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "scheduleDrawable", 
function (who, what, when) {
if (this.mCallback != null) {
this.mCallback.scheduleDrawable (this, what, when);
}}, "android.graphics.drawable.Drawable,Runnable,~N");
Clazz.defineMethod (c$, "unscheduleDrawable", 
function (who, what) {
if (this.mCallback != null) {
this.mCallback.unscheduleDrawable (this, what);
}}, "android.graphics.drawable.Drawable,Runnable");
Clazz.defineMethod (c$, "draw", 
function (canvas) {
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
for (var i = 0; i < N; i++) {
array[i].mDrawable.draw (canvas);
}
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
return Clazz.superCall (this, android.graphics.drawable.LayerDrawable, "getChangingConfigurations", []) | this.mLayerState.mChangingConfigurations | this.mLayerState.mChildrenChangingConfigurations;
});
Clazz.defineMethod (c$, "getPadding", 
function (padding) {
padding.left = 0;
padding.top = 0;
padding.right = 0;
padding.bottom = 0;
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
for (var i = 0; i < N; i++) {
this.reapplyPadding (i, array[i]);
padding.left += this.mPaddingL[i];
padding.top += this.mPaddingT[i];
padding.right += this.mPaddingR[i];
padding.bottom += this.mPaddingB[i];
}
return true;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "setVisible", 
function (visible, restart) {
var changed = Clazz.superCall (this, android.graphics.drawable.LayerDrawable, "setVisible", [visible, restart]);
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
for (var i = 0; i < N; i++) {
array[i].mDrawable.setVisible (visible, restart);
}
return changed;
}, "~B,~B");
Clazz.defineMethod (c$, "setDither", 
function (dither) {
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
for (var i = 0; i < N; i++) {
array[i].mDrawable.setDither (dither);
}
}, "~B");
Clazz.defineMethod (c$, "setAlpha", 
function (alpha) {
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
for (var i = 0; i < N; i++) {
array[i].mDrawable.setAlpha (alpha);
}
}, "~N");
Clazz.defineMethod (c$, "setColorFilter", 
function (cf) {
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
for (var i = 0; i < N; i++) {
array[i].mDrawable.setColorFilter (cf);
}
}, "android.graphics.ColorFilter");
Clazz.defineMethod (c$, "getOpacity", 
function () {
return this.mLayerState.getOpacity ();
});
Clazz.defineMethod (c$, "isStateful", 
function () {
return this.mLayerState.isStateful ();
});
Clazz.overrideMethod (c$, "onStateChange", 
function (state) {
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
var paddingChanged = false;
var changed = false;
for (var i = 0; i < N; i++) {
var r = array[i];
if (r.mDrawable.setState (state)) {
changed = true;
}if (this.reapplyPadding (i, r)) {
paddingChanged = true;
}}
if (paddingChanged) {
this.onBoundsChange (this.getBounds ());
}return changed;
}, "~A");
Clazz.overrideMethod (c$, "onLevelChange", 
function (level) {
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
var paddingChanged = false;
var changed = false;
for (var i = 0; i < N; i++) {
var r = array[i];
if (r.mDrawable.setLevel (level)) {
changed = true;
}if (this.reapplyPadding (i, r)) {
paddingChanged = true;
}}
if (paddingChanged) {
this.onBoundsChange (this.getBounds ());
}return changed;
}, "~N");
Clazz.overrideMethod (c$, "onBoundsChange", 
function (bounds) {
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
var padL = 0;
var padT = 0;
var padR = 0;
var padB = 0;
for (var i = 0; i < N; i++) {
var r = array[i];
r.mDrawable.setBounds (bounds.left + r.mInsetL + padL, bounds.top + r.mInsetT + padT, bounds.right - r.mInsetR - padR, bounds.bottom - r.mInsetB - padB);
padL += this.mPaddingL[i];
padR += this.mPaddingR[i];
padT += this.mPaddingT[i];
padB += this.mPaddingB[i];
}
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "getIntrinsicWidth", 
function () {
var width = -1;
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
var padL = 0;
var padR = 0;
for (var i = 0; i < N; i++) {
var r = array[i];
var w = r.mDrawable.getIntrinsicWidth () + r.mInsetL + r.mInsetR + padL + padR;
if (w > width) {
width = w;
}padL += this.mPaddingL[i];
padR += this.mPaddingR[i];
}
return width;
});
Clazz.defineMethod (c$, "getIntrinsicHeight", 
function () {
var height = -1;
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
var padT = 0;
var padB = 0;
for (var i = 0; i < N; i++) {
var r = array[i];
var h = r.mDrawable.getIntrinsicHeight () + r.mInsetT + r.mInsetB + +padT + padB;
if (h > height) {
height = h;
}padT += this.mPaddingT[i];
padB += this.mPaddingB[i];
}
return height;
});
Clazz.defineMethod (c$, "reapplyPadding", 
($fz = function (i, r) {
var rect = this.mTmpRect;
r.mDrawable.getPadding (rect);
if (rect.left != this.mPaddingL[i] || rect.top != this.mPaddingT[i] || rect.right != this.mPaddingR[i] || rect.bottom != this.mPaddingB[i]) {
this.mPaddingL[i] = rect.left;
this.mPaddingT[i] = rect.top;
this.mPaddingR[i] = rect.right;
this.mPaddingB[i] = rect.bottom;
return true;
}return false;
}, $fz.isPrivate = true, $fz), "~N,android.graphics.drawable.LayerDrawable.ChildDrawable");
Clazz.defineMethod (c$, "ensurePadding", 
($fz = function () {
var N = this.mLayerState.mNum;
if (this.mPaddingL != null && this.mPaddingL.length >= N) {
return ;
}this.mPaddingL =  Clazz.newArray (N, 0);
this.mPaddingT =  Clazz.newArray (N, 0);
this.mPaddingR =  Clazz.newArray (N, 0);
this.mPaddingB =  Clazz.newArray (N, 0);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getConstantState", 
function () {
if (this.mLayerState.canConstantState ()) {
this.mLayerState.mChangingConfigurations = Clazz.superCall (this, android.graphics.drawable.LayerDrawable, "getChangingConfigurations", []);
return this.mLayerState;
}return null;
});
Clazz.defineMethod (c$, "mutate", 
function () {
if (!this.mMutated && Clazz.superCall (this, android.graphics.drawable.LayerDrawable, "mutate", []) === this) {
var array = this.mLayerState.mChildren;
var N = this.mLayerState.mNum;
for (var i = 0; i < N; i++) {
array[i].mDrawable.mutate ();
}
this.mMutated = true;
}return this;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mDrawable = null;
this.mInsetL = 0;
this.mInsetT = 0;
this.mInsetR = 0;
this.mInsetB = 0;
this.mId = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.LayerDrawable, "ChildDrawable");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mNum = 0;
this.mChildren = null;
this.mChangingConfigurations = 0;
this.mChildrenChangingConfigurations = 0;
this.mHaveOpacity = false;
this.mOpacity = 0;
this.mHaveStateful = false;
this.mStateful = false;
this.mCheckedConstantState = false;
this.mCanConstantState = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.LayerDrawable, "LayerState", android.graphics.drawable.Drawable.ConstantState);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.graphics.drawable.LayerDrawable.LayerState, []);
if (a != null) {
var d = a.mChildren;
var e = a.mNum;
this.mNum = e;
this.mChildren =  new Array (e);
this.mChangingConfigurations = a.mChangingConfigurations;
this.mChildrenChangingConfigurations = a.mChildrenChangingConfigurations;
for (var f = 0; f < e; f++) {
var g = this.mChildren[f] =  new android.graphics.drawable.LayerDrawable.ChildDrawable ();
var h = d[f];
if (c != null) {
g.mDrawable = h.mDrawable.getConstantState ().newDrawable (c);
} else {
g.mDrawable = h.mDrawable.getConstantState ().newDrawable ();
}g.mDrawable.setCallback (b);
g.mInsetL = h.mInsetL;
g.mInsetT = h.mInsetT;
g.mInsetR = h.mInsetR;
g.mInsetB = h.mInsetB;
g.mId = h.mId;
}
this.mHaveOpacity = a.mHaveOpacity;
this.mOpacity = a.mOpacity;
this.mHaveStateful = a.mHaveStateful;
this.mStateful = a.mStateful;
this.mCheckedConstantState = this.mCanConstantState = true;
} else {
this.mNum = 0;
this.mChildren = null;
}}, "android.graphics.drawable.LayerDrawable.LayerState,android.graphics.drawable.LayerDrawable,android.content.res.Resources");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.LayerDrawable (this, null);
});
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return  new android.graphics.drawable.LayerDrawable (this, a);
}, "android.content.res.Resources");
Clazz.overrideMethod (c$, "getChangingConfigurations", 
function () {
return this.mChangingConfigurations;
});
Clazz.defineMethod (c$, "getOpacity", 
function () {
if (this.mHaveOpacity) {
return this.mOpacity;
}var a = this.mNum;
var b = a > 0 ? this.mChildren[0].mDrawable.getOpacity () : -2;
for (var c = 1; c < a; c++) {
b = android.graphics.drawable.Drawable.resolveOpacity (b, this.mChildren[c].mDrawable.getOpacity ());
}
this.mOpacity = b;
this.mHaveOpacity = true;
return b;
});
Clazz.defineMethod (c$, "isStateful", 
function () {
if (this.mHaveStateful) {
return this.mStateful;
}var a = false;
var b = this.mNum;
for (var c = 0; c < b; c++) {
if (this.mChildren[c].mDrawable.isStateful ()) {
a = true;
break;
}}
this.mStateful = a;
this.mHaveStateful = true;
return a;
});
Clazz.defineMethod (c$, "canConstantState", 
function () {
if (!this.mCheckedConstantState && this.mChildren != null) {
this.mCanConstantState = true;
var a = this.mNum;
for (var b = 0; b < a; b++) {
if (this.mChildren[b].mDrawable.getConstantState () == null) {
this.mCanConstantState = false;
break;
}}
this.mCheckedConstantState = true;
}return this.mCanConstantState;
});
c$ = Clazz.p0p ();
});
