﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Drawable"], "android.graphics.drawable.ShapeDrawable", ["android.graphics.Paint", "$.Rect", "android.util.Log", "com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mShapeState = null;
this.mMutated = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "ShapeDrawable", android.graphics.drawable.Drawable);
Clazz.makeConstructor (c$, 
function () {
this.construct (Clazz.castNullAs ("android.graphics.drawable.ShapeDrawable.ShapeState"));
});
Clazz.makeConstructor (c$, 
function (s) {
this.construct (Clazz.castNullAs ("android.graphics.drawable.ShapeDrawable.ShapeState"));
this.mShapeState.mShape = s;
}, "android.graphics.drawable.shapes.Shape");
Clazz.makeConstructor (c$, 
($fz = function (state) {
Clazz.superConstructor (this, android.graphics.drawable.ShapeDrawable, []);
this.mShapeState =  new android.graphics.drawable.ShapeDrawable.ShapeState (state);
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.ShapeDrawable.ShapeState");
Clazz.defineMethod (c$, "getShape", 
function () {
return this.mShapeState.mShape;
});
Clazz.defineMethod (c$, "setShape", 
function (s) {
this.mShapeState.mShape = s;
this.updateShape ();
}, "android.graphics.drawable.shapes.Shape");
Clazz.defineMethod (c$, "getPaint", 
function () {
return this.mShapeState.mPaint;
});
Clazz.defineMethod (c$, "setPadding", 
function (left, top, right, bottom) {
if ((left | top | right | bottom) == 0) {
this.mShapeState.mPadding = null;
} else {
if (this.mShapeState.mPadding == null) {
this.mShapeState.mPadding =  new android.graphics.Rect ();
}this.mShapeState.mPadding.set (left, top, right, bottom);
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setPadding", 
function (padding) {
if (padding == null) {
this.mShapeState.mPadding = null;
} else {
if (this.mShapeState.mPadding == null) {
this.mShapeState.mPadding =  new android.graphics.Rect ();
}this.mShapeState.mPadding.set (padding);
}}, "android.graphics.Rect");
Clazz.defineMethod (c$, "setIntrinsicWidth", 
function (width) {
this.mShapeState.mIntrinsicWidth = width;
}, "~N");
Clazz.defineMethod (c$, "setIntrinsicHeight", 
function (height) {
this.mShapeState.mIntrinsicHeight = height;
}, "~N");
Clazz.overrideMethod (c$, "getIntrinsicWidth", 
function () {
return this.mShapeState.mIntrinsicWidth;
});
Clazz.overrideMethod (c$, "getIntrinsicHeight", 
function () {
return this.mShapeState.mIntrinsicHeight;
});
Clazz.defineMethod (c$, "getPadding", 
function (padding) {
if (this.mShapeState.mPadding != null) {
padding.set (this.mShapeState.mPadding);
return true;
} else {
return Clazz.superCall (this, android.graphics.drawable.ShapeDrawable, "getPadding", [padding]);
}}, "android.graphics.Rect");
c$.modulateAlpha = Clazz.defineMethod (c$, "modulateAlpha", 
($fz = function (paintAlpha, alpha) {
var scale = alpha + (alpha >>> 7);
return paintAlpha * scale >>> 8;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "onDraw", 
function (shape, canvas, paint) {
shape.draw (canvas, paint);
}, "android.graphics.drawable.shapes.Shape,android.graphics.Canvas,android.graphics.Paint");
Clazz.overrideMethod (c$, "draw", 
function (canvas) {
var r = this.getBounds ();
var paint = this.mShapeState.mPaint;
var prevAlpha = paint.getAlpha ();
paint.setAlpha (android.graphics.drawable.ShapeDrawable.modulateAlpha (prevAlpha, this.mShapeState.mAlpha));
if (this.mShapeState.mShape != null) {
var count = canvas.save ();
canvas.translate (r.left, r.top);
this.onDraw (this.mShapeState.mShape, canvas, paint);
canvas.restoreToCount (count);
} else {
canvas.drawRect (r, paint);
}paint.setAlpha (prevAlpha);
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
return Clazz.superCall (this, android.graphics.drawable.ShapeDrawable, "getChangingConfigurations", []) | this.mShapeState.mChangingConfigurations;
});
Clazz.overrideMethod (c$, "setAlpha", 
function (alpha) {
this.mShapeState.mAlpha = alpha;
}, "~N");
Clazz.defineMethod (c$, "setColorFilter", 
function (cf) {
}, "android.graphics.ColorFilter");
Clazz.overrideMethod (c$, "getOpacity", 
function () {
if (this.mShapeState.mShape == null) {
var p = this.mShapeState.mPaint;
var alpha = p.getAlpha ();
if (alpha == 0) {
return -2;
}if (alpha == 255) {
return -1;
}}return -3;
});
Clazz.overrideMethod (c$, "setDither", 
function (dither) {
this.mShapeState.mPaint.setDither (dither);
}, "~B");
Clazz.defineMethod (c$, "onBoundsChange", 
function (bounds) {
Clazz.superCall (this, android.graphics.drawable.ShapeDrawable, "onBoundsChange", [bounds]);
this.updateShape ();
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "inflateTag", 
function (name, r, parser, attrs) {
if (name.equals ("padding")) {
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.ShapeDrawablePadding);
this.setPadding (a.getDimensionPixelOffset (0, 0), a.getDimensionPixelOffset (1, 0), a.getDimensionPixelOffset (2, 0), a.getDimensionPixelOffset (3, 0));
a.recycle ();
return true;
}return false;
}, "~S,android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
Clazz.superCall (this, android.graphics.drawable.ShapeDrawable, "inflate", [r, parser, attrs]);
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.ShapeDrawable);
var color = this.mShapeState.mPaint.getColor ();
color = a.getColor (2, color);
this.mShapeState.mPaint.setColor (color);
this.setIntrinsicWidth (Math.round (a.getDimension (1, 0)));
this.setIntrinsicHeight (Math.round (a.getDimension (0, 0)));
a.recycle ();
var type;
var outerDepth = parser.getDepth ();
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type != 2) {
continue ;}var name = parser.getName ();
if (!this.inflateTag (name, r, parser, attrs)) {
android.util.Log.w ("drawable", "Unknown element: " + name + " for ShapeDrawable " + this);
}}
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "updateShape", 
($fz = function () {
if (this.mShapeState.mShape != null) {
var r = this.getBounds ();
var w = r.width ();
var h = r.height ();
this.mShapeState.mShape.resize (w, h);
}}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getConstantState", 
function () {
this.mShapeState.mChangingConfigurations = Clazz.superCall (this, android.graphics.drawable.ShapeDrawable, "getChangingConfigurations", []);
return this.mShapeState;
});
Clazz.defineMethod (c$, "mutate", 
function () {
if (!this.mMutated && Clazz.superCall (this, android.graphics.drawable.ShapeDrawable, "mutate", []) === this) {
this.mShapeState.mPaint =  new android.graphics.Paint (this.mShapeState.mPaint);
this.mShapeState.mPadding =  new android.graphics.Rect (this.mShapeState.mPadding);
try {
this.mShapeState.mShape = this.mShapeState.mShape.clone ();
} catch (e) {
if (Clazz.instanceOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
this.mMutated = true;
}return this;
});
Clazz.defineMethod (c$, "setShaderFactory", 
function (fact) {
console.log("Missing method: setShaderFactory");
}, "~O");
Clazz.defineMethod (c$, "getShaderFactory", 
function () {
console.log("Missing method: getShaderFactory");
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mChangingConfigurations = 0;
this.mPaint = null;
this.mShape = null;
this.mPadding = null;
this.mIntrinsicWidth = 0;
this.mIntrinsicHeight = 0;
this.mAlpha = 255;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.ShapeDrawable, "ShapeState", android.graphics.drawable.Drawable.ConstantState);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.graphics.drawable.ShapeDrawable.ShapeState, []);
if (a != null) {
this.mPaint = a.mPaint;
this.mShape = a.mShape;
this.mPadding = a.mPadding;
this.mIntrinsicWidth = a.mIntrinsicWidth;
this.mIntrinsicHeight = a.mIntrinsicHeight;
this.mAlpha = a.mAlpha;
} else {
this.mPaint =  new android.graphics.Paint (1);
}}, "android.graphics.drawable.ShapeDrawable.ShapeState");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.ShapeDrawable (this);
});
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return  new android.graphics.drawable.ShapeDrawable (this);
}, "android.content.res.Resources");
Clazz.overrideMethod (c$, "getChangingConfigurations", 
function () {
return this.mChangingConfigurations;
});
c$ = Clazz.p0p ();
});
