﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.declareInterface (android.graphics.drawable, "Animatable");
