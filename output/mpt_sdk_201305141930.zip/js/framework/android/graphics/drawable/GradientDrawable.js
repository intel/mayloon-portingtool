﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Drawable"], "android.graphics.drawable.GradientDrawable", ["android.graphics.Rect", "com.android.internal.R", "org.xmlpull.v1.XmlPullParserException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mGradientState = null;
this.mPadding = null;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "GradientDrawable", android.graphics.drawable.Drawable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.graphics.drawable.GradientDrawable, []);
var colors = null;
this.mGradientState =  new android.graphics.drawable.GradientDrawable.GradientState (0, colors);
});
Clazz.makeConstructor (c$, 
function (orientation, colors) {
Clazz.superConstructor (this, android.graphics.drawable.GradientDrawable, []);
this.mGradientState =  new android.graphics.drawable.GradientDrawable.GradientState (orientation, colors);
}, "~N,~A");
Clazz.defineMethod (c$, "setCornerRadius", 
function (radius) {
this.mGradientState.setCornerRadius (radius);
}, "~N");
Clazz.defineMethod (c$, "setGradientType", 
function (gradient) {
this.mGradientState.setGradientType (gradient);
}, "~N");
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
var st = this.mGradientState;
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.GradientDrawable);
Clazz.superCall (this, android.graphics.drawable.GradientDrawable, "inflateWithAttributes", [r, parser, a, 0]);
a.recycle ();
var type;
var innerDepth = parser.getDepth () + 1;
var depth;
while ((type = parser.next ()) != 1 && ((depth = parser.getDepth ()) >= innerDepth || type != 3)) {
if (type != 2) {
continue ;}if (depth > innerDepth) {
continue ;}var name = parser.getName ();
if (name.equals ("gradient")) {
a = r.obtainAttributes (attrs, com.android.internal.R.styleable.GradientDrawableGradient);
var startColor = a.getColor (0, 0);
var endColor = a.getColor (1, 0);
var gradientType = a.getInt (4, 0);
st.mGradient = gradientType;
if (gradientType == 0) {
var angle = Math.round (a.getFloat (3, 0));
angle %= 360;
if (angle % 45 != 0) {
throw  new org.xmlpull.v1.XmlPullParserException ("<gradient> tag requires \'angle\' attribute to be a multiple of 45");
}st.mOrientation = angle;
}a.recycle ();
st.mColors =  Clazz.newArray (2, 0);
st.mColors[0] = startColor;
st.mColors[1] = endColor;
} else if (name.equals ("corners")) {
a = r.obtainAttributes (attrs, com.android.internal.R.styleable.DrawableCorners);
var radius = a.getDimensionPixelSize (0, 0);
this.setCornerRadius (radius);
a.recycle ();
} else if (name.equals ("padding")) {
a = r.obtainAttributes (attrs, com.android.internal.R.styleable.GradientDrawablePadding);
this.mPadding =  new android.graphics.Rect (a.getDimensionPixelOffset (0, 0), a.getDimensionPixelOffset (1, 0), a.getDimensionPixelOffset (2, 0), a.getDimensionPixelOffset (3, 0));
a.recycle ();
this.mGradientState.mPadding = this.mPadding;
} else {
}}
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.overrideMethod (c$, "draw", 
function (canvas) {
canvas.drawGradient (this.mGradientState.mColors[1], this.mGradientState.mColors[0], this.mGradientState.mOrientation);
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "setShape", 
function (shape) {
console.log("Missing method: setShape");
}, "~N");
Clazz.defineMethod (c$, "setCornerRadii", 
function (radii) {
console.log("Missing method: setCornerRadii");
}, "~A");
Clazz.defineMethod (c$, "setUseLevel", 
function (useLevel) {
console.log("Missing method: setUseLevel");
}, "~B");
Clazz.defineMethod (c$, "setGradientRadius", 
function (gradientRadius) {
console.log("Missing method: setGradientRadius");
}, "~N");
Clazz.defineMethod (c$, "setColor", 
function (argb) {
console.log("Missing method: setColor");
}, "~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mGradient = 0;
this.mOrientation = 0;
this.mColors = null;
this.mPadding = null;
this.mRadius = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.GradientDrawable, "GradientState", android.graphics.drawable.Drawable.ConstantState);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.graphics.drawable.GradientDrawable.GradientState, []);
this.mOrientation = a;
this.mColors = b;
}, "~N,~A");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.GradientDrawable (this.mOrientation, this.mColors);
});
Clazz.defineMethod (c$, "setGradientType", 
function (a) {
this.mGradient = a;
}, "~N");
Clazz.defineMethod (c$, "setCornerRadius", 
function (a) {
if (a < 0) {
a = 0;
}this.mRadius = a;
}, "~N");
Clazz.overrideMethod (c$, "getChangingConfigurations", 
function () {
return 0;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"RECTANGLE", 0,
"OVAL", 1,
"LINE", 2,
"RING", 3,
"LINEAR_GRADIENT", 0,
"RADIAL_GRADIENT", 1,
"SWEEP_GRADIENT", 2,
"TOP_BOTTOM", 0,
"TR_BL", 1,
"RIGHT_LEFT", 2,
"BR_TL", 3,
"BOTTOM_TOP", 4,
"BL_TR", 5,
"LEFT_RIGHT", 6,
"TL_BR", 7);
});
