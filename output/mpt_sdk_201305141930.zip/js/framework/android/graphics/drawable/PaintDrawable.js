﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.ShapeDrawable"], "android.graphics.drawable.PaintDrawable", ["android.graphics.drawable.shapes.RoundRectShape", "com.android.internal.R"], function () {
c$ = Clazz.declareType (android.graphics.drawable, "PaintDrawable", android.graphics.drawable.ShapeDrawable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.graphics.drawable.PaintDrawable, []);
});
Clazz.makeConstructor (c$, 
function (color) {
Clazz.superConstructor (this, android.graphics.drawable.PaintDrawable, []);
this.getPaint ().setColor (color);
}, "~N");
Clazz.defineMethod (c$, "setCornerRadius", 
function (radius) {
var radii = null;
if (radius > 0) {
radii =  Clazz.newArray (8, 0);
for (var i = 0; i < 8; i++) {
radii[i] = radius;
}
}this.setCornerRadii (radii);
}, "~N");
Clazz.defineMethod (c$, "setCornerRadii", 
function (radii) {
if (radii == null) {
if (this.getShape () != null) {
this.setShape (null);
}} else {
this.setShape ( new android.graphics.drawable.shapes.RoundRectShape (radii, null, null));
}}, "~A");
Clazz.defineMethod (c$, "inflateTag", 
function (name, r, parser, attrs) {
if (name.equals ("corners")) {
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.DrawableCorners);
var radius = a.getDimensionPixelSize (0, 0);
this.setCornerRadius (radius);
var topLeftRadius = a.getDimensionPixelSize (1, radius);
var topRightRadius = a.getDimensionPixelSize (2, radius);
var bottomLeftRadius = a.getDimensionPixelSize (3, radius);
var bottomRightRadius = a.getDimensionPixelSize (4, radius);
if (topLeftRadius != radius || topRightRadius != radius || bottomLeftRadius != radius || bottomRightRadius != radius) {
this.setCornerRadii ([topLeftRadius, topLeftRadius, topRightRadius, topRightRadius, bottomLeftRadius, bottomLeftRadius, bottomRightRadius, bottomRightRadius]);
}a.recycle ();
return true;
}return Clazz.superCall (this, android.graphics.drawable.PaintDrawable, "inflateTag", [name, r, parser, attrs]);
}, "~S,android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
});
