﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Drawable"], "android.graphics.drawable.ColorDrawable", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mState = null;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "ColorDrawable", android.graphics.drawable.Drawable);
Clazz.overrideMethod (c$, "draw", 
function (canvas) {
canvas.drawColor (this.mState.mUseColor);
}, "android.graphics.Canvas");
Clazz.makeConstructor (c$, 
function () {
this.construct (null);
});
Clazz.makeConstructor (c$, 
function (color) {
this.construct (null);
this.mState.mBaseColor = this.mState.mUseColor = color;
}, "~N");
Clazz.makeConstructor (c$, 
($fz = function (state) {
Clazz.superConstructor (this, android.graphics.drawable.ColorDrawable, []);
this.mState =  new android.graphics.drawable.ColorDrawable.ColorState (state);
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.ColorDrawable.ColorState");
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
return Clazz.superCall (this, android.graphics.drawable.ColorDrawable, "getChangingConfigurations", []) | this.mState.mChangingConfigurations;
});
Clazz.defineMethod (c$, "getAlpha", 
function () {
return this.mState.mUseColor >>> 24;
});
Clazz.overrideMethod (c$, "setAlpha", 
function (alpha) {
alpha += alpha >> 7;
var baseAlpha = this.mState.mBaseColor >>> 24;
var useAlpha = baseAlpha * alpha >> 8;
this.mState.mUseColor = (this.mState.mBaseColor << 8 >>> 8) | (useAlpha << 24);
}, "~N");
Clazz.overrideMethod (c$, "getOpacity", 
function () {
switch (this.mState.mUseColor >>> 24) {
case 255:
return -1;
case 0:
return -2;
}
return -3;
});
Clazz.overrideMethod (c$, "getConstantState", 
function () {
this.mState.mChangingConfigurations = Clazz.superCall (this, android.graphics.drawable.ColorDrawable, "getChangingConfigurations", []);
return this.mState;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mBaseColor = 0;
this.mUseColor = 0;
this.mChangingConfigurations = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.ColorDrawable, "ColorState", android.graphics.drawable.Drawable.ConstantState);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.graphics.drawable.ColorDrawable.ColorState, []);
if (a != null) {
this.mBaseColor = a.mBaseColor;
this.mUseColor = a.mUseColor;
}}, "android.graphics.drawable.ColorDrawable.ColorState");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.ColorDrawable (this);
});
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return  new android.graphics.drawable.ColorDrawable (this);
}, "android.content.res.Resources");
Clazz.overrideMethod (c$, "getChangingConfigurations", 
function () {
return this.mChangingConfigurations;
});
c$ = Clazz.p0p ();
});
