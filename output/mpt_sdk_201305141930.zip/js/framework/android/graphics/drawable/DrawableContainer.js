﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Drawable"], "android.graphics.drawable.DrawableContainer", ["android.graphics.Rect"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDrawableContainerState = null;
this.mCurrDrawable = null;
this.mAlpha = 0xFF;
this.mColorFilter = null;
this.mCurIndex = -1;
this.mMutated = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "DrawableContainer", android.graphics.drawable.Drawable, android.graphics.drawable.Drawable.Callback);
Clazz.defineMethod (c$, "draw", 
function (canvas) {
if (this.mCurrDrawable != null) {
this.mCurrDrawable.draw (canvas);
}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
return Clazz.superCall (this, android.graphics.drawable.DrawableContainer, "getChangingConfigurations", []) | this.mDrawableContainerState.mChangingConfigurations | this.mDrawableContainerState.mChildrenChangingConfigurations;
});
Clazz.defineMethod (c$, "getPadding", 
function (padding) {
var r = this.mDrawableContainerState.getConstantPadding ();
if (r != null) {
padding.set (r);
return true;
}if (this.mCurrDrawable != null) {
return this.mCurrDrawable.getPadding (padding);
} else {
return Clazz.superCall (this, android.graphics.drawable.DrawableContainer, "getPadding", [padding]);
}}, "android.graphics.Rect");
Clazz.defineMethod (c$, "setAlpha", 
function (alpha) {
if (this.mAlpha != alpha) {
this.mAlpha = alpha;
if (this.mCurrDrawable != null) {
this.mCurrDrawable.setAlpha (alpha);
}}}, "~N");
Clazz.defineMethod (c$, "setDither", 
function (dither) {
if (this.mDrawableContainerState.mDither != dither) {
this.mDrawableContainerState.mDither = dither;
if (this.mCurrDrawable != null) {
this.mCurrDrawable.setDither (this.mDrawableContainerState.mDither);
}}}, "~B");
Clazz.defineMethod (c$, "setColorFilter", 
function (cf) {
if (this.mColorFilter !== cf) {
this.mColorFilter = cf;
if (this.mCurrDrawable != null) {
this.mCurrDrawable.setColorFilter (cf);
}}}, "android.graphics.ColorFilter");
Clazz.overrideMethod (c$, "onBoundsChange", 
function (bounds) {
if (this.mCurrDrawable != null) {
this.mCurrDrawable.setBounds (bounds);
}}, "android.graphics.Rect");
Clazz.defineMethod (c$, "isStateful", 
function () {
return this.mDrawableContainerState.isStateful ();
});
Clazz.overrideMethod (c$, "onStateChange", 
function (state) {
if (this.mCurrDrawable != null) {
return this.mCurrDrawable.setState (state);
}return false;
}, "~A");
Clazz.overrideMethod (c$, "onLevelChange", 
function (level) {
if (this.mCurrDrawable != null) {
return this.mCurrDrawable.setLevel (level);
}return false;
}, "~N");
Clazz.defineMethod (c$, "getIntrinsicWidth", 
function () {
if (this.mDrawableContainerState.isConstantSize ()) {
return this.mDrawableContainerState.getConstantWidth ();
}return this.mCurrDrawable != null ? this.mCurrDrawable.getIntrinsicWidth () : -1;
});
Clazz.defineMethod (c$, "getIntrinsicHeight", 
function () {
if (this.mDrawableContainerState.isConstantSize ()) {
return this.mDrawableContainerState.getConstantHeight ();
}return this.mCurrDrawable != null ? this.mCurrDrawable.getIntrinsicHeight () : -1;
});
Clazz.defineMethod (c$, "getMinimumWidth", 
function () {
if (this.mDrawableContainerState.isConstantSize ()) {
return this.mDrawableContainerState.getConstantMinimumWidth ();
}return this.mCurrDrawable != null ? this.mCurrDrawable.getMinimumWidth () : 0;
});
Clazz.defineMethod (c$, "getMinimumHeight", 
function () {
if (this.mDrawableContainerState.isConstantSize ()) {
return this.mDrawableContainerState.getConstantMinimumHeight ();
}return this.mCurrDrawable != null ? this.mCurrDrawable.getMinimumHeight () : 0;
});
Clazz.defineMethod (c$, "invalidateDrawable", 
function (who) {
if (who === this.mCurrDrawable && this.mCallback != null) {
this.mCallback.invalidateDrawable (this);
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "scheduleDrawable", 
function (who, what, when) {
if (who === this.mCurrDrawable && this.mCallback != null) {
this.mCallback.scheduleDrawable (this, what, when);
}}, "android.graphics.drawable.Drawable,Runnable,~N");
Clazz.defineMethod (c$, "unscheduleDrawable", 
function (who, what) {
if (who === this.mCurrDrawable && this.mCallback != null) {
this.mCallback.unscheduleDrawable (this, what);
}}, "android.graphics.drawable.Drawable,Runnable");
Clazz.defineMethod (c$, "setVisible", 
function (visible, restart) {
var changed = Clazz.superCall (this, android.graphics.drawable.DrawableContainer, "setVisible", [visible, restart]);
if (this.mCurrDrawable != null) {
this.mCurrDrawable.setVisible (visible, restart);
}return changed;
}, "~B,~B");
Clazz.defineMethod (c$, "getOpacity", 
function () {
return this.mCurrDrawable == null || !this.mCurrDrawable.isVisible () ? -2 : this.mDrawableContainerState.getOpacity ();
});
Clazz.defineMethod (c$, "selectDrawable", 
function (idx) {
if (idx == this.mCurIndex) {
return false;
}if (idx >= 0 && idx < this.mDrawableContainerState.mNumChildren) {
var d = this.mDrawableContainerState.mDrawables[idx];
if (this.mCurrDrawable != null) {
this.mCurrDrawable.setVisible (false, false);
}this.mCurrDrawable = d;
this.mCurIndex = idx;
if (d != null) {
d.setVisible (this.isVisible (), true);
d.setAlpha (this.mAlpha);
d.setDither (this.mDrawableContainerState.mDither);
d.setColorFilter (this.mColorFilter);
d.setState (this.getState ());
d.setLevel (this.getLevel ());
d.setBounds (this.getBounds ());
}} else {
if (this.mCurrDrawable != null) {
this.mCurrDrawable.setVisible (false, false);
}this.mCurrDrawable = null;
this.mCurIndex = -1;
}this.invalidateSelf ();
return true;
}, "~N");
Clazz.overrideMethod (c$, "getCurrent", 
function () {
return this.mCurrDrawable;
});
Clazz.defineMethod (c$, "getConstantState", 
function () {
if (this.mDrawableContainerState.canConstantState ()) {
this.mDrawableContainerState.mChangingConfigurations = Clazz.superCall (this, android.graphics.drawable.DrawableContainer, "getChangingConfigurations", []);
return this.mDrawableContainerState;
}return null;
});
Clazz.defineMethod (c$, "mutate", 
function () {
if (!this.mMutated && Clazz.superCall (this, android.graphics.drawable.DrawableContainer, "mutate", []) === this) {
var N = this.mDrawableContainerState.getChildCount ();
var drawables = this.mDrawableContainerState.getChildren ();
for (var i = 0; i < N; i++) {
if (drawables[i] != null) drawables[i].mutate ();
}
this.mMutated = true;
}return this;
});
Clazz.defineMethod (c$, "setConstantState", 
function (state) {
this.mDrawableContainerState = state;
}, "android.graphics.drawable.DrawableContainer.DrawableContainerState");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mOwner = null;
this.mChangingConfigurations = 0;
this.mChildrenChangingConfigurations = 0;
this.mDrawables = null;
this.mNumChildren = 0;
this.mVariablePadding = false;
this.mConstantPadding = null;
this.mConstantSize = false;
this.mComputedConstantSize = false;
this.mConstantWidth = 0;
this.mConstantHeight = 0;
this.mConstantMinimumWidth = 0;
this.mConstantMinimumHeight = 0;
this.mHaveOpacity = false;
this.mOpacity = 0;
this.mHaveStateful = false;
this.mStateful = false;
this.mCheckedConstantState = false;
this.mCanConstantState = false;
this.mPaddingChecked = false;
this.mDither = true;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.DrawableContainer, "DrawableContainerState", android.graphics.drawable.Drawable.ConstantState);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.graphics.drawable.DrawableContainer.DrawableContainerState, []);
this.mOwner = b;
if (a != null) {
this.mChangingConfigurations = a.mChangingConfigurations;
this.mChildrenChangingConfigurations = a.mChildrenChangingConfigurations;
var d = a.mDrawables;
this.mDrawables =  new Array (d.length);
this.mNumChildren = a.mNumChildren;
var e = this.mNumChildren;
for (var f = 0; f < e; f++) {
if (c != null) {
this.mDrawables[f] = d[f].getConstantState ().newDrawable (c);
} else {
this.mDrawables[f] = d[f].getConstantState ().newDrawable ();
}this.mDrawables[f].setCallback (b);
}
this.mCheckedConstantState = this.mCanConstantState = true;
this.mVariablePadding = a.mVariablePadding;
if (a.mConstantPadding != null) {
this.mConstantPadding =  new android.graphics.Rect (a.mConstantPadding);
}this.mConstantSize = a.mConstantSize;
this.mComputedConstantSize = a.mComputedConstantSize;
this.mConstantWidth = a.mConstantWidth;
this.mConstantHeight = a.mConstantHeight;
this.mHaveOpacity = a.mHaveOpacity;
this.mOpacity = a.mOpacity;
this.mHaveStateful = a.mHaveStateful;
this.mStateful = a.mStateful;
this.mDither = a.mDither;
} else {
this.mDrawables =  new Array (10);
this.mNumChildren = 0;
this.mCheckedConstantState = this.mCanConstantState = false;
}}, "android.graphics.drawable.DrawableContainer.DrawableContainerState,android.graphics.drawable.DrawableContainer,android.content.res.Resources");
Clazz.overrideMethod (c$, "getChangingConfigurations", 
function () {
return this.mChangingConfigurations;
});
Clazz.defineMethod (c$, "addChild", 
function (a) {
var b = this.mNumChildren;
if (b >= this.mDrawables.length) {
this.growArray (b, b + 10);
}a.setVisible (false, true);
a.setCallback (this.mOwner);
this.mDrawables[b] = a;
this.mNumChildren++;
this.mChildrenChangingConfigurations |= a.getChangingConfigurations ();
this.mHaveOpacity = false;
this.mHaveStateful = false;
this.mConstantPadding = null;
this.mPaddingChecked = false;
this.mComputedConstantSize = false;
return b;
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "getChildCount", 
function () {
return this.mNumChildren;
});
Clazz.defineMethod (c$, "getChildren", 
function () {
return this.mDrawables;
});
Clazz.defineMethod (c$, "setVariablePadding", 
function (a) {
this.mVariablePadding = a;
}, "~B");
Clazz.defineMethod (c$, "getConstantPadding", 
function () {
if (this.mVariablePadding) {
return null;
}if (this.mConstantPadding != null || this.mPaddingChecked) {
return this.mConstantPadding;
}var a = null;
var b =  new android.graphics.Rect ();
var c = this.getChildCount ();
var d = this.mDrawables;
for (var e = 0; e < c; e++) {
if (d[e].getPadding (b)) {
if (a == null) a =  new android.graphics.Rect (0, 0, 0, 0);
if (b.left > a.left) a.left = b.left;
if (b.top > a.top) a.top = b.top;
if (b.right > a.right) a.right = b.right;
if (b.bottom > a.bottom) a.bottom = b.bottom;
}}
this.mPaddingChecked = true;
return (this.mConstantPadding = a);
});
Clazz.defineMethod (c$, "setConstantSize", 
function (a) {
this.mConstantSize = a;
}, "~B");
Clazz.defineMethod (c$, "isConstantSize", 
function () {
return this.mConstantSize;
});
Clazz.defineMethod (c$, "getConstantWidth", 
function () {
if (!this.mComputedConstantSize) {
this.computeConstantSize ();
}return this.mConstantWidth;
});
Clazz.defineMethod (c$, "getConstantHeight", 
function () {
if (!this.mComputedConstantSize) {
this.computeConstantSize ();
}return this.mConstantHeight;
});
Clazz.defineMethod (c$, "getConstantMinimumWidth", 
function () {
if (!this.mComputedConstantSize) {
this.computeConstantSize ();
}return this.mConstantMinimumWidth;
});
Clazz.defineMethod (c$, "getConstantMinimumHeight", 
function () {
if (!this.mComputedConstantSize) {
this.computeConstantSize ();
}return this.mConstantMinimumHeight;
});
Clazz.defineMethod (c$, "computeConstantSize", 
($fz = function () {
this.mComputedConstantSize = true;
var a = this.getChildCount ();
var b = this.mDrawables;
this.mConstantWidth = this.mConstantHeight = 0;
this.mConstantMinimumWidth = this.mConstantMinimumHeight = 0;
for (var c = 0; c < a; c++) {
var d = b[c];
var e = d.getIntrinsicWidth ();
if (e > this.mConstantWidth) this.mConstantWidth = e;
e = d.getIntrinsicHeight ();
if (e > this.mConstantHeight) this.mConstantHeight = e;
e = d.getMinimumWidth ();
if (e > this.mConstantMinimumWidth) this.mConstantMinimumWidth = e;
e = d.getMinimumHeight ();
if (e > this.mConstantMinimumHeight) this.mConstantMinimumHeight = e;
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getOpacity", 
function () {
if (this.mHaveOpacity) {
return this.mOpacity;
}var a = this.getChildCount ();
var b = this.mDrawables;
var c = a > 0 ? b[0].getOpacity () : -2;
for (var d = 1; d < a; d++) {
c = android.graphics.drawable.Drawable.resolveOpacity (c, b[d].getOpacity ());
}
this.mOpacity = c;
this.mHaveOpacity = true;
return c;
});
Clazz.defineMethod (c$, "isStateful", 
function () {
if (this.mHaveStateful) {
return this.mStateful;
}var a = false;
var b = this.getChildCount ();
for (var c = 0; c < b; c++) {
if (this.mDrawables[c].isStateful ()) {
a = true;
break;
}}
this.mStateful = a;
this.mHaveStateful = true;
return a;
});
Clazz.defineMethod (c$, "growArray", 
function (a, b) {
var c =  new Array (b);
System.arraycopy (this.mDrawables, 0, c, 0, a);
this.mDrawables = c;
}, "~N,~N");
Clazz.defineMethod (c$, "canConstantState", 
function () {
if (!this.mCheckedConstantState) {
this.mCanConstantState = true;
var a = this.mNumChildren;
for (var b = 0; b < a; b++) {
if (this.mDrawables[b].getConstantState () == null) {
this.mCanConstantState = false;
break;
}}
this.mCheckedConstantState = true;
}return this.mCanConstantState;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DEFAULT_DITHER", true);
});
