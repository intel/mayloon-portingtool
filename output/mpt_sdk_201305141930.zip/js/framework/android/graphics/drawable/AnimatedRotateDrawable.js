﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Drawable"], "android.graphics.drawable.AnimatedRotateDrawable", ["android.os.SystemClock", "android.util.Log", "com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mState = null;
this.mMutated = false;
this.mCurrentDegrees = 0;
this.mIncrement = 0;
this.mRunning = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "AnimatedRotateDrawable", android.graphics.drawable.Drawable, [android.graphics.drawable.Drawable.Callback, Runnable]);
Clazz.makeConstructor (c$, 
function () {
this.construct (null, null);
});
Clazz.makeConstructor (c$, 
($fz = function (rotateState, res) {
Clazz.superConstructor (this, android.graphics.drawable.AnimatedRotateDrawable, []);
this.mState =  new android.graphics.drawable.AnimatedRotateDrawable.AnimatedRotateState (rotateState, this, res);
this.init ();
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.AnimatedRotateDrawable.AnimatedRotateState,android.content.res.Resources");
Clazz.defineMethod (c$, "init", 
($fz = function () {
var state = this.mState;
this.mIncrement = 360.0 / state.mFramesCount;
var drawable = state.mDrawable;
if (drawable != null) {
drawable.setFilterBitmap (true);
if (Clazz.instanceOf (drawable, android.graphics.drawable.BitmapDrawable)) {
}}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "draw", 
function (canvas) {
var saveCount = canvas.save ();
var st = this.mState;
var drawable = st.mDrawable;
var bounds = drawable.getBounds ();
var w = bounds.right - bounds.left;
var h = bounds.bottom - bounds.top;
var px = st.mPivotXRel ? (w * st.mPivotX) : st.mPivotX;
var py = st.mPivotYRel ? (h * st.mPivotY) : st.mPivotY;
canvas.rotate (this.mCurrentDegrees, px, py);
drawable.draw (canvas);
canvas.restoreToCount (saveCount);
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "start", 
function () {
if (!this.mRunning) {
this.mRunning = true;
this.nextFrame ();
}});
Clazz.defineMethod (c$, "stop", 
function () {
this.mRunning = false;
this.unscheduleSelf (this);
});
Clazz.defineMethod (c$, "isRunning", 
function () {
return this.mRunning;
});
Clazz.defineMethod (c$, "nextFrame", 
($fz = function () {
this.scheduleSelf (this, android.os.SystemClock.uptimeMillis () + this.mState.mFrameDuration);
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "run", 
function () {
this.mCurrentDegrees += this.mIncrement;
if (this.mCurrentDegrees > (360.0 - this.mIncrement)) {
this.mCurrentDegrees = 0.0;
}this.invalidateSelf ();
this.nextFrame ();
});
Clazz.defineMethod (c$, "setVisible", 
function (visible, restart) {
this.mState.mDrawable.setVisible (visible, restart);
var changed = Clazz.superCall (this, android.graphics.drawable.AnimatedRotateDrawable, "setVisible", [visible, restart]);
if (visible) {
if (changed || restart) {
this.mCurrentDegrees = 0.0;
this.nextFrame ();
}} else {
this.unscheduleSelf (this);
}return changed;
}, "~B,~B");
Clazz.defineMethod (c$, "getDrawable", 
function () {
return this.mState.mDrawable;
});
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
return Clazz.superCall (this, android.graphics.drawable.AnimatedRotateDrawable, "getChangingConfigurations", []) | this.mState.mChangingConfigurations | this.mState.mDrawable.getChangingConfigurations ();
});
Clazz.defineMethod (c$, "setAlpha", 
function (alpha) {
this.mState.mDrawable.setAlpha (alpha);
}, "~N");
Clazz.defineMethod (c$, "setColorFilter", 
function (cf) {
this.mState.mDrawable.setColorFilter (cf);
}, "android.graphics.ColorFilter");
Clazz.defineMethod (c$, "getOpacity", 
function () {
return this.mState.mDrawable.getOpacity ();
});
Clazz.defineMethod (c$, "invalidateDrawable", 
function (who) {
if (this.mCallback != null) {
this.mCallback.invalidateDrawable (this);
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "scheduleDrawable", 
function (who, what, when) {
if (this.mCallback != null) {
this.mCallback.scheduleDrawable (this, what, when);
}}, "android.graphics.drawable.Drawable,Runnable,~N");
Clazz.defineMethod (c$, "unscheduleDrawable", 
function (who, what) {
if (this.mCallback != null) {
this.mCallback.unscheduleDrawable (this, what);
}}, "android.graphics.drawable.Drawable,Runnable");
Clazz.defineMethod (c$, "getPadding", 
function (padding) {
return this.mState.mDrawable.getPadding (padding);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "isStateful", 
function () {
return this.mState.mDrawable.isStateful ();
});
Clazz.overrideMethod (c$, "onBoundsChange", 
function (bounds) {
this.mState.mDrawable.setBounds (bounds.left, bounds.top, bounds.right, bounds.bottom);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "getIntrinsicWidth", 
function () {
return this.mState.mDrawable.getIntrinsicWidth ();
});
Clazz.defineMethod (c$, "getIntrinsicHeight", 
function () {
return this.mState.mDrawable.getIntrinsicHeight ();
});
Clazz.defineMethod (c$, "getConstantState", 
function () {
if (this.mState.canConstantState ()) {
this.mState.mChangingConfigurations = Clazz.superCall (this, android.graphics.drawable.AnimatedRotateDrawable, "getChangingConfigurations", []);
return this.mState;
}return null;
});
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.AnimatedRotateDrawable);
Clazz.superCall (this, android.graphics.drawable.AnimatedRotateDrawable, "inflateWithAttributes", [r, parser, a, 0]);
var tv = a.peekValue (2);
var pivotXRel = tv.type == 6;
var pivotX = pivotXRel ? tv.getFraction (1.0, 1.0) : tv.getFloat ();
tv = a.peekValue (3);
var pivotYRel = tv.type == 6;
var pivotY = pivotYRel ? tv.getFraction (1.0, 1.0) : tv.getFloat ();
var framesCount = a.getInt (5, 12);
var frameDuration = a.getInt (4, 150);
var res = a.getResourceId (1, 0);
var drawable = null;
if (res > 0) {
drawable = r.getDrawable (res);
}a.recycle ();
var outerDepth = parser.getDepth ();
var type;
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
System.out.println ("NONONONO");
if (type != 2) {
continue ;}if ((drawable = android.graphics.drawable.Drawable.createFromXmlInner (r, parser, attrs)) == null) {
android.util.Log.w ("drawable", "Bad element under <animated-rotate>: " + parser.getName ());
}}
if (drawable == null) {
android.util.Log.w ("drawable", "No drawable specified for <animated-rotate>");
}var rotateState = this.mState;
rotateState.mDrawable = drawable;
rotateState.mPivotXRel = pivotXRel;
rotateState.mPivotX = pivotX;
rotateState.mPivotYRel = pivotYRel;
rotateState.mPivotY = pivotY;
rotateState.mFramesCount = framesCount;
rotateState.mFrameDuration = frameDuration;
this.init ();
if (drawable != null) {
drawable.setCallback (this);
}}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "mutate", 
function () {
if (!this.mMutated && Clazz.superCall (this, android.graphics.drawable.AnimatedRotateDrawable, "mutate", []) === this) {
this.mState.mDrawable.mutate ();
this.mMutated = true;
}return this;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mDrawable = null;
this.mChangingConfigurations = 0;
this.mPivotXRel = false;
this.mPivotX = 0;
this.mPivotYRel = false;
this.mPivotY = 0;
this.mFrameDuration = 0;
this.mFramesCount = 0;
this.mCanConstantState = false;
this.mCheckedConstantState = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.AnimatedRotateDrawable, "AnimatedRotateState", android.graphics.drawable.Drawable.ConstantState);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.graphics.drawable.AnimatedRotateDrawable.AnimatedRotateState, []);
System.out.println ("AnimatedRotateState()");
if (a != null) {
if (c != null) {
this.mDrawable = a.mDrawable.getConstantState ().newDrawable (c);
} else {
this.mDrawable = a.mDrawable.getConstantState ().newDrawable ();
}console.log(this.mDrawable);
this.mDrawable.setCallback (b);
this.mPivotXRel = a.mPivotXRel;
this.mPivotX = a.mPivotX;
this.mPivotYRel = a.mPivotYRel;
this.mPivotY = a.mPivotY;
this.mFramesCount = a.mFramesCount;
this.mFrameDuration = a.mFrameDuration;
this.mCanConstantState = this.mCheckedConstantState = true;
}}, "android.graphics.drawable.AnimatedRotateDrawable.AnimatedRotateState,android.graphics.drawable.AnimatedRotateDrawable,android.content.res.Resources");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.AnimatedRotateDrawable (this, null);
});
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return  new android.graphics.drawable.AnimatedRotateDrawable (this, a);
}, "android.content.res.Resources");
Clazz.overrideMethod (c$, "getChangingConfigurations", 
function () {
return this.mChangingConfigurations;
});
Clazz.defineMethod (c$, "canConstantState", 
function () {
if (!this.mCheckedConstantState) {
this.mCanConstantState = this.mDrawable.getConstantState () != null;
this.mCheckedConstantState = true;
}return this.mCanConstantState;
});
c$ = Clazz.p0p ();
});
