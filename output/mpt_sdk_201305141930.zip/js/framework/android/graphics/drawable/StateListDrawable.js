﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.DrawableContainer"], "android.graphics.drawable.StateListDrawable", ["android.graphics.drawable.Drawable", "android.util.StateSet", "com.android.internal.R", "org.xmlpull.v1.XmlPullParserException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mStateListState = null;
this.$mMutated = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "StateListDrawable", android.graphics.drawable.DrawableContainer);
Clazz.makeConstructor (c$, 
function () {
this.construct (null, null);
});
Clazz.defineMethod (c$, "addState", 
function (stateSet, drawable) {
if (drawable != null) {
this.mStateListState.addStateSet (stateSet, drawable);
this.onStateChange (this.getState ());
}}, "~A,android.graphics.drawable.Drawable");
Clazz.overrideMethod (c$, "isStateful", 
function () {
return true;
});
Clazz.defineMethod (c$, "onStateChange", 
function (stateSet) {
var idx = this.mStateListState.indexOfStateSet (stateSet);
if (idx < 0) {
idx = this.mStateListState.indexOfStateSet (android.util.StateSet.WILD_CARD);
}if (this.selectDrawable (idx)) {
return true;
}return Clazz.superCall (this, android.graphics.drawable.StateListDrawable, "onStateChange", [stateSet]);
}, "~A");
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.StateListDrawable);
Clazz.superCall (this, android.graphics.drawable.StateListDrawable, "inflateWithAttributes", [r, parser, a, 1]);
this.mStateListState.setVariablePadding (a.getBoolean (2, false));
this.mStateListState.setConstantSize (a.getBoolean (3, false));
this.setDither (a.getBoolean (0, true));
a.recycle ();
var type;
var innerDepth = parser.getDepth () + 1;
var depth;
while ((type = parser.next ()) != 1 && ((depth = parser.getDepth ()) >= innerDepth || type != 3)) {
if (type != 2) {
continue ;}if (depth > innerDepth || !parser.getName ().equals ("item")) {
continue ;}var drawableRes = 0;
var i;
var j = 0;
var numAttrs = attrs.getAttributeCount ();
var states =  Clazz.newArray (numAttrs, 0);
for (i = 0; i < numAttrs; i++) {
var stateResId = attrs.getAttributeNameResource (i);
if (stateResId == 0) break;
if (stateResId == 16843161) {
drawableRes = attrs.getAttributeResourceValue (i, 0);
} else {
states[j++] = attrs.getAttributeBooleanValue (i, false) ? stateResId : -stateResId;
}}
states = android.util.StateSet.trimStateSet (states, j);
var dr;
if (drawableRes != 0) {
dr = r.getDrawable (drawableRes);
} else {
while ((type = parser.next ()) == 4) {
}
if (type != 2) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <item> tag requires a 'drawable' attribute or " + "child tag defining a drawable");
}dr = android.graphics.drawable.Drawable.createFromXmlInner (r, parser, attrs);
}if (dr == null) {
continue ;}this.mStateListState.addStateSet (states, dr);
}
this.onStateChange (this.getState ());
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "getStateListState", 
function () {
return this.mStateListState;
});
Clazz.defineMethod (c$, "getStateCount", 
function () {
return this.mStateListState.getChildCount ();
});
Clazz.defineMethod (c$, "getStateSet", 
function (index) {
return this.mStateListState.mStateSets[index];
}, "~N");
Clazz.defineMethod (c$, "getStateDrawable", 
function (index) {
return this.mStateListState.getChildren ()[index];
}, "~N");
Clazz.defineMethod (c$, "getStateDrawableIndex", 
function (stateSet) {
return this.mStateListState.indexOfStateSet (stateSet);
}, "~A");
Clazz.defineMethod (c$, "mutate", 
function () {
if (!this.$mMutated && Clazz.superCall (this, android.graphics.drawable.StateListDrawable, "mutate", []) === this) {
var sets = this.mStateListState.mStateSets;
var count = sets.length;
this.mStateListState.mStateSets =  Clazz.newArray (count, 0);
for (var i = 0; i < count; i++) {
this.mStateListState.mStateSets[i] = sets[i].clone ();
}
this.$mMutated = true;
}return this;
});
Clazz.makeConstructor (c$, 
($fz = function (state, res) {
Clazz.superConstructor (this, android.graphics.drawable.StateListDrawable, []);
var as =  new android.graphics.drawable.StateListDrawable.StateListState (state, this, res);
this.mStateListState = as;
this.setConstantState (as);
this.onStateChange (this.getState ());
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.StateListDrawable.StateListState,android.content.res.Resources");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mStateSets = null;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.StateListDrawable, "StateListState", android.graphics.drawable.DrawableContainer.DrawableContainerState);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.graphics.drawable.StateListDrawable.StateListState, [a, b, c]);
if (a != null) {
this.mStateSets = a.mStateSets;
} else {
this.mStateSets =  Clazz.newArray (this.getChildren ().length, 0);
}}, "android.graphics.drawable.StateListDrawable.StateListState,android.graphics.drawable.StateListDrawable,android.content.res.Resources");
Clazz.defineMethod (c$, "addStateSet", 
function (a, b) {
var c = this.addChild (b);
this.mStateSets[c] = a;
return c;
}, "~A,android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "indexOfStateSet", 
($fz = function (a) {
var b = this.mStateSets;
var c = this.getChildCount ();
for (var d = 0; d < c; d++) {
if (android.util.StateSet.stateSetMatches (b[d], a)) {
return d;
}}
return -1;
}, $fz.isPrivate = true, $fz), "~A");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.StateListDrawable (this, null);
});
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return  new android.graphics.drawable.StateListDrawable (this, a);
}, "android.content.res.Resources");
Clazz.defineMethod (c$, "growArray", 
function (a, b) {
Clazz.superCall (this, android.graphics.drawable.StateListDrawable.StateListState, "growArray", [a, b]);
var c =  Clazz.newArray (b, 0);
System.arraycopy (this.mStateSets, 0, c, 0, a);
this.mStateSets = c;
}, "~N,~N");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"$DEFAULT_DITHER", true);
});
