﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Drawable", "android.graphics.Rect"], "android.graphics.drawable.ClipDrawable", ["android.view.Gravity", "com.android.internal.R", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mClipState = null;
this.mTmpRect = null;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "ClipDrawable", android.graphics.drawable.Drawable, android.graphics.drawable.Drawable.Callback);
Clazz.prepareFields (c$, function () {
this.mTmpRect =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function () {
this.construct (null, null);
});
Clazz.makeConstructor (c$, 
function (drawable, gravity, orientation) {
this.construct (null, null);
this.mClipState.mDrawable = drawable;
this.mClipState.mGravity = gravity;
this.mClipState.mOrientation = orientation;
if (drawable != null) {
drawable.setCallback (this);
}}, "android.graphics.drawable.Drawable,~N,~N");
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
Clazz.superCall (this, android.graphics.drawable.ClipDrawable, "inflate", [r, parser, attrs]);
var type;
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.ClipDrawable);
var orientation = a.getInt (2, 1);
var g = a.getInt (0, 3);
var dr = a.getDrawable (1);
a.recycle ();
var outerDepth = parser.getDepth ();
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type != 2) {
continue ;}dr = android.graphics.drawable.Drawable.createFromXmlInner (r, parser, attrs);
}
if (dr == null) {
throw  new IllegalArgumentException ("No drawable specified for <clip>");
}this.mClipState.mDrawable = dr;
this.mClipState.mOrientation = orientation;
this.mClipState.mGravity = g;
dr.setCallback (this);
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "invalidateDrawable", 
function (who) {
if (this.mCallback != null) {
this.mCallback.invalidateDrawable (this);
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "scheduleDrawable", 
function (who, what, when) {
if (this.mCallback != null) {
this.mCallback.scheduleDrawable (this, what, when);
}}, "android.graphics.drawable.Drawable,Runnable,~N");
Clazz.defineMethod (c$, "unscheduleDrawable", 
function (who, what) {
if (this.mCallback != null) {
this.mCallback.unscheduleDrawable (this, what);
}}, "android.graphics.drawable.Drawable,Runnable");
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
return Clazz.superCall (this, android.graphics.drawable.ClipDrawable, "getChangingConfigurations", []) | this.mClipState.mChangingConfigurations | this.mClipState.mDrawable.getChangingConfigurations ();
});
Clazz.defineMethod (c$, "getPadding", 
function (padding) {
return this.mClipState.mDrawable.getPadding (padding);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "setVisible", 
function (visible, restart) {
this.mClipState.mDrawable.setVisible (visible, restart);
return Clazz.superCall (this, android.graphics.drawable.ClipDrawable, "setVisible", [visible, restart]);
}, "~B,~B");
Clazz.defineMethod (c$, "setAlpha", 
function (alpha) {
this.mClipState.mDrawable.setAlpha (alpha);
}, "~N");
Clazz.defineMethod (c$, "setColorFilter", 
function (cf) {
this.mClipState.mDrawable.setColorFilter (cf);
}, "android.graphics.ColorFilter");
Clazz.defineMethod (c$, "getOpacity", 
function () {
return this.mClipState.mDrawable.getOpacity ();
});
Clazz.defineMethod (c$, "isStateful", 
function () {
return this.mClipState.mDrawable.isStateful ();
});
Clazz.overrideMethod (c$, "onStateChange", 
function (state) {
return this.mClipState.mDrawable.setState (state);
}, "~A");
Clazz.overrideMethod (c$, "onLevelChange", 
function (level) {
this.mClipState.mDrawable.setLevel (level);
this.invalidateSelf ();
return true;
}, "~N");
Clazz.overrideMethod (c$, "onBoundsChange", 
function (bounds) {
this.mClipState.mDrawable.setBounds (bounds);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "draw", 
function (canvas) {
if (this.mClipState.mDrawable.getLevel () == 0) {
return ;
}var r = this.mTmpRect;
var bounds = this.getBounds ();
var level = this.getLevel ();
var w = bounds.width ();
var iw = 0;
if ((this.mClipState.mOrientation & 1) != 0) {
w -= Math.floor ((w - 0) * (10000 - level) / 10000);
}var h = bounds.height ();
var ih = 0;
if ((this.mClipState.mOrientation & 2) != 0) {
h -= Math.floor ((h - 0) * (10000 - level) / 10000);
}android.view.Gravity.apply (this.mClipState.mGravity, w, h, bounds, r);
if (w > 0 && h > 0) {
canvas.save ();
canvas.clipRect (r);
this.mClipState.mDrawable.draw (canvas);
canvas.restore ();
}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "getIntrinsicWidth", 
function () {
return this.mClipState.mDrawable.getIntrinsicWidth ();
});
Clazz.defineMethod (c$, "getIntrinsicHeight", 
function () {
return this.mClipState.mDrawable.getIntrinsicHeight ();
});
Clazz.defineMethod (c$, "getConstantState", 
function () {
if (this.mClipState.canConstantState ()) {
this.mClipState.mChangingConfigurations = this.getChangingConfigurations ();
return this.mClipState;
}return null;
});
Clazz.makeConstructor (c$, 
($fz = function (state, res) {
Clazz.superConstructor (this, android.graphics.drawable.ClipDrawable, []);
this.mClipState =  new android.graphics.drawable.ClipDrawable.ClipState (state, this, res);
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.ClipDrawable.ClipState,android.content.res.Resources");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mDrawable = null;
this.mChangingConfigurations = 0;
this.mOrientation = 0;
this.mGravity = 0;
this.mCheckedConstantState = false;
this.mCanConstantState = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.ClipDrawable, "ClipState", android.graphics.drawable.Drawable.ConstantState);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.graphics.drawable.ClipDrawable.ClipState, []);
if (a != null) {
if (c != null) {
this.mDrawable = a.mDrawable.getConstantState ().newDrawable (c);
} else {
this.mDrawable = a.mDrawable.getConstantState ().newDrawable ();
}this.mDrawable.setCallback (b);
this.mOrientation = a.mOrientation;
this.mGravity = a.mGravity;
this.mCheckedConstantState = this.mCanConstantState = true;
}}, "android.graphics.drawable.ClipDrawable.ClipState,android.graphics.drawable.ClipDrawable,android.content.res.Resources");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.ClipDrawable (this, null);
});
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return  new android.graphics.drawable.ClipDrawable (this, a);
}, "android.content.res.Resources");
Clazz.overrideMethod (c$, "getChangingConfigurations", 
function () {
return this.mChangingConfigurations;
});
Clazz.defineMethod (c$, "canConstantState", 
function () {
if (!this.mCheckedConstantState) {
this.mCanConstantState = this.mDrawable.getConstantState () != null;
this.mCheckedConstantState = true;
}return this.mCanConstantState;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"HORIZONTAL", 1,
"VERTICAL", 2);
});
