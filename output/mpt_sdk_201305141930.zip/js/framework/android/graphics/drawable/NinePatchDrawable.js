﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Drawable"], "android.graphics.drawable.NinePatchDrawable", ["android.graphics.Bitmap", "$.BitmapFactory", "$.NinePatch", "$.Paint", "$.Rect", "android.util.DisplayMetrics", "$.Log", "$.TypedValue", "com.android.internal.R", "org.xmlpull.v1.XmlPullParserException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mNinePatchState = null;
this.mNinePatch = null;
this.mPadding = null;
this.mPaint = null;
this.mMutated = false;
this.mTargetDensity = 160;
this.mBitmapWidth = 0;
this.mBitmapHeight = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "NinePatchDrawable", android.graphics.drawable.Drawable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.graphics.drawable.NinePatchDrawable, []);
});
Clazz.makeConstructor (c$, 
function (bitmap, chunk, padding, srcName) {
this.construct ( new android.graphics.drawable.NinePatchDrawable.NinePatchState ( new android.graphics.NinePatch (bitmap, chunk, srcName), padding), null);
}, "android.graphics.Bitmap,android.graphics.BitmapFactory.Res_png_9patch,android.graphics.Rect,~S");
Clazz.makeConstructor (c$, 
function (res, bitmap, chunk, padding, srcName) {
this.construct ( new android.graphics.drawable.NinePatchDrawable.NinePatchState ( new android.graphics.NinePatch (bitmap, chunk, srcName), padding), res);
this.mNinePatchState.mTargetDensity = this.mTargetDensity;
}, "android.content.res.Resources,android.graphics.Bitmap,android.graphics.BitmapFactory.Res_png_9patch,android.graphics.Rect,~S");
Clazz.makeConstructor (c$, 
function (patch) {
this.construct ( new android.graphics.drawable.NinePatchDrawable.NinePatchState (patch,  new android.graphics.Rect ()), null);
}, "android.graphics.NinePatch");
Clazz.makeConstructor (c$, 
function (res, patch) {
this.construct ( new android.graphics.drawable.NinePatchDrawable.NinePatchState (patch,  new android.graphics.Rect ()), res);
this.mNinePatchState.mTargetDensity = this.mTargetDensity;
}, "android.content.res.Resources,android.graphics.NinePatch");
Clazz.defineMethod (c$, "setNinePatchState", 
($fz = function (state, res) {
this.mNinePatchState = state;
this.mNinePatch = state.mNinePatch;
this.mPadding = state.mPadding;
this.mTargetDensity = res != null ? res.getDisplayMetrics ().densityDpi : state.mTargetDensity;
if (true != state.mDither) {
this.setDither (state.mDither);
}if (this.mNinePatch != null) {
this.computeBitmapSize ();
}}, $fz.isPrivate = true, $fz), "android.graphics.drawable.NinePatchDrawable.NinePatchState,android.content.res.Resources");
Clazz.defineMethod (c$, "setTargetDensity", 
function (canvas) {
this.setTargetDensity (canvas.getDensity ());
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "setTargetDensity", 
function (metrics) {
this.mTargetDensity = metrics.densityDpi;
if (this.mNinePatch != null) {
this.computeBitmapSize ();
}}, "android.util.DisplayMetrics");
Clazz.defineMethod (c$, "setTargetDensity", 
function (density) {
this.mTargetDensity = density == 0 ? 160 : density;
if (this.mNinePatch != null) {
this.computeBitmapSize ();
}}, "~N");
Clazz.defineMethod (c$, "computeBitmapSize", 
($fz = function () {
var sdensity = this.mNinePatch.getDensity ();
var tdensity = this.mTargetDensity;
if (sdensity == tdensity) {
this.mBitmapWidth = this.mNinePatch.getWidth ();
this.mBitmapHeight = this.mNinePatch.getHeight ();
} else {
this.mBitmapWidth = android.graphics.Bitmap.scaleFromDensity (this.mNinePatch.getWidth (), sdensity, tdensity);
this.mBitmapHeight = android.graphics.Bitmap.scaleFromDensity (this.mNinePatch.getHeight (), sdensity, tdensity);
if (this.mNinePatchState.mPadding != null && this.mPadding != null) {
var dest = this.mPadding;
var src = this.mNinePatchState.mPadding;
if (dest === src) {
this.mPadding = dest =  new android.graphics.Rect (src);
}dest.left = android.graphics.Bitmap.scaleFromDensity (src.left, sdensity, tdensity);
dest.top = android.graphics.Bitmap.scaleFromDensity (src.top, sdensity, tdensity);
dest.right = android.graphics.Bitmap.scaleFromDensity (src.right, sdensity, tdensity);
dest.bottom = android.graphics.Bitmap.scaleFromDensity (src.bottom, sdensity, tdensity);
}}}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "draw", 
function (canvas) {
if (false) {
var pts =  Clazz.newArray (2, 0);
canvas.getMatrix ().mapPoints (pts);
android.util.Log.v ("9patch", "Drawing 9-patch @ " + pts[0] + "," + pts[1] + ": " + this.getBounds ());
}this.mNinePatch.draw (canvas, this.getBounds (), this.mPaint);
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
return Clazz.superCall (this, android.graphics.drawable.NinePatchDrawable, "getChangingConfigurations", []) | this.mNinePatchState.mChangingConfigurations;
});
Clazz.overrideMethod (c$, "getPadding", 
function (padding) {
padding.set (this.mPadding);
return true;
}, "android.graphics.Rect");
Clazz.overrideMethod (c$, "setAlpha", 
function (alpha) {
this.getPaint ().setAlpha (alpha);
}, "~N");
Clazz.defineMethod (c$, "setColorFilter", 
function (cf) {
}, "android.graphics.ColorFilter");
Clazz.overrideMethod (c$, "setDither", 
function (dither) {
this.getPaint ().setDither (dither);
}, "~B");
Clazz.overrideMethod (c$, "setFilterBitmap", 
function (filter) {
}, "~B");
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
Clazz.superCall (this, android.graphics.drawable.NinePatchDrawable, "inflate", [r, parser, attrs]);
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.NinePatchDrawable);
var id = a.getResourceId (0, 0);
if (id == 0) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <nine-patch> requires a valid src attribute");
}var dither = a.getBoolean (1, true);
var options =  new android.graphics.BitmapFactory.Options ();
if (dither) {
options.inDither = false;
}options.inScreenDensity = android.util.DisplayMetrics.DENSITY_DEVICE;
var padding =  new android.graphics.Rect ();
var bitmap = null;
try {
var value =  new android.util.TypedValue ();
var is = r.openRawResource (id, value);
bitmap = android.graphics.BitmapFactory.decodeResourceStream (r, value, is, padding, options);
is.close ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
if (bitmap == null) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <nine-patch> requires a valid src attribute");
} else if (bitmap.getNinePatch () == null) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <nine-patch> requires a valid 9-patch source image");
}this.setNinePatchState ( new android.graphics.drawable.NinePatchDrawable.NinePatchState ( new android.graphics.NinePatch (bitmap, bitmap.getNinePatch (), "XML 9-patch"), padding, dither), r);
this.mNinePatchState.mTargetDensity = this.mTargetDensity;
a.recycle ();
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "getPaint", 
function () {
if (this.mPaint == null) {
this.mPaint =  new android.graphics.Paint ();
this.mPaint.setDither (true);
}return this.mPaint;
});
Clazz.overrideMethod (c$, "getIntrinsicWidth", 
function () {
return this.mBitmapWidth;
});
Clazz.overrideMethod (c$, "getIntrinsicHeight", 
function () {
return this.mBitmapHeight;
});
Clazz.overrideMethod (c$, "getMinimumWidth", 
function () {
return this.mBitmapWidth;
});
Clazz.overrideMethod (c$, "getMinimumHeight", 
function () {
return this.mBitmapHeight;
});
Clazz.overrideMethod (c$, "getOpacity", 
function () {
return this.mNinePatch.hasAlpha () || (this.mPaint != null && this.mPaint.getAlpha () < 255) ? -3 : -1;
});
Clazz.overrideMethod (c$, "getTransparentRegion", 
function () {
return this.mNinePatch.getTransparentRegion (this.getBounds ());
});
Clazz.overrideMethod (c$, "getConstantState", 
function () {
this.mNinePatchState.mChangingConfigurations = Clazz.superCall (this, android.graphics.drawable.NinePatchDrawable, "getChangingConfigurations", []);
return this.mNinePatchState;
});
Clazz.defineMethod (c$, "mutate", 
function () {
if (!this.mMutated && Clazz.superCall (this, android.graphics.drawable.NinePatchDrawable, "mutate", []) === this) {
this.mNinePatchState =  new android.graphics.drawable.NinePatchDrawable.NinePatchState (this.mNinePatchState);
this.mNinePatch = this.mNinePatchState.mNinePatch;
this.mMutated = true;
}return this;
});
Clazz.makeConstructor (c$, 
($fz = function (state, res) {
Clazz.superConstructor (this, android.graphics.drawable.NinePatchDrawable, []);
this.setNinePatchState (state, res);
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.NinePatchDrawable.NinePatchState,android.content.res.Resources");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mNinePatch = null;
this.mPadding = null;
this.mDither = false;
this.mChangingConfigurations = 0;
this.mTargetDensity = 160;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.NinePatchDrawable, "NinePatchState", android.graphics.drawable.Drawable.ConstantState);
Clazz.makeConstructor (c$, 
function (a, b) {
this.construct (a, b, true);
}, "android.graphics.NinePatch,android.graphics.Rect");
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.graphics.drawable.NinePatchDrawable.NinePatchState, []);
this.mNinePatch = a;
this.mPadding = b;
this.mDither = c;
}, "android.graphics.NinePatch,android.graphics.Rect,~B");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.graphics.drawable.NinePatchDrawable.NinePatchState, []);
this.mNinePatch =  new android.graphics.NinePatch (a.mNinePatch);
this.mPadding = a.mPadding;
this.mDither = a.mDither;
this.mChangingConfigurations = a.mChangingConfigurations;
this.mTargetDensity = a.mTargetDensity;
}, "android.graphics.drawable.NinePatchDrawable.NinePatchState");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.NinePatchDrawable (this, null);
});
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return  new android.graphics.drawable.NinePatchDrawable (this, a);
}, "android.content.res.Resources");
Clazz.overrideMethod (c$, "getChangingConfigurations", 
function () {
return this.mChangingConfigurations;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DEFAULT_DITHER", true);
});
