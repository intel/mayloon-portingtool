﻿Clazz.declarePackage ("android.graphics.drawable.shapes");
Clazz.load (["android.graphics.drawable.shapes.Shape", "android.graphics.RectF"], "android.graphics.drawable.shapes.RectShape", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mRect = null;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.shapes, "RectShape", android.graphics.drawable.shapes.Shape);
Clazz.prepareFields (c$, function () {
this.mRect =  new android.graphics.RectF ();
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.graphics.drawable.shapes.RectShape, []);
});
Clazz.overrideMethod (c$, "draw", 
function (canvas, paint) {
canvas.drawRect (this.mRect, paint);
}, "android.graphics.Canvas,android.graphics.Paint");
Clazz.overrideMethod (c$, "onResize", 
function (width, height) {
this.mRect.set (0, 0, width, height);
}, "~N,~N");
Clazz.defineMethod (c$, "rect", 
function () {
return this.mRect;
});
Clazz.defineMethod (c$, "clone", 
function () {
var shape = Clazz.superCall (this, android.graphics.drawable.shapes.RectShape, "clone", []);
shape.mRect =  new android.graphics.RectF (this.mRect);
return shape;
});
});
