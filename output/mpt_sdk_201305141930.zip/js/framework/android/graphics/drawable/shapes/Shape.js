﻿Clazz.declarePackage ("android.graphics.drawable.shapes");
c$ = Clazz.decorateAsClass (function () {
this.mWidth = 0;
this.mHeight = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.shapes, "Shape", null, Cloneable);
Clazz.defineMethod (c$, "getWidth", 
function () {
return this.mWidth;
});
Clazz.defineMethod (c$, "getHeight", 
function () {
return this.mHeight;
});
Clazz.defineMethod (c$, "resize", 
function (width, height) {
if (width < 0) {
width = 0;
}if (height < 0) {
height = 0;
}if (this.mWidth != width || this.mHeight != height) {
this.mWidth = width;
this.mHeight = height;
this.onResize (width, height);
}}, "~N,~N");
Clazz.defineMethod (c$, "hasAlpha", 
function () {
return true;
});
Clazz.defineMethod (c$, "onResize", 
function (width, height) {
}, "~N,~N");
Clazz.defineMethod (c$, "clone", 
function () {
return Clazz.superCall (this, android.graphics.drawable.shapes.Shape, "clone", []);
});
