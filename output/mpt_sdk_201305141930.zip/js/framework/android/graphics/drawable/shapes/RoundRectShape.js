﻿Clazz.declarePackage ("android.graphics.drawable.shapes");
Clazz.load (["android.graphics.drawable.shapes.RectShape"], "android.graphics.drawable.shapes.RoundRectShape", ["android.graphics.Path", "$.RectF", "java.lang.ArrayIndexOutOfBoundsException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mOuterRadii = null;
this.mInset = null;
this.mInnerRadii = null;
this.mInnerRect = null;
this.mPath = null;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.shapes, "RoundRectShape", android.graphics.drawable.shapes.RectShape);
Clazz.makeConstructor (c$, 
function (outerRadii, inset, innerRadii) {
Clazz.superConstructor (this, android.graphics.drawable.shapes.RoundRectShape, []);
if (outerRadii.length < 8) {
throw  new ArrayIndexOutOfBoundsException ("outer radii must have >= 8 values");
}if (innerRadii != null && innerRadii.length < 8) {
throw  new ArrayIndexOutOfBoundsException ("inner radii must have >= 8 values");
}this.mOuterRadii = outerRadii;
this.mInset = inset;
this.mInnerRadii = innerRadii;
if (inset != null) {
this.mInnerRect =  new android.graphics.RectF ();
}this.mPath =  new android.graphics.Path ();
}, "~A,android.graphics.RectF,~A");
Clazz.overrideMethod (c$, "draw", 
function (canvas, paint) {
canvas.drawPath (this.mPath, paint);
}, "android.graphics.Canvas,android.graphics.Paint");
Clazz.defineMethod (c$, "onResize", 
function (w, h) {
Clazz.superCall (this, android.graphics.drawable.shapes.RoundRectShape, "onResize", [w, h]);
var r = this.rect ();
this.mPath.reset ();
if (this.mOuterRadii != null) {
this.mPath.addRoundRect (r, this.mOuterRadii, android.graphics.Path.Path.Direction.CW);
} else {
this.mPath.addRect (r, android.graphics.Path.Path.Direction.CW);
}if (this.mInnerRect != null) {
this.mInnerRect.set (r.left + this.mInset.left, r.top + this.mInset.top, r.right - this.mInset.right, r.bottom - this.mInset.bottom);
if (this.mInnerRect.width () < w && this.mInnerRect.height () < h) {
if (this.mInnerRadii != null) {
this.mPath.addRoundRect (this.mInnerRect, this.mInnerRadii, android.graphics.Path.Path.Direction.CCW);
} else {
this.mPath.addRect (this.mInnerRect, android.graphics.Path.Path.Direction.CCW);
}}}}, "~N,~N");
Clazz.defineMethod (c$, "clone", 
function () {
var shape = Clazz.superCall (this, android.graphics.drawable.shapes.RoundRectShape, "clone", []);
shape.mOuterRadii = this.mOuterRadii.clone ();
shape.mInnerRadii = this.mInnerRadii.clone ();
shape.mInset =  new android.graphics.RectF (this.mInset);
shape.mInnerRect =  new android.graphics.RectF (this.mInnerRect);
shape.mPath =  new android.graphics.Path (this.mPath);
return shape;
});
});
