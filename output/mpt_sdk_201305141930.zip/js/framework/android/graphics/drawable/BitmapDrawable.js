﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Drawable", "android.graphics.Paint", "$.Rect"], "android.graphics.drawable.BitmapDrawable", ["android.graphics.BitmapFactory", "$.BitmapShader", "$.Shader", "android.util.Log", "android.view.Gravity", "com.android.internal.R", "org.xmlpull.v1.XmlPullParserException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mBitmapState = null;
this.mBitmap = null;
this.mTargetDensity = 0;
this.mDstRect = null;
this.mApplyGravity = false;
this.mRebuildShader = false;
this.mMutated = false;
this.mBitmapWidth = 0;
this.mBitmapHeight = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "BitmapDrawable", android.graphics.drawable.Drawable);
Clazz.prepareFields (c$, function () {
this.mDstRect =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.graphics.drawable.BitmapDrawable, []);
this.mBitmapState =  new android.graphics.drawable.BitmapDrawable.BitmapState (Clazz.castNullAs ("android.graphics.Bitmap"));
});
Clazz.makeConstructor (c$, 
function (res) {
Clazz.superConstructor (this, android.graphics.drawable.BitmapDrawable, []);
this.mBitmapState =  new android.graphics.drawable.BitmapDrawable.BitmapState (Clazz.castNullAs ("android.graphics.Bitmap"));
this.mBitmapState.mTargetDensity = this.mTargetDensity;
}, "android.content.res.Resources");
Clazz.makeConstructor (c$, 
function (bitmap) {
this.construct ( new android.graphics.drawable.BitmapDrawable.BitmapState (bitmap), null);
}, "android.graphics.Bitmap");
Clazz.makeConstructor (c$, 
function (res, bitmap) {
this.construct ();
this.mBitmapState.mBitmap = bitmap;
if (res != null) {
this.mTargetDensity = res.getDisplayMetrics ().densityDpi;
} else {
this.mTargetDensity = this.mBitmapState.mTargetDensity;
}this.setBitmap (this.mBitmapState.mBitmap);
}, "android.content.res.Resources,android.graphics.Bitmap");
Clazz.makeConstructor (c$, 
function (filepath) {
this.construct ( new android.graphics.drawable.BitmapDrawable.BitmapState (android.graphics.BitmapFactory.decodeFile (filepath)), null);
if (this.mBitmap == null) {
android.util.Log.w ("BitmapDrawable", "BitmapDrawable cannot decode " + filepath);
}}, "~S");
Clazz.makeConstructor (c$, 
function (res, filepath) {
this.construct ( new android.graphics.drawable.BitmapDrawable.BitmapState (android.graphics.BitmapFactory.decodeFile (filepath)), null);
this.mBitmapState.mTargetDensity = this.mTargetDensity;
if (this.mBitmap == null) {
android.util.Log.w ("BitmapDrawable", "BitmapDrawable cannot decode " + filepath);
}}, "android.content.res.Resources,~S");
Clazz.makeConstructor (c$, 
function (is) {
this.construct ( new android.graphics.drawable.BitmapDrawable.BitmapState (android.graphics.BitmapFactory.decodeStream (is)), null);
if (this.mBitmap == null) {
android.util.Log.w ("BitmapDrawable", "BitmapDrawable cannot decode " + is);
}}, "java.io.InputStream");
Clazz.makeConstructor (c$, 
function (res, is) {
this.construct ( new android.graphics.drawable.BitmapDrawable.BitmapState (android.graphics.BitmapFactory.decodeStream (is)), null);
this.mBitmapState.mTargetDensity = this.mTargetDensity;
if (this.mBitmap == null) {
android.util.Log.w ("BitmapDrawable", "BitmapDrawable cannot decode " + is);
}}, "android.content.res.Resources,java.io.InputStream");
Clazz.defineMethod (c$, "getBitmap", 
function () {
return this.mBitmap;
});
Clazz.defineMethod (c$, "computeBitmapSize", 
($fz = function () {
this.mBitmapWidth = this.mBitmap.getScaledWidth (this.mTargetDensity);
this.mBitmapHeight = this.mBitmap.getScaledHeight (this.mTargetDensity);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setBitmap", 
function (bitmap) {
this.mBitmap = bitmap;
if (bitmap != null) {
this.computeBitmapSize ();
} else {
this.mBitmapWidth = this.mBitmapHeight = -1;
}}, "android.graphics.Bitmap");
Clazz.defineMethod (c$, "setTargetDensity", 
function (metrics) {
this.mTargetDensity = metrics.densityDpi;
if (this.mBitmap != null) {
this.computeBitmapSize ();
}}, "android.util.DisplayMetrics");
Clazz.defineMethod (c$, "setTargetDensity", 
function (density) {
this.mTargetDensity = density == 0 ? 160 : density;
if (this.mBitmap != null) {
this.computeBitmapSize ();
}}, "~N");
Clazz.defineMethod (c$, "getGravity", 
function () {
return this.mBitmapState.mGravity;
});
Clazz.defineMethod (c$, "setGravity", 
function (gravity) {
this.mBitmapState.mGravity = gravity;
this.mApplyGravity = true;
}, "~N");
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
return Clazz.superCall (this, android.graphics.drawable.BitmapDrawable, "getChangingConfigurations", []) | this.mBitmapState.mChangingConfigurations;
});
Clazz.defineMethod (c$, "onBoundsChange", 
function (bounds) {
Clazz.superCall (this, android.graphics.drawable.BitmapDrawable, "onBoundsChange", [bounds]);
this.mApplyGravity = true;
}, "android.graphics.Rect");
Clazz.overrideMethod (c$, "draw", 
function (canvas) {
var bitmap = this.mBitmap;
if (bitmap != null) {
var state = this.mBitmapState;
if (this.mRebuildShader) {
var tmx = state.mTileModeX;
var tmy = state.mTileModeY;
if (tmx == null && tmy == null) {
state.mPaint.setShader (null);
} else {
var s =  new android.graphics.BitmapShader (bitmap, tmx == null ? android.graphics.Shader.Shader.TileMode.CLAMP : tmx, tmy == null ? android.graphics.Shader.Shader.TileMode.CLAMP : tmy);
state.mPaint.setShader (s);
}this.mRebuildShader = false;
this.copyBounds (this.mDstRect);
}var shader = state.mPaint.getShader ();
if (shader == null) {
if (this.mApplyGravity) {
android.view.Gravity.apply (state.mGravity, this.mBitmapWidth, this.mBitmapHeight, this.getBounds (), this.mDstRect);
this.mApplyGravity = false;
}canvas.drawBitmap (bitmap, null, this.mDstRect, state.mPaint);
} else {
if (this.mApplyGravity) {
this.mDstRect.set (this.getBounds ());
this.mApplyGravity = false;
}canvas.drawRect (this.mDstRect, state.mPaint);
}}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "mutate", 
function () {
if (!this.mMutated && Clazz.superCall (this, android.graphics.drawable.BitmapDrawable, "mutate", []) === this) {
this.mBitmapState =  new android.graphics.drawable.BitmapDrawable.BitmapState (this.mBitmapState);
this.mMutated = true;
}return this;
});
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
Clazz.superCall (this, android.graphics.drawable.BitmapDrawable, "inflate", [r, parser, attrs]);
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.BitmapDrawable);
var id = a.getResourceId (1, 0);
if (id == 0) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <bitmap> requires a valid src attribute");
}var bitmap = android.graphics.BitmapFactory.decodeResource (r, id);
if (bitmap == null) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <bitmap> requires a valid src attribute");
}a.recycle ();
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.overrideMethod (c$, "getIntrinsicWidth", 
function () {
return this.mBitmapWidth;
});
Clazz.overrideMethod (c$, "getIntrinsicHeight", 
function () {
return this.mBitmapHeight;
});
Clazz.makeConstructor (c$, 
($fz = function (state, res) {
Clazz.superConstructor (this, android.graphics.drawable.BitmapDrawable, []);
this.mBitmapState = state;
if (res != null) {
this.mTargetDensity = res.getDisplayMetrics ().densityDpi;
} else {
this.mTargetDensity = state.mTargetDensity;
}this.setBitmap (state.mBitmap);
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.BitmapDrawable.BitmapState,android.content.res.Resources");
Clazz.defineMethod (c$, "setAntiAlias", 
function (aa) {
console.log("Missing method: setAntiAlias");
}, "~B");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mBitmap = null;
this.mChangingConfigurations = 0;
this.mGravity = 119;
this.mPaint = null;
this.mTileModeX = null;
this.mTileModeY = null;
this.mTargetDensity = 160;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.BitmapDrawable, "BitmapState", android.graphics.drawable.Drawable.ConstantState);
Clazz.prepareFields (c$, function () {
this.mPaint =  new android.graphics.Paint (6);
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.graphics.drawable.BitmapDrawable.BitmapState, []);
this.mBitmap = a;
}, "android.graphics.Bitmap");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a.mBitmap);
this.mChangingConfigurations = a.mChangingConfigurations;
this.mGravity = a.mGravity;
this.mTileModeX = a.mTileModeX;
this.mTileModeY = a.mTileModeY;
this.mTargetDensity = a.mTargetDensity;
this.mPaint =  new android.graphics.Paint (a.mPaint);
}, "android.graphics.drawable.BitmapDrawable.BitmapState");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.BitmapDrawable (this, null);
});
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return  new android.graphics.drawable.BitmapDrawable (this, a);
}, "android.content.res.Resources");
Clazz.overrideMethod (c$, "getChangingConfigurations", 
function () {
return this.mChangingConfigurations;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DEFAULT_PAINT_FLAGS", 6);
});
