﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.drawable.Animatable", "$.DrawableContainer"], "android.graphics.drawable.AnimationDrawable", ["android.graphics.drawable.Drawable", "android.os.SystemClock", "com.android.internal.R", "org.xmlpull.v1.XmlPullParserException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAnimationState = null;
this.mCurFrame = -1;
this.$mMutated = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "AnimationDrawable", android.graphics.drawable.DrawableContainer, [Runnable, android.graphics.drawable.Animatable]);
Clazz.makeConstructor (c$, 
function () {
this.construct (null, null);
});
Clazz.defineMethod (c$, "setVisible", 
function (visible, restart) {
var changed = Clazz.superCall (this, android.graphics.drawable.AnimationDrawable, "setVisible", [visible, restart]);
if (visible) {
if (changed || restart) {
this.setFrame (0, true, true);
}} else {
this.unscheduleSelf (this);
}return changed;
}, "~B,~B");
Clazz.overrideMethod (c$, "start", 
function () {
if (!this.isRunning ()) {
this.run ();
}});
Clazz.overrideMethod (c$, "stop", 
function () {
if (this.isRunning ()) {
this.unscheduleSelf (this);
}});
Clazz.overrideMethod (c$, "isRunning", 
function () {
return this.mCurFrame > -1;
});
Clazz.overrideMethod (c$, "run", 
function () {
this.nextFrame (false);
});
Clazz.defineMethod (c$, "unscheduleSelf", 
function (what) {
this.mCurFrame = -1;
Clazz.superCall (this, android.graphics.drawable.AnimationDrawable, "unscheduleSelf", [what]);
}, "Runnable");
Clazz.defineMethod (c$, "getNumberOfFrames", 
function () {
return this.mAnimationState.getChildCount ();
});
Clazz.defineMethod (c$, "getFrame", 
function (index) {
return this.mAnimationState.getChildren ()[index];
}, "~N");
Clazz.defineMethod (c$, "getDuration", 
function (i) {
return this.mAnimationState.mDurations[i];
}, "~N");
Clazz.defineMethod (c$, "isOneShot", 
function () {
return this.mAnimationState.mOneShot;
});
Clazz.defineMethod (c$, "setOneShot", 
function (oneShot) {
this.mAnimationState.mOneShot = oneShot;
}, "~B");
Clazz.defineMethod (c$, "addFrame", 
function (frame, duration) {
this.mAnimationState.addFrame (frame, duration);
}, "android.graphics.drawable.Drawable,~N");
Clazz.defineMethod (c$, "nextFrame", 
($fz = function (unschedule) {
var next = this.mCurFrame + 1;
var N = this.mAnimationState.getChildCount ();
if (next >= N) {
next = 0;
}this.setFrame (next, unschedule, !this.mAnimationState.mOneShot || next < (N - 1));
}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "setFrame", 
($fz = function (frame, unschedule, animate) {
if (frame >= this.mAnimationState.getChildCount ()) {
return ;
}this.mCurFrame = frame;
this.selectDrawable (frame);
if (unschedule) {
this.unscheduleSelf (this);
}if (animate) {
this.scheduleSelf (this, android.os.SystemClock.uptimeMillis () + this.mAnimationState.mDurations[frame]);
}}, $fz.isPrivate = true, $fz), "~N,~B,~B");
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.AnimationDrawable);
Clazz.superCall (this, android.graphics.drawable.AnimationDrawable, "inflateWithAttributes", [r, parser, a, 0]);
this.mAnimationState.setVariablePadding (a.getBoolean (1, false));
this.mAnimationState.mOneShot = a.getBoolean (2, false);
a.recycle ();
var type;
var innerDepth = parser.getDepth () + 1;
var depth;
while ((type = parser.next ()) != 1 && ((depth = parser.getDepth ()) >= innerDepth || type != 3)) {
if (type != 2) {
continue ;}if (depth > innerDepth || !parser.getName ().equals ("item")) {
continue ;}a = r.obtainAttributes (attrs, com.android.internal.R.styleable.AnimationDrawableItem);
var duration = a.getInt (0, -1);
if (duration < 0) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <item> tag requires a 'duration' attribute");
}var drawableRes = a.getResourceId (1, 0);
a.recycle ();
var dr;
if (drawableRes != 0) {
dr = r.getDrawable (drawableRes);
} else {
while ((type = parser.next ()) == 4) {
}
if (type != 2) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <item> tag requires a 'drawable' attribute or child tag" + " defining a drawable");
}dr = android.graphics.drawable.Drawable.createFromXmlInner (r, parser, attrs);
}this.mAnimationState.addFrame (dr, duration);
if (dr != null) {
dr.setCallback (this);
}}
this.setFrame (0, true, false);
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "mutate", 
function () {
if (!this.$mMutated && Clazz.superCall (this, android.graphics.drawable.AnimationDrawable, "mutate", []) === this) {
this.mAnimationState.mDurations = this.mAnimationState.mDurations.clone ();
this.$mMutated = true;
}return this;
});
Clazz.makeConstructor (c$, 
($fz = function (state, res) {
Clazz.superConstructor (this, android.graphics.drawable.AnimationDrawable, []);
var as =  new android.graphics.drawable.AnimationDrawable.AnimationState (state, this, res);
this.mAnimationState = as;
this.setConstantState (as);
if (state != null) {
this.setFrame (0, true, false);
}}, $fz.isPrivate = true, $fz), "android.graphics.drawable.AnimationDrawable.AnimationState,android.content.res.Resources");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mDurations = null;
this.mOneShot = false;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable.AnimationDrawable, "AnimationState", android.graphics.drawable.DrawableContainer.DrawableContainerState);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.graphics.drawable.AnimationDrawable.AnimationState, [a, b, c]);
if (a != null) {
this.mDurations = a.mDurations;
this.mOneShot = a.mOneShot;
} else {
this.mDurations =  Clazz.newArray (this.getChildren ().length, 0);
this.mOneShot = true;
}}, "android.graphics.drawable.AnimationDrawable.AnimationState,android.graphics.drawable.AnimationDrawable,android.content.res.Resources");
Clazz.defineMethod (c$, "newDrawable", 
function () {
return  new android.graphics.drawable.AnimationDrawable (this, null);
});
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return  new android.graphics.drawable.AnimationDrawable (this, a);
}, "android.content.res.Resources");
Clazz.defineMethod (c$, "addFrame", 
function (a, b) {
var c = Clazz.superCall (this, android.graphics.drawable.AnimationDrawable.AnimationState, "addChild", [a]);
this.mDurations[c] = b;
}, "android.graphics.drawable.Drawable,~N");
Clazz.defineMethod (c$, "growArray", 
function (a, b) {
Clazz.superCall (this, android.graphics.drawable.AnimationDrawable.AnimationState, "growArray", [a, b]);
var c =  Clazz.newArray (b, 0);
System.arraycopy (this.mDurations, 0, c, 0, a);
this.mDurations = c;
}, "~N,~N");
c$ = Clazz.p0p ();
});
