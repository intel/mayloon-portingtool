﻿Clazz.declarePackage ("android.graphics.drawable");
Clazz.load (["android.graphics.Rect", "android.util.StateSet"], "android.graphics.drawable.Drawable", ["android.graphics.BitmapFactory", "android.util.DisplayMetrics", "$.Log", "com.android.internal.R", "java.lang.RuntimeException", "java.util.Arrays", "org.xmlpull.v1.XmlPullParserException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mStateSet = null;
this.mLevel = 0;
this.mChangingConfigurations = 0;
this.mBounds = null;
this.mCallback = null;
this.mVisible = true;
this.URI = null;
Clazz.instantialize (this, arguments);
}, android.graphics.drawable, "Drawable");
Clazz.prepareFields (c$, function () {
this.mStateSet = android.util.StateSet.WILD_CARD;
this.mBounds = android.graphics.drawable.Drawable.ZERO_BOUNDS_RECT;
});
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "toCSS", 
function () {
return null;
});
Clazz.defineMethod (c$, "draw", 
function (canvas) {
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "setColorFilter", 
function (cf) {
}, "android.graphics.ColorFilter");
Clazz.defineMethod (c$, "setBounds", 
function (left, top, right, bottom) {
var oldBounds = this.mBounds;
if (oldBounds === android.graphics.drawable.Drawable.ZERO_BOUNDS_RECT) {
oldBounds = this.mBounds =  new android.graphics.Rect ();
}if (oldBounds.left != left || oldBounds.top != top || oldBounds.right != right || oldBounds.bottom != bottom) {
this.mBounds.set (left, top, right, bottom);
this.onBoundsChange (this.mBounds);
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setBounds", 
function (bounds) {
this.setBounds (bounds.left, bounds.top, bounds.right, bounds.bottom);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "copyBounds", 
function (bounds) {
bounds.set (this.mBounds);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "copyBounds", 
function () {
return  new android.graphics.Rect (this.mBounds);
});
Clazz.defineMethod (c$, "getBounds", 
function () {
if (this.mBounds === android.graphics.drawable.Drawable.ZERO_BOUNDS_RECT) {
this.mBounds =  new android.graphics.Rect ();
}return this.mBounds;
});
Clazz.defineMethod (c$, "setChangingConfigurations", 
function (configs) {
this.mChangingConfigurations = configs;
}, "~N");
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
return this.mChangingConfigurations;
});
Clazz.defineMethod (c$, "getOpacity", 
function () {
return 0;
});
Clazz.defineMethod (c$, "setDither", 
function (dither) {
}, "~B");
Clazz.defineMethod (c$, "setFilterBitmap", 
function (filter) {
}, "~B");
Clazz.defineMethod (c$, "setCallback", 
function (cb) {
this.mCallback = cb;
}, "android.graphics.drawable.Drawable.Callback");
Clazz.defineMethod (c$, "invalidateSelf", 
function () {
if (this.mCallback != null) {
this.mCallback.invalidateDrawable (this);
}});
Clazz.defineMethod (c$, "scheduleSelf", 
function (what, when) {
if (this.mCallback != null) {
this.mCallback.scheduleDrawable (this, what, when);
}}, "Runnable,~N");
Clazz.defineMethod (c$, "unscheduleSelf", 
function (what) {
if (this.mCallback != null) {
this.mCallback.unscheduleDrawable (this, what);
}}, "Runnable");
Clazz.defineMethod (c$, "setAlpha", 
function (alpha) {
}, "~N");
Clazz.defineMethod (c$, "isStateful", 
function () {
return false;
});
Clazz.defineMethod (c$, "setState", 
function (stateSet) {
if (!java.util.Arrays.equals (this.mStateSet, stateSet)) {
this.mStateSet = stateSet;
return this.onStateChange (stateSet);
}return false;
}, "~A");
Clazz.defineMethod (c$, "getState", 
function () {
return this.mStateSet;
});
Clazz.defineMethod (c$, "getCurrent", 
function () {
return this;
});
Clazz.defineMethod (c$, "setLevel", 
function (level) {
if (this.mLevel != level) {
this.mLevel = level;
return this.onLevelChange (level);
}return false;
}, "~N");
Clazz.defineMethod (c$, "getLevel", 
function () {
return this.mLevel;
});
Clazz.defineMethod (c$, "setVisible", 
function (visible, restart) {
var changed = this.mVisible != visible;
this.mVisible = visible;
return changed;
}, "~B,~B");
Clazz.defineMethod (c$, "isVisible", 
function () {
return this.mVisible;
});
Clazz.defineMethod (c$, "onStateChange", 
function (state) {
return false;
}, "~A");
Clazz.defineMethod (c$, "onLevelChange", 
function (level) {
return false;
}, "~N");
Clazz.defineMethod (c$, "onBoundsChange", 
function (bounds) {
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "getIntrinsicWidth", 
function () {
return -1;
});
Clazz.defineMethod (c$, "getIntrinsicHeight", 
function () {
return -1;
});
Clazz.defineMethod (c$, "getMinimumWidth", 
function () {
var intrinsicWidth = this.getIntrinsicWidth ();
return intrinsicWidth > 0 ? intrinsicWidth : 0;
});
c$.resolveOpacity = Clazz.defineMethod (c$, "resolveOpacity", 
function (op1, op2) {
if (op1 == op2) {
return op1;
}if (op1 == 0 || op2 == 0) {
return 0;
}if (op1 == -3 || op2 == -3) {
return -3;
}if (op1 == -2 || op2 == -2) {
return -2;
}return -1;
}, "~N,~N");
Clazz.defineMethod (c$, "getMinimumHeight", 
function () {
var intrinsicHeight = this.getIntrinsicHeight ();
return intrinsicHeight > 0 ? intrinsicHeight : 0;
});
Clazz.defineMethod (c$, "getPadding", 
function (padding) {
padding.set (0, 0, 0, 0);
return false;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "mutate", 
function () {
return this;
});
c$.createFromStream = Clazz.defineMethod (c$, "createFromStream", 
function (is, srcName) {
return android.graphics.drawable.Drawable.createFromResourceStream (null, null, is, srcName, null);
}, "java.io.InputStream,~S");
c$.createFromResourceStream = Clazz.defineMethod (c$, "createFromResourceStream", 
function (res, value, is, srcName) {
return android.graphics.drawable.Drawable.createFromResourceStream (res, value, is, srcName, null);
}, "android.content.res.Resources,android.util.TypedValue,java.io.InputStream,~S");
c$.createFromResourceStream = Clazz.defineMethod (c$, "createFromResourceStream", 
function (res, value, is, srcName, opts) {
if (is == null) {
return null;
}var pad =  new android.graphics.Rect ();
if (opts == null) opts =  new android.graphics.BitmapFactory.Options ();
opts.inScreenDensity = android.util.DisplayMetrics.DENSITY_DEVICE;
var bm = android.graphics.BitmapFactory.decodeResourceStream (res, value, is, pad, opts);
if (bm != null) {
var np = bm.getNinePatch ();
if (np == null) {
np = null;
pad = null;
}bm.fileName = srcName;
return android.graphics.drawable.Drawable.drawableFromBitmap (res, bm, np, pad, srcName);
}return null;
}, "android.content.res.Resources,android.util.TypedValue,java.io.InputStream,~S,android.graphics.BitmapFactory.Options");
c$.createFromResource = Clazz.defineMethod (c$, "createFromResource", 
function (res, value, srcName, id, opts) {
var pad =  new android.graphics.Rect ();
var afd = res.openRawResourceFd (id);
var bm = android.graphics.BitmapFactory.decodeResourceFd (afd, id);
if (bm != null) {
var np = bm.getNinePatch ();
if (np == null) {
np = null;
pad = null;
}bm.fileName = srcName;
return android.graphics.drawable.Drawable.drawableFromBitmap (res, bm, np, pad, srcName);
}return null;
}, "android.content.res.Resources,android.util.TypedValue,~S,~N,android.graphics.BitmapFactory.Options");
c$.drawableFromBitmap = Clazz.defineMethod (c$, "drawableFromBitmap", 
($fz = function (res, bm, np, pad, srcName) {
if (np != null) {
return  new android.graphics.drawable.NinePatchDrawable (res, bm, np, pad, srcName);
}var drawable = null;
try {
drawable = Class.forName ("android.graphics.drawable.BitmapDrawable").newInstance ();
(drawable).setBitmap (bm);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.e ("Drawable", "drawable exception");
} else {
throw e;
}
}
return drawable;
}, $fz.isPrivate = true, $fz), "android.content.res.Resources,android.graphics.Bitmap,android.graphics.BitmapFactory.Res_png_9patch,android.graphics.Rect,~S");
c$.createFromPath = Clazz.defineMethod (c$, "createFromPath", 
function (pathName) {
if (pathName == null) {
return null;
}return null;
}, "~S");
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.Drawable);
this.inflateWithAttributes (r, parser, a, 0);
a.recycle ();
}, "android.content.res.Resources,android.content.res.XmlResourceParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "inflateWithAttributes", 
function (r, parser, attrs, visibleAttr) {
this.mVisible = attrs.getBoolean (visibleAttr, this.mVisible);
}, "android.content.res.Resources,android.content.res.XmlResourceParser,android.content.res.TypedArray,~N");
Clazz.defineMethod (c$, "getConstantState", 
function () {
return null;
});
c$.createFromXml = Clazz.defineMethod (c$, "createFromXml", 
function (r, parser) {
var attrs = parser;
var type;
while ((type = parser.next ()) != 2 && type != 1) {
}
if (type != 2) {
throw  new org.xmlpull.v1.XmlPullParserException ("No start tag found");
}var drawable = android.graphics.drawable.Drawable.createFromXmlInner (r, parser, attrs);
if (drawable == null) {
throw  new RuntimeException ("Unknown initial tag: " + parser.getName ());
}return drawable;
}, "android.content.res.Resources,android.content.res.XmlResourceParser");
c$.createFromXmlInner = Clazz.defineMethod (c$, "createFromXmlInner", 
function (r, parser, attrs) {
var drawable = null;
var name = parser.getName ();
try {
if (name.equals ("color")) {
drawable = Class.forName ("android.graphics.drawable.ColorDrawable").newInstance ();
} else if (name.equals ("layer-list")) {
drawable = Class.forName ("android.graphics.drawable.LayerDrawable").newInstance ();
} else if (name.equals ("shape")) {
drawable = Class.forName ("android.graphics.drawable.GradientDrawable").newInstance ();
} else if (name.equals ("selector")) {
drawable = Class.forName ("android.graphics.drawable.StateListDrawable").newInstance ();
} else if (name.equals ("clip")) {
drawable = Class.forName ("android.graphics.drawable.ClipDrawable").newInstance ();
} else if (name.equals ("animated-rotate")) {
drawable = Class.forName ("android.graphics.drawable.AnimatedRotateDrawable").newInstance ();
} else if (name.equals ("animation-list")) {
drawable = Class.forName ("android.graphics.drawable.AnimationDrawable").newInstance ();
} else if (name.equals ("bitmap")) {
drawable =  new android.graphics.drawable.BitmapDrawable ();
if (r != null) {
(drawable).setTargetDensity (r.getDisplayMetrics ());
}} else if (name.equals ("nine-patch")) {
drawable =  new android.graphics.drawable.NinePatchDrawable ();
if (r != null) {
(drawable).setTargetDensity (r.getDisplayMetrics ());
}} else {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": invalid drawable tag " + name);
}} catch (e$$) {
if (Clazz.instanceOf (e$$, InstantiationException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, IllegalAccessException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, ClassNotFoundException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else {
throw e$$;
}
}
drawable.inflate (r, parser, attrs);
return drawable;
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "inflate", 
function (r, parser, attrs) {
var a = r.obtainAttributes (attrs, com.android.internal.R.styleable.Drawable);
this.inflateWithAttributes (r, parser, a, 0);
a.recycle ();
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "inflateWithAttributes", 
function (r, parser, attrs, visibleAttr) {
this.mVisible = attrs.getBoolean (visibleAttr, this.mVisible);
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.content.res.TypedArray,~N");
Clazz.defineMethod (c$, "getTransparentRegion", 
function () {
android.util.Log.e ("Drawable", "Not implemented yet!");
return null;
});
Clazz.defineMethod (c$, "setColorFilter", 
function (color, mode) {
console.log("Missing method: setColorFilter");
}, "~N,android.graphics.PorterDuff.Mode");
Clazz.defineMethod (c$, "clearColorFilter", 
function () {
console.log("Missing method: clearColorFilter");
});
Clazz.declareInterface (android.graphics.drawable.Drawable, "Callback");
Clazz.pu$h ();
c$ = Clazz.declareType (android.graphics.drawable.Drawable, "ConstantState");
Clazz.defineMethod (c$, "newDrawable", 
function (a) {
return this.newDrawable ();
}, "android.content.res.Resources");
c$ = Clazz.p0p ();
c$.ZERO_BOUNDS_RECT = c$.prototype.ZERO_BOUNDS_RECT =  new android.graphics.Rect ();
});
