﻿Clazz.declarePackage ("android.graphics");
Clazz.load (null, "android.graphics.Path", ["android.graphics.Matrix", "$.Paint", "$.PointF", "$.RectF", "android.util.Log", "java.lang.ArrayIndexOutOfBoundsException", "$.Float", "$.NullPointerException", "$.RuntimeException", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
if (!Clazz.isClassDefined ("android.graphics.Path.SkPath")) {
android.graphics.Path.$Path$SkPath$ ();
}
this.mNativePath = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "Path");
Clazz.makeConstructor (c$, 
function () {
this.mNativePath = this.init1 ();
});
Clazz.makeConstructor (c$, 
function (src) {
var valNative = null;
if (src != null) {
valNative = src.mNativePath;
}this.mNativePath = this.init2 (valNative);
}, "android.graphics.Path");
Clazz.defineMethod (c$, "reset", 
function () {
android.graphics.Path.native_reset (this.mNativePath);
});
Clazz.defineMethod (c$, "rewind", 
function () {
android.graphics.Path.native_rewind (this.mNativePath);
});
Clazz.defineMethod (c$, "set", 
function (src) {
if (this !== src) {
android.graphics.Path.native_set (this.mNativePath, src.mNativePath);
}}, "android.graphics.Path");
Clazz.defineMethod (c$, "getFillType", 
function () {
return android.graphics.Path.sFillTypeArray[android.graphics.Path.native_getFillType (this.mNativePath)];
});
Clazz.defineMethod (c$, "setFillType", 
function (ft) {
android.graphics.Path.native_setFillType (this.mNativePath, ft.nativeInt);
}, "android.graphics.Path.FillType");
Clazz.defineMethod (c$, "isInverseFillType", 
function () {
var ft = android.graphics.Path.native_getFillType (this.mNativePath);
return (ft & 2) != 0;
});
Clazz.defineMethod (c$, "toggleInverseFillType", 
function () {
var ft = android.graphics.Path.native_getFillType (this.mNativePath);
ft ^= 2;
android.graphics.Path.native_setFillType (this.mNativePath, ft);
});
Clazz.defineMethod (c$, "isEmpty", 
function () {
return android.graphics.Path.native_isEmpty (this.mNativePath);
});
Clazz.defineMethod (c$, "isRect", 
function (rect) {
return android.graphics.Path.native_isRect (this.mNativePath, rect);
}, "android.graphics.RectF");
Clazz.defineMethod (c$, "computeBounds", 
function (bounds, exact) {
android.graphics.Path.native_computeBounds (this.mNativePath, bounds);
}, "android.graphics.RectF,~B");
Clazz.defineMethod (c$, "incReserve", 
function (extraPtCount) {
}, "~N");
Clazz.defineMethod (c$, "moveTo", 
function (x, y) {
android.graphics.Path.native_moveTo (this.mNativePath, x, y);
}, "~N,~N");
Clazz.defineMethod (c$, "rMoveTo", 
function (dx, dy) {
android.graphics.Path.native_rMoveTo (this.mNativePath, dx, dy);
}, "~N,~N");
Clazz.defineMethod (c$, "lineTo", 
function (x, y) {
android.graphics.Path.native_lineTo (this.mNativePath, x, y);
}, "~N,~N");
Clazz.defineMethod (c$, "rLineTo", 
function (dx, dy) {
android.graphics.Path.native_rLineTo (this.mNativePath, dx, dy);
}, "~N,~N");
Clazz.defineMethod (c$, "quadTo", 
function (x1, y1, x2, y2) {
android.graphics.Path.native_quadTo (this.mNativePath, x1, y1, x2, y2);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "rQuadTo", 
function (dx1, dy1, dx2, dy2) {
android.graphics.Path.native_rQuadTo (this.mNativePath, dx1, dy1, dx2, dy2);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "cubicTo", 
function (x1, y1, x2, y2, x3, y3) {
android.graphics.Path.native_cubicTo (this.mNativePath, x1, y1, x2, y2, x3, y3);
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "rCubicTo", 
function (x1, y1, x2, y2, x3, y3) {
android.graphics.Path.native_rCubicTo (this.mNativePath, x1, y1, x2, y2, x3, y3);
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "arcTo", 
function (oval, startAngle, sweepAngle, forceMoveTo) {
android.graphics.Path.native_arcTo (this.mNativePath, oval, startAngle, sweepAngle, forceMoveTo);
}, "android.graphics.RectF,~N,~N,~B");
Clazz.defineMethod (c$, "arcTo", 
function (oval, startAngle, sweepAngle) {
android.graphics.Path.native_arcTo (this.mNativePath, oval, startAngle, sweepAngle, false);
}, "android.graphics.RectF,~N,~N");
Clazz.defineMethod (c$, "close", 
function () {
android.graphics.Path.native_close (this.mNativePath);
});
Clazz.defineMethod (c$, "addRect", 
function (rect, dir) {
if (rect == null) {
throw  new NullPointerException ("need rect parameter");
}android.graphics.Path.native_addRect (this.mNativePath, rect, dir.nativeInt);
}, "android.graphics.RectF,android.graphics.Path.Direction");
Clazz.defineMethod (c$, "addRect", 
function (left, top, right, bottom, dir) {
android.graphics.Path.native_addRect (this.mNativePath, left, top, right, bottom, dir.nativeInt);
}, "~N,~N,~N,~N,android.graphics.Path.Direction");
Clazz.defineMethod (c$, "addOval", 
function (oval, dir) {
if (oval == null) {
throw  new NullPointerException ("need oval parameter");
}android.graphics.Path.native_addOval (this.mNativePath, oval, dir.nativeInt);
}, "android.graphics.RectF,android.graphics.Path.Direction");
Clazz.defineMethod (c$, "addCircle", 
function (x, y, radius, dir) {
android.graphics.Path.native_addCircle (this.mNativePath, x, y, radius, dir.nativeInt);
}, "~N,~N,~N,android.graphics.Path.Direction");
Clazz.defineMethod (c$, "addArc", 
function (oval, startAngle, sweepAngle) {
if (oval == null) {
throw  new NullPointerException ("need oval parameter");
}android.graphics.Path.native_addArc (this.mNativePath, oval, startAngle, sweepAngle);
}, "android.graphics.RectF,~N,~N");
Clazz.defineMethod (c$, "addRoundRect", 
function (rect, rx, ry, dir) {
if (rect == null) {
throw  new NullPointerException ("need rect parameter");
}android.graphics.Path.native_addRoundRect (this.mNativePath, rect, rx, ry, dir.nativeInt);
}, "android.graphics.RectF,~N,~N,android.graphics.Path.Direction");
Clazz.defineMethod (c$, "addRoundRect", 
function (rect, radii, dir) {
if (rect == null) {
throw  new NullPointerException ("need rect parameter");
}if (radii.length < 8) {
throw  new ArrayIndexOutOfBoundsException ("radii[] needs 8 values");
}android.graphics.Path.native_addRoundRect (this.mNativePath, rect, radii, dir.nativeInt);
}, "android.graphics.RectF,~A,android.graphics.Path.Direction");
Clazz.defineMethod (c$, "addPath", 
function (src, dx, dy) {
android.graphics.Path.native_addPath (this.mNativePath, src.mNativePath, dx, dy);
}, "android.graphics.Path,~N,~N");
Clazz.defineMethod (c$, "addPath", 
function (src) {
android.graphics.Path.native_addPath (this.mNativePath, src.mNativePath);
}, "android.graphics.Path");
Clazz.defineMethod (c$, "addPath", 
function (src, matrix) {
android.graphics.Path.native_addPath (this.mNativePath, src.mNativePath, matrix);
}, "android.graphics.Path,android.graphics.Matrix");
Clazz.defineMethod (c$, "offset", 
function (dx, dy, dst) {
var dstNative = null;
if (dst != null) {
dstNative = dst.mNativePath;
}android.graphics.Path.native_offset (this.mNativePath, dx, dy, dstNative);
}, "~N,~N,android.graphics.Path");
Clazz.defineMethod (c$, "offset", 
function (dx, dy) {
android.graphics.Path.native_offset (this.mNativePath, dx, dy);
}, "~N,~N");
Clazz.defineMethod (c$, "setLastPoint", 
function (dx, dy) {
android.graphics.Path.native_setLastPoint (this.mNativePath, dx, dy);
}, "~N,~N");
Clazz.defineMethod (c$, "transform", 
function (matrix, dst) {
var dstNative = null;
if (dst != null) {
dstNative = dst.mNativePath;
}android.graphics.Path.native_transform (this.mNativePath, matrix, dstNative);
}, "android.graphics.Matrix,android.graphics.Path");
Clazz.defineMethod (c$, "transform", 
function (matrix) {
android.graphics.Path.native_transform (this.mNativePath, matrix);
}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "drawOnCanvas", 
function (activeCanvas, bitmap, paint) {
android.graphics.Path.native_drawOnCanvas (this.mNativePath, activeCanvas, bitmap, paint);
}, "~S,android.graphics.Bitmap,android.graphics.Paint");
Clazz.defineMethod (c$, "finalize", 
function () {
try {
} finally {
Clazz.superCall (this, android.graphics.Path, "finalize", []);
}
});
Clazz.defineMethod (c$, "ni", 
function () {
return 0;
});
Clazz.defineMethod (c$, "init1", 
($fz = function () {
return Clazz.innerTypeInstance (android.graphics.Path.SkPath, this, null);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "init2", 
($fz = function (src) {
return Clazz.innerTypeInstance (android.graphics.Path.SkPath, this, null, src);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath");
c$.native_reset = Clazz.defineMethod (c$, "native_reset", 
($fz = function (path) {
path.reset ();
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath");
c$.native_rewind = Clazz.defineMethod (c$, "native_rewind", 
($fz = function (path) {
path.rewind ();
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath");
c$.native_set = Clazz.defineMethod (c$, "native_set", 
($fz = function (path, src) {
path.set (src);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.Path.SkPath");
c$.native_getFillType = Clazz.defineMethod (c$, "native_getFillType", 
($fz = function (path) {
return path.getFillType ();
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath");
c$.native_setFillType = Clazz.defineMethod (c$, "native_setFillType", 
($fz = function (path, ft) {
path.setFillType (ft);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N");
c$.native_isEmpty = Clazz.defineMethod (c$, "native_isEmpty", 
($fz = function (path) {
return path.isEmpty ();
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath");
c$.native_isRect = Clazz.defineMethod (c$, "native_isRect", 
($fz = function (path, rect) {
return path.isRect (rect);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.RectF");
c$.native_computeBounds = Clazz.defineMethod (c$, "native_computeBounds", 
($fz = function (path, bounds) {
path.computeBounds (bounds);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.RectF");
c$.native_moveTo = Clazz.defineMethod (c$, "native_moveTo", 
($fz = function (path, x, y) {
path.moveTo (x, y);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N");
c$.native_rMoveTo = Clazz.defineMethod (c$, "native_rMoveTo", 
($fz = function (path, dx, dy) {
path.rMoveTo (dx, dy);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N");
c$.native_lineTo = Clazz.defineMethod (c$, "native_lineTo", 
($fz = function (path, x, y) {
path.lineTo (x, y);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N");
c$.native_rLineTo = Clazz.defineMethod (c$, "native_rLineTo", 
($fz = function (path, dx, dy) {
path.rLineTo (dx, dy);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N");
c$.native_quadTo = Clazz.defineMethod (c$, "native_quadTo", 
($fz = function (path, x1, y1, x2, y2) {
path.quadTo (x1, y1, x2, y2);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N,~N,~N");
c$.native_rQuadTo = Clazz.defineMethod (c$, "native_rQuadTo", 
($fz = function (path, dx1, dy1, dx2, dy2) {
path.rQuadTo (dx1, dy1, dx2, dy2);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N,~N,~N");
c$.native_cubicTo = Clazz.defineMethod (c$, "native_cubicTo", 
($fz = function (path, x1, y1, x2, y2, x3, y3) {
path.cubicTo (x1, y1, x2, y2, x3, y3);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N,~N,~N,~N,~N");
c$.native_rCubicTo = Clazz.defineMethod (c$, "native_rCubicTo", 
($fz = function (path, x1, y1, x2, y2, x3, y3) {
path.rCubicTo (x1, y1, x2, y2, x3, y3);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N,~N,~N,~N,~N");
c$.native_arcTo = Clazz.defineMethod (c$, "native_arcTo", 
($fz = function (path, oval, startAngle, sweepAngle, forceMoveTo) {
path.arcTo (oval, startAngle, sweepAngle, forceMoveTo);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.RectF,~N,~N,~B");
c$.native_close = Clazz.defineMethod (c$, "native_close", 
($fz = function (path) {
path.close ();
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath");
c$.native_addRect = Clazz.defineMethod (c$, "native_addRect", 
($fz = function (path, rect, dir) {
path.addRect (rect.left, rect.top, rect.right, rect.bottom, dir);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.RectF,~N");
c$.native_addRect = Clazz.defineMethod (c$, "native_addRect", 
($fz = function (path, left, top, right, bottom, dir) {
path.addRect (left, top, right, bottom, dir);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N,~N,~N,~N");
c$.native_addOval = Clazz.defineMethod (c$, "native_addOval", 
($fz = function (path, oval, dir) {
path.addOval (oval, dir);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.RectF,~N");
c$.native_addCircle = Clazz.defineMethod (c$, "native_addCircle", 
($fz = function (path, x, y, radius, dir) {
path.addCircle (x, y, radius, dir);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N,~N,~N");
c$.native_addArc = Clazz.defineMethod (c$, "native_addArc", 
($fz = function (path, oval, startAngle, sweepAngle) {
path.addArc (oval, startAngle, sweepAngle);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.RectF,~N,~N");
c$.native_addRoundRect = Clazz.defineMethod (c$, "native_addRoundRect", 
($fz = function (path, rect, rx, ry, dir) {
path.addRoundRect (rect, rx, ry, dir);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.RectF,~N,~N,~N");
c$.native_addRoundRect = Clazz.defineMethod (c$, "native_addRoundRect", 
($fz = function (path, r, radii, dir) {
path.addRoundRect (r, radii, dir);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.RectF,~A,~N");
c$.native_addPath = Clazz.defineMethod (c$, "native_addPath", 
($fz = function (path, src, dx, dy) {
path.addPath (src, dx, dy);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.Path.SkPath,~N,~N");
c$.native_addPath = Clazz.defineMethod (c$, "native_addPath", 
($fz = function (path, src) {
path.addPath (src);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.Path.SkPath");
c$.native_addPath = Clazz.defineMethod (c$, "native_addPath", 
($fz = function (path, src, matrix) {
path.addPath (src, matrix);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.Path.SkPath,android.graphics.Matrix");
c$.native_offset = Clazz.defineMethod (c$, "native_offset", 
($fz = function (path, dx, dy, dst_path) {
var matrix =  new android.graphics.Matrix ();
matrix.setTranslate (dx, dy);
path.transform (matrix, dst_path);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N,android.graphics.Path.SkPath");
c$.native_offset = Clazz.defineMethod (c$, "native_offset", 
($fz = function (path, dx, dy) {
android.graphics.Path.native_offset (path, dx, dy, path);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N");
c$.native_setLastPoint = Clazz.defineMethod (c$, "native_setLastPoint", 
($fz = function (path, dx, dy) {
path.setLastPt (dx, dy);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~N,~N");
c$.native_transform = Clazz.defineMethod (c$, "native_transform", 
($fz = function (path, matrix, dst_path) {
path.transform (matrix, dst_path);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.Matrix,android.graphics.Path.SkPath");
c$.native_transform = Clazz.defineMethod (c$, "native_transform", 
($fz = function (path, matrix) {
path.transform (matrix, path);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.Matrix");
c$.native_drawOnCanvas = Clazz.defineMethod (c$, "native_drawOnCanvas", 
($fz = function (path, canvas, bitmap, paint) {
path.drawOnCanvas (canvas, bitmap, paint);
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~S,android.graphics.Bitmap,android.graphics.Paint");
c$.$Path$SkPath$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.fPts = null;
this.fVerbs = null;
this.fBoundsIsDirty = false;
this.fBounds = null;
this.fFillType = 0;
this.mCanvasId = null;
this.mBitmap = null;
this.mPts = null;
if (!Clazz.isClassDefined ("android.graphics.Path.SkPath.Bezier")) {
android.graphics.Path.SkPath.$Path$SkPath$Bezier$ ();
}
if (!Clazz.isClassDefined ("android.graphics.Path.SkPath.PathIter")) {
android.graphics.Path.SkPath.$Path$SkPath$PathIter$ ();
}
Clazz.instantialize (this, arguments);
}, android.graphics.Path, "SkPath");
Clazz.makeConstructor (c$, 
function () {
this.fPts =  new java.util.ArrayList ();
this.fVerbs =  new java.util.ArrayList ();
this.fBoundsIsDirty = true;
this.fFillType = 0;
});
Clazz.makeConstructor (c$, 
function (a) {
}, "android.graphics.Path.SkPath");
Clazz.defineMethod (c$, "reset", 
function () {
this.fPts.clear ();
this.fVerbs.clear ();
this.fBoundsIsDirty = true;
});
Clazz.defineMethod (c$, "rewind", 
function () {
this.fPts.clear ();
this.fVerbs.clear ();
this.fBoundsIsDirty = true;
});
Clazz.defineMethod (c$, "set", 
function (a) {
if (a !== this) {
this.fPts = a.fPts;
this.fVerbs = a.fVerbs;
this.fFillType = a.fFillType;
this.fBoundsIsDirty = a.fBoundsIsDirty;
}}, "android.graphics.Path.SkPath");
Clazz.defineMethod (c$, "isEmpty", 
function () {
var a = this.fVerbs.size ();
return a == 0 || (a == 1 && (this.fVerbs.get (0)).intValue () === 0);
});
Clazz.defineMethod (c$, "isRect", 
function (a) {
android.util.Log.e ("Path", "unimplemented");
return false;
}, "android.graphics.RectF");
Clazz.defineMethod (c$, "getLastPt", 
function () {
var a = this.fPts.size ();
if (a == 0) {
return  new android.graphics.PointF (0, 0);
} else {
return this.fPts.get (a - 1);
}});
Clazz.defineMethod (c$, "computeBounds", 
function (a) {
}, "android.graphics.RectF");
Clazz.defineMethod (c$, "setLastPt", 
function (a, b) {
var c = this.fPts.size ();
if (c == 0) {
this.moveTo (a, b);
} else {
this.fPts.set (c - 1,  new android.graphics.PointF (a, b));
}}, "~N,~N");
Clazz.defineMethod (c$, "getFillType", 
function () {
return this.fFillType;
});
Clazz.defineMethod (c$, "setFillType", 
function (a) {
if (a != 0) {
throw  new RuntimeException ("Only Winding FillType is supported in Path");
}this.fFillType = a;
}, "~N");
Clazz.defineMethod (c$, "moveTo", 
function (a, b) {
var c = this.fVerbs.size ();
var d =  new android.graphics.PointF (a, b);
if (c > 0 && (this.fVerbs.get (c - 1)).intValue () === 0) {
this.fPts.set (this.fPts.size () - 1, d);
} else {
this.fPts.add (d);
this.fVerbs.add (new Integer (0));
}this.fBoundsIsDirty = true;
}, "~N,~N");
Clazz.defineMethod (c$, "rMoveTo", 
function (a, b) {
var c = this.getLastPt ();
this.moveTo (c.x + a, c.y + b);
}, "~N,~N");
Clazz.defineMethod (c$, "lineTo", 
function (a, b) {
if (this.fVerbs.size () == 0) {
this.fPts.add ( new android.graphics.PointF (0, 0));
this.fVerbs.add (new Integer (0));
}this.fPts.add ( new android.graphics.PointF (a, b));
this.fVerbs.add (new Integer (1));
this.fBoundsIsDirty = true;
}, "~N,~N");
Clazz.defineMethod (c$, "rLineTo", 
function (a, b) {
var c = this.getLastPt ();
this.lineTo (c.x + a, c.y + b);
}, "~N,~N");
Clazz.defineMethod (c$, "quadTo", 
function (a, b, c, d) {
if (this.fVerbs.size () == 0) {
this.fPts.add ( new android.graphics.PointF (0, 0));
this.fVerbs.add (new Integer (0));
}this.fPts.add ( new android.graphics.PointF (a, b));
this.fPts.add ( new android.graphics.PointF (c, d));
this.fVerbs.add (new Integer (2));
this.fBoundsIsDirty = true;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "rQuadTo", 
function (a, b, c, d) {
var e = this.getLastPt ();
this.quadTo (e.x + a, e.y + b, e.x + c, e.y + d);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "cubicTo", 
function (a, b, c, d, e, f) {
if (this.fVerbs.size () == 0) {
this.fPts.add ( new android.graphics.PointF (0, 0));
this.fVerbs.add (new Integer (0));
}this.fPts.add ( new android.graphics.PointF (a, b));
this.fPts.add ( new android.graphics.PointF (c, d));
this.fPts.add ( new android.graphics.PointF (e, f));
this.fVerbs.add (new Integer (3));
this.fBoundsIsDirty = true;
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "rCubicTo", 
function (a, b, c, d, e, f) {
var g = this.getLastPt ();
this.cubicTo (g.x + a, g.y + b, g.x + c, g.y + d, g.x + e, g.y + f);
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "arcTo", 
function (a, b, c, d) {
if (a.width () < 0 || a.height () < 0) {
return ;
}if (this.fVerbs.size () == 0) {
d = true;
}var e = this.build_cubics_points (a, b, c);
if (d) {
this.moveTo (e.get (0).x, e.get (0).y);
} else {
this.lineTo (e.get (0).x, e.get (0).y);
}for (var f = 1; (f + 3) <= e.size (); f += 3) {
this.cubicTo (e.get (f).x, e.get (f).y, e.get (f + 1).x, e.get (f + 1).y, e.get (f + 2).x, e.get (f + 2).y);
}
}, "android.graphics.RectF,~N,~N,~B");
Clazz.defineMethod (c$, "build_cubics_points", 
($fz = function (a, b, c) {
var d =  new java.util.ArrayList ();
var e = a.left;
var f = a.top;
var g = a.width ();
var h = a.width () / 2;
var i = h * 0.5522848;
var j = a.height ();
var k = a.height () / 2;
var l = k * 0.5522848;
var m = [ new android.graphics.PointF (e + g, f + k),  new android.graphics.PointF (e + g, f + k + l),  new android.graphics.PointF (e + h + i, f + j),  new android.graphics.PointF (e + h, f + j),  new android.graphics.PointF (e + h - i, f + j),  new android.graphics.PointF (e, f + k + l),  new android.graphics.PointF (e, f + k),  new android.graphics.PointF (e, f + k - l),  new android.graphics.PointF (e + h - i, f),  new android.graphics.PointF (e + h, f),  new android.graphics.PointF (e + h + i, f),  new android.graphics.PointF (e + g, f + k - l),  new android.graphics.PointF (e + g, f + k)];
if (c > 360.0) {
c = 360.0;
} else if (c < -360.0) {
c = -360.0;
}if (b == 0.0) {
if (c == 360.0) {
d.add (m[12]);
for (var n = 11; n >= 0; --n) d.add (m[n]);

return d;
} else if (c == -360.0) {
d.add (m[0]);
for (var n = 1; n <= 12; ++n) d.add (m[n]);

return d;
}}var n = Math.round (Math.floor (b / 90));
var o = Math.round (Math.floor ((b + c) / 90));
var p = (b - n * 90) / 90;
var q = (b + c - o * 90) / 90;
var r = c > 0 ? 1 : -1;
if (r < 0) {
p = 1 - p;
q = 1 - q;
}if (this.fuzzyIsNull (p - 1.0)) {
p = 0;
n += r;
}if (this.fuzzyIsNull (q)) {
q = 1;
o -= r;
}p = this.for_arc_angle (p * 90);
q = this.for_arc_angle (q * 90);
var s = !this.fuzzyIsNull (p);
var t = !this.fuzzyIsNull (q - 1.0);
var u = o + r;
if (n == u) {
var v = 3 - ((n % 4) + 4) % 4;
var w = 3 * v;
if (r > 0) {
d.add (m[w + 3]);
} else {
d.add (m[w]);
}return d;
}var v =  new android.graphics.PointF ();
var w =  new android.graphics.PointF ();
this.find_ellipse_coords (a, b, c, v, w);
d.add (v);
for (var x = n; x != u; x += r) {
var y = 3 - ((x % 4) + 4) % 4;
var z = 3 * y;
var A = Clazz.innerTypeInstance (android.graphics.Path.SkPath.Bezier, this, null);
if (r > 0) A.fromPoints (m[z + 3], m[z + 2], m[z + 1], m[z]);
 else A.fromPoints (m[z], m[z + 1], m[z + 2], m[z + 3]);
if (n == o && this.fuzzyCompare (p, q)) {
return d;
}if (x == n) {
if (x == o && t) A = A.bezierOnInterval (p, q);
 else if (s) A = A.bezierOnInterval (p, 1);
} else if (x == o && t) {
A = A.bezierOnInterval (0, q);
}d.add ( new android.graphics.PointF (A.x2, A.y2));
d.add ( new android.graphics.PointF (A.x3, A.y3));
d.add ( new android.graphics.PointF (A.x4, A.y4));
}
d.set (d.size () - 1, w);
return d;
}, $fz.isPrivate = true, $fz), "android.graphics.RectF,~N,~N");
Clazz.defineMethod (c$, "fuzzyIsNull", 
($fz = function (a) {
return Math.abs (a) < 0.00001;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "fuzzyCompare", 
($fz = function (a, b) {
return Math.abs (a - b) < 0.00001 * Math.min (Math.abs (a), Math.abs (b));
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "for_arc_angle", 
($fz = function (a) {
if (this.fuzzyIsNull (a)) return 0;
if (this.fuzzyCompare (a, 90.0)) return 1;
var b = (3.141592653589793 * a / 180);
var c = Math.cos (b);
var d = Math.sin (b);
var e = a / 90;
e -= ((((0.3431456) * e + -1.3431456) * e) * e + 1 - c) / (((1.0294371) * e + -2.6862912) * e);
e -= ((((0.3431456) * e + -1.3431456) * e) * e + 1 - c) / (((1.0294371) * e + -2.6862912) * e);
var f = e;
f -= ((((-0.3431456) * f - 3.3137088 + 3) * f + 1.6568544) * f - d) / (((-1.0294371) * f + 6.6274176 - 6) * f + 1.6568544);
f -= ((((-0.3431456) * f - 3.3137088 + 3) * f + 1.6568544) * f - d) / (((-1.0294371) * f + 6.6274176 - 6) * f + 1.6568544);
var g = 0.5 * (e + f);
return g;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "find_ellipse_coords", 
($fz = function (a, b, c, d, e) {
if (a.isEmpty ()) {
return ;
}var f = a.width () / 2;
var g = a.height () / 2;
var h = [b, b + c];
for (var i = 0; i < 2; ++i) {
var j = (h[i] - 360 * Math.floor (h[i] / 360));
var k = j / 90;
var l = Math.round ((k >= 0 ? Math.floor (k) : Math.ceil (k)));
k -= l;
k = this.for_arc_angle (90 * k);
if ((l & 1) != 0) k = 1 - k;
var m =  Clazz.newArray (4, 0);
this.BezierCoefficient (k, m);
var n =  new android.graphics.PointF (m[0] + m[1] + m[2] * 0.5522848, m[3] + m[2] + m[1] * 0.5522848);
if (l == 1 || l == 2) n.x = -n.x;
if (l == 0 || l == 1) n.y = -n.y;
if (i == 0) {
d.x = a.centerX () + f * n.x;
d.y = a.centerY () + g * n.y;
} else {
e.x = a.centerX () + f * n.x;
e.y = a.centerY () + g * n.y;
}}
}, $fz.isPrivate = true, $fz), "android.graphics.RectF,~N,~N,android.graphics.PointF,android.graphics.PointF");
Clazz.defineMethod (c$, "BezierCoefficient", 
($fz = function (a, b) {
var c = 1.0 - a;
b[1] = c * c;
b[2] = a * a;
b[3] = b[2] * a;
b[0] = b[1] * c;
b[1] *= 3.0 * a;
b[2] *= 3.0 * c;
}, $fz.isPrivate = true, $fz), "~N,~A");
Clazz.defineMethod (c$, "close", 
function () {
var a = this.fVerbs.size ();
if (a > 0) {
switch (this.fVerbs.get (a - 1).intValue ()) {
case 1:
case 2:
case 3:
this.fVerbs.add (new Integer (4));
break;
default:
break;
}
}});
Clazz.defineMethod (c$, "addRect", 
function (a, b, c, d, e) {
this.moveTo (a, b);
if (e == 1) {
this.lineTo (a, d);
this.lineTo (c, d);
this.lineTo (c, b);
} else {
this.lineTo (c, b);
this.lineTo (c, d);
this.lineTo (a, d);
}this.close ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "addOval", 
function (a, b) {
var c = a.centerX ();
var d = a.centerY ();
var e = a.width () / 2;
var f = a.height () / 2;
var g = e * 0.5522848;
var h = f * 0.5522848;
this.moveTo (c + e, d);
if (b == 1) {
this.cubicTo (c + e, d - h, c + g, d - f, c, d - f);
this.cubicTo (c - g, d - f, c - e, d - h, c - e, d);
this.cubicTo (c - e, d + h, c - g, d + f, c, d + f);
this.cubicTo (c + g, d + f, c + e, d + h, c + e, d);
} else {
this.cubicTo (c + e, d + h, c + g, d + f, c, d + f);
this.cubicTo (c - g, d + f, c - e, d + h, c - e, d);
this.cubicTo (c - e, d - h, c - g, d - f, c, d - f);
this.cubicTo (c + g, d - f, c + e, d - h, c + e, d);
}this.close ();
}, "android.graphics.RectF,~N");
Clazz.defineMethod (c$, "addCircle", 
function (a, b, c, d) {
if (c > 0) {
var e =  new android.graphics.RectF (a - c, b - c, a + c, b + c);
this.addOval (e, d);
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "addArc", 
function (a, b, c) {
if (a.isEmpty () || 0 == c) {
return ;
}if (c >= 360 || c <= -360.0) {
this.addOval (a, c > 0 ? 0 : 1);
}var d = this.build_cubics_points (a, b, c);
this.moveTo (d.get (0).x, d.get (0).y);
for (var e = 1; e < d.size (); e += 3) {
this.cubicTo (d.get (e).x, d.get (e).y, d.get (e + 1).x, d.get (e + 1).y, d.get (e + 2).x, d.get (e + 2).y);
}
this.close ();
}, "android.graphics.RectF,~N,~N");
Clazz.defineMethod (c$, "addRoundRect", 
function (a, b, c, d) {
var e = a.width ();
var f = e / 2;
var g = a.height ();
var h = g / 2;
if (f <= 0 || h <= 0) {
return ;
}var i = b >= f;
var j = c >= h;
if (i && j) {
this.addOval (a, d);
return ;
}if (i) {
b = f;
} else if (j) {
c = h;
}var k = b * 0.5522848;
var l = c * 0.5522848;
this.moveTo (a.right - b, a.top);
if (d == 1) {
if (!i) {
this.lineTo (a.left + b, a.top);
}this.cubicTo (a.left + b - k, a.top, a.left, a.top + c - l, a.left, a.top + c);
if (!j) {
this.lineTo (a.left, a.bottom - c);
}this.cubicTo (a.left, a.bottom - c + l, a.left + b - k, a.bottom, a.left + b, a.bottom);
if (!i) {
this.lineTo (a.right - b, a.bottom);
}this.cubicTo (a.right - b + k, a.bottom, a.right, a.bottom - c + l, a.right, a.bottom - c);
if (!j) {
this.lineTo (a.right, a.top + c);
}this.cubicTo (a.right, a.top + c - l, a.right - b + k, a.top, a.right - b, a.top);
} else {
this.cubicTo (a.right - b + k, a.top, a.right, a.top + c - l, a.right, a.top + c);
if (!j) {
this.lineTo (a.right, a.bottom - c);
}this.cubicTo (a.right, a.bottom - c + l, a.right - b + k, a.bottom, a.right - b, a.bottom);
if (!i) {
this.lineTo (a.left + b, a.bottom);
}this.cubicTo (a.left + b - k, a.bottom, a.left, a.bottom - c + l, a.left, a.bottom - c);
if (!j) {
this.lineTo (a.left, a.top + c);
}this.cubicTo (a.left, a.top + c - l, a.left + b - k, a.top, a.left + b, a.top);
if (!i) {
this.lineTo (a.right - b, a.top);
}}this.close ();
}, "android.graphics.RectF,~N,~N,~N");
Clazz.defineMethod (c$, "addRoundRect", 
function (a, b, c) {
if (a.isEmpty ()) {
return ;
}if (0 == c) {
this.add_corner_arc (a, b[0], b[1], 180, c, true);
this.add_corner_arc (a, b[2], b[3], 270, c, false);
this.add_corner_arc (a, b[4], b[5], 0, c, false);
this.add_corner_arc (a, b[6], b[7], 90, c, false);
} else {
this.add_corner_arc (a, b[0], b[1], 180, c, true);
this.add_corner_arc (a, b[6], b[7], 90, c, false);
this.add_corner_arc (a, b[4], b[5], 0, c, false);
this.add_corner_arc (a, b[2], b[3], 270, c, false);
}this.close ();
}, "android.graphics.RectF,~A,~N");
Clazz.defineMethod (c$, "add_corner_arc", 
($fz = function (a, b, c, d, e, f) {
b = Math.min (a.width () / 2, b);
c = Math.min (a.height () / 2, c);
var g =  new android.graphics.RectF (-b, -c, b, c);
g.set (-b, -c, b, c);
switch (d) {
case 0:
g.offset (a.right - g.right, a.bottom - g.bottom);
break;
case 90:
g.offset (a.left - g.left, a.bottom - g.bottom);
break;
case 180:
g.offset (a.left - g.left, a.top - g.top);
break;
case 270:
g.offset (a.right - g.right, a.top - g.top);
break;
default:
android.util.Log.e ("Path", "unexpected startAngle in add_corner_arc");
}
var h = d;
var i = 90;
if (1 == e) {
h += i;
i = -i;
}this.arcTo (g, h, i, f);
}, $fz.isPrivate = true, $fz), "android.graphics.RectF,~N,~N,~N,~N,~B");
Clazz.defineMethod (c$, "addPath", 
function (a, b, c) {
var d =  new android.graphics.Matrix ();
d.setTranslate (b, c);
this.addPath (a, d);
}, "android.graphics.Path.SkPath,~N,~N");
Clazz.defineMethod (c$, "addPath", 
function (a) {
var b =  new android.graphics.Matrix ();
b.reset ();
this.addPath (a, b);
}, "android.graphics.Path.SkPath");
Clazz.defineMethod (c$, "addPath", 
($fz = function (a, b) {
var c =  new Array (4);
var d;
var e = Clazz.innerTypeInstance (android.graphics.Path.SkPath.PathIter, this, null, a, false);
while ((d = e.next (c)) != 5) {
switch (d) {
case 0:
var f =  Clazz.newArray (2, 0);
f[0] = c[0].x;
f[1] = c[0].y;
b.mapPoints (f);
this.moveTo (f[0], f[1]);
break;
case 1:
var g =  Clazz.newArray (2, 0);
g[0] = c[1].x;
g[1] = c[1].y;
b.mapPoints (g);
this.lineTo (g[0], g[1]);
break;
case 2:
var h =  Clazz.newArray (4, 0);
h[0] = c[1].x;
h[1] = c[1].y;
h[2] = c[2].x;
h[3] = c[2].y;
b.mapPoints (h);
this.quadTo (h[0], h[1], h[2], h[3]);
break;
case 3:
var i =  Clazz.newArray (6, 0);
i[0] = c[1].x;
i[1] = c[1].y;
i[2] = c[2].x;
i[3] = c[2].y;
i[4] = c[3].x;
i[5] = c[3].y;
b.mapPoints (i);
this.cubicTo (i[0], i[1], i[2], i[3], i[4], i[5]);
break;
case 4:
this.close ();
break;
default:
android.util.Log.e ("Path", "unknown verb");
}
}
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,android.graphics.Matrix");
Clazz.defineMethod (c$, "transform", 
function (a, b) {
if (b == null) {
b = this;
}if ((a.getType () & 0x08) != 0) {
android.util.Log.e ("Path", "transform path with perspective has not been implemented yet!");
} else {
if (!this.fBoundsIsDirty && a.rectStaysRect () && this.fPts.size () > 1) {
a.mapRect (b.fBounds, this.fBounds);
b.fBoundsIsDirty = false;
} else {
b.fBoundsIsDirty = true;
}if (this !== b) {
b.fVerbs = this.fVerbs;
b.fFillType = this.fFillType;
}var c =  Clazz.newArray (this.fPts.size () * 2, 0);
var d =  Clazz.newArray (this.fPts.size () * 2, 0);
for (var e = 0; e < this.fPts.size (); e++) {
d[e * 2 + 0] = this.fPts.get (e).x;
d[e * 2 + 1] = this.fPts.get (e).y;
}
a.mapPoints (c, d);
}}, "android.graphics.Matrix,android.graphics.Path.SkPath");
Clazz.defineMethod (c$, "drawOnCanvas", 
function (a, b, c) {
this.mCanvasId = a;
this.mBitmap = b;
var _canvas = null;
if (this.mCanvasId != null) {
_canvas = document.getElementById(this.mCanvasId);
} else {
_canvas = this.mBitmap.mCachedCanvas;
// Update the bitmap cached canvas dirty flag
this.mBitmap.mIsCachedCanvasDirty = true;
}
if (_canvas == null) {
throw "Can't get canvas for this path!";
}
var ctx = _canvas.getContext("2d");
ctx.beginPath();
var d = Clazz.innerTypeInstance (android.graphics.Path.SkPath.PathIter, this, null, this, false);
this.mPts =  new Array (4);
var e;
while ((e = d.next (this.mPts)) != 5) {
switch (e) {
case 0:
{
ctx.moveTo(this.mPts[0].x, this.mPts[0].y);
}break;
case 1:
{
ctx.lineTo(this.mPts[1].x, this.mPts[1].y);
}break;
case 2:
{
ctx.quadraticCurveTo(this.mPts[1].x, this.mPts[1].y, this.mPts[2].x, this.mPts[2].y);
}break;
case 3:
{
ctx.bezierCurveTo(this.mPts[1].x, this.mPts[1].y, this.mPts[2].x, this.mPts[2].y, this.mPts[3].x, this.mPts[3].y);
}break;
case 4:
{
ctx.closePath();
}break;
default:
break;
}
}
var f = c.getStyle ();
if (android.graphics.Paint.Style.FILL.equals (f)) {
ctx.fill();
} else if (android.graphics.Paint.Style.STROKE.equals (f)) {
ctx.stroke();
} else if (android.graphics.Paint.Style.FILL_AND_STROKE.equals (f)) {
ctx.fill();
ctx.stroke();
}}, "~S,android.graphics.Bitmap,android.graphics.Paint");
c$.$Path$SkPath$Bezier$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.x1 = 0;
this.y1 = 0;
this.x2 = 0;
this.y2 = 0;
this.x3 = 0;
this.y3 = 0;
this.x4 = 0;
this.y4 = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Path.SkPath, "Bezier");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "setValue", 
function (a, b, c, d, e, f, g, h) {
this.x1 = a;
this.y1 = b;
this.x2 = c;
this.y2 = d;
this.x3 = e;
this.y3 = f;
this.x4 = g;
this.y4 = h;
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "fromPoints", 
function (a, b, c, d) {
this.x1 = a.x;
this.y1 = a.y;
this.x2 = b.x;
this.y2 = b.y;
this.x3 = c.x;
this.y3 = c.y;
this.x4 = d.x;
this.y4 = d.y;
}, "android.graphics.PointF,android.graphics.PointF,android.graphics.PointF,android.graphics.PointF");
Clazz.defineMethod (c$, "bezierOnInterval", 
function (a, b) {
if (a == 0 && b == 1) return this;
var c = Clazz.innerTypeInstance (android.graphics.Path.SkPath.Bezier, this, null);
c.setValue (this.x1, this.y1, this.x2, this.y2, this.x3, this.y3, this.x4, this.y4);
var d = Clazz.innerTypeInstance (android.graphics.Path.SkPath.Bezier, this, null);
c.parameterSplitLeft (a, d);
var e = (b - a) / (1 - a);
c.parameterSplitLeft (e, d);
return d;
}, "~N,~N");
Clazz.defineMethod (c$, "parameterSplitLeft", 
function (a, b) {
b.x1 = this.x1;
b.y1 = this.y1;
b.x2 = this.x1 + a * (this.x2 - this.x1);
b.y2 = this.y1 + a * (this.y2 - this.y1);
b.x3 = this.x2 + a * (this.x3 - this.x2);
b.y3 = this.y2 + a * (this.y3 - this.y2);
this.x3 = this.x3 + a * (this.x4 - this.x3);
this.y3 = this.y3 + a * (this.y4 - this.y3);
this.x2 = b.x3 + a * (this.x3 - b.x3);
this.y2 = b.y3 + a * (this.y3 - b.y3);
b.x3 = b.x2 + a * (b.x3 - b.x2);
b.y3 = b.y2 + a * (b.y3 - b.y2);
b.x4 = this.x1 = b.x3 + a * (this.x2 - b.x3);
b.y4 = this.y1 = b.y3 + a * (this.y2 - b.y3);
}, "~N,android.graphics.Path.SkPath.Bezier");
c$ = Clazz.p0p ();
};
c$.$Path$SkPath$PathIter$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.fPath = null;
this.fPtsIndex = 0;
this.fVerbIndex = 0;
this.fVerbStop = 0;
this.fMoveTo = null;
this.fLastPt = null;
this.fForceClose = false;
this.fNeedClose = false;
this.fNeedMoveTo = 2;
this.fCloseLine = false;
Clazz.instantialize (this, arguments);
}, android.graphics.Path.SkPath, "PathIter");
Clazz.makeConstructor (c$, 
function (a, b) {
this.setPath (a, b);
}, "android.graphics.Path.SkPath,~B");
Clazz.defineMethod (c$, "setPath", 
($fz = function (a, b) {
this.fPath = a;
this.fPtsIndex = 0;
this.fVerbIndex = 0;
this.fVerbStop = a.fVerbs.size ();
this.fForceClose = b;
this.fNeedClose = false;
}, $fz.isPrivate = true, $fz), "android.graphics.Path.SkPath,~B");
Clazz.defineMethod (c$, "next", 
function (a) {
if (this.fVerbIndex == this.fVerbStop) {
if (this.fNeedClose) {
if (1 == this.autoClose (a)) {
return 1;
}this.fNeedClose = false;
return 5;
}return 5;
}var b = (this.fPath.fVerbs.get (this.fVerbIndex++)).intValue ();
switch (b) {
case 0:
if (this.fNeedClose) {
this.fVerbIndex -= 1;
b = this.autoClose (a);
if (b == 4) {
this.fNeedClose = false;
}return b;
}if (this.fVerbIndex == this.fVerbStop) {
return 5;
}this.fMoveTo = this.fPath.fPts.get (this.fPtsIndex);
if (a != null) {
a[0] = this.fMoveTo;
}this.fPtsIndex += 1;
this.fNeedMoveTo = 1;
this.fNeedClose = this.fForceClose;
break;
case 1:
if (this.cons_moveTo (a)) {
return 0;
}if (a != null) {
a[1] = this.fPath.fPts.get (this.fPtsIndex);
}this.fLastPt = this.fPath.fPts.get (this.fPtsIndex);
this.fCloseLine = false;
this.fPtsIndex += 1;
break;
case 2:
if (this.cons_moveTo (a)) {
return 0;
}if (a != null) {
a[1] = this.fPath.fPts.get (this.fPtsIndex);
a[2] = this.fPath.fPts.get (this.fPtsIndex + 1);
}this.fLastPt = this.fPath.fPts.get (this.fPtsIndex + 1);
this.fPtsIndex += 2;
break;
case 3:
if (this.cons_moveTo (a)) {
return 0;
}if (a != null) {
a[1] = this.fPath.fPts.get (this.fPtsIndex);
a[2] = this.fPath.fPts.get (this.fPtsIndex + 1);
a[3] = this.fPath.fPts.get (this.fPtsIndex + 2);
}this.fLastPt = this.fPath.fPts.get (this.fPtsIndex + 2);
;this.fPtsIndex += 3;
break;
case 4:
b = this.autoClose (a);
if (b == 1) {
this.fVerbIndex -= 1;
} else {
this.fNeedClose = false;
}this.fNeedMoveTo = 0;
break;
}
return b;
}, "~A");
Clazz.defineMethod (c$, "cons_moveTo", 
($fz = function (a) {
if (this.fNeedMoveTo == 0) {
if (a != null) {
a[0] = this.fMoveTo;
}this.fNeedClose = this.fForceClose;
this.fNeedMoveTo = 1;
this.fVerbIndex -= 1;
return true;
}if (this.fNeedMoveTo == 1) {
if (a != null) {
a[0] = this.fMoveTo;
}this.fNeedMoveTo = 2;
} else {
if (a != null) {
a[0] = this.fPath.fPts.get (this.fPtsIndex - 1);
}}return false;
}, $fz.isPrivate = true, $fz), "~A");
Clazz.defineMethod (c$, "autoClose", 
($fz = function (a) {
if (this.fLastPt.x != this.fMoveTo.x || this.fLastPt.y != this.fMoveTo.y) {
if (Float.isNaN (this.fLastPt.x) || Float.isNaN (this.fLastPt.y) || Float.isNaN (this.fMoveTo.x) || Float.isNaN (this.fMoveTo.y)) {
return 4;
}if (a != null) {
a[0] = this.fLastPt;
a[1] = this.fMoveTo;
}this.fLastPt = this.fMoveTo;
this.fCloseLine = true;
return 1;
}return 4;
}, $fz.isPrivate = true, $fz), "~A");
Clazz.defineStatics (c$,
"kAfterClose_NeedMoveToState", 0,
"kAfterCons_NeedMoveToState", 1,
"kAfterPrefix_NeedMoveToState", 2);
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"kWinding_FillType", 0,
"kEvenOdd_FillType", 1,
"kInverseWinding_FillType", 2,
"kInverseEvenOdd_FillType", 3,
"kMove_Verb", 0,
"kLine_Verb", 1,
"kQuad_Verb", 2,
"kCubic_Verb", 3,
"kClose_Verb", 4,
"kDone_Verb", 5,
"kCW_Direction", 0,
"kCCW_Direction", 1,
"SK_PATH_KAPPA", 0.5522847498);
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Path, "FillType");
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (a) {
if ("WINDING".equals (a)) {
return android.graphics.Path.FillType.WINDING;
} else if ("EVEN_ODD".equals (a)) {
return android.graphics.Path.FillType.EVEN_ODD;
} else if ("INVERSE_WINDING".equals (a)) {
return android.graphics.Path.FillType.INVERSE_WINDING;
} else if ("INVERSE_EVEN_ODD".equals (a)) {
return android.graphics.Path.FillType.INVERSE_EVEN_ODD;
} else {
return null;
}}, "~S");
c$.values = Clazz.defineMethod (c$, "values", 
function () {
var a =  new Array (4);
a[0] = android.graphics.Path.FillType.WINDING;
a[1] = android.graphics.Path.FillType.EVEN_ODD;
a[2] = android.graphics.Path.FillType.INVERSE_WINDING;
a[3] = android.graphics.Path.FillType.INVERSE_EVEN_ODD;
return a;
});
c$.WINDING = c$.prototype.WINDING =  new android.graphics.Path.FillType (0);
c$.EVEN_ODD = c$.prototype.EVEN_ODD =  new android.graphics.Path.FillType (1);
c$.INVERSE_WINDING = c$.prototype.INVERSE_WINDING =  new android.graphics.Path.FillType (2);
c$.INVERSE_EVEN_ODD = c$.prototype.INVERSE_EVEN_ODD =  new android.graphics.Path.FillType (3);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Path, "Direction");
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (a) {
if ("CW".equals (a)) {
return android.graphics.Path.Direction.CW;
} else if ("CCW".equals (a)) {
return android.graphics.Path.Direction.CCW;
} else {
return null;
}}, "~S");
c$.values = Clazz.defineMethod (c$, "values", 
function () {
var a =  new Array (2);
a[0] = android.graphics.Path.Direction.CW;
a[1] = android.graphics.Path.Direction.CCW;
return a;
});
c$.CW = c$.prototype.CW =  new android.graphics.Path.Direction (0);
c$.CCW = c$.prototype.CCW =  new android.graphics.Path.Direction (1);
c$ = Clazz.p0p ();
c$.sFillTypeArray = c$.prototype.sFillTypeArray = [android.graphics.Path.FillType.WINDING, android.graphics.Path.FillType.EVEN_ODD, android.graphics.Path.FillType.INVERSE_WINDING, android.graphics.Path.FillType.INVERSE_EVEN_ODD];
});
