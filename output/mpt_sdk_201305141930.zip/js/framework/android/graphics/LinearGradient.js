﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["android.graphics.Shader"], "android.graphics.LinearGradient", ["android.graphics.PointF", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.m_pts0 = null;
this.m_pts1 = null;
this.m_colors = null;
this.m_positions = null;
this.m_tileMode = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "LinearGradient", android.graphics.Shader);
Clazz.makeConstructor (c$, 
function (x0, y0, x1, y1, colors, positions, tile) {
Clazz.superConstructor (this, android.graphics.LinearGradient, []);
if (colors.length < 2) {
throw  new IllegalArgumentException ("needs >= 2 number of colors");
}if (positions != null && colors.length != positions.length) {
throw  new IllegalArgumentException ("color and position arrays must be of equal length");
}this.m_pts0 =  new android.graphics.PointF (x0, y0);
this.m_pts1 =  new android.graphics.PointF (x1, y1);
this.m_tileMode = tile;
this.m_colors =  Clazz.newArray (colors.length, 0);
for (var i = 0; i < colors.length; i++) {
this.m_colors[i] = colors[i];
}
if (positions != null) {
this.m_positions =  Clazz.newArray (positions.length, 0);
for (var i = 0; i < positions.length; i++) {
this.m_positions[i] = positions[i];
}
}}, "~N,~N,~N,~N,~A,~A,android.graphics.Shader.TileMode");
Clazz.makeConstructor (c$, 
function (x0, y0, x1, y1, color0, color1, tile) {
Clazz.superConstructor (this, android.graphics.LinearGradient, []);
this.m_pts0 =  new android.graphics.PointF (x0, y0);
this.m_pts1 =  new android.graphics.PointF (x1, y1);
this.m_tileMode = tile;
this.m_colors =  Clazz.newArray (2, 0);
this.m_colors[0] = color0;
this.m_colors[1] = color1;
}, "~N,~N,~N,~N,~N,~N,android.graphics.Shader.TileMode");
});
