﻿Clazz.declarePackage ("android.graphics");
Clazz.load (null, "android.graphics.NinePatch", ["android.graphics.BitmapFactory", "$.Color", "$.Paint", "$.Rect", "$.RectF", "android.util.Log", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mBitmap = null;
this.mChunk = null;
this.mPaint = null;
this.mSrcName = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "NinePatch");
Clazz.makeConstructor (c$, 
function (bitmap, chunk, srcName) {
this.mBitmap = bitmap;
this.mChunk = android.graphics.BitmapFactory.Res_png_9patch.deserialize (chunk);
this.mSrcName = srcName;
android.graphics.NinePatch.validateNinePatchChunk (this.mBitmap, this.mChunk);
}, "android.graphics.Bitmap,~A,~S");
Clazz.makeConstructor (c$, 
function (bitmap, chunk, srcName) {
this.mBitmap = bitmap;
this.mChunk = chunk;
this.mSrcName = srcName;
android.graphics.NinePatch.validateNinePatchChunk (this.mBitmap, chunk);
}, "android.graphics.Bitmap,android.graphics.BitmapFactory.Res_png_9patch,~S");
Clazz.makeConstructor (c$, 
function (patch) {
this.mBitmap = patch.mBitmap;
this.mChunk = patch.mChunk;
this.mSrcName = patch.mSrcName;
if (patch.mPaint != null) {
this.mPaint =  new android.graphics.Paint (patch.mPaint);
}android.graphics.NinePatch.validateNinePatchChunk (this.mBitmap, this.mChunk);
}, "android.graphics.NinePatch");
Clazz.defineMethod (c$, "setPaint", 
function (p) {
this.mPaint = p;
}, "android.graphics.Paint");
Clazz.defineMethod (c$, "draw", 
function (canvas, location) {
this.draw (canvas, location, this.mPaint, canvas.mDensity, this.mBitmap.getDensity ());
}, "android.graphics.Canvas,android.graphics.RectF");
Clazz.defineMethod (c$, "draw", 
function (canvas, location) {
this.draw (canvas,  new android.graphics.RectF (location), this.mPaint, canvas.mDensity, this.mBitmap.getDensity ());
}, "android.graphics.Canvas,android.graphics.Rect");
Clazz.defineMethod (c$, "draw", 
function (canvas, location, paint) {
this.draw (canvas,  new android.graphics.RectF (location), paint, canvas.mDensity, this.mBitmap.getDensity ());
}, "android.graphics.Canvas,android.graphics.Rect,android.graphics.Paint");
Clazz.defineMethod (c$, "draw", 
($fz = function (canvas, location, paint, destDensity, srcDensity) {
var chunk = this.mBitmap.getNinePatch ();
if (destDensity == srcDensity || destDensity == 0 || srcDensity == 0) {
android.util.Log.v ("NinePatch", "Drawing unscaled 9-patch: (" + location.left + "," + location.top + ")-(" + location.right + "," + location.bottom + ")");
this.NinePatch_Draw (canvas, location, this.mBitmap, chunk, paint);
} else {
canvas.save ();
var scale = Math.floor (destDensity / srcDensity);
canvas.translate (location.left, location.top);
canvas.scale (scale, scale);
location.right = (location.right - location.left) / scale;
location.bottom = (location.bottom - location.top) / scale;
location.left = location.top = 0;
android.util.Log.v ("NinePatch", "Drawing unscaled 9-patch: (" + location.left + "," + location.top + ")-(" + location.right + "," + location.bottom + ")" + " " + "srcDensity=" + srcDensity + " destDensity=" + destDensity);
this.NinePatch_Draw (canvas, location, this.mBitmap, chunk, paint);
canvas.restore ();
}}, $fz.isPrivate = true, $fz), "android.graphics.Canvas,android.graphics.RectF,android.graphics.Paint,~N,~N");
Clazz.defineMethod (c$, "NinePatch_Draw", 
($fz = function (canvas, location, bitmap, chunk, paint) {
var defaultPaint =  new android.graphics.Paint ();
if (null == paint) {
defaultPaint.setDither (true);
paint = defaultPaint;
}if (true) {
android.util.Log.v ("NinePatch", "======== ninepatch location [" + location.width () + " " + location.height () + "]");
android.util.Log.v ("NinePatch", "======== ninepatch paint bm [" + bitmap.getWidth () + "," + bitmap.getHeight () + "]");
android.util.Log.v ("NinePatch", "======== ninepatch xDivs [" + chunk.xDivs[0] + "," + chunk.xDivs[1] + "]");
android.util.Log.v ("NinePatch", "======== ninepatch yDivs [" + chunk.yDivs[0] + "," + chunk.yDivs[1] + "]");
}if (location.isEmpty () || bitmap.getWidth () == 0 || bitmap.getHeight () == 0) {
if (true) android.util.Log.v ("NinePatch", "======== abort ninepatch draw");
return ;
}var hasXfer = false;
var dst =  new android.graphics.RectF ();
var src =  new android.graphics.RectF ();
var x0 = chunk.xDivs[0];
var y0 = chunk.yDivs[0];
var initColor = paint.getColor ();
var numXDivs = chunk.numXDivs;
var numYDivs = chunk.numYDivs;
var i;
var j;
var colorIndex = 0;
var color;
var xIsStretchable;
var initialXIsStretchable = (x0 == 0);
var yIsStretchable = (y0 == 0);
var bitmapWidth = bitmap.getWidth ();
var bitmapHeight = bitmap.getHeight ();
var dstRights =  Clazz.newArray (numXDivs + 1, 0);
var dstRightsHaveBeenCached = false;
var numStretchyXPixelsRemaining = 0;
for (i = 0; i < numXDivs; i += 2) {
numStretchyXPixelsRemaining += chunk.xDivs[i + 1] - chunk.xDivs[i];
}
var numFixedXPixelsRemaining = bitmapWidth - numStretchyXPixelsRemaining;
var numStretchyYPixelsRemaining = 0;
for (i = 0; i < numYDivs; i += 2) {
numStretchyYPixelsRemaining += chunk.yDivs[i + 1] - chunk.yDivs[i];
}
var numFixedYPixelsRemaining = bitmapHeight - numStretchyYPixelsRemaining;
src.top = 0;
dst.top = location.top;
for (j = yIsStretchable ? 1 : 0; j <= numYDivs && src.top < bitmapHeight; j++, yIsStretchable = !yIsStretchable) {
src.left = 0;
dst.left = location.left;
if (j == numYDivs) {
src.bottom = bitmapHeight;
dst.bottom = location.bottom;
} else {
src.bottom = chunk.yDivs[j];
var srcYSize = src.bottom - src.top;
if (yIsStretchable) {
dst.bottom = dst.top + this.calculateStretch (location.bottom, dst.top, srcYSize, numStretchyYPixelsRemaining, numFixedYPixelsRemaining);
numStretchyYPixelsRemaining -= srcYSize;
} else {
dst.bottom = dst.top + srcYSize;
numFixedYPixelsRemaining -= srcYSize;
}}xIsStretchable = initialXIsStretchable;
for (i = xIsStretchable ? 1 : 0; i <= numXDivs && src.left < bitmapWidth; i++, xIsStretchable = !xIsStretchable) {
color = chunk.colors[colorIndex++];
if (i == numXDivs) {
src.right = bitmapWidth;
dst.right = location.right;
} else {
src.right = chunk.xDivs[i];
if (dstRightsHaveBeenCached) {
dst.right = dstRights[i];
} else {
var srcXSize = src.right - src.left;
if (xIsStretchable) {
dst.right = dst.left + this.calculateStretch (location.right, dst.left, srcXSize, numStretchyXPixelsRemaining, numFixedXPixelsRemaining);
numStretchyXPixelsRemaining -= srcXSize;
} else {
dst.right = dst.left + srcXSize;
numFixedXPixelsRemaining -= srcXSize;
}dstRights[i] = dst.right;
}}if (src.left >= src.right) {
src.left = src.right;
continue ;}if (dst.right <= dst.left || dst.bottom <= dst.top) {
} else {
if (canvas != null) {
this.drawStretchyPatch (canvas, src, dst, bitmap, paint, initColor, color, hasXfer);
}}src.left = src.right;
dst.left = dst.right;
}
src.top = src.bottom;
dst.top = dst.bottom;
dstRightsHaveBeenCached = true;
}
}, $fz.isPrivate = true, $fz), "android.graphics.Canvas,android.graphics.RectF,android.graphics.Bitmap,android.graphics.BitmapFactory.Res_png_9patch,android.graphics.Paint");
Clazz.defineMethod (c$, "calculateStretch", 
($fz = function (boundsLimit, startingPoint, srcSpace, numStrechyPixelsRemaining, numFixedPixelsRemaining) {
var spaceRemaining = boundsLimit - startingPoint;
var stretchySpaceRemaining = spaceRemaining - numFixedPixelsRemaining;
return srcSpace * stretchySpaceRemaining / numStrechyPixelsRemaining;
}, $fz.isPrivate = true, $fz), "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "drawStretchyPatch", 
($fz = function (canvas, src, dst, bitmap, paint, initColor, colorHint, hasXfer) {
if (colorHint != 1) {
var modAlpha = Math.round ((android.graphics.Color.alpha (colorHint) * paint.getAlpha () / 256.0));
var color = android.graphics.Color.argb (modAlpha, android.graphics.Color.red (colorHint), android.graphics.Color.green (colorHint), android.graphics.Color.blue (colorHint));
paint.setColor (color);
canvas.drawRect (dst, paint);
paint.setColor (initColor);
} else if (src.width () == 1 && src.height () == 1) {
var c = bitmap.getPixel (Math.round (src.left), Math.round (src.top));
if (0 != c || hasXfer) {
var prev = paint.getColor ();
paint.setColor (c);
canvas.drawRect (dst, paint);
paint.setColor (prev);
}} else {
var tmpSrc =  new android.graphics.Rect (Math.round (src.left), Math.round (src.top), Math.round (src.right), Math.round (src.bottom));
canvas.drawBitmap (bitmap, tmpSrc, dst, paint);
}}, $fz.isPrivate = true, $fz), "android.graphics.Canvas,android.graphics.RectF,android.graphics.RectF,android.graphics.Bitmap,android.graphics.Paint,~N,~N,~B");
Clazz.defineMethod (c$, "getDensity", 
function () {
return this.mBitmap.mDensity;
});
Clazz.defineMethod (c$, "getWidth", 
function () {
return this.mBitmap.getWidth ();
});
Clazz.defineMethod (c$, "getHeight", 
function () {
return this.mBitmap.getHeight ();
});
Clazz.defineMethod (c$, "hasAlpha", 
function () {
return this.mBitmap.hasAlpha ();
});
Clazz.defineMethod (c$, "getTransparentRegion", 
function (location) {
android.util.Log.e ("NinePatch", "Not implemented yet!");
return null;
}, "android.graphics.Rect");
c$.isNinePatchChunk = Clazz.defineMethod (c$, "isNinePatchChunk", 
function (chunk) {
if (chunk == null) {
return false;
}if (chunk.length < 32) {
return false;
}if (chunk[0] != 0) {
return false;
}return true;
}, "~A");
c$.validateNinePatchChunk = Clazz.defineMethod (c$, "validateNinePatchChunk", 
($fz = function (bitmap, chunk) {
if (chunk.wasDeserialized != 1) {
throw  new RuntimeException ("NinePatchChunk is not deserialized!.");
}}, $fz.isPrivate = true, $fz), "android.graphics.Bitmap,android.graphics.BitmapFactory.Res_png_9patch");
Clazz.defineStatics (c$,
"debug", true);
});
