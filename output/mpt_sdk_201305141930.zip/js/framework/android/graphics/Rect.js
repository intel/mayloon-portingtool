﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["java.util.regex.Pattern"], "android.graphics.Rect", ["java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.left = 0;
this.top = 0;
this.right = 0;
this.bottom = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "Rect");
Clazz.defineMethod (c$, "copyFrom", 
function (_rect) {
this.left = _rect.left;
this.top = _rect.top;
this.right = _rect.right;
this.bottom = _rect.bottom;
}, "android.graphics.Rect");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (left, top, right, bottom) {
this.left = left;
this.top = top;
this.right = right;
this.bottom = bottom;
}, "~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (r) {
this.left = r.left;
this.top = r.top;
this.right = r.right;
this.bottom = r.bottom;
}, "android.graphics.Rect");
Clazz.overrideMethod (c$, "equals", 
function (obj) {
var r = obj;
if (r != null) {
return this.left == r.left && this.top == r.top && this.right == r.right && this.bottom == r.bottom;
}return false;
}, "~O");
Clazz.overrideMethod (c$, "toString", 
function () {
var sb =  new StringBuilder (32);
sb.append ("Rect(");
sb.append (this.left);
sb.append (", ");
sb.append (this.top);
sb.append (" - ");
sb.append (this.right);
sb.append (", ");
sb.append (this.bottom);
sb.append (")");
return sb.toString ();
});
Clazz.defineMethod (c$, "toShortString", 
function () {
return this.toShortString ( new StringBuilder (32));
});
Clazz.defineMethod (c$, "toShortString", 
function (sb) {
sb.setLength (0);
sb.append ('[');
sb.append (this.left);
sb.append (',');
sb.append (this.top);
sb.append ("][");
sb.append (this.right);
sb.append (',');
sb.append (this.bottom);
sb.append (']');
return sb.toString ();
}, "StringBuilder");
Clazz.defineMethod (c$, "flattenToString", 
function () {
var sb =  new StringBuilder (32);
sb.append (this.left);
sb.append (' ');
sb.append (this.top);
sb.append (' ');
sb.append (this.right);
sb.append (' ');
sb.append (this.bottom);
return sb.toString ();
});
c$.unflattenFromString = Clazz.defineMethod (c$, "unflattenFromString", 
function (str) {
var matcher = android.graphics.Rect.FLATTENED_PATTERN.matcher (str);
if (!matcher.matches ()) {
return null;
}return  new android.graphics.Rect (Integer.parseInt (matcher.group (1)), Integer.parseInt (matcher.group (2)), Integer.parseInt (matcher.group (3)), Integer.parseInt (matcher.group (4)));
}, "~S");
Clazz.defineMethod (c$, "isEmpty", 
function () {
return this.left >= this.right || this.top >= this.bottom;
});
Clazz.defineMethod (c$, "width", 
function () {
return this.right - this.left;
});
Clazz.defineMethod (c$, "height", 
function () {
return this.bottom - this.top;
});
Clazz.defineMethod (c$, "centerX", 
function () {
return (this.left + this.right) >> 1;
});
Clazz.defineMethod (c$, "centerY", 
function () {
return (this.top + this.bottom) >> 1;
});
Clazz.defineMethod (c$, "exactCenterX", 
function () {
return (this.left + this.right) * 0.5;
});
Clazz.defineMethod (c$, "exactCenterY", 
function () {
return (this.top + this.bottom) * 0.5;
});
Clazz.defineMethod (c$, "setEmpty", 
function () {
this.left = this.right = this.top = this.bottom = 0;
});
Clazz.defineMethod (c$, "set", 
function (left, top, right, bottom) {
this.left = left;
this.top = top;
this.right = right;
this.bottom = bottom;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "set", 
function (src) {
this.left = src.left;
this.top = src.top;
this.right = src.right;
this.bottom = src.bottom;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "offset", 
function (dx, dy) {
this.left += dx;
this.top += dy;
this.right += dx;
this.bottom += dy;
}, "~N,~N");
Clazz.defineMethod (c$, "offsetTo", 
function (newLeft, newTop) {
this.right += newLeft - this.left;
this.bottom += newTop - this.top;
this.left = newLeft;
this.top = newTop;
}, "~N,~N");
Clazz.defineMethod (c$, "inset", 
function (dx, dy) {
this.left += dx;
this.top += dy;
this.right -= dx;
this.bottom -= dy;
}, "~N,~N");
Clazz.defineMethod (c$, "contains", 
function (x, y) {
return this.left < this.right && this.top < this.bottom && x >= this.left && x < this.right && y >= this.top && y < this.bottom;
}, "~N,~N");
Clazz.defineMethod (c$, "contains", 
function (left, top, right, bottom) {
return this.left < this.right && this.top < this.bottom && this.left <= left && this.top <= top && this.right >= right && this.bottom >= bottom;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "contains", 
function (r) {
return this.left < this.right && this.top < this.bottom && this.left <= r.left && this.top <= r.top && this.right >= r.right && this.bottom >= r.bottom;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "intersect", 
function (left, top, right, bottom) {
if (this.left < right && left < this.right && this.top < bottom && top < this.bottom) {
if (this.left < left) {
this.left = left;
}if (this.top < top) {
this.top = top;
}if (this.right > right) {
this.right = right;
}if (this.bottom > bottom) {
this.bottom = bottom;
}return true;
}return false;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "intersect", 
function (r) {
return this.intersect (r.left, r.top, r.right, r.bottom);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "setIntersect", 
function (a, b) {
if (a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom) {
this.left = Math.max (a.left, b.left);
this.top = Math.max (a.top, b.top);
this.right = Math.min (a.right, b.right);
this.bottom = Math.min (a.bottom, b.bottom);
return true;
}return false;
}, "android.graphics.Rect,android.graphics.Rect");
Clazz.defineMethod (c$, "intersects", 
function (left, top, right, bottom) {
return this.left < right && left < this.right && this.top < bottom && top < this.bottom;
}, "~N,~N,~N,~N");
c$.intersects = Clazz.defineMethod (c$, "intersects", 
function (a, b) {
return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
}, "android.graphics.Rect,android.graphics.Rect");
Clazz.defineMethod (c$, "union", 
function (left, top, right, bottom) {
if ((left < right) && (top < bottom)) {
if ((this.left < this.right) && (this.top < this.bottom)) {
if (this.left > left) this.left = left;
if (this.top > top) this.top = top;
if (this.right < right) this.right = right;
if (this.bottom < bottom) this.bottom = bottom;
} else {
this.left = left;
this.top = top;
this.right = right;
this.bottom = bottom;
}}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "union", 
function (r) {
this.union (r.left, r.top, r.right, r.bottom);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "union", 
function (x, y) {
if (x < this.left) {
this.left = x;
} else if (x > this.right) {
this.right = x;
}if (y < this.top) {
this.top = y;
} else if (y > this.bottom) {
this.bottom = y;
}}, "~N,~N");
Clazz.defineMethod (c$, "sort", 
function () {
if (this.left > this.right) {
var temp = this.left;
this.left = this.right;
this.right = temp;
}if (this.top > this.bottom) {
var temp = this.top;
this.top = this.bottom;
this.bottom = temp;
}});
Clazz.defineMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "scale", 
function (scale) {
if (scale != 1.0) {
this.left = Math.round ((this.left * scale + 0.5));
this.top = Math.round ((this.top * scale + 0.5));
this.right = Math.round ((this.right * scale + 0.5));
this.bottom = Math.round ((this.bottom * scale + 0.5));
}}, "~N");
Clazz.defineMethod (c$, "readFromParcel", 
function ($in) {
console.log("Missing method: readFromParcel");
}, "android.os.Parcel");
c$.FLATTENED_PATTERN = c$.prototype.FLATTENED_PATTERN = java.util.regex.Pattern.compile ("(-?\\d+) (-?\\d+) (-?\\d+) (-?\\d+)");
});
