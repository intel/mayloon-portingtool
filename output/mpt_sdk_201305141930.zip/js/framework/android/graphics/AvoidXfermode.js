﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["android.graphics.Xfermode", "java.lang.Enum"], "android.graphics.AvoidXfermode", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.declareType (android.graphics, "AvoidXfermode", android.graphics.Xfermode);
Clazz.makeConstructor (c$, 
function (opColor, tolerance, mode) {
Clazz.superConstructor (this, android.graphics.AvoidXfermode, []);
if (tolerance < 0 || tolerance > 255) {
throw  new IllegalArgumentException ("tolerance must be 0..255");
}}, "~N,~N,android.graphics.AvoidXfermode.Mode");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.AvoidXfermode, "Mode", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
Clazz.defineEnumConstant (c$, "AVOID", 0, [0]);
Clazz.defineEnumConstant (c$, "TARGET", 1, [1]);
c$ = Clazz.p0p ();
});
