﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["java.lang.Enum"], "android.graphics.Interpolator", ["java.lang.ArrayStoreException", "$.IndexOutOfBoundsException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mValueCount = 0;
this.mFrameCount = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "Interpolator");
Clazz.makeConstructor (c$, 
function (valueCount) {
this.mValueCount = valueCount;
this.mFrameCount = 2;
}, "~N");
Clazz.makeConstructor (c$, 
function (valueCount, frameCount) {
this.mValueCount = valueCount;
this.mFrameCount = frameCount;
}, "~N,~N");
Clazz.defineMethod (c$, "reset", 
function (valueCount) {
this.reset (valueCount, 2);
}, "~N");
Clazz.defineMethod (c$, "reset", 
function (valueCount, frameCount) {
this.mValueCount = valueCount;
this.mFrameCount = frameCount;
}, "~N,~N");
Clazz.defineMethod (c$, "getKeyFrameCount", 
function () {
return this.mFrameCount;
});
Clazz.defineMethod (c$, "getValueCount", 
function () {
return this.mValueCount;
});
Clazz.defineMethod (c$, "setKeyFrame", 
function (index, msec, values) {
this.setKeyFrame (index, msec, values, null);
}, "~N,~N,~A");
Clazz.defineMethod (c$, "setKeyFrame", 
function (index, msec, values, blend) {
if (index < 0 || index >= this.mFrameCount) {
throw  new IndexOutOfBoundsException ();
}if (values.length < this.mValueCount) {
throw  new ArrayStoreException ();
}if (blend != null && blend.length < 4) {
throw  new ArrayStoreException ();
}}, "~N,~N,~A,~A");
Clazz.defineMethod (c$, "setRepeatMirror", 
function (repeatCount, mirror) {
if (repeatCount >= 0) {
}}, "~N,~B");
Clazz.defineMethod (c$, "timeToValues", 
function (msec, values) {
console.log("Missing method: timeToValues");
}, "~N,~A");
Clazz.overrideMethod (c$, "finalize", 
function () {
console.log("Missing method: finalize");
});
Clazz.defineMethod (c$, "timeToValues", 
function (values) {
console.log("Missing method: timeToValues");
}, "~A");
Clazz.pu$h ();
c$ = Clazz.declareType (android.graphics.Interpolator, "Result", Enum);
Clazz.defineEnumConstant (c$, "NORMAL", 0, []);
Clazz.defineEnumConstant (c$, "FREEZE_START", 1, []);
Clazz.defineEnumConstant (c$, "FREEZE_END", 2, []);
c$ = Clazz.p0p ();
});
