﻿Clazz.declarePackage ("android.graphics");
Clazz.load (null, "android.graphics.PointF", ["android.util.FloatMath"], function () {
c$ = Clazz.decorateAsClass (function () {
this.x = 0;
this.y = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "PointF");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (x, y) {
this.x = x;
this.y = y;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (p) {
this.x = p.x;
this.y = p.y;
}, "android.graphics.Point");
Clazz.defineMethod (c$, "set", 
function (x, y) {
this.x = x;
this.y = y;
}, "~N,~N");
Clazz.defineMethod (c$, "set", 
function (p) {
this.x = p.x;
this.y = p.y;
}, "android.graphics.PointF");
Clazz.defineMethod (c$, "negate", 
function () {
this.x = -this.x;
this.y = -this.y;
});
Clazz.defineMethod (c$, "offset", 
function (dx, dy) {
this.x += dx;
this.y += dy;
}, "~N,~N");
Clazz.defineMethod (c$, "equals", 
function (x, y) {
return this.x == x && this.y == y;
}, "~N,~N");
Clazz.defineMethod (c$, "length", 
function () {
return android.graphics.PointF.length (this.x, this.y);
});
c$.length = Clazz.defineMethod (c$, "length", 
function (x, y) {
return android.util.FloatMath.sqrt (x * x + y * y);
}, "~N,~N");
});
