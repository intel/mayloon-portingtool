﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["android.os.Parcelable"], "android.graphics.Region", ["android.graphics.Path", "$.Rect", "java.lang.NullPointerException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mNativeRegion = 0;
Clazz.instantialize (this, arguments);
}, android.graphics, "Region", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
this.construct (android.graphics.Region.nativeConstructor ());
});
Clazz.makeConstructor (c$, 
function (region) {
this.construct (android.graphics.Region.nativeConstructor ());
android.graphics.Region.nativeSetRegion (this.mNativeRegion, region.mNativeRegion);
}, "android.graphics.Region");
Clazz.makeConstructor (c$, 
function (r) {
this.mNativeRegion = android.graphics.Region.nativeConstructor ();
android.graphics.Region.nativeSetRect (this.mNativeRegion, r.left, r.top, r.right, r.bottom);
}, "android.graphics.Rect");
Clazz.makeConstructor (c$, 
function (left, top, right, bottom) {
this.mNativeRegion = android.graphics.Region.nativeConstructor ();
android.graphics.Region.nativeSetRect (this.mNativeRegion, left, top, right, bottom);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setEmpty", 
function () {
android.graphics.Region.nativeSetRect (this.mNativeRegion, 0, 0, 0, 0);
});
Clazz.defineMethod (c$, "set", 
function (region) {
return android.graphics.Region.nativeSetRegion (this.mNativeRegion, region.mNativeRegion);
}, "android.graphics.Region");
Clazz.defineMethod (c$, "set", 
function (r) {
return android.graphics.Region.nativeSetRect (this.mNativeRegion, r.left, r.top, r.right, r.bottom);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "set", 
function (left, top, right, bottom) {
return android.graphics.Region.nativeSetRect (this.mNativeRegion, left, top, right, bottom);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setPath", 
function (path, clip) {
return android.graphics.Region.nativeSetPath (this.mNativeRegion, path.ni (), clip.mNativeRegion);
}, "android.graphics.Path,android.graphics.Region");
Clazz.defineMethod (c$, "getBounds", 
function () {
var r =  new android.graphics.Rect ();
android.graphics.Region.nativeGetBounds (this.mNativeRegion, r);
return r;
});
Clazz.defineMethod (c$, "getBounds", 
function (r) {
if (r == null) {
throw  new NullPointerException ();
}return android.graphics.Region.nativeGetBounds (this.mNativeRegion, r);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "getBoundaryPath", 
function () {
var path =  new android.graphics.Path ();
android.graphics.Region.nativeGetBoundaryPath (this.mNativeRegion, path.ni ());
return path;
});
Clazz.defineMethod (c$, "getBoundaryPath", 
function (path) {
return android.graphics.Region.nativeGetBoundaryPath (this.mNativeRegion, path.ni ());
}, "android.graphics.Path");
Clazz.defineMethod (c$, "quickContains", 
function (r) {
return this.quickContains (r.left, r.top, r.right, r.bottom);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "quickReject", 
function (r) {
return this.quickReject (r.left, r.top, r.right, r.bottom);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "translate", 
function (dx, dy) {
this.translate (dx, dy, null);
}, "~N,~N");
Clazz.defineMethod (c$, "scale", 
function (scale) {
this.scale (scale, null);
}, "~N");
Clazz.defineMethod (c$, "union", 
function (r) {
return this.op (r, android.graphics.Region.Op.UNION);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "op", 
function (r, op) {
return android.graphics.Region.nativeOp (this.mNativeRegion, r.left, r.top, r.right, r.bottom, op.nativeInt);
}, "android.graphics.Rect,android.graphics.Region.Op");
Clazz.defineMethod (c$, "op", 
function (left, top, right, bottom, op) {
return android.graphics.Region.nativeOp (this.mNativeRegion, left, top, right, bottom, op.nativeInt);
}, "~N,~N,~N,~N,android.graphics.Region.Op");
Clazz.defineMethod (c$, "op", 
function (region, op) {
return this.op (this, region, op);
}, "android.graphics.Region,android.graphics.Region.Op");
Clazz.defineMethod (c$, "op", 
function (rect, region, op) {
return android.graphics.Region.nativeOp (this.mNativeRegion, rect, region.mNativeRegion, op.nativeInt);
}, "android.graphics.Rect,android.graphics.Region,android.graphics.Region.Op");
Clazz.defineMethod (c$, "op", 
function (region1, region2, op) {
return android.graphics.Region.nativeOp (this.mNativeRegion, region1.mNativeRegion, region2.mNativeRegion, op.nativeInt);
}, "android.graphics.Region,android.graphics.Region,android.graphics.Region.Op");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (p, flags) {
if (!android.graphics.Region.nativeWriteToParcel (this.mNativeRegion, p)) {
throw  new RuntimeException ();
}}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "equals", 
function (obj) {
if (obj == null || !(Clazz.instanceOf (obj, android.graphics.Region))) {
return false;
}var peer = obj;
return android.graphics.Region.nativeEquals (this.mNativeRegion, peer.mNativeRegion);
}, "~O");
Clazz.overrideMethod (c$, "finalize", 
function () {
android.graphics.Region.nativeDestructor (this.mNativeRegion);
});
Clazz.makeConstructor (c$, 
function (ni) {
if (ni == 0) {
throw  new RuntimeException ();
}this.mNativeRegion = ni;
}, "~N");
Clazz.defineMethod (c$, "ni", 
function () {
return this.mNativeRegion;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Region, "Op");
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (a) {
if ("DIFFERENCE".equals (a)) {
return android.graphics.Region.Op.DIFFERENCE;
} else if ("INTERSECT".equals (a)) {
return android.graphics.Region.Op.INTERSECT;
} else if ("UNION".equals (a)) {
return android.graphics.Region.Op.UNION;
} else if ("XOR".equals (a)) {
return android.graphics.Region.Op.XOR;
} else if ("REVERSE_DIFFERENCE".equals (a)) {
return android.graphics.Region.Op.REVERSE_DIFFERENCE;
} else if ("REPLACE".equals (a)) {
return android.graphics.Region.Op.REPLACE;
} else {
return null;
}}, "~S");
c$.values = Clazz.defineMethod (c$, "values", 
function () {
var a =  new Array (6);
a[0] = android.graphics.Region.Op.DIFFERENCE;
a[1] = android.graphics.Region.Op.INTERSECT;
a[2] = android.graphics.Region.Op.UNION;
a[3] = android.graphics.Region.Op.XOR;
a[4] = android.graphics.Region.Op.REVERSE_DIFFERENCE;
a[5] = android.graphics.Region.Op.REPLACE;
return a;
});
c$.DIFFERENCE = c$.prototype.DIFFERENCE =  new android.graphics.Region.Op (0);
c$.INTERSECT = c$.prototype.INTERSECT =  new android.graphics.Region.Op (1);
c$.UNION = c$.prototype.UNION =  new android.graphics.Region.Op (2);
c$.XOR = c$.prototype.XOR =  new android.graphics.Region.Op (3);
c$.REVERSE_DIFFERENCE = c$.prototype.REVERSE_DIFFERENCE =  new android.graphics.Region.Op (4);
c$.REPLACE = c$.prototype.REPLACE =  new android.graphics.Region.Op (5);
c$ = Clazz.p0p ();
});
