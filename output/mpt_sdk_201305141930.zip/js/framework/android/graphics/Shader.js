﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["java.lang.Enum"], "android.graphics.Shader", ["android.graphics.Matrix"], function () {
c$ = Clazz.decorateAsClass (function () {
this.native_instance = 0;
this.mLocalMatrix = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "Shader");
Clazz.defineMethod (c$, "getLocalMatrix", 
function (localM) {
if (this.mLocalMatrix != null) {
if (localM != null) {
localM.set (this.mLocalMatrix);
}return true;
} else {
if (localM != null) {
localM.reset ();
}return false;
}}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "setLocalMatrix", 
function (localM) {
if (localM == null || localM.isIdentity ()) {
this.mLocalMatrix = null;
} else {
if (this.mLocalMatrix == null) {
this.mLocalMatrix =  new android.graphics.Matrix ();
}this.mLocalMatrix.set (localM);
}}, "android.graphics.Matrix");
Clazz.overrideMethod (c$, "finalize", 
function () {
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Shader, "TileMode", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
Clazz.defineEnumConstant (c$, "CLAMP", 0, [0]);
Clazz.defineEnumConstant (c$, "REPEAT", 1, [1]);
Clazz.defineEnumConstant (c$, "MIRROR", 2, [2]);
c$ = Clazz.p0p ();
});
