﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["android.graphics.Shader"], "android.graphics.RadialGradient", ["android.graphics.PointF", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.m_center = null;
this.m_radius = 0;
this.m_colors = null;
this.m_positions = null;
this.m_tileMode = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "RadialGradient", android.graphics.Shader);
Clazz.makeConstructor (c$, 
function (x, y, radius, colors, positions, tile) {
Clazz.superConstructor (this, android.graphics.RadialGradient, []);
if (radius <= 0) {
throw  new IllegalArgumentException ("radius must be > 0");
}if (colors.length < 2) {
throw  new IllegalArgumentException ("needs >= 2 number of colors");
}if (positions != null && colors.length != positions.length) {
throw  new IllegalArgumentException ("color and position arrays must be of equal length");
}this.m_center =  new android.graphics.PointF (x, y);
this.m_radius = radius;
this.m_tileMode = tile;
this.m_colors =  Clazz.newArray (colors.length, 0);
for (var i = 0; i < colors.length; i++) {
this.m_colors[i] = colors[i];
}
if (positions != null) {
this.m_positions =  Clazz.newArray (positions.length, 0);
for (var i = 0; i < positions.length; i++) {
this.m_positions[i] = positions[i];
}
}}, "~N,~N,~N,~A,~A,android.graphics.Shader.TileMode");
Clazz.makeConstructor (c$, 
function (x, y, radius, color0, color1, tile) {
Clazz.superConstructor (this, android.graphics.RadialGradient, []);
if (radius <= 0) {
throw  new IllegalArgumentException ("radius must be > 0");
}this.m_center =  new android.graphics.PointF (x, y);
this.m_radius = radius;
this.m_tileMode = tile;
this.m_colors =  Clazz.newArray (2, 0);
this.m_colors[0] = color0;
this.m_colors[1] = color1;
}, "~N,~N,~N,~N,~N,android.graphics.Shader.TileMode");
});
