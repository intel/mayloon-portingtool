﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["android.graphics.ColorFilter"], "android.graphics.PorterDuffColorFilter", null, function () {
c$ = Clazz.declareType (android.graphics, "PorterDuffColorFilter", android.graphics.ColorFilter);
Clazz.makeConstructor (c$, 
function (srcColor, mode) {
Clazz.superConstructor (this, android.graphics.PorterDuffColorFilter, []);
}, "~N,android.graphics.PorterDuff.Mode");
});
