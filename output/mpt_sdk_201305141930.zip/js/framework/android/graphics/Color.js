﻿Clazz.declarePackage ("android.graphics");
Clazz.load (null, "android.graphics.Color", ["android.util.MathUtils", "java.lang.IllegalArgumentException", "$.Long", "$.RuntimeException", "$.StringBuilder", "java.util.HashMap", "$.Locale"], function () {
c$ = Clazz.declareType (android.graphics, "Color");
c$.alpha = Clazz.defineMethod (c$, "alpha", 
function (color) {
return color >>> 24;
}, "~N");
c$.red = Clazz.defineMethod (c$, "red", 
function (color) {
return (color >> 16) & 0xFF;
}, "~N");
c$.green = Clazz.defineMethod (c$, "green", 
function (color) {
return (color >> 8) & 0xFF;
}, "~N");
c$.blue = Clazz.defineMethod (c$, "blue", 
function (color) {
return color & 0xFF;
}, "~N");
c$.rgb = Clazz.defineMethod (c$, "rgb", 
function (red, green, blue) {
return (-16777216) | (red << 16) | (green << 8) | blue;
}, "~N,~N,~N");
c$.argb = Clazz.defineMethod (c$, "argb", 
function (alpha, red, green, blue) {
return (alpha << 24) | (red << 16) | (green << 8) | blue;
}, "~N,~N,~N,~N");
c$.hue = Clazz.defineMethod (c$, "hue", 
function (color) {
var r = (color >> 16) & 0xFF;
var g = (color >> 8) & 0xFF;
var b = color & 0xFF;
var V = Math.max (b, Math.max (r, g));
var temp = Math.min (b, Math.min (r, g));
var H;
if (V == temp) {
H = 0;
} else {
var vtemp = (V - temp);
var cr = (V - r) / vtemp;
var cg = (V - g) / vtemp;
var cb = (V - b) / vtemp;
if (r == V) {
H = cb - cg;
} else if (g == V) {
H = 2 + cr - cb;
} else {
H = 4 + cg - cr;
}H /= 6.;
if (H < 0) {
H++;
}}return H;
}, "~N");
c$.saturation = Clazz.defineMethod (c$, "saturation", 
function (color) {
var r = (color >> 16) & 0xFF;
var g = (color >> 8) & 0xFF;
var b = color & 0xFF;
var V = Math.max (b, Math.max (r, g));
var temp = Math.min (b, Math.min (r, g));
var S;
if (V == temp) {
S = 0;
} else {
S = (V - temp) / V;
}return S;
}, "~N");
c$.brightness = Clazz.defineMethod (c$, "brightness", 
function (color) {
var r = (color >> 16) & 0xFF;
var g = (color >> 8) & 0xFF;
var b = color & 0xFF;
var V = Math.max (b, Math.max (r, g));
return (V / 255.);
}, "~N");
c$.parseColor = Clazz.defineMethod (c$, "parseColor", 
function (colorString) {
if ((colorString.charAt (0)).charCodeAt (0) == ('#').charCodeAt (0)) {
var color = Long.parseLong (colorString.substring (1), 16);
if (colorString.length == 7) {
color |= 0x00000000ff000000;
} else if (colorString.length != 9) {
throw  new IllegalArgumentException ("Unknown color");
}return color;
} else {
var color = android.graphics.Color.sColorNameMap.get (colorString.toLowerCase (java.util.Locale.US));
if (color != null) {
return color;
}}throw  new IllegalArgumentException ("Unknown color");
}, "~S");
c$.toString = Clazz.defineMethod (c$, "toString", 
function (color) {
return "rgba(" + android.graphics.Color.red (color) + "," + android.graphics.Color.green (color) + "," + android.graphics.Color.blue (color) + "," + android.graphics.Color.alpha (color) + ")";
}, "~N");
c$.toString2 = Clazz.defineMethod (c$, "toString2", 
function (color) {
var sb =  new StringBuilder ("\"#");
var tmp = Integer.toHexString (android.graphics.Color.red (color));
if (tmp.length == 1) sb.append ("0" + tmp);
 else sb.append (tmp);
tmp = Integer.toHexString (android.graphics.Color.green (color));
if (tmp.length == 1) sb.append ("0" + tmp);
 else sb.append (tmp);
tmp = Integer.toHexString (android.graphics.Color.blue (color));
if (tmp.length == 1) sb.append ("0" + tmp);
 else sb.append (tmp);
sb.append ("\"");
return sb.toString ();
}, "~N");
c$.HSBtoColor = Clazz.defineMethod (c$, "HSBtoColor", 
function (hsb) {
return android.graphics.Color.HSBtoColor (hsb[0], hsb[1], hsb[2]);
}, "~A");
c$.HSBtoColor = Clazz.defineMethod (c$, "HSBtoColor", 
function (h, s, b) {
h = android.util.MathUtils.constrain (h, 0.0, 1.0);
s = android.util.MathUtils.constrain (s, 0.0, 1.0);
b = android.util.MathUtils.constrain (b, 0.0, 1.0);
var red = 0.0;
var green = 0.0;
var blue = 0.0;
var hf = (h - Math.round (h)) * 6.0;
var ihf = Math.round (hf);
var f = hf - ihf;
var pv = b * (1.0 - s);
var qv = b * (1.0 - s * f);
var tv = b * (1.0 - s * (1.0 - f));
switch (ihf) {
case 0:
red = b;
green = tv;
blue = pv;
break;
case 1:
red = qv;
green = b;
blue = pv;
break;
case 2:
red = pv;
green = b;
blue = tv;
break;
case 3:
red = pv;
green = qv;
blue = b;
break;
case 4:
red = tv;
green = pv;
blue = b;
break;
case 5:
red = b;
green = pv;
blue = qv;
break;
}
return 0xFF000000 | ((Math.round ((red * 255.0))) << 16) | ((Math.round ((green * 255.0))) << 8) | (Math.round ((blue * 255.0)));
}, "~N,~N,~N");
c$.RGBToHSV = Clazz.defineMethod (c$, "RGBToHSV", 
function (red, green, blue, hsv) {
if (hsv.length < 3) {
throw  new RuntimeException ("3 components required for hsv");
}android.graphics.Color.nativeRGBToHSV (red, green, blue, hsv);
}, "~N,~N,~N,~A");
c$.colorToHSV = Clazz.defineMethod (c$, "colorToHSV", 
function (color, hsv) {
android.graphics.Color.RGBToHSV ((color >> 16) & 0xFF, (color >> 8) & 0xFF, color & 0xFF, hsv);
}, "~N,~A");
c$.HSVToColor = Clazz.defineMethod (c$, "HSVToColor", 
function (hsv) {
return android.graphics.Color.HSVToColor (0xFF, hsv);
}, "~A");
c$.HSVToColor = Clazz.defineMethod (c$, "HSVToColor", 
function (alpha, hsv) {
if (hsv.length < 3) {
throw  new RuntimeException ("3 components required for hsv");
}return android.graphics.Color.nativeHSVToColor (alpha, hsv);
}, "~N,~A");
Clazz.defineStatics (c$,
"BLACK", 0xFF000000,
"DKGRAY", 0xFF444444,
"GRAY", 0xFF888888,
"LTGRAY", 0xFFCCCCCC,
"WHITE", 0xFFFFFFFF,
"RED", 0xFFFF0000,
"GREEN", 0xFF00FF00,
"BLUE", 0xFF0000FF,
"YELLOW", 0xFFFFFF00,
"CYAN", 0xFF00FFFF,
"MAGENTA", 0xFFFF00FF,
"TRANSPARENT", 0,
"sColorNameMap", null);
{
($t$ = android.graphics.Color.sColorNameMap =  new java.util.HashMap (), android.graphics.Color.prototype.sColorNameMap = android.graphics.Color.sColorNameMap, $t$);
android.graphics.Color.sColorNameMap.put ("black", new Integer (-16777216));
android.graphics.Color.sColorNameMap.put ("darkgray", new Integer (-12303292));
android.graphics.Color.sColorNameMap.put ("gray", new Integer (-7829368));
android.graphics.Color.sColorNameMap.put ("lightgray", new Integer (-3355444));
android.graphics.Color.sColorNameMap.put ("white", new Integer (-1));
android.graphics.Color.sColorNameMap.put ("red", new Integer (-65536));
android.graphics.Color.sColorNameMap.put ("green", new Integer (-16711936));
android.graphics.Color.sColorNameMap.put ("blue", new Integer (-16776961));
android.graphics.Color.sColorNameMap.put ("yellow", new Integer (-256));
android.graphics.Color.sColorNameMap.put ("cyan", new Integer (-16711681));
android.graphics.Color.sColorNameMap.put ("magenta", new Integer (-65281));
}});
