﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["java.lang.Enum"], "android.graphics.PorterDuff", null, function () {
c$ = Clazz.declareType (android.graphics, "PorterDuff");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.PorterDuff, "Mode", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
Clazz.defineEnumConstant (c$, "CLEAR", 0, [0]);
Clazz.defineEnumConstant (c$, "SRC", 1, [1]);
Clazz.defineEnumConstant (c$, "DST", 2, [2]);
Clazz.defineEnumConstant (c$, "SRC_OVER", 3, [3]);
Clazz.defineEnumConstant (c$, "DST_OVER", 4, [4]);
Clazz.defineEnumConstant (c$, "SRC_IN", 5, [5]);
Clazz.defineEnumConstant (c$, "DST_IN", 6, [6]);
Clazz.defineEnumConstant (c$, "SRC_OUT", 7, [7]);
Clazz.defineEnumConstant (c$, "DST_OUT", 8, [8]);
Clazz.defineEnumConstant (c$, "SRC_ATOP", 9, [9]);
Clazz.defineEnumConstant (c$, "DST_ATOP", 10, [10]);
Clazz.defineEnumConstant (c$, "XOR", 11, [11]);
Clazz.defineEnumConstant (c$, "DARKEN", 12, [12]);
Clazz.defineEnumConstant (c$, "LIGHTEN", 13, [13]);
Clazz.defineEnumConstant (c$, "MULTIPLY", 14, [14]);
Clazz.defineEnumConstant (c$, "SCREEN", 15, [15]);
c$ = Clazz.p0p ();
});
