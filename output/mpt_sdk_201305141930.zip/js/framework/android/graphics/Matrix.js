﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["java.lang.Enum"], "android.graphics.Matrix", ["android.util.MathUtils", "java.lang.ArrayIndexOutOfBoundsException", "$.IllegalArgumentException", "$.NullPointerException", "$.StringBuilder", "java.util.Arrays"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mSkMatrix = null;
Clazz.instantialize (this, arguments);
}, android.graphics, "Matrix");
Clazz.makeConstructor (c$, 
function () {
this.mSkMatrix = android.graphics.Matrix.native_create (null);
});
Clazz.makeConstructor (c$, 
function (src) {
this.mSkMatrix = android.graphics.Matrix.native_create (src.mSkMatrix);
}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "isIdentity", 
function () {
return this.mSkMatrix.isIdentity ();
});
Clazz.defineMethod (c$, "rectStaysRect", 
function () {
return this.mSkMatrix.rectStaysRect ();
});
Clazz.defineMethod (c$, "set", 
function (src) {
if (src == null) {
this.reset ();
} else {
this.mSkMatrix.fTypeMask = src.mSkMatrix.fTypeMask;
System.arraycopy (src.mSkMatrix.fMat, 0, this.mSkMatrix.fMat, 0, src.mSkMatrix.fMat.length);
}}, "android.graphics.Matrix");
Clazz.overrideMethod (c$, "equals", 
function (obj) {
return obj != null && Clazz.instanceOf (obj, android.graphics.Matrix) && java.util.Arrays.equals (this.mSkMatrix.fMat, (obj).mSkMatrix.fMat);
}, "~O");
Clazz.defineMethod (c$, "reset", 
function () {
this.mSkMatrix.reset ();
});
Clazz.defineMethod (c$, "setTranslate", 
function (dx, dy) {
this.mSkMatrix.setTranslate (dx, dy);
}, "~N,~N");
Clazz.defineMethod (c$, "setScale", 
function (sx, sy, px, py) {
this.mSkMatrix.setScale (sx, sy, px, py);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setScale", 
function (sx, sy) {
this.mSkMatrix.setScale (sx, sy);
}, "~N,~N");
Clazz.defineMethod (c$, "setRotate", 
function (degrees, px, py) {
this.mSkMatrix.setRotate (degrees, px, py);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "setRotate", 
function (degrees) {
this.mSkMatrix.setRotate (degrees);
}, "~N");
Clazz.defineMethod (c$, "setSinCos", 
function (sinValue, cosValue, px, py) {
this.mSkMatrix.setSinCos (sinValue, cosValue, px, py);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setSinCos", 
function (sinValue, cosValue) {
this.mSkMatrix.setSinCos (sinValue, cosValue);
}, "~N,~N");
Clazz.defineMethod (c$, "setSkew", 
function (kx, ky, px, py) {
this.mSkMatrix.setSkew (kx, ky, px, py);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setSkew", 
function (kx, ky) {
this.mSkMatrix.setSkew (kx, ky);
}, "~N,~N");
Clazz.defineMethod (c$, "setConcat", 
function (a, b) {
return this.mSkMatrix.setConcat (a.mSkMatrix, b.mSkMatrix);
}, "android.graphics.Matrix,android.graphics.Matrix");
Clazz.defineMethod (c$, "preTranslate", 
function (dx, dy) {
return this.mSkMatrix.preTranslate (dx, dy);
}, "~N,~N");
Clazz.defineMethod (c$, "preScale", 
function (sx, sy, px, py) {
return this.mSkMatrix.preScale (sx, sy, px, py);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "preScale", 
function (sx, sy) {
return this.mSkMatrix.preScale (sx, sy);
}, "~N,~N");
Clazz.defineMethod (c$, "preRotate", 
function (degrees, px, py) {
return this.mSkMatrix.preRotate (degrees, px, py);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "preRotate", 
function (degrees) {
return this.mSkMatrix.preRotate (degrees);
}, "~N");
Clazz.defineMethod (c$, "preSkew", 
function (kx, ky, px, py) {
return this.mSkMatrix.preSkew (kx, ky, px, py);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "preSkew", 
function (kx, ky) {
return this.mSkMatrix.preSkew (kx, ky);
}, "~N,~N");
Clazz.defineMethod (c$, "preConcat", 
function (other) {
return this.mSkMatrix.preConcat (other.mSkMatrix);
}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "postTranslate", 
function (dx, dy) {
return this.mSkMatrix.postTranslate (dx, dy);
}, "~N,~N");
Clazz.defineMethod (c$, "postScale", 
function (sx, sy, px, py) {
return this.mSkMatrix.postScale (sx, sy, px, py);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "postScale", 
function (sx, sy) {
return this.mSkMatrix.postScale (sx, sy);
}, "~N,~N");
Clazz.defineMethod (c$, "postRotate", 
function (degrees, px, py) {
return this.mSkMatrix.postRotate (degrees, px, py);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "postRotate", 
function (degrees) {
return this.mSkMatrix.postRotate (degrees);
}, "~N");
Clazz.defineMethod (c$, "postSkew", 
function (kx, ky, px, py) {
return this.mSkMatrix.postSkew (kx, ky, px, py);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "postSkew", 
function (kx, ky) {
return this.mSkMatrix.postSkew (kx, ky);
}, "~N,~N");
Clazz.defineMethod (c$, "postConcat", 
function (other) {
return this.mSkMatrix.postConcat (other.mSkMatrix);
}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "setRectToRect", 
function (src, dst, stf) {
if (dst == null || src == null) {
throw  new NullPointerException ();
}return this.mSkMatrix.setRectToRect (src, dst, stf.nativeInt);
}, "android.graphics.RectF,android.graphics.RectF,android.graphics.Matrix.ScaleToFit");
c$.checkPointArrays = Clazz.defineMethod (c$, "checkPointArrays", 
($fz = function (src, srcIndex, dst, dstIndex, pointCount) {
var srcStop = srcIndex + (pointCount << 1);
var dstStop = dstIndex + (pointCount << 1);
if ((pointCount | srcIndex | dstIndex | srcStop | dstStop) < 0 || srcStop > src.length || dstStop > dst.length) {
throw  new ArrayIndexOutOfBoundsException ();
}}, $fz.isPrivate = true, $fz), "~A,~N,~A,~N,~N");
Clazz.defineMethod (c$, "setPolyToPoly", 
function (src, srcIndex, dst, dstIndex, pointCount) {
if (pointCount > 4) {
throw  new IllegalArgumentException ();
}android.graphics.Matrix.checkPointArrays (src, srcIndex, dst, dstIndex, pointCount);
var tmpSrc = java.util.Arrays.copyOfRange (src, srcIndex, src.length - 1);
var tmpDst = java.util.Arrays.copyOfRange (dst, dstIndex, dst.length - 1);
var result = this.mSkMatrix.setPolyToPoly (tmpSrc, tmpDst, pointCount);
System.arraycopy (tmpSrc, 0, src, srcIndex, tmpSrc.length);
System.arraycopy (tmpDst, 0, dst, dstIndex, tmpDst.length);
return result;
}, "~A,~N,~A,~N,~N");
Clazz.defineMethod (c$, "invert", 
function (inverse) {
return this.mSkMatrix.invert (inverse.mSkMatrix);
}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "mapPoints", 
function (dst, dstIndex, src, srcIndex, pointCount) {
android.graphics.Matrix.checkPointArrays (src, srcIndex, dst, dstIndex, pointCount);
var tmpSrc = java.util.Arrays.copyOfRange (src, srcIndex, src.length - 1);
var tmpDst = java.util.Arrays.copyOfRange (dst, dstIndex, dst.length - 1);
this.mSkMatrix.mapPoints (tmpDst, tmpSrc, pointCount);
System.arraycopy (tmpSrc, 0, src, srcIndex, tmpSrc.length);
System.arraycopy (tmpDst, 0, dst, dstIndex, tmpDst.length);
}, "~A,~N,~A,~N,~N");
Clazz.defineMethod (c$, "mapVectors", 
function (dst, dstIndex, src, srcIndex, vectorCount) {
android.graphics.Matrix.checkPointArrays (src, srcIndex, dst, dstIndex, vectorCount);
var tmpSrc = java.util.Arrays.copyOfRange (src, srcIndex, src.length - 1);
var tmpDst = java.util.Arrays.copyOfRange (dst, dstIndex, dst.length - 1);
this.mSkMatrix.mapVectors (dst, src, vectorCount);
System.arraycopy (tmpSrc, 0, src, srcIndex, tmpSrc.length);
System.arraycopy (tmpDst, 0, dst, dstIndex, tmpDst.length);
}, "~A,~N,~A,~N,~N");
Clazz.defineMethod (c$, "mapPoints", 
function (dst, src) {
if (dst.length != src.length) {
throw  new ArrayIndexOutOfBoundsException ();
}this.mapPoints (dst, 0, src, 0, dst.length >> 1);
}, "~A,~A");
Clazz.defineMethod (c$, "mapVectors", 
function (dst, src) {
if (dst.length != src.length) {
throw  new ArrayIndexOutOfBoundsException ();
}this.mapVectors (dst, 0, src, 0, dst.length >> 1);
}, "~A,~A");
Clazz.defineMethod (c$, "mapPoints", 
function (pts) {
this.mapPoints (pts, 0, pts, 0, pts.length >> 1);
}, "~A");
Clazz.defineMethod (c$, "mapVectors", 
function (vecs) {
this.mapVectors (vecs, 0, vecs, 0, vecs.length >> 1);
}, "~A");
Clazz.defineMethod (c$, "mapRect", 
function (dst, src) {
if (dst == null || src == null) {
throw  new NullPointerException ();
}return this.mSkMatrix.mapRect (dst, src);
}, "android.graphics.RectF,android.graphics.RectF");
Clazz.defineMethod (c$, "mapRect", 
function (rect) {
return this.mapRect (rect, rect);
}, "android.graphics.RectF");
Clazz.defineMethod (c$, "mapRadius", 
function (radius) {
return this.mSkMatrix.mapRadius (radius);
}, "~N");
Clazz.defineMethod (c$, "getValues", 
function (values) {
if (values.length < 9) {
throw  new ArrayIndexOutOfBoundsException ();
}this.mSkMatrix.getValues (values);
}, "~A");
Clazz.defineMethod (c$, "setValues", 
function (values) {
if (values.length < 9) {
throw  new ArrayIndexOutOfBoundsException ();
}this.mSkMatrix.setValues (values);
}, "~A");
Clazz.defineMethod (c$, "getType", 
function () {
return this.mSkMatrix.getType ();
});
Clazz.overrideMethod (c$, "toString", 
function () {
var sb =  new StringBuilder (64);
sb.append ("Matrix{");
this.toShortString (sb);
sb.append ('}');
return sb.toString ();
});
Clazz.defineMethod (c$, "toShortString", 
function () {
var sb =  new StringBuilder (64);
this.toShortString (sb);
return sb.toString ();
});
Clazz.defineMethod (c$, "toShortString", 
function (sb) {
var values =  Clazz.newArray (9, 0);
this.getValues (values);
sb.append ('[');
sb.append (values[0]);
sb.append (", ");
sb.append (values[1]);
sb.append (", ");
sb.append (values[2]);
sb.append ("][");
sb.append (values[3]);
sb.append (", ");
sb.append (values[4]);
sb.append (", ");
sb.append (values[5]);
sb.append ("][");
sb.append (values[6]);
sb.append (", ");
sb.append (values[7]);
sb.append (", ");
sb.append (values[8]);
sb.append (']');
}, "StringBuilder");
Clazz.defineMethod (c$, "printShortString", 
function (pw) {
var values =  Clazz.newArray (9, 0);
this.getValues (values);
pw.print ('[');
pw.print (values[0]);
pw.print (", ");
pw.print (values[1]);
pw.print (", ");
pw.print (values[2]);
pw.print ("][");
pw.print (values[3]);
pw.print (", ");
pw.print (values[4]);
pw.print (", ");
pw.print (values[5]);
pw.print ("][");
pw.print (values[6]);
pw.print (", ");
pw.print (values[7]);
pw.print (", ");
pw.print (values[8]);
pw.print (']');
}, "java.io.PrintWriter");
Clazz.overrideMethod (c$, "finalize", 
function () {
android.graphics.Matrix.finalizer (this.mSkMatrix);
});
Clazz.defineMethod (c$, "ni", 
function () {
return this.mSkMatrix;
});
c$.native_create = Clazz.defineMethod (c$, "native_create", 
($fz = function (matrix) {
return  new android.graphics.Matrix.SkMatrix (matrix);
}, $fz.isPrivate = true, $fz), "android.graphics.Matrix.SkMatrix");
c$.finalizer = Clazz.defineMethod (c$, "finalizer", 
($fz = function (matrix) {
}, $fz.isPrivate = true, $fz), "android.graphics.Matrix.SkMatrix");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Matrix, "ScaleToFit", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
Clazz.defineEnumConstant (c$, "FILL", 0, [0]);
Clazz.defineEnumConstant (c$, "START", 1, [1]);
Clazz.defineEnumConstant (c$, "CENTER", 2, [2]);
Clazz.defineEnumConstant (c$, "END", 3, [3]);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.fMat = null;
this.fTypeMask = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.Matrix, "SkMatrix");
Clazz.prepareFields (c$, function () {
this.fMat =  Clazz.newArray (9, 0);
});
Clazz.defineMethod (c$, "getType", 
function () {
if ((this.fTypeMask & 128) != 0) {
this.fTypeMask = this.computeTypeMask ();
}return (this.fTypeMask & 0xF);
});
Clazz.defineMethod (c$, "computeTypeMask", 
function () {
var a = 0;
if ( new Boolean ( new Boolean (this.fMat[6] != 0 | this.fMat[7] != 0).valueOf () | (this.fMat[8] - 1.0) != 0).valueOf ()) {
a |= 8;
}if ( new Boolean (this.fMat[2] != 0 | this.fMat[5] != 0).valueOf ()) {
a |= 1;
}if ( new Boolean (this.fMat[1] != 0 | this.fMat[3] != 0).valueOf ()) {
a |= 4;
}if ( new Boolean ((this.fMat[0] - 1.0) != 0 | (this.fMat[4] - 1.0) != 0).valueOf ()) {
a |= 2;
}if ((a & 8) == 0) {
var b = this.fMat[0] != 0 ? 1 : 0;
var c = this.fMat[1] != 0 ? 1 : 0;
var d = this.fMat[3] != 0 ? 1 : 0;
var e = this.fMat[4] != 0 ? 1 : 0;
var f = (b | e) ^ 1;
var g = b & e;
var h = (c | d) ^ 1;
var i = c & d;
a |= ((f & i) | (g & h)) << 4;
}return a;
});
Clazz.makeConstructor (c$, 
function (a) {
if (a != null) {
this.fTypeMask = a.fTypeMask;
System.arraycopy (a.fMat, 0, this.fMat, 0, this.fMat.length);
} else {
this.reset ();
}}, "android.graphics.Matrix.SkMatrix");
Clazz.defineMethod (c$, "isIdentity", 
function () {
return this.getType () == 0;
});
Clazz.defineMethod (c$, "rectStaysRect", 
function () {
if ((this.fTypeMask & 128) != 0) {
this.fTypeMask = this.computeTypeMask ();
}return (this.fTypeMask & 16) != 0;
});
Clazz.defineMethod (c$, "reset", 
function () {
this.fMat[0] = this.fMat[4] = 1.0;
this.fMat[1] = this.fMat[3] = this.fMat[2] = this.fMat[5] = this.fMat[6] = this.fMat[7] = 0;
this.fMat[8] = 1.0;
this.setTypeMask (16);
});
Clazz.defineMethod (c$, "hasPerspective", 
function () {
return (this.getType () & 8) != 0;
});
Clazz.defineMethod (c$, "getScaleX", 
function () {
return this.fMat[0];
});
Clazz.defineMethod (c$, "getScaleY", 
function () {
return this.fMat[4];
});
Clazz.defineMethod (c$, "getSkewY", 
function () {
return this.fMat[3];
});
Clazz.defineMethod (c$, "getSkewX", 
function () {
return this.fMat[1];
});
Clazz.defineMethod (c$, "getTranslateX", 
function () {
return this.fMat[2];
});
Clazz.defineMethod (c$, "getTranslateY", 
function () {
return this.fMat[5];
});
Clazz.defineMethod (c$, "getPerspX", 
function () {
return this.fMat[6];
});
Clazz.defineMethod (c$, "getPerspY", 
function () {
return this.fMat[7];
});
Clazz.defineMethod (c$, "set", 
function (a, b) {
this.fMat[a] = b;
this.setTypeMask (128);
}, "~N,~N");
Clazz.defineMethod (c$, "get", 
function (a) {
return this.fMat[a];
}, "~N");
Clazz.defineMethod (c$, "setScaleX", 
function (a) {
this.set (0, a);
}, "~N");
Clazz.defineMethod (c$, "setScaleY", 
function (a) {
this.set (4, a);
}, "~N");
Clazz.defineMethod (c$, "setSkewY", 
function (a) {
this.set (3, a);
}, "~N");
Clazz.defineMethod (c$, "setSkewX", 
function (a) {
this.set (1, a);
}, "~N");
Clazz.defineMethod (c$, "setTranslateX", 
function (a) {
this.set (2, a);
}, "~N");
Clazz.defineMethod (c$, "setTranslateY", 
function (a) {
this.set (5, a);
}, "~N");
Clazz.defineMethod (c$, "setPerspX", 
function (a) {
this.set (6, a);
}, "~N");
Clazz.defineMethod (c$, "setPerspY", 
function (a) {
this.set (7, a);
}, "~N");
Clazz.defineMethod (c$, "setTranslate", 
function (a, b) {
if (a != 0 || b != 0) {
this.fMat[2] = a;
this.fMat[5] = b;
this.fMat[0] = this.fMat[4] = 1.0;
this.fMat[1] = this.fMat[3] = this.fMat[6] = this.fMat[7] = 0;
this.fMat[8] = 1.0;
this.setTypeMask (17);
} else {
this.reset ();
}}, "~N,~N");
Clazz.defineMethod (c$, "setScale", 
function (a, b, c, d) {
this.fMat[0] = a;
this.fMat[4] = b;
this.fMat[2] = c - a * c;
this.fMat[5] = d - b * d;
this.fMat[8] = 1.0;
this.fMat[1] = this.fMat[3] = this.fMat[6] = this.fMat[7] = 0;
this.setTypeMask (19);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setScale", 
function (a, b) {
this.fMat[0] = a;
this.fMat[4] = b;
this.fMat[8] = 1.0;
this.fMat[2] = this.fMat[5] = this.fMat[1] = this.fMat[3] = this.fMat[6] = this.fMat[7] = 0;
this.setTypeMask (18);
}, "~N,~N");
Clazz.defineMethod (c$, "setRotate", 
function (a, b, c) {
var d;
var e;
var f = android.util.MathUtils.radians (a);
d = Math.sin (f);
e = Math.cos (f);
this.setSinCos (d, e, b, c);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "setRotate", 
function (a) {
var b;
var c;
var d = android.util.MathUtils.radians (a);
b = Math.sin (d);
c = Math.cos (d);
this.setSinCos (b, c);
}, "~N");
c$.rowcol3 = Clazz.defineMethod (c$, "rowcol3", 
($fz = function (a, b, c, d) {
return a[b + 0] * c[d + 0] + a[b + 1] * c[d + 3] + a[b + 2] * c[d + 6];
}, $fz.isPrivate = true, $fz), "~A,~N,~A,~N");
c$.normalize_perspective = Clazz.defineMethod (c$, "normalize_perspective", 
($fz = function (a) {
if (Math.abs (a[8]) > 1.0) {
for (var b = 0; b < 9; b++) {
a[b] = 0.5 * a[b];
}
}}, $fz.isPrivate = true, $fz), "~A");
Clazz.defineMethod (c$, "setConcat", 
function (a, b) {
var c = a.getType ();
var d = b.getType ();
if (0 == c) {
this.fTypeMask = b.fTypeMask;
System.arraycopy (b.fMat, 0, this.fMat, 0, this.fMat.length);
} else if (0 == d) {
this.fTypeMask = a.fTypeMask;
System.arraycopy (a.fMat, 0, this.fMat, 0, this.fMat.length);
} else {
var e =  new android.graphics.Matrix.SkMatrix (null);
if (((c | d) & 8) != 0) {
e.fMat[0] = android.graphics.Matrix.SkMatrix.rowcol3 (a.fMat, 0, b.fMat, 0);
e.fMat[1] = android.graphics.Matrix.SkMatrix.rowcol3 (a.fMat, 0, b.fMat, 1);
e.fMat[2] = android.graphics.Matrix.SkMatrix.rowcol3 (a.fMat, 0, b.fMat, 2);
e.fMat[3] = android.graphics.Matrix.SkMatrix.rowcol3 (a.fMat, 3, b.fMat, 0);
e.fMat[4] = android.graphics.Matrix.SkMatrix.rowcol3 (a.fMat, 3, b.fMat, 1);
e.fMat[5] = android.graphics.Matrix.SkMatrix.rowcol3 (a.fMat, 3, b.fMat, 2);
e.fMat[6] = android.graphics.Matrix.SkMatrix.rowcol3 (a.fMat, 6, b.fMat, 0);
e.fMat[7] = android.graphics.Matrix.SkMatrix.rowcol3 (a.fMat, 6, b.fMat, 1);
e.fMat[8] = android.graphics.Matrix.SkMatrix.rowcol3 (a.fMat, 6, b.fMat, 2);
android.graphics.Matrix.SkMatrix.normalize_perspective (e.fMat);
} else {
e.fMat[0] = a.fMat[0] * b.fMat[0] + a.fMat[1] * b.fMat[3];
e.fMat[1] = a.fMat[0] * b.fMat[1] + a.fMat[1] * b.fMat[4];
e.fMat[2] = a.fMat[0] * b.fMat[2] + a.fMat[1] * b.fMat[5];
e.fMat[2] = e.fMat[2] + a.fMat[2];
e.fMat[3] = a.fMat[3] * b.fMat[0] + a.fMat[4] * b.fMat[3];
e.fMat[4] = a.fMat[3] * b.fMat[1] + a.fMat[4] * b.fMat[4];
e.fMat[5] = a.fMat[3] * b.fMat[2] + a.fMat[4] * b.fMat[5];
e.fMat[5] = e.fMat[5] + a.fMat[5];
e.fMat[6] = e.fMat[7] = 0;
e.fMat[8] = 1.0;
}this.fTypeMask = e.fTypeMask;
System.arraycopy (e.fMat, 0, this.fMat, 0, this.fMat.length);
}this.setTypeMask (128);
return true;
}, "android.graphics.Matrix.SkMatrix,android.graphics.Matrix.SkMatrix");
Clazz.defineMethod (c$, "setTypeMask", 
function (a) {
this.fTypeMask = a;
}, "~N");
Clazz.defineMethod (c$, "clearTypeMask", 
function (a) {
this.fTypeMask &= ~a;
}, "~N");
Clazz.defineMethod (c$, "setSinCos", 
function (a, b, c, d) {
sinV = sinV.toFixed(15);
cosV = cosV.toFixed(15);
var e = 1.0 - b;
this.fMat[0] = b;
this.fMat[1] = -a;
this.fMat[2] = a * d + e * c;
this.fMat[3] = a;
this.fMat[4] = b;
this.fMat[5] = -a * c + e * d;
this.fMat[6] = this.fMat[7] = 0;
this.fMat[8] = 1.0;
this.setTypeMask (128);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setSinCos", 
function (a, b) {
sinV = sinV.toFixed(15);
cosV = cosV.toFixed(15);
this.fMat[0] = b;
this.fMat[1] = -a;
this.fMat[2] = 0;
this.fMat[3] = a;
this.fMat[4] = b;
this.fMat[5] = 0;
this.fMat[6] = this.fMat[7] = 0;
this.fMat[8] = 1.0;
this.setTypeMask (128);
}, "~N,~N");
Clazz.defineMethod (c$, "invert", 
function (a) {
var b = this.hasPerspective ();
var c = android.graphics.Matrix.SkMatrix.sk_inv_determinant (this.fMat, b);
if (c == 0) {
return false;
}if (a != null) {
var d =  new android.graphics.Matrix.SkMatrix (null);
if (a === this) {
a.fTypeMask = this.fTypeMask;
System.arraycopy (this.fMat, 0, a.fMat, 0, this.fMat.length);
}if (b) {
d.fMat[0] = ((this.fMat[4] * this.fMat[8] - this.fMat[5] * this.fMat[7]) * c);
d.fMat[1] = ((this.fMat[2] * this.fMat[7] - this.fMat[1] * this.fMat[8]) * c);
d.fMat[2] = ((this.fMat[1] * this.fMat[5] - this.fMat[2] * this.fMat[4]) * c);
d.fMat[3] = ((this.fMat[5] * this.fMat[6] - this.fMat[3] * this.fMat[8]) * c);
d.fMat[4] = ((this.fMat[0] * this.fMat[8] - this.fMat[2] * this.fMat[6]) * c);
d.fMat[5] = ((this.fMat[2] * this.fMat[3] - this.fMat[0] * this.fMat[5]) * c);
d.fMat[6] = ((this.fMat[3] * this.fMat[7] - this.fMat[4] * this.fMat[6]) * c);
d.fMat[7] = ((this.fMat[1] * this.fMat[6] - this.fMat[0] * this.fMat[7]) * c);
d.fMat[8] = ((this.fMat[0] * this.fMat[4] - this.fMat[1] * this.fMat[3]) * c);
} else {
d.fMat[6] = 0;
d.fMat[7] = 0;
d.fMat[8] = 1.0;
}System.arraycopy (d.fMat, 0, a.fMat, 0, d.fMat.length);
a.setTypeMask (128);
}return true;
}, "android.graphics.Matrix.SkMatrix");
Clazz.defineMethod (c$, "setRectToRect", 
function (a, b, c) {
if (a.isEmpty ()) {
this.reset ();
return false;
}if (b.isEmpty ()) {
java.util.Arrays.fill (this.fMat, 0);
this.setTypeMask (18);
} else {
var d;
var e = b.width () / a.width ();
var f;
var g = b.height () / a.height ();
var h = false;
if (c != 0) {
if (e > g) {
h = true;
e = g;
} else {
g = e;
}}d = b.left - a.left * e;
f = b.top - a.top * g;
if (c == 2 || c == 3) {
var i;
if (h) {
i = b.width () - a.width () * g;
} else {
i = b.height () - a.height () * g;
}if (c == 2) {
i = i * 0.5;
}if (h) {
d += i;
} else {
f += i;
}}this.fMat[0] = e;
this.fMat[4] = g;
this.fMat[2] = d;
this.fMat[5] = f;
this.fMat[1] = this.fMat[3] = this.fMat[6] = this.fMat[7] = 0;
this.setTypeMask (19);
}this.fMat[8] = 1.0;
return true;
}, "android.graphics.RectF,android.graphics.RectF,~N");
Clazz.defineMethod (c$, "setSkew", 
function (a, b, c, d) {
this.fMat[0] = 1.0;
this.fMat[1] = a;
this.fMat[2] = -a * d;
this.fMat[3] = b;
this.fMat[4] = 1.0;
this.fMat[5] = -b * c;
this.fMat[6] = this.fMat[7] = 0;
this.fMat[8] = 1.0;
this.setTypeMask (128);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setSkew", 
function (a, b) {
this.fMat[0] = 1.0;
this.fMat[1] = a;
this.fMat[2] = 0;
this.fMat[3] = b;
this.fMat[4] = 1.0;
this.fMat[5] = 0;
this.fMat[6] = this.fMat[7] = 0;
this.fMat[8] = 1.0;
this.setTypeMask (128);
}, "~N,~N");
Clazz.defineMethod (c$, "preTranslate", 
function (a, b) {
if (this.hasPerspective ()) {
var c =  new android.graphics.Matrix.SkMatrix (null);
c.setTranslate (a, b);
return this.preConcat (c);
}if (a != 0 || b != 0) {
this.fMat[2] += this.fMat[0] * a + this.fMat[1] * b;
this.fMat[5] += this.fMat[3] * a + this.fMat[4] * b;
this.setTypeMask (128);
}return true;
}, "~N,~N");
Clazz.defineMethod (c$, "preScale", 
function (a, b, c, d) {
var e =  new android.graphics.Matrix.SkMatrix (null);
e.setScale (a, b, c, d);
return this.preConcat (e);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "preScale", 
function (a, b) {
var c =  new android.graphics.Matrix.SkMatrix (null);
c.setScale (a, b);
return this.preConcat (c);
}, "~N,~N");
Clazz.defineMethod (c$, "preRotate", 
function (a, b, c) {
var d =  new android.graphics.Matrix.SkMatrix (null);
d.setRotate (a, b, c);
return this.preConcat (d);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "preRotate", 
function (a) {
var b =  new android.graphics.Matrix.SkMatrix (null);
b.setRotate (a);
return this.preConcat (b);
}, "~N");
Clazz.defineMethod (c$, "preSkew", 
function (a, b, c, d) {
var e =  new android.graphics.Matrix.SkMatrix (null);
e.setSkew (a, b, c, d);
return this.preConcat (e);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "preSkew", 
function (a, b) {
var c =  new android.graphics.Matrix.SkMatrix (null);
c.setSkew (a, b);
return this.preConcat (c);
}, "~N,~N");
Clazz.defineMethod (c$, "preConcat", 
function (a) {
return a.isIdentity () || this.setConcat (this, a);
}, "android.graphics.Matrix.SkMatrix");
Clazz.defineMethod (c$, "postConcat", 
function (a) {
return a.isIdentity () || this.setConcat (a, this);
}, "android.graphics.Matrix.SkMatrix");
Clazz.defineMethod (c$, "postTranslate", 
function (a, b) {
if (this.hasPerspective ()) {
var c =  new android.graphics.Matrix.SkMatrix (null);
c.setTranslate (a, b);
return this.postConcat (c);
}if (a != 0 || b != 0) {
this.fMat[2] += a;
this.fMat[5] += b;
this.setTypeMask (128);
}return true;
}, "~N,~N");
Clazz.defineMethod (c$, "postScale", 
function (a, b, c, d) {
var e =  new android.graphics.Matrix.SkMatrix (null);
e.setScale (a, b, c, d);
return this.postConcat (e);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "postScale", 
function (a, b) {
var c =  new android.graphics.Matrix.SkMatrix (null);
c.setScale (a, b);
return this.postConcat (c);
}, "~N,~N");
Clazz.defineMethod (c$, "postRotate", 
function (a, b, c) {
var d =  new android.graphics.Matrix.SkMatrix (null);
d.setRotate (a, b, c);
return this.postConcat (d);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "postRotate", 
function (a) {
var b =  new android.graphics.Matrix.SkMatrix (null);
b.setRotate (a);
return this.postConcat (b);
}, "~N");
Clazz.defineMethod (c$, "postSkew", 
function (a, b, c, d) {
var e =  new android.graphics.Matrix.SkMatrix (null);
e.setSkew (a, b, c, d);
return this.postConcat (e);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "postSkew", 
function (a, b) {
var c =  new android.graphics.Matrix.SkMatrix (null);
c.setSkew (a, b);
return this.postConcat (c);
}, "~N,~N");
c$.sk_inv_determinant = Clazz.defineMethod (c$, "sk_inv_determinant", 
function (a, b) {
var c;
if (b) {
c = a[0] * (a[4] * a[8] - a[5] * a[7]) + a[1] * (a[5] * a[6] - a[3] * a[8]) + a[2] * (a[3] * a[7] - a[4] * a[6]);
} else {
c = a[0] * a[4] - a[1] * a[3];
}if (android.graphics.Matrix.SkMatrix.SkScalarNearlyZero (c, 1.4551915E-11)) {
return 0;
}return 1.0 / c;
}, "~A,~B");
c$.polyToPoint = Clazz.defineMethod (c$, "polyToPoint", 
function (a, b, c) {
var d = 1;
var e = 1;
var f =  Clazz.newArray (2, 0);
var g =  Clazz.newArray (2, 0);
if (c > 1) {
f[0] = b[2] - b[0];
f[1] = b[3] - b[1];
e = Math.sqrt (f[0] * f[0] + f[1] * f[1]);
if (e * e == 0) {
return false;
}switch (c) {
case 2:
break;
case 3:
g[0] = b[1] - b[5];
g[1] = b[4] - b[0];
d = (f[0] * g[1] + f[1] * g[1]) / e;
break;
default:
g[0] = b[1] - b[7];
g[1] = b[6] - b[0];
d = (f[0] * g[1] + f[1] * g[1]) / e;
break;
}
}a[0] = d;
a[1] = e;
return true;
}, "~A,~A,~N");
c$.SkScalarNearlyZero = Clazz.defineMethod (c$, "SkScalarNearlyZero", 
function (a, b) {
return Math.abs (a) < b;
}, "~N,~N");
c$.Poly2Proc = Clazz.defineMethod (c$, "Poly2Proc", 
function (a, b, c) {
var d = 1 / c[1];
b.fMat[0] = (a[3] - a[1]) * d;
b.fMat[3] = (a[0] - a[2]) * d;
b.fMat[6] = 0;
b.fMat[1] = (a[2] - a[0]) * d;
b.fMat[4] = (a[3] - a[1]) * d;
b.fMat[7] = 0;
b.fMat[2] = a[0];
b.fMat[5] = a[1];
b.fMat[8] = 1;
b.setTypeMask (128);
return true;
}, "~A,android.graphics.Matrix.SkMatrix,~A");
c$.Poly3Proc = Clazz.defineMethod (c$, "Poly3Proc", 
function (a, b, c) {
var d = 1 / c[0];
b.fMat[0] = (a[4] - a[0]) * d;
b.fMat[3] = (a[5] - a[1]) * d;
b.fMat[6] = 0;
d = 1 / c[1];
b.fMat[1] = (a[2] - a[0]) * d;
b.fMat[4] = (a[3] - a[1]) * d;
b.fMat[7] = 0;
b.fMat[2] = a[0];
b.fMat[5] = a[1];
b.fMat[8] = 1;
b.setTypeMask (128);
return true;
}, "~A,android.graphics.Matrix.SkMatrix,~A");
c$.Poly4Proc = Clazz.defineMethod (c$, "Poly4Proc", 
function (a, b, c) {
var d;
var e;
var f;
var g;
var h;
var i;
var j;
var k;
f = a[4] - a[0];
g = a[5] - a[1];
h = a[4] - a[2];
i = a[5] - a[3];
j = a[4] - a[6];
k = a[5] - a[7];
if (j > 0 ? k > 0 ? j > k : j > -k : k > 0 ? -j > k : j < k) {
var l = h * k / j - i;
if (l * l == 0) {
return false;
}d = ((f - h) * k / j - g + i) / l;
} else {
var l = h - i * j / k;
if (l * l == 0) {
return false;
}d = (f - h - ((g - i) * j / k)) / l;
}if (h > 0 ? i > 0 ? h > i : h > -i : i > 0 ? -h > i : h < i) {
var l = k - (j * i / h);
if (l * l == 0) {
return false;
}e = (g - k - (f - j) * i / h) / l;
} else {
var l = k * h / i - j;
if (l * l == 0) {
return false;
}e = ((g - k) * h / i - f + j) / l;
}var l = 1 / c[0];
b.fMat[0] = (e * a[6] + a[6] - a[0]) * l;
b.fMat[3] = (e * a[7] + a[7] - a[1]) * l;
b.fMat[6] = e * l;
l = 1 / c[1];
b.fMat[1] = (d * a[2] + a[2] - a[0]) * l;
b.fMat[4] = (d * a[3] + a[3] - a[1]) * l;
b.fMat[7] = d * l;
b.fMat[2] = a[0];
b.fMat[5] = a[1];
b.fMat[8] = 1;
b.setTypeMask (128);
return true;
}, "~A,android.graphics.Matrix.SkMatrix,~A");
Clazz.defineMethod (c$, "setPolyToPoly", 
function (a, b, c) {
if (c > 4) {
return false;
}if (0 == c) {
this.reset ();
return true;
}if (1 == c) {
this.setTranslate (b[0] - a[0], b[1] - a[1]);
return true;
}var d =  Clazz.newArray (2, 0);
if (!android.graphics.Matrix.SkMatrix.polyToPoint (d, a, c) || android.graphics.Matrix.SkMatrix.SkScalarNearlyZero (d[0], 2.4414062E-4) || android.graphics.Matrix.SkMatrix.SkScalarNearlyZero (d[1], 2.4414062E-4)) {
return false;
}var e =  new android.graphics.Matrix.SkMatrix (null);
var f =  new android.graphics.Matrix.SkMatrix (null);
e.setTypeMask (128);
var g = true;
switch (c - 2) {
case 0:
g = android.graphics.Matrix.SkMatrix.Poly2Proc (a, e, d);
break;
case 1:
g = android.graphics.Matrix.SkMatrix.Poly3Proc (a, e, d);
break;
case 2:
g = android.graphics.Matrix.SkMatrix.Poly4Proc (a, e, d);
break;
}
if (!g) return false;
if (!e.invert (f)) {
return false;
}switch (c - 2) {
case 0:
g = android.graphics.Matrix.SkMatrix.Poly2Proc (b, e, d);
break;
case 1:
g = android.graphics.Matrix.SkMatrix.Poly3Proc (b, e, d);
break;
case 2:
g = android.graphics.Matrix.SkMatrix.Poly4Proc (b, e, d);
break;
}
if (!f.setConcat (e, f)) {
return false;
}this.fTypeMask = f.fTypeMask;
System.arraycopy (f.fMat, 0, this.fMat, 0, this.fMat.length);
return true;
}, "~A,~A,~N");
Clazz.defineMethod (c$, "Identity_pts", 
function (a, b, c, d) {
if (b !== c && d > 0) {
System.arraycopy (c, 0, b, 0, d * 2);
}}, "android.graphics.Matrix.SkMatrix,~A,~A,~N");
Clazz.defineMethod (c$, "Trans_pts", 
function (a, b, c, d) {
if (d > 0) {
var e = a.fMat[2];
var f = a.fMat[5];
var g = 0;
do {
b[g + 1] = c[g + 1] + f;
b[g + 0] = c[g + 0] + e;
g += 2;
} while (--d != 0);
}}, "android.graphics.Matrix.SkMatrix,~A,~A,~N");
Clazz.defineMethod (c$, "Scale_pts", 
function (a, b, c, d) {
if (d > 0) {
var e = a.fMat[0];
var f = a.fMat[4];
var g = 0;
do {
b[g + 1] = c[g + 1] * f;
b[g + 0] = c[g + 0] * e;
g += 2;
} while (--d != 0);
}}, "android.graphics.Matrix.SkMatrix,~A,~A,~N");
Clazz.defineMethod (c$, "ScaleTrans_pts", 
function (a, b, c, d) {
if (d > 0) {
var e = a.fMat[0];
var f = a.fMat[4];
var g = a.fMat[2];
var h = a.fMat[5];
var i = 0;
do {
b[i + 1] = c[i + 1] * f + h;
b[i + 0] = c[i + 0] * e + g;
i += 2;
} while (--d != 0);
}}, "android.graphics.Matrix.SkMatrix,~A,~A,~N");
Clazz.defineMethod (c$, "Rot_pts", 
function (a, b, c, d) {
if (d > 0) {
var e = a.fMat[0];
var f = a.fMat[4];
var g = a.fMat[1];
var h = a.fMat[3];
var i = 0;
do {
var j = c[i + 1];
var k = c[i + 0];
b[i + 1] = k * h + j * f;
b[i + 0] = k * e + j * g;
i += 2;
} while (--d != 0);
}}, "android.graphics.Matrix.SkMatrix,~A,~A,~N");
Clazz.defineMethod (c$, "RotTrans_pts", 
function (a, b, c, d) {
if (d > 0) {
var e = a.fMat[0];
var f = a.fMat[4];
var g = a.fMat[1];
var h = a.fMat[3];
var i = a.fMat[2];
var j = a.fMat[5];
var k = 0;
do {
var l = c[k + 1];
var m = c[k + 0];
b[k + 1] = m * h + l * f + j;
b[k + 0] = m * e + l * g + i;
k += 2;
} while (--d != 0);
}}, "android.graphics.Matrix.SkMatrix,~A,~A,~N");
Clazz.defineMethod (c$, "Persp_pts", 
function (a, b, c, d) {
if (d > 0) {
var e = 0;
do {
var f = c[e + 1];
var g = c[e + 0];
var h = g * a.fMat[0] + f * a.fMat[1] + a.fMat[2];
var i = g * a.fMat[3] + f * a.fMat[4] + a.fMat[5];
var j = g * a.fMat[6] + f * a.fMat[7] + a.fMat[8];
if (j != 0) {
j = 1.0 / j;
}b[e + 1] = i * j;
b[e + 0] = h * j;
e += 2;
} while (--d != 0);
}}, "android.graphics.Matrix.SkMatrix,~A,~A,~N");
Clazz.defineMethod (c$, "mapPoints", 
function (a, b, c) {
switch (this.getType () & 31) {
case 0:
this.Identity_pts (this, a, b, c);
break;
case 1:
this.Trans_pts (this, a, b, c);
break;
case 2:
this.Scale_pts (this, a, b, c);
break;
case 3:
this.ScaleTrans_pts (this, a, b, c);
break;
case 4:
this.Rot_pts (this, a, b, c);
break;
case 5:
this.RotTrans_pts (this, a, b, c);
break;
case 6:
this.RotTrans_pts (this, a, b, c);
break;
case 7:
this.RotTrans_pts (this, a, b, c);
break;
case 8:
case 9:
case 10:
case 11:
case 12:
case 13:
case 14:
case 15:
this.Persp_pts (this, a, b, c);
break;
}
}, "~A,~A,~N");
Clazz.defineMethod (c$, "Identity_xy", 
function (a, b, c, d) {
d[0] = b;
d[1] = c;
}, "android.graphics.Matrix.SkMatrix,~N,~N,~A");
Clazz.defineMethod (c$, "Trans_xy", 
function (a, b, c, d) {
d[0] = b + a.fMat[2];
d[1] = c + a.fMat[5];
}, "android.graphics.Matrix.SkMatrix,~N,~N,~A");
Clazz.defineMethod (c$, "Scale_xy", 
function (a, b, c, d) {
d[0] = b * a.fMat[0];
d[1] = c * a.fMat[4];
}, "android.graphics.Matrix.SkMatrix,~N,~N,~A");
Clazz.defineMethod (c$, "ScaleTrans_xy", 
function (a, b, c, d) {
d[0] = b * a.fMat[0] + a.fMat[2];
d[1] = c * a.fMat[4] + a.fMat[5];
}, "android.graphics.Matrix.SkMatrix,~N,~N,~A");
Clazz.defineMethod (c$, "Rot_xy", 
function (a, b, c, d) {
d[0] = b * a.fMat[0] + c * a.fMat[1] + a.fMat[2];
d[1] = b * a.fMat[3] + c * a.fMat[4] + a.fMat[5];
}, "android.graphics.Matrix.SkMatrix,~N,~N,~A");
Clazz.defineMethod (c$, "RotTrans_xy", 
function (a, b, c, d) {
d[0] = b * a.fMat[0] + c * a.fMat[1] + a.fMat[2];
d[1] = b * a.fMat[3] + c * a.fMat[4] + a.fMat[5];
}, "android.graphics.Matrix.SkMatrix,~N,~N,~A");
Clazz.defineMethod (c$, "Persp_xy", 
function (a, b, c, d) {
var e = b * a.fMat[0] + c * a.fMat[1] + a.fMat[2];
var f = b * a.fMat[3] + c * a.fMat[4] + a.fMat[5];
var g = b * a.fMat[6] + c * a.fMat[7] + a.fMat[8];
if (g != 0) {
g = 1.0 / g;
}d[0] = e * g;
d[1] = f * g;
}, "android.graphics.Matrix.SkMatrix,~N,~N,~A");
Clazz.defineMethod (c$, "mapXY", 
function (a, b, c, d, e) {
switch (a & 31) {
case 0:
this.Identity_xy (b, c, d, e);
break;
case 1:
this.Trans_xy (b, c, d, e);
break;
case 2:
this.Scale_xy (b, c, d, e);
break;
case 3:
this.ScaleTrans_xy (b, c, d, e);
break;
case 4:
this.Rot_xy (b, c, d, e);
break;
case 5:
this.RotTrans_xy (b, c, d, e);
break;
case 6:
this.Rot_xy (b, c, d, e);
break;
case 7:
this.RotTrans_xy (b, c, d, e);
break;
case 8:
case 9:
case 10:
case 11:
case 12:
case 13:
case 14:
case 15:
this.Persp_xy (b, c, d, e);
break;
}
}, "~N,android.graphics.Matrix.SkMatrix,~N,~N,~A");
Clazz.defineMethod (c$, "mapVectors", 
function (a, b, c) {
if ((this.fTypeMask & 8) != 0) {
var d =  Clazz.newArray (2, 0);
this.mapXY (this.fTypeMask, this, 0, 0, d);
var e = 0;
for (var f = 0; f < c; f++) {
var g =  Clazz.newArray (2, 0);
this.mapXY (this.fTypeMask, this, b[e + 0], b[e + 1], g);
a[e + 0] = g[0] - d[0];
a[e + 1] = g[1] - d[1];
e += 2;
}
} else {
var d =  new android.graphics.Matrix.SkMatrix (null);
d.fTypeMask = this.fTypeMask;
System.arraycopy (this.fMat, 0, d.fMat, 0, this.fMat.length);
d.fMat[2] = d.fMat[5] = 0;
d.clearTypeMask (1);
d.mapPoints (a, b, c);
}}, "~A,~A,~N");
Clazz.defineMethod (c$, "mapRect", 
function (a, b) {
if (this.rectStaysRect ()) {
var c =  Clazz.newArray (4, 0);
var d =  Clazz.newArray (4, 0);
c[0] = b.left;
c[1] = b.top;
c[2] = b.right;
c[3] = b.bottom;
this.mapPoints (d, c, 2);
a.left = Math.round (d[0]);
a.top = Math.round (d[1]);
a.right = Math.round (d[2]);
a.bottom = Math.round (d[3]);
a.sort ();
return true;
} else {
var c =  Clazz.newArray (8, 0);
c[0] = b.left;
c[1] = b.top;
c[2] = b.right;
c[3] = b.top;
c[4] = b.right;
c[5] = b.bottom;
c[6] = b.left;
c[7] = b.bottom;
this.mapPoints (c, c, 4);
var d;
var e;
var f;
var g;
d = f = c[0];
e = g = c[1];
for (var h = 2; h < 8; h += 2) {
var i = c[h + 0];
var j = c[h + 1];
if (i < d) d = i;
 else if (i > f) f = i;
if (j < e) e = j;
 else if (j > g) g = j;
}
a.set (Math.round (d), Math.round (e), Math.round (f), Math.round (g));
return false;
}}, "android.graphics.RectF,android.graphics.RectF");
Clazz.defineMethod (c$, "mapRadius", 
function (a) {
var b =  Clazz.newArray (4, 0);
b[0] = a;
b[1] = 0;
b[2] = 0;
b[3] = a;
this.mapVectors (b, b, 2);
var c = Math.sqrt (b[0] * b[0] + b[1] * b[1]);
var d = Math.sqrt (b[2] * b[2] + b[3] * b[3]);
if (a == 3.4028235E38) {
return Infinity;
} else if (a == 1.4E-45) {
return 0;
}return Math.sqrt (c * d);
}, "~N");
Clazz.defineMethod (c$, "setValues", 
function (a) {
for (var b = 0; b < 9; b++) {
this.set (b, a[b]);
}
}, "~A");
Clazz.defineMethod (c$, "getValues", 
function (a) {
for (var b = 0; b < 9; b++) {
a[b] = this.get (b);
}
}, "~A");
Clazz.defineStatics (c$,
"kIdentity_Mask", 0,
"kTranslate_Mask", 0x01,
"kScale_Mask", 0x02,
"kAffine_Mask", 0x04,
"kPerspective_Mask", 0x08,
"kRectStaysRect_Mask", 0x10,
"kUnknown_Mask", 0x80,
"kAllMasks", 31,
"kMScaleX", 0,
"kMSkewX", 1,
"kMTransX", 2,
"kMSkewY", 3,
"kMScaleY", 4,
"kMTransY", 5,
"kMPersp0", 6,
"kMPersp1", 7,
"kMPersp2", 8,
"SK_Scalar1", 1.0,
"kMatrix22Elem", 1.0,
"tolerance", 2.4414062E-4,
"kPersp1Int", 1.0,
"kScalar1Int", 1.0,
"kTranslate_Shift", 0,
"kScale_Shift", 1,
"kAffine_Shift", 2,
"kPerspective_Shift", 3,
"kRectStaysRect_Shift", 4,
"kFill_ScaleToFit", 0,
"kStart_ScaleToFit", 1,
"kCenter_ScaleToFit", 2,
"kEnd_ScaleToFit", 3);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"MSCALE_X", 0,
"MSKEW_X", 1,
"MTRANS_X", 2,
"MSKEW_Y", 3,
"MSCALE_Y", 4,
"MTRANS_Y", 5,
"MPERSP_0", 6,
"MPERSP_1", 7,
"MPERSP_2", 8);
});
