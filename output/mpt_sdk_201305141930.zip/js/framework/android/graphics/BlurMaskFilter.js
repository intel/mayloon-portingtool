﻿Clazz.declarePackage ("android.graphics");
Clazz.load (["android.graphics.MaskFilter", "java.lang.Enum"], "android.graphics.BlurMaskFilter", null, function () {
c$ = Clazz.declareType (android.graphics, "BlurMaskFilter", android.graphics.MaskFilter);
Clazz.makeConstructor (c$, 
function (radius, style) {
Clazz.superConstructor (this, android.graphics.BlurMaskFilter, []);
}, "~N,android.graphics.BlurMaskFilter.Blur");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.native_int = 0;
Clazz.instantialize (this, arguments);
}, android.graphics.BlurMaskFilter, "Blur", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.native_int = a;
}, "~N");
Clazz.defineEnumConstant (c$, "NORMAL", 0, [0]);
Clazz.defineEnumConstant (c$, "SOLID", 1, [1]);
Clazz.defineEnumConstant (c$, "OUTER", 2, [2]);
Clazz.defineEnumConstant (c$, "INNER", 3, [3]);
c$ = Clazz.p0p ();
});
