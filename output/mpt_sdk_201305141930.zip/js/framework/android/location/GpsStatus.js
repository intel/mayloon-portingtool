﻿Clazz.declarePackage ("android.location");
Clazz.load (["java.util.Iterator"], "android.location.GpsStatus", ["android.location.GpsSatellite", "java.lang.UnsupportedOperationException", "java.util.NoSuchElementException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mTimeToFirstFix = 0;
this.mSatellites = null;
if (!Clazz.isClassDefined ("android.location.GpsStatus.SatelliteIterator")) {
android.location.GpsStatus.$GpsStatus$SatelliteIterator$ ();
}
this.mSatelliteList = null;
Clazz.instantialize (this, arguments);
}, android.location, "GpsStatus");
Clazz.prepareFields (c$, function () {
this.mSatellites =  new Array (255);
this.mSatelliteList = ((Clazz.isClassDefined ("android.location.GpsStatus$1") ? 0 : android.location.GpsStatus.$GpsStatus$1$ ()), Clazz.innerTypeInstance (android.location.GpsStatus$1, this, null));
});
Clazz.makeConstructor (c$, 
function () {
for (var i = 0; i < this.mSatellites.length; i++) {
this.mSatellites[i] =  new android.location.GpsSatellite (i + 1);
}
});
Clazz.defineMethod (c$, "setStatus", 
function (svCount, prns, snrs, elevations, azimuths, ephemerisMask, almanacMask, usedInFixMask) {
var i;
for (i = 0; i < this.mSatellites.length; i++) {
this.mSatellites[i].mValid = false;
}
for (i = 0; i < svCount; i++) {
var prn = prns[i] - 1;
var prnShift = (1 << prn);
if (prn >= 0 && prn < this.mSatellites.length) {
var satellite = this.mSatellites[prn];
satellite.mValid = true;
satellite.mSnr = snrs[i];
satellite.mElevation = elevations[i];
satellite.mAzimuth = azimuths[i];
satellite.mHasEphemeris = ((ephemerisMask & prnShift) != 0);
satellite.mHasAlmanac = ((almanacMask & prnShift) != 0);
satellite.mUsedInFix = ((usedInFixMask & prnShift) != 0);
}}
}, "~N,~A,~A,~A,~A,~N,~N,~N");
Clazz.defineMethod (c$, "setStatus", 
function (status) {
this.mTimeToFirstFix = status.getTimeToFirstFix ();
for (var i = 0; i < this.mSatellites.length; i++) {
this.mSatellites[i].setStatus (status.mSatellites[i]);
}
}, "android.location.GpsStatus");
Clazz.defineMethod (c$, "setTimeToFirstFix", 
function (ttff) {
this.mTimeToFirstFix = ttff;
}, "~N");
Clazz.defineMethod (c$, "getTimeToFirstFix", 
function () {
return this.mTimeToFirstFix;
});
Clazz.defineMethod (c$, "getSatellites", 
function () {
return this.mSatelliteList;
});
Clazz.defineMethod (c$, "getMaxSatellites", 
function () {
return 255;
});
c$.$GpsStatus$SatelliteIterator$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mSatellites = null;
this.mIndex = 0;
Clazz.instantialize (this, arguments);
}, android.location.GpsStatus, "SatelliteIterator", null, java.util.Iterator);
Clazz.makeConstructor (c$, 
function (a) {
this.mSatellites = a;
}, "~A");
Clazz.overrideMethod (c$, "hasNext", 
function () {
for (var a = this.mIndex; a < this.mSatellites.length; a++) {
if (this.mSatellites[a].mValid) {
return true;
}}
return false;
});
Clazz.overrideMethod (c$, "next", 
function () {
while (this.mIndex < this.mSatellites.length) {
var a = this.mSatellites[this.mIndex++];
if (a.mValid) {
return a;
}}
throw  new java.util.NoSuchElementException ();
});
Clazz.overrideMethod (c$, "remove", 
function () {
throw  new UnsupportedOperationException ();
});
c$ = Clazz.p0p ();
};
c$.$GpsStatus$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.location, "GpsStatus$1", null, Iterable);
Clazz.overrideMethod (c$, "iterator", 
function () {
return Clazz.innerTypeInstance (android.location.GpsStatus.SatelliteIterator, this, null, this.b$["android.location.GpsStatus"].mSatellites);
});
c$ = Clazz.p0p ();
};
Clazz.declareInterface (android.location.GpsStatus, "Listener");
Clazz.declareInterface (android.location.GpsStatus, "NmeaListener");
Clazz.defineStatics (c$,
"NUM_SATELLITES", 255,
"GPS_EVENT_STARTED", 1,
"GPS_EVENT_STOPPED", 2,
"GPS_EVENT_FIRST_FIX", 3,
"GPS_EVENT_SATELLITE_STATUS", 4);
});
