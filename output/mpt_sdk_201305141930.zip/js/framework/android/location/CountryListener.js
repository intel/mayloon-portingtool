﻿Clazz.declarePackage ("android.location");
Clazz.declareInterface (android.location, "CountryListener");
