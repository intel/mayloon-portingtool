﻿Clazz.declarePackage ("android.location");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.location.Criteria", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mHorizontalAccuracy = 0;
this.mVerticalAccuracy = 0;
this.mSpeedAccuracy = 0;
this.mBearingAccuracy = 0;
this.mPowerRequirement = 0;
this.mAltitudeRequired = false;
this.mBearingRequired = false;
this.mSpeedRequired = false;
this.mCostAllowed = false;
Clazz.instantialize (this, arguments);
}, android.location, "Criteria", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (criteria) {
this.mHorizontalAccuracy = criteria.mHorizontalAccuracy;
this.mVerticalAccuracy = criteria.mVerticalAccuracy;
this.mSpeedAccuracy = criteria.mSpeedAccuracy;
this.mBearingAccuracy = criteria.mBearingAccuracy;
this.mPowerRequirement = criteria.mPowerRequirement;
this.mAltitudeRequired = criteria.mAltitudeRequired;
this.mBearingRequired = criteria.mBearingRequired;
this.mSpeedRequired = criteria.mSpeedRequired;
this.mCostAllowed = criteria.mCostAllowed;
}, "android.location.Criteria");
Clazz.defineMethod (c$, "setHorizontalAccuracy", 
function (accuracy) {
if (accuracy < 0 || accuracy > 3) {
throw  new IllegalArgumentException ("accuracy=" + accuracy);
}this.mHorizontalAccuracy = accuracy;
}, "~N");
Clazz.defineMethod (c$, "getHorizontalAccuracy", 
function () {
return this.mHorizontalAccuracy;
});
Clazz.defineMethod (c$, "setVerticalAccuracy", 
function (accuracy) {
if (accuracy < 0 || accuracy > 3) {
throw  new IllegalArgumentException ("accuracy=" + accuracy);
}this.mVerticalAccuracy = accuracy;
}, "~N");
Clazz.defineMethod (c$, "getVerticalAccuracy", 
function () {
return this.mVerticalAccuracy;
});
Clazz.defineMethod (c$, "setSpeedAccuracy", 
function (accuracy) {
if (accuracy < 0 || accuracy > 3) {
throw  new IllegalArgumentException ("accuracy=" + accuracy);
}this.mSpeedAccuracy = accuracy;
}, "~N");
Clazz.defineMethod (c$, "getSpeedAccuracy", 
function () {
return this.mSpeedAccuracy;
});
Clazz.defineMethod (c$, "setBearingAccuracy", 
function (accuracy) {
if (accuracy < 0 || accuracy > 3) {
throw  new IllegalArgumentException ("accuracy=" + accuracy);
}this.mBearingAccuracy = accuracy;
}, "~N");
Clazz.defineMethod (c$, "getBearingAccuracy", 
function () {
return this.mBearingAccuracy;
});
Clazz.defineMethod (c$, "setAccuracy", 
function (accuracy) {
if (accuracy < 0 || accuracy > 2) {
throw  new IllegalArgumentException ("accuracy=" + accuracy);
}if (accuracy == 1) {
this.mHorizontalAccuracy = 3;
} else {
this.mHorizontalAccuracy = 1;
}}, "~N");
Clazz.defineMethod (c$, "getAccuracy", 
function () {
if (this.mHorizontalAccuracy >= 3) {
return 1;
} else {
return 2;
}});
Clazz.defineMethod (c$, "setPowerRequirement", 
function (level) {
if (level < 0 || level > 3) {
throw  new IllegalArgumentException ("level=" + level);
}this.mPowerRequirement = level;
}, "~N");
Clazz.defineMethod (c$, "getPowerRequirement", 
function () {
return this.mPowerRequirement;
});
Clazz.defineMethod (c$, "setCostAllowed", 
function (costAllowed) {
this.mCostAllowed = costAllowed;
}, "~B");
Clazz.defineMethod (c$, "isCostAllowed", 
function () {
return this.mCostAllowed;
});
Clazz.defineMethod (c$, "setAltitudeRequired", 
function (altitudeRequired) {
this.mAltitudeRequired = altitudeRequired;
}, "~B");
Clazz.defineMethod (c$, "isAltitudeRequired", 
function () {
return this.mAltitudeRequired;
});
Clazz.defineMethod (c$, "setSpeedRequired", 
function (speedRequired) {
this.mSpeedRequired = speedRequired;
}, "~B");
Clazz.defineMethod (c$, "isSpeedRequired", 
function () {
return this.mSpeedRequired;
});
Clazz.defineMethod (c$, "setBearingRequired", 
function (bearingRequired) {
this.mBearingRequired = bearingRequired;
}, "~B");
Clazz.defineMethod (c$, "isBearingRequired", 
function () {
return this.mBearingRequired;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (parcel, flags) {
parcel.writeInt (this.mHorizontalAccuracy);
parcel.writeInt (this.mVerticalAccuracy);
parcel.writeInt (this.mSpeedAccuracy);
parcel.writeInt (this.mBearingAccuracy);
parcel.writeInt (this.mPowerRequirement);
parcel.writeInt (this.mAltitudeRequired ? 1 : 0);
parcel.writeInt (this.mBearingRequired ? 1 : 0);
parcel.writeInt (this.mSpeedRequired ? 1 : 0);
parcel.writeInt (this.mCostAllowed ? 1 : 0);
}, "android.os.Parcel,~N");
c$.$Criteria$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.location, "Criteria$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
var c =  new android.location.Criteria ();
c.mHorizontalAccuracy = $in.readInt ();
c.mVerticalAccuracy = $in.readInt ();
c.mSpeedAccuracy = $in.readInt ();
c.mBearingAccuracy = $in.readInt ();
c.mPowerRequirement = $in.readInt ();
c.mAltitudeRequired = $in.readInt () != 0;
c.mBearingRequired = $in.readInt () != 0;
c.mSpeedRequired = $in.readInt () != 0;
c.mCostAllowed = $in.readInt () != 0;
return c;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"NO_REQUIREMENT", 0,
"POWER_LOW", 1,
"POWER_MEDIUM", 2,
"POWER_HIGH", 3,
"ACCURACY_FINE", 1,
"ACCURACY_COARSE", 2,
"ACCURACY_LOW", 1,
"ACCURACY_MEDIUM", 2,
"ACCURACY_HIGH", 3);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.location.Criteria$1") ? 0 : android.location.Criteria.$Criteria$1$ ()), Clazz.innerTypeInstance (android.location.Criteria$1, this, null));
});
