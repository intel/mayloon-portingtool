﻿Clazz.declarePackage ("android.location");
c$ = Clazz.decorateAsClass (function () {
this.mValid = false;
this.mHasEphemeris = false;
this.mHasAlmanac = false;
this.mUsedInFix = false;
this.mPrn = 0;
this.mSnr = 0;
this.mElevation = 0;
this.mAzimuth = 0;
Clazz.instantialize (this, arguments);
}, android.location, "GpsSatellite");
Clazz.makeConstructor (c$, 
function (prn) {
this.mPrn = prn;
}, "~N");
Clazz.defineMethod (c$, "setStatus", 
function (satellite) {
this.mValid = satellite.mValid;
this.mHasEphemeris = satellite.mHasEphemeris;
this.mHasAlmanac = satellite.mHasAlmanac;
this.mUsedInFix = satellite.mUsedInFix;
this.mSnr = satellite.mSnr;
this.mElevation = satellite.mElevation;
this.mAzimuth = satellite.mAzimuth;
}, "android.location.GpsSatellite");
Clazz.defineMethod (c$, "getPrn", 
function () {
return this.mPrn;
});
Clazz.defineMethod (c$, "getSnr", 
function () {
return this.mSnr;
});
Clazz.defineMethod (c$, "getElevation", 
function () {
return this.mElevation;
});
Clazz.defineMethod (c$, "getAzimuth", 
function () {
return this.mAzimuth;
});
Clazz.defineMethod (c$, "hasEphemeris", 
function () {
return this.mHasEphemeris;
});
Clazz.defineMethod (c$, "hasAlmanac", 
function () {
return this.mHasAlmanac;
});
Clazz.defineMethod (c$, "usedInFix", 
function () {
return this.mUsedInFix;
});
