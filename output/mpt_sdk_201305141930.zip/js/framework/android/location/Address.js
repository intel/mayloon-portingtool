﻿Clazz.declarePackage ("android.location");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator", "java.util.HashMap", "$.Locale"], "android.location.Address", ["android.os.Bundle", "java.lang.IllegalArgumentException", "$.IllegalStateException", "$.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mLocale = null;
this.mFeatureName = null;
this.mAddressLines = null;
this.mMaxAddressLineIndex = -1;
this.mAdminArea = null;
this.mSubAdminArea = null;
this.mLocality = null;
this.mSubLocality = null;
this.mThoroughfare = null;
this.mSubThoroughfare = null;
this.mPremises = null;
this.mPostalCode = null;
this.mCountryCode = null;
this.mCountryName = null;
this.mLatitude = 0;
this.mLongitude = 0;
this.mHasLatitude = false;
this.mHasLongitude = false;
this.mPhone = null;
this.mUrl = null;
this.mExtras = null;
Clazz.instantialize (this, arguments);
}, android.location, "Address", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function (locale) {
this.mLocale = locale;
}, "java.util.Locale");
Clazz.defineMethod (c$, "getLocale", 
function () {
return this.mLocale;
});
Clazz.defineMethod (c$, "getMaxAddressLineIndex", 
function () {
return this.mMaxAddressLineIndex;
});
Clazz.defineMethod (c$, "getAddressLine", 
function (index) {
if (index < 0) {
throw  new IllegalArgumentException ("index = " + index + " < 0");
}return this.mAddressLines == null ? null : this.mAddressLines.get (new Integer (index));
}, "~N");
Clazz.defineMethod (c$, "setAddressLine", 
function (index, line) {
if (index < 0) {
throw  new IllegalArgumentException ("index = " + index + " < 0");
}if (this.mAddressLines == null) {
this.mAddressLines =  new java.util.HashMap ();
}this.mAddressLines.put (new Integer (index), line);
if (line == null) {
this.mMaxAddressLineIndex = -1;
for (var i, $i = this.mAddressLines.keySet ().iterator (); $i.hasNext () && ((i = $i.next ()) || true);) {
this.mMaxAddressLineIndex = Math.max (this.mMaxAddressLineIndex, (i).intValue ());
}
} else {
this.mMaxAddressLineIndex = Math.max (this.mMaxAddressLineIndex, index);
}}, "~N,~S");
Clazz.defineMethod (c$, "getFeatureName", 
function () {
return this.mFeatureName;
});
Clazz.defineMethod (c$, "setFeatureName", 
function (featureName) {
this.mFeatureName = featureName;
}, "~S");
Clazz.defineMethod (c$, "getAdminArea", 
function () {
return this.mAdminArea;
});
Clazz.defineMethod (c$, "setAdminArea", 
function (adminArea) {
this.mAdminArea = adminArea;
}, "~S");
Clazz.defineMethod (c$, "getSubAdminArea", 
function () {
return this.mSubAdminArea;
});
Clazz.defineMethod (c$, "setSubAdminArea", 
function (subAdminArea) {
this.mSubAdminArea = subAdminArea;
}, "~S");
Clazz.defineMethod (c$, "getLocality", 
function () {
return this.mLocality;
});
Clazz.defineMethod (c$, "setLocality", 
function (locality) {
this.mLocality = locality;
}, "~S");
Clazz.defineMethod (c$, "getSubLocality", 
function () {
return this.mSubLocality;
});
Clazz.defineMethod (c$, "setSubLocality", 
function (sublocality) {
this.mSubLocality = sublocality;
}, "~S");
Clazz.defineMethod (c$, "getThoroughfare", 
function () {
return this.mThoroughfare;
});
Clazz.defineMethod (c$, "setThoroughfare", 
function (thoroughfare) {
this.mThoroughfare = thoroughfare;
}, "~S");
Clazz.defineMethod (c$, "getSubThoroughfare", 
function () {
return this.mSubThoroughfare;
});
Clazz.defineMethod (c$, "setSubThoroughfare", 
function (subthoroughfare) {
this.mSubThoroughfare = subthoroughfare;
}, "~S");
Clazz.defineMethod (c$, "getPremises", 
function () {
return this.mPremises;
});
Clazz.defineMethod (c$, "setPremises", 
function (premises) {
this.mPremises = premises;
}, "~S");
Clazz.defineMethod (c$, "getPostalCode", 
function () {
return this.mPostalCode;
});
Clazz.defineMethod (c$, "setPostalCode", 
function (postalCode) {
this.mPostalCode = postalCode;
}, "~S");
Clazz.defineMethod (c$, "getCountryCode", 
function () {
return this.mCountryCode;
});
Clazz.defineMethod (c$, "setCountryCode", 
function (countryCode) {
this.mCountryCode = countryCode;
}, "~S");
Clazz.defineMethod (c$, "getCountryName", 
function () {
return this.mCountryName;
});
Clazz.defineMethod (c$, "setCountryName", 
function (countryName) {
this.mCountryName = countryName;
}, "~S");
Clazz.defineMethod (c$, "hasLatitude", 
function () {
return this.mHasLatitude;
});
Clazz.defineMethod (c$, "getLatitude", 
function () {
if (this.mHasLatitude) {
return this.mLatitude;
} else {
throw  new IllegalStateException ();
}});
Clazz.defineMethod (c$, "setLatitude", 
function (latitude) {
this.mLatitude = latitude;
this.mHasLatitude = true;
}, "~N");
Clazz.defineMethod (c$, "clearLatitude", 
function () {
this.mHasLatitude = false;
});
Clazz.defineMethod (c$, "hasLongitude", 
function () {
return this.mHasLongitude;
});
Clazz.defineMethod (c$, "getLongitude", 
function () {
if (this.mHasLongitude) {
return this.mLongitude;
} else {
throw  new IllegalStateException ();
}});
Clazz.defineMethod (c$, "setLongitude", 
function (longitude) {
this.mLongitude = longitude;
this.mHasLongitude = true;
}, "~N");
Clazz.defineMethod (c$, "clearLongitude", 
function () {
this.mHasLongitude = false;
});
Clazz.defineMethod (c$, "getPhone", 
function () {
return this.mPhone;
});
Clazz.defineMethod (c$, "setPhone", 
function (phone) {
this.mPhone = phone;
}, "~S");
Clazz.defineMethod (c$, "getUrl", 
function () {
return this.mUrl;
});
Clazz.defineMethod (c$, "setUrl", 
function (Url) {
this.mUrl = Url;
}, "~S");
Clazz.defineMethod (c$, "getExtras", 
function () {
return this.mExtras;
});
Clazz.defineMethod (c$, "setExtras", 
function (extras) {
this.mExtras = (extras == null) ? null :  new android.os.Bundle (extras);
}, "android.os.Bundle");
Clazz.overrideMethod (c$, "toString", 
function () {
var sb =  new StringBuilder ();
sb.append ("Address[addressLines=[");
for (var i = 0; i <= this.mMaxAddressLineIndex; i++) {
if (i > 0) {
sb.append (',');
}sb.append (i);
sb.append (':');
var line = this.mAddressLines.get (new Integer (i));
if (line == null) {
sb.append ("null");
} else {
sb.append ('\"');
sb.append (line);
sb.append ('\"');
}}
sb.append (']');
sb.append (",feature=");
sb.append (this.mFeatureName);
sb.append (",admin=");
sb.append (this.mAdminArea);
sb.append (",sub-admin=");
sb.append (this.mSubAdminArea);
sb.append (",locality=");
sb.append (this.mLocality);
sb.append (",thoroughfare=");
sb.append (this.mThoroughfare);
sb.append (",postalCode=");
sb.append (this.mPostalCode);
sb.append (",countryCode=");
sb.append (this.mCountryCode);
sb.append (",countryName=");
sb.append (this.mCountryName);
sb.append (",hasLatitude=");
sb.append (this.mHasLatitude);
sb.append (",latitude=");
sb.append (this.mLatitude);
sb.append (",hasLongitude=");
sb.append (this.mHasLongitude);
sb.append (",longitude=");
sb.append (this.mLongitude);
sb.append (",phone=");
sb.append (this.mPhone);
sb.append (",url=");
sb.append (this.mUrl);
sb.append (",extras=");
sb.append (this.mExtras);
sb.append (']');
return sb.toString ();
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return (this.mExtras != null) ? this.mExtras.describeContents () : 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (parcel, flags) {
parcel.writeString (this.mLocale.getLanguage ());
parcel.writeString (this.mLocale.getCountry ());
if (this.mAddressLines == null) {
parcel.writeInt (0);
} else {
var entries = this.mAddressLines.entrySet ();
parcel.writeInt (entries.size ());
for (var e, $e = entries.iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
parcel.writeInt ((e.getKey ()).intValue ());
parcel.writeString (e.getValue ());
}
}parcel.writeString (this.mFeatureName);
parcel.writeString (this.mAdminArea);
parcel.writeString (this.mSubAdminArea);
parcel.writeString (this.mLocality);
parcel.writeString (this.mSubLocality);
parcel.writeString (this.mThoroughfare);
parcel.writeString (this.mSubThoroughfare);
parcel.writeString (this.mPremises);
parcel.writeString (this.mPostalCode);
parcel.writeString (this.mCountryCode);
parcel.writeString (this.mCountryName);
parcel.writeInt (this.mHasLatitude ? 1 : 0);
if (this.mHasLatitude) {
parcel.writeDouble (this.mLatitude);
}parcel.writeInt (this.mHasLongitude ? 1 : 0);
if (this.mHasLongitude) {
parcel.writeDouble (this.mLongitude);
}parcel.writeString (this.mPhone);
parcel.writeString (this.mUrl);
parcel.writeBundle (this.mExtras);
}, "android.os.Parcel,~N");
c$.$Address$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.location, "Address$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
var language = $in.readString ();
var country = $in.readString ();
var locale = country.length > 0 ?  new java.util.Locale (language, country) :  new java.util.Locale (language);
var a =  new android.location.Address (locale);
var N = $in.readInt ();
if (N > 0) {
a.mAddressLines =  new java.util.HashMap (N);
for (var i = 0; i < N; i++) {
var index = $in.readInt ();
var line = $in.readString ();
a.mAddressLines.put (new Integer (index), line);
a.mMaxAddressLineIndex = Math.max (a.mMaxAddressLineIndex, index);
}
} else {
a.mAddressLines = null;
a.mMaxAddressLineIndex = -1;
}a.mFeatureName = $in.readString ();
a.mAdminArea = $in.readString ();
a.mSubAdminArea = $in.readString ();
a.mLocality = $in.readString ();
a.mSubLocality = $in.readString ();
a.mThoroughfare = $in.readString ();
a.mSubThoroughfare = $in.readString ();
a.mPremises = $in.readString ();
a.mPostalCode = $in.readString ();
a.mCountryCode = $in.readString ();
a.mCountryName = $in.readString ();
a.mHasLatitude = $in.readInt () == 0 ? false : true;
if (a.mHasLatitude) {
a.mLatitude = $in.readDouble ();
}a.mHasLongitude = $in.readInt () == 0 ? false : true;
if (a.mHasLongitude) {
a.mLongitude = $in.readDouble ();
}a.mPhone = $in.readString ();
a.mUrl = $in.readString ();
a.mExtras = $in.readBundle ();
return a;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.location.Address$1") ? 0 : android.location.Address.$Address$1$ ()), Clazz.innerTypeInstance (android.location.Address$1, this, null));
});
