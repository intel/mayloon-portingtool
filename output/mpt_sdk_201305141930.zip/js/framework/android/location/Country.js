﻿Clazz.declarePackage ("android.location");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.location.Country", ["java.lang.IllegalArgumentException", "java.util.Locale"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mCountryIso = null;
this.mSource = 0;
this.mHashCode = 0;
Clazz.instantialize (this, arguments);
}, android.location, "Country", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function (countryIso, source) {
if (countryIso == null || source < 0 || source > 3) {
throw  new IllegalArgumentException ();
}this.mCountryIso = countryIso.toUpperCase (java.util.Locale.US);
this.mSource = source;
}, "~S,~N");
Clazz.makeConstructor (c$, 
function (country) {
this.mCountryIso = country.mCountryIso;
this.mSource = country.mSource;
}, "android.location.Country");
Clazz.defineMethod (c$, "getCountryIso", 
function () {
return this.mCountryIso;
});
Clazz.defineMethod (c$, "getSource", 
function () {
return this.mSource;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (parcel, flags) {
parcel.writeString (this.mCountryIso);
parcel.writeInt (this.mSource);
}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "equals", 
function (object) {
if (object === this) {
return true;
}if (Clazz.instanceOf (object, android.location.Country)) {
var c = object;
return this.mCountryIso.equals (c.getCountryIso ()) && this.mSource == c.getSource ();
}return false;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
var hash = this.mHashCode;
if (hash == 0) {
hash = 17;
hash = hash * 13 + this.mCountryIso.hashCode ();
hash = hash * 13 + this.mSource;
this.mHashCode = hash;
}return this.mHashCode;
});
Clazz.defineMethod (c$, "equalsIgnoreSource", 
function (country) {
return country != null && this.mCountryIso.equals (country.getCountryIso ());
}, "android.location.Country");
c$.$Country$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.location, "Country$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
return  new android.location.Country ($in.readString (), $in.readInt ());
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"COUNTRY_SOURCE_NETWORK", 0,
"COUNTRY_SOURCE_LOCATION", 1,
"COUNTRY_SOURCE_SIM", 2,
"COUNTRY_SOURCE_LOCALE", 3);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.location.Country$1") ? 0 : android.location.Country.$Country$1$ ()), Clazz.innerTypeInstance (android.location.Country$1, this, null));
});
