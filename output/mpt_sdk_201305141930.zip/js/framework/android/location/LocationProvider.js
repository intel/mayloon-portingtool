﻿Clazz.declarePackage ("android.location");
Clazz.load (null, "android.location.LocationProvider", ["android.util.Log", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mName = null;
this.mService = null;
Clazz.instantialize (this, arguments);
}, android.location, "LocationProvider");
Clazz.makeConstructor (c$, 
function (name, service) {
if (name.matches ("[^a-zA-Z0-9]")) {
throw  new IllegalArgumentException ("name " + name + " contains an illegal character");
}this.mName = name;
this.mService = service;
android.util.Log.d ("LocationProvider>>>", " using " + name + " provider");
}, "~S,android.location.LocationManager");
Clazz.defineMethod (c$, "getName", 
function () {
return this.mName;
});
Clazz.defineMethod (c$, "meetsCriteria", 
function (criteria) {
return this.mService.providerMeetsCriteria (this.mName, criteria);
}, "android.location.Criteria");
Clazz.defineMethod (c$, "requiresNetwork", 
function () {
return true;
});
Clazz.defineMethod (c$, "requiresSatellite", 
function () {
return this.mName.equals ("gps");
});
Clazz.defineMethod (c$, "requiresCell", 
function () {
return false;
});
Clazz.defineMethod (c$, "hasMonetaryCost", 
function () {
return false;
});
Clazz.defineMethod (c$, "supportsAltitude", 
function () {
if (this.mName.equals ("gps")) {
return true;
}return false;
});
Clazz.defineMethod (c$, "supportsSpeed", 
function () {
if (this.mName.equals ("gps")) {
return true;
}return false;
});
Clazz.defineMethod (c$, "supportsBearing", 
function () {
return false;
});
Clazz.defineMethod (c$, "getPowerRequirement", 
function () {
if (this.mName.equals ("gps")) {
return 3;
}return 1;
});
Clazz.defineMethod (c$, "getAccuracy", 
function () {
if (this.mName.equals ("gps")) {
return 1;
}return 2;
});
Clazz.defineStatics (c$,
"TAG", "LocationProvider>>>",
"BAD_CHARS_REGEX", "[^a-zA-Z0-9]",
"OUT_OF_SERVICE", 0,
"TEMPORARILY_UNAVAILABLE", 1,
"AVAILABLE", 2);
});
