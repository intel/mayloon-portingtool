﻿Clazz.declarePackage ("android.location");
Clazz.load (["android.location.GpsStatus", "java.util.ArrayList", "$.HashMap"], "android.location.LocationManager", ["android.location.Location", "$.LocationProvider", "android.os.Bundle", "$.Handler", "$.Message", "android.util.Log", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mService = null;
this.mGpsStatus = null;
if (!Clazz.isClassDefined ("android.location.LocationManager.ListenerTransport")) {
android.location.LocationManager.$LocationManager$ListenerTransport$ ();
}
if (!Clazz.isClassDefined ("android.location.LocationManager.IntentTransport")) {
android.location.LocationManager.$LocationManager$IntentTransport$ ();
}
if (!Clazz.isClassDefined ("android.location.LocationManager.AlertTransport")) {
android.location.LocationManager.$LocationManager$AlertTransport$ ();
}
this.watchID = -1;
this.loc = null;
if (!Clazz.isClassDefined ("android.location.LocationManager.Position")) {
android.location.LocationManager.$LocationManager$Position$ ();
}
if (!Clazz.isClassDefined ("android.location.LocationManager.PositionError")) {
android.location.LocationManager.$LocationManager$PositionError$ ();
}
Clazz.instantialize (this, arguments);
}, android.location, "LocationManager");
Clazz.prepareFields (c$, function () {
this.mGpsStatus =  new android.location.GpsStatus ();
});
Clazz.makeConstructor (c$, 
function (service) {
this.mService = service;
}, "android.location.LocationManager");
Clazz.makeConstructor (c$, 
function () {
this.mService = this;
});
Clazz.defineMethod (c$, "errorCall", 
function (error) {
switch (error.code) {
case 3:
case 2:
break;
case 1:
for (var listener, $listener = android.location.LocationManager.mListeners.keySet ().iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
var lt = android.location.LocationManager.mListeners.get (listener);
lt.onProviderDisabled ("network");
lt.onProviderDisabled ("gps");
}
for (var intent, $intent = android.location.LocationManager.mIntents.keySet ().iterator (); $intent.hasNext () && ((intent = $intent.next ()) || true);) {
var it = android.location.LocationManager.mIntents.get (intent);
it.onProviderDisabled ("network");
it.onProviderDisabled ("gps");
}
break;
}
System.out.println ("geoLocation error: " + error.message);
}, "android.location.LocationManager.PositionError");
Clazz.defineMethod (c$, "succussCall", 
function (position) {
android.util.Log.d ("LocationManager>>>>", " location changed");
this.loc =  new android.location.Location ("internet");
this.loc.setAccuracy (position.coords.accuracy);
this.loc.setLatitude (position.coords.latitude);
this.loc.setLongitude (position.coords.longitude);
this.loc.setTime(position.timestamp);
if(position.coords.speed!=undefined){
this.loc.setSpeed(position.coords.speed); }
if(position.coords.altitude!=undefined){
this.loc.setAltitude(position.coords.altitude);
this.loc.setProvider('gps'); }
if(position.coords.heading!=undefined){
this.loc.setBearing(position.coords.heading); }
for (var listener, $listener = android.location.LocationManager.mListeners.keySet ().iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
var lt = android.location.LocationManager.mListeners.get (listener);
lt.onLocationChanged (this.loc);
if (lt.singleShot) {
android.location.LocationManager.mListeners.remove (listener);
}}
for (var intent, $intent = android.location.LocationManager.mIntents.keySet ().iterator (); $intent.hasNext () && ((intent = $intent.next ()) || true);) {
var it = android.location.LocationManager.mIntents.get (intent);
it.onLocationChanged (this.loc);
if (it.singleShot) {
android.location.LocationManager.mIntents.remove (it);
}}
for (var intent, $intent = android.location.LocationManager.mAlerts.keySet ().iterator (); $intent.hasNext () && ((intent = $intent.next ()) || true);) {
var at = android.location.LocationManager.mAlerts.get (intent);
at.alert (this.loc);
}
if (android.location.LocationManager.mIntents.size () <= 0 && android.location.LocationManager.mListeners.size () <= 0 && android.location.LocationManager.mAlerts.size () <= 0) {
navigator.geolocation.clearWatch(watchID);
($t$ = android.location.LocationManager.isEnableGeoLocation = false, android.location.LocationManager.prototype.isEnableGeoLocation = android.location.LocationManager.isEnableGeoLocation, $t$);
}}, "android.location.LocationManager.Position");
Clazz.defineMethod (c$, "createProvider", 
($fz = function (name) {
var provider =  new android.location.LocationProvider (name, this);
return provider;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "getAllProviders", 
function () {
return android.location.LocationManager.providers;
});
Clazz.defineMethod (c$, "getProviders", 
function (enabledOnly) {
if (enabledOnly) {
if (android.location.LocationManager.PERMISSION_DENIED) {
return null;
}return android.location.LocationManager.providers;
} else {
if (android.location.LocationManager.PERMISSION_DENIED) {
return android.location.LocationManager.providers;
}return null;
}}, "~B");
Clazz.defineMethod (c$, "getProvider", 
function (name) {
if (name == null) {
throw  new IllegalArgumentException ("name==null");
}return this.createProvider (name);
}, "~S");
Clazz.defineMethod (c$, "getProviders", 
function (criteria, enabledOnly) {
if (criteria == null) {
throw  new IllegalArgumentException ("criteria==null");
}return this.getProviders (enabledOnly);
}, "android.location.Criteria,~B");
Clazz.defineMethod (c$, "getBestProvider", 
function (criteria, enabledOnly) {
if (criteria == null) {
throw  new IllegalArgumentException ("criteria==null");
}return "gps";
}, "android.location.Criteria,~B");
Clazz.defineMethod (c$, "requestLocationUpdates", 
function (provider, minTime, minDistance, listener) {
if (provider == null) {
throw  new IllegalArgumentException ("provider==null");
}if (listener == null) {
throw  new IllegalArgumentException ("listener==null");
}this._requestLocationUpdates (provider, null, minTime, minDistance, false, listener, null);
}, "~S,~N,~N,android.location.LocationListener");
Clazz.defineMethod (c$, "requestLocationUpdates", 
function (provider, minTime, minDistance, listener, looper) {
if (provider == null) {
throw  new IllegalArgumentException ("provider==null");
}if (listener == null) {
throw  new IllegalArgumentException ("listener==null");
}this._requestLocationUpdates (provider, null, minTime, minDistance, false, listener, looper);
}, "~S,~N,~N,android.location.LocationListener,android.os.Looper");
Clazz.defineMethod (c$, "requestLocationUpdates", 
function (minTime, minDistance, criteria, listener, looper) {
if (criteria == null) {
throw  new IllegalArgumentException ("criteria==null");
}if (listener == null) {
throw  new IllegalArgumentException ("listener==null");
}this._requestLocationUpdates (null, criteria, minTime, minDistance, false, listener, looper);
}, "~N,~N,android.location.Criteria,android.location.LocationListener,android.os.Looper");
Clazz.defineMethod (c$, "_requestLocationUpdates", 
($fz = function (provider, criteria, minTime, minDistance, singleShot, listener, looper) {
if (minTime < 0) {
minTime = 0;
}if (minDistance < 0.0) {
minDistance = 0.0;
}{
var transport = android.location.LocationManager.mListeners.get (listener);
if (transport == null) {
transport = Clazz.innerTypeInstance (android.location.LocationManager.ListenerTransport, this, null, listener, looper);
transport.singleShot = singleShot;
android.location.LocationManager.mListeners.put (listener, transport);
this.enableGeoLoaction ();
}}}, $fz.isPrivate = true, $fz), "~S,android.location.Criteria,~N,~N,~B,android.location.LocationListener,android.os.Looper");
Clazz.defineMethod (c$, "requestLocationUpdates", 
function (provider, minTime, minDistance, intent) {
if (provider == null) {
throw  new IllegalArgumentException ("provider==null");
}if (intent == null) {
throw  new IllegalArgumentException ("intent==null");
}this._requestLocationUpdates (provider, null, minTime, minDistance, false, intent);
}, "~S,~N,~N,android.app.PendingIntent");
Clazz.defineMethod (c$, "requestLocationUpdates", 
function (minTime, minDistance, criteria, intent) {
if (criteria == null) {
throw  new IllegalArgumentException ("criteria==null");
}if (intent == null) {
throw  new IllegalArgumentException ("intent==null");
}this._requestLocationUpdates (null, criteria, minTime, minDistance, false, intent);
}, "~N,~N,android.location.Criteria,android.app.PendingIntent");
Clazz.defineMethod (c$, "_requestLocationUpdates", 
($fz = function (provider, criteria, minTime, minDistance, singleShot, intent) {
if (minTime < 0) {
minTime = 0;
}if (minDistance < 0.0) {
minDistance = 0.0;
}{
var transport = android.location.LocationManager.mIntents.get (intent);
if (transport == null) {
transport = Clazz.innerTypeInstance (android.location.LocationManager.IntentTransport, this, null, intent);
transport.singleShot = singleShot;
android.location.LocationManager.mIntents.put (intent, transport);
this.enableGeoLoaction ();
}}}, $fz.isPrivate = true, $fz), "~S,android.location.Criteria,~N,~N,~B,android.app.PendingIntent");
Clazz.defineMethod (c$, "requestSingleUpdate", 
function (provider, listener, looper) {
if (provider == null) {
throw  new IllegalArgumentException ("provider==null");
}if (listener == null) {
throw  new IllegalArgumentException ("listener==null");
}this._requestLocationUpdates (provider, null, 0, 0.0, true, listener, looper);
}, "~S,android.location.LocationListener,android.os.Looper");
Clazz.defineMethod (c$, "requestSingleUpdate", 
function (criteria, listener, looper) {
if (criteria == null) {
throw  new IllegalArgumentException ("criteria==null");
}if (listener == null) {
throw  new IllegalArgumentException ("listener==null");
}this._requestLocationUpdates (null, criteria, 0, 0.0, true, listener, looper);
}, "android.location.Criteria,android.location.LocationListener,android.os.Looper");
Clazz.defineMethod (c$, "requestSingleUpdate", 
function (provider, intent) {
if (provider == null) {
throw  new IllegalArgumentException ("provider==null");
}if (intent == null) {
throw  new IllegalArgumentException ("intent==null");
}this._requestLocationUpdates (provider, null, 0, 0.0, true, intent);
}, "~S,android.app.PendingIntent");
Clazz.defineMethod (c$, "requestSingleUpdate", 
function (criteria, intent) {
if (criteria == null) {
throw  new IllegalArgumentException ("criteria==null");
}if (intent == null) {
throw  new IllegalArgumentException ("intent==null");
}this._requestLocationUpdates (null, criteria, 0, 0.0, true, intent);
}, "android.location.Criteria,android.app.PendingIntent");
Clazz.defineMethod (c$, "removeUpdates", 
function (listener) {
if (listener == null) {
throw  new IllegalArgumentException ("listener==null");
}android.location.LocationManager.mListeners.remove (listener);
if (android.location.LocationManager.mIntents.size () <= 0 && android.location.LocationManager.mListeners.size () <= 0) {
navigator.geolocation.clearWatch(this.watchID);
($t$ = android.location.LocationManager.isEnableGeoLocation = false, android.location.LocationManager.prototype.isEnableGeoLocation = android.location.LocationManager.isEnableGeoLocation, $t$);
}}, "android.location.LocationListener");
Clazz.defineMethod (c$, "removeUpdates", 
function (intent) {
if (intent == null) {
throw  new IllegalArgumentException ("intent==null");
}android.location.LocationManager.mIntents.remove (intent);
if (android.location.LocationManager.mIntents.size () <= 0 && android.location.LocationManager.mListeners.size () <= 0) {
navigator.geolocation.clearWatch(this.watchID);
($t$ = android.location.LocationManager.isEnableGeoLocation = false, android.location.LocationManager.prototype.isEnableGeoLocation = android.location.LocationManager.isEnableGeoLocation, $t$);
}}, "android.app.PendingIntent");
Clazz.defineMethod (c$, "addProximityAlert", 
function (latitude, longitude, radius, expiration, intent) {
{
var transport = android.location.LocationManager.mAlerts.get (intent);
if (transport == null) {
if (expiration != -1) expiration = System.currentTimeMillis () + expiration;
transport = Clazz.innerTypeInstance (android.location.LocationManager.AlertTransport, this, null, latitude, longitude, radius, expiration, intent);
android.location.LocationManager.mAlerts.put (intent, transport);
this.enableGeoLoaction ();
}}}, "~N,~N,~N,~N,android.app.PendingIntent");
Clazz.defineMethod (c$, "enableGeoLoaction", 
($fz = function () {
if (navigator.geolocation) {
if(this.watchID!=-1){
navigator.geolocation.clearWatch(this.watchID);
}
this.watchID=navigator.geolocation.watchPosition
(this.succussCall, this.errorCall,
{enableHighAccuracy:true, timeout:10000, maximumAge:3000}
); }
($t$ = android.location.LocationManager.isEnableGeoLocation = true, android.location.LocationManager.prototype.isEnableGeoLocation = android.location.LocationManager.isEnableGeoLocation, $t$);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "removeProximityAlert", 
function (intent) {
android.location.LocationManager.mAlerts.remove (intent);
if (android.location.LocationManager.mIntents.size () <= 0 && android.location.LocationManager.mListeners.size () <= 0 && android.location.LocationManager.mAlerts.size () <= 0) {
navigator.geolocation.clearWatch(this.watchID);
($t$ = android.location.LocationManager.isEnableGeoLocation = false, android.location.LocationManager.prototype.isEnableGeoLocation = android.location.LocationManager.isEnableGeoLocation, $t$);
}}, "android.app.PendingIntent");
Clazz.defineMethod (c$, "isProviderEnabled", 
function (provider) {
if (provider == null) {
throw  new IllegalArgumentException ("provider==null");
}return "gps".equals (provider) || "network".equals (provider);
}, "~S");
Clazz.defineMethod (c$, "getLastKnownLocation", 
function (provider) {
if (provider == null) {
throw  new IllegalArgumentException ("provider==null");
}return this.loc;
}, "~S");
Clazz.defineMethod (c$, "addGpsStatusListener", 
function (listener) {
var result = false;
return result;
}, "android.location.GpsStatus.Listener");
Clazz.defineMethod (c$, "removeGpsStatusListener", 
function (listener) {
}, "android.location.GpsStatus.Listener");
Clazz.defineMethod (c$, "getGpsStatus", 
function (status) {
if (status == null) {
status =  new android.location.GpsStatus ();
}status.setStatus (this.mGpsStatus);
return status;
}, "android.location.GpsStatus");
Clazz.defineMethod (c$, "providerMeetsCriteria", 
function (mName, criteria) {
return true;
}, "~S,android.location.Criteria");
Clazz.defineMethod (c$, "removeNmeaListener", 
function (listener) {
console.log("Missing method: removeNmeaListener");
}, "android.location.GpsStatus.NmeaListener");
Clazz.defineMethod (c$, "Nmea", 
function (timestamp, nmea) {
console.log("Missing method: Nmea");
}, "~N,~S");
Clazz.defineMethod (c$, "clearTestProviderLocation", 
function (provider) {
console.log("Missing method: clearTestProviderLocation");
}, "~S");
Clazz.defineMethod (c$, "removeTestProvider", 
function (provider) {
console.log("Missing method: removeTestProvider");
}, "~S");
Clazz.defineMethod (c$, "clearTestProviderStatus", 
function (provider) {
console.log("Missing method: clearTestProviderStatus");
}, "~S");
Clazz.defineMethod (c$, "clearTestProviderEnabled", 
function (provider) {
console.log("Missing method: clearTestProviderEnabled");
}, "~S");
c$.$LocationManager$ListenerTransport$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mListener = null;
this.mListenerHandler = null;
this.singleShot = true;
Clazz.instantialize (this, arguments);
}, android.location.LocationManager, "ListenerTransport");
Clazz.makeConstructor (c$, 
function (a, b) {
this.mListener = a;
if (b == null) {
this.mListenerHandler = ((Clazz.isClassDefined ("android.location.LocationManager$ListenerTransport$1") ? 0 : android.location.LocationManager.ListenerTransport.$LocationManager$ListenerTransport$1$ ()), Clazz.innerTypeInstance (android.location.LocationManager$ListenerTransport$1, this, null));
} else {
this.mListenerHandler = ((Clazz.isClassDefined ("android.location.LocationManager$ListenerTransport$2") ? 0 : android.location.LocationManager.ListenerTransport.$LocationManager$ListenerTransport$2$ ()), Clazz.innerTypeInstance (android.location.LocationManager$ListenerTransport$2, this, null, b));
}}, "android.location.LocationListener,android.os.Looper");
Clazz.defineMethod (c$, "onLocationChanged", 
function (a) {
var b = android.os.Message.obtain ();
b.what = 1;
b.obj = a;
this.mListenerHandler.sendMessage (b);
}, "android.location.Location");
Clazz.defineMethod (c$, "onStatusChanged", 
function (a, b, c) {
var d = android.os.Message.obtain ();
d.what = 2;
var e =  new android.os.Bundle ();
e.putString ("provider", a);
e.putInt ("status", b);
if (c != null) {
e.putBundle ("extras", c);
}d.obj = e;
this.mListenerHandler.sendMessage (d);
}, "~S,~N,android.os.Bundle");
Clazz.defineMethod (c$, "onProviderEnabled", 
function (a) {
var b = android.os.Message.obtain ();
b.what = 3;
b.obj = a;
this.mListenerHandler.sendMessage (b);
}, "~S");
Clazz.defineMethod (c$, "onProviderDisabled", 
function (a) {
var b = android.os.Message.obtain ();
b.what = 4;
b.obj = a;
this.mListenerHandler.sendMessage (b);
}, "~S");
Clazz.defineMethod (c$, "_handleMessage", 
($fz = function (a) {
switch (a.what) {
case 1:
var b =  new android.location.Location (a.obj);
this.mListener.onLocationChanged (b);
break;
case 2:
var c = a.obj;
var d = c.getString ("provider");
var e = c.getInt ("status");
var f = c.getBundle ("extras");
this.mListener.onStatusChanged (d, e, f);
break;
case 3:
this.mListener.onProviderEnabled (a.obj);
break;
case 4:
this.mListener.onProviderDisabled (a.obj);
break;
}
}, $fz.isPrivate = true, $fz), "android.os.Message");
c$.$LocationManager$ListenerTransport$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.location, "LocationManager$ListenerTransport$1", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
this.b$["android.location.LocationManager.ListenerTransport"]._handleMessage (a);
}, "android.os.Message");
c$ = Clazz.p0p ();
};
c$.$LocationManager$ListenerTransport$2$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.location, "LocationManager$ListenerTransport$2", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
this.b$["android.location.LocationManager.ListenerTransport"]._handleMessage (a);
}, "android.os.Message");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"TYPE_LOCATION_CHANGED", 1,
"TYPE_STATUS_CHANGED", 2,
"TYPE_PROVIDER_ENABLED", 3,
"TYPE_PROVIDER_DISABLED", 4);
c$ = Clazz.p0p ();
};
c$.$LocationManager$IntentTransport$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mListenerHandler = null;
this.singleShot = true;
this.mPendingIntent = null;
Clazz.instantialize (this, arguments);
}, android.location.LocationManager, "IntentTransport");
Clazz.makeConstructor (c$, 
function (a) {
this.mPendingIntent = a;
this.mListenerHandler = ((Clazz.isClassDefined ("android.location.LocationManager$IntentTransport$1") ? 0 : android.location.LocationManager.IntentTransport.$LocationManager$IntentTransport$1$ ()), Clazz.innerTypeInstance (android.location.LocationManager$IntentTransport$1, this, null));
}, "android.app.PendingIntent");
Clazz.defineMethod (c$, "onLocationChanged", 
function (a) {
var b = android.os.Message.obtain ();
b.what = 1;
b.obj = a;
this.mListenerHandler.sendMessage (b);
}, "android.location.Location");
Clazz.defineMethod (c$, "onStatusChanged", 
function (a, b, c) {
var d = android.os.Message.obtain ();
d.what = 2;
var e =  new android.os.Bundle ();
e.putString ("provider", a);
e.putInt ("status", b);
if (c != null) {
e.putBundle ("extras", c);
}d.obj = e;
this.mListenerHandler.sendMessage (d);
}, "~S,~N,android.os.Bundle");
Clazz.defineMethod (c$, "onProviderEnabled", 
function (a) {
var b = android.os.Message.obtain ();
b.what = 3;
b.obj = a;
this.mListenerHandler.sendMessage (b);
}, "~S");
Clazz.defineMethod (c$, "onProviderDisabled", 
function (a) {
var b = android.os.Message.obtain ();
b.what = 4;
b.obj = a;
this.mListenerHandler.sendMessage (b);
}, "~S");
Clazz.defineMethod (c$, "_handleMessage", 
($fz = function (a) {
switch (a.what) {
case 1:
var b =  new android.location.Location (a.obj);
var c = this.mPendingIntent.mIntent;
c.putExtra ("location", b);
this.mPendingIntent.send ();
break;
case 2:
var d = a.obj;
var e = d.getString ("provider");
var f = d.getInt ("status");
var g = d.getBundle ("extras");
break;
case 3:
break;
case 4:
break;
}
}, $fz.isPrivate = true, $fz), "android.os.Message");
c$.$LocationManager$IntentTransport$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.location, "LocationManager$IntentTransport$1", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
this.b$["android.location.LocationManager.IntentTransport"]._handleMessage (a);
}, "android.os.Message");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"TYPE_LOCATION_CHANGED", 1,
"TYPE_STATUS_CHANGED", 2,
"TYPE_PROVIDER_ENABLED", 3,
"TYPE_PROVIDER_DISABLED", 4);
c$ = Clazz.p0p ();
};
c$.$LocationManager$AlertTransport$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.startLatitude = 0;
this.startLongitude = 0;
this.radius = 0;
this.expiration = 0;
this.mPendingIntent = null;
Clazz.instantialize (this, arguments);
}, android.location.LocationManager, "AlertTransport");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e) {
this.startLatitude = a;
this.startLongitude = b;
this.radius = c;
this.expiration = d;
this.mPendingIntent = e;
}, "~N,~N,~N,~N,android.app.PendingIntent");
Clazz.defineMethod (c$, "alert", 
function (a) {
if (a == null) return ;
var b = System.currentTimeMillis ();
if (this.expiration != -1) {
if (b > this.expiration) {
android.location.LocationManager.mAlerts.remove (this.mPendingIntent);
}} else {
var c =  Clazz.newArray (1, 0);
android.location.Location.distanceBetween (this.startLatitude, this.startLongitude, a.getLatitude (), a.getLongitude (), c);
var d = this.mPendingIntent.mIntent;
if (this.radius >= c[0]) {
d.putExtra ("entering", true);
} else {
d.putExtra ("entering", false);
}this.mPendingIntent.send ();
}}, "android.location.Location");
c$ = Clazz.p0p ();
};
c$.$LocationManager$Position$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.coords = null;
this.timestamp = null;
if (!Clazz.isClassDefined ("android.location.LocationManager.Position.Coordinates")) {
android.location.LocationManager.Position.$LocationManager$Position$Coordinates$ ();
}
Clazz.instantialize (this, arguments);
}, android.location.LocationManager, "Position");
c$.$LocationManager$Position$Coordinates$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.latitude = 0;
this.longitude = 0;
this.altitude = 0;
this.accuracy = 0;
this.altitudeAccuracy = 0;
this.heading = 0;
this.speed = 0;
Clazz.instantialize (this, arguments);
}, android.location.LocationManager.Position, "Coordinates");
c$ = Clazz.p0p ();
};
c$ = Clazz.p0p ();
};
c$.$LocationManager$PositionError$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.code = 0;
this.message = null;
Clazz.instantialize (this, arguments);
}, android.location.LocationManager, "PositionError");
Clazz.defineStatics (c$,
"PERMISSION_DENIED", 1,
"POSITION_UNAVAILABLE", 2,
"TIMEOUT", 3);
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"TAG", "LocationManager>>>>",
"NETWORK_PROVIDER", "network",
"GPS_PROVIDER", "gps",
"PASSIVE_PROVIDER", "passive",
"KEY_PROXIMITY_ENTERING", "entering",
"KEY_STATUS_CHANGED", "status",
"KEY_PROVIDER_ENABLED", "providerEnabled",
"KEY_LOCATION_CHANGED", "location",
"GPS_ENABLED_CHANGE_ACTION", "android.location.GPS_ENABLED_CHANGE",
"PROVIDERS_CHANGED_ACTION", "android.location.PROVIDERS_CHANGED",
"GPS_FIX_CHANGE_ACTION", "android.location.GPS_FIX_CHANGE",
"EXTRA_GPS_ENABLED", "enabled",
"isEnableGeoLocation", false);
c$.mListeners = c$.prototype.mListeners =  new java.util.HashMap ();
c$.mIntents = c$.prototype.mIntents =  new java.util.HashMap ();
c$.mAlerts = c$.prototype.mAlerts =  new java.util.HashMap ();
c$.providers = c$.prototype.providers =  new java.util.ArrayList ();
Clazz.defineStatics (c$,
"PERMISSION_DENIED", false);
{
android.location.LocationManager.providers.add ("gps");
android.location.LocationManager.providers.add ("network");
}});
