﻿Clazz.declarePackage ("android.location");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator", "java.util.Locale"], "android.location.GeocoderParams", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mLocale = null;
this.mPackageName = null;
Clazz.instantialize (this, arguments);
}, android.location, "GeocoderParams", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
($fz = function () {
}, $fz.isPrivate = true, $fz));
Clazz.makeConstructor (c$, 
function (context, locale) {
this.mLocale = locale;
this.mPackageName = context.getPackageName ();
}, "android.content.Context,java.util.Locale");
Clazz.defineMethod (c$, "getLocale", 
function () {
return this.mLocale;
});
Clazz.defineMethod (c$, "getClientPackage", 
function () {
return this.mPackageName;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (parcel, flags) {
parcel.writeString (this.mLocale.getLanguage ());
parcel.writeString (this.mLocale.getCountry ());
parcel.writeString (this.mLocale.getVariant ());
parcel.writeString (this.mPackageName);
}, "android.os.Parcel,~N");
c$.$GeocoderParams$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.location, "GeocoderParams$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
var gp =  new android.location.GeocoderParams ();
var language = $in.readString ();
var country = $in.readString ();
var variant = $in.readString ();
gp.mLocale =  new java.util.Locale (language, country, variant);
gp.mPackageName = $in.readString ();
return gp;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.location.GeocoderParams$1") ? 0 : android.location.GeocoderParams.$GeocoderParams$1$ ()), Clazz.innerTypeInstance (android.location.GeocoderParams$1, this, null));
});
