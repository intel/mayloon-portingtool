﻿Clazz.declarePackage ("android.location");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.location.Location", ["android.os.Bundle", "java.lang.Double", "$.IllegalArgumentException", "$.NullPointerException", "$.StringBuilder", "java.text.DecimalFormat", "java.util.StringTokenizer"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mProvider = null;
this.mTime = 0;
this.mLatitude = 0.0;
this.mLongitude = 0.0;
this.mHasAltitude = false;
this.mAltitude = 0.0;
this.mHasSpeed = false;
this.mSpeed = 0.0;
this.mHasBearing = false;
this.mBearing = 0.0;
this.mHasAccuracy = false;
this.mAccuracy = 0.0;
this.mExtras = null;
this.mLat1 = 0.0;
this.mLon1 = 0.0;
this.mLat2 = 0.0;
this.mLon2 = 0.0;
this.mDistance = 0.0;
this.mInitialBearing = 0.0;
this.mResults = null;
Clazz.instantialize (this, arguments);
}, android.location, "Location", null, android.os.Parcelable);
Clazz.prepareFields (c$, function () {
this.mResults =  Clazz.newArray (2, 0);
});
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
pw.println (prefix + "mProvider=" + this.mProvider + " mTime=" + this.mTime);
pw.println (prefix + "mLatitude=" + this.mLatitude + " mLongitude=" + this.mLongitude);
pw.println (prefix + "mHasAltitude=" + this.mHasAltitude + " mAltitude=" + this.mAltitude);
pw.println (prefix + "mHasSpeed=" + this.mHasSpeed + " mSpeed=" + this.mSpeed);
pw.println (prefix + "mHasBearing=" + this.mHasBearing + " mBearing=" + this.mBearing);
pw.println (prefix + "mHasAccuracy=" + this.mHasAccuracy + " mAccuracy=" + this.mAccuracy);
pw.println (prefix + "mExtras=" + this.mExtras);
}, "android.util.Printer,~S");
Clazz.makeConstructor (c$, 
function (provider) {
this.mProvider = provider;
}, "~S");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (l) {
this.set (l);
}, "android.location.Location");
Clazz.defineMethod (c$, "set", 
function (l) {
this.mProvider = l.mProvider;
this.mTime = l.mTime;
this.mLatitude = l.mLatitude;
this.mLongitude = l.mLongitude;
this.mHasAltitude = l.mHasAltitude;
this.mAltitude = l.mAltitude;
this.mHasSpeed = l.mHasSpeed;
this.mSpeed = l.mSpeed;
this.mHasBearing = l.mHasBearing;
this.mBearing = l.mBearing;
this.mHasAccuracy = l.mHasAccuracy;
this.mAccuracy = l.mAccuracy;
this.mExtras = (l.mExtras == null) ? null :  new android.os.Bundle (l.mExtras);
}, "android.location.Location");
Clazz.defineMethod (c$, "reset", 
function () {
this.mProvider = null;
this.mTime = 0;
this.mLatitude = 0;
this.mLongitude = 0;
this.mHasAltitude = false;
this.mAltitude = 0;
this.mHasSpeed = false;
this.mSpeed = 0;
this.mHasBearing = false;
this.mBearing = 0;
this.mHasAccuracy = false;
this.mAccuracy = 0;
this.mExtras = null;
});
c$.convert = Clazz.defineMethod (c$, "convert", 
function (coordinate, outputType) {
if (coordinate < -180.0 || coordinate > 180.0 || Double.isNaN (coordinate)) {
throw  new IllegalArgumentException ("coordinate=" + coordinate);
}if ((outputType != 0) && (outputType != 1) && (outputType != 2)) {
throw  new IllegalArgumentException ("outputType=" + outputType);
}var sb =  new StringBuilder ();
if (coordinate < 0) {
sb.append ('-');
coordinate = -coordinate;
}var df =  new java.text.DecimalFormat ("###.#####");
if (outputType == 1 || outputType == 2) {
var degrees = Math.round (Math.floor (coordinate));
sb.append (degrees);
sb.append (':');
coordinate -= degrees;
coordinate *= 60.0;
if (outputType == 2) {
var minutes = Math.round (Math.floor (coordinate));
sb.append (minutes);
sb.append (':');
coordinate -= minutes;
coordinate *= 60.0;
}}sb.append (df.format (coordinate));
return sb.toString ();
}, "~N,~N");
c$.convert = Clazz.defineMethod (c$, "convert", 
function (coordinate) {
if (coordinate == null) {
throw  new NullPointerException ("coordinate");
}var negative = false;
if ((coordinate.charAt (0)).charCodeAt (0) == ('-').charCodeAt (0)) {
coordinate = coordinate.substring (1);
negative = true;
}var st =  new java.util.StringTokenizer (coordinate, ":");
var tokens = st.countTokens ();
if (tokens < 1) {
throw  new IllegalArgumentException ("coordinate=" + coordinate);
}try {
var degrees = st.nextToken ();
var val;
if (tokens == 1) {
val = Double.parseDouble (degrees);
return negative ? -val : val;
}var minutes = st.nextToken ();
var deg = Integer.parseInt (degrees);
var min;
var sec = 0.0;
if (st.hasMoreTokens ()) {
min = Integer.parseInt (minutes);
var seconds = st.nextToken ();
sec = Double.parseDouble (seconds);
} else {
min = Double.parseDouble (minutes);
}var isNegative180 = negative && (deg == 180) && (min == 0) && (sec == 0);
if ((deg < 0.0) || (deg > 179 && !isNegative180)) {
throw  new IllegalArgumentException ("coordinate=" + coordinate);
}if (min < 0 || min > 59) {
throw  new IllegalArgumentException ("coordinate=" + coordinate);
}if (sec < 0 || sec > 59) {
throw  new IllegalArgumentException ("coordinate=" + coordinate);
}val = deg * 3600.0 + min * 60.0 + sec;
val /= 3600.0;
return negative ? -val : val;
} catch (nfe) {
if (Clazz.instanceOf (nfe, NumberFormatException)) {
throw  new IllegalArgumentException ("coordinate=" + coordinate);
} else {
throw nfe;
}
}
}, "~S");
c$.computeDistanceAndBearing = Clazz.defineMethod (c$, "computeDistanceAndBearing", 
($fz = function (lat1, lon1, lat2, lon2, results) {
var MAXITERS = 20;
lat1 *= 0.017453292519943295;
lat2 *= 0.017453292519943295;
lon1 *= 0.017453292519943295;
lon2 *= 0.017453292519943295;
var a = 6378137.0;
var b = 6356752.3142;
var f = (a - b) / a;
var aSqMinusBSqOverBSq = (a * a - b * b) / (b * b);
var L = lon2 - lon1;
var A = 0.0;
var U1 = Math.atan ((1.0 - f) * Math.tan (lat1));
var U2 = Math.atan ((1.0 - f) * Math.tan (lat2));
var cosU1 = Math.cos (U1);
var cosU2 = Math.cos (U2);
var sinU1 = Math.sin (U1);
var sinU2 = Math.sin (U2);
var cosU1cosU2 = cosU1 * cosU2;
var sinU1sinU2 = sinU1 * sinU2;
var sigma = 0.0;
var deltaSigma = 0.0;
var cosSqAlpha = 0.0;
var cos2SM = 0.0;
var cosSigma = 0.0;
var sinSigma = 0.0;
var cosLambda = 0.0;
var sinLambda = 0.0;
var lambda = L;
for (var iter = 0; iter < MAXITERS; iter++) {
var lambdaOrig = lambda;
cosLambda = Math.cos (lambda);
sinLambda = Math.sin (lambda);
var t1 = cosU2 * sinLambda;
var t2 = cosU1 * sinU2 - sinU1 * cosU2 * cosLambda;
var sinSqSigma = t1 * t1 + t2 * t2;
sinSigma = Math.sqrt (sinSqSigma);
cosSigma = sinU1sinU2 + cosU1cosU2 * cosLambda;
sigma = Math.atan2 (sinSigma, cosSigma);
var sinAlpha = (sinSigma == 0) ? 0.0 : cosU1cosU2 * sinLambda / sinSigma;
cosSqAlpha = 1.0 - sinAlpha * sinAlpha;
cos2SM = (cosSqAlpha == 0) ? 0.0 : cosSigma - 2.0 * sinU1sinU2 / cosSqAlpha;
var uSquared = cosSqAlpha * aSqMinusBSqOverBSq;
A = 1 + (uSquared / 16384.0) * (4096.0 + uSquared * (-768 + uSquared * (320.0 - 175.0 * uSquared)));
var B = (uSquared / 1024.0) * (256.0 + uSquared * (-128.0 + uSquared * (74.0 - 47.0 * uSquared)));
var C = (f / 16.0) * cosSqAlpha * (4.0 + f * (4.0 - 3.0 * cosSqAlpha));
var cos2SMSq = cos2SM * cos2SM;
deltaSigma = B * sinSigma * (cos2SM + (B / 4.0) * (cosSigma * (-1.0 + 2.0 * cos2SMSq) - (B / 6.0) * cos2SM * (-3.0 + 4.0 * sinSigma * sinSigma) * (-3.0 + 4.0 * cos2SMSq)));
lambda = L + (1.0 - C) * f * sinAlpha * (sigma + C * sinSigma * (cos2SM + C * cosSigma * (-1.0 + 2.0 * cos2SM * cos2SM)));
var delta = (lambda - lambdaOrig) / lambda;
if (Math.abs (delta) < 1.0e-12) {
break;
}}
var distance = (b * A * (sigma - deltaSigma));
results[0] = distance;
if (results.length > 1) {
var initialBearing = Math.atan2 (cosU2 * sinLambda, cosU1 * sinU2 - sinU1 * cosU2 * cosLambda);
initialBearing *= 57.29577951308232;
results[1] = initialBearing;
if (results.length > 2) {
var finalBearing = Math.atan2 (cosU1 * sinLambda, -sinU1 * cosU2 + cosU1 * sinU2 * cosLambda);
finalBearing *= 57.29577951308232;
results[2] = finalBearing;
}}}, $fz.isPrivate = true, $fz), "~N,~N,~N,~N,~A");
c$.distanceBetween = Clazz.defineMethod (c$, "distanceBetween", 
function (startLatitude, startLongitude, endLatitude, endLongitude, results) {
if (results == null || results.length < 1) {
throw  new IllegalArgumentException ("results is null or has length < 1");
}android.location.Location.computeDistanceAndBearing (startLatitude, startLongitude, endLatitude, endLongitude, results);
}, "~N,~N,~N,~N,~A");
Clazz.defineMethod (c$, "distanceTo", 
function (dest) {
{
if (this.mLatitude != this.mLat1 || this.mLongitude != this.mLon1 || dest.mLatitude != this.mLat2 || dest.mLongitude != this.mLon2) {
android.location.Location.computeDistanceAndBearing (this.mLatitude, this.mLongitude, dest.mLatitude, dest.mLongitude, this.mResults);
this.mLat1 = this.mLatitude;
this.mLon1 = this.mLongitude;
this.mLat2 = dest.mLatitude;
this.mLon2 = dest.mLongitude;
this.mDistance = this.mResults[0];
this.mInitialBearing = this.mResults[1];
}return this.mDistance;
}}, "android.location.Location");
Clazz.defineMethod (c$, "bearingTo", 
function (dest) {
{
if (this.mLatitude != this.mLat1 || this.mLongitude != this.mLon1 || dest.mLatitude != this.mLat2 || dest.mLongitude != this.mLon2) {
android.location.Location.computeDistanceAndBearing (this.mLatitude, this.mLongitude, dest.mLatitude, dest.mLongitude, this.mResults);
this.mLat1 = this.mLatitude;
this.mLon1 = this.mLongitude;
this.mLat2 = dest.mLatitude;
this.mLon2 = dest.mLongitude;
this.mDistance = this.mResults[0];
this.mInitialBearing = this.mResults[1];
}return this.mInitialBearing;
}}, "android.location.Location");
Clazz.defineMethod (c$, "getProvider", 
function () {
return this.mProvider;
});
Clazz.defineMethod (c$, "setProvider", 
function (provider) {
this.mProvider = provider;
}, "~S");
Clazz.defineMethod (c$, "getTime", 
function () {
return this.mTime;
});
Clazz.defineMethod (c$, "setTime", 
function (time) {
this.mTime = time;
}, "~N");
Clazz.defineMethod (c$, "getLatitude", 
function () {
return this.mLatitude;
});
Clazz.defineMethod (c$, "setLatitude", 
function (latitude) {
this.mLatitude = latitude;
}, "~N");
Clazz.defineMethod (c$, "getLongitude", 
function () {
return this.mLongitude;
});
Clazz.defineMethod (c$, "setLongitude", 
function (longitude) {
this.mLongitude = longitude;
}, "~N");
Clazz.defineMethod (c$, "hasAltitude", 
function () {
return this.mHasAltitude;
});
Clazz.defineMethod (c$, "getAltitude", 
function () {
return this.mAltitude;
});
Clazz.defineMethod (c$, "setAltitude", 
function (altitude) {
this.mAltitude = altitude;
this.mHasAltitude = true;
}, "~N");
Clazz.defineMethod (c$, "removeAltitude", 
function () {
this.mAltitude = 0.0;
this.mHasAltitude = false;
});
Clazz.defineMethod (c$, "hasSpeed", 
function () {
return this.mHasSpeed;
});
Clazz.defineMethod (c$, "getSpeed", 
function () {
return this.mSpeed;
});
Clazz.defineMethod (c$, "setSpeed", 
function (speed) {
this.mSpeed = speed;
this.mHasSpeed = true;
}, "~N");
Clazz.defineMethod (c$, "removeSpeed", 
function () {
this.mSpeed = 0.0;
this.mHasSpeed = false;
});
Clazz.defineMethod (c$, "hasBearing", 
function () {
return this.mHasBearing;
});
Clazz.defineMethod (c$, "getBearing", 
function () {
return this.mBearing;
});
Clazz.defineMethod (c$, "setBearing", 
function (bearing) {
while (bearing < 0.0) {
bearing += 360.0;
}
while (bearing >= 360.0) {
bearing -= 360.0;
}
this.mBearing = bearing;
this.mHasBearing = true;
}, "~N");
Clazz.defineMethod (c$, "removeBearing", 
function () {
this.mBearing = 0.0;
this.mHasBearing = false;
});
Clazz.defineMethod (c$, "hasAccuracy", 
function () {
return this.mHasAccuracy;
});
Clazz.defineMethod (c$, "getAccuracy", 
function () {
return this.mAccuracy;
});
Clazz.defineMethod (c$, "setAccuracy", 
function (accuracy) {
this.mAccuracy = accuracy;
this.mHasAccuracy = true;
}, "~N");
Clazz.defineMethod (c$, "removeAccuracy", 
function () {
this.mAccuracy = 0.0;
this.mHasAccuracy = false;
});
Clazz.defineMethod (c$, "getExtras", 
function () {
return this.mExtras;
});
Clazz.defineMethod (c$, "setExtras", 
function (extras) {
this.mExtras = (extras == null) ? null :  new android.os.Bundle (extras);
}, "android.os.Bundle");
Clazz.overrideMethod (c$, "toString", 
function () {
return "Location[mProvider=" + this.mProvider + ",mTime=" + this.mTime + ",mLatitude=" + this.mLatitude + ",mLongitude=" + this.mLongitude + ",mHasAltitude=" + this.mHasAltitude + ",mAltitude=" + this.mAltitude + ",mHasSpeed=" + this.mHasSpeed + ",mSpeed=" + this.mSpeed + ",mHasBearing=" + this.mHasBearing + ",mBearing=" + this.mBearing + ",mHasAccuracy=" + this.mHasAccuracy + ",mAccuracy=" + this.mAccuracy + ",mExtras=" + this.mExtras + "]";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (parcel, flags) {
parcel.writeString (this.mProvider);
parcel.writeLong (this.mTime);
parcel.writeDouble (this.mLatitude);
parcel.writeDouble (this.mLongitude);
parcel.writeInt (this.mHasAltitude ? 1 : 0);
parcel.writeDouble (this.mAltitude);
parcel.writeInt (this.mHasSpeed ? 1 : 0);
parcel.writeFloat (this.mSpeed);
parcel.writeInt (this.mHasBearing ? 1 : 0);
parcel.writeFloat (this.mBearing);
parcel.writeInt (this.mHasAccuracy ? 1 : 0);
parcel.writeFloat (this.mAccuracy);
parcel.writeBundle (this.mExtras);
}, "android.os.Parcel,~N");
c$.$Location$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.location, "Location$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
var provider = $in.readString ();
var l =  new android.location.Location (provider);
l.mTime = $in.readLong ();
l.mLatitude = $in.readDouble ();
l.mLongitude = $in.readDouble ();
l.mHasAltitude = $in.readInt () != 0;
l.mAltitude = $in.readDouble ();
l.mHasSpeed = $in.readInt () != 0;
l.mSpeed = $in.readFloat ();
l.mHasBearing = $in.readInt () != 0;
l.mBearing = $in.readFloat ();
l.mHasAccuracy = $in.readInt () != 0;
l.mAccuracy = $in.readFloat ();
l.mExtras = $in.readBundle ();
return l;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"FORMAT_DEGREES", 0,
"FORMAT_MINUTES", 1,
"FORMAT_SECONDS", 2);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.location.Location$1") ? 0 : android.location.Location.$Location$1$ ()), Clazz.innerTypeInstance (android.location.Location$1, this, null));
});
