﻿Clazz.declarePackage ("android.text");
Clazz.load (null, "android.text.SpannableStringInternal", ["android.text.SpanWatcher", "com.android.internal.util.ArrayUtils", "java.lang.IndexOutOfBoundsException", "$.RuntimeException", "java.lang.reflect.Array"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mText = null;
this.mSpans = null;
this.mSpanData = null;
this.mSpanCount = 0;
Clazz.instantialize (this, arguments);
}, android.text, "SpannableStringInternal");
Clazz.makeConstructor (c$, 
function (source, start, end) {
if (start == 0 && end == source.toString ().length) this.mText = source.toString ();
 else this.mText = source.toString ().substring (start, end);
var initial = com.android.internal.util.ArrayUtils.idealIntArraySize (0);
this.mSpans =  new Array (initial);
this.mSpanData =  Clazz.newArray (initial * 3, 0);
if (Clazz.instanceOf (source, android.text.Spanned)) {
var sp = source;
var spans = sp.getSpans (start, end, JavaObject);
for (var i = 0; i < spans.length; i++) {
var st = sp.getSpanStart (spans[i]);
var en = sp.getSpanEnd (spans[i]);
var fl = sp.getSpanFlags (spans[i]);
if (st < start) st = start;
if (en > end) en = end;
this.setSpan (spans[i], st - start, en - start, fl);
}
}}, "CharSequence,~N,~N");
Clazz.defineMethod (c$, "length", 
function () {
return this.mText.length;
});
Clazz.defineMethod (c$, "charAt", 
function (i) {
return this.mText.charAt (i);
}, "~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return this.mText;
});
Clazz.defineMethod (c$, "getChars", 
function (start, end, dest, off) {
this.mText.getChars (start, end, dest, off);
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "setSpan", 
function (what, start, end, flags) {
var nstart = start;
var nend = end;
this.checkRange ("setSpan", start, end);
if ((flags & 51) == 51) {
if (start != 0 && start != this.length ()) {
var c = this.charAt (start - 1);
if ((c).charCodeAt (0) != ('\n').charCodeAt (0)) throw  new RuntimeException ("PARAGRAPH span must start at paragraph boundary (" + start + " follows " + c + ")");
}if (end != 0 && end != this.length ()) {
var c = this.charAt (end - 1);
if ((c).charCodeAt (0) != ('\n').charCodeAt (0)) throw  new RuntimeException ("PARAGRAPH span must end at paragraph boundary (" + end + " follows " + c + ")");
}}var count = this.mSpanCount;
var spans = this.mSpans;
var data = this.mSpanData;
for (var i = 0; i < count; i++) {
if (spans[i] === what) {
var ostart = data[i * 3 + 0];
var oend = data[i * 3 + 1];
data[i * 3 + 0] = start;
data[i * 3 + 1] = end;
data[i * 3 + 2] = flags;
this.sendSpanChanged (what, ostart, oend, nstart, nend);
return ;
}}
if (this.mSpanCount + 1 >= this.mSpans.length) {
var newsize = com.android.internal.util.ArrayUtils.idealIntArraySize (this.mSpanCount + 1);
var newtags =  new Array (newsize);
var newdata =  Clazz.newArray (newsize * 3, 0);
System.arraycopy (this.mSpans, 0, newtags, 0, this.mSpanCount);
System.arraycopy (this.mSpanData, 0, newdata, 0, this.mSpanCount * 3);
this.mSpans = newtags;
this.mSpanData = newdata;
}this.mSpans[this.mSpanCount] = what;
this.mSpanData[this.mSpanCount * 3 + 0] = start;
this.mSpanData[this.mSpanCount * 3 + 1] = end;
this.mSpanData[this.mSpanCount * 3 + 2] = flags;
this.mSpanCount++;
if (Clazz.instanceOf (this, android.text.Spannable)) this.sendSpanAdded (what, nstart, nend);
}, "~O,~N,~N,~N");
Clazz.defineMethod (c$, "removeSpan", 
function (what) {
var count = this.mSpanCount;
var spans = this.mSpans;
var data = this.mSpanData;
for (var i = count - 1; i >= 0; i--) {
if (spans[i] === what) {
var ostart = data[i * 3 + 0];
var oend = data[i * 3 + 1];
var c = count - (i + 1);
System.arraycopy (spans, i + 1, spans, i, c);
System.arraycopy (data, (i + 1) * 3, data, i * 3, c * 3);
this.mSpanCount--;
this.sendSpanRemoved (what, ostart, oend);
return ;
}}
}, "~O");
Clazz.defineMethod (c$, "getSpanStart", 
function (what) {
var count = this.mSpanCount;
var spans = this.mSpans;
var data = this.mSpanData;
for (var i = count - 1; i >= 0; i--) {
if (spans[i] === what) {
return data[i * 3 + 0];
}}
return -1;
}, "~O");
Clazz.defineMethod (c$, "getSpanEnd", 
function (what) {
var count = this.mSpanCount;
var spans = this.mSpans;
var data = this.mSpanData;
for (var i = count - 1; i >= 0; i--) {
if (spans[i] === what) {
return data[i * 3 + 1];
}}
return -1;
}, "~O");
Clazz.defineMethod (c$, "getSpanFlags", 
function (what) {
var count = this.mSpanCount;
var spans = this.mSpans;
var data = this.mSpanData;
for (var i = count - 1; i >= 0; i--) {
if (spans[i] === what) {
return data[i * 3 + 2];
}}
return 0;
}, "~O");
Clazz.defineMethod (c$, "getSpans", 
function (queryStart, queryEnd, kind) {
var count = 0;
var spanCount = this.mSpanCount;
var spans = this.mSpans;
var data = this.mSpanData;
var ret = null;
var ret1 = null;
for (var i = 0; i < spanCount; i++) {
var spanStart = data[i * 3 + 0];
var spanEnd = data[i * 3 + 1];
if (spanStart > queryEnd) {
continue ;}if (spanEnd < queryStart) {
continue ;}if (spanStart != spanEnd && queryStart != queryEnd) {
if (spanStart == queryEnd) {
continue ;}if (spanEnd == queryStart) {
continue ;}}if (kind != null && !kind.isInstance (spans[i])) {
continue ;}if (count == 0) {
ret1 = spans[i];
count++;
} else {
if (count == 1) {
ret = java.lang.reflect.Array.newInstance (kind, spanCount - i + 1);
ret[0] = ret1;
}var prio = data[i * 3 + 2] & 16711680;
if (prio != 0) {
var j;
for (j = 0; j < count; j++) {
var p = this.getSpanFlags (ret[j]) & 16711680;
if (prio > p) {
break;
}}
System.arraycopy (ret, j, ret, j + 1, count - j);
ret[j] = spans[i];
count++;
} else {
ret[count++] = spans[i];
}}}
if (count == 0) {
return com.android.internal.util.ArrayUtils.emptyArray (kind);
}if (count == 1) {
ret = java.lang.reflect.Array.newInstance (kind, 1);
ret[0] = ret1;
return ret;
}if (count == ret.length) {
return ret;
}var nret = java.lang.reflect.Array.newInstance (kind, count);
System.arraycopy (ret, 0, nret, 0, count);
return nret;
}, "~N,~N,Class");
Clazz.defineMethod (c$, "nextSpanTransition", 
function (start, limit, kind) {
var count = this.mSpanCount;
var spans = this.mSpans;
var data = this.mSpanData;
if (kind == null) {
kind = JavaObject;
}for (var i = 0; i < count; i++) {
var st = data[i * 3 + 0];
var en = data[i * 3 + 1];
if (st > start && st < limit && kind.isInstance (spans[i])) limit = st;
if (en > start && en < limit && kind.isInstance (spans[i])) limit = en;
}
return limit;
}, "~N,~N,Class");
Clazz.defineMethod (c$, "sendSpanAdded", 
($fz = function (what, start, end) {
var recip = this.getSpans (start, end, android.text.SpanWatcher);
var n = recip.length;
for (var i = 0; i < n; i++) {
recip[i].onSpanAdded (this, what, start, end);
}
}, $fz.isPrivate = true, $fz), "~O,~N,~N");
Clazz.defineMethod (c$, "sendSpanRemoved", 
($fz = function (what, start, end) {
var recip = this.getSpans (start, end, android.text.SpanWatcher);
var n = recip.length;
for (var i = 0; i < n; i++) {
recip[i].onSpanRemoved (this, what, start, end);
}
}, $fz.isPrivate = true, $fz), "~O,~N,~N");
Clazz.defineMethod (c$, "sendSpanChanged", 
($fz = function (what, s, e, st, en) {
var recip = this.getSpans (Math.min (s, st), Math.max (e, en), android.text.SpanWatcher);
var n = recip.length;
for (var i = 0; i < n; i++) {
recip[i].onSpanChanged (this, what, s, e, st, en);
}
}, $fz.isPrivate = true, $fz), "~O,~N,~N,~N,~N");
c$.region = Clazz.defineMethod (c$, "region", 
($fz = function (start, end) {
return "(" + start + " ... " + end + ")";
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "checkRange", 
($fz = function (operation, start, end) {
if (end < start) {
throw  new IndexOutOfBoundsException (operation + " " + android.text.SpannableStringInternal.region (start, end) + " has end before start");
}var len = this.length ();
if (start > len || end > len) {
throw  new IndexOutOfBoundsException (operation + " " + android.text.SpannableStringInternal.region (start, end) + " ends beyond length " + len);
}if (start < 0 || end < 0) {
throw  new IndexOutOfBoundsException (operation + " " + android.text.SpannableStringInternal.region (start, end) + " starts before 0");
}}, $fz.isPrivate = true, $fz), "~S,~N,~N");
c$.EMPTY = c$.prototype.EMPTY =  new Array (0);
Clazz.defineStatics (c$,
"START", 0,
"END", 1,
"FLAGS", 2,
"COLUMNS", 3);
});
