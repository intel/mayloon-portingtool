﻿Clazz.declarePackage ("android.text");
c$ = Clazz.declareType (android.text, "AndroidCharacter");
Clazz.defineStatics (c$,
"EAST_ASIAN_WIDTH_NEUTRAL", 0,
"EAST_ASIAN_WIDTH_AMBIGUOUS", 1,
"EAST_ASIAN_WIDTH_HALF_WIDTH", 2,
"EAST_ASIAN_WIDTH_FULL_WIDTH", 3,
"EAST_ASIAN_WIDTH_NARROW", 4,
"EAST_ASIAN_WIDTH_WIDE", 5);
