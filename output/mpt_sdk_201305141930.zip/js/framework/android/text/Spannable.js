﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.text.Spanned"], "android.text.Spannable", null, function () {
Clazz.declareInterface (android.text, "Spannable", android.text.Spanned);
Clazz.pu$h ();
c$ = Clazz.declareType (android.text.Spannable, "Factory");
c$.getInstance = Clazz.defineMethod (c$, "getInstance", 
function () {
return android.text.Spannable.Factory.sInstance;
});
Clazz.defineMethod (c$, "newSpannable", 
function (a) {
return  new android.text.SpannableString (a);
}, "CharSequence");
c$.sInstance = c$.prototype.sInstance =  new android.text.Spannable.Factory ();
c$ = Clazz.p0p ();
});
