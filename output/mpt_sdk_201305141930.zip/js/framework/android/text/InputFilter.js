﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.text.SpannableString", "$.TextUtils", "java.lang.Character"], "android.text.InputFilter", null, function () {
Clazz.declareInterface (android.text, "InputFilter");
Clazz.pu$h ();
c$ = Clazz.declareType (android.text.InputFilter, "AllCaps", null, android.text.InputFilter);
Clazz.overrideMethod (c$, "filter", 
function (a, b, c, d, e, f) {
for (var g = b; g < c; g++) {
if (Character.isLowerCase (a.charAt (g))) {
var h =  Clazz.newArray (c - b, '\0');
android.text.TextUtils.getChars (a, b, c, h, 0);
var i =  String.instantialize (h).toUpperCase ();
if (Clazz.instanceOf (a, android.text.Spanned)) {
var j =  new android.text.SpannableString (i);
android.text.TextUtils.copySpansFrom (a, b, c, null, j, 0);
return j;
} else {
return i;
}}}
return null;
}, "CharSequence,~N,~N,android.text.Spanned,~N,~N");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mMax = 0;
Clazz.instantialize (this, arguments);
}, android.text.InputFilter, "LengthFilter", null, android.text.InputFilter);
Clazz.makeConstructor (c$, 
function (a) {
this.mMax = a;
}, "~N");
Clazz.overrideMethod (c$, "filter", 
function (a, b, c, d, e, f) {
var g = this.mMax - (d.length () - (f - e));
if (g <= 0) {
return "";
} else if (g >= c - b) {
return null;
} else {
g += b;
if (Character.isHighSurrogate (a.charAt (g - 1))) {
--g;
if (g == b) {
return "";
}}return a.subSequence (b, g);
}}, "CharSequence,~N,~N,android.text.Spanned,~N,~N");
c$ = Clazz.p0p ();
});
