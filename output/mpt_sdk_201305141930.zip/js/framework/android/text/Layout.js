﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.text.GetChars", "$.Spanned", "java.lang.Enum", "android.emoji.EmojiFactory", "android.graphics.Rect", "android.text.style.ParagraphStyle", "com.android.internal.util.ArrayUtils"], "android.text.Layout", ["android.graphics.Path", "$.RectF", "android.text.SpannableString", "$.Styled", "$.TextPaint", "$.TextUtils", "android.text.style.AlignmentSpan", "$.LeadingMarginSpan", "$.LineBackgroundSpan", "$.ReplacementSpan", "$.TabStopSpan", "java.lang.Character", "$.IllegalArgumentException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mEmojiRect = null;
this.mText = null;
this.mPaint = null;
this.mWorkPaint = null;
this.mWidth = 0;
this.mAlignment = null;
this.mSpacingMult = 0;
this.mSpacingAdd = 0;
this.mSpannedText = false;
Clazz.instantialize (this, arguments);
}, android.text, "Layout");
Clazz.prepareFields (c$, function () {
this.mAlignment = android.text.Layout.Alignment.ALIGN_NORMAL;
});
c$.getDesiredWidth = Clazz.defineMethod (c$, "getDesiredWidth", 
function (source, paint) {
return android.text.Layout.getDesiredWidth (source, 0, source.length (), paint);
}, "CharSequence,android.text.TextPaint");
c$.getDesiredWidth = Clazz.defineMethod (c$, "getDesiredWidth", 
function (source, start, end, paint) {
var need = 0;
var workPaint =  new android.text.TextPaint ();
var next;
for (var i = start; i <= end; i = next) {
next = android.text.TextUtils.indexOf (source, '\n', i, end);
if (next < 0) next = end;
var w = android.text.Layout.measureText (paint, workPaint, source, i, next, null, true, null);
if (w > need) need = w;
next++;
}
return need;
}, "CharSequence,~N,~N,android.text.TextPaint");
Clazz.makeConstructor (c$, 
function (text, paint, width, align, spacingMult, spacingAdd) {
if (width < 0) throw  new IllegalArgumentException ("Layout: " + width + " < 0");
this.mText = text;
this.mPaint = paint;
this.mWorkPaint =  new android.text.TextPaint ();
this.mWidth = width;
this.mAlignment = align;
this.mSpacingMult = spacingMult;
this.mSpacingAdd = spacingAdd;
this.mSpannedText = Clazz.instanceOf (text, android.text.Spanned);
}, "CharSequence,android.text.TextPaint,~N,android.text.Layout.Alignment,~N,~N");
Clazz.defineMethod (c$, "replaceWith", 
function (text, paint, width, align, spacingmult, spacingadd) {
if (width < 0) {
throw  new IllegalArgumentException ("Layout: " + width + " < 0");
}this.mText = text;
this.mPaint = paint;
this.mWidth = width;
this.mAlignment = align;
this.mSpacingMult = spacingmult;
this.mSpacingAdd = spacingadd;
this.mSpannedText = Clazz.instanceOf (text, android.text.Spanned);
}, "CharSequence,android.text.TextPaint,~N,android.text.Layout.Alignment,~N,~N");
Clazz.defineMethod (c$, "draw", 
function (c) {
this.draw (c, null, null, 0);
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "draw", 
function (c, highlight, highlightPaint, cursorOffsetVertical) {
var dtop;
var dbottom;
{
if (!c.getClipBounds (android.text.Layout.sTempRect)) {
return ;
}dtop = android.text.Layout.sTempRect.top;
dbottom = android.text.Layout.sTempRect.bottom;
}var top = 0;
var bottom = this.getLineTop (this.getLineCount ());
if (dtop > top) {
top = dtop;
}if (dbottom < bottom) {
bottom = dbottom;
}var first = this.getLineForVertical (top);
var last = this.getLineForVertical (bottom);
var previousLineBottom = this.getLineTop (first);
var previousLineEnd = this.getLineStart (first);
var paint = this.mPaint;
var buf = this.mText;
var width = this.mWidth;
var spannedText = this.mSpannedText;
var spans = android.text.Layout.NO_PARA_SPANS;
var spanend = 0;
var textLength = 0;
if (spannedText) {
textLength = buf.length ();
for (var i = first; i <= last; i++) {
var start = previousLineEnd;
var end = this.getLineStart (i + 1);
previousLineEnd = end;
var ltop = previousLineBottom;
var lbottom = this.getLineTop (i + 1);
previousLineBottom = lbottom;
var lbaseline = lbottom - this.getLineDescent (i);
if (start >= spanend) {
var sp = buf;
spanend = sp.nextSpanTransition (start, textLength, android.text.style.LineBackgroundSpan);
spans = sp.getSpans (start, spanend, android.text.style.LineBackgroundSpan);
}for (var n = 0; n < spans.length; n++) {
var back = spans[n];
back.drawBackground (c, paint, 0, width, ltop, lbaseline, lbottom, buf, start, end, i);
}
}
spanend = 0;
previousLineBottom = this.getLineTop (first);
previousLineEnd = this.getLineStart (first);
spans = android.text.Layout.NO_PARA_SPANS;
}if (highlight != null) {
if (cursorOffsetVertical != 0) {
c.translate (0, cursorOffsetVertical);
}c.drawPath (highlight, highlightPaint);
if (cursorOffsetVertical != 0) {
c.translate (0, -cursorOffsetVertical);
}}var align = this.mAlignment;
for (var i = first; i <= last; i++) {
var start = previousLineEnd;
previousLineEnd = this.getLineStart (i + 1);
var end = this.getLineVisibleEnd (i, start, previousLineEnd);
var ltop = previousLineBottom;
var lbottom = this.getLineTop (i + 1);
previousLineBottom = lbottom;
var lbaseline = lbottom - this.getLineDescent (i);
var isFirstParaLine = false;
if (spannedText) {
if (start == 0 || (buf.charAt (start - 1)).charCodeAt (0) == ('\n').charCodeAt (0)) {
isFirstParaLine = true;
}if (start >= spanend) {
var sp = buf;
spanend = sp.nextSpanTransition (start, textLength, android.text.style.ParagraphStyle);
spans = sp.getSpans (start, spanend, android.text.style.ParagraphStyle);
align = this.mAlignment;
for (var n = spans.length - 1; n >= 0; n--) {
if (Clazz.instanceOf (spans[n], android.text.style.AlignmentSpan)) {
align = (spans[n]).getAlignment ();
break;
}}
}}var dir = this.getParagraphDirection (i);
var left = 0;
var right = this.mWidth;
if (spannedText) {
var length = spans.length;
for (var n = 0; n < length; n++) {
if (Clazz.instanceOf (spans[n], android.text.style.LeadingMarginSpan)) {
var margin = spans[n];
if (dir == -1) {
margin.drawLeadingMargin (c, paint, right, dir, ltop, lbaseline, lbottom, buf, start, end, isFirstParaLine, this);
right -= margin.getLeadingMargin (isFirstParaLine);
} else {
margin.drawLeadingMargin (c, paint, left, dir, ltop, lbaseline, lbottom, buf, start, end, isFirstParaLine, this);
var useMargin = isFirstParaLine;
if (Clazz.instanceOf (margin, android.text.style.LeadingMarginSpan.LeadingMarginSpan2)) {
var count = (margin).getLeadingMarginLineCount ();
useMargin = count > i;
}left += margin.getLeadingMargin (useMargin);
}}}
}var x;
if (align === android.text.Layout.Alignment.ALIGN_NORMAL) {
if (dir == 1) {
x = left;
} else {
x = right;
}} else {
var max = Math.round (this.getLineMax (i, spans, false));
if (align === android.text.Layout.Alignment.ALIGN_OPPOSITE) {
if (dir == -1) {
x = left + max;
} else {
x = right - max;
}} else {
max = max & -2;
var half = (right - left - max) >> 1;
if (dir == -1) {
x = right - half;
} else {
x = left + half;
}}}var directions = this.getLineDirections (i);
var hasTab = this.getLineContainsTab (i);
if (directions === android.text.Layout.DIRS_ALL_LEFT_TO_RIGHT && !spannedText && !hasTab) {
if (false) {
}c.drawText (buf, start, end, x, lbaseline, paint);
} else {
this.drawText (c, buf, start, end, dir, directions, x, ltop, lbaseline, lbottom, paint, this.mWorkPaint, hasTab, spans);
}}
}, "android.graphics.Canvas,android.graphics.Path,android.graphics.Paint,~N");
Clazz.defineMethod (c$, "getText", 
function () {
return this.mText;
});
Clazz.defineMethod (c$, "getPaint", 
function () {
return this.mPaint;
});
Clazz.defineMethod (c$, "getWidth", 
function () {
return this.mWidth;
});
Clazz.defineMethod (c$, "getEllipsizedWidth", 
function () {
return this.mWidth;
});
Clazz.defineMethod (c$, "increaseWidthTo", 
function (wid) {
if (wid < this.mWidth) {
throw  new RuntimeException ("attempted to reduce Layout width");
}this.mWidth = wid;
}, "~N");
Clazz.defineMethod (c$, "getHeight", 
function () {
return this.getLineTop (this.getLineCount ());
});
Clazz.defineMethod (c$, "getAlignment", 
function () {
return this.mAlignment;
});
Clazz.defineMethod (c$, "getSpacingMultiplier", 
function () {
return this.mSpacingMult;
});
Clazz.defineMethod (c$, "getSpacingAdd", 
function () {
return this.mSpacingAdd;
});
Clazz.defineMethod (c$, "getLineBounds", 
function (line, bounds) {
if (bounds != null) {
bounds.left = 0;
bounds.top = this.getLineTop (line);
bounds.right = this.mWidth;
bounds.bottom = this.getLineTop (line + 1);
}return this.getLineBaseline (line);
}, "~N,android.graphics.Rect");
Clazz.defineMethod (c$, "getPrimaryHorizontal", 
function (offset) {
return this.getHorizontal (offset, false, true);
}, "~N");
Clazz.defineMethod (c$, "getSecondaryHorizontal", 
function (offset) {
return this.getHorizontal (offset, true, true);
}, "~N");
Clazz.defineMethod (c$, "getHorizontal", 
($fz = function (offset, trailing, alt) {
var line = this.getLineForOffset (offset);
return this.getHorizontal (offset, trailing, alt, line);
}, $fz.isPrivate = true, $fz), "~N,~B,~B");
Clazz.defineMethod (c$, "getHorizontal", 
($fz = function (offset, trailing, alt, line) {
var start = this.getLineStart (line);
var end = this.getLineVisibleEnd (line);
var dir = this.getParagraphDirection (line);
var tab = this.getLineContainsTab (line);
var directions = this.getLineDirections (line);
var tabs = null;
if (tab && Clazz.instanceOf (this.mText, android.text.Spanned)) {
tabs = (this.mText).getSpans (start, end, android.text.style.TabStopSpan);
}var wid = android.text.Layout.measureText (this.mPaint, this.mWorkPaint, this.mText, start, offset, end, dir, directions, trailing, alt, tab, tabs);
if (offset > end) {
if (dir == -1) wid -= android.text.Layout.measureText (this.mPaint, this.mWorkPaint, this.mText, end, offset, null, tab, tabs);
 else wid += android.text.Layout.measureText (this.mPaint, this.mWorkPaint, this.mText, end, offset, null, tab, tabs);
}var align = this.getParagraphAlignment (line);
var left = this.getParagraphLeft (line);
var right = this.getParagraphRight (line);
if (align === android.text.Layout.Alignment.ALIGN_NORMAL) {
if (dir == -1) return right + wid;
 else return left + wid;
}var max = this.getLineMax (line);
if (align === android.text.Layout.Alignment.ALIGN_OPPOSITE) {
if (dir == -1) return left + max + wid;
 else return right - max + wid;
} else {
var imax = (Math.round (max)) & -2;
if (dir == -1) return right - (Math.floor (((right - left) - imax) / 2)) + wid;
 else return left + Math.floor (((right - left) - imax) / 2) + wid;
}}, $fz.isPrivate = true, $fz), "~N,~B,~B,~N");
Clazz.defineMethod (c$, "getLineLeft", 
function (line) {
var dir = this.getParagraphDirection (line);
var align = this.getParagraphAlignment (line);
if (align === android.text.Layout.Alignment.ALIGN_NORMAL) {
if (dir == -1) return this.getParagraphRight (line) - this.getLineMax (line);
 else return 0;
} else if (align === android.text.Layout.Alignment.ALIGN_OPPOSITE) {
if (dir == -1) return 0;
 else return this.mWidth - this.getLineMax (line);
} else {
var left = this.getParagraphLeft (line);
var right = this.getParagraphRight (line);
var max = (Math.round (this.getLineMax (line))) & -2;
return left + Math.floor (((right - left) - max) / 2);
}}, "~N");
Clazz.defineMethod (c$, "getLineRight", 
function (line) {
var dir = this.getParagraphDirection (line);
var align = this.getParagraphAlignment (line);
if (align === android.text.Layout.Alignment.ALIGN_NORMAL) {
if (dir == -1) return this.mWidth;
 else return this.getParagraphLeft (line) + this.getLineMax (line);
} else if (align === android.text.Layout.Alignment.ALIGN_OPPOSITE) {
if (dir == -1) return this.getLineMax (line);
 else return this.mWidth;
} else {
var left = this.getParagraphLeft (line);
var right = this.getParagraphRight (line);
var max = (Math.round (this.getLineMax (line))) & -2;
return right - Math.floor (((right - left) - max) / 2);
}}, "~N");
Clazz.defineMethod (c$, "getLineMax", 
function (line) {
return this.getLineMax (line, null, false);
}, "~N");
Clazz.defineMethod (c$, "getLineWidth", 
function (line) {
return this.getLineMax (line, null, true);
}, "~N");
Clazz.defineMethod (c$, "getLineMax", 
($fz = function (line, tabs, full) {
var start = this.getLineStart (line);
var end;
if (full) {
end = this.getLineEnd (line);
} else {
end = this.getLineVisibleEnd (line);
}var tab = this.getLineContainsTab (line);
if (tabs == null && tab && Clazz.instanceOf (this.mText, android.text.Spanned)) {
tabs = (this.mText).getSpans (start, end, android.text.style.TabStopSpan);
}return android.text.Layout.measureText (this.mPaint, this.mWorkPaint, this.mText, start, end, null, tab, tabs);
}, $fz.isPrivate = true, $fz), "~N,~A,~B");
Clazz.defineMethod (c$, "getLineForVertical", 
function (vertical) {
var high = this.getLineCount ();
var low = -1;
var guess;
while (high - low > 1) {
guess = Math.floor ((high + low) / 2);
if (this.getLineTop (guess) > vertical) high = guess;
 else low = guess;
}
if (low < 0) return 0;
 else return low;
}, "~N");
Clazz.defineMethod (c$, "getLineForOffset", 
function (offset) {
var high = this.getLineCount ();
var low = -1;
var guess;
while (high - low > 1) {
guess = Math.floor ((high + low) / 2);
if (this.getLineStart (guess) > offset) high = guess;
 else low = guess;
}
if (low < 0) return 0;
 else return low;
}, "~N");
Clazz.defineMethod (c$, "getOffsetForHorizontal", 
function (line, horiz) {
var max = this.getLineEnd (line) - 1;
var min = this.getLineStart (line);
var dirs = this.getLineDirections (line);
if (line == this.getLineCount () - 1) max++;
if (line != this.getLineCount () - 1) max = android.text.TextUtils.getOffsetBefore (this.mText, this.getLineEnd (line));
var best = min;
var bestdist = Math.abs (this.getPrimaryHorizontal (best) - horiz);
var here = min;
for (var i = 0; i < dirs.mDirections.length; i++) {
var there = here + dirs.mDirections[i];
var swap = ((i & 1) == 0) ? 1 : -1;
if (there > max) there = max;
var high = there - 1 + 1;
var low = here + 1 - 1;
var guess;
while (high - low > 1) {
guess = Math.floor ((high + low) / 2);
var adguess = this.getOffsetAtStartOf (guess);
if (this.getPrimaryHorizontal (adguess) * swap >= horiz * swap) high = guess;
 else low = guess;
}
if (low < here + 1) low = here + 1;
if (low < there) {
low = this.getOffsetAtStartOf (low);
var dist = Math.abs (this.getPrimaryHorizontal (low) - horiz);
var aft = android.text.TextUtils.getOffsetAfter (this.mText, low);
if (aft < there) {
var other = Math.abs (this.getPrimaryHorizontal (aft) - horiz);
if (other < dist) {
dist = other;
low = aft;
}}if (dist < bestdist) {
bestdist = dist;
best = low;
}}var dist = Math.abs (this.getPrimaryHorizontal (here) - horiz);
if (dist < bestdist) {
bestdist = dist;
best = here;
}here = there;
}
var dist = Math.abs (this.getPrimaryHorizontal (max) - horiz);
if (dist < bestdist) {
bestdist = dist;
best = max;
}return best;
}, "~N,~N");
Clazz.defineMethod (c$, "getLineEnd", 
function (line) {
return this.getLineStart (line + 1);
}, "~N");
Clazz.defineMethod (c$, "getLineVisibleEnd", 
function (line) {
return this.getLineVisibleEnd (line, this.getLineStart (line), this.getLineStart (line + 1));
}, "~N");
Clazz.defineMethod (c$, "getLineVisibleEnd", 
($fz = function (line, start, end) {
if (false) {
}var text = this.mText;
var ch;
if (line == this.getLineCount () - 1) {
return end;
}for (; end > start; end--) {
ch = text.charAt (end - 1);
if ((ch).charCodeAt (0) == ('\n').charCodeAt (0)) {
return end - 1;
}if ((ch).charCodeAt (0) != (' ').charCodeAt (0) && (ch).charCodeAt (0) != ('\t').charCodeAt (0)) {
break;
}}
return end;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "getLineBottom", 
function (line) {
return this.getLineTop (line + 1);
}, "~N");
Clazz.defineMethod (c$, "getLineBaseline", 
function (line) {
return this.getLineTop (line + 1) - this.getLineDescent (line);
}, "~N");
Clazz.defineMethod (c$, "getLineAscent", 
function (line) {
return this.getLineTop (line) - (this.getLineTop (line + 1) - this.getLineDescent (line));
}, "~N");
Clazz.defineMethod (c$, "getOffsetToLeftOf", 
function (offset) {
var line = this.getLineForOffset (offset);
var start = this.getLineStart (line);
var end = this.getLineEnd (line);
var dirs = this.getLineDirections (line);
if (line != this.getLineCount () - 1) end = android.text.TextUtils.getOffsetBefore (this.mText, end);
var horiz = this.getPrimaryHorizontal (offset);
var best = offset;
var besth = -2147483648;
var candidate;
candidate = android.text.TextUtils.getOffsetBefore (this.mText, offset);
if (candidate >= start && candidate <= end) {
var h = this.getPrimaryHorizontal (candidate);
if (h < horiz && h > besth) {
best = candidate;
besth = h;
}}candidate = android.text.TextUtils.getOffsetAfter (this.mText, offset);
if (candidate >= start && candidate <= end) {
var h = this.getPrimaryHorizontal (candidate);
if (h < horiz && h > besth) {
best = candidate;
besth = h;
}}var here = start;
for (var i = 0; i < dirs.mDirections.length; i++) {
var there = here + dirs.mDirections[i];
if (there > end) there = end;
var h = this.getPrimaryHorizontal (here);
if (h < horiz && h > besth) {
best = here;
besth = h;
}candidate = android.text.TextUtils.getOffsetAfter (this.mText, here);
if (candidate >= start && candidate <= end) {
h = this.getPrimaryHorizontal (candidate);
if (h < horiz && h > besth) {
best = candidate;
besth = h;
}}candidate = android.text.TextUtils.getOffsetBefore (this.mText, there);
if (candidate >= start && candidate <= end) {
h = this.getPrimaryHorizontal (candidate);
if (h < horiz && h > besth) {
best = candidate;
besth = h;
}}here = there;
}
var h = this.getPrimaryHorizontal (end);
if (h < horiz && h > besth) {
best = end;
besth = h;
}if (best != offset) return best;
var dir = this.getParagraphDirection (line);
if (dir > 0) {
if (line == 0) return best;
 else return this.getOffsetForHorizontal (line - 1, 10000);
} else {
if (line == this.getLineCount () - 1) return best;
 else return this.getOffsetForHorizontal (line + 1, 10000);
}}, "~N");
Clazz.defineMethod (c$, "getOffsetToRightOf", 
function (offset) {
var line = this.getLineForOffset (offset);
var start = this.getLineStart (line);
var end = this.getLineEnd (line);
var dirs = this.getLineDirections (line);
if (line != this.getLineCount () - 1) end = android.text.TextUtils.getOffsetBefore (this.mText, end);
var horiz = this.getPrimaryHorizontal (offset);
var best = offset;
var besth = 2147483647;
var candidate;
candidate = android.text.TextUtils.getOffsetBefore (this.mText, offset);
if (candidate >= start && candidate <= end) {
var h = this.getPrimaryHorizontal (candidate);
if (h > horiz && h < besth) {
best = candidate;
besth = h;
}}candidate = android.text.TextUtils.getOffsetAfter (this.mText, offset);
if (candidate >= start && candidate <= end) {
var h = this.getPrimaryHorizontal (candidate);
if (h > horiz && h < besth) {
best = candidate;
besth = h;
}}var here = start;
for (var i = 0; i < dirs.mDirections.length; i++) {
var there = here + dirs.mDirections[i];
if (there > end) there = end;
var h = this.getPrimaryHorizontal (here);
if (h > horiz && h < besth) {
best = here;
besth = h;
}candidate = android.text.TextUtils.getOffsetAfter (this.mText, here);
if (candidate >= start && candidate <= end) {
h = this.getPrimaryHorizontal (candidate);
if (h > horiz && h < besth) {
best = candidate;
besth = h;
}}candidate = android.text.TextUtils.getOffsetBefore (this.mText, there);
if (candidate >= start && candidate <= end) {
h = this.getPrimaryHorizontal (candidate);
if (h > horiz && h < besth) {
best = candidate;
besth = h;
}}here = there;
}
var h = this.getPrimaryHorizontal (end);
if (h > horiz && h < besth) {
best = end;
besth = h;
}if (best != offset) return best;
var dir = this.getParagraphDirection (line);
if (dir > 0) {
if (line == this.getLineCount () - 1) return best;
 else return this.getOffsetForHorizontal (line + 1, -10000);
} else {
if (line == 0) return best;
 else return this.getOffsetForHorizontal (line - 1, -10000);
}}, "~N");
Clazz.defineMethod (c$, "getOffsetAtStartOf", 
($fz = function (offset) {
if (offset == 0) return 0;
var text = this.mText;
var c = text.charAt (offset);
if ((c).charCodeAt (0) >= ('\uDC00').charCodeAt (0) && (c).charCodeAt (0) <= ('\uDFFF').charCodeAt (0)) {
var c1 = text.charAt (offset - 1);
if ((c1).charCodeAt (0) >= ('\uD800').charCodeAt (0) && (c1).charCodeAt (0) <= ('\uDBFF').charCodeAt (0)) offset -= 1;
}if (this.mSpannedText) {
var spans = (text).getSpans (offset, offset, android.text.style.ReplacementSpan);
for (var i = 0; i < spans.length; i++) {
var start = (text).getSpanStart (spans[i]);
var end = (text).getSpanEnd (spans[i]);
if (start < offset && end > offset) offset = start;
}
}return offset;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "addSelection", 
($fz = function (line, start, end, top, bottom, dest) {
var linestart = this.getLineStart (line);
var lineend = this.getLineEnd (line);
var dirs = this.getLineDirections (line);
if (lineend > linestart && (this.mText.charAt (lineend - 1)).charCodeAt (0) == ('\n').charCodeAt (0)) lineend--;
var here = linestart;
for (var i = 0; i < dirs.mDirections.length; i++) {
var there = here + dirs.mDirections[i];
if (there > lineend) there = lineend;
if (start <= there && end >= here) {
var st = Math.max (start, here);
var en = Math.min (end, there);
if (st != en) {
var h1 = this.getHorizontal (st, false, false, line);
var h2 = this.getHorizontal (en, true, false, line);
dest.addRect (h1, top, h2, bottom, android.graphics.Path.Direction.CW);
}}here = there;
}
}, $fz.isPrivate = true, $fz), "~N,~N,~N,~N,~N,android.graphics.Path");
Clazz.defineMethod (c$, "getSelectionPath", 
function (start, end, dest) {
dest.reset ();
if (start == end) return ;
if (end < start) {
var temp = end;
end = start;
start = temp;
}var startline = this.getLineForOffset (start);
var endline = this.getLineForOffset (end);
var top = this.getLineTop (startline);
var bottom = this.getLineBottom (endline);
if (startline == endline) {
this.addSelection (startline, start, end, top, bottom, dest);
} else {
var width = this.mWidth;
this.addSelection (startline, start, this.getLineEnd (startline), top, this.getLineBottom (startline), dest);
if (this.getParagraphDirection (startline) == -1) dest.addRect (this.getLineLeft (startline), top, 0, this.getLineBottom (startline), android.graphics.Path.Direction.CW);
 else dest.addRect (this.getLineRight (startline), top, width, this.getLineBottom (startline), android.graphics.Path.Direction.CW);
for (var i = startline + 1; i < endline; i++) {
top = this.getLineTop (i);
bottom = this.getLineBottom (i);
dest.addRect (0, top, width, bottom, android.graphics.Path.Direction.CW);
}
top = this.getLineTop (endline);
bottom = this.getLineBottom (endline);
this.addSelection (endline, this.getLineStart (endline), end, top, bottom, dest);
if (this.getParagraphDirection (endline) == -1) dest.addRect (width, top, this.getLineRight (endline), bottom, android.graphics.Path.Direction.CW);
 else dest.addRect (0, top, this.getLineLeft (endline), bottom, android.graphics.Path.Direction.CW);
}}, "~N,~N,android.graphics.Path");
Clazz.defineMethod (c$, "getParagraphAlignment", 
function (line) {
var align = this.mAlignment;
if (this.mSpannedText) {
var sp = this.mText;
var spans = sp.getSpans (this.getLineStart (line), this.getLineEnd (line), android.text.style.AlignmentSpan);
var spanLength = spans.length;
if (spanLength > 0) {
align = spans[spanLength - 1].getAlignment ();
}}return align;
}, "~N");
Clazz.defineMethod (c$, "getParagraphLeft", 
function (line) {
var dir = this.getParagraphDirection (line);
var left = 0;
var par = false;
var off = this.getLineStart (line);
if (off == 0 || (this.mText.charAt (off - 1)).charCodeAt (0) == ('\n').charCodeAt (0)) par = true;
if (dir == 1) {
if (this.mSpannedText) {
var sp = this.mText;
var spans = sp.getSpans (this.getLineStart (line), this.getLineEnd (line), android.text.style.LeadingMarginSpan);
for (var i = 0; i < spans.length; i++) {
var margin = par;
var span = spans[i];
if (Clazz.instanceOf (span, android.text.style.LeadingMarginSpan.LeadingMarginSpan2)) {
var count = (span).getLeadingMarginLineCount ();
margin = count >= line;
}left += span.getLeadingMargin (margin);
}
}}return left;
}, "~N");
Clazz.defineMethod (c$, "getParagraphRight", 
function (line) {
var dir = this.getParagraphDirection (line);
var right = this.mWidth;
var par = false;
var off = this.getLineStart (line);
if (off == 0 || (this.mText.charAt (off - 1)).charCodeAt (0) == ('\n').charCodeAt (0)) par = true;
if (dir == -1) {
if (this.mSpannedText) {
var sp = this.mText;
var spans = sp.getSpans (this.getLineStart (line), this.getLineEnd (line), android.text.style.LeadingMarginSpan);
for (var i = 0; i < spans.length; i++) {
right -= spans[i].getLeadingMargin (par);
}
}}return right;
}, "~N");
Clazz.defineMethod (c$, "drawText", 
($fz = function (canvas, text, start, end, dir, directions, x, top, y, bottom, paint, workPaint, hasTabs, parspans) {
var buf;
if (!hasTabs) {
if (directions === android.text.Layout.DIRS_ALL_LEFT_TO_RIGHT) {
if (false) {
}android.text.Styled.drawText (canvas, text, start, end, dir, false, x, top, y, bottom, paint, workPaint, false);
return ;
}buf = null;
} else {
buf = android.text.TextUtils.obtain (end - start);
android.text.TextUtils.getChars (text, start, end, buf, 0);
}var h = 0;
var here = 0;
for (var i = 0; i < directions.mDirections.length; i++) {
var there = here + directions.mDirections[i];
if (there > end - start) there = end - start;
var segstart = here;
for (var j = hasTabs ? here : there; j <= there; j++) {
if (j == there || (buf[j]).charCodeAt (0) == ('\t').charCodeAt (0)) {
h += android.text.Styled.drawText (canvas, text, start + segstart, start + j, dir, (i & 1) != 0, x + h, top, y, bottom, paint, workPaint, start + j != end);
if (j != there && (buf[j]).charCodeAt (0) == ('\t').charCodeAt (0)) h = dir * android.text.Layout.nextTab (text, start, end, h * dir, parspans);
segstart = j + 1;
} else if (hasTabs && (buf[j]).charCodeAt (0) >= 0xD800 && (buf[j]).charCodeAt (0) <= 0xDFFF && j + 1 < there) {
var emoji = Character.codePointAt (buf, j);
if (emoji >= android.text.Layout.MIN_EMOJI && emoji <= android.text.Layout.MAX_EMOJI) {
var bm = android.text.Layout.EMOJI_FACTORY.getBitmapFromAndroidPua (emoji);
if (bm != null) {
h += android.text.Styled.drawText (canvas, text, start + segstart, start + j, dir, (i & 1) != 0, x + h, top, y, bottom, paint, workPaint, start + j != end);
if (this.mEmojiRect == null) {
this.mEmojiRect =  new android.graphics.RectF ();
}workPaint.set (paint);
android.text.Styled.measureText (paint, workPaint, text, start + j, start + j + 1, null);
var bitmapHeight = bm.getHeight ();
var textHeight = -workPaint.ascent ();
var scale = textHeight / bitmapHeight;
var width = bm.getWidth () * scale;
this.mEmojiRect.set (x + h, y - textHeight, x + h + width, y);
canvas.drawBitmap (bm, null, this.mEmojiRect, paint);
h += width;
j++;
segstart = j + 1;
}}}}
here = there;
}
if (hasTabs) android.text.TextUtils.recycle (buf);
}, $fz.isPrivate = true, $fz), "android.graphics.Canvas,CharSequence,~N,~N,~N,android.text.Layout.Directions,~N,~N,~N,~N,android.text.TextPaint,android.text.TextPaint,~B,~A");
c$.measureText = Clazz.defineMethod (c$, "measureText", 
($fz = function (paint, workPaint, text, start, offset, end, dir, directions, trailing, alt, hasTabs, tabs) {
var buf = null;
if (hasTabs) {
buf = android.text.TextUtils.obtain (end - start);
android.text.TextUtils.getChars (text, start, end, buf, 0);
}var h = 0;
if (alt) {
if (dir == -1) trailing = !trailing;
}var here = 0;
for (var i = 0; i < directions.mDirections.length; i++) {
if (alt) trailing = !trailing;
var there = here + directions.mDirections[i];
if (there > end - start) there = end - start;
var segstart = here;
for (var j = hasTabs ? here : there; j <= there; j++) {
var codept = 0;
var bm = null;
if (hasTabs && j < there) {
codept = (buf[j]).charCodeAt (0);
}if (codept >= 0xD800 && codept <= 0xDFFF && j + 1 < there) {
codept = Character.codePointAt (buf, j);
if (codept >= android.text.Layout.MIN_EMOJI && codept <= android.text.Layout.MAX_EMOJI) {
bm = android.text.Layout.EMOJI_FACTORY.getBitmapFromAndroidPua (codept);
}}if (j == there || codept == ('\t').charCodeAt (0) || bm != null) {
var segw;
if (offset < start + j || (trailing && offset <= start + j)) {
if (dir == 1 && (i & 1) == 0) {
h += android.text.Styled.measureText (paint, workPaint, text, start + segstart, offset, null);
return h;
}if (dir == -1 && (i & 1) != 0) {
h -= android.text.Styled.measureText (paint, workPaint, text, start + segstart, offset, null);
return h;
}}segw = android.text.Styled.measureText (paint, workPaint, text, start + segstart, start + j, null);
if (offset < start + j || (trailing && offset <= start + j)) {
if (dir == 1) {
h += segw - android.text.Styled.measureText (paint, workPaint, text, start + segstart, offset, null);
return h;
}if (dir == -1) {
h -= segw - android.text.Styled.measureText (paint, workPaint, text, start + segstart, offset, null);
return h;
}}if (dir == -1) h -= segw;
 else h += segw;
if (j != there && (buf[j]).charCodeAt (0) == ('\t').charCodeAt (0)) {
if (offset == start + j) return h;
h = dir * android.text.Layout.nextTab (text, start, end, h * dir, tabs);
}if (j != there && bm != null) {
if (offset == start + j) return h;
workPaint.set (paint);
android.text.Styled.measureText (paint, workPaint, text, j, j + 2, null);
var wid = bm.getWidth () * -workPaint.ascent () / bm.getHeight ();
if (dir == -1) {
h -= wid;
} else {
h += wid;
}j++;
}segstart = j + 1;
}}
here = there;
}
if (hasTabs) android.text.TextUtils.recycle (buf);
return h;
}, $fz.isPrivate = true, $fz), "android.text.TextPaint,android.text.TextPaint,CharSequence,~N,~N,~N,~N,android.text.Layout.Directions,~B,~B,~B,~A");
c$.measureText = Clazz.defineMethod (c$, "measureText", 
function (paint, workPaint, text, start, end, fm, hasTabs, tabs) {
var buf = null;
if (hasTabs) {
buf = android.text.TextUtils.obtain (end - start);
android.text.TextUtils.getChars (text, start, end, buf, 0);
}var len = end - start;
var lastPos = 0;
var width = 0;
var ascent = 0;
var descent = 0;
var top = 0;
var bottom = 0;
if (fm != null) {
fm.ascent = 0;
fm.descent = 0;
}for (var pos = hasTabs ? 0 : len; pos <= len; pos++) {
var codept = 0;
var bm = null;
if (hasTabs && pos < len) {
codept = (buf[pos]).charCodeAt (0);
}if (codept >= 0xD800 && codept <= 0xDFFF && pos < len) {
codept = Character.codePointAt (buf, pos);
if (codept >= android.text.Layout.MIN_EMOJI && codept <= android.text.Layout.MAX_EMOJI) {
bm = android.text.Layout.EMOJI_FACTORY.getBitmapFromAndroidPua (codept);
}}if (pos == len || codept == ('\t').charCodeAt (0) || bm != null) {
workPaint.baselineShift = 0;
width += android.text.Styled.measureText (paint, workPaint, text, start + lastPos, start + pos, fm);
if (fm != null) {
if (workPaint.baselineShift < 0) {
fm.ascent += workPaint.baselineShift;
fm.top += workPaint.baselineShift;
} else {
fm.descent += workPaint.baselineShift;
fm.bottom += workPaint.baselineShift;
}}if (pos != len) {
if (bm == null) {
width = android.text.Layout.nextTab (text, start, end, width, tabs);
} else {
workPaint.set (paint);
android.text.Styled.measureText (paint, workPaint, text, start + pos, start + pos + 1, null);
width += bm.getWidth () * -workPaint.ascent () / bm.getHeight ();
pos++;
}}if (fm != null) {
if (fm.ascent < ascent) {
ascent = fm.ascent;
}if (fm.descent > descent) {
descent = fm.descent;
}if (fm.top < top) {
top = fm.top;
}if (fm.bottom > bottom) {
bottom = fm.bottom;
}}lastPos = pos + 1;
}}
if (fm != null) {
fm.ascent = ascent;
fm.descent = descent;
fm.top = top;
fm.bottom = bottom;
}if (hasTabs) android.text.TextUtils.recycle (buf);
return width;
}, "android.text.TextPaint,android.text.TextPaint,CharSequence,~N,~N,android.graphics.Paint.FontMetricsInt,~B,~A");
c$.nextTab = Clazz.defineMethod (c$, "nextTab", 
function (text, start, end, h, tabs) {
var nh = 3.4028235E38;
var alltabs = false;
if (Clazz.instanceOf (text, android.text.Spanned)) {
if (tabs == null) {
tabs = (text).getSpans (start, end, android.text.style.TabStopSpan);
alltabs = true;
}for (var i = 0; i < tabs.length; i++) {
if (!alltabs) {
if (!(Clazz.instanceOf (tabs[i], android.text.style.TabStopSpan))) continue ;}var where = (tabs[i]).getTabStop ();
if (where < nh && where > h) nh = where;
}
if (nh != 3.4028235E38) return nh;
}return (Math.round (((h + 20) / 20))) * 20;
}, "CharSequence,~N,~N,~N,~A");
Clazz.defineMethod (c$, "isSpanned", 
function () {
return this.mSpannedText;
});
Clazz.defineMethod (c$, "ellipsize", 
($fz = function (start, end, line, dest, destoff) {
var ellipsisCount = this.getEllipsisCount (line);
if (ellipsisCount == 0) {
return ;
}var ellipsisStart = this.getEllipsisStart (line);
var linestart = this.getLineStart (line);
for (var i = ellipsisStart; i < ellipsisStart + ellipsisCount; i++) {
var c;
if (i == ellipsisStart) {
c = '\u2026';
} else {
c = '\uFEFF';
}var a = i + linestart;
if (a >= start && a < end) {
dest[destoff + a - start] = c;
}}
}, $fz.isPrivate = true, $fz), "~N,~N,~N,~A,~N");
Clazz.pu$h ();
c$ = Clazz.declareType (android.text.Layout, "Alignment", Enum);
Clazz.defineEnumConstant (c$, "ALIGN_NORMAL", 0, []);
Clazz.defineEnumConstant (c$, "ALIGN_OPPOSITE", 1, []);
Clazz.defineEnumConstant (c$, "ALIGN_CENTER", 2, []);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mDirections = null;
Clazz.instantialize (this, arguments);
}, android.text.Layout, "Directions");
Clazz.makeConstructor (c$, 
function (a) {
this.mDirections = a;
}, "~A");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mText = null;
this.mLayout = null;
this.mWidth = 0;
this.mMethod = null;
Clazz.instantialize (this, arguments);
}, android.text.Layout, "Ellipsizer", null, [CharSequence, android.text.GetChars]);
Clazz.makeConstructor (c$, 
function (a) {
this.mText = a;
}, "CharSequence");
Clazz.overrideMethod (c$, "charAt", 
function (a) {
var b = android.text.TextUtils.obtain (1);
this.getChars (a, a + 1, b, 0);
var c = b[0];
android.text.TextUtils.recycle (b);
return c;
}, "~N");
Clazz.overrideMethod (c$, "getChars", 
function (a, b, c, d) {
var e = this.mLayout.getLineForOffset (a);
var f = this.mLayout.getLineForOffset (b);
android.text.TextUtils.getChars (this.mText, a, b, c, d);
for (var g = e; g <= f; g++) {
this.mLayout.ellipsize (a, b, g, c, d);
}
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "length", 
function () {
return this.mText.length ();
});
Clazz.overrideMethod (c$, "subSequence", 
function (a, b) {
var c =  Clazz.newArray (b - a, '\0');
this.getChars (a, b, c, 0);
return  String.instantialize (c);
}, "~N,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
var a =  Clazz.newArray (this.length (), '\0');
this.getChars (0, this.length (), a, 0);
return  String.instantialize (a);
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mSpanned = null;
Clazz.instantialize (this, arguments);
}, android.text.Layout, "SpannedEllipsizer", android.text.Layout.Ellipsizer, android.text.Spanned);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.text.Layout.SpannedEllipsizer, [a]);
this.mSpanned = a;
}, "CharSequence");
Clazz.defineMethod (c$, "getSpans", 
function (a, b, c) {
return this.mSpanned.getSpans (a, b, c);
}, "~N,~N,Class");
Clazz.defineMethod (c$, "getSpanStart", 
function (a) {
return this.mSpanned.getSpanStart (a);
}, "~O");
Clazz.defineMethod (c$, "getSpanEnd", 
function (a) {
return this.mSpanned.getSpanEnd (a);
}, "~O");
Clazz.defineMethod (c$, "getSpanFlags", 
function (a) {
return this.mSpanned.getSpanFlags (a);
}, "~O");
Clazz.defineMethod (c$, "nextSpanTransition", 
function (a, b, c) {
return this.mSpanned.nextSpanTransition (a, b, c);
}, "~N,~N,Class");
Clazz.overrideMethod (c$, "subSequence", 
function (a, b) {
var c =  Clazz.newArray (b - a, '\0');
this.getChars (a, b, c, 0);
var d =  new android.text.SpannableString ( String.instantialize (c));
android.text.TextUtils.copySpansFrom (this.mSpanned, a, b, JavaObject, d, 0);
return d;
}, "~N,~N");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DEBUG", false);
c$.NO_PARA_SPANS = c$.prototype.NO_PARA_SPANS = com.android.internal.util.ArrayUtils.emptyArray (android.text.style.ParagraphStyle);
c$.EMOJI_FACTORY = c$.prototype.EMOJI_FACTORY = android.emoji.EmojiFactory.newAvailableInstance ();
Clazz.defineStatics (c$,
"MIN_EMOJI", 0,
"MAX_EMOJI", 0);
{
if (android.text.Layout.EMOJI_FACTORY != null) {
($t$ = android.text.Layout.MIN_EMOJI = android.text.Layout.EMOJI_FACTORY.getMinimumAndroidPua (), android.text.Layout.prototype.MIN_EMOJI = android.text.Layout.MIN_EMOJI, $t$);
($t$ = android.text.Layout.MAX_EMOJI = android.text.Layout.EMOJI_FACTORY.getMaximumAndroidPua (), android.text.Layout.prototype.MAX_EMOJI = android.text.Layout.MAX_EMOJI, $t$);
} else {
($t$ = android.text.Layout.MIN_EMOJI = -1, android.text.Layout.prototype.MIN_EMOJI = android.text.Layout.MIN_EMOJI, $t$);
($t$ = android.text.Layout.MAX_EMOJI = -1, android.text.Layout.prototype.MAX_EMOJI = android.text.Layout.MAX_EMOJI, $t$);
}}c$.sTempRect = c$.prototype.sTempRect =  new android.graphics.Rect ();
Clazz.defineStatics (c$,
"DIR_LEFT_TO_RIGHT", 1,
"DIR_RIGHT_TO_LEFT", -1,
"DIR_REQUEST_LTR", 1,
"DIR_REQUEST_RTL", -1,
"DIR_REQUEST_DEFAULT_LTR", 2,
"DIR_REQUEST_DEFAULT_RTL", -2,
"TAB_INCREMENT", 20);
c$.DIRS_ALL_LEFT_TO_RIGHT = c$.prototype.DIRS_ALL_LEFT_TO_RIGHT =  new android.text.Layout.Directions ([32767]);
c$.DIRS_ALL_RIGHT_TO_LEFT = c$.prototype.DIRS_ALL_RIGHT_TO_LEFT =  new android.text.Layout.Directions ([0, 32767]);
});
