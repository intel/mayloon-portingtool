﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.text.Spannable"], "android.text.Editable", null, function () {
Clazz.declareInterface (android.text, "Editable", android.text.Spannable);
Clazz.pu$h ();
c$ = Clazz.declareType (android.text.Editable, "Factory");
c$.getInstance = Clazz.defineMethod (c$, "getInstance", 
function () {
return android.text.Editable.Factory.sInstance;
});
Clazz.defineMethod (c$, "newEditable", 
function (a) {
var b = null;
try {
b = Class.forName ("android.text.SpannableStringBuilder").newInstance ();
} catch (e$$) {
if (Clazz.instanceOf (e$$, InstantiationException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, IllegalAccessException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, ClassNotFoundException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else {
throw e$$;
}
}
return b.append (a);
}, "CharSequence");
c$.sInstance = c$.prototype.sInstance =  new android.text.Editable.Factory ();
c$ = Clazz.p0p ();
});
