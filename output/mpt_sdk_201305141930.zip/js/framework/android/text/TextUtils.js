﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.text.GetChars", "java.lang.Enum"], "android.text.TextUtils", ["android.text.AndroidCharacter", "android.text.style.ReplacementSpan", "com.android.internal.util.ArrayUtils", "java.lang.StringBuilder"], function () {
c$ = Clazz.declareType (android.text, "TextUtils");
c$.getChars = Clazz.defineMethod (c$, "getChars", 
function (s, start, end, dest, destoff) {
var c = s.getClass ();
if (c === String) (s).getChars (start, end, dest, destoff);
 else if (c === StringBuilder) (s).getChars (start, end, dest, destoff);
 else {
for (var i = start; i < end; i++) dest[destoff++] = s.charAt (i);

}}, "CharSequence,~N,~N,~A,~N");
c$.indexOf = Clazz.defineMethod (c$, "indexOf", 
function (s, ch) {
return android.text.TextUtils.indexOf (s, ch, 0);
}, "CharSequence,~N");
c$.indexOf = Clazz.defineMethod (c$, "indexOf", 
function (s, ch, start) {
var c = s.getClass ();
if (c === String) return (s).indexOf (ch, start);
return android.text.TextUtils.indexOf (s, ch, start, s.length ());
}, "CharSequence,~N,~N");
c$.indexOf = Clazz.defineMethod (c$, "indexOf", 
function (s, ch, start, end) {
for (var i = start; i < end; i++) if ((s.charAt (i)).charCodeAt (0) == (ch).charCodeAt (0)) return i;

return -1;
}, "CharSequence,~N,~N,~N");
c$.lastIndexOf = Clazz.defineMethod (c$, "lastIndexOf", 
function (s, ch) {
return 0;
}, "CharSequence,~N");
c$.writeToParcel = Clazz.defineMethod (c$, "writeToParcel", 
function (val, parcel, i) {
}, "CharSequence,android.os.Parcel,~N");
c$.isEmpty = Clazz.defineMethod (c$, "isEmpty", 
function (str) {
if (str == null) {
return true;
}if (android.text.TextUtils.getLength (str) == 0) return true;
 else return false;
}, "CharSequence");
c$.getLength = Clazz.defineMethod (c$, "getLength", 
function (str) {
if (str == null) {
return 0;
}return String(str).length;
return 0;
}, "CharSequence");
c$.join = Clazz.defineMethod (c$, "join", 
function (delimiter, tokens) {
var sb =  new StringBuilder ();
var firstTime = true;
for (var token, $token = 0, $$token = tokens; $token < $$token.length && ((token = $$token[$token]) || true); $token++) {
if (firstTime) {
firstTime = false;
} else {
sb.append (delimiter);
}sb.append (token);
}
return sb.toString ();
}, "CharSequence,~A");
c$.join = Clazz.defineMethod (c$, "join", 
function (delimiter, tokens) {
var sb =  new StringBuilder ();
var firstTime = true;
for (var token, $token = tokens.iterator (); $token.hasNext () && ((token = $token.next ()) || true);) {
if (firstTime) {
firstTime = false;
} else {
sb.append (delimiter);
}sb.append (token);
}
return sb.toString ();
}, "CharSequence,Iterable");
c$.split = Clazz.defineMethod (c$, "split", 
function (text, expression) {
if (text.length == 0) {
return android.text.TextUtils.EMPTY_STRING_ARRAY;
} else {
return text.$plit (expression, -1);
}}, "~S,~S");
c$.split = Clazz.defineMethod (c$, "split", 
function (text, pattern) {
if (text.length == 0) {
return android.text.TextUtils.EMPTY_STRING_ARRAY;
} else {
return pattern.split (text, -1);
}}, "~S,java.util.regex.Pattern");
c$.equals = Clazz.defineMethod (c$, "equals", 
function (a, b) {
if (a === b) return true;
var length;
if (a != null && b != null && (length = a.length ()) == b.length ()) {
if (Clazz.instanceOf (a, String) && Clazz.instanceOf (b, String)) {
return a.equals (b);
} else {
for (var i = 0; i < length; i++) {
if ((a.charAt (i)).charCodeAt (0) != (b.charAt (i)).charCodeAt (0)) return false;
}
return true;
}}return false;
}, "CharSequence,CharSequence");
c$.getOffsetBefore = Clazz.defineMethod (c$, "getOffsetBefore", 
function (text, offset) {
if (offset == 0) return 0;
if (offset == 1) return 0;
var c = text.charAt (offset - 1);
if ((c).charCodeAt (0) >= ('\uDC00').charCodeAt (0) && (c).charCodeAt (0) <= ('\uDFFF').charCodeAt (0)) {
var c1 = text.charAt (offset - 2);
if ((c1).charCodeAt (0) >= ('\uD800').charCodeAt (0) && (c1).charCodeAt (0) <= ('\uDBFF').charCodeAt (0)) offset -= 2;
 else offset -= 1;
} else {
offset -= 1;
}return offset;
}, "CharSequence,~N");
c$.copySpansFrom = Clazz.defineMethod (c$, "copySpansFrom", 
function (source, start, end, kind, dest, destoff) {
if (kind == null) {
kind = JavaObject;
}var spans = source.getSpans (start, end, kind);
for (var i = 0; i < spans.length; i++) {
var st = source.getSpanStart (spans[i]);
var en = source.getSpanEnd (spans[i]);
var fl = source.getSpanFlags (spans[i]);
if (st < start) st = start;
if (en > end) en = end;
dest.setSpan (spans[i], st - start + destoff, en - start + destoff, fl);
}
}, "android.text.Spanned,~N,~N,Class,android.text.Spannable,~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (len) {
var buf;
{
buf = android.text.TextUtils.sTemp;
($t$ = android.text.TextUtils.sTemp = null, android.text.TextUtils.prototype.sTemp = android.text.TextUtils.sTemp, $t$);
}if (buf == null || buf.length < len) buf =  Clazz.newArray (com.android.internal.util.ArrayUtils.idealCharArraySize (len), '\0');
return buf;
}, "~N");
c$.recycle = Clazz.defineMethod (c$, "recycle", 
function (temp) {
if (temp.length > 1000) return ;
{
($t$ = android.text.TextUtils.sTemp = temp, android.text.TextUtils.prototype.sTemp = android.text.TextUtils.sTemp, $t$);
}}, "~A");
c$.getOffsetAfter = Clazz.defineMethod (c$, "getOffsetAfter", 
function (text, offset) {
var len = text.length ();
if (offset == len) return len;
if (offset == len - 1) return len;
var c = text.charAt (offset);
if ((c).charCodeAt (0) >= ('\uD800').charCodeAt (0) && (c).charCodeAt (0) <= ('\uDBFF').charCodeAt (0)) {
var c1 = text.charAt (offset + 1);
if ((c1).charCodeAt (0) >= ('\uDC00').charCodeAt (0) && (c1).charCodeAt (0) <= ('\uDFFF').charCodeAt (0)) offset += 2;
 else offset += 1;
} else {
offset += 1;
}if (Clazz.instanceOf (text, android.text.Spanned)) {
var spans = (text).getSpans (offset, offset, android.text.style.ReplacementSpan);
for (var i = 0; i < spans.length; i++) {
var start = (text).getSpanStart (spans[i]);
var end = (text).getSpanEnd (spans[i]);
if (start < offset && end > offset) offset = end;
}
}return offset;
}, "CharSequence,~N");
c$.getReverse = Clazz.defineMethod (c$, "getReverse", 
function (source, start, end) {
return  new android.text.TextUtils.Reverser (source, start, end);
}, "CharSequence,~N,~N");
c$.getTrimmedLength = Clazz.defineMethod (c$, "getTrimmedLength", 
function (s) {
console.log("Missing method: getTrimmedLength");
}, "CharSequence");
c$.htmlEncode = Clazz.defineMethod (c$, "htmlEncode", 
function (s) {
console.log("Missing method: htmlEncode");
}, "~S");
c$.isGraphic = Clazz.defineMethod (c$, "isGraphic", 
function (c) {
console.log("Missing method: isGraphic");
}, "~N");
c$.isDigitsOnly = Clazz.defineMethod (c$, "isDigitsOnly", 
function (str) {
console.log("Missing method: isDigitsOnly");
}, "CharSequence");
c$.stringOrSpannedString = Clazz.defineMethod (c$, "stringOrSpannedString", 
function (source) {
console.log("Missing method: stringOrSpannedString");
}, "CharSequence");
c$.isGraphic = Clazz.defineMethod (c$, "isGraphic", 
function (str) {
console.log("Missing method: isGraphic");
}, "CharSequence");
c$.concat = Clazz.defineMethod (c$, "concat", 
function (text) {
console.log("Missing method: concat");
}, "CharSequence");
Clazz.pu$h ();
c$ = Clazz.declareType (android.text.TextUtils, "TruncateAt", Enum);
Clazz.defineEnumConstant (c$, "START", 0, []);
Clazz.defineEnumConstant (c$, "MIDDLE", 1, []);
Clazz.defineEnumConstant (c$, "END", 2, []);
Clazz.defineEnumConstant (c$, "MARQUEE", 3, []);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mSource = null;
this.mStart = 0;
this.mEnd = 0;
Clazz.instantialize (this, arguments);
}, android.text.TextUtils, "Reverser", null, [CharSequence, android.text.GetChars]);
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.mSource = a;
this.mStart = b;
this.mEnd = c;
}, "CharSequence,~N,~N");
Clazz.overrideMethod (c$, "length", 
function () {
return this.mEnd - this.mStart;
});
Clazz.overrideMethod (c$, "subSequence", 
function (a, b) {
var c =  Clazz.newArray (b - a, '\0');
this.getChars (a, b, c, 0);
return  String.instantialize (c);
}, "~N,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return this.subSequence (0, this.length ()).toString ();
});
Clazz.defineMethod (c$, "charAt", 
function (a) {
return android.text.AndroidCharacter.getMirror (this.mSource.charAt (this.mEnd - 1 - a));
}, "~N");
Clazz.overrideMethod (c$, "getChars", 
function (a, b, c, d) {
android.text.TextUtils.getChars (this.mSource, a + this.mStart, b + this.mStart, c, d);
android.text.AndroidCharacter.mirror (c, 0, b - a);
var e = b - a;
var f = Math.floor ((b - a) / 2);
for (var g = 0; g < f; g++) {
var h = c[d + g];
c[d + g] = c[d + e - g - 1];
c[d + e - g - 1] = h;
}
}, "~N,~N,~A,~N");
c$ = Clazz.p0p ();
c$.EMPTY_STRING_ARRAY = c$.prototype.EMPTY_STRING_ARRAY = [];
Clazz.defineStatics (c$,
"ALIGNMENT_SPAN", 1,
"FOREGROUND_COLOR_SPAN", 2,
"RELATIVE_SIZE_SPAN", 3,
"SCALE_X_SPAN", 4,
"STRIKETHROUGH_SPAN", 5,
"UNDERLINE_SPAN", 6,
"STYLE_SPAN", 7,
"BULLET_SPAN", 8,
"QUOTE_SPAN", 9,
"LEADING_MARGIN_SPAN", 10,
"URL_SPAN", 11,
"BACKGROUND_COLOR_SPAN", 12,
"TYPEFACE_SPAN", 13,
"SUPERSCRIPT_SPAN", 14,
"SUBSCRIPT_SPAN", 15,
"ABSOLUTE_SIZE_SPAN", 16,
"TEXT_APPEARANCE_SPAN", 17,
"ANNOTATION", 18);
c$.sLock = c$.prototype.sLock =  new JavaObject ();
Clazz.defineStatics (c$,
"sTemp", null);
});
