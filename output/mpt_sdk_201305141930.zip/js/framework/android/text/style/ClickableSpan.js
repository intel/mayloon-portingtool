﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.CharacterStyle", "$.UpdateAppearance"], "android.text.style.ClickableSpan", null, function () {
c$ = Clazz.declareType (android.text.style, "ClickableSpan", android.text.style.CharacterStyle, android.text.style.UpdateAppearance);
Clazz.overrideMethod (c$, "updateDrawState", 
function (ds) {
ds.setColor (ds.linkColor);
ds.setUnderlineText (true);
}, "android.text.TextPaint");
});
