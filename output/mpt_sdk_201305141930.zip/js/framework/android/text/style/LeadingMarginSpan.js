﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.ParagraphStyle", "$.WrapTogetherSpan"], "android.text.style.LeadingMarginSpan", null, function () {
Clazz.declareInterface (android.text.style, "LeadingMarginSpan", android.text.style.ParagraphStyle);
Clazz.declareInterface (android.text.style.LeadingMarginSpan, "LeadingMarginSpan2", [android.text.style.LeadingMarginSpan, android.text.style.WrapTogetherSpan]);
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mFirst = 0;
this.mRest = 0;
Clazz.instantialize (this, arguments);
}, android.text.style.LeadingMarginSpan, "Standard", null, [android.text.style.LeadingMarginSpan, android.text.ParcelableSpan]);
Clazz.makeConstructor (c$, 
function (a, b) {
this.mFirst = a;
this.mRest = b;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a, a);
}, "~N");
Clazz.makeConstructor (c$, 
function (a) {
this.mFirst = a.readInt ();
this.mRest = a.readInt ();
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 10;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
a.writeInt (this.mFirst);
a.writeInt (this.mRest);
}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "getLeadingMargin", 
function (a) {
return a ? this.mFirst : this.mRest;
}, "~B");
Clazz.overrideMethod (c$, "drawLeadingMargin", 
function (a, b, c, d, e, f, g, h, i, j, k, l) {
;}, "android.graphics.Canvas,android.graphics.Paint,~N,~N,~N,~N,~N,CharSequence,~N,~N,~B,android.text.Layout");
c$ = Clazz.p0p ();
});
