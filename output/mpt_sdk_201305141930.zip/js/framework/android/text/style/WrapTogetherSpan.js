﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.ParagraphStyle"], "android.text.style.WrapTogetherSpan", null, function () {
Clazz.declareInterface (android.text.style, "WrapTogetherSpan", android.text.style.ParagraphStyle);
});
