﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.MetricAffectingSpan"], "android.text.style.SubscriptSpan", null, function () {
c$ = Clazz.declareType (android.text.style, "SubscriptSpan", android.text.style.MetricAffectingSpan, android.text.ParcelableSpan);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.text.style.SubscriptSpan, []);
});
Clazz.makeConstructor (c$, 
function (src) {
Clazz.superConstructor (this, android.text.style.SubscriptSpan, []);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 15;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "updateDrawState", 
function (tp) {
tp.baselineShift -= Math.round ((tp.ascent () / 2));
}, "android.text.TextPaint");
Clazz.overrideMethod (c$, "updateMeasureState", 
function (tp) {
tp.baselineShift -= Math.round ((tp.ascent () / 2));
}, "android.text.TextPaint");
});
