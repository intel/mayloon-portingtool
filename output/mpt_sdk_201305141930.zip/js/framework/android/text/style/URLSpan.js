﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.ClickableSpan"], "android.text.style.URLSpan", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mURL = null;
Clazz.instantialize (this, arguments);
}, android.text.style, "URLSpan", android.text.style.ClickableSpan, android.text.ParcelableSpan);
Clazz.makeConstructor (c$, 
function (url) {
Clazz.superConstructor (this, android.text.style.URLSpan, []);
this.mURL = url;
}, "~S");
Clazz.makeConstructor (c$, 
function (src) {
Clazz.superConstructor (this, android.text.style.URLSpan, []);
this.mURL = src.readString ();
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 11;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeString (this.mURL);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "getURL", 
function () {
return this.mURL;
});
Clazz.overrideMethod (c$, "onClick", 
function (widget) {
}, "android.view.View");
});
