﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.MetricAffectingSpan"], "android.text.style.StyleSpan", ["android.graphics.Typeface"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mStyle = 0;
Clazz.instantialize (this, arguments);
}, android.text.style, "StyleSpan", android.text.style.MetricAffectingSpan, android.text.ParcelableSpan);
Clazz.makeConstructor (c$, 
function (style) {
Clazz.superConstructor (this, android.text.style.StyleSpan, []);
this.mStyle = style;
}, "~N");
Clazz.makeConstructor (c$, 
function (src) {
Clazz.superConstructor (this, android.text.style.StyleSpan, []);
this.mStyle = src.readInt ();
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 7;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeInt (this.mStyle);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "getStyle", 
function () {
return this.mStyle;
});
Clazz.overrideMethod (c$, "updateDrawState", 
function (ds) {
android.text.style.StyleSpan.apply (ds, this.mStyle);
}, "android.text.TextPaint");
Clazz.overrideMethod (c$, "updateMeasureState", 
function (paint) {
android.text.style.StyleSpan.apply (paint, this.mStyle);
}, "android.text.TextPaint");
c$.apply = Clazz.defineMethod (c$, "apply", 
($fz = function (paint, style) {
var oldStyle;
var old = paint.getTypeface ();
if (old == null) {
oldStyle = 0;
} else {
oldStyle = old.getStyle ();
}var want = oldStyle | style;
var tf;
if (old == null) {
tf = android.graphics.Typeface.defaultFromStyle (want);
} else {
tf = android.graphics.Typeface.create (old, want);
}var fake = want & ~tf.getStyle ();
if ((fake & 1) != 0) {
paint.setFakeBoldText (true);
}if ((fake & 2) != 0) {
paint.setTextSkewX (-0.25);
}paint.setTypeface (tf);
}, $fz.isPrivate = true, $fz), "android.graphics.Paint,~N");
});
