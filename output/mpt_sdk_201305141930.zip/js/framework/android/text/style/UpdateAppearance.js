﻿Clazz.declarePackage ("android.text.style");
Clazz.declareInterface (android.text.style, "UpdateAppearance");
