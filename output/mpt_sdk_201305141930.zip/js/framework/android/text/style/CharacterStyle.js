﻿Clazz.declarePackage ("android.text.style");
c$ = Clazz.declareType (android.text.style, "CharacterStyle");
c$.wrap = Clazz.defineMethod (c$, "wrap", 
function (cs) {
if (Clazz.instanceOf (cs, android.text.style.MetricAffectingSpan)) {
return  new android.text.style.MetricAffectingSpan.Passthrough (cs);
} else {
return  new android.text.style.CharacterStyle.Passthrough (cs);
}}, "android.text.style.CharacterStyle");
Clazz.defineMethod (c$, "getUnderlying", 
function () {
return this;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mStyle = null;
Clazz.instantialize (this, arguments);
}, android.text.style.CharacterStyle, "Passthrough", android.text.style.CharacterStyle);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.text.style.CharacterStyle.Passthrough, []);
this.mStyle = a;
}, "android.text.style.CharacterStyle");
Clazz.defineMethod (c$, "updateDrawState", 
function (a) {
this.mStyle.updateDrawState (a);
}, "android.text.TextPaint");
Clazz.defineMethod (c$, "getUnderlying", 
function () {
return this.mStyle.getUnderlying ();
});
c$ = Clazz.p0p ();
