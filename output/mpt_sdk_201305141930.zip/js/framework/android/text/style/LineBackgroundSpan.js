﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.ParagraphStyle"], "android.text.style.LineBackgroundSpan", null, function () {
Clazz.declareInterface (android.text.style, "LineBackgroundSpan", android.text.style.ParagraphStyle);
});
