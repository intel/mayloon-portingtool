﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.LeadingMarginSpan", "$.LineHeightSpan"], "android.text.style.DrawableMarginSpan", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mDrawable = null;
this.mPad = 0;
Clazz.instantialize (this, arguments);
}, android.text.style, "DrawableMarginSpan", null, [android.text.style.LeadingMarginSpan, android.text.style.LineHeightSpan]);
Clazz.makeConstructor (c$, 
function (b) {
this.mDrawable = b;
}, "android.graphics.drawable.Drawable");
Clazz.makeConstructor (c$, 
function (b, pad) {
this.mDrawable = b;
this.mPad = pad;
}, "android.graphics.drawable.Drawable,~N");
Clazz.overrideMethod (c$, "getLeadingMargin", 
function (first) {
return this.mDrawable.getIntrinsicWidth () + this.mPad;
}, "~B");
Clazz.overrideMethod (c$, "drawLeadingMargin", 
function (c, p, x, dir, top, baseline, bottom, text, start, end, first, layout) {
var st = (text).getSpanStart (this);
var ix = x;
var itop = layout.getLineTop (layout.getLineForOffset (st));
var dw = this.mDrawable.getIntrinsicWidth ();
var dh = this.mDrawable.getIntrinsicHeight ();
this.mDrawable.setBounds (ix, itop, ix + dw, itop + dh);
this.mDrawable.draw (c);
}, "android.graphics.Canvas,android.graphics.Paint,~N,~N,~N,~N,~N,CharSequence,~N,~N,~B,android.text.Layout");
Clazz.overrideMethod (c$, "chooseHeight", 
function (text, start, end, istartv, v, fm) {
if (end == (text).getSpanEnd (this)) {
var ht = this.mDrawable.getIntrinsicHeight ();
var need = ht - (v + fm.descent - fm.ascent - istartv);
if (need > 0) fm.descent += need;
need = ht - (v + fm.bottom - fm.top - istartv);
if (need > 0) fm.bottom += need;
}}, "CharSequence,~N,~N,~N,~N,android.graphics.Paint.FontMetricsInt");
});
