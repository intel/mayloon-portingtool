﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.ParagraphStyle"], "android.text.style.TabStopSpan", null, function () {
Clazz.declareInterface (android.text.style, "TabStopSpan", android.text.style.ParagraphStyle);
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mTab = 0;
Clazz.instantialize (this, arguments);
}, android.text.style.TabStopSpan, "Standard", null, android.text.style.TabStopSpan);
Clazz.makeConstructor (c$, 
function (a) {
this.mTab = a;
}, "~N");
Clazz.overrideMethod (c$, "getTabStop", 
function () {
return this.mTab;
});
c$ = Clazz.p0p ();
});
