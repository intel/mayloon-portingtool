﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.CharacterStyle", "$.UpdateLayout"], "android.text.style.MetricAffectingSpan", null, function () {
c$ = Clazz.declareType (android.text.style, "MetricAffectingSpan", android.text.style.CharacterStyle, android.text.style.UpdateLayout);
Clazz.overrideMethod (c$, "getUnderlying", 
function () {
return this;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mStyle = null;
Clazz.instantialize (this, arguments);
}, android.text.style.MetricAffectingSpan, "Passthrough", android.text.style.MetricAffectingSpan);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.text.style.MetricAffectingSpan.Passthrough, []);
this.mStyle = a;
}, "android.text.style.MetricAffectingSpan");
Clazz.defineMethod (c$, "updateDrawState", 
function (a) {
this.mStyle.updateDrawState (a);
}, "android.text.TextPaint");
Clazz.defineMethod (c$, "updateMeasureState", 
function (a) {
this.mStyle.updateMeasureState (a);
}, "android.text.TextPaint");
Clazz.defineMethod (c$, "getUnderlying", 
function () {
return this.mStyle.getUnderlying ();
});
c$ = Clazz.p0p ();
});
