﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.DynamicDrawableSpan"], "android.text.style.ImageSpan", ["android.graphics.BitmapFactory", "android.graphics.drawable.BitmapDrawable", "android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDrawable = null;
this.mContentUri = null;
this.mResourceId = 0;
this.mContext = null;
this.mSource = null;
Clazz.instantialize (this, arguments);
}, android.text.style, "ImageSpan", android.text.style.DynamicDrawableSpan);
Clazz.makeConstructor (c$, 
function (b) {
this.construct (null, b, 0);
}, "android.graphics.Bitmap");
Clazz.makeConstructor (c$, 
function (b, verticalAlignment) {
this.construct (null, b, verticalAlignment);
}, "android.graphics.Bitmap,~N");
Clazz.makeConstructor (c$, 
function (context, b) {
this.construct (context, b, 0);
}, "android.content.Context,android.graphics.Bitmap");
Clazz.makeConstructor (c$, 
function (context, b, verticalAlignment) {
Clazz.superConstructor (this, android.text.style.ImageSpan, [verticalAlignment]);
this.mContext = context;
this.mDrawable = context != null ?  new android.graphics.drawable.BitmapDrawable (context.getResources (), b) :  new android.graphics.drawable.BitmapDrawable (b);
var width = this.mDrawable.getIntrinsicWidth ();
var height = this.mDrawable.getIntrinsicHeight ();
this.mDrawable.setBounds (0, 0, width > 0 ? width : 0, height > 0 ? height : 0);
}, "android.content.Context,android.graphics.Bitmap,~N");
Clazz.makeConstructor (c$, 
function (d) {
this.construct (d, 0);
}, "android.graphics.drawable.Drawable");
Clazz.makeConstructor (c$, 
function (d, verticalAlignment) {
Clazz.superConstructor (this, android.text.style.ImageSpan, [verticalAlignment]);
this.mDrawable = d;
}, "android.graphics.drawable.Drawable,~N");
Clazz.makeConstructor (c$, 
function (d, source) {
this.construct (d, source, 0);
}, "android.graphics.drawable.Drawable,~S");
Clazz.makeConstructor (c$, 
function (d, source, verticalAlignment) {
Clazz.superConstructor (this, android.text.style.ImageSpan, [verticalAlignment]);
this.mDrawable = d;
this.mSource = source;
}, "android.graphics.drawable.Drawable,~S,~N");
Clazz.makeConstructor (c$, 
function (context, uri) {
this.construct (context, uri, 0);
}, "android.content.Context,android.net.Uri");
Clazz.makeConstructor (c$, 
function (context, uri, verticalAlignment) {
Clazz.superConstructor (this, android.text.style.ImageSpan, [verticalAlignment]);
this.mContext = context;
this.mContentUri = uri;
this.mSource = uri.toString ();
}, "android.content.Context,android.net.Uri,~N");
Clazz.makeConstructor (c$, 
function (context, resourceId) {
this.construct (context, resourceId, 0);
}, "android.content.Context,~N");
Clazz.makeConstructor (c$, 
function (context, resourceId, verticalAlignment) {
Clazz.superConstructor (this, android.text.style.ImageSpan, [verticalAlignment]);
this.mContext = context;
this.mResourceId = resourceId;
}, "android.content.Context,~N,~N");
Clazz.overrideMethod (c$, "getDrawable", 
function () {
var drawable = null;
if (this.mDrawable != null) {
drawable = this.mDrawable;
} else if (this.mContentUri != null) {
var bitmap = null;
try {
var is = this.mContext.getContentResolver ().openInputStream (this.mContentUri);
bitmap = android.graphics.BitmapFactory.decodeStream (is);
drawable =  new android.graphics.drawable.BitmapDrawable (this.mContext.getResources (), bitmap);
drawable.setBounds (0, 0, drawable.getIntrinsicWidth (), drawable.getIntrinsicHeight ());
is.close ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.e ("sms", "Failed to loaded content " + this.mContentUri, e);
} else {
throw e;
}
}
} else {
try {
drawable = this.mContext.getResources ().getDrawable (this.mResourceId);
drawable.setBounds (0, 0, drawable.getIntrinsicWidth (), drawable.getIntrinsicHeight ());
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.e ("sms", "Unable to find resource: " + this.mResourceId);
} else {
throw e;
}
}
}return drawable;
});
Clazz.defineMethod (c$, "getSource", 
function () {
return this.mSource;
});
});
