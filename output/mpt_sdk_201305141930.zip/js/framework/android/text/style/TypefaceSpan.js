﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.MetricAffectingSpan"], "android.text.style.TypefaceSpan", ["android.graphics.Typeface"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFamily = null;
Clazz.instantialize (this, arguments);
}, android.text.style, "TypefaceSpan", android.text.style.MetricAffectingSpan, android.text.ParcelableSpan);
Clazz.makeConstructor (c$, 
function (family) {
Clazz.superConstructor (this, android.text.style.TypefaceSpan, []);
this.mFamily = family;
}, "~S");
Clazz.makeConstructor (c$, 
function (src) {
Clazz.superConstructor (this, android.text.style.TypefaceSpan, []);
this.mFamily = src.readString ();
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 13;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeString (this.mFamily);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "getFamily", 
function () {
return this.mFamily;
});
Clazz.overrideMethod (c$, "updateDrawState", 
function (ds) {
android.text.style.TypefaceSpan.apply (ds, this.mFamily);
}, "android.text.TextPaint");
Clazz.overrideMethod (c$, "updateMeasureState", 
function (paint) {
android.text.style.TypefaceSpan.apply (paint, this.mFamily);
}, "android.text.TextPaint");
c$.apply = Clazz.defineMethod (c$, "apply", 
($fz = function (paint, family) {
var oldStyle;
var old = paint.getTypeface ();
if (old == null) {
oldStyle = 0;
} else {
oldStyle = old.getStyle ();
}var tf = android.graphics.Typeface.create (family, oldStyle);
var fake = oldStyle & ~tf.getStyle ();
if ((fake & 1) != 0) {
paint.setFakeBoldText (true);
}if ((fake & 2) != 0) {
paint.setTextSkewX (-0.25);
}paint.setTypeface (tf);
}, $fz.isPrivate = true, $fz), "android.graphics.Paint,~S");
});
