﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.MetricAffectingSpan"], "android.text.style.ReplacementSpan", null, function () {
c$ = Clazz.declareType (android.text.style, "ReplacementSpan", android.text.style.MetricAffectingSpan);
Clazz.overrideMethod (c$, "updateMeasureState", 
function (p) {
}, "android.text.TextPaint");
Clazz.overrideMethod (c$, "updateDrawState", 
function (ds) {
}, "android.text.TextPaint");
});
