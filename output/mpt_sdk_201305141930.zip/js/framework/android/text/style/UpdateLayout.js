﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.UpdateAppearance"], "android.text.style.UpdateLayout", null, function () {
Clazz.declareInterface (android.text.style, "UpdateLayout", android.text.style.UpdateAppearance);
});
