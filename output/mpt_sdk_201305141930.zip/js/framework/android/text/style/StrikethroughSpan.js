﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.CharacterStyle", "$.UpdateAppearance"], "android.text.style.StrikethroughSpan", null, function () {
c$ = Clazz.declareType (android.text.style, "StrikethroughSpan", android.text.style.CharacterStyle, [android.text.style.UpdateAppearance, android.text.ParcelableSpan]);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.text.style.StrikethroughSpan, []);
});
Clazz.makeConstructor (c$, 
function (src) {
Clazz.superConstructor (this, android.text.style.StrikethroughSpan, []);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 5;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "updateDrawState", 
function (ds) {
ds.setStrikeThruText (true);
}, "android.text.TextPaint");
});
