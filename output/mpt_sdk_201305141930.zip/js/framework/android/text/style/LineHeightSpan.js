﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.ParagraphStyle", "$.WrapTogetherSpan"], "android.text.style.LineHeightSpan", null, function () {
Clazz.declareInterface (android.text.style, "LineHeightSpan", [android.text.style.ParagraphStyle, android.text.style.WrapTogetherSpan]);
Clazz.declareInterface (android.text.style.LineHeightSpan, "WithDensity", android.text.style.LineHeightSpan);
});
