﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.MetricAffectingSpan"], "android.text.style.ScaleXSpan", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mProportion = 0;
Clazz.instantialize (this, arguments);
}, android.text.style, "ScaleXSpan", android.text.style.MetricAffectingSpan, android.text.ParcelableSpan);
Clazz.makeConstructor (c$, 
function (proportion) {
Clazz.superConstructor (this, android.text.style.ScaleXSpan, []);
this.mProportion = proportion;
}, "~N");
Clazz.makeConstructor (c$, 
function (src) {
Clazz.superConstructor (this, android.text.style.ScaleXSpan, []);
this.mProportion = src.readFloat ();
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 4;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeFloat (this.mProportion);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "getScaleX", 
function () {
return this.mProportion;
});
Clazz.overrideMethod (c$, "updateDrawState", 
function (ds) {
ds.setTextScaleX (ds.getTextScaleX () * this.mProportion);
}, "android.text.TextPaint");
Clazz.overrideMethod (c$, "updateMeasureState", 
function (ds) {
ds.setTextScaleX (ds.getTextScaleX () * this.mProportion);
}, "android.text.TextPaint");
});
