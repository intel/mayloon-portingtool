﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.LeadingMarginSpan"], "android.text.style.QuoteSpan", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mColor = 0;
Clazz.instantialize (this, arguments);
}, android.text.style, "QuoteSpan", null, [android.text.style.LeadingMarginSpan, android.text.ParcelableSpan]);
Clazz.makeConstructor (c$, 
function () {
this.mColor = 0xff0000ff;
});
Clazz.makeConstructor (c$, 
function (color) {
this.mColor = color;
}, "~N");
Clazz.makeConstructor (c$, 
function (src) {
this.mColor = src.readInt ();
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 9;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeInt (this.mColor);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "getColor", 
function () {
return this.mColor;
});
Clazz.overrideMethod (c$, "getLeadingMargin", 
function (first) {
return 4;
}, "~B");
Clazz.overrideMethod (c$, "drawLeadingMargin", 
function (c, p, x, dir, top, baseline, bottom, text, start, end, first, layout) {
}, "android.graphics.Canvas,android.graphics.Paint,~N,~N,~N,~N,~N,CharSequence,~N,~N,~B,android.text.Layout");
Clazz.defineStatics (c$,
"STRIPE_WIDTH", 2,
"GAP_WIDTH", 2);
});
