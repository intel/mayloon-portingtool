﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.LeadingMarginSpan"], "android.text.style.BulletSpan", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mGapWidth = 0;
this.mWantColor = false;
this.mColor = 0;
Clazz.instantialize (this, arguments);
}, android.text.style, "BulletSpan", null, [android.text.style.LeadingMarginSpan, android.text.ParcelableSpan]);
Clazz.makeConstructor (c$, 
function () {
this.mGapWidth = 2;
this.mWantColor = false;
this.mColor = 0;
});
Clazz.makeConstructor (c$, 
function (gapWidth) {
this.mGapWidth = gapWidth;
this.mWantColor = false;
this.mColor = 0;
}, "~N");
Clazz.makeConstructor (c$, 
function (gapWidth, color) {
this.mGapWidth = gapWidth;
this.mWantColor = true;
this.mColor = color;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (src) {
this.mGapWidth = src.readInt ();
this.mWantColor = src.readInt () != 0;
this.mColor = src.readInt ();
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 8;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeInt (this.mGapWidth);
dest.writeInt (this.mWantColor ? 1 : 0);
dest.writeInt (this.mColor);
}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "getLeadingMargin", 
function (first) {
return 6 + this.mGapWidth;
}, "~B");
Clazz.overrideMethod (c$, "drawLeadingMargin", 
function (c, p, x, dir, top, baseline, bottom, text, start, end, first, l) {
}, "android.graphics.Canvas,android.graphics.Paint,~N,~N,~N,~N,~N,CharSequence,~N,~N,~B,android.text.Layout");
Clazz.defineStatics (c$,
"BULLET_RADIUS", 3,
"STANDARD_GAP_WIDTH", 2);
});
