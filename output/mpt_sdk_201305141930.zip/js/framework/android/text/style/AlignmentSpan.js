﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.ParagraphStyle", "android.text.Layout"], "android.text.style.AlignmentSpan", null, function () {
Clazz.declareInterface (android.text.style, "AlignmentSpan", android.text.style.ParagraphStyle);
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mAlignment = null;
Clazz.instantialize (this, arguments);
}, android.text.style.AlignmentSpan, "Standard", null, [android.text.style.AlignmentSpan, android.text.ParcelableSpan]);
Clazz.makeConstructor (c$, 
function (a) {
this.mAlignment = a;
}, "android.text.Layout.Alignment");
Clazz.makeConstructor (c$, 
function (a) {
this.mAlignment = android.text.Layout.Alignment.$valueOf (a.readString ());
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 1;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
a.writeString (this.mAlignment.name ());
}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "getAlignment", 
function () {
return this.mAlignment;
});
c$ = Clazz.p0p ();
});
