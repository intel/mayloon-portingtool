﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.LeadingMarginSpan", "$.LineHeightSpan"], "android.text.style.IconMarginSpan", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mBitmap = null;
this.mPad = 0;
Clazz.instantialize (this, arguments);
}, android.text.style, "IconMarginSpan", null, [android.text.style.LeadingMarginSpan, android.text.style.LineHeightSpan]);
Clazz.makeConstructor (c$, 
function (b) {
this.mBitmap = b;
}, "android.graphics.Bitmap");
Clazz.makeConstructor (c$, 
function (b, pad) {
this.mBitmap = b;
this.mPad = pad;
}, "android.graphics.Bitmap,~N");
Clazz.overrideMethod (c$, "getLeadingMargin", 
function (first) {
return this.mBitmap.getWidth () + this.mPad;
}, "~B");
Clazz.overrideMethod (c$, "drawLeadingMargin", 
function (c, p, x, dir, top, baseline, bottom, text, start, end, first, layout) {
var st = (text).getSpanStart (this);
var itop = layout.getLineTop (layout.getLineForOffset (st));
if (dir < 0) x -= this.mBitmap.getWidth ();
c.drawBitmap (this.mBitmap, x, itop, p);
}, "android.graphics.Canvas,android.graphics.Paint,~N,~N,~N,~N,~N,CharSequence,~N,~N,~B,android.text.Layout");
Clazz.overrideMethod (c$, "chooseHeight", 
function (text, start, end, istartv, v, fm) {
if (end == (text).getSpanEnd (this)) {
var ht = this.mBitmap.getHeight ();
var need = ht - (v + fm.descent - fm.ascent - istartv);
if (need > 0) fm.descent += need;
need = ht - (v + fm.bottom - fm.top - istartv);
if (need > 0) fm.bottom += need;
}}, "CharSequence,~N,~N,~N,~N,android.graphics.Paint.FontMetricsInt");
});
