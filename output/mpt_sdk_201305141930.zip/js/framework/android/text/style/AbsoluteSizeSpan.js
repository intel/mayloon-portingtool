﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.MetricAffectingSpan"], "android.text.style.AbsoluteSizeSpan", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mSize = 0;
this.mDip = false;
Clazz.instantialize (this, arguments);
}, android.text.style, "AbsoluteSizeSpan", android.text.style.MetricAffectingSpan, android.text.ParcelableSpan);
Clazz.makeConstructor (c$, 
function (size) {
Clazz.superConstructor (this, android.text.style.AbsoluteSizeSpan, []);
this.mSize = size;
}, "~N");
Clazz.makeConstructor (c$, 
function (size, dip) {
Clazz.superConstructor (this, android.text.style.AbsoluteSizeSpan, []);
this.mSize = size;
this.mDip = dip;
}, "~N,~B");
Clazz.makeConstructor (c$, 
function (src) {
Clazz.superConstructor (this, android.text.style.AbsoluteSizeSpan, []);
this.mSize = src.readInt ();
this.mDip = src.readInt () != 0;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 16;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeInt (this.mSize);
dest.writeInt (this.mDip ? 1 : 0);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "getSize", 
function () {
return this.mSize;
});
Clazz.defineMethod (c$, "getDip", 
function () {
return this.mDip;
});
Clazz.overrideMethod (c$, "updateDrawState", 
function (ds) {
if (this.mDip) {
ds.setTextSize (this.mSize * ds.density);
} else {
ds.setTextSize (this.mSize);
}}, "android.text.TextPaint");
Clazz.overrideMethod (c$, "updateMeasureState", 
function (ds) {
if (this.mDip) {
ds.setTextSize (this.mSize * ds.density);
} else {
ds.setTextSize (this.mSize);
}}, "android.text.TextPaint");
});
