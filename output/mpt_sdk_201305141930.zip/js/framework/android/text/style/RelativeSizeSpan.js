﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.MetricAffectingSpan"], "android.text.style.RelativeSizeSpan", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mProportion = 0;
Clazz.instantialize (this, arguments);
}, android.text.style, "RelativeSizeSpan", android.text.style.MetricAffectingSpan, android.text.ParcelableSpan);
Clazz.makeConstructor (c$, 
function (proportion) {
Clazz.superConstructor (this, android.text.style.RelativeSizeSpan, []);
this.mProportion = proportion;
}, "~N");
Clazz.makeConstructor (c$, 
function (src) {
Clazz.superConstructor (this, android.text.style.RelativeSizeSpan, []);
this.mProportion = src.readFloat ();
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 3;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeFloat (this.mProportion);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "getSizeChange", 
function () {
return this.mProportion;
});
Clazz.overrideMethod (c$, "updateDrawState", 
function (ds) {
ds.setTextSize (ds.getTextSize () * this.mProportion);
}, "android.text.TextPaint");
Clazz.overrideMethod (c$, "updateMeasureState", 
function (ds) {
ds.setTextSize (ds.getTextSize () * this.mProportion);
}, "android.text.TextPaint");
});
