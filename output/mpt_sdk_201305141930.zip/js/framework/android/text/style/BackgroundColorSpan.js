﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.ParcelableSpan", "android.text.style.CharacterStyle", "$.UpdateAppearance"], "android.text.style.BackgroundColorSpan", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mColor = 0;
Clazz.instantialize (this, arguments);
}, android.text.style, "BackgroundColorSpan", android.text.style.CharacterStyle, [android.text.style.UpdateAppearance, android.text.ParcelableSpan]);
Clazz.makeConstructor (c$, 
function (color) {
Clazz.superConstructor (this, android.text.style.BackgroundColorSpan, []);
this.mColor = color;
}, "~N");
Clazz.makeConstructor (c$, 
function (src) {
Clazz.superConstructor (this, android.text.style.BackgroundColorSpan, []);
this.mColor = src.readInt ();
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "getSpanTypeId", 
function () {
return 12;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeInt (this.mColor);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "getBackgroundColor", 
function () {
return this.mColor;
});
Clazz.overrideMethod (c$, "updateDrawState", 
function (ds) {
ds.bgColor = this.mColor;
}, "android.text.TextPaint");
});
