﻿Clazz.declarePackage ("android.text.style");
Clazz.load (["android.text.style.ReplacementSpan"], "android.text.style.DynamicDrawableSpan", ["java.lang.ref.WeakReference"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mVerticalAlignment = 0;
this.mDrawableRef = null;
Clazz.instantialize (this, arguments);
}, android.text.style, "DynamicDrawableSpan", android.text.style.ReplacementSpan);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.text.style.DynamicDrawableSpan, []);
this.mVerticalAlignment = 0;
});
Clazz.makeConstructor (c$, 
function (verticalAlignment) {
Clazz.superConstructor (this, android.text.style.DynamicDrawableSpan, []);
this.mVerticalAlignment = verticalAlignment;
}, "~N");
Clazz.defineMethod (c$, "getVerticalAlignment", 
function () {
return this.mVerticalAlignment;
});
Clazz.overrideMethod (c$, "getSize", 
function (paint, text, start, end, fm) {
var d = this.getCachedDrawable ();
var rect = d.getBounds ();
if (fm != null) {
fm.ascent = -rect.bottom;
fm.descent = 0;
fm.top = fm.ascent;
fm.bottom = 0;
}return rect.right;
}, "android.graphics.Paint,CharSequence,~N,~N,android.graphics.Paint.FontMetricsInt");
Clazz.overrideMethod (c$, "draw", 
function (canvas, text, start, end, x, top, y, bottom, paint) {
var b = this.getCachedDrawable ();
canvas.save ();
var transY = bottom - b.getBounds ().bottom;
if (this.mVerticalAlignment == 1) {
transY -= paint.getFontMetricsInt ().descent;
}canvas.translate (x, transY);
b.draw (canvas);
canvas.restore ();
}, "android.graphics.Canvas,CharSequence,~N,~N,~N,~N,~N,~N,android.graphics.Paint");
Clazz.defineMethod (c$, "getCachedDrawable", 
($fz = function () {
var wr = this.mDrawableRef;
var d = null;
if (wr != null) d = wr.get ();
if (d == null) {
d = this.getDrawable ();
this.mDrawableRef =  new java.lang.ref.WeakReference (d);
}return d;
}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"TAG", "DynamicDrawableSpan",
"ALIGN_BOTTOM", 0,
"ALIGN_BASELINE", 1);
});
