﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.text.GetChars", "$.Spannable", "$.SpannableStringInternal"], "android.text.SpannableString", null, function () {
c$ = Clazz.declareType (android.text, "SpannableString", android.text.SpannableStringInternal, [CharSequence, android.text.GetChars, android.text.Spannable]);
Clazz.makeConstructor (c$, 
function (source) {
Clazz.superConstructor (this, android.text.SpannableString, [source, 0, source.toString ().length]);
}, "CharSequence");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (source) {
if (Clazz.instanceOf (source, android.text.SpannableString)) {
return source;
} else {
return  new android.text.SpannableString (source);
}}, "CharSequence");
Clazz.overrideMethod (c$, "subSequence", 
function (start, end) {
return  new android.text.SpannableString (this, start, end);
}, "~N,~N");
});
