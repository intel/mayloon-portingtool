﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.text.GetChars", "$.SpannableStringInternal", "$.Spanned"], "android.text.SpannedString", null, function () {
c$ = Clazz.declareType (android.text, "SpannedString", android.text.SpannableStringInternal, [CharSequence, android.text.GetChars, android.text.Spanned]);
Clazz.makeConstructor (c$, 
function (source) {
Clazz.superConstructor (this, android.text.SpannedString, [source, 0, source.toString ().length]);
}, "CharSequence");
Clazz.overrideMethod (c$, "subSequence", 
function (start, end) {
return  new android.text.SpannedString (this, start, end);
}, "~N,~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (source) {
if (Clazz.instanceOf (source, android.text.SpannedString)) {
return source;
} else {
return  new android.text.SpannedString (source);
}}, "CharSequence");
});
