﻿Clazz.declarePackage ("android.text");
c$ = Clazz.declareType (android.text, "Selection");
c$.getSelectionStart = Clazz.defineMethod (c$, "getSelectionStart", 
function (text) {
if (Clazz.instanceOf (text, android.text.Spanned)) {
return (text).getSpanStart (android.text.Selection.SELECTION_START);
} else return -1;
}, "CharSequence");
c$.getSelectionEnd = Clazz.defineMethod (c$, "getSelectionEnd", 
function (text) {
if (Clazz.instanceOf (text, android.text.Spanned)) {
return (text).getSpanStart (android.text.Selection.SELECTION_END);
} else return -1;
}, "CharSequence");
c$.setSelection = Clazz.defineMethod (c$, "setSelection", 
function (text, start, stop) {
var ostart = android.text.Selection.getSelectionStart (text);
var oend = android.text.Selection.getSelectionEnd (text);
if (ostart != start || oend != stop) {
text.setSpan (android.text.Selection.SELECTION_START, start, start, 546);
text.setSpan (android.text.Selection.SELECTION_END, stop, stop, 34);
}}, "android.text.Spannable,~N,~N");
c$.setSelection = Clazz.defineMethod (c$, "setSelection", 
function (text, index) {
android.text.Selection.setSelection (text, index, index);
}, "android.text.Spannable,~N");
c$.selectAll = Clazz.defineMethod (c$, "selectAll", 
function (text) {
android.text.Selection.setSelection (text, 0, text.length ());
}, "android.text.Spannable");
c$.extendSelection = Clazz.defineMethod (c$, "extendSelection", 
function (text, index) {
if (text.getSpanStart (android.text.Selection.SELECTION_END) != index) text.setSpan (android.text.Selection.SELECTION_END, index, index, 34);
}, "android.text.Spannable,~N");
c$.removeSelection = Clazz.defineMethod (c$, "removeSelection", 
function (text) {
text.removeSpan (android.text.Selection.SELECTION_START);
text.removeSpan (android.text.Selection.SELECTION_END);
}, "android.text.Spannable");
Clazz.pu$h ();
c$ = Clazz.declareType (android.text.Selection, "START");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.text.Selection, "END");
c$ = Clazz.p0p ();
c$.SELECTION_START = c$.prototype.SELECTION_START =  new android.text.Selection.START ();
c$.SELECTION_END = c$.prototype.SELECTION_END =  new android.text.Selection.END ();
