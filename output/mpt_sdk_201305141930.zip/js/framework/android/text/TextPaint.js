﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.graphics.Paint"], "android.text.TextPaint", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.bgColor = 0;
this.baselineShift = 0;
this.linkColor = 0;
this.drawableState = null;
this.density = 1.0;
Clazz.instantialize (this, arguments);
}, android.text, "TextPaint", android.graphics.Paint);
Clazz.defineMethod (c$, "set", 
function (tp) {
Clazz.superCall (this, android.text.TextPaint, "set", [tp]);
this.bgColor = tp.bgColor;
this.baselineShift = tp.baselineShift;
this.linkColor = tp.linkColor;
this.drawableState = tp.drawableState;
this.density = tp.density;
}, "android.text.TextPaint");
});
