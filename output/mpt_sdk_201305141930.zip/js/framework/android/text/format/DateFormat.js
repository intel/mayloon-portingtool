﻿Clazz.declarePackage ("android.text.format");
Clazz.load (null, "android.text.format.DateFormat", ["android.provider.Settings", "android.text.SpannableStringBuilder", "$.SpannedString", "android.text.format.DateUtils", "java.lang.StringBuilder", "java.text.DateFormat", "$.SimpleDateFormat", "java.util.Date", "$.GregorianCalendar"], function () {
c$ = Clazz.declareType (android.text.format, "DateFormat");
c$.is24HourFormat = Clazz.defineMethod (c$, "is24HourFormat", 
function (context) {
var value = android.provider.Settings.System.getString (context.getContentResolver (), "time_12_24");
if (value == null) {
var locale = context.getResources ().getConfiguration ().locale;
{
if (android.text.format.DateFormat.sIs24HourLocale != null && android.text.format.DateFormat.sIs24HourLocale.equals (locale)) {
return android.text.format.DateFormat.sIs24Hour;
}}var natural = java.text.DateFormat.getTimeInstance (1, locale);
if (Clazz.instanceOf (natural, java.text.SimpleDateFormat)) {
var sdf = natural;
var pattern = sdf.toPattern ();
if (pattern.indexOf ('H') >= 0) {
value = "24";
} else {
value = "12";
}} else {
value = "12";
}{
($t$ = android.text.format.DateFormat.sIs24HourLocale = locale, android.text.format.DateFormat.prototype.sIs24HourLocale = android.text.format.DateFormat.sIs24HourLocale, $t$);
($t$ = android.text.format.DateFormat.sIs24Hour = !value.equals ("12"), android.text.format.DateFormat.prototype.sIs24Hour = android.text.format.DateFormat.sIs24Hour, $t$);
}}var b24 = !(value == null || value.equals ("12"));
return b24;
}, "android.content.Context");
c$.getTimeFormat = Clazz.defineMethod (c$, "getTimeFormat", 
function (context) {
var b24 = android.text.format.DateFormat.is24HourFormat (context);
var res;
if (b24) {
res = 17039473;
} else {
res = 17039472;
}return  new java.text.SimpleDateFormat (context.getString (res));
}, "android.content.Context");
c$.getDateFormat = Clazz.defineMethod (c$, "getDateFormat", 
function (context) {
var value = android.provider.Settings.System.getString (context.getContentResolver (), "date_format");
return android.text.format.DateFormat.getDateFormatForSetting (context, value);
}, "android.content.Context");
c$.getDateFormatForSetting = Clazz.defineMethod (c$, "getDateFormatForSetting", 
function (context, value) {
var format = android.text.format.DateFormat.getDateFormatStringForSetting (context, value);
return  new java.text.SimpleDateFormat (format);
}, "android.content.Context,~S");
c$.getDateFormatStringForSetting = Clazz.defineMethod (c$, "getDateFormatStringForSetting", 
($fz = function (context, value) {
if (value != null) {
var month = value.indexOf ('M');
var day = value.indexOf ('d');
var year = value.indexOf ('y');
if (month >= 0 && day >= 0 && year >= 0) {
var template = context.getString (17039476);
if (year < month && year < day) {
if (month < day) {
value = String.format (template, ["yyyy", "MM", "dd"]);
} else {
value = String.format (template, ["yyyy", "dd", "MM"]);
}} else if (month < day) {
if (day < year) {
value = String.format (template, ["MM", "dd", "yyyy"]);
} else {
value = String.format (template, ["MM", "yyyy", "dd"]);
}} else {
if (month < year) {
value = String.format (template, ["dd", "MM", "yyyy"]);
} else {
value = String.format (template, ["dd", "yyyy", "MM"]);
}}return value;
}}value = context.getString (17039475);
return value;
}, $fz.isPrivate = true, $fz), "android.content.Context,~S");
c$.getLongDateFormat = Clazz.defineMethod (c$, "getLongDateFormat", 
function (context) {
return java.text.DateFormat.getDateInstance (1);
}, "android.content.Context");
c$.getMediumDateFormat = Clazz.defineMethod (c$, "getMediumDateFormat", 
function (context) {
return java.text.DateFormat.getDateInstance (2);
}, "android.content.Context");
c$.getDateFormatOrder = Clazz.defineMethod (c$, "getDateFormatOrder", 
function (context) {
var order = ['d', 'M', 'y'];
var value = android.text.format.DateFormat.getDateFormatString (context);
var index = 0;
var foundDate = false;
var foundMonth = false;
var foundYear = false;
for (var c, $c = 0, $$c = value.toCharArray (); $c < $$c.length && ((c = $$c[$c]) || true); $c++) {
if (!foundDate && ((c).charCodeAt (0) == ('d').charCodeAt (0))) {
foundDate = true;
order[index] = 'd';
index++;
}if (!foundMonth && ((c).charCodeAt (0) == ('M').charCodeAt (0))) {
foundMonth = true;
order[index] = 'M';
index++;
}if (!foundYear && ((c).charCodeAt (0) == ('y').charCodeAt (0))) {
foundYear = true;
order[index] = 'y';
index++;
}}
return order;
}, "android.content.Context");
c$.getDateFormatString = Clazz.defineMethod (c$, "getDateFormatString", 
($fz = function (context) {
var value = android.provider.Settings.System.getString (context.getContentResolver (), "date_format");
return android.text.format.DateFormat.getDateFormatStringForSetting (context, value);
}, $fz.isPrivate = true, $fz), "android.content.Context");
c$.format = Clazz.defineMethod (c$, "format", 
function (inFormat, inTimeInMillis) {
return android.text.format.DateFormat.format (inFormat,  new java.util.Date (inTimeInMillis));
}, "CharSequence,~N");
c$.format = Clazz.defineMethod (c$, "format", 
function (inFormat, inDate) {
var c =  new java.util.GregorianCalendar ();
c.setTime (inDate);
return android.text.format.DateFormat.format (inFormat, c);
}, "CharSequence,java.util.Date");
c$.format = Clazz.defineMethod (c$, "format", 
function (inFormat, inDate) {
var s =  new android.text.SpannableStringBuilder (inFormat);
var c;
var count;
var len = inFormat.length ();
for (var i = 0; i < len; i += count) {
var temp;
count = 1;
c = (s.charAt (i)).charCodeAt (0);
if (c == (''').charCodeAt (0)) {
count = android.text.format.DateFormat.appendQuotedText (s, i, len);
len = s.length ();
continue ;}while ((i + count < len) && ((s.charAt (i + count)).charCodeAt (0) == c)) {
count++;
}
var replacement;
switch (c) {
case 'a':
replacement = android.text.format.DateUtils.getAMPMString (inDate.get (9));
break;
case 'A':
replacement = android.text.format.DateUtils.getAMPMString (inDate.get (9));
break;
case 'd':
replacement = android.text.format.DateFormat.zeroPad (inDate.get (5), count);
break;
case 'E':
temp = inDate.get (7);
replacement = android.text.format.DateUtils.getDayOfWeekString (temp, count < 4 ? 20 : 10);
break;
case 'h':
temp = inDate.get (10);
if (0 == temp) temp = 12;
replacement = android.text.format.DateFormat.zeroPad (temp, count);
break;
case 'k':
replacement = android.text.format.DateFormat.zeroPad (inDate.get (11), count);
break;
case 'm':
replacement = android.text.format.DateFormat.zeroPad (inDate.get (12), count);
break;
case 'M':
replacement = android.text.format.DateFormat.getMonthString (inDate, count);
break;
case 's':
replacement = android.text.format.DateFormat.zeroPad (inDate.get (13), count);
break;
case 'z':
replacement = android.text.format.DateFormat.getTimeZoneString (inDate, count);
break;
case 'y':
replacement = android.text.format.DateFormat.getYearString (inDate, count);
break;
default:
replacement = null;
break;
}
if (replacement != null) {
s.replace (i, i + count, replacement);
count = replacement.length;
len = s.length ();
}}
if (Clazz.instanceOf (inFormat, android.text.Spanned)) return  new android.text.SpannedString (s);
 else return s.toString ();
}, "CharSequence,java.util.Calendar");
c$.getMonthString = Clazz.defineMethod (c$, "getMonthString", 
($fz = function (inDate, count) {
var month = inDate.get (2);
if (count >= 4) return android.text.format.DateUtils.getMonthString (month, 10);
 else if (count == 3) return android.text.format.DateUtils.getMonthString (month, 20);
 else {
return android.text.format.DateFormat.zeroPad (month + 1, count);
}}, $fz.isPrivate = true, $fz), "java.util.Calendar,~N");
c$.getTimeZoneString = Clazz.defineMethod (c$, "getTimeZoneString", 
($fz = function (inDate, count) {
var tz = inDate.getTimeZone ();
if (count < 2) {
return android.text.format.DateFormat.formatZoneOffset (inDate.get (16) + inDate.get (15), count);
} else {
var dst = inDate.get (16) != 0;
return tz.getDisplayName (dst, 0);
}}, $fz.isPrivate = true, $fz), "java.util.Calendar,~N");
c$.formatZoneOffset = Clazz.defineMethod (c$, "formatZoneOffset", 
($fz = function (offset, count) {
offset /= 1000;
var tb =  new StringBuilder ();
if (offset < 0) {
tb.insert (0, "-");
offset = -offset;
} else {
tb.insert (0, "+");
}var hours = Math.floor (offset / 3600);
var minutes = Math.floor ((offset % 3600) / 60);
tb.append (android.text.format.DateFormat.zeroPad (hours, 2));
tb.append (android.text.format.DateFormat.zeroPad (minutes, 2));
return tb.toString ();
}, $fz.isPrivate = true, $fz), "~N,~N");
c$.getYearString = Clazz.defineMethod (c$, "getYearString", 
($fz = function (inDate, count) {
var year = inDate.get (1);
return (count <= 2) ? android.text.format.DateFormat.zeroPad (year % 100, 2) : String.valueOf (year);
}, $fz.isPrivate = true, $fz), "java.util.Calendar,~N");
c$.appendQuotedText = Clazz.defineMethod (c$, "appendQuotedText", 
($fz = function (s, i, len) {
if (i + 1 < len && (s.charAt (i + 1)).charCodeAt (0) == (''').charCodeAt (0)) {
s.$delete (i, i + 1);
return 1;
}var count = 0;
s.$delete (i, i + 1);
len--;
while (i < len) {
var c = s.charAt (i);
if ((c).charCodeAt (0) == (''').charCodeAt (0)) {
if (i + 1 < len && (s.charAt (i + 1)).charCodeAt (0) == (''').charCodeAt (0)) {
s.$delete (i, i + 1);
len--;
count++;
i++;
} else {
s.$delete (i, i + 1);
break;
}} else {
i++;
count++;
}}
return count;
}, $fz.isPrivate = true, $fz), "android.text.SpannableStringBuilder,~N,~N");
c$.zeroPad = Clazz.defineMethod (c$, "zeroPad", 
($fz = function (inValue, inMinDigits) {
var val = String.valueOf (inValue);
if (val.length < inMinDigits) {
var buf =  Clazz.newArray (inMinDigits, '\0');
for (var i = 0; i < inMinDigits; i++) buf[i] = '0';

val.getChars (0, val.length, buf, inMinDigits - val.length);
val =  String.instantialize (buf);
}return val;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineStatics (c$,
"QUOTE", '\'',
"AM_PM", 'a',
"CAPITAL_AM_PM", 'A',
"DATE", 'd',
"DAY", 'E',
"HOUR", 'h',
"HOUR_OF_DAY", 'k',
"MINUTE", 'm',
"MONTH", 'M',
"SECONDS", 's',
"TIME_ZONE", 'z',
"YEAR", 'y');
c$.sLocaleLock = c$.prototype.sLocaleLock =  new JavaObject ();
Clazz.defineStatics (c$,
"sIs24HourLocale", null,
"sIs24Hour", false);
});
