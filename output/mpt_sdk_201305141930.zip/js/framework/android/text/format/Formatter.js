﻿Clazz.declarePackage ("android.text.format");
Clazz.load (null, "android.text.format.Formatter", ["java.lang.StringBuffer"], function () {
c$ = Clazz.declareType (android.text.format, "Formatter");
c$.formatFileSize = Clazz.defineMethod (c$, "formatFileSize", 
function (context, number) {
return android.text.format.Formatter.formatFileSize (context, number, false);
}, "android.content.Context,~N");
c$.formatShortFileSize = Clazz.defineMethod (c$, "formatShortFileSize", 
function (context, number) {
return android.text.format.Formatter.formatFileSize (context, number, true);
}, "android.content.Context,~N");
c$.formatFileSize = Clazz.defineMethod (c$, "formatFileSize", 
($fz = function (context, number, shorter) {
if (context == null) {
return "";
}var result = number;
var suffix = 17039530;
if (result > 900) {
suffix = 17039531;
result = result / 1024;
}if (result > 900) {
suffix = 17039532;
result = result / 1024;
}if (result > 900) {
suffix = 17039533;
result = result / 1024;
}if (result > 900) {
suffix = 17039534;
result = result / 1024;
}if (result > 900) {
suffix = 17039535;
result = result / 1024;
}var value;
if (result < 1) {
value = String.format ("%.2f", [new Float (result)]);
} else if (result < 10) {
if (shorter) {
value = String.format ("%.1f", [new Float (result)]);
} else {
value = String.format ("%.2f", [new Float (result)]);
}} else if (result < 100) {
if (shorter) {
value = String.format ("%.0f", [new Float (result)]);
} else {
value = String.format ("%.2f", [new Float (result)]);
}} else {
value = String.format ("%.0f", [new Float (result)]);
}return context.getResources ().getString (17039536, [value, context.getString (suffix)]);
}, $fz.isPrivate = true, $fz), "android.content.Context,~N,~B");
c$.formatIpAddress = Clazz.defineMethod (c$, "formatIpAddress", 
function (addr) {
var buf =  new StringBuffer ();
buf.append (addr & 0xff).append ('.').append ((addr >>>= 8) & 0xff).append ('.').append ((addr >>>= 8) & 0xff).append ('.').append ((addr >>>= 8) & 0xff);
return buf.toString ();
}, "~N");
});
