﻿Clazz.declarePackage ("android.text.format");
Clazz.load (null, "android.text.format.DateUtils", ["android.content.res.Resources", "android.text.format.DateFormat", "$.Time", "java.lang.StringBuilder", "java.text.DateFormat", "java.util.Calendar", "$.Formatter", "$.GregorianCalendar", "$.Locale", "$.TimeZone"], function () {
c$ = Clazz.declareType (android.text.format, "DateUtils");
c$.getDayOfWeekString = Clazz.defineMethod (c$, "getDayOfWeekString", 
function (dayOfWeek, abbrev) {
var list;
switch (abbrev) {
case 10:
list = android.text.format.DateUtils.sDaysLong;
break;
case 20:
list = android.text.format.DateUtils.sDaysMedium;
break;
case 30:
list = android.text.format.DateUtils.sDaysShort;
break;
case 40:
list = android.text.format.DateUtils.sDaysShort;
break;
case 50:
list = android.text.format.DateUtils.sDaysShortest;
break;
default:
list = android.text.format.DateUtils.sDaysMedium;
break;
}
var r = android.content.res.Resources.getSystem ();
return r.getString (list[dayOfWeek - 1]);
}, "~N,~N");
c$.getAMPMString = Clazz.defineMethod (c$, "getAMPMString", 
function (ampm) {
var r = android.content.res.Resources.getSystem ();
return r.getString (android.text.format.DateUtils.sAmPm[ampm - 0]);
}, "~N");
c$.getMonthString = Clazz.defineMethod (c$, "getMonthString", 
function (month, abbrev) {
var list;
switch (abbrev) {
case 10:
list = android.text.format.DateUtils.sMonthsLong;
break;
case 20:
list = android.text.format.DateUtils.sMonthsMedium;
break;
case 30:
list = android.text.format.DateUtils.sMonthsMedium;
break;
case 40:
list = android.text.format.DateUtils.sMonthsMedium;
break;
case 50:
list = android.text.format.DateUtils.sMonthsShortest;
break;
default:
list = android.text.format.DateUtils.sMonthsMedium;
break;
}
var r = android.content.res.Resources.getSystem ();
return r.getString (list[month - 0]);
}, "~N,~N");
c$.getStandaloneMonthString = Clazz.defineMethod (c$, "getStandaloneMonthString", 
function (month, abbrev) {
var list;
switch (abbrev) {
case 10:
list = android.text.format.DateUtils.sMonthsStandaloneLong;
break;
case 20:
list = android.text.format.DateUtils.sMonthsMedium;
break;
case 30:
list = android.text.format.DateUtils.sMonthsMedium;
break;
case 40:
list = android.text.format.DateUtils.sMonthsMedium;
break;
case 50:
list = android.text.format.DateUtils.sMonthsShortest;
break;
default:
list = android.text.format.DateUtils.sMonthsMedium;
break;
}
var r = android.content.res.Resources.getSystem ();
return r.getString (list[month - 0]);
}, "~N,~N");
c$.getRelativeTimeSpanString = Clazz.defineMethod (c$, "getRelativeTimeSpanString", 
function (startTime) {
return android.text.format.DateUtils.getRelativeTimeSpanString (startTime, System.currentTimeMillis (), 60000);
}, "~N");
c$.getRelativeTimeSpanString = Clazz.defineMethod (c$, "getRelativeTimeSpanString", 
function (time, now, minResolution) {
var flags = 65556;
return android.text.format.DateUtils.getRelativeTimeSpanString (time, now, minResolution, flags);
}, "~N,~N,~N");
c$.getRelativeTimeSpanString = Clazz.defineMethod (c$, "getRelativeTimeSpanString", 
function (time, now, minResolution, flags) {
var r = android.content.res.Resources.getSystem ();
var abbrevRelative = (flags & (786432)) != 0;
var past = (now >= time);
var duration = Math.abs (now - time);
var resId;
var count;
if (duration < 60000 && minResolution < 60000) {
count = Math.floor (duration / 1000);
if (past) {
if (abbrevRelative) {
resId = 17760265;
} else {
resId = 17760256;
}} else {
if (abbrevRelative) {
resId = 17760269;
} else {
resId = 17760261;
}}} else if (duration < 3600000 && minResolution < 3600000) {
count = Math.floor (duration / 60000);
if (past) {
if (abbrevRelative) {
resId = 17760266;
} else {
resId = 17760257;
}} else {
if (abbrevRelative) {
resId = 17760270;
} else {
resId = 17760262;
}}} else if (duration < 86400000 && minResolution < 86400000) {
count = Math.floor (duration / 3600000);
if (past) {
if (abbrevRelative) {
resId = 17760267;
} else {
resId = 17760258;
}} else {
if (abbrevRelative) {
resId = 17760271;
} else {
resId = 17760263;
}}} else if (duration < 604800000 && minResolution < 604800000) {
count = android.text.format.DateUtils.getNumberOfDaysPassed (time, now);
if (past) {
if (abbrevRelative) {
resId = 17760268;
} else {
resId = 17760260;
}} else {
if (abbrevRelative) {
resId = 17760272;
} else {
resId = 17760264;
}}} else {
return android.text.format.DateUtils.formatDateRange (null, time, time, flags);
}var format = r.getQuantityString (resId, count);
return String.format (format, [new Long (count)]);
}, "~N,~N,~N,~N");
c$.getNumberOfDaysPassed = Clazz.defineMethod (c$, "getNumberOfDaysPassed", 
($fz = function (date1, date2) {
if (android.text.format.DateUtils.sThenTime == null) {
($t$ = android.text.format.DateUtils.sThenTime =  new android.text.format.Time (), android.text.format.DateUtils.prototype.sThenTime = android.text.format.DateUtils.sThenTime, $t$);
}android.text.format.DateUtils.sThenTime.set (date1);
var day1 = android.text.format.Time.getJulianDay (date1, android.text.format.DateUtils.sThenTime.gmtoff);
android.text.format.DateUtils.sThenTime.set (date2);
var day2 = android.text.format.Time.getJulianDay (date2, android.text.format.DateUtils.sThenTime.gmtoff);
return Math.abs (day2 - day1);
}, $fz.isPrivate = true, $fz), "~N,~N");
c$.getRelativeDateTimeString = Clazz.defineMethod (c$, "getRelativeDateTimeString", 
function (c, time, minResolution, transitionResolution, flags) {
var r = android.content.res.Resources.getSystem ();
var now = System.currentTimeMillis ();
var duration = Math.abs (now - time);
if (transitionResolution > 604800000) {
transitionResolution = 604800000;
} else if (transitionResolution < 86400000) {
transitionResolution = 86400000;
}var timeClause = android.text.format.DateUtils.formatDateRange (c, time, time, 1);
var result;
if (duration < transitionResolution) {
var relativeClause = android.text.format.DateUtils.getRelativeTimeSpanString (time, now, minResolution, flags);
result = r.getString (17040090, [relativeClause, timeClause]);
} else {
var dateClause = android.text.format.DateUtils.getRelativeTimeSpanString (c, time, false);
result = r.getString (17039480, [dateClause, timeClause]);
}return result;
}, "android.content.Context,~N,~N,~N,~N");
c$.initFormatStrings = Clazz.defineMethod (c$, "initFormatStrings", 
($fz = function () {
{
android.text.format.DateUtils.initFormatStringsLocked ();
}}, $fz.isPrivate = true, $fz));
c$.initFormatStringsLocked = Clazz.defineMethod (c$, "initFormatStringsLocked", 
($fz = function () {
var r = android.content.res.Resources.getSystem ();
var cfg = r.getConfiguration ();
if (android.text.format.DateUtils.sLastConfig == null || !android.text.format.DateUtils.sLastConfig.equals (cfg)) {
($t$ = android.text.format.DateUtils.sLastConfig = cfg, android.text.format.DateUtils.prototype.sLastConfig = android.text.format.DateUtils.sLastConfig, $t$);
($t$ = android.text.format.DateUtils.sStatusTimeFormat = java.text.DateFormat.getTimeInstance (3), android.text.format.DateUtils.prototype.sStatusTimeFormat = android.text.format.DateUtils.sStatusTimeFormat, $t$);
($t$ = android.text.format.DateUtils.sElapsedFormatMMSS = r.getString (17040095), android.text.format.DateUtils.prototype.sElapsedFormatMMSS = android.text.format.DateUtils.sElapsedFormatMMSS, $t$);
($t$ = android.text.format.DateUtils.sElapsedFormatHMMSS = r.getString (17040096), android.text.format.DateUtils.prototype.sElapsedFormatHMMSS = android.text.format.DateUtils.sElapsedFormatHMMSS, $t$);
}}, $fz.isPrivate = true, $fz));
c$.timeString = Clazz.defineMethod (c$, "timeString", 
function (millis) {
{
android.text.format.DateUtils.initFormatStringsLocked ();
return android.text.format.DateUtils.sStatusTimeFormat.format (new Long (millis));
}}, "~N");
c$.formatElapsedTime = Clazz.defineMethod (c$, "formatElapsedTime", 
function (elapsedSeconds) {
return android.text.format.DateUtils.formatElapsedTime (null, elapsedSeconds);
}, "~N");
c$.formatElapsedTime = Clazz.defineMethod (c$, "formatElapsedTime", 
function (recycle, elapsedSeconds) {
android.text.format.DateUtils.initFormatStrings ();
var hours = 0;
var minutes = 0;
var seconds = 0;
if (elapsedSeconds >= 3600) {
hours = Math.floor (elapsedSeconds / 3600);
elapsedSeconds -= hours * 3600;
}if (elapsedSeconds >= 60) {
minutes = Math.floor (elapsedSeconds / 60);
elapsedSeconds -= minutes * 60;
}seconds = elapsedSeconds;
var result;
if (hours > 0) {
return android.text.format.DateUtils.formatElapsedTime (recycle, android.text.format.DateUtils.sElapsedFormatHMMSS, hours, minutes, seconds);
} else {
return android.text.format.DateUtils.formatElapsedTime (recycle, android.text.format.DateUtils.sElapsedFormatMMSS, minutes, seconds);
}}, "StringBuilder,~N");
c$.formatElapsedTime = Clazz.defineMethod (c$, "formatElapsedTime", 
($fz = function (recycle, format, hours, minutes, seconds) {
if ("%1$d:%2$02d:%3$02d".equals (format)) {
var sb = recycle;
if (sb == null) {
sb =  new StringBuilder (8);
} else {
sb.setLength (0);
}sb.append (hours);
sb.append (':');
if (minutes < 10) {
sb.append ('0');
} else {
sb.append (android.text.format.DateUtils.toDigitChar (Math.floor (minutes / 10)));
}sb.append (android.text.format.DateUtils.toDigitChar (minutes % 10));
sb.append (':');
if (seconds < 10) {
sb.append ('0');
} else {
sb.append (android.text.format.DateUtils.toDigitChar (Math.floor (seconds / 10)));
}sb.append (android.text.format.DateUtils.toDigitChar (seconds % 10));
return sb.toString ();
} else {
return String.format (format, [new Long (hours), new Long (minutes), new Long (seconds)]);
}}, $fz.isPrivate = true, $fz), "StringBuilder,~S,~N,~N,~N");
c$.formatElapsedTime = Clazz.defineMethod (c$, "formatElapsedTime", 
($fz = function (recycle, format, minutes, seconds) {
if ("%1$02d:%2$02d".equals (format)) {
var sb = recycle;
if (sb == null) {
sb =  new StringBuilder (8);
} else {
sb.setLength (0);
}if (minutes < 10) {
sb.append ('0');
} else {
sb.append (android.text.format.DateUtils.toDigitChar (Math.floor (minutes / 10)));
}sb.append (android.text.format.DateUtils.toDigitChar (minutes % 10));
sb.append (':');
if (seconds < 10) {
sb.append ('0');
} else {
sb.append (android.text.format.DateUtils.toDigitChar (Math.floor (seconds / 10)));
}sb.append (android.text.format.DateUtils.toDigitChar (seconds % 10));
return sb.toString ();
} else {
return String.format (format, [new Long (minutes), new Long (seconds)]);
}}, $fz.isPrivate = true, $fz), "StringBuilder,~S,~N,~N");
c$.toDigitChar = Clazz.defineMethod (c$, "toDigitChar", 
($fz = function (digit) {
return String.fromCharCode ((digit + ('0').charCodeAt (0)));
}, $fz.isPrivate = true, $fz), "~N");
c$.formatSameDayTime = Clazz.defineMethod (c$, "formatSameDayTime", 
function (then, now, dateStyle, timeStyle) {
var thenCal =  new java.util.GregorianCalendar ();
thenCal.setTimeInMillis (then);
var thenDate = thenCal.getTime ();
var nowCal =  new java.util.GregorianCalendar ();
nowCal.setTimeInMillis (now);
var f;
if (thenCal.get (1) == nowCal.get (1) && thenCal.get (2) == nowCal.get (2) && thenCal.get (5) == nowCal.get (5)) {
f = java.text.DateFormat.getTimeInstance (timeStyle);
} else {
f = java.text.DateFormat.getDateInstance (dateStyle);
}return f.format (thenDate);
}, "~N,~N,~N,~N");
c$.newCalendar = Clazz.defineMethod (c$, "newCalendar", 
function (zulu) {
if (zulu) return java.util.Calendar.getInstance (java.util.TimeZone.getTimeZone ("GMT"));
return java.util.Calendar.getInstance ();
}, "~B");
c$.isToday = Clazz.defineMethod (c$, "isToday", 
function (when) {
var time =  new android.text.format.Time ();
time.set (when);
var thenYear = time.year;
var thenMonth = time.month;
var thenMonthDay = time.monthDay;
time.set (System.currentTimeMillis ());
return (thenYear == time.year) && (thenMonth == time.month) && (thenMonthDay == time.monthDay);
}, "~N");
c$.isUTC = Clazz.defineMethod (c$, "isUTC", 
function (s) {
if (s.length == 16 && (s.charAt (15)).charCodeAt (0) == ('Z').charCodeAt (0)) {
return true;
}if (s.length == 9 && (s.charAt (8)).charCodeAt (0) == ('Z').charCodeAt (0)) {
return true;
}return false;
}, "~S");
c$.writeDateTime = Clazz.defineMethod (c$, "writeDateTime", 
function (cal) {
var tz = java.util.TimeZone.getTimeZone ("GMT");
var c =  new java.util.GregorianCalendar (tz);
c.setTimeInMillis (cal.getTimeInMillis ());
return android.text.format.DateUtils.writeDateTime (c, true);
}, "java.util.Calendar");
c$.writeDateTime = Clazz.defineMethod (c$, "writeDateTime", 
function (cal, zulu) {
var sb =  new StringBuilder ();
sb.ensureCapacity (16);
if (zulu) {
sb.setLength (16);
sb.setCharAt (15, 'Z');
} else {
sb.setLength (15);
}return android.text.format.DateUtils.writeDateTime (cal, sb);
}, "java.util.Calendar,~B");
c$.writeDateTime = Clazz.defineMethod (c$, "writeDateTime", 
function (cal, sb) {
var n;
n = cal.get (1);
sb.setCharAt (3, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n /= 10;
sb.setCharAt (2, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n /= 10;
sb.setCharAt (1, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n /= 10;
sb.setCharAt (0, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n = cal.get (2) + 1;
sb.setCharAt (5, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n /= 10;
sb.setCharAt (4, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n = cal.get (5);
sb.setCharAt (7, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n /= 10;
sb.setCharAt (6, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
sb.setCharAt (8, 'T');
n = cal.get (11);
sb.setCharAt (10, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n /= 10;
sb.setCharAt (9, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n = cal.get (12);
sb.setCharAt (12, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n /= 10;
sb.setCharAt (11, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n = cal.get (13);
sb.setCharAt (14, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
n /= 10;
sb.setCharAt (13, String.fromCharCode ((('0').charCodeAt (0) + n % 10)));
return sb.toString ();
}, "java.util.Calendar,StringBuilder");
c$.assign = Clazz.defineMethod (c$, "assign", 
function (lval, rval) {
lval.clear ();
lval.setTimeInMillis (rval.getTimeInMillis ());
}, "java.util.Calendar,java.util.Calendar");
c$.formatDateRange = Clazz.defineMethod (c$, "formatDateRange", 
function (context, startMillis, endMillis, flags) {
var f =  new java.util.Formatter ( new StringBuilder (50), java.util.Locale.getDefault ());
return android.text.format.DateUtils.formatDateRange (context, f, startMillis, endMillis, flags).toString ();
}, "android.content.Context,~N,~N,~N");
c$.formatDateRange = Clazz.defineMethod (c$, "formatDateRange", 
function (context, formatter, startMillis, endMillis, flags) {
return android.text.format.DateUtils.formatDateRange (context, formatter, startMillis, endMillis, flags, null);
}, "android.content.Context,java.util.Formatter,~N,~N,~N");
c$.formatDateRange = Clazz.defineMethod (c$, "formatDateRange", 
function (context, formatter, startMillis, endMillis, flags, timeZone) {
var res = android.content.res.Resources.getSystem ();
var showTime = (flags & 1) != 0;
var showWeekDay = (flags & 2) != 0;
var showYear = (flags & 4) != 0;
var noYear = (flags & 8) != 0;
var useUTC = (flags & 8192) != 0;
var abbrevWeekDay = (flags & (557056)) != 0;
var abbrevMonth = (flags & (589824)) != 0;
var noMonthDay = (flags & 32) != 0;
var numericDate = (flags & 131072) != 0;
var isInstant = (startMillis == endMillis);
var startDate;
if (timeZone != null) {
startDate =  new android.text.format.Time (timeZone);
} else if (useUTC) {
startDate =  new android.text.format.Time ("UTC");
} else {
startDate =  new android.text.format.Time ();
}startDate.set (startMillis);
var endDate;
var dayDistance;
if (isInstant) {
endDate = startDate;
dayDistance = 0;
} else {
if (timeZone != null) {
endDate =  new android.text.format.Time (timeZone);
} else if (useUTC) {
endDate =  new android.text.format.Time ("UTC");
} else {
endDate =  new android.text.format.Time ();
}endDate.set (endMillis);
var startJulianDay = android.text.format.Time.getJulianDay (startMillis, startDate.gmtoff);
var endJulianDay = android.text.format.Time.getJulianDay (endMillis, endDate.gmtoff);
dayDistance = endJulianDay - startJulianDay;
}if (!isInstant && (endDate.hour | endDate.minute | endDate.second) == 0 && (!showTime || dayDistance <= 1)) {
endDate.monthDay -= 1;
endDate.normalize (true);
}var startDay = startDate.monthDay;
var startMonthNum = startDate.month;
var startYear = startDate.year;
var endDay = endDate.monthDay;
var endMonthNum = endDate.month;
var endYear = endDate.year;
var startWeekDayString = "";
var endWeekDayString = "";
if (showWeekDay) {
var weekDayFormat = "";
if (abbrevWeekDay) {
weekDayFormat = "%a";
} else {
weekDayFormat = "%A";
}startWeekDayString = startDate.format (weekDayFormat);
endWeekDayString = isInstant ? startWeekDayString : endDate.format (weekDayFormat);
}var startTimeString = "";
var endTimeString = "";
if (showTime) {
var startTimeFormat = "";
var endTimeFormat = "";
var force24Hour = (flags & 128) != 0;
var force12Hour = (flags & 64) != 0;
var use24Hour;
if (force24Hour) {
use24Hour = true;
} else if (force12Hour) {
use24Hour = false;
} else {
use24Hour = android.text.format.DateFormat.is24HourFormat (context);
}if (use24Hour) {
startTimeFormat = endTimeFormat = res.getString (17039469);
} else {
var abbrevTime = (flags & (540672)) != 0;
var capAMPM = (flags & 256) != 0;
var noNoon = (flags & 512) != 0;
var capNoon = (flags & 1024) != 0;
var noMidnight = (flags & 2048) != 0;
var capMidnight = (flags & 4096) != 0;
var startOnTheHour = startDate.minute == 0 && startDate.second == 0;
var endOnTheHour = endDate.minute == 0 && endDate.second == 0;
if (abbrevTime && startOnTheHour) {
if (capAMPM) {
startTimeFormat = res.getString (17040041);
} else {
startTimeFormat = res.getString (17040040);
}} else {
if (capAMPM) {
startTimeFormat = res.getString (17039471);
} else {
startTimeFormat = res.getString (17039470);
}}if (!isInstant) {
if (abbrevTime && endOnTheHour) {
if (capAMPM) {
endTimeFormat = res.getString (17040041);
} else {
endTimeFormat = res.getString (17040040);
}} else {
if (capAMPM) {
endTimeFormat = res.getString (17039471);
} else {
endTimeFormat = res.getString (17039470);
}}if (endDate.hour == 12 && endOnTheHour && !noNoon) {
if (capNoon) {
endTimeFormat = res.getString (17040092);
} else {
endTimeFormat = res.getString (17040091);
}} else if (endDate.hour == 0 && endOnTheHour && !noMidnight) {
if (capMidnight) {
endTimeFormat = res.getString (17040094);
} else {
endTimeFormat = res.getString (17040093);
}}}if (startDate.hour == 12 && startOnTheHour && !noNoon) {
if (capNoon) {
startTimeFormat = res.getString (17040092);
} else {
startTimeFormat = res.getString (17040091);
}}}startTimeString = startDate.format (startTimeFormat);
endTimeString = isInstant ? startTimeString : endDate.format (endTimeFormat);
}if (showYear) {
} else if (noYear) {
showYear = false;
} else if (startYear != endYear) {
showYear = true;
} else {
var currentTime =  new android.text.format.Time ();
currentTime.setToNow ();
showYear = startYear != currentTime.year;
}var defaultDateFormat;
var fullFormat;
var dateRange;
if (numericDate) {
defaultDateFormat = res.getString (17039474);
} else if (showYear) {
if (abbrevMonth) {
if (noMonthDay) {
defaultDateFormat = res.getString (17039488);
} else {
defaultDateFormat = res.getString (17039482);
}} else {
if (noMonthDay) {
defaultDateFormat = res.getString (17039485);
} else {
defaultDateFormat = res.getString (17039477);
}}} else {
if (abbrevMonth) {
if (noMonthDay) {
defaultDateFormat = res.getString (17039487);
} else {
defaultDateFormat = res.getString (17039486);
}} else {
if (noMonthDay) {
defaultDateFormat = res.getString (17039484);
} else {
defaultDateFormat = res.getString (17039483);
}}}if (showWeekDay) {
if (showTime) {
fullFormat = res.getString (17039499);
} else {
fullFormat = res.getString (17039500);
}} else {
if (showTime) {
fullFormat = res.getString (17039501);
} else {
fullFormat = res.getString (17039490);
}}if (noMonthDay && startMonthNum == endMonthNum) {
return formatter.format ("%s", [startDate.format (defaultDateFormat)]);
}if (startYear != endYear || noMonthDay) {
var startDateString = startDate.format (defaultDateFormat);
var endDateString = endDate.format (defaultDateFormat);
return formatter.format (fullFormat, [startWeekDayString, startDateString, startTimeString, endWeekDayString, endDateString, endTimeString]);
}var monthFormat;
if (numericDate) {
monthFormat = "%m";
} else if (abbrevMonth) {
monthFormat = res.getString (17039521);
} else {
monthFormat = "%B";
}var startMonthString = startDate.format (monthFormat);
var startMonthDayString = startDate.format ("%-d");
var startYearString = startDate.format ("%Y");
var endMonthString = isInstant ? null : endDate.format (monthFormat);
var endMonthDayString = isInstant ? null : endDate.format ("%-d");
var endYearString = isInstant ? null : endDate.format ("%Y");
if (startMonthNum != endMonthNum) {
var index = 0;
if (showWeekDay) index = 1;
if (showYear) index += 2;
if (showTime) index += 4;
if (numericDate) index += 8;
var resId = android.text.format.DateUtils.sameYearTable[index];
fullFormat = res.getString (resId);
return formatter.format (fullFormat, [startWeekDayString, startMonthString, startMonthDayString, startYearString, startTimeString, endWeekDayString, endMonthString, endMonthDayString, endYearString, endTimeString]);
}if (startDay != endDay) {
var index = 0;
if (showWeekDay) index = 1;
if (showYear) index += 2;
if (showTime) index += 4;
if (numericDate) index += 8;
var resId = android.text.format.DateUtils.sameMonthTable[index];
fullFormat = res.getString (resId);
return formatter.format (fullFormat, [startWeekDayString, startMonthString, startMonthDayString, startYearString, startTimeString, endWeekDayString, endMonthString, endMonthDayString, endYearString, endTimeString]);
}var showDate = (flags & 16) != 0;
if (!showTime && !showDate && !showWeekDay) showDate = true;
var timeString = "";
if (showTime) {
if (isInstant) {
timeString = startTimeString;
} else {
var timeFormat = res.getString (17039489);
timeString = String.format (timeFormat, [startTimeString, endTimeString]);
}}fullFormat = "";
var dateString = "";
if (showDate) {
dateString = startDate.format (defaultDateFormat);
if (showWeekDay) {
if (showTime) {
fullFormat = res.getString (17039502);
} else {
fullFormat = res.getString (17039503);
}} else {
if (showTime) {
fullFormat = res.getString (17039481);
} else {
return formatter.format ("%s", [dateString]);
}}} else if (showWeekDay) {
if (showTime) {
fullFormat = res.getString (17039504);
} else {
return formatter.format ("%s", [startWeekDayString]);
}} else if (showTime) {
return formatter.format ("%s", [timeString]);
}return formatter.format (fullFormat, [timeString, startWeekDayString, dateString]);
}, "android.content.Context,java.util.Formatter,~N,~N,~N,~S");
c$.formatDateTime = Clazz.defineMethod (c$, "formatDateTime", 
function (context, millis, flags) {
return android.text.format.DateUtils.formatDateRange (context, millis, millis, flags);
}, "android.content.Context,~N,~N");
c$.getRelativeTimeSpanString = Clazz.defineMethod (c$, "getRelativeTimeSpanString", 
function (c, millis, withPreposition) {
var result;
var now = System.currentTimeMillis ();
var span = now - millis;
{
if (android.text.format.DateUtils.sNowTime == null) {
($t$ = android.text.format.DateUtils.sNowTime =  new android.text.format.Time (), android.text.format.DateUtils.prototype.sNowTime = android.text.format.DateUtils.sNowTime, $t$);
}if (android.text.format.DateUtils.sThenTime == null) {
($t$ = android.text.format.DateUtils.sThenTime =  new android.text.format.Time (), android.text.format.DateUtils.prototype.sThenTime = android.text.format.DateUtils.sThenTime, $t$);
}android.text.format.DateUtils.sNowTime.set (now);
android.text.format.DateUtils.sThenTime.set (millis);
var prepositionId;
if (span < 86400000 && android.text.format.DateUtils.sNowTime.weekDay == android.text.format.DateUtils.sThenTime.weekDay) {
var flags = 1;
result = android.text.format.DateUtils.formatDateRange (c, millis, millis, flags);
prepositionId = 17040076;
} else if (android.text.format.DateUtils.sNowTime.year != android.text.format.DateUtils.sThenTime.year) {
var flags = 131092;
result = android.text.format.DateUtils.formatDateRange (c, millis, millis, flags);
prepositionId = 17040075;
} else {
var flags = 65552;
result = android.text.format.DateUtils.formatDateRange (c, millis, millis, flags);
prepositionId = 17040075;
}if (withPreposition) {
var res = c.getResources ();
result = res.getString (prepositionId, result);
}}return result;
}, "android.content.Context,~N,~B");
c$.getRelativeTimeSpanString = Clazz.defineMethod (c$, "getRelativeTimeSpanString", 
function (c, millis) {
return android.text.format.DateUtils.getRelativeTimeSpanString (c, millis, false);
}, "android.content.Context,~N");
c$.sLock = c$.prototype.sLock =  new JavaObject ();
Clazz.defineStatics (c$,
"sDaysLong", [17039436, 17039437, 17039438, 17039439, 17039440, 17039441, 17039442],
"sDaysMedium", [17039443, 17039444, 17039445, 17039446, 17039447, 17039448, 17039449],
"sDaysShort", [17039450, 17039451, 17039452, 17039453, 17039454, 17039455, 17039456],
"sDaysShortest", [17039457, 17039458, 17039459, 17039460, 17039461, 17039462, 17039463],
"sMonthsStandaloneLong", [17039388, 17039389, 17039390, 17039391, 17039392, 17039393, 17039394, 17039395, 17039396, 17039397, 17039398, 17039399],
"sMonthsLong", [17039400, 17039401, 17039402, 17039403, 17039404, 17039405, 17039406, 17039407, 17039408, 17039409, 17039410, 17039411],
"sMonthsMedium", [17039412, 17039413, 17039414, 17039415, 17039416, 17039417, 17039418, 17039419, 17039420, 17039421, 17039422, 17039423],
"sMonthsShortest", [17039424, 17039425, 17039426, 17039427, 17039428, 17039429, 17039430, 17039431, 17039432, 17039433, 17039434, 17039435],
"sAmPm", [17039464, 17039465],
"sLastConfig", null,
"sStatusTimeFormat", null,
"sElapsedFormatMMSS", null,
"sElapsedFormatHMMSS", null,
"FAST_FORMAT_HMMSS", "%1$d:%2$02d:%3$02d",
"FAST_FORMAT_MMSS", "%1$02d:%2$02d",
"TIME_PADDING", '0',
"TIME_SEPARATOR", ':',
"SECOND_IN_MILLIS", 1000,
"MINUTE_IN_MILLIS", 60000,
"HOUR_IN_MILLIS", 3600000,
"DAY_IN_MILLIS", 86400000,
"WEEK_IN_MILLIS", 604800000,
"YEAR_IN_MILLIS", 31449600000,
"FORMAT_SHOW_TIME", 0x00001,
"FORMAT_SHOW_WEEKDAY", 0x00002,
"FORMAT_SHOW_YEAR", 0x00004,
"FORMAT_NO_YEAR", 0x00008,
"FORMAT_SHOW_DATE", 0x00010,
"FORMAT_NO_MONTH_DAY", 0x00020,
"FORMAT_12HOUR", 0x00040,
"FORMAT_24HOUR", 0x00080,
"FORMAT_CAP_AMPM", 0x00100,
"FORMAT_NO_NOON", 0x00200,
"FORMAT_CAP_NOON", 0x00400,
"FORMAT_NO_MIDNIGHT", 0x00800,
"FORMAT_CAP_MIDNIGHT", 0x01000,
"FORMAT_UTC", 0x02000,
"FORMAT_ABBREV_TIME", 0x04000,
"FORMAT_ABBREV_WEEKDAY", 0x08000,
"FORMAT_ABBREV_MONTH", 0x10000,
"FORMAT_NUMERIC_DATE", 0x20000,
"FORMAT_ABBREV_RELATIVE", 0x40000,
"FORMAT_ABBREV_ALL", 0x80000,
"FORMAT_CAP_NOON_MIDNIGHT", (5120),
"FORMAT_NO_NOON_MIDNIGHT", (2560),
"HOUR_MINUTE_24", "%H:%M",
"MONTH_FORMAT", "%B",
"ABBREV_MONTH_FORMAT", "%b",
"NUMERIC_MONTH_FORMAT", "%m",
"MONTH_DAY_FORMAT", "%-d",
"YEAR_FORMAT", "%Y",
"YEAR_FORMAT_TWO_DIGITS", "%g",
"WEEKDAY_FORMAT", "%A",
"ABBREV_WEEKDAY_FORMAT", "%a",
"sameYearTable", [17039505, 17039506, 17039518, 17039520, 17039507, 17039509, 17039511, 17039513, 17039491, 17039492, 17039493, 17039494, 17039496, 17039497, 17039498, 17039495],
"sameMonthTable", [17039516, 17039517, 17039519, 17039515, 17039508, 17039510, 17039512, 17039514, 17039491, 17039492, 17039493, 17039494, 17039496, 17039497, 17039498, 17039495],
"LENGTH_LONG", 10,
"LENGTH_MEDIUM", 20,
"LENGTH_SHORT", 30,
"LENGTH_SHORTER", 40,
"LENGTH_SHORTEST", 50,
"sNowTime", null,
"sThenTime", null);
});
