﻿Clazz.declarePackage ("android.text.format");
Clazz.load (null, "android.text.format.Time", ["android.content.res.Resources", "java.lang.NullPointerException", "$.RuntimeException", "java.util.Locale", "$.TimeZone"], function () {
c$ = Clazz.decorateAsClass (function () {
this.allDay = false;
this.second = 0;
this.minute = 0;
this.hour = 0;
this.monthDay = 0;
this.month = 0;
this.year = 0;
this.weekDay = 0;
this.yearDay = 0;
this.isDst = 0;
this.gmtoff = 0;
this.timezone = null;
Clazz.instantialize (this, arguments);
}, android.text.format, "Time");
Clazz.makeConstructor (c$, 
function (timezone) {
if (timezone == null) {
throw  new NullPointerException ("timezone is null!");
}this.timezone = timezone;
this.year = 1970;
this.monthDay = 1;
this.isDst = -1;
}, "~S");
Clazz.makeConstructor (c$, 
function () {
this.construct (java.util.TimeZone.getDefault ().getID ());
});
Clazz.makeConstructor (c$, 
function (other) {
this.set (other);
}, "android.text.format.Time");
Clazz.defineMethod (c$, "getActualMaximum", 
function (field) {
switch (field) {
case 1:
return 59;
case 2:
return 59;
case 3:
return 23;
case 4:
{
var n = android.text.format.Time.DAYS_PER_MONTH[this.month];
if (n != 28) {
return n;
} else {
var y = this.year;
return ((y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0)) ? 29 : 28;
}}case 5:
return 11;
case 6:
return 2037;
case 7:
return 6;
case 8:
{
var y = this.year;
return ((y % 4) == 0 && ((y % 100) != 0 || (y % 400) == 0)) ? 365 : 364;
}case 9:
throw  new RuntimeException ("WEEK_NUM not implemented");
default:
throw  new RuntimeException ("bad field=" + field);
}
}, "~N");
Clazz.defineMethod (c$, "clear", 
function (timezone) {
if (timezone == null) {
throw  new NullPointerException ("timezone is null!");
}this.timezone = timezone;
this.allDay = false;
this.second = 0;
this.minute = 0;
this.hour = 0;
this.monthDay = 0;
this.month = 0;
this.year = 0;
this.weekDay = 0;
this.yearDay = 0;
this.gmtoff = 0;
this.isDst = -1;
}, "~S");
Clazz.defineMethod (c$, "format", 
function (format) {
{
var locale = java.util.Locale.getDefault ();
if (android.text.format.Time.sLocale == null || locale == null || !(locale.equals (android.text.format.Time.sLocale))) {
var r = android.content.res.Resources.getSystem ();
($t$ = android.text.format.Time.sShortMonths = [r.getString (17039412), r.getString (17039413), r.getString (17039414), r.getString (17039415), r.getString (17039416), r.getString (17039417), r.getString (17039418), r.getString (17039419), r.getString (17039420), r.getString (17039421), r.getString (17039422), r.getString (17039423)], android.text.format.Time.prototype.sShortMonths = android.text.format.Time.sShortMonths, $t$);
($t$ = android.text.format.Time.sLongMonths = [r.getString (17039400), r.getString (17039401), r.getString (17039402), r.getString (17039403), r.getString (17039404), r.getString (17039405), r.getString (17039406), r.getString (17039407), r.getString (17039408), r.getString (17039409), r.getString (17039410), r.getString (17039411)], android.text.format.Time.prototype.sLongMonths = android.text.format.Time.sLongMonths, $t$);
($t$ = android.text.format.Time.sLongStandaloneMonths = [r.getString (17039388), r.getString (17039389), r.getString (17039390), r.getString (17039391), r.getString (17039392), r.getString (17039393), r.getString (17039394), r.getString (17039395), r.getString (17039396), r.getString (17039397), r.getString (17039398), r.getString (17039399)], android.text.format.Time.prototype.sLongStandaloneMonths = android.text.format.Time.sLongStandaloneMonths, $t$);
($t$ = android.text.format.Time.sShortWeekdays = [r.getString (17039443), r.getString (17039444), r.getString (17039445), r.getString (17039446), r.getString (17039447), r.getString (17039448), r.getString (17039449)], android.text.format.Time.prototype.sShortWeekdays = android.text.format.Time.sShortWeekdays, $t$);
($t$ = android.text.format.Time.sLongWeekdays = [r.getString (17039436), r.getString (17039437), r.getString (17039438), r.getString (17039439), r.getString (17039440), r.getString (17039441), r.getString (17039442)], android.text.format.Time.prototype.sLongWeekdays = android.text.format.Time.sLongWeekdays, $t$);
($t$ = android.text.format.Time.sTimeOnlyFormat = r.getString (17039478), android.text.format.Time.prototype.sTimeOnlyFormat = android.text.format.Time.sTimeOnlyFormat, $t$);
($t$ = android.text.format.Time.sDateOnlyFormat = r.getString (17039477), android.text.format.Time.prototype.sDateOnlyFormat = android.text.format.Time.sDateOnlyFormat, $t$);
($t$ = android.text.format.Time.sDateTimeFormat = r.getString (17039479), android.text.format.Time.prototype.sDateTimeFormat = android.text.format.Time.sDateTimeFormat, $t$);
($t$ = android.text.format.Time.sAm = r.getString (17039464), android.text.format.Time.prototype.sAm = android.text.format.Time.sAm, $t$);
($t$ = android.text.format.Time.sPm = r.getString (17039465), android.text.format.Time.prototype.sPm = android.text.format.Time.sPm, $t$);
($t$ = android.text.format.Time.sLocale = locale, android.text.format.Time.prototype.sLocale = android.text.format.Time.sLocale, $t$);
}return this.format1 (format);
}}, "~S");
Clazz.defineMethod (c$, "parse", 
function (s) {
if (this.nativeParse (s)) {
this.timezone = "UTC";
return true;
}return false;
}, "~S");
Clazz.defineMethod (c$, "parse3339", 
function (s) {
if (this.nativeParse3339 (s)) {
this.timezone = "UTC";
return true;
}return false;
}, "~S");
c$.getCurrentTimezone = Clazz.defineMethod (c$, "getCurrentTimezone", 
function () {
return java.util.TimeZone.getDefault ().getID ();
});
Clazz.defineMethod (c$, "set", 
function (that) {
this.timezone = that.timezone;
this.allDay = that.allDay;
this.second = that.second;
this.minute = that.minute;
this.hour = that.hour;
this.monthDay = that.monthDay;
this.month = that.month;
this.year = that.year;
this.weekDay = that.weekDay;
this.yearDay = that.yearDay;
this.isDst = that.isDst;
this.gmtoff = that.gmtoff;
}, "android.text.format.Time");
Clazz.defineMethod (c$, "set", 
function (second, minute, hour, monthDay, month, year) {
this.allDay = false;
this.second = second;
this.minute = minute;
this.hour = hour;
this.monthDay = monthDay;
this.month = month;
this.year = year;
this.weekDay = 0;
this.yearDay = 0;
this.isDst = -1;
this.gmtoff = 0;
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "set", 
function (monthDay, month, year) {
this.allDay = true;
this.second = 0;
this.minute = 0;
this.hour = 0;
this.monthDay = monthDay;
this.month = month;
this.year = year;
this.weekDay = 0;
this.yearDay = 0;
this.isDst = -1;
this.gmtoff = 0;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "before", 
function (that) {
return android.text.format.Time.compare (this, that) < 0;
}, "android.text.format.Time");
Clazz.defineMethod (c$, "after", 
function (that) {
return android.text.format.Time.compare (this, that) > 0;
}, "android.text.format.Time");
Clazz.defineMethod (c$, "getWeekNumber", 
function () {
var closestThursday = this.yearDay + android.text.format.Time.sThursdayOffset[this.weekDay];
if (closestThursday >= 0 && closestThursday <= 364) {
return Math.floor (closestThursday / 7) + 1;
}var temp =  new android.text.format.Time (this);
temp.monthDay += android.text.format.Time.sThursdayOffset[this.weekDay];
temp.normalize (true);
return Math.floor (temp.yearDay / 7) + 1;
});
Clazz.defineMethod (c$, "format3339", 
function (allDay) {
if (allDay) {
return this.format ("%Y-%m-%d");
} else if ("UTC".equals (this.timezone)) {
return this.format ("%Y-%m-%dT%H:%M:%S.000Z");
} else {
var base = this.format ("%Y-%m-%dT%H:%M:%S.000");
var sign = (this.gmtoff < 0) ? "-" : "+";
var offset = Math.abs (this.gmtoff);
var minutes = Math.floor ((offset % 3600) / 60);
var hours = Math.floor (offset / 3600);
return String.format ("%s%s%02d:%02d", [base, sign, new Integer (hours), new Integer (minutes)]);
}}, "~B");
c$.isEpoch = Clazz.defineMethod (c$, "isEpoch", 
function (time) {
var millis = time.toMillis (true);
return android.text.format.Time.getJulianDay (millis, 0) == 2440588;
}, "android.text.format.Time");
c$.getJulianDay = Clazz.defineMethod (c$, "getJulianDay", 
function (millis, gmtoff) {
var offsetMillis = gmtoff * 1000;
var julianDay = Math.floor ((millis + offsetMillis) / 86400000);
return julianDay + 2440588;
}, "~N,~N");
Clazz.defineMethod (c$, "setJulianDay", 
function (julianDay) {
var millis = (julianDay - 2440588) * 86400000;
this.set (millis);
var approximateDay = android.text.format.Time.getJulianDay (millis, this.gmtoff);
var diff = julianDay - approximateDay;
this.monthDay += diff;
this.hour = 0;
this.minute = 0;
this.second = 0;
millis = this.normalize (true);
return millis;
}, "~N");
Clazz.defineStatics (c$,
"Y_M_D_T_H_M_S_000", "%Y-%m-%dT%H:%M:%S.000",
"Y_M_D_T_H_M_S_000_Z", "%Y-%m-%dT%H:%M:%S.000Z",
"Y_M_D", "%Y-%m-%d",
"TIMEZONE_UTC", "UTC",
"EPOCH_JULIAN_DAY", 2440588,
"SECOND", 1,
"MINUTE", 2,
"HOUR", 3,
"MONTH_DAY", 4,
"MONTH", 5,
"YEAR", 6,
"WEEK_DAY", 7,
"YEAR_DAY", 8,
"WEEK_NUM", 9,
"SUNDAY", 0,
"MONDAY", 1,
"TUESDAY", 2,
"WEDNESDAY", 3,
"THURSDAY", 4,
"FRIDAY", 5,
"SATURDAY", 6,
"sLocale", null,
"sShortMonths", null,
"sLongMonths", null,
"sLongStandaloneMonths", null,
"sShortWeekdays", null,
"sLongWeekdays", null,
"sTimeOnlyFormat", null,
"sDateOnlyFormat", null,
"sDateTimeFormat", null,
"sAm", null,
"sPm", null,
"sDateCommand", "%a %b %e %H:%M:%S %Z %Y",
"DAYS_PER_MONTH", [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31],
"sThursdayOffset", [-3, 3, 2, 1, 0, -1, -2]);
});
