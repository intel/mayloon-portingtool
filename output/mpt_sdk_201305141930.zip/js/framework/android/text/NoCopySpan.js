﻿Clazz.declarePackage ("android.text");
Clazz.declareInterface (android.text, "NoCopySpan");
Clazz.pu$h ();
c$ = Clazz.declareType (android.text.NoCopySpan, "Concrete", null, android.text.NoCopySpan);
c$ = Clazz.p0p ();
