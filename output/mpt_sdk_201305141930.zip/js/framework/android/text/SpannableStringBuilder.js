﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.text.Editable"], "android.text.SpannableStringBuilder", ["android.text.SpanWatcher", "$.TextUtils", "$.TextWatcher", "android.util.ArrayUtils", "java.lang.Exception", "$.IndexOutOfBoundsException", "$.RuntimeException", "java.lang.reflect.Array"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mText = null;
this.mGapStart = 0;
this.mGapLength = 0;
this.mSpans = null;
this.mSpanStarts = null;
this.mSpanEnds = null;
this.mSpanFlags = null;
this.mSpanCount = 0;
Clazz.instantialize (this, arguments);
}, android.text, "SpannableStringBuilder", null, [CharSequence, android.text.Editable]);
Clazz.makeConstructor (c$, 
function () {
this.construct ("");
});
Clazz.makeConstructor (c$, 
function (text) {
this.construct (text, 0, text.toString ().length);
}, "CharSequence");
Clazz.makeConstructor (c$, 
function (text, start, end) {
var srclen = end - start;
var len = android.util.ArrayUtils.idealCharArraySize (srclen + 1);
this.mText =  Clazz.newArray (len, '\0');
this.mGapStart = srclen;
this.mGapLength = len - srclen;
android.text.TextUtils.getChars (text, start, end, this.mText, 0);
}, "CharSequence,~N,~N");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (source) {
if (Clazz.instanceOf (source, android.text.SpannableStringBuilder)) {
return source;
} else {
return  new android.text.SpannableStringBuilder (source);
}}, "CharSequence");
Clazz.overrideMethod (c$, "charAt", 
function (where) {
var len = this.length ();
if (where < 0) {
throw  new IndexOutOfBoundsException ("charAt: " + where + " < 0");
} else if (where >= len) {
throw  new IndexOutOfBoundsException ("charAt: " + where + " >= length " + len);
}if (where >= this.mGapStart) return this.mText[where + this.mGapLength];
 else return this.mText[where];
}, "~N");
Clazz.defineMethod (c$, "length", 
function () {
return this.mText.length - this.mGapLength;
});
Clazz.defineMethod (c$, "resizeFor", 
($fz = function (size) {
var newlen = android.util.ArrayUtils.idealCharArraySize (size + 1);
var newtext =  Clazz.newArray (newlen, '\0');
var after = this.mText.length - (this.mGapStart + this.mGapLength);
System.arraycopy (this.mText, 0, newtext, 0, this.mGapStart);
System.arraycopy (this.mText, this.mText.length - after, newtext, newlen - after, after);
for (var i = 0; i < this.mSpanCount; i++) {
if (this.mSpanStarts[i] > this.mGapStart) this.mSpanStarts[i] += newlen - this.mText.length;
if (this.mSpanEnds[i] > this.mGapStart) this.mSpanEnds[i] += newlen - this.mText.length;
}
var oldlen = this.mText.length;
this.mText = newtext;
this.mGapLength += this.mText.length - oldlen;
if (this.mGapLength < 1)  new Exception ("mGapLength < 1").printStackTrace ();
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "moveGapTo", 
($fz = function (where) {
if (where == this.mGapStart) return ;
var atend = (where == this.length ());
if (where < this.mGapStart) {
var overlap = this.mGapStart - where;
System.arraycopy (this.mText, where, this.mText, this.mGapStart + this.mGapLength - overlap, overlap);
} else {
var overlap = where - this.mGapStart;
System.arraycopy (this.mText, where + this.mGapLength - overlap, this.mText, this.mGapStart, overlap);
}for (var i = 0; i < this.mSpanCount; i++) {
var start = this.mSpanStarts[i];
var end = this.mSpanEnds[i];
if (start > this.mGapStart) start -= this.mGapLength;
if (start > where) start += this.mGapLength;
 else if (start == where) {
var flag = (this.mSpanFlags[i] & 240) >> 4;
if (flag == 2 || (atend && flag == 3)) start += this.mGapLength;
}if (end > this.mGapStart) end -= this.mGapLength;
if (end > where) end += this.mGapLength;
 else if (end == where) {
var flag = (this.mSpanFlags[i] & 15);
if (flag == 2 || (atend && flag == 3)) end += this.mGapLength;
}this.mSpanStarts[i] = start;
this.mSpanEnds[i] = end;
}
this.mGapStart = where;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.overrideMethod (c$, "insert", 
function (where, tb) {
return this.replace (where, where, tb, 0, tb.toString ().length);
}, "~N,CharSequence");
Clazz.overrideMethod (c$, "$delete", 
function (start, end) {
var ret = this.replace (start, end, "", 0, 0);
if (this.mGapLength > 2 * this.length ()) this.resizeFor (this.length ());
return ret;
}, "~N,~N");
Clazz.overrideMethod (c$, "clear", 
function () {
this.replace (0, this.length (), "", 0, 0);
});
Clazz.overrideMethod (c$, "clearSpans", 
function () {
for (var i = this.mSpanCount - 1; i >= 0; i--) {
var what = this.mSpans[i];
var ostart = this.mSpanStarts[i];
var oend = this.mSpanEnds[i];
if (ostart > this.mGapStart) ostart -= this.mGapLength;
if (oend > this.mGapStart) oend -= this.mGapLength;
this.mSpanCount = i;
this.mSpans[i] = null;
}
});
Clazz.defineMethod (c$, "append", 
function (text) {
var length = this.length ();
return this.replace (length, length, text, 0, text.toString ().length);
}, "CharSequence");
Clazz.defineMethod (c$, "append", 
function (text, start, end) {
var length = this.length ();
return this.replace (length, length, text, start, end);
}, "CharSequence,~N,~N");
Clazz.defineMethod (c$, "append", 
function (text) {
return this.append (String.valueOf (text));
}, "~N");
Clazz.defineMethod (c$, "change", 
($fz = function (start, end, tb, tbstart, tbend) {
return this.change (true, start, end, tb, tbstart, tbend);
}, $fz.isPrivate = true, $fz), "~N,~N,CharSequence,~N,~N");
Clazz.defineMethod (c$, "change", 
($fz = function (notify, start, end, tb, tbstart, tbend) {
this.checkRange ("replace", start, end);
var ret = tbend - tbstart;
var recipients = null;
if (notify) recipients = this.sendTextWillChange (start, end - start, tbend - tbstart);
for (var i = this.mSpanCount - 1; i >= 0; i--) {
if ((this.mSpanFlags[i] & 51) == 51) {
var st = this.mSpanStarts[i];
if (st > this.mGapStart) st -= this.mGapLength;
var en = this.mSpanEnds[i];
if (en > this.mGapStart) en -= this.mGapLength;
var ost = st;
var oen = en;
var clen = this.length ();
if (st > start && st <= end) {
for (st = end; st < clen; st++) if (st > end && (this.charAt (st - 1)).charCodeAt (0) == ('\n').charCodeAt (0)) break;

}if (en > start && en <= end) {
for (en = end; en < clen; en++) if (en > end && (this.charAt (en - 1)).charCodeAt (0) == ('\n').charCodeAt (0)) break;

}if (st != ost || en != oen) this.setSpan (this.mSpans[i], st, en, this.mSpanFlags[i]);
}}
this.moveGapTo (end);
if (tbend - tbstart >= this.mGapLength + (end - start)) this.resizeFor (this.mText.length - this.mGapLength + tbend - tbstart - (end - start));
this.mGapStart += tbend - tbstart - (end - start);
this.mGapLength -= tbend - tbstart - (end - start);
if (this.mGapLength < 1)  new Exception ("mGapLength < 1").printStackTrace ();
android.text.TextUtils.getChars (tb, tbstart, tbend, this.mText, start);
if (Clazz.instanceOf (tb, android.text.Spanned)) {
var sp = tb;
var spans = sp.getSpans (tbstart, tbend, JavaObject);
for (var i = 0; i < spans.length; i++) {
var st = sp.getSpanStart (spans[i]);
var en = sp.getSpanEnd (spans[i]);
if (st < tbstart) st = tbstart;
if (en > tbend) en = tbend;
if (this.getSpanStart (spans[i]) < 0) {
this.setSpan (false, spans[i], st - tbstart + start, en - tbstart + start, sp.getSpanFlags (spans[i]));
}}
}if (tbend > tbstart && end - start == 0) {
if (notify) {
this.sendTextChange (recipients, start, end - start, tbend - tbstart);
this.sendTextHasChanged (recipients);
}return ret;
}var atend = (this.mGapStart + this.mGapLength == this.mText.length);
for (var i = this.mSpanCount - 1; i >= 0; i--) {
if (this.mSpanStarts[i] >= start && this.mSpanStarts[i] < this.mGapStart + this.mGapLength) {
var flag = (this.mSpanFlags[i] & 240) >> 4;
if (flag == 2 || (flag == 3 && atend)) this.mSpanStarts[i] = this.mGapStart + this.mGapLength;
 else this.mSpanStarts[i] = start;
}if (this.mSpanEnds[i] >= start && this.mSpanEnds[i] < this.mGapStart + this.mGapLength) {
var flag = (this.mSpanFlags[i] & 15);
if (flag == 2 || (flag == 3 && atend)) this.mSpanEnds[i] = this.mGapStart + this.mGapLength;
 else this.mSpanEnds[i] = start;
}if (this.mSpanEnds[i] < this.mSpanStarts[i]) {
System.arraycopy (this.mSpans, i + 1, this.mSpans, i, this.mSpanCount - (i + 1));
System.arraycopy (this.mSpanStarts, i + 1, this.mSpanStarts, i, this.mSpanCount - (i + 1));
System.arraycopy (this.mSpanEnds, i + 1, this.mSpanEnds, i, this.mSpanCount - (i + 1));
System.arraycopy (this.mSpanFlags, i + 1, this.mSpanFlags, i, this.mSpanCount - (i + 1));
this.mSpanCount--;
}}
if (notify) {
this.sendTextChange (recipients, start, end - start, tbend - tbstart);
this.sendTextHasChanged (recipients);
}return ret;
}, $fz.isPrivate = true, $fz), "~B,~N,~N,CharSequence,~N,~N");
Clazz.defineMethod (c$, "replace", 
function (start, end, tb) {
return this.replace (start, end, tb, 0, tb.length ());
}, "~N,~N,CharSequence");
Clazz.defineMethod (c$, "replace", 
function (start, end, tb, tbstart, tbend) {
if (end == start && tbstart == tbend) {
return this;
}if (end == start || tbstart == tbend) {
this.change (start, end, tb, tbstart, tbend);
} else {
this.checkRange ("replace", start, end);
this.moveGapTo (end);
var recipients;
recipients = this.sendTextWillChange (start, end - start, tbend - tbstart);
var origlen = end - start;
if (this.mGapLength < 2) this.resizeFor (this.length () + 1);
for (var i = this.mSpanCount - 1; i >= 0; i--) {
if (this.mSpanStarts[i] == this.mGapStart) this.mSpanStarts[i]++;
if (this.mSpanEnds[i] == this.mGapStart) this.mSpanEnds[i]++;
}
this.mText[this.mGapStart] = ' ';
this.mGapStart++;
this.mGapLength--;
if (this.mGapLength < 1)  new Exception ("mGapLength < 1").printStackTrace ();
var oldlen = (end + 1) - start;
var inserted = this.change (false, start + 1, start + 1, tb, tbstart, tbend);
this.change (false, start, start + 1, "", 0, 0);
this.change (false, start + inserted, start + inserted + oldlen - 1, "", 0, 0);
this.sendTextChange (recipients, start, origlen, inserted);
this.sendTextHasChanged (recipients);
}return this;
}, "~N,~N,CharSequence,~N,~N");
Clazz.defineMethod (c$, "setSpan", 
function (what, start, end, flags) {
this.setSpan (true, what, start, end, flags);
}, "~O,~N,~N,~N");
Clazz.defineMethod (c$, "setSpan", 
($fz = function (send, what, start, end, flags) {
var nstart = start;
var nend = end;
this.checkRange ("setSpan", start, end);
if ((flags & 240) == (48)) {
if (start != 0 && start != this.length ()) {
var c = this.charAt (start - 1);
if ((c).charCodeAt (0) != ('\n').charCodeAt (0)) throw  new RuntimeException ("PARAGRAPH span must start at paragraph boundary");
}}if ((flags & 15) == 3) {
if (end != 0 && end != this.length ()) {
var c = this.charAt (end - 1);
if ((c).charCodeAt (0) != ('\n').charCodeAt (0)) throw  new RuntimeException ("PARAGRAPH span must end at paragraph boundary");
}}if (start > this.mGapStart) start += this.mGapLength;
 else if (start == this.mGapStart) {
var flag = (flags & 240) >> 4;
if (flag == 2 || (flag == 3 && start == this.length ())) start += this.mGapLength;
}if (end > this.mGapStart) end += this.mGapLength;
 else if (end == this.mGapStart) {
var flag = (flags & 15);
if (flag == 2 || (flag == 3 && end == this.length ())) end += this.mGapLength;
}var count = this.mSpanCount;
var spans = this.mSpans;
for (var i = 0; i < count; i++) {
if (spans[i] === what) {
var ostart = this.mSpanStarts[i];
var oend = this.mSpanEnds[i];
if (ostart > this.mGapStart) ostart -= this.mGapLength;
if (oend > this.mGapStart) oend -= this.mGapLength;
this.mSpanStarts[i] = start;
this.mSpanEnds[i] = end;
this.mSpanFlags[i] = flags;
if (send) this.sendSpanChanged (what, ostart, oend, nstart, nend);
return ;
}}
if ((null == this.mSpans) || (this.mSpanCount + 1 >= this.mSpans.length)) {
var newsize = android.util.ArrayUtils.idealIntArraySize (this.mSpanCount + 1);
var newspans =  new Array (newsize);
var newspanstarts =  Clazz.newArray (newsize, 0);
var newspanends =  Clazz.newArray (newsize, 0);
var newspanflags =  Clazz.newArray (newsize, 0);
if (this.mSpans != null) {
System.arraycopy (this.mSpans, 0, newspans, 0, this.mSpanCount);
System.arraycopy (this.mSpanStarts, 0, newspanstarts, 0, this.mSpanCount);
System.arraycopy (this.mSpanEnds, 0, newspanends, 0, this.mSpanCount);
System.arraycopy (this.mSpanFlags, 0, newspanflags, 0, this.mSpanCount);
}this.mSpans = newspans;
this.mSpanStarts = newspanstarts;
this.mSpanEnds = newspanends;
this.mSpanFlags = newspanflags;
}this.mSpans[this.mSpanCount] = what;
this.mSpanStarts[this.mSpanCount] = start;
this.mSpanEnds[this.mSpanCount] = end;
this.mSpanFlags[this.mSpanCount] = flags;
this.mSpanCount++;
if (send) this.sendSpanAdded (what, nstart, nend);
}, $fz.isPrivate = true, $fz), "~B,~O,~N,~N,~N");
Clazz.overrideMethod (c$, "removeSpan", 
function (what) {
for (var i = this.mSpanCount - 1; i >= 0; i--) {
if (this.mSpans[i] === what) {
var ostart = this.mSpanStarts[i];
var oend = this.mSpanEnds[i];
if (ostart > this.mGapStart) ostart -= this.mGapLength;
if (oend > this.mGapStart) oend -= this.mGapLength;
var count = this.mSpanCount - (i + 1);
System.arraycopy (this.mSpans, i + 1, this.mSpans, i, count);
System.arraycopy (this.mSpanStarts, i + 1, this.mSpanStarts, i, count);
System.arraycopy (this.mSpanEnds, i + 1, this.mSpanEnds, i, count);
System.arraycopy (this.mSpanFlags, i + 1, this.mSpanFlags, i, count);
this.mSpanCount--;
this.mSpans[this.mSpanCount] = null;
return ;
}}
}, "~O");
Clazz.defineMethod (c$, "getSpanStart", 
function (what) {
var count = this.mSpanCount;
var spans = this.mSpans;
for (var i = count - 1; i >= 0; i--) {
if (spans[i] === what) {
var where = this.mSpanStarts[i];
if (where > this.mGapStart) where -= this.mGapLength;
return where;
}}
return -1;
}, "~O");
Clazz.defineMethod (c$, "getSpanEnd", 
function (what) {
var count = this.mSpanCount;
var spans = this.mSpans;
for (var i = count - 1; i >= 0; i--) {
if (spans[i] === what) {
var where = this.mSpanEnds[i];
if (where > this.mGapStart) where -= this.mGapLength;
return where;
}}
return -1;
}, "~O");
Clazz.defineMethod (c$, "getSpanFlags", 
function (what) {
var count = this.mSpanCount;
var spans = this.mSpans;
for (var i = count - 1; i >= 0; i--) {
if (spans[i] === what) {
return this.mSpanFlags[i];
}}
return 0;
}, "~O");
Clazz.defineMethod (c$, "getSpans", 
function (queryStart, queryEnd, kind) {
var spanCount = this.mSpanCount;
var spans = this.mSpans;
var starts = this.mSpanStarts;
var ends = this.mSpanEnds;
var flags = this.mSpanFlags;
var gapstart = this.mGapStart;
var gaplen = this.mGapLength;
var count = 0;
var ret = null;
var ret1 = null;
for (var i = 0; i < spanCount; i++) {
var spanStart = starts[i];
var spanEnd = ends[i];
if (spanStart > gapstart) {
spanStart -= gaplen;
}if (spanEnd > gapstart) {
spanEnd -= gaplen;
}if (spanStart > queryEnd) {
continue ;}if (spanEnd < queryStart) {
continue ;}if (spanStart != spanEnd && queryStart != queryEnd) {
if (spanStart == queryEnd) continue ;if (spanEnd == queryStart) continue ;}if (kind != null && !kind.getName ().equals ("Object") && (spans[i].getClass ().getName ().equals ("android.text.Selection.START") || spans[i].getClass ().getName ().equals ("android.text.Selection.END"))) {
continue ;}if (count == 0) {
ret1 = spans[i];
count++;
} else {
if (count == 1) {
ret = java.lang.reflect.Array.newInstance (kind, spanCount - i + 1);
ret[0] = ret1;
}var prio = flags[i] & 16711680;
if (prio != 0) {
var j;
for (j = 0; j < count; j++) {
var p = this.getSpanFlags (ret[j]) & 16711680;
if (prio > p) {
break;
}}
System.arraycopy (ret, j, ret, j + 1, count - j);
ret[j] = spans[i];
count++;
} else {
ret[count++] = spans[i];
}}}
if (count == 0) {
return android.util.ArrayUtils.emptyArray (kind);
}if (count == 1) {
ret = java.lang.reflect.Array.newInstance (kind, 1);
ret[0] = ret1;
return ret;
}if (count == ret.length) {
return ret;
}var nret = java.lang.reflect.Array.newInstance (kind, count);
System.arraycopy (ret, 0, nret, 0, count);
return nret;
}, "~N,~N,Class");
Clazz.overrideMethod (c$, "nextSpanTransition", 
function (start, limit, kind) {
var count = this.mSpanCount;
var spans = this.mSpans;
var starts = this.mSpanStarts;
var ends = this.mSpanEnds;
var gapstart = this.mGapStart;
var gaplen = this.mGapLength;
if (kind == null) {
kind = JavaObject;
}for (var i = 0; i < count; i++) {
var st = starts[i];
var en = ends[i];
if (st > gapstart) st -= gaplen;
if (en > gapstart) en -= gaplen;
if (st > start && st < limit && kind.isInstance (spans[i])) limit = st;
if (en > start && en < limit && kind.isInstance (spans[i])) limit = en;
}
return limit;
}, "~N,~N,Class");
Clazz.overrideMethod (c$, "subSequence", 
function (start, end) {
return  new android.text.SpannableStringBuilder (this, start, end);
}, "~N,~N");
Clazz.defineMethod (c$, "getChars", 
function (start, end, dest, destoff) {
this.checkRange ("getChars", start, end);
if (end <= this.mGapStart) {
System.arraycopy (this.mText, start, dest, destoff, end - start);
} else if (start >= this.mGapStart) {
System.arraycopy (this.mText, start + this.mGapLength, dest, destoff, end - start);
} else {
System.arraycopy (this.mText, start, dest, destoff, this.mGapStart - start);
System.arraycopy (this.mText, this.mGapStart + this.mGapLength, dest, destoff + (this.mGapStart - start), end - this.mGapStart);
}}, "~N,~N,~A,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
var len = this.length ();
var buf =  Clazz.newArray (len, '\0');
this.getChars (0, len, buf, 0);
return  String.instantialize (buf);
});
Clazz.defineMethod (c$, "sendTextWillChange", 
($fz = function (start, before, after) {
var recip = this.getSpans (start, start + before, android.text.TextWatcher);
var n = recip.length;
for (var i = 0; i < n; i++) {
recip[i].beforeTextChanged (this, start, before, after);
}
return recip;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "sendTextChange", 
($fz = function (recip, start, before, after) {
var n = recip.length;
for (var i = 0; i < n; i++) {
recip[i].onTextChanged (this, start, before, after);
}
}, $fz.isPrivate = true, $fz), "~A,~N,~N,~N");
Clazz.defineMethod (c$, "sendTextHasChanged", 
($fz = function (recip) {
var n = recip.length;
for (var i = 0; i < n; i++) {
if ((recip[i].getClass ().getName ().equals ("android.text.Selection.START")) || (recip[i].getClass ().getName ().equals ("android.text.Selection.END"))) {
continue ;}recip[i].afterTextChanged (this);
}
}, $fz.isPrivate = true, $fz), "~A");
Clazz.defineMethod (c$, "sendSpanAdded", 
($fz = function (what, start, end) {
var recip = this.getSpans (start, end, android.text.SpanWatcher);
var n = recip.length;
for (var i = 0; i < n; i++) {
}
}, $fz.isPrivate = true, $fz), "~O,~N,~N");
Clazz.defineMethod (c$, "sendSpanChanged", 
($fz = function (what, s, e, st, en) {
var recip = this.getSpans (Math.min (s, st), Math.max (e, en), android.text.SpanWatcher);
var n = recip.length;
for (var i = 0; i < n; i++) {
recip[i].onSpanChanged (this, what, s, e, st, en);
}
}, $fz.isPrivate = true, $fz), "~O,~N,~N,~N,~N");
c$.region = Clazz.defineMethod (c$, "region", 
($fz = function (start, end) {
return "(" + start + " ... " + end + ")";
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "checkRange", 
($fz = function (operation, start, end) {
if (end < start) {
throw  new IndexOutOfBoundsException (operation + " " + android.text.SpannableStringBuilder.region (start, end) + " has end before start");
}var len = this.length ();
if (start > len || end > len) {
throw  new IndexOutOfBoundsException (operation + " " + android.text.SpannableStringBuilder.region (start, end) + " ends beyond length " + len);
}if (start < 0 || end < 0) {
throw  new IndexOutOfBoundsException (operation + " " + android.text.SpannableStringBuilder.region (start, end) + " starts before 0");
}}, $fz.isPrivate = true, $fz), "~S,~N,~N");
Clazz.defineMethod (c$, "getFilters", 
function () {
console.log("Missing method: getFilters");
});
Clazz.defineStatics (c$,
"MARK", 1,
"POINT", 2,
"PARAGRAPH", 3,
"START_MASK", 0xF0,
"END_MASK", 0x0F,
"START_SHIFT", 4);
});
