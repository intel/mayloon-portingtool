﻿Clazz.declarePackage ("android.text");
Clazz.load (null, "android.text.Styled", ["android.graphics.Paint", "android.text.TextUtils", "android.text.style.CharacterStyle", "$.MetricAffectingSpan"], function () {
c$ = Clazz.declareType (android.text, "Styled");
c$.drawUniformRun = Clazz.defineMethod (c$, "drawUniformRun", 
($fz = function (canvas, text, start, end, dir, runIsRtl, x, top, y, bottom, fmi, paint, workPaint, needWidth) {
var haveWidth = false;
var ret = 0;
var spans = text.getSpans (start, end, android.text.style.CharacterStyle);
var replacement = null;
paint.bgColor = 0;
paint.baselineShift = 0;
workPaint.set (paint);
if (spans.length > 0) {
for (var i = 0; i < spans.length; i++) {
var span = spans[i];
if (Clazz.instanceOf (span, android.text.style.ReplacementSpan)) {
replacement = span;
} else {
span.updateDrawState (workPaint);
}}
}if (replacement == null) {
var tmp;
var tmpstart;
var tmpend;
if (runIsRtl) {
tmp = android.text.TextUtils.getReverse (text, start, end);
tmpstart = 0;
tmpend = end - start;
} else {
tmp = text;
tmpstart = start;
tmpend = end;
}if (fmi != null) {
workPaint.getFontMetricsInt (fmi);
}if (canvas != null) {
if (workPaint.bgColor != 0) {
var c = workPaint.getColor ();
var s = workPaint.getStyle ();
workPaint.setColor (workPaint.bgColor);
workPaint.setStyle (android.graphics.Paint.Style.FILL);
if (!haveWidth) {
ret = workPaint.measureText (tmp, tmpstart, tmpend);
haveWidth = true;
}if (dir == -1) canvas.drawRect (x - ret, top, x, bottom, workPaint);
 else canvas.drawRect (x, top, x + ret, bottom, workPaint);
workPaint.setStyle (s);
workPaint.setColor (c);
}if (dir == -1) {
if (!haveWidth) {
ret = workPaint.measureText (tmp, tmpstart, tmpend);
haveWidth = true;
}canvas.drawText (tmp, tmpstart, tmpend, x - ret, y + workPaint.baselineShift, workPaint);
} else {
if (needWidth) {
if (!haveWidth) {
ret = workPaint.measureText (tmp, tmpstart, tmpend);
haveWidth = true;
}}canvas.drawText (tmp, tmpstart, tmpend, x, y + workPaint.baselineShift, workPaint);
}} else {
if (needWidth && !haveWidth) {
ret = workPaint.measureText (tmp, tmpstart, tmpend);
haveWidth = true;
}}} else {
ret = replacement.getSize (workPaint, text, start, end, fmi);
if (canvas != null) {
if (dir == -1) replacement.draw (canvas, text, start, end, x - ret, top, y, bottom, workPaint);
 else replacement.draw (canvas, text, start, end, x, top, y, bottom, workPaint);
}}if (dir == -1) return -ret;
 else return ret;
}, $fz.isPrivate = true, $fz), "android.graphics.Canvas,android.text.Spanned,~N,~N,~N,~B,~N,~N,~N,~N,android.graphics.Paint.FontMetricsInt,android.text.TextPaint,android.text.TextPaint,~B");
c$.getTextWidths = Clazz.defineMethod (c$, "getTextWidths", 
function (paint, workPaint, text, start, end, widths, fmi) {
var spans = text.getSpans (start, end, android.text.style.MetricAffectingSpan);
var replacement = null;
workPaint.set (paint);
for (var i = 0; i < spans.length; i++) {
var span = spans[i];
if (Clazz.instanceOf (span, android.text.style.ReplacementSpan)) {
replacement = span;
} else {
span.updateMeasureState (workPaint);
}}
var result;
if (replacement == null) {
workPaint.getFontMetricsInt (fmi);
result = workPaint.getTextWidths (text, start, end, widths);
} else {
var wid = replacement.getSize (workPaint, text, start, end, fmi);
if (end > start) {
widths[0] = wid;
for (var i = start + 1; i < end; i++) widths[i - start] = 0;

}result = end - start;
}return result;
}, "android.text.TextPaint,android.text.TextPaint,android.text.Spanned,~N,~N,~A,android.graphics.Paint.FontMetricsInt");
c$.drawDirectionalRun = Clazz.defineMethod (c$, "drawDirectionalRun", 
($fz = function (canvas, text, start, end, dir, runIsRtl, x, top, y, bottom, fmi, paint, workPaint, needWidth) {
if (!(Clazz.instanceOf (text, android.text.Spanned))) {
var ret = 0;
if (runIsRtl) {
var tmp = android.text.TextUtils.getReverse (text, start, end);
var tmpend = end - start;
if (canvas != null || needWidth) ret = paint.measureText (tmp, 0, tmpend);
if (canvas != null) canvas.drawText (tmp, 0, tmpend, x - ret, y, paint);
} else {
if (needWidth) ret = paint.measureText (text, start, end);
if (canvas != null) canvas.drawText (text, start, end, x, y, paint);
}if (fmi != null) {
paint.getFontMetricsInt (fmi);
}return ret * dir;
}var ox = x;
var minAscent = 0;
var maxDescent = 0;
var minTop = 0;
var maxBottom = 0;
var sp = text;
var division;
if (canvas == null) division = android.text.style.MetricAffectingSpan;
 else division = android.text.style.CharacterStyle;
var next;
for (var i = start; i < end; i = next) {
next = sp.nextSpanTransition (i, end, division);
x += android.text.Styled.drawUniformRun (canvas, sp, i, next, dir, runIsRtl, x, top, y, bottom, fmi, paint, workPaint, needWidth || next != end);
if (fmi != null) {
if (fmi.ascent < minAscent) minAscent = fmi.ascent;
if (fmi.descent > maxDescent) maxDescent = fmi.descent;
if (fmi.top < minTop) minTop = fmi.top;
if (fmi.bottom > maxBottom) maxBottom = fmi.bottom;
}}
if (fmi != null) {
if (start == end) {
paint.getFontMetricsInt (fmi);
} else {
fmi.ascent = minAscent;
fmi.descent = maxDescent;
fmi.top = minTop;
fmi.bottom = maxBottom;
}}return x - ox;
}, $fz.isPrivate = true, $fz), "android.graphics.Canvas,CharSequence,~N,~N,~N,~B,~N,~N,~N,~N,android.graphics.Paint.FontMetricsInt,android.text.TextPaint,android.text.TextPaint,~B");
c$.drawText = Clazz.defineMethod (c$, "drawText", 
function (canvas, text, start, end, dir, runIsRtl, x, top, y, bottom, paint, workPaint, needWidth) {
if ((dir == -1 && !runIsRtl) || (runIsRtl && dir == 1)) {
var ch = android.text.Styled.drawDirectionalRun (null, text, start, end, 1, false, 0, 0, 0, 0, null, paint, workPaint, true);
ch *= dir;
android.text.Styled.drawDirectionalRun (canvas, text, start, end, -dir, runIsRtl, x + ch, top, y, bottom, null, paint, workPaint, true);
return ch;
}return android.text.Styled.drawDirectionalRun (canvas, text, start, end, dir, runIsRtl, x, top, y, bottom, null, paint, workPaint, needWidth);
}, "android.graphics.Canvas,CharSequence,~N,~N,~N,~B,~N,~N,~N,~N,android.text.TextPaint,android.text.TextPaint,~B");
c$.drawText = Clazz.defineMethod (c$, "drawText", 
function (canvas, text, start, end, direction, x, top, y, bottom, paint, workPaint, needWidth) {
direction = direction >= 0 ? 1 : -1;
return android.text.Styled.drawText (canvas, text, start, end, direction, false, x, top, y, bottom, paint, workPaint, needWidth);
}, "android.graphics.Canvas,CharSequence,~N,~N,~N,~N,~N,~N,~N,android.text.TextPaint,android.text.TextPaint,~B");
c$.measureText = Clazz.defineMethod (c$, "measureText", 
function (paint, workPaint, text, start, end, fmi) {
return android.text.Styled.drawDirectionalRun (null, text, start, end, 1, false, 0, 0, 0, 0, fmi, paint, workPaint, true);
}, "android.text.TextPaint,android.text.TextPaint,CharSequence,~N,~N,android.graphics.Paint.FontMetricsInt");
});
