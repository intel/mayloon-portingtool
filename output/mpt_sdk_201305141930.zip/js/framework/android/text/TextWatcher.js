﻿Clazz.declarePackage ("android.text");
Clazz.declareInterface (android.text, "TextWatcher");
