﻿Clazz.declarePackage ("android.text");
Clazz.load (["android.os.Parcelable"], "android.text.ParcelableSpan", null, function () {
Clazz.declareInterface (android.text, "ParcelableSpan", android.os.Parcelable);
});
