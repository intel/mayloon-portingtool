﻿Clazz.declarePackage ("android.text.method");
Clazz.declareInterface (android.text.method, "KeyListener");
