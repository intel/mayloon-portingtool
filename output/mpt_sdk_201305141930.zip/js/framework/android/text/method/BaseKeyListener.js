﻿Clazz.declarePackage ("android.text.method");
Clazz.load (["android.text.method.KeyListener", "android.text.NoCopySpan"], "android.text.method.BaseKeyListener", ["android.text.Selection"], function () {
c$ = Clazz.declareType (android.text.method, "BaseKeyListener", null, android.text.method.KeyListener);
Clazz.overrideMethod (c$, "onKeyOther", 
function (view, content, event) {
if (event.getAction () != 2 || event.getKeyCode () != 0) {
return false;
}var selStart;
var selEnd;
var a = android.text.Selection.getSelectionStart (content);
var b = android.text.Selection.getSelectionEnd (content);
selStart = Math.min (a, b);
selEnd = Math.max (a, b);
var text = event.getCharacters ();
if (text == null) {
return false;
}return true;
}, "android.view.View,android.text.Editable,android.view.KeyEvent");
c$.OLD_SEL_START = c$.prototype.OLD_SEL_START =  new android.text.NoCopySpan.Concrete ();
});
