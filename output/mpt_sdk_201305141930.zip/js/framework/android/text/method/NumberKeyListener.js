﻿Clazz.declarePackage ("android.text.method");
Clazz.load (["android.text.method.BaseKeyListener"], "android.text.method.NumberKeyListener", null, function () {
c$ = Clazz.declareType (android.text.method, "NumberKeyListener", android.text.method.BaseKeyListener);
Clazz.defineMethod (c$, "getAcceptedChars", 
function () {
console.log("Missing method: getAcceptedChars");
});
});
