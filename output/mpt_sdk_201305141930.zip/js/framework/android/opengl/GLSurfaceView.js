﻿Clazz.declarePackage ("android.opengl");
Clazz.load (["android.view.SurfaceHolder", "$.SurfaceView", "java.io.Writer", "java.lang.Thread", "$.StringBuilder", "java.util.ArrayList"], "android.opengl.GLSurfaceView", ["android.opengl.GLDebugHelper", "$.GLES10", "$.GLES20", "android.util.Log", "java.lang.IllegalArgumentException", "$.IllegalStateException", "$.RuntimeException", "javax.microedition.khronos.egl.EGL10"], function () {
c$ = Clazz.decorateAsClass (function () {
if (!Clazz.isClassDefined ("android.opengl.GLSurfaceView.DefaultContextFactory")) {
android.opengl.GLSurfaceView.$GLSurfaceView$DefaultContextFactory$ ();
}
if (!Clazz.isClassDefined ("android.opengl.GLSurfaceView.BaseConfigChooser")) {
android.opengl.GLSurfaceView.$GLSurfaceView$BaseConfigChooser$ ();
}
if (!Clazz.isClassDefined ("android.opengl.GLSurfaceView.ComponentSizeChooser")) {
android.opengl.GLSurfaceView.$GLSurfaceView$ComponentSizeChooser$ ();
}
if (!Clazz.isClassDefined ("android.opengl.GLSurfaceView.SimpleEGLConfigChooser")) {
android.opengl.GLSurfaceView.$GLSurfaceView$SimpleEGLConfigChooser$ ();
}
if (!Clazz.isClassDefined ("android.opengl.GLSurfaceView.EglHelper")) {
android.opengl.GLSurfaceView.$GLSurfaceView$EglHelper$ ();
}
if (!Clazz.isClassDefined ("android.opengl.GLSurfaceView.GLThread")) {
android.opengl.GLSurfaceView.$GLSurfaceView$GLThread$ ();
}
this.mSizeChanged = true;
this.mGLThread = null;
this.mEGLConfigChooser = null;
this.mEGLContextFactory = null;
this.mEGLWindowSurfaceFactory = null;
this.mGLWrapper = null;
this.mDebugFlags = 0;
this.mEGLContextClientVersion = 0;
Clazz.instantialize (this, arguments);
}, android.opengl, "GLSurfaceView", android.view.SurfaceView, android.view.SurfaceHolder.Callback);
Clazz.makeConstructor (c$, 
function (context) {
Clazz.superConstructor (this, android.opengl.GLSurfaceView, [context]);
this.init ();
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.opengl.GLSurfaceView, [context, attrs]);
this.init ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "init", 
($fz = function () {
var $private = Clazz.checkPrivateMethod (arguments);
if ($private != null) {
return $private.apply (this, arguments);
}
var holder = this.getHolder ();
holder.addCallback (this);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setGLWrapper", 
function (glWrapper) {
this.mGLWrapper = glWrapper;
}, "android.opengl.GLSurfaceView.GLWrapper");
Clazz.defineMethod (c$, "setDebugFlags", 
function (debugFlags) {
this.mDebugFlags = debugFlags;
}, "~N");
Clazz.defineMethod (c$, "getDebugFlags", 
function () {
return this.mDebugFlags;
});
Clazz.defineMethod (c$, "setRenderer", 
function (renderer) {
this.getHolder ().addCallback (this);
this.checkRenderThreadState ();
if (this.mEGLConfigChooser == null) {
this.mEGLConfigChooser = Clazz.innerTypeInstance (android.opengl.GLSurfaceView.SimpleEGLConfigChooser, this, null, true);
}if (this.mEGLContextFactory == null) {
this.mEGLContextFactory = Clazz.innerTypeInstance (android.opengl.GLSurfaceView.DefaultContextFactory, this, null);
}if (this.mEGLWindowSurfaceFactory == null) {
this.mEGLWindowSurfaceFactory =  new android.opengl.GLSurfaceView.DefaultWindowSurfaceFactory ();
}this.mGLThread = Clazz.innerTypeInstance (android.opengl.GLSurfaceView.GLThread, this, null, renderer);
this.mGLThread.start ();
}, "android.opengl.GLSurfaceView.Renderer");
Clazz.defineMethod (c$, "setEGLContextFactory", 
function (factory) {
this.checkRenderThreadState ();
this.mEGLContextFactory = factory;
}, "android.opengl.GLSurfaceView.EGLContextFactory");
Clazz.defineMethod (c$, "setEGLWindowSurfaceFactory", 
function (factory) {
this.checkRenderThreadState ();
this.mEGLWindowSurfaceFactory = factory;
}, "android.opengl.GLSurfaceView.EGLWindowSurfaceFactory");
Clazz.defineMethod (c$, "setEGLConfigChooser", 
function (configChooser) {
this.checkRenderThreadState ();
this.mEGLConfigChooser = configChooser;
}, "android.opengl.GLSurfaceView.EGLConfigChooser");
Clazz.defineMethod (c$, "setEGLConfigChooser", 
function (needDepth) {
this.setEGLConfigChooser (Clazz.innerTypeInstance (android.opengl.GLSurfaceView.SimpleEGLConfigChooser, this, null, needDepth));
}, "~B");
Clazz.defineMethod (c$, "setEGLConfigChooser", 
function (redSize, greenSize, blueSize, alphaSize, depthSize, stencilSize) {
this.setEGLConfigChooser (Clazz.innerTypeInstance (android.opengl.GLSurfaceView.ComponentSizeChooser, this, null, redSize, greenSize, blueSize, alphaSize, depthSize, stencilSize));
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "setEGLContextClientVersion", 
function (version) {
this.checkRenderThreadState ();
if (version != 2) {
throw  new IllegalArgumentException ("Only OpenGL ES 2.0 is supported!");
}this.mEGLContextClientVersion = version;
}, "~N");
Clazz.defineMethod (c$, "setRenderMode", 
function (renderMode) {
this.mGLThread.setRenderMode (renderMode);
}, "~N");
Clazz.defineMethod (c$, "getRenderMode", 
function () {
return this.mGLThread.getRenderMode ();
});
Clazz.defineMethod (c$, "requestRender", 
function () {
this.mGLThread.requestRender ();
});
Clazz.overrideMethod (c$, "surfaceCreated", 
function (holder) {
if (true) {
android.util.Log.d ("GLSurfaceView", "surfacecreated");
}this.mGLThread.surfaceCreated ();
}, "android.view.SurfaceHolder");
Clazz.overrideMethod (c$, "surfaceDestroyed", 
function (holder) {
if (true) {
android.util.Log.d ("GLSurfaceView", "surfacedestroyed");
}this.mGLThread.surfaceDestroyed ();
}, "android.view.SurfaceHolder");
Clazz.overrideMethod (c$, "surfaceChanged", 
function (holder, format, w, h) {
if (true) {
android.util.Log.d ("GLSurfaceView", "surfaceChanged:w:" + w + " h:" + h);
}this.mGLThread.onWindowResize (w, h);
}, "android.view.SurfaceHolder,~N,~N,~N");
Clazz.defineMethod (c$, "onPause", 
function () {
this.mGLThread.onPause ();
});
Clazz.defineMethod (c$, "onResume", 
function () {
this.mGLThread.onResume ();
});
Clazz.defineMethod (c$, "queueEvent", 
function (r) {
this.mGLThread.queueEvent (r);
}, "Runnable");
Clazz.defineMethod (c$, "onDetachedFromWindow", 
function () {
android.util.Log.d ("GLSurfaceView", "onDetachedFromWindow");
Clazz.superCall (this, android.opengl.GLSurfaceView, "onDetachedFromWindow", []);
this.mGLThread.requestExitAndWait ();
});
Clazz.defineMethod (c$, "checkRenderThreadState", 
($fz = function () {
if (this.mGLThread != null) {
throw  new IllegalStateException ("setRenderer has already been called for this instance.");
}}, $fz.isPrivate = true, $fz));
c$.$GLSurfaceView$DefaultContextFactory$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.EGL_CONTEXT_CLIENT_VERSION = 0x3098;
Clazz.instantialize (this, arguments);
}, android.opengl.GLSurfaceView, "DefaultContextFactory", null, android.opengl.GLSurfaceView.EGLContextFactory);
Clazz.overrideMethod (c$, "createContext", 
function (a, b, c) {
var d = [this.EGL_CONTEXT_CLIENT_VERSION, this.b$["android.opengl.GLSurfaceView"].mEGLContextClientVersion, 12344];
return a.eglCreateContext (b, c, javax.microedition.khronos.egl.EGL10.EGL_NO_CONTEXT, this.b$["android.opengl.GLSurfaceView"].mEGLContextClientVersion != 0 ? d : null);
}, "javax.microedition.khronos.egl.EGL10,javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLConfig");
Clazz.overrideMethod (c$, "destroyContext", 
function (a, b, c) {
if (!a.eglDestroyContext (b, c)) {
android.util.Log.e ("DefaultContextFactory", "display:" + b + " context: " + c);
if (true) {
android.util.Log.i ("DefaultContextFactory", "tid=");
}}}, "javax.microedition.khronos.egl.EGL10,javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLContext");
c$ = Clazz.p0p ();
};
c$.$GLSurfaceView$BaseConfigChooser$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mConfigSpec = null;
Clazz.instantialize (this, arguments);
}, android.opengl.GLSurfaceView, "BaseConfigChooser", null, android.opengl.GLSurfaceView.EGLConfigChooser);
Clazz.makeConstructor (c$, 
function (a) {
this.mConfigSpec = this.filterConfigSpec (a);
}, "~A");
Clazz.defineMethod (c$, "chooseConfig", 
function (a, b) {
var c =  Clazz.newArray (1, 0);
if (!a.eglChooseConfig (b, this.mConfigSpec, null, 0, c)) {
throw  new IllegalArgumentException ("eglChooseConfig failed");
}var d = c[0];
if (d <= 0) {
throw  new IllegalArgumentException ("No configs match configSpec");
}var e =  new Array (d);
if (!a.eglChooseConfig (b, this.mConfigSpec, e, d, c)) {
throw  new IllegalArgumentException ("eglChooseConfig#2 failed");
}var f = this.chooseConfig (a, b, e);
if (f == null) {
throw  new IllegalArgumentException ("No config chosen");
}return f;
}, "javax.microedition.khronos.egl.EGL10,javax.microedition.khronos.egl.EGLDisplay");
Clazz.defineMethod (c$, "filterConfigSpec", 
($fz = function (a) {
if (this.b$["android.opengl.GLSurfaceView"].mEGLContextClientVersion != 2) {
return a;
}var b = a.length;
var c =  Clazz.newArray (b + 2, 0);
System.arraycopy (a, 0, c, 0, b - 1);
c[b - 1] = 12352;
c[b] = 4;
c[b + 1] = 12344;
return c;
}, $fz.isPrivate = true, $fz), "~A");
c$ = Clazz.p0p ();
};
c$.$GLSurfaceView$ComponentSizeChooser$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mValue = null;
this.mRedSize = 0;
this.mGreenSize = 0;
this.mBlueSize = 0;
this.mAlphaSize = 0;
this.mDepthSize = 0;
this.mStencilSize = 0;
Clazz.instantialize (this, arguments);
}, android.opengl.GLSurfaceView, "ComponentSizeChooser", android.opengl.GLSurfaceView.BaseConfigChooser, null, Clazz.innerTypeInstance (android.opengl.GLSurfaceView.BaseConfigChooser, this, null, Clazz.inheritArgs));
Clazz.makeConstructor (c$, 
function (a, b, c, d, e, f) {
Clazz.superConstructor (this, android.opengl.GLSurfaceView.ComponentSizeChooser, [[12324, a, 12323, b, 12322, c, 12321, d, 12325, e, 12326, f, 12344]]);
this.mValue =  Clazz.newArray (1, 0);
this.mRedSize = a;
this.mGreenSize = b;
this.mBlueSize = c;
this.mAlphaSize = d;
this.mDepthSize = e;
this.mStencilSize = f;
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "chooseConfig", 
function (a, b, c) {
for (var config, $config = 0, $$config = c; $config < $$config.length && ((config = $$config[$config]) || true); $config++) {
var d = this.findConfigAttrib (a, b, config, 12325, 0);
var e = this.findConfigAttrib (a, b, config, 12326, 0);
if ((d >= this.mDepthSize) && (e >= this.mStencilSize)) {
var f = this.findConfigAttrib (a, b, config, 12324, 0);
var g = this.findConfigAttrib (a, b, config, 12323, 0);
var h = this.findConfigAttrib (a, b, config, 12322, 0);
var i = this.findConfigAttrib (a, b, config, 12321, 0);
if ((f == this.mRedSize) && (g == this.mGreenSize) && (h == this.mBlueSize) && (i == this.mAlphaSize)) {
return config;
}}}
return null;
}, "javax.microedition.khronos.egl.EGL10,javax.microedition.khronos.egl.EGLDisplay,~A");
Clazz.defineMethod (c$, "findConfigAttrib", 
($fz = function (a, b, c, d, e) {
if (a.eglGetConfigAttrib (b, c, d, this.mValue)) {
return this.mValue[0];
}return e;
}, $fz.isPrivate = true, $fz), "javax.microedition.khronos.egl.EGL10,javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLConfig,~N,~N");
c$ = Clazz.p0p ();
};
c$.$GLSurfaceView$SimpleEGLConfigChooser$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.opengl.GLSurfaceView, "SimpleEGLConfigChooser", android.opengl.GLSurfaceView.ComponentSizeChooser, null, Clazz.innerTypeInstance (android.opengl.GLSurfaceView.ComponentSizeChooser, this, null, Clazz.inheritArgs));
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.opengl.GLSurfaceView.SimpleEGLConfigChooser, [5, 6, 5, 0, a ? 16 : 0, 0]);
}, "~B");
c$ = Clazz.p0p ();
};
c$.$GLSurfaceView$EglHelper$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mEgl = null;
this.mEglDisplay = null;
this.mEglSurface = null;
this.mEglConfig = null;
this.mEglContext = null;
this.mCanvasID = null;
Clazz.instantialize (this, arguments);
}, android.opengl.GLSurfaceView, "EglHelper");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "start", 
function () {
if (true) {
android.util.Log.w ("EglHelper", "start() tid=");
}this.mEglSurface = null;
});
Clazz.defineMethod (c$, "createSurface", 
function (a) {
if (true) {
android.util.Log.w ("EglHelper", "createSurface()  tid=");
}var b =  new android.opengl.GLES10 ();
if (this.b$["android.opengl.GLSurfaceView"].mGLWrapper != null) {
b = this.b$["android.opengl.GLSurfaceView"].mGLWrapper.wrap (b);
}if ((this.b$["android.opengl.GLSurfaceView"].mDebugFlags & (3)) != 0) {
var c = 0;
var d = null;
if ((this.b$["android.opengl.GLSurfaceView"].mDebugFlags & 1) != 0) {
c |= 1;
}if ((this.b$["android.opengl.GLSurfaceView"].mDebugFlags & 2) != 0) {
d =  new android.opengl.GLSurfaceView.LogWriter ();
}b = android.opengl.GLDebugHelper.wrap (b, c, d);
}var c = a.lockCanvas ();
if (c == null) {
throw  new RuntimeException ("Can't create a HTML5 canvas for this GLSurfaceView");
}var d = c.getHTML5CanvasID ();
if (d == null) {
throw  new RuntimeException ("Can't find canvas ID of GLSurfaceView");
}this.mCanvasID = d;
var _canvas = document.getElementById(this.mCanvasID);
if (!_canvas) {
throw "Can't get Canvas for GLSurfaceView!"
}
// set the background
_canvas.style.backgroundColor = "rgba(0,0,0,255)";
// Support FireFox, Safari, Chrome
var context = _canvas.getContext("webkit-3d") || _canvas.getContext("webgl") || _canvas.getContext("experimental-webgl") || _canvas.getContext("moz-webgl");
if (!context) {
throw "Can't get 3d context of GLSurfaceView' canvas!"
}
// android opengl es2.0 uses static interface in app, so we save the context
// in the GLES20' prototype.
android.opengl.GLES20.prototype.mContext = context;
android.opengl.GLES20.prototype.classInit();
return b;
}, "android.view.SurfaceHolder");
Clazz.defineMethod (c$, "swap", 
function () {
android.opengl.GLES20.glFinish ();
return true;
});
Clazz.defineMethod (c$, "destroySurface", 
function () {
if (true) {
android.util.Log.w ("EglHelper", "destroySurface()  tid=");
}var canvas = document.getElementById(this.mCanvasID);
if (canvas) {
canvas.parentNode.removeChild(canvas);
}
});
Clazz.defineMethod (c$, "finish", 
function () {
if (true) {
android.util.Log.w ("EglHelper", "finish() tid=");
}android.opengl.GLES20.prototype.mContext = null;
android.opengl.GLES20.prototype.classTerminate();
});
Clazz.defineMethod (c$, "throwEglException", 
($fz = function (a, b) {
var c = a + " failed: ";
if (true) {
android.util.Log.e ("EglHelper", "throwEglException tid=" + " " + c);
}throw  new RuntimeException (c);
}, $fz.isPrivate = true, $fz), "~S,~N");
c$ = Clazz.p0p ();
};
c$.$GLSurfaceView$GLThread$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mShouldExit = false;
this.mExited = false;
this.mRequestPaused = false;
this.mPaused = false;
this.mHasSurface = false;
this.mWaitingForSurface = false;
this.mHaveEglContext = false;
this.mHaveEglSurface = false;
this.mShouldReleaseEglContext = false;
this.mWidth = 0;
this.mHeight = 0;
this.mRenderMode = 0;
this.mRequestRender = false;
this.mRenderComplete = false;
this.mEventQueue = null;
this.mRenderer = null;
this.mEglHelper = null;
this.createEglContext = false;
this.createEglSurface = false;
this.lostEglContext = false;
this.sizeChanged = false;
this.wantRenderNotification = false;
this.doRenderNotification = false;
this.askedToReleaseEglContext = false;
this.w = 0;
this.h = 0;
this.event = null;
this.gl = null;
Clazz.instantialize (this, arguments);
}, android.opengl.GLSurfaceView, "GLThread", Thread);
Clazz.prepareFields (c$, function () {
this.mEventQueue =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.opengl.GLSurfaceView.GLThread);
this.mWidth = 0;
this.mHeight = 0;
this.mRequestRender = true;
this.mRenderMode = 1;
this.mRenderer = a;
}, "android.opengl.GLSurfaceView.Renderer");
Clazz.overrideMethod (c$, "run", 
function () {
this.setName ("GLThread ");
if (true) {
android.util.Log.i ("GLThread", "starting tid=");
}try {
this.guardedRun ();
} catch (e) {
if (Clazz.instanceOf (e, InterruptedException)) {
} else {
throw e;
}
} finally {
}
});
Clazz.defineMethod (c$, "stopEglSurfaceLocked", 
($fz = function () {
if (this.mHaveEglSurface) {
this.mHaveEglSurface = false;
this.mShouldExit = true;
this.mEglHelper.destroySurface ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "stopEglContextLocked", 
($fz = function () {
if (this.mHaveEglContext) {
this.mEglHelper.finish ();
this.mHaveEglContext = false;
android.opengl.GLSurfaceView.sGLThreadManager.releaseEglContextLocked (this);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "mainLoop", 
($fz = function (a) {
if (!a) return ;
try {
{
while (true) {
if (this.mShouldExit) {
return ;
}if (!this.mEventQueue.isEmpty ()) {
this.event = this.mEventQueue.remove (0);
break;
}if (this.mPaused != this.mRequestPaused) {
this.mPaused = this.mRequestPaused;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
if (true) {
android.util.Log.i ("GLThread", "mPaused is now " + this.mPaused + " tid=");
}}if (this.mShouldReleaseEglContext) {
if (true) {
android.util.Log.i ("GLThread", "releasing EGL context because asked to tid=");
}this.stopEglSurfaceLocked ();
this.stopEglContextLocked ();
this.mShouldReleaseEglContext = false;
this.askedToReleaseEglContext = true;
}if (this.lostEglContext) {
this.stopEglSurfaceLocked ();
this.stopEglContextLocked ();
this.lostEglContext = false;
}if (this.mHaveEglSurface && this.mPaused) {
if (true) {
android.util.Log.i ("GLThread", "releasing EGL surface because paused tid=");
}this.stopEglSurfaceLocked ();
if (android.opengl.GLSurfaceView.sGLThreadManager.shouldReleaseEGLContextWhenPausing ()) {
this.stopEglContextLocked ();
if (true) {
android.util.Log.i ("GLThread", "releasing EGL context because paused tid=");
}}if (android.opengl.GLSurfaceView.sGLThreadManager.shouldTerminateEGLWhenPausing ()) {
this.mEglHelper.finish ();
if (true) {
android.util.Log.i ("GLThread", "terminating EGL because paused tid=");
}}}if ((!this.mHasSurface) && (!this.mWaitingForSurface)) {
if (true) {
android.util.Log.i ("GLThread", "noticed surfaceView surface lost tid=");
}if (this.mHaveEglSurface) {
this.stopEglSurfaceLocked ();
}this.mWaitingForSurface = true;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
}if (this.mHasSurface && this.mWaitingForSurface) {
if (true) {
android.util.Log.i ("GLThread", "noticed surfaceView surface acquired tid=");
}this.mWaitingForSurface = false;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
}if (this.doRenderNotification) {
if (true) {
android.util.Log.i ("GLThread", "sending render notification tid=");
}this.wantRenderNotification = false;
this.doRenderNotification = false;
this.mRenderComplete = true;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
}if (this.readyToDraw ()) {
if (!this.mHaveEglContext) {
if (this.askedToReleaseEglContext) {
this.askedToReleaseEglContext = false;
} else if (android.opengl.GLSurfaceView.sGLThreadManager.tryAcquireEglContextLocked (this)) {
try {
this.mEglHelper.start ();
} catch (t) {
if (Clazz.instanceOf (t, RuntimeException)) {
android.opengl.GLSurfaceView.sGLThreadManager.releaseEglContextLocked (this);
throw t;
} else {
throw t;
}
}
this.mHaveEglContext = true;
this.createEglContext = true;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
}}if (this.mHaveEglContext && !this.mHaveEglSurface) {
this.mHaveEglSurface = true;
this.createEglSurface = true;
this.sizeChanged = true;
}if (this.mHaveEglSurface) {
if (this.b$["android.opengl.GLSurfaceView"].mSizeChanged) {
this.sizeChanged = true;
this.w = this.mWidth;
this.h = this.mHeight;
this.wantRenderNotification = true;
if (true) {
android.util.Log.i ("GLThread", "noticing that we want render notification tid=");
}if (true) {
} else {
this.mRequestRender = false;
}this.b$["android.opengl.GLSurfaceView"].mSizeChanged = false;
} else {
this.mRequestRender = false;
}android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
break;
}}if (true) {
android.util.Log.i ("GLThread", "waiting tid= mHaveEglContext: " + this.mHaveEglContext + " mHaveEglSurface: " + this.mHaveEglSurface + " mPaused: " + this.mPaused + " mHasSurface: " + this.mHasSurface + " mWaitingForSurface: " + this.mWaitingForSurface + " mWidth: " + this.mWidth + " mHeight: " + this.mHeight + " mRequestRender: " + this.mRequestRender + " mRenderMode: " + this.mRenderMode);
}}
}if (this.event != null) {
this.event.run ();
this.event = null;
return ;
}if (this.createEglSurface) {
if (true) {
android.util.Log.w ("GLThread", "egl createSurface");
}this.gl = this.mEglHelper.createSurface (this.b$["android.opengl.GLSurfaceView"].getHolder ());
if (this.gl == null) {
throw  new RuntimeException ("Can't create a surface for gl");
}android.opengl.GLSurfaceView.sGLThreadManager.checkGLDriver (this.gl);
this.createEglSurface = false;
}if (this.createEglContext) {
if (true) {
android.util.Log.w ("GLThread", "onSurfaceCreated");
}this.mRenderer.onSurfaceCreated (this.gl, this.mEglHelper.mEglConfig);
this.createEglContext = false;
}if (this.sizeChanged) {
if (true) {
android.util.Log.w ("GLThread", "onSurfaceChanged(" + this.w + ", " + this.h + ")");
}this.mRenderer.onSurfaceChanged (this.gl, this.w, this.h);
this.sizeChanged = false;
}if (false) {
android.util.Log.w ("GLThread", "onDrawFrame tid=");
}this.mRenderer.onDrawFrame (this.gl);
if (!this.mEglHelper.swap ()) {
if (true) {
android.util.Log.i ("GLThread", "egl context lost tid=");
}this.lostEglContext = true;
}if (this.wantRenderNotification) {
this.doRenderNotification = true;
}} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
{
this.stopEglSurfaceLocked ();
this.stopEglContextLocked ();
}} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "initMainLoopState", 
($fz = function () {
this.mainLoop (false);
this.createEglContext = false;
this.createEglSurface = false;
this.lostEglContext = false;
this.sizeChanged = false;
this.wantRenderNotification = false;
this.doRenderNotification = false;
this.askedToReleaseEglContext = false;
this.w = this.h = 0;
this.event = null;
this.gl = null;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "guardedRun", 
($fz = function () {
this.mEglHelper = Clazz.innerTypeInstance (android.opengl.GLSurfaceView.EglHelper, this, null);
this.mHaveEglContext = false;
this.mHaveEglSurface = false;
this.initMainLoopState ();
var requestAnimationFrame = window.requestAnimationFrame ||
window.webkitRequestAnimationFrame ||
window.mozRequestAnimationFrame    ||
window.oRequestAnimationFrame      ||
window.msRequestAnimationFrame     || null;
var cancelAnimationFrame = window.cancelAnimationFrame ||
window.webkitCancelRequestAnimationFrame ||
window.mozCancelRequestAnimationFrame    ||
window.oCancelRequestAnimationFrame      ||
window.msRequestAnimationFrame     || null;
if (requestAnimationFrame == null || cancelAnimationFrame == null) {
throw "requestAnimationFrame is not support by this browser";
}
var glthread = this;
var requestID = null;
var recursiveAnim = function() {
glthread.mainLoop(true);
if (glthread.mShouldExit) {
console.debug("GL animation exited.");
cancelAnimationFrame(requestID);
} else {
var canvas = document.getElementById(glthread.mEglHelper.mCanvasID);
if (canvas) {
// only update the webgl canvas, may get better performance
requestAnimationFrame(recursiveAnim, canvas);
} else {
requestAnimationFrame(recursiveAnim);
}
}
};
// start the main loop
requestID = requestAnimationFrame(recursiveAnim);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "ableToDraw", 
function () {
return this.mHaveEglContext && this.mHaveEglSurface && this.readyToDraw ();
});
Clazz.defineMethod (c$, "readyToDraw", 
($fz = function () {
return (!this.mPaused) && this.mHasSurface && (this.mWidth > 0) && (this.mHeight > 0) && (this.mRequestRender || (this.mRenderMode == 1));
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setRenderMode", 
function (a) {
if (!((0 <= a) && (a <= 1))) {
throw  new IllegalArgumentException ("renderMode");
}{
this.mRenderMode = a;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
}}, "~N");
Clazz.defineMethod (c$, "getRenderMode", 
function () {
{
return this.mRenderMode;
}});
Clazz.defineMethod (c$, "requestRender", 
function () {
{
this.mRequestRender = true;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
}});
Clazz.defineMethod (c$, "surfaceCreated", 
function () {
{
if (true) {
android.util.Log.i ("GLThread", "surfaceCreated tid=");
}this.mHasSurface = true;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
while ((this.mWaitingForSurface) && (!this.mExited)) {
try {
android.opengl.GLSurfaceView.sGLThreadManager.wait ();
} catch (e) {
if (Clazz.instanceOf (e, InterruptedException)) {
Thread.currentThread ().interrupt ();
} else {
throw e;
}
}
}
}});
Clazz.defineMethod (c$, "surfaceDestroyed", 
function () {
{
if (true) {
android.util.Log.i ("GLThread", "surfaceDestroyed tid=");
}this.mHasSurface = false;
android.opengl.GLSurfaceView.sGLThreadManager.threadExiting (this);
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
while ((!this.mWaitingForSurface) && (!this.mExited)) {
try {
android.opengl.GLSurfaceView.sGLThreadManager.wait ();
} catch (e) {
if (Clazz.instanceOf (e, InterruptedException)) {
Thread.currentThread ().interrupt ();
} else {
throw e;
}
}
}
}});
Clazz.defineMethod (c$, "onPause", 
function () {
{
if (true) {
android.util.Log.i ("GLThread", "onPause tid=");
}this.mRequestPaused = true;
this.mPaused = true;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
while ((!this.mExited) && (!this.mPaused)) {
if (true) {
android.util.Log.i ("Main thread", "onPause waiting for mPaused.");
}try {
android.opengl.GLSurfaceView.sGLThreadManager.wait ();
} catch (ex) {
if (Clazz.instanceOf (ex, InterruptedException)) {
Thread.currentThread ().interrupt ();
} else {
throw ex;
}
}
}
}});
Clazz.defineMethod (c$, "onResume", 
function () {
{
if (true) {
android.util.Log.i ("GLThread", "onResume tid=");
}this.mRequestPaused = false;
this.mRequestRender = true;
this.mRenderComplete = false;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
while ((!this.mExited) && this.mPaused && (!this.mRenderComplete)) {
if (true) {
android.util.Log.i ("Main thread", "onResume waiting for !mPaused.");
}try {
android.opengl.GLSurfaceView.sGLThreadManager.wait ();
} catch (ex) {
if (Clazz.instanceOf (ex, InterruptedException)) {
Thread.currentThread ().interrupt ();
} else {
throw ex;
}
}
}
}});
Clazz.defineMethod (c$, "onWindowResize", 
function (a, b) {
{
this.mWidth = a;
this.mHeight = b;
this.b$["android.opengl.GLSurfaceView"].mSizeChanged = true;
this.mRequestRender = true;
this.mRenderComplete = false;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
while (!this.mExited && !this.mPaused && !this.mRenderComplete && (this.b$["android.opengl.GLSurfaceView"].mGLThread != null && this.b$["android.opengl.GLSurfaceView"].mGLThread.ableToDraw ())) {
if (true) {
android.util.Log.i ("Main thread", "onWindowResize waiting for render complete from tid=");
}try {
android.opengl.GLSurfaceView.sGLThreadManager.wait ();
} catch (ex) {
if (Clazz.instanceOf (ex, InterruptedException)) {
Thread.currentThread ().interrupt ();
} else {
throw ex;
}
}
}
}}, "~N,~N");
Clazz.defineMethod (c$, "requestExitAndWait", 
function () {
{
this.mShouldExit = true;
this.stopEglSurfaceLocked ();
this.stopEglContextLocked ();
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
while (!this.mExited) {
try {
android.opengl.GLSurfaceView.sGLThreadManager.wait ();
} catch (ex) {
if (Clazz.instanceOf (ex, InterruptedException)) {
Thread.currentThread ().interrupt ();
} else {
throw ex;
}
}
}
}});
Clazz.defineMethod (c$, "requestReleaseEglContextLocked", 
function () {
this.mShouldReleaseEglContext = true;
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
});
Clazz.defineMethod (c$, "queueEvent", 
function (a) {
if (a == null) {
throw  new IllegalArgumentException ("r must not be null");
}{
this.mEventQueue.add (a);
android.opengl.GLSurfaceView.sGLThreadManager.notifyAll ();
}}, "Runnable");
c$ = Clazz.p0p ();
};
Clazz.declareInterface (android.opengl.GLSurfaceView, "GLWrapper");
Clazz.declareInterface (android.opengl.GLSurfaceView, "Renderer");
Clazz.declareInterface (android.opengl.GLSurfaceView, "EGLContextFactory");
Clazz.declareInterface (android.opengl.GLSurfaceView, "EGLWindowSurfaceFactory");
Clazz.pu$h ();
c$ = Clazz.declareType (android.opengl.GLSurfaceView, "DefaultWindowSurfaceFactory", null, android.opengl.GLSurfaceView.EGLWindowSurfaceFactory);
Clazz.overrideMethod (c$, "createWindowSurface", 
function (a, b, c, d) {
return a.eglCreateWindowSurface (b, c, d, null);
}, "javax.microedition.khronos.egl.EGL10,javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLConfig,~O");
Clazz.overrideMethod (c$, "destroySurface", 
function (a, b, c) {
a.eglDestroySurface (b, c);
}, "javax.microedition.khronos.egl.EGL10,javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLSurface");
c$ = Clazz.p0p ();
Clazz.declareInterface (android.opengl.GLSurfaceView, "EGLConfigChooser");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mBuilder = null;
Clazz.instantialize (this, arguments);
}, android.opengl.GLSurfaceView, "LogWriter", java.io.Writer);
Clazz.prepareFields (c$, function () {
this.mBuilder =  new StringBuilder ();
});
Clazz.overrideMethod (c$, "close", 
function () {
this.flushBuilder ();
});
Clazz.overrideMethod (c$, "flush", 
function () {
this.flushBuilder ();
});
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
for (var d = 0; d < c; d++) {
var e = a[b + d];
if ((e).charCodeAt (0) == ('\n').charCodeAt (0)) {
this.flushBuilder ();
} else {
this.mBuilder.append (e);
}}
}, "~A,~N,~N");
Clazz.defineMethod (c$, "flushBuilder", 
($fz = function () {
if (this.mBuilder.length () > 0) {
android.util.Log.v ("GLSurfaceView", this.mBuilder.toString ());
this.mBuilder.$delete (0, this.mBuilder.length ());
}}, $fz.isPrivate = true, $fz));
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mGLESVersionCheckComplete = false;
this.mGLESVersion = 0;
this.mGLESDriverCheckComplete = false;
this.mMultipleGLESContextsAllowed = false;
this.mEglOwner = null;
Clazz.instantialize (this, arguments);
}, android.opengl.GLSurfaceView, "GLThreadManager");
Clazz.defineMethod (c$, "threadExiting", 
function (a) {
if (true) {
android.util.Log.i ("GLThread", "exiting tid=");
}a.mExited = true;
if (this.mEglOwner === a) {
this.mEglOwner = null;
}this.notifyAll ();
}, "android.opengl.GLSurfaceView.GLThread");
Clazz.defineMethod (c$, "tryAcquireEglContextLocked", 
function (a) {
if (this.mEglOwner === a || this.mEglOwner == null) {
this.mEglOwner = a;
this.notifyAll ();
return true;
}this.checkGLESVersion ();
if (this.mMultipleGLESContextsAllowed) {
return true;
}if (this.mEglOwner != null) {
this.mEglOwner.requestReleaseEglContextLocked ();
}return false;
}, "android.opengl.GLSurfaceView.GLThread");
Clazz.defineMethod (c$, "releaseEglContextLocked", 
function (a) {
if (this.mEglOwner === a) {
this.mEglOwner = null;
}this.notifyAll ();
}, "android.opengl.GLSurfaceView.GLThread");
Clazz.defineMethod (c$, "shouldReleaseEGLContextWhenPausing", 
function () {
return true;
});
Clazz.defineMethod (c$, "shouldTerminateEGLWhenPausing", 
function () {
this.checkGLESVersion ();
return !this.mMultipleGLESContextsAllowed;
});
Clazz.defineMethod (c$, "checkGLDriver", 
function (a) {
if (!this.mGLESDriverCheckComplete) {
this.checkGLESVersion ();
if (this.mGLESVersion < 131072) {
var b = a.glGetString (7937);
this.mMultipleGLESContextsAllowed = !b.startsWith ("Q3Dimension MSM7500 ");
if (true) {
android.util.Log.w (android.opengl.GLSurfaceView.GLThreadManager.TAG, "checkGLDriver renderer = \"" + b + "\" multipleContextsAllowed = " + this.mMultipleGLESContextsAllowed);
}this.notifyAll ();
}this.mGLESDriverCheckComplete = true;
}}, "javax.microedition.khronos.opengles.GL10");
Clazz.defineMethod (c$, "checkGLESVersion", 
($fz = function () {
if (!this.mGLESVersionCheckComplete) {
this.mGLESVersion = 131072;
if (this.mGLESVersion >= 131072) {
this.mMultipleGLESContextsAllowed = true;
}if (true) {
android.util.Log.w (android.opengl.GLSurfaceView.GLThreadManager.TAG, "checkGLESVersion mGLESVersion = " + this.mGLESVersion + " mMultipleGLESContextsAllowed = " + this.mMultipleGLESContextsAllowed);
}this.mGLESVersionCheckComplete = true;
}}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"TAG", "GLThreadManager",
"kGLES_20", 0x20000,
"kMSM7K_RENDERER_PREFIX", "Q3Dimension MSM7500 ");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"LOG_THREADS", true,
"LOG_PAUSE_RESUME", true,
"LOG_SURFACE", true,
"LOG_RENDERER", true,
"LOG_RENDERER_DRAW_FRAME", false,
"LOG_EGL", true,
"DRAW_TWICE_AFTER_SIZE_CHANGED", true,
"RENDERMODE_WHEN_DIRTY", 0,
"RENDERMODE_CONTINUOUSLY", 1,
"DEBUG_CHECK_GL_ERROR", 1,
"DEBUG_LOG_GL_CALLS", 2);
c$.sGLThreadManager = c$.prototype.sGLThreadManager =  new android.opengl.GLSurfaceView.GLThreadManager ();
});
