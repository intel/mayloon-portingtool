﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (["android.opengl.OpenGLES10.Uniform", "java.util.ArrayList"], "android.opengl.OpenGLES10.UniformState", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.defineName = null;
this.defineShaderFiles = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "UniformState", android.opengl.OpenGLES10.Uniform);
Clazz.prepareFields (c$, function () {
this.defineShaderFiles =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
function (defineShaderFile, defineName, value) {
Clazz.superConstructor (this, android.opengl.OpenGLES10.UniformState, [value]);
this.defineName = defineName;
this.defineShaderFiles.add (defineShaderFile);
}, "android.opengl.OpenGLES10.ShaderFile,~S,~O");
Clazz.defineMethod (c$, "addDefineShaderFile", 
function (defineShaderFile) {
this.defineShaderFiles.add (defineShaderFile);
}, "android.opengl.OpenGLES10.ShaderFile");
Clazz.defineMethod (c$, "getDefineShaderFiles", 
function () {
return this.defineShaderFiles;
});
Clazz.overrideMethod (c$, "getAdditionalRequiredShaderFiles", 
function () {
var shaderFiles =  new java.util.ArrayList ();
for (var i = 0; i < this.additionalRequiredShaderFiles.size (); i++) {
if (this.additionalRequiredShaderFiles.get (i).getKey ().equals (this.value) && (this.father == null || (((this.father)).getValue ()).booleanValue () === true)) {
shaderFiles.add (this.additionalRequiredShaderFiles.get (i).getValue ());
}}
return shaderFiles;
});
Clazz.overrideMethod (c$, "getValue", 
function () {
if (this.father == null || (((this.father)).getValue ()).booleanValue () === true) {
return this.value;
} else {
return null;
}});
Clazz.defineMethod (c$, "getDefine", 
function () {
if (Clazz.instanceOf (this.value, Boolean)) {
var define = "#define ";
define += this.defineName;
define += " ";
define += this.value ? "1" : "0";
define += "\n";
return define;
}if (Clazz.instanceOf (this.value, Integer)) {
var define = "#define ";
define += this.defineName;
define += " ";
define += this.value.toString ();
define += "\n";
return define;
}return null;
});
});
