﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
c$ = Clazz.decorateAsClass (function () {
this.m = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "Matrix3x3f");
Clazz.prepareFields (c$, function () {
this.m =  Clazz.newArray (9, 0);
});
Clazz.makeConstructor (c$, 
function () {
for (var i = 0; i < 9; i++) {
this.m[i] = 0;
}
});
Clazz.makeConstructor (c$, 
function (other) {
for (var i = 0; i < 9; i++) {
this.m[i] = other.m[i];
}
}, "android.opengl.OpenGLES10.Matrix3x3f");
Clazz.defineMethod (c$, "copyFrom", 
function (other) {
for (var i = 0; i < 9; i++) {
this.m[i] = other.m[i];
}
return this;
}, "android.opengl.OpenGLES10.Matrix3x3f");
Clazz.defineMethod (c$, "getItem", 
function (i, j) {
return this.m[i * 3 + j];
}, "~N,~N");
Clazz.defineMethod (c$, "equalsTo", 
function (other) {
for (var i = 0; i < 9; i++) {
if (this.m[i] != other.m[i]) {
return false;
}}
return true;
}, "android.opengl.OpenGLES10.Matrix3x3f");
Clazz.defineMethod (c$, "notEqualsTo", 
function (other) {
return !this.equalsTo (other);
}, "android.opengl.OpenGLES10.Matrix3x3f");
