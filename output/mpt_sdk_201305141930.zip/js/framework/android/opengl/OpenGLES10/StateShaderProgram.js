﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
c$ = Clazz.decorateAsClass (function () {
this.state = null;
this.shaderProgram = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "StateShaderProgram");
Clazz.makeConstructor (c$, 
function (state, program) {
this.state = state;
this.shaderProgram = program;
}, "~A,android.opengl.OpenGLES10.ShaderProgram");
