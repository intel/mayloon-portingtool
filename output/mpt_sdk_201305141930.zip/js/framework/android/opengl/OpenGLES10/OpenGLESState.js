﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (["java.util.ArrayList", "$.HashMap"], "android.opengl.OpenGLES10.OpenGLESState", ["android.opengl.OpenGLES10.Attribute", "$.Matrix3x3f", "$.Matrix4x4f", "$.Shader", "$.ShaderFile", "$.ShaderProgram", "$.ShaderSource", "$.StateShaderProgram", "$.Uniform", "$.Uniform3f", "$.Uniform4f", "$.UniformState", "$.Vector3f", "android.util.Log", "java.util.Arrays"], function () {
c$ = Clazz.decorateAsClass (function () {
this.uniforms = null;
this.attributes = null;
this.shaders = null;
this.stateShaderPrograms = null;
this.currentStateShaderProgram = null;
this.stateSize = 0;
this.stateSizeBool = 0;
this.currentState = null;
this.activeTexture = 0;
this.clientActiveTexture = 0;
this.boundTextureFormats = null;
this.boundTextures = null;
if (!Clazz.isClassDefined ("android.opengl.OpenGLES10.OpenGLESState.ShaderId")) {
android.opengl.OpenGLES10.OpenGLESState.$OpenGLESState$ShaderId$ ();
}
if (!Clazz.isClassDefined ("android.opengl.OpenGLES10.OpenGLESState.AttributeId")) {
android.opengl.OpenGLES10.OpenGLESState.$OpenGLESState$AttributeId$ ();
}
if (!Clazz.isClassDefined ("android.opengl.OpenGLES10.OpenGLESState.UniformId")) {
android.opengl.OpenGLES10.OpenGLESState.$OpenGLESState$UniformId$ ();
}
this.setCurrentProgram_uberShaderCompiled = false;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "OpenGLESState");
Clazz.prepareFields (c$, function () {
this.uniforms =  new Array (149);
this.attributes =  new Array (6);
this.shaders =  new Array (20);
this.stateShaderPrograms =  new java.util.ArrayList ();
this.currentState =  Clazz.newArray (53, 0);
this.boundTextureFormats =  new java.util.HashMap ();
});
Clazz.makeConstructor (c$, 
function () {
this.stateShaderPrograms =  new java.util.ArrayList ();
this.currentStateShaderProgram = null;
this.stateSize = 53;
this.stateSizeBool = 1;
this.activeTexture = 0;
this.clientActiveTexture = 0;
});
Clazz.defineMethod (c$, "init", 
function (context) {
java.util.Arrays.fill (this.currentState, 0);
this.boundTextures =  Clazz.newArray (context.maxTextureImageUnits, 0);
java.util.Arrays.fill (this.boundTextures, 0);
this.shaders[0] =  new android.opengl.OpenGLES10.ShaderFile (35633, "main.vert");
this.shaders[1] =  new android.opengl.OpenGLES10.ShaderFile (35633, "lighting.vert");
this.shaders[2] =  new android.opengl.OpenGLES10.ShaderFile (35633, "lightingPerVertex.vert");
this.shaders[3] =  new android.opengl.OpenGLES10.ShaderFile (35633, "lightingPerFragment.vert");
this.shaders[9] =  new android.opengl.OpenGLES10.ShaderFile (35633, "fog.glsl");
this.shaders[4] =  new android.opengl.OpenGLES10.ShaderFile (35633, "clipPlane.vert");
this.shaders[5] =  new android.opengl.OpenGLES10.ShaderFile (35633, "texture.vert");
this.shaders[6] =  new android.opengl.OpenGLES10.ShaderFile (35633, "texture0.vert");
this.shaders[7] =  new android.opengl.OpenGLES10.ShaderFile (35633, "texture1.vert");
this.shaders[8] =  new android.opengl.OpenGLES10.ShaderFile (35633, "texture2.vert");
this.shaders[10] =  new android.opengl.OpenGLES10.ShaderFile (35632, "main.frag");
this.shaders[11] =  new android.opengl.OpenGLES10.ShaderFile (35632, "lighting.frag");
this.shaders[12] =  new android.opengl.OpenGLES10.ShaderFile (35632, "lightingPerFragment.frag");
this.shaders[19] =  new android.opengl.OpenGLES10.ShaderFile (35632, "fog.glsl");
this.shaders[13] =  new android.opengl.OpenGLES10.ShaderFile (35632, "alphaTest.frag");
this.shaders[14] =  new android.opengl.OpenGLES10.ShaderFile (35632, "clipPlane.frag");
this.shaders[15] =  new android.opengl.OpenGLES10.ShaderFile (35632, "texture.frag");
this.shaders[16] =  new android.opengl.OpenGLES10.ShaderFile (35632, "texture0.frag");
this.shaders[17] =  new android.opengl.OpenGLES10.ShaderFile (35632, "texture1.frag");
this.shaders[18] =  new android.opengl.OpenGLES10.ShaderFile (35632, "texture2.frag");
this.attributes[0] =  new android.opengl.OpenGLES10.Attribute ();
this.attributes[1] =  new android.opengl.OpenGLES10.Attribute ();
this.attributes[2] =  new android.opengl.OpenGLES10.Attribute ();
this.attributes[3] =  new android.opengl.OpenGLES10.Attribute ();
this.attributes[4] =  new android.opengl.OpenGLES10.Attribute ();
this.attributes[5] =  new android.opengl.OpenGLES10.Attribute ();
if (true) {
this.uniforms[0] =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "POSITION_ENABLED", new Boolean (false));
} else {
this.uniforms[0] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}if (true) {
this.uniforms[2] =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "COLOR_ENABLED", new Boolean (false));
} else {
this.uniforms[2] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}var texcoord0Enabled = null;
if (true) {
texcoord0Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "TEXCOORD0_ENABLED", new Boolean (false));
texcoord0Enabled.addDefineShaderFile (this.shaders[16]);
this.uniforms[3] = texcoord0Enabled;
} else {
this.uniforms[3] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[3].addAdditionalRequiredShaderFile (1, this.shaders[5]);
this.uniforms[3].addAdditionalRequiredShaderFile (1, this.shaders[6]);
var texcoord1Enabled = null;
if (true) {
texcoord1Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "TEXCOORD1_ENABLED", new Boolean (false));
texcoord1Enabled.addDefineShaderFile (this.shaders[17]);
this.uniforms[4] = texcoord1Enabled;
} else {
this.uniforms[4] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[4].addAdditionalRequiredShaderFile (1, this.shaders[5]);
this.uniforms[4].addAdditionalRequiredShaderFile (1, this.shaders[7]);
var texcoord2Enabled = null;
if (true) {
texcoord2Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "TEXCOORD2_ENABLED", new Boolean (false));
texcoord2Enabled.addDefineShaderFile (this.shaders[18]);
this.uniforms[5] = texcoord2Enabled;
} else {
this.uniforms[5] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[5].addAdditionalRequiredShaderFile (1, this.shaders[5]);
this.uniforms[5].addAdditionalRequiredShaderFile (1, this.shaders[8]);
if (true) {
this.uniforms[15] =  new android.opengl.OpenGLES10.UniformState (this.shaders[5], "TEXTURE0_MATRIX_ENABLED", new Boolean (false));
} else {
this.uniforms[15] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}if (true) {
this.uniforms[16] =  new android.opengl.OpenGLES10.UniformState (this.shaders[5], "TEXTURE1_MATRIX_ENABLED", new Boolean (false));
} else {
this.uniforms[16] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}if (true) {
this.uniforms[17] =  new android.opengl.OpenGLES10.UniformState (this.shaders[5], "TEXTURE2_MATRIX_ENABLED", new Boolean (false));
} else {
this.uniforms[17] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}var lightingEnabled = null;
if (true) {
lightingEnabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "LIGHTING_ENABLED", new Boolean (false));
lightingEnabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[6] = lightingEnabled;
} else {
this.uniforms[6] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[6].addAdditionalRequiredShaderFile (1, this.shaders[1]);
this.uniforms[6].addAdditionalRequiredShaderFile (1, this.shaders[11]);
if (true) {
this.uniforms[7] =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "LIGHT_MODEL_LOCAL_VIEWER_ENABLED", new Boolean (false));
} else {
this.uniforms[7] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[7].setFather (lightingEnabled);
var lightModelTwoSideEnabled = null;
if (true) {
lightModelTwoSideEnabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[1], "LIGHT_MODEL_TWO_SIDE_ENABLED", new Boolean (false));
lightModelTwoSideEnabled.addDefineShaderFile (this.shaders[11]);
this.uniforms[8] = lightModelTwoSideEnabled;
} else {
this.uniforms[8] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[8].setFather (lightingEnabled);
var light0Enabled = null;
if (true) {
light0Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[1], "LIGHT0_ENABLED", new Boolean (false));
light0Enabled.addDefineShaderFile (this.shaders[12]);
this.uniforms[9] = light0Enabled;
} else {
this.uniforms[9] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[9].setFather (lightingEnabled);
var light1Enabled = null;
if (true) {
light1Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[1], "LIGHT1_ENABLED", new Boolean (false));
light1Enabled.addDefineShaderFile (this.shaders[12]);
this.uniforms[10] = light1Enabled;
} else {
this.uniforms[10] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[10].setFather (lightingEnabled);
var light2Enabled = null;
if (true) {
light2Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[1], "LIGHT2_ENABLED", new Boolean (false));
light2Enabled.addDefineShaderFile (this.shaders[12]);
this.uniforms[11] = light2Enabled;
} else {
this.uniforms[11] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[11].setFather (lightingEnabled);
if (true) {
this.uniforms[1] =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "NORMAL_ENABLED", new Boolean (false));
} else {
this.uniforms[1] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[1].setFather (lightingEnabled);
if (true) {
this.uniforms[26] =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "RESCALE_NORMAL_ENABLED", new Boolean (false));
} else {
this.uniforms[26] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[26].setFather (lightingEnabled);
if (true) {
this.uniforms[27] =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "NORMALIZE_ENABLED", new Boolean (false));
} else {
this.uniforms[27] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[27].setFather (lightingEnabled);
var fogEnabled = null;
if (true) {
fogEnabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "FOG_ENABLED", new Boolean (false));
fogEnabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[18] = fogEnabled;
} else {
this.uniforms[18] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}var texture0Enabled = null;
if (true) {
texture0Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "TEXTURE0_ENABLED", new Boolean (false));
texture0Enabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[12] = texture0Enabled;
} else {
this.uniforms[12] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[12].addAdditionalRequiredShaderFile (1, this.shaders[15]);
this.uniforms[12].addAdditionalRequiredShaderFile (1, this.shaders[16]);
var texture1Enabled = null;
if (true) {
texture1Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "TEXTURE1_ENABLED", new Boolean (false));
texture1Enabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[13] = texture1Enabled;
} else {
this.uniforms[13] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[13].addAdditionalRequiredShaderFile (1, this.shaders[15]);
this.uniforms[13].addAdditionalRequiredShaderFile (1, this.shaders[17]);
var texture2Enabled = null;
if (true) {
texture2Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "TEXTURE2_ENABLED", new Boolean (false));
texture2Enabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[14] = texture2Enabled;
} else {
this.uniforms[14] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[14].addAdditionalRequiredShaderFile (1, this.shaders[15]);
this.uniforms[14].addAdditionalRequiredShaderFile (1, this.shaders[18]);
var alphaTestEnabled = null;
if (true) {
alphaTestEnabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[10], "ALPHA_TEST_ENABLED", new Boolean (false));
this.uniforms[19] = alphaTestEnabled;
} else {
this.uniforms[19] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[19].addAdditionalRequiredShaderFile (1, this.shaders[13]);
var clipPlane0Enabled = null;
if (true) {
clipPlane0Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "CLIP_PLANE0_ENABLED", new Boolean (false));
clipPlane0Enabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[20] = clipPlane0Enabled;
} else {
this.uniforms[20] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[20].addAdditionalRequiredShaderFile (1, this.shaders[4]);
this.uniforms[20].addAdditionalRequiredShaderFile (1, this.shaders[14]);
var clipPlane1Enabled = null;
if (true) {
clipPlane1Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "CLIP_PLANE1_ENABLED", new Boolean (false));
clipPlane1Enabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[21] = clipPlane1Enabled;
} else {
this.uniforms[21] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[21].addAdditionalRequiredShaderFile (1, this.shaders[4]);
this.uniforms[21].addAdditionalRequiredShaderFile (1, this.shaders[14]);
var clipPlane2Enabled = null;
if (true) {
clipPlane2Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "CLIP_PLANE2_ENABLED", new Boolean (false));
clipPlane2Enabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[22] = clipPlane2Enabled;
} else {
this.uniforms[22] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[22].addAdditionalRequiredShaderFile (1, this.shaders[4]);
this.uniforms[22].addAdditionalRequiredShaderFile (1, this.shaders[14]);
var clipPlane3Enabled = null;
if (true) {
clipPlane3Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "CLIP_PLANE3_ENABLED", new Boolean (false));
clipPlane3Enabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[23] = clipPlane3Enabled;
} else {
this.uniforms[23] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[23].addAdditionalRequiredShaderFile (1, this.shaders[4]);
this.uniforms[23].addAdditionalRequiredShaderFile (1, this.shaders[14]);
var clipPlane4Enabled = null;
if (true) {
clipPlane4Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "CLIP_PLANE4_ENABLED", new Boolean (false));
clipPlane4Enabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[24] = clipPlane4Enabled;
} else {
this.uniforms[24] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[24].addAdditionalRequiredShaderFile (1, this.shaders[4]);
this.uniforms[24].addAdditionalRequiredShaderFile (1, this.shaders[14]);
var clipPlane5Enabled = null;
if (true) {
clipPlane5Enabled =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "CLIP_PLANE5_ENABLED", new Boolean (false));
clipPlane5Enabled.addDefineShaderFile (this.shaders[10]);
this.uniforms[25] = clipPlane5Enabled;
} else {
this.uniforms[25] =  new android.opengl.OpenGLES10.Uniform (new Boolean (false));
}this.uniforms[25].addAdditionalRequiredShaderFile (1, this.shaders[4]);
this.uniforms[25].addAdditionalRequiredShaderFile (1, this.shaders[14]);
var fogMode = null;
if (true) {
fogMode =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "FOG_MODE", new Integer (2048));
fogMode.addDefineShaderFile (this.shaders[19]);
this.uniforms[28] = fogMode;
} else {
this.uniforms[28] =  new android.opengl.OpenGLES10.Uniform (new Integer (2048));
}this.uniforms[28].setFather (fogEnabled);
var fogHint = null;
if (true) {
fogHint =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "FOG_HINT", new Integer (4353));
fogHint.addDefineShaderFile (this.shaders[10]);
this.uniforms[29] = fogHint;
} else {
this.uniforms[29] =  new android.opengl.OpenGLES10.Uniform (new Integer (4353));
}this.uniforms[29].addAdditionalRequiredShaderFile (4353, this.shaders[9]);
this.uniforms[29].addAdditionalRequiredShaderFile (4354, this.shaders[19]);
this.uniforms[29].setFather (fogEnabled);
var lightingHint = null;
if (true) {
lightingHint =  new android.opengl.OpenGLES10.UniformState (this.shaders[0], "LIGHTING_HINT", new Integer (4353));
lightingHint.addDefineShaderFile (this.shaders[10]);
this.uniforms[79] = lightingHint;
} else {
this.uniforms[79] =  new android.opengl.OpenGLES10.Uniform (new Integer (4353));
}this.uniforms[79].addAdditionalRequiredShaderFile (4353, this.shaders[1]);
this.uniforms[79].addAdditionalRequiredShaderFile (4353, this.shaders[2]);
this.uniforms[79].addAdditionalRequiredShaderFile (4354, this.shaders[11]);
this.uniforms[79].addAdditionalRequiredShaderFile (4354, this.shaders[3]);
this.uniforms[79].addAdditionalRequiredShaderFile (4354, this.shaders[12]);
this.uniforms[79].setFather (lightingEnabled);
if (true) {
this.uniforms[30] =  new android.opengl.OpenGLES10.UniformState (this.shaders[13], "ALPHA_FUNC", new Integer (519));
} else {
this.uniforms[30] =  new android.opengl.OpenGLES10.Uniform (new Integer (519));
}this.uniforms[30].setFather (alphaTestEnabled);
if (true) {
this.uniforms[31] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_FORMAT", new Integer (6408));
} else {
this.uniforms[31] =  new android.opengl.OpenGLES10.Uniform (new Integer (6408));
}this.uniforms[31].setFather (texture0Enabled);
if (true) {
this.uniforms[32] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_FORMAT", new Integer (6408));
} else {
this.uniforms[32] =  new android.opengl.OpenGLES10.Uniform (new Integer (6408));
}this.uniforms[32].setFather (texture1Enabled);
if (true) {
this.uniforms[33] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_FORMAT", new Integer (6408));
} else {
this.uniforms[33] =  new android.opengl.OpenGLES10.Uniform (new Integer (6408));
}this.uniforms[33].setFather (texture2Enabled);
if (true) {
this.uniforms[34] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_MODE", new Integer (8448));
} else {
this.uniforms[34] =  new android.opengl.OpenGLES10.Uniform (new Integer (8448));
}this.uniforms[34].setFather (texture0Enabled);
if (true) {
this.uniforms[35] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_MODE", new Integer (8448));
} else {
this.uniforms[35] =  new android.opengl.OpenGLES10.Uniform (new Integer (8448));
}this.uniforms[35].setFather (texture1Enabled);
if (true) {
this.uniforms[36] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_MODE", new Integer (8448));
} else {
this.uniforms[36] =  new android.opengl.OpenGLES10.Uniform (new Integer (8448));
}this.uniforms[36].setFather (texture2Enabled);
if (true) {
this.uniforms[37] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_COMBINE_RGB", new Integer (8448));
} else {
this.uniforms[37] =  new android.opengl.OpenGLES10.Uniform (new Integer (8448));
}this.uniforms[37].setFather (texture0Enabled);
if (true) {
this.uniforms[38] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_COMBINE_RGB", new Integer (8448));
} else {
this.uniforms[38] =  new android.opengl.OpenGLES10.Uniform (new Integer (8448));
}this.uniforms[38].setFather (texture1Enabled);
if (true) {
this.uniforms[39] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_COMBINE_RGB", new Integer (8448));
} else {
this.uniforms[39] =  new android.opengl.OpenGLES10.Uniform (new Integer (8448));
}this.uniforms[39].setFather (texture2Enabled);
if (true) {
this.uniforms[40] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_COMBINE_ALPHA", new Integer (8448));
} else {
this.uniforms[40] =  new android.opengl.OpenGLES10.Uniform (new Integer (8448));
}this.uniforms[40].setFather (texture0Enabled);
if (true) {
this.uniforms[41] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_COMBINE_ALPHA", new Integer (8448));
} else {
this.uniforms[41] =  new android.opengl.OpenGLES10.Uniform (new Integer (8448));
}this.uniforms[41].setFather (texture1Enabled);
if (true) {
this.uniforms[42] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_COMBINE_ALPHA", new Integer (8448));
} else {
this.uniforms[42] =  new android.opengl.OpenGLES10.Uniform (new Integer (8448));
}this.uniforms[42].setFather (texture2Enabled);
if (true) {
this.uniforms[43] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_SRC0_RGB", new Integer (0));
} else {
this.uniforms[43] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[43].setFather (texture0Enabled);
if (true) {
this.uniforms[44] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_SRC1_RGB", new Integer (34168));
} else {
this.uniforms[44] =  new android.opengl.OpenGLES10.Uniform (new Integer (34168));
}this.uniforms[44].setFather (texture0Enabled);
if (true) {
this.uniforms[45] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_SRC2_RGB", new Integer (34166));
} else {
this.uniforms[45] =  new android.opengl.OpenGLES10.Uniform (new Integer (34166));
}this.uniforms[45].setFather (texture0Enabled);
if (true) {
this.uniforms[46] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_SRC0_RGB", new Integer (1));
} else {
this.uniforms[46] =  new android.opengl.OpenGLES10.Uniform (new Integer (1));
}this.uniforms[46].setFather (texture1Enabled);
if (true) {
this.uniforms[47] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_SRC1_RGB", new Integer (34168));
} else {
this.uniforms[47] =  new android.opengl.OpenGLES10.Uniform (new Integer (34168));
}this.uniforms[47].setFather (texture1Enabled);
if (true) {
this.uniforms[48] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_SRC2_RGB", new Integer (34166));
} else {
this.uniforms[48] =  new android.opengl.OpenGLES10.Uniform (new Integer (34166));
}this.uniforms[48].setFather (texture1Enabled);
if (true) {
this.uniforms[49] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_SRC0_RGB", new Integer (2));
} else {
this.uniforms[49] =  new android.opengl.OpenGLES10.Uniform (new Integer (2));
}this.uniforms[49].setFather (texture2Enabled);
if (true) {
this.uniforms[50] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_SRC1_RGB", new Integer (34168));
} else {
this.uniforms[50] =  new android.opengl.OpenGLES10.Uniform (new Integer (34168));
}this.uniforms[50].setFather (texture2Enabled);
if (true) {
this.uniforms[51] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_SRC2_RGB", new Integer (34166));
} else {
this.uniforms[51] =  new android.opengl.OpenGLES10.Uniform (new Integer (34166));
}this.uniforms[51].setFather (texture2Enabled);
if (true) {
this.uniforms[52] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_OPERAND0_RGB", new Integer (768));
} else {
this.uniforms[52] =  new android.opengl.OpenGLES10.Uniform (new Integer (768));
}this.uniforms[52].setFather (texture0Enabled);
if (true) {
this.uniforms[53] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_OPERAND1_RGB", new Integer (768));
} else {
this.uniforms[53] =  new android.opengl.OpenGLES10.Uniform (new Integer (768));
}this.uniforms[53].setFather (texture0Enabled);
if (true) {
this.uniforms[54] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_OPERAND2_RGB", new Integer (768));
} else {
this.uniforms[54] =  new android.opengl.OpenGLES10.Uniform (new Integer (768));
}this.uniforms[54].setFather (texture0Enabled);
if (true) {
this.uniforms[55] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_OPERAND0_RGB", new Integer (768));
} else {
this.uniforms[55] =  new android.opengl.OpenGLES10.Uniform (new Integer (768));
}this.uniforms[55].setFather (texture1Enabled);
if (true) {
this.uniforms[56] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_OPERAND1_RGB", new Integer (768));
} else {
this.uniforms[56] =  new android.opengl.OpenGLES10.Uniform (new Integer (768));
}this.uniforms[56].setFather (texture1Enabled);
if (true) {
this.uniforms[57] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_OPERAND2_RGB", new Integer (768));
} else {
this.uniforms[57] =  new android.opengl.OpenGLES10.Uniform (new Integer (768));
}this.uniforms[57].setFather (texture1Enabled);
if (true) {
this.uniforms[58] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_OPERAND0_RGB", new Integer (768));
} else {
this.uniforms[58] =  new android.opengl.OpenGLES10.Uniform (new Integer (768));
}this.uniforms[58].setFather (texture2Enabled);
if (true) {
this.uniforms[59] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_OPERAND1_RGB", new Integer (768));
} else {
this.uniforms[59] =  new android.opengl.OpenGLES10.Uniform (new Integer (768));
}this.uniforms[59].setFather (texture2Enabled);
if (true) {
this.uniforms[60] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_OPERAND2_RGB", new Integer (768));
} else {
this.uniforms[60] =  new android.opengl.OpenGLES10.Uniform (new Integer (768));
}this.uniforms[60].setFather (texture2Enabled);
if (true) {
this.uniforms[61] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_SRC0_ALPHA", new Integer (0));
} else {
this.uniforms[61] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[61].setFather (texture0Enabled);
if (true) {
this.uniforms[62] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_SRC1_ALPHA", new Integer (0));
} else {
this.uniforms[62] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[62].setFather (texture0Enabled);
if (true) {
this.uniforms[63] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_SRC2_ALPHA", new Integer (0));
} else {
this.uniforms[63] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[63].setFather (texture0Enabled);
if (true) {
this.uniforms[64] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_SRC0_ALPHA", new Integer (0));
} else {
this.uniforms[64] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[64].setFather (texture1Enabled);
if (true) {
this.uniforms[65] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_SRC1_ALPHA", new Integer (0));
} else {
this.uniforms[65] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[65].setFather (texture1Enabled);
if (true) {
this.uniforms[66] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_SRC2_ALPHA", new Integer (0));
} else {
this.uniforms[66] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[66].setFather (texture1Enabled);
if (true) {
this.uniforms[67] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_SRC0_ALPHA", new Integer (0));
} else {
this.uniforms[67] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[67].setFather (texture2Enabled);
if (true) {
this.uniforms[68] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_SRC1_ALPHA", new Integer (0));
} else {
this.uniforms[68] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[68].setFather (texture2Enabled);
if (true) {
this.uniforms[69] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_SRC2_ALPHA", new Integer (0));
} else {
this.uniforms[69] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
}this.uniforms[69].setFather (texture2Enabled);
if (true) {
this.uniforms[70] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_OPERAND0_ALPHA", new Integer (770));
} else {
this.uniforms[70] =  new android.opengl.OpenGLES10.Uniform (new Integer (770));
}this.uniforms[70].setFather (texture0Enabled);
if (true) {
this.uniforms[71] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_OPERAND1_ALPHA", new Integer (770));
} else {
this.uniforms[71] =  new android.opengl.OpenGLES10.Uniform (new Integer (770));
}this.uniforms[71].setFather (texture0Enabled);
if (true) {
this.uniforms[72] =  new android.opengl.OpenGLES10.UniformState (this.shaders[16], "TEXTURE0_ENV_OPERAND2_ALPHA", new Integer (770));
} else {
this.uniforms[72] =  new android.opengl.OpenGLES10.Uniform (new Integer (770));
}this.uniforms[72].setFather (texture0Enabled);
if (true) {
this.uniforms[73] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_OPERAND0_ALPHA", new Integer (770));
} else {
this.uniforms[73] =  new android.opengl.OpenGLES10.Uniform (new Integer (770));
}this.uniforms[73].setFather (texture1Enabled);
if (true) {
this.uniforms[74] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_OPERAND1_ALPHA", new Integer (770));
} else {
this.uniforms[74] =  new android.opengl.OpenGLES10.Uniform (new Integer (770));
}this.uniforms[74].setFather (texture1Enabled);
if (true) {
this.uniforms[75] =  new android.opengl.OpenGLES10.UniformState (this.shaders[17], "TEXTURE1_ENV_OPERAND2_ALPHA", new Integer (770));
} else {
this.uniforms[75] =  new android.opengl.OpenGLES10.Uniform (new Integer (770));
}this.uniforms[75].setFather (texture1Enabled);
if (true) {
this.uniforms[76] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_OPERAND0_ALPHA", new Integer (770));
} else {
this.uniforms[76] =  new android.opengl.OpenGLES10.Uniform (new Integer (770));
}this.uniforms[76].setFather (texture2Enabled);
if (true) {
this.uniforms[77] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_OPERAND1_ALPHA", new Integer (770));
} else {
this.uniforms[77] =  new android.opengl.OpenGLES10.Uniform (new Integer (770));
}this.uniforms[77].setFather (texture2Enabled);
if (true) {
this.uniforms[78] =  new android.opengl.OpenGLES10.UniformState (this.shaders[18], "TEXTURE2_ENV_OPERAND2_ALPHA", new Integer (770));
} else {
this.uniforms[78] =  new android.opengl.OpenGLES10.Uniform (new Integer (770));
}this.uniforms[78].setFather (texture2Enabled);
this.uniforms[102] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 1.0);
this.uniforms[103] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 1.0);
this.uniforms[104] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 1.0);
this.uniforms[105] =  new android.opengl.OpenGLES10.Uniform4f (1.0, 1.0, 1.0, 1.0);
this.uniforms[106] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[107] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[108] =  new android.opengl.OpenGLES10.Uniform4f (1.0, 1.0, 1.0, 1.0);
this.uniforms[109] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[110] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[111] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 1.0, 0.0);
this.uniforms[112] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 1.0, 0.0);
this.uniforms[113] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 1.0, 0.0);
this.uniforms[114] =  new android.opengl.OpenGLES10.Uniform3f (0.0, 0.0, -1.0);
this.uniforms[115] =  new android.opengl.OpenGLES10.Uniform3f (0.0, 0.0, -1.0);
this.uniforms[116] =  new android.opengl.OpenGLES10.Uniform3f (0.0, 0.0, -1.0);
this.uniforms[117] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[118] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[119] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[120] =  new android.opengl.OpenGLES10.Uniform (new Float (-1.0));
this.uniforms[121] =  new android.opengl.OpenGLES10.Uniform (new Float (-1.0));
this.uniforms[122] =  new android.opengl.OpenGLES10.Uniform (new Float (-1.0));
this.uniforms[123] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[124] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[125] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[126] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[127] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[128] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[129] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[130] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[131] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[132] =  new android.opengl.OpenGLES10.Uniform4f (0.2, 0.2, 0.2, 1.0);
this.uniforms[133] =  new android.opengl.OpenGLES10.Uniform4f (0.8, 0.8, 0.8, 1.0);
this.uniforms[134] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 1.0);
this.uniforms[135] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 1.0);
this.uniforms[136] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[81] =  new android.opengl.OpenGLES10.Uniform ();
this.uniforms[80] =  new android.opengl.OpenGLES10.Uniform ();
this.uniforms[82] =  new android.opengl.OpenGLES10.Uniform ();
this.uniforms[101] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[137] =  new android.opengl.OpenGLES10.Uniform3f (0.0, 0.0, 0.0);
this.uniforms[138] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[139] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[140] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[148] =  new android.opengl.OpenGLES10.Uniform4f (0.2, 0.2, 0.2, 1.0);
this.uniforms[141] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[142] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[143] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[144] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[145] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[146] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[147] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[89] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[90] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[91] =  new android.opengl.OpenGLES10.Uniform4f (0.0, 0.0, 0.0, 0.0);
this.uniforms[92] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[93] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[94] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[95] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[96] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[97] =  new android.opengl.OpenGLES10.Uniform (new Float (1.0));
this.uniforms[98] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[99] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[100] =  new android.opengl.OpenGLES10.Uniform (new Float (0.0));
this.uniforms[86] =  new android.opengl.OpenGLES10.Uniform (new Integer (0));
this.uniforms[87] =  new android.opengl.OpenGLES10.Uniform (new Integer (1));
this.uniforms[88] =  new android.opengl.OpenGLES10.Uniform (new Integer (2));
this.uniforms[83] =  new android.opengl.OpenGLES10.Uniform ();
this.uniforms[84] =  new android.opengl.OpenGLES10.Uniform ();
this.uniforms[85] =  new android.opengl.OpenGLES10.Uniform ();
}, "android.opengl.OpenGLES10.OpenGLES10Context");
Clazz.defineMethod (c$, "setCurrentProgram", 
function () {
if (false) {
if (!this.setCurrentProgram_uberShaderCompiled) {
var vertexShaderSources =  new java.util.ArrayList ();
for (var i = 0; i <= 9; i++) {
vertexShaderSources.add ( new android.opengl.OpenGLES10.ShaderSource (this.shaders[i], ""));
}
var fragmentShaderSources =  new java.util.ArrayList ();
for (var i = 10; i <= 19; i++) {
fragmentShaderSources.add ( new android.opengl.OpenGLES10.ShaderSource (this.shaders[i], ""));
}
var vertexShader =  new android.opengl.OpenGLES10.Shader (35633, vertexShaderSources);
var fragmentShader =  new android.opengl.OpenGLES10.Shader (35632, fragmentShaderSources);
this.currentStateShaderProgram =  new android.opengl.OpenGLES10.StateShaderProgram (this.getCopyOfCurrentState (),  new android.opengl.OpenGLES10.ShaderProgram ("UberShader", vertexShader, fragmentShader));
this.stateShaderPrograms.add (this.currentStateShaderProgram);
this.currentStateShaderProgram.shaderProgram.use ();
this.setActiveUniformLocations (this.currentStateShaderProgram.shaderProgram.getActiveUniforms ());
this.setActiveAttributeLocations (this.currentStateShaderProgram.shaderProgram.getActiveAttributes ());
this.setCurrentProgram_uberShaderCompiled = true;
}this.uploadUniforms ();
this.uploadAttributes ();
return ;
}var oldStateShaderProgram = this.currentStateShaderProgram;
var currentBit = 0;
for (var i = 0; i <= 27; i++) {
if (currentBit % 32 == 0) {
this.currentState[Math.floor (currentBit / 32)] = 0;
}var value = (((this.uniforms[i])).getValue ()).booleanValue ();
this.currentState[Math.floor (currentBit / 32)] |= (value ? 1 : 0) << (currentBit % 32);
currentBit++;
}
var index = this.stateSizeBool;
for (var i = 28; i <= 79; i++) {
var val = (((this.uniforms[i])).getValue ()).intValue ();
this.currentState[index] = val;
index++;
}
var stateIndex = -1;
for (var i = 0; i < this.stateShaderPrograms.size (); i++) {
var stateFound = true;
for (var j = 0; j < this.stateSize; j++) {
if (this.currentState[j] != this.stateShaderPrograms.get (i).state[j]) {
stateFound = false;
break;
}}
if (stateFound) {
stateIndex = i;
break;
}}
if (stateIndex >= 0) {
this.currentStateShaderProgram = this.stateShaderPrograms.get (stateIndex);
} else {
android.util.Log.d ("OpenGLESState", "State binary presentation:");
android.util.Log.d ("OpenGLESState", "Bool states: ");
for (var i = 0; i < this.stateSizeBool; i++) {
android.util.Log.d ("OpenGLESState", Integer.toBinaryString (this.currentState[i]));
}
android.util.Log.d ("OpenGLESState", "Int states: ");
for (var i = this.stateSizeBool; i < this.stateSize; i++) {
android.util.Log.d ("OpenGLESState", Integer.toHexString (this.currentState[i]));
}
var vertexShaderSources =  new java.util.ArrayList ();
var fragmentShaderSources =  new java.util.ArrayList ();
this.addRequiredShaderSources (vertexShaderSources, fragmentShaderSources);
this.addDefinesToShaderSources (vertexShaderSources, fragmentShaderSources);
if (true) {
android.util.Log.d ("OpenGLESState", "Using shader files:");
for (var i = 0; i < vertexShaderSources.size (); i++) {
android.util.Log.d ("OpenGLESState", vertexShaderSources.get (i).getFile ().getName ());
}
for (var i = 0; i < fragmentShaderSources.size (); i++) {
android.util.Log.d ("OpenGLESState", fragmentShaderSources.get (i).getFile ().getName ());
}
}var vertexShader =  new android.opengl.OpenGLES10.Shader (35633, vertexShaderSources);
var fragmentShader =  new android.opengl.OpenGLES10.Shader (35632, fragmentShaderSources);
this.currentStateShaderProgram =  new android.opengl.OpenGLES10.StateShaderProgram (this.getCopyOfCurrentState (),  new android.opengl.OpenGLES10.ShaderProgram ("Optimized Shader " + (this.stateShaderPrograms.size () + 1), vertexShader, fragmentShader));
this.stateShaderPrograms.add (this.currentStateShaderProgram);
}if (this.currentStateShaderProgram !== oldStateShaderProgram) {
this.currentStateShaderProgram.shaderProgram.use ();
this.setActiveUniformLocations (this.currentStateShaderProgram.shaderProgram.getActiveUniforms ());
this.setActiveAttributeLocations (this.currentStateShaderProgram.shaderProgram.getActiveAttributes ());
}this.uploadAttributes ();
this.uploadUniforms ();
});
Clazz.defineMethod (c$, "setActiveTexture", 
function (a) {
this.activeTexture = a;
}, "~N");
Clazz.defineMethod (c$, "getActiveTexture", 
function () {
return this.activeTexture;
});
Clazz.defineMethod (c$, "setClientActiveTexture", 
function (a) {
this.clientActiveTexture = a;
}, "~N");
Clazz.defineMethod (c$, "getClientActiveTexture", 
function () {
return this.clientActiveTexture;
});
Clazz.defineMethod (c$, "setBoundTextureFormat", 
function (format) {
this.boundTextureFormats.put (new Integer (this.boundTextures[this.activeTexture]), new Integer (format));
}, "~N");
Clazz.defineMethod (c$, "setBoundTexture", 
function (i) {
this.boundTextures[this.activeTexture] = i;
}, "~N");
Clazz.defineMethod (c$, "setPosition", 
function (size, type, stride, pointer) {
this.attributes[0].setValues (size, type, stride, pointer);
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "setNormal", 
function (size, type, stride, pointer) {
this.attributes[1].setValues (size, type, stride, pointer);
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "setColor", 
function (size, type, stride, pointer) {
this.attributes[2].setValues (size, type, stride, pointer);
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "setTexCoord", 
function (size, type, stride, pointer) {
this.attributes[3 + this.clientActiveTexture].setValues (size, type, stride, pointer);
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "setPosition", 
function (enabled) {
((this.uniforms[0])).setValue (new Boolean (enabled));
this.attributes[0].setEnabled (enabled);
}, "~B");
Clazz.defineMethod (c$, "setNormal", 
function (enabled) {
((this.uniforms[1])).setValue (new Boolean (enabled));
this.attributes[1].setEnabled (enabled);
}, "~B");
Clazz.defineMethod (c$, "isNormal", 
function () {
return ((this.uniforms[1])).getValue ();
});
Clazz.defineMethod (c$, "setColor", 
function (enabled) {
((this.uniforms[2])).setValue (new Boolean (enabled));
this.attributes[2].setEnabled (enabled);
}, "~B");
Clazz.defineMethod (c$, "setTexCoord", 
function (enabled) {
((this.uniforms[3 + this.clientActiveTexture])).setValue (new Boolean (enabled));
this.attributes[3 + this.clientActiveTexture].setEnabled (enabled);
}, "~B");
Clazz.defineMethod (c$, "isTexCoord", 
function (index) {
return ((this.uniforms[3 + index])).getValue ();
}, "~N");
Clazz.defineMethod (c$, "setTexture", 
function (enabled) {
((this.uniforms[12 + this.activeTexture])).setValue (new Boolean (enabled));
}, "~B");
Clazz.defineMethod (c$, "setTextureFormat", 
function () {
((this.uniforms[31 + this.activeTexture])).setValue (this.boundTextureFormats.get (new Integer (this.boundTextures[this.activeTexture])));
});
Clazz.defineMethod (c$, "setTextureEnvMode", 
function (val) {
((this.uniforms[34 + this.activeTexture])).setValue (new Integer (val));
}, "~N");
Clazz.defineMethod (c$, "setTextureEnvColor", 
function (vec) {
((this.uniforms[89 + this.activeTexture])).setValue (vec);
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setTextureEnvCombineRGB", 
function (val) {
((this.uniforms[37 + this.activeTexture])).setValue (new Integer (val));
}, "~N");
Clazz.defineMethod (c$, "setTextureEnvCombineAlpha", 
function (val) {
((this.uniforms[40 + this.activeTexture])).setValue (new Integer (val));
}, "~N");
Clazz.defineMethod (c$, "setTextureEnvSrcRGB", 
function (index, val) {
((this.uniforms[43 + index + 3 * this.activeTexture])).setValue (new Integer (val));
}, "~N,~N");
Clazz.defineMethod (c$, "setTextureEnvOperandRGB", 
function (index, val) {
((this.uniforms[52 + index + 3 * this.activeTexture])).setValue (new Integer (val));
}, "~N,~N");
Clazz.defineMethod (c$, "setTextureEnvSrcAlpha", 
function (index, val) {
((this.uniforms[61 + index + 3 * this.activeTexture])).setValue (new Integer (val));
}, "~N,~N");
Clazz.defineMethod (c$, "setTextureEnvOperandAlpha", 
function (index, val) {
((this.uniforms[70 + index + 3 * this.activeTexture])).setValue (new Integer (val));
}, "~N,~N");
Clazz.defineMethod (c$, "setTextureEnvRGBScale", 
function (val) {
((this.uniforms[92 + this.activeTexture])).setValue (new Float (val));
}, "~N");
Clazz.defineMethod (c$, "setTextureEnvAlphaScale", 
function (val) {
((this.uniforms[95 + this.activeTexture])).setValue (new Float (val));
}, "~N");
Clazz.defineMethod (c$, "setTextureEnvBlurAmount", 
function (val) {
((this.uniforms[98 + this.activeTexture])).setValue (new Float (val));
}, "~N");
Clazz.defineMethod (c$, "setLightModelLocalViewer", 
function (enabled) {
((this.uniforms[7])).setValue (new Boolean (enabled));
}, "~B");
Clazz.defineMethod (c$, "setLightModelTwoSide", 
function (enabled) {
((this.uniforms[8])).setValue (new Boolean (enabled));
}, "~B");
Clazz.defineMethod (c$, "setLighting", 
function (enabled) {
((this.uniforms[6])).setValue (new Boolean (enabled));
}, "~B");
Clazz.defineMethod (c$, "setLightingHint", 
function (val) {
((this.uniforms[79])).setValue (new Integer (val));
}, "~N");
Clazz.defineMethod (c$, "setLight", 
function (light, enabled) {
((this.uniforms[9 + light])).setValue (new Boolean (enabled));
}, "~N,~B");
Clazz.defineMethod (c$, "setLightAmbient", 
function (light, vec) {
((this.uniforms[102 + light])).setValue (vec);
}, "~N,android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setLightDiffuse", 
function (light, vec) {
((this.uniforms[105 + light])).setValue (vec);
}, "~N,android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setLightSpecular", 
function (light, vec) {
((this.uniforms[108 + light])).setValue (vec);
}, "~N,android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setLightPosition", 
function (light, vec) {
((this.uniforms[111 + light])).setValue (vec);
}, "~N,android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setLightSpotDirection", 
function (light, vec) {
((this.uniforms[114 + light])).setValue ( new android.opengl.OpenGLES10.Vector3f (vec));
}, "~N,android.opengl.OpenGLES10.Vector3f");
Clazz.defineMethod (c$, "setLightSpotExponent", 
function (light, val) {
((this.uniforms[117 + light])).setValue (new Float (val));
}, "~N,~N");
Clazz.defineMethod (c$, "setLightSpotCutoffAngleCos", 
function (light, val) {
((this.uniforms[120 + light])).setValue (new Float (val));
}, "~N,~N");
Clazz.defineMethod (c$, "setLightConstantAttenuation", 
function (light, val) {
((this.uniforms[123 + light])).setValue (new Float (val));
}, "~N,~N");
Clazz.defineMethod (c$, "setLightLinearAttenuation", 
function (light, val) {
((this.uniforms[126 + light])).setValue (new Float (val));
}, "~N,~N");
Clazz.defineMethod (c$, "setLightQuadraticAttenuation", 
function (light, val) {
((this.uniforms[129 + light])).setValue (new Float (val));
}, "~N,~N");
Clazz.defineMethod (c$, "setMaterialAmbient", 
function (vec) {
((this.uniforms[132])).setValue (vec);
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setMaterialDiffuse", 
function (vec) {
((this.uniforms[133])).setValue (vec);
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setMaterialSpecular", 
function (vec) {
((this.uniforms[134])).setValue (vec);
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setMaterialEmission", 
function (vec) {
((this.uniforms[135])).setValue (vec);
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setMaterialShininess", 
function (val) {
((this.uniforms[136])).setValue (new Float (val));
}, "~N");
Clazz.defineMethod (c$, "setModelViewMatrix", 
function (mat) {
((this.uniforms[81])).setValue ( new android.opengl.OpenGLES10.Matrix4x4f (mat));
}, "android.opengl.OpenGLES10.Matrix4x4f");
Clazz.defineMethod (c$, "setModelViewProjectionMatrix", 
function (mat) {
((this.uniforms[80])).setValue ( new android.opengl.OpenGLES10.Matrix4x4f (mat));
}, "android.opengl.OpenGLES10.Matrix4x4f");
Clazz.defineMethod (c$, "setTransposeAdjointModelViewMatrix", 
function (mat) {
((this.uniforms[82])).setValue ( new android.opengl.OpenGLES10.Matrix3x3f (mat));
}, "android.opengl.OpenGLES10.Matrix3x3f");
Clazz.defineMethod (c$, "setNormalize", 
function (enabled) {
((this.uniforms[27])).setValue (new Boolean (enabled));
}, "~B");
Clazz.defineMethod (c$, "setRescaleNormal", 
function (enabled) {
((this.uniforms[26])).setValue (new Boolean (enabled));
}, "~B");
Clazz.defineMethod (c$, "isRescaleNormal", 
function () {
return ((this.uniforms[26])).getValue ();
});
Clazz.defineMethod (c$, "setRescaleNormalFactor", 
function (val) {
((this.uniforms[101])).setValue (new Float (val));
}, "~N");
Clazz.defineMethod (c$, "setGlobalAmbientColor", 
function (vec) {
((this.uniforms[148])).setValue (vec);
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "setFog", 
function (enabled) {
((this.uniforms[18])).setValue (new Boolean (enabled));
}, "~B");
Clazz.defineMethod (c$, "setFogColor", 
function (vec) {
((this.uniforms[137])).setValue (vec);
}, "android.opengl.OpenGLES10.Vector3f");
Clazz.defineMethod (c$, "setFogMode", 
function (val) {
((this.uniforms[28])).setValue (new Integer (val));
}, "~N");
Clazz.defineMethod (c$, "setFogDensity", 
function (val) {
((this.uniforms[138])).setValue (new Float (val));
}, "~N");
Clazz.defineMethod (c$, "setFogStart", 
function (val) {
((this.uniforms[139])).setValue (new Float (val));
}, "~N");
Clazz.defineMethod (c$, "setFogEnd", 
function (val) {
((this.uniforms[140])).setValue (new Float (val));
}, "~N");
Clazz.defineMethod (c$, "setFogHint", 
function (val) {
((this.uniforms[29])).setValue (new Integer (val));
}, "~N");
Clazz.defineMethod (c$, "setAlphaTest", 
function (enabled) {
((this.uniforms[19])).setValue (new Boolean (enabled));
}, "~B");
Clazz.defineMethod (c$, "setAlphaFunc", 
function (val) {
((this.uniforms[30])).setValue (new Integer (val));
}, "~N");
Clazz.defineMethod (c$, "setAlphaFuncValue", 
function (val) {
((this.uniforms[141])).setValue (new Float (val));
}, "~N");
Clazz.defineMethod (c$, "setClipPlane", 
function (clipPlaneIndex, enabled) {
((this.uniforms[20 + clipPlaneIndex])).setValue (new Boolean (enabled));
}, "~N,~B");
Clazz.defineMethod (c$, "setClipPlane", 
function (clipPlaneIndex, vec) {
((this.uniforms[142 + clipPlaneIndex])).setValue (vec);
}, "~N,android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "getClipPlane", 
function (clipPlaneIndex, eqn) {
var vec = ((this.uniforms[142 + clipPlaneIndex])).getValue ();
eqn[0] = vec.getItem (0);
eqn[1] = vec.getItem (1);
eqn[2] = vec.getItem (2);
eqn[3] = vec.getItem (3);
}, "~N,~A");
Clazz.defineMethod (c$, "setTextureMatrix", 
function (index, mat) {
((this.uniforms[83 + index])).setValue (mat);
}, "~N,android.opengl.OpenGLES10.Matrix4x4f");
Clazz.defineMethod (c$, "setTextureMatrix", 
function (index, enabled) {
((this.uniforms[15 + index])).setValue (new Boolean (enabled));
}, "~N,~B");
Clazz.defineMethod (c$, "getCachedShaderAmount", 
function () {
return this.stateShaderPrograms.size ();
});
Clazz.defineMethod (c$, "setActiveUniformLocations", 
($fz = function (activeUniforms) {
for (var i = 0; i < activeUniforms.size (); i++) {
var activeUniform = activeUniforms.get (i);
var index = activeUniform.getId ();
this.uniforms[index].setLocation (activeUniform.getLocation ());
}
}, $fz.isPrivate = true, $fz), "java.util.ArrayList");
Clazz.defineMethod (c$, "setActiveAttributeLocations", 
($fz = function (activeAttributes) {
for (var i = 0; i < activeAttributes.size (); i++) {
var activeAttribute = activeAttributes.get (i);
var index = activeAttribute.getId ();
this.attributes[index].setLocation (activeAttribute.getLocation ());
}
}, $fz.isPrivate = true, $fz), "java.util.ArrayList");
Clazz.defineMethod (c$, "uploadAttributes", 
($fz = function () {
var activeAttributes = this.currentStateShaderProgram.shaderProgram.getActiveAttributes ();
for (var i = 0; i < activeAttributes.size (); i++) {
var activeAttribute = activeAttributes.get (i);
this.attributes[activeAttribute.getId ()].upload (this.currentStateShaderProgram.shaderProgram);
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "uploadUniforms", 
($fz = function () {
var activeUniforms = this.currentStateShaderProgram.shaderProgram.getActiveUniforms ();
for (var i = 0; i < activeUniforms.size (); i++) {
var activeUniform = activeUniforms.get (i);
this.uniforms[activeUniform.getId ()].upload (this.currentStateShaderProgram.shaderProgram);
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "addRequiredShaderSources", 
($fz = function (vertexShaderSources, fragmentShaderSources) {
vertexShaderSources.add ( new android.opengl.OpenGLES10.ShaderSource (this.shaders[0]));
fragmentShaderSources.add ( new android.opengl.OpenGLES10.ShaderSource (this.shaders[10]));
for (var i = 0; i < 149; i++) {
var additionalRequiredShaderFiles = this.uniforms[i].getAdditionalRequiredShaderFiles ();
for (var j = 0; j < additionalRequiredShaderFiles.size (); j++) {
var shaderFileFound = false;
if (additionalRequiredShaderFiles.get (j).getType () == 35633) {
for (var k = 0; k < vertexShaderSources.size (); k++) {
if (vertexShaderSources.get (k).getFile () === additionalRequiredShaderFiles.get (j)) {
shaderFileFound = true;
break;
}}
if (!shaderFileFound) {
vertexShaderSources.add ( new android.opengl.OpenGLES10.ShaderSource (additionalRequiredShaderFiles.get (j)));
}} else {
for (var k = 0; k < fragmentShaderSources.size (); k++) {
if (fragmentShaderSources.get (k).getFile () === additionalRequiredShaderFiles.get (j)) {
shaderFileFound = true;
break;
}}
if (!shaderFileFound) {
fragmentShaderSources.add ( new android.opengl.OpenGLES10.ShaderSource (additionalRequiredShaderFiles.get (j)));
}}}
}
}, $fz.isPrivate = true, $fz), "java.util.ArrayList,java.util.ArrayList");
Clazz.defineMethod (c$, "addDefinesToShaderSources", 
($fz = function (vertexShaderSources, fragmentShaderSources) {
for (var i = 0; i <= 27; i++) {
var uniformState = (this.uniforms[i]);
var defineShaderFiles = uniformState.getDefineShaderFiles ();
var define = uniformState.getDefine ();
this.addDefineToShaderSources (define, defineShaderFiles, vertexShaderSources, fragmentShaderSources);
}
for (var i = 28; i <= 79; i++) {
var uniformState = (this.uniforms[i]);
var defineShaderFiles = uniformState.getDefineShaderFiles ();
var define = uniformState.getDefine ();
this.addDefineToShaderSources (define, defineShaderFiles, vertexShaderSources, fragmentShaderSources);
}
var light = Clazz.instanceOf (this.uniforms[6], android.opengl.OpenGLES10.UniformState) ? true : false;
var light0 = Clazz.instanceOf (this.uniforms[9], android.opengl.OpenGLES10.UniformState) ? true : false;
var light1 = Clazz.instanceOf (this.uniforms[10], android.opengl.OpenGLES10.UniformState) ? true : false;
var light2 = Clazz.instanceOf (this.uniforms[11], android.opengl.OpenGLES10.UniformState) ? true : false;
if (light && light0 && light1 && light2) {
var nonDirectionalLightEnabled = false;
if ((((this.uniforms[6])).getValue ()).booleanValue ()) {
for (var i = 0; i < 3; i++) {
if ((((this.uniforms[9 + i])).getValue ()).booleanValue () && ((this.uniforms[111 + i])).getValue ().v[3] != 0.0) {
nonDirectionalLightEnabled = true;
break;
}}
}var nonDirectionalLightEnabledString = "#define NON_DIRECTIONAL_LIGHT_ENABLED ";
nonDirectionalLightEnabledString += nonDirectionalLightEnabled ? "1" : "0";
nonDirectionalLightEnabledString += "\n";
vertexShaderSources.get (0).appendAdditionalSource (nonDirectionalLightEnabledString);
}}, $fz.isPrivate = true, $fz), "java.util.ArrayList,java.util.ArrayList");
Clazz.defineMethod (c$, "addDefineToShaderSources", 
($fz = function (define, shaderFiles, vertexShaderSources, fragmentShaderSources) {
for (var i = 0; i < shaderFiles.size (); i++) {
if (shaderFiles.get (i).getType () == 35633) {
for (var j = 0; j < vertexShaderSources.size (); j++) {
if (shaderFiles.get (i) === vertexShaderSources.get (j).getFile ()) {
vertexShaderSources.get (j).appendAdditionalSource (define);
}}
} else {
for (var j = 0; j < fragmentShaderSources.size (); j++) {
if (shaderFiles.get (i) === fragmentShaderSources.get (j).getFile ()) {
fragmentShaderSources.get (j).appendAdditionalSource (define);
}}
}}
}, $fz.isPrivate = true, $fz), "~S,java.util.ArrayList,java.util.ArrayList,java.util.ArrayList");
Clazz.defineMethod (c$, "getCopyOfCurrentState", 
($fz = function () {
var state =  Clazz.newArray (this.stateSize, 0);
for (var i = 0; i < this.stateSize; i++) {
state[i] = this.currentState[i];
}
return state;
}, $fz.isPrivate = true, $fz));
c$.$OpenGLESState$ShaderId$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10.OpenGLESState, "ShaderId");
Clazz.defineStatics (c$,
"MAIN_VERTEX_SHADER", 0,
"LIGHTING_VERTEX_SHADER", 1,
"LIGHTING_PER_VERTEX_VERTEX_SHADER", 2,
"LIGHTING_PER_FRAGMENT_VERTEX_SHADER", 3,
"CLIP_PLANE_VERTEX_SHADER", 4,
"TEXTURE_VERTEX_SHADER", 5,
"TEXTURE0_VERTEX_SHADER", 6,
"TEXTURE1_VERTEX_SHADER", 7,
"TEXTURE2_VERTEX_SHADER", 8,
"FOG_VERTEX_SHADER", 9,
"MAIN_FRAGMENT_SHADER", 10,
"LIGHTING_FRAGMENT_SHADER", 11,
"LIGHTING_PER_FRAGMENT_FRAGMENT_SHADER", 12,
"ALPHA_TEST_FRAGMENT_SHADER", 13,
"CLIP_PLANE_FRAGMENT_SHADER", 14,
"TEXTURE_FRAGMENT_SHADER", 15,
"TEXTURE0_FRAGMENT_SHADER", 16,
"TEXTURE1_FRAGMENT_SHADER", 17,
"TEXTURE2_FRAGMENT_SHADER", 18,
"FOG_FRAGMENT_SHADER", 19,
"FIRST_VERTEX_SHADER", 0,
"LAST_VERTEX_SHADER", 9,
"FIRST_FRAGMENT_SHADER", 10,
"LAST_FRAGMENT_SHADER", 19,
"COUNT", 20);
c$ = Clazz.p0p ();
};
c$.$OpenGLESState$AttributeId$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10.OpenGLESState, "AttributeId");
Clazz.defineStatics (c$,
"POSITION", 0,
"NORMAL", 1,
"COLOR", 2,
"TEXCOORD0", 3,
"TEXCOORD1", 4,
"TEXCOORD2", 5,
"COUNT", 6);
c$ = Clazz.p0p ();
};
c$.$OpenGLESState$UniformId$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10.OpenGLESState, "UniformId");
Clazz.defineStatics (c$,
"POSITION_ENABLED", 0,
"NORMAL_ENABLED", 1,
"COLOR_ENABLED", 2,
"TEXCOORD0_ENABLED", 3,
"TEXCOORD1_ENABLED", 4,
"TEXCOORD2_ENABLED", 5,
"LIGHTING_ENABLED", 6,
"LIGHT_MODEL_LOCAL_VIEWER_ENABLED", 7,
"LIGHT_MODEL_TWO_SIDE_ENABLED", 8,
"LIGHT0_ENABLED", 9,
"LIGHT1_ENABLED", 10,
"LIGHT2_ENABLED", 11,
"TEXTURE0_ENABLED", 12,
"TEXTURE1_ENABLED", 13,
"TEXTURE2_ENABLED", 14,
"TEXTURE0_MATRIX_ENABLED", 15,
"TEXTURE1_MATRIX_ENABLED", 16,
"TEXTURE2_MATRIX_ENABLED", 17,
"FOG_ENABLED", 18,
"ALPHA_TEST_ENABLED", 19,
"CLIP_PLANE0_ENABLED", 20,
"CLIP_PLANE1_ENABLED", 21,
"CLIP_PLANE2_ENABLED", 22,
"CLIP_PLANE3_ENABLED", 23,
"CLIP_PLANE4_ENABLED", 24,
"CLIP_PLANE5_ENABLED", 25,
"RESCALE_NORMAL_ENABLED", 26,
"NORMALIZE_ENABLED", 27,
"FOG_MODE", 28,
"FOG_HINT", 29,
"ALPHA_FUNC", 30,
"TEXTURE0_FORMAT", 31,
"TEXTURE1_FORMAT", 32,
"TEXTURE2_FORMAT", 33,
"TEXTURE0_ENV_MODE", 34,
"TEXTURE1_ENV_MODE", 35,
"TEXTURE2_ENV_MODE", 36,
"TEXTURE0_ENV_COMBINE_RGB", 37,
"TEXTURE1_ENV_COMBINE_RGB", 38,
"TEXTURE2_ENV_COMBINE_RGB", 39,
"TEXTURE0_ENV_COMBINE_ALPHA", 40,
"TEXTURE1_ENV_COMBINE_ALPHA", 41,
"TEXTURE2_ENV_COMBINE_ALPHA", 42,
"TEXTURE0_ENV_SRC0_RGB", 43,
"TEXTURE0_ENV_SRC1_RGB", 44,
"TEXTURE0_ENV_SRC2_RGB", 45,
"TEXTURE1_ENV_SRC0_RGB", 46,
"TEXTURE1_ENV_SRC1_RGB", 47,
"TEXTURE1_ENV_SRC2_RGB", 48,
"TEXTURE2_ENV_SRC0_RGB", 49,
"TEXTURE2_ENV_SRC1_RGB", 50,
"TEXTURE2_ENV_SRC2_RGB", 51,
"TEXTURE0_ENV_OPERAND0_RGB", 52,
"TEXTURE0_ENV_OPERAND1_RGB", 53,
"TEXTURE0_ENV_OPERAND2_RGB", 54,
"TEXTURE1_ENV_OPERAND0_RGB", 55,
"TEXTURE1_ENV_OPERAND1_RGB", 56,
"TEXTURE1_ENV_OPERAND2_RGB", 57,
"TEXTURE2_ENV_OPERAND0_RGB", 58,
"TEXTURE2_ENV_OPERAND1_RGB", 59,
"TEXTURE2_ENV_OPERAND2_RGB", 60,
"TEXTURE0_ENV_SRC0_ALPHA", 61,
"TEXTURE0_ENV_SRC1_ALPHA", 62,
"TEXTURE0_ENV_SRC2_ALPHA", 63,
"TEXTURE1_ENV_SRC0_ALPHA", 64,
"TEXTURE1_ENV_SRC1_ALPHA", 65,
"TEXTURE1_ENV_SRC2_ALPHA", 66,
"TEXTURE2_ENV_SRC0_ALPHA", 67,
"TEXTURE2_ENV_SRC1_ALPHA", 68,
"TEXTURE2_ENV_SRC2_ALPHA", 69,
"TEXTURE0_ENV_OPERAND0_ALPHA", 70,
"TEXTURE0_ENV_OPERAND1_ALPHA", 71,
"TEXTURE0_ENV_OPERAND2_ALPHA", 72,
"TEXTURE1_ENV_OPERAND0_ALPHA", 73,
"TEXTURE1_ENV_OPERAND1_ALPHA", 74,
"TEXTURE1_ENV_OPERAND2_ALPHA", 75,
"TEXTURE2_ENV_OPERAND0_ALPHA", 76,
"TEXTURE2_ENV_OPERAND1_ALPHA", 77,
"TEXTURE2_ENV_OPERAND2_ALPHA", 78,
"LIGHTING_HINT", 79,
"MODELVIEW_PROJECTION_MATRIX", 80,
"MODELVIEW_MATRIX", 81,
"TRANPOSE_ADJOINT_MODEL_VIEW_MATRIX", 82,
"TEXTURE0_MATRIX", 83,
"TEXTURE1_MATRIX", 84,
"TEXTURE2_MATRIX", 85,
"TEXTURE0_SAMPLER", 86,
"TEXTURE1_SAMPLER", 87,
"TEXTURE2_SAMPLER", 88,
"TEXTURE0_ENV_COLOR", 89,
"TEXTURE1_ENV_COLOR", 90,
"TEXTURE2_ENV_COLOR", 91,
"TEXTURE0_ENV_RGB_SCALE", 92,
"TEXTURE1_ENV_RGB_SCALE", 93,
"TEXTURE2_ENV_RGB_SCALE", 94,
"TEXTURE0_ENV_ALPHA_SCALE", 95,
"TEXTURE1_ENV_ALPHA_SCALE", 96,
"TEXTURE2_ENV_ALPHA_SCALE", 97,
"TEXTURE0_ENV_BLUR_AMOUNT", 98,
"TEXTURE1_ENV_BLUR_AMOUNT", 99,
"TEXTURE2_ENV_BLUR_AMOUNT", 100,
"RESCALE_NORMAL_FACTOR", 101,
"LIGHT0_AMBIENT", 102,
"LIGHT1_AMBIENT", 103,
"LIGHT2_AMBIENT", 104,
"LIGHT0_DIFFUSE", 105,
"LIGHT1_DIFFUSE", 106,
"LIGHT2_DIFFUSE", 107,
"LIGHT0_SPECULAR", 108,
"LIGHT1_SPECULAR", 109,
"LIGHT2_SPECULAR", 110,
"LIGHT0_POSITION", 111,
"LIGHT1_POSITION", 112,
"LIGHT2_POSITION", 113,
"LIGHT0_SPOT_DIRECTION", 114,
"LIGHT1_SPOT_DIRECTION", 115,
"LIGHT2_SPOT_DIRECTION", 116,
"LIGHT0_SPOT_EXPONENT", 117,
"LIGHT1_SPOT_EXPONENT", 118,
"LIGHT2_SPOT_EXPONENT", 119,
"LIGHT0_SPOT_CUTOFF_ANGLE_COS", 120,
"LIGHT1_SPOT_CUTOFF_ANGLE_COS", 121,
"LIGHT2_SPOT_CUTOFF_ANGLE_COS", 122,
"LIGHT0_CONSTANT_ATTENUATION", 123,
"LIGHT1_CONSTANT_ATTENUATION", 124,
"LIGHT2_CONSTANT_ATTENUATION", 125,
"LIGHT0_LINEAR_ATTENUATION", 126,
"LIGHT1_LINEAR_ATTENUATION", 127,
"LIGHT2_LINEAR_ATTENUATION", 128,
"LIGHT0_QUADRATIC_ATTENUATION", 129,
"LIGHT1_QUADRATIC_ATTENUATION", 130,
"LIGHT2_QUADRATIC_ATTENUATION", 131,
"MATERIAL_AMBIENT", 132,
"MATERIAL_DIFFUSE", 133,
"MATERIAL_SPECULAR", 134,
"MATERIAL_EMISSION", 135,
"MATERIAL_SHININESS", 136,
"FOG_COLOR", 137,
"FOG_DENSITY", 138,
"FOG_START", 139,
"FOG_END", 140,
"ALPHA_FUNC_VALUE", 141,
"CLIP_PLANE0_EQUATION", 142,
"CLIP_PLANE1_EQUATION", 143,
"CLIP_PLANE2_EQUATION", 144,
"CLIP_PLANE3_EQUATION", 145,
"CLIP_PLANE4_EQUATION", 146,
"CLIP_PLANE5_EQUATION", 147,
"GLOBAL_AMBIENT_COLOR", 148,
"FIRST_STATE_UNIFORM_BOOL", 0,
"LAST_STATE_UNIFORM_BOOL", 27,
"FIRST_STATE_UNIFORM_INT", 28,
"LAST_STATE_UNIFORM_INT", 79,
"FIRST_NORMAL_UNIFORM", 80,
"LAST_NORMAL_UNIFORM", 148,
"COUNT", 149,
"STATE_UNIFORM_BOOL_COUNT", 28,
"STATE_UNIFORM_INT_COUNT", 52);
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"TAG", "OpenGLESState");
});
