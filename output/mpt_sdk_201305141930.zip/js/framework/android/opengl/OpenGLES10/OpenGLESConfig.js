﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
c$ = Clazz.declareType (android.opengl.OpenGLES10, "OpenGLESConfig");
Clazz.defineStatics (c$,
"USE_ONLY_UBER_SHADER", false,
"DEBUG", true);
