﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (["java.util.ArrayList"], "android.opengl.OpenGLES10.ShaderProgram", ["android.opengl.GLES20", "android.opengl.OpenGLES10.AttributeSimple", "$.UniformSimple", "android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.name = null;
this.program = 0;
this.activeUniforms = 0;
this.activeUniformsMaxLength = 0;
this.uniforms = null;
this.activeAttributes = 0;
this.activeAttributesMaxLength = 0;
this.attributes = null;
this.attachedShaders = 0;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "ShaderProgram");
Clazz.prepareFields (c$, function () {
this.uniforms =  new java.util.ArrayList ();
this.attributes =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
function (name, vertexShader, fragmentShader) {
this.name = name;
this.program = this.createProgram (vertexShader, fragmentShader);
}, "~S,android.opengl.OpenGLES10.Shader,android.opengl.OpenGLES10.Shader");
Clazz.makeConstructor (c$, 
function (name, binary, length, binaryformat) {
this.name = name;
}, "~S,~O,~N,~N");
Clazz.defineMethod (c$, "dispose", 
function () {
android.opengl.GLES20.glDeleteProgram (this.program);
});
Clazz.defineMethod (c$, "use", 
function () {
android.opengl.GLES20.glUseProgram (this.program);
});
Clazz.defineMethod (c$, "unuse", 
function () {
android.opengl.GLES20.glUseProgram (0);
});
Clazz.defineMethod (c$, "validate", 
function () {
android.opengl.GLES20.glValidateProgram (this.program);
var validated =  Clazz.newArray (1, 0);
android.opengl.GLES20.glGetProgramiv (this.program, 35715, validated, 0);
if (validated[0] != 0) {
var infoLog = null;
infoLog = android.opengl.GLES20.glGetProgramInfoLog (this.program);
android.util.Log.e ("ShaderProgram", "ERROR: Validation error in program " + this.name + ":\n" + infoLog);
}});
Clazz.defineMethod (c$, "getActiveAttributes", 
function () {
return this.attributes;
});
Clazz.defineMethod (c$, "getActiveUniforms", 
function () {
return this.uniforms;
});
Clazz.defineMethod (c$, "setAttributeVertexPointer", 
function (location, size, type, normalized, stride, ptr) {
android.opengl.GLES20.glVertexAttribPointer (location, size, type, normalized, stride, ptr);
}, "~N,~N,~N,~B,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "setUniform1i", 
function (name, i) {
android.opengl.GLES20.glUniform1i (this.getUniformLocation (name), i);
}, "~S,~N");
Clazz.defineMethod (c$, "setUniform1i", 
function (loc, i) {
android.opengl.GLES20.glUniform1i (loc, i);
}, "~N,~N");
Clazz.defineMethod (c$, "setUniform1iv", 
function (name, count, i) {
android.opengl.GLES20.glUniform1iv (this.getUniformLocation (name), count, i, 0);
}, "~S,~N,~A");
Clazz.defineMethod (c$, "setUniform1iv", 
function (loc, count, i) {
android.opengl.GLES20.glUniform1iv (loc, count, i, 0);
}, "~N,~N,~A");
Clazz.defineMethod (c$, "setUniform1f", 
function (name, v) {
android.opengl.GLES20.glUniform1f (this.getUniformLocation (name), v);
}, "~S,~N");
Clazz.defineMethod (c$, "setUniform1f", 
function (loc, v) {
android.opengl.GLES20.glUniform1f (loc, v);
}, "~N,~N");
Clazz.defineMethod (c$, "setUniform3f", 
function (name, x, y, z) {
android.opengl.GLES20.glUniform3f (this.getUniformLocation (name), x, y, z);
}, "~S,~N,~N,~N");
Clazz.defineMethod (c$, "setUniform3f", 
function (loc, x, y, z) {
android.opengl.GLES20.glUniform3f (loc, x, y, z);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setUniform3fv", 
function (name, count, v) {
android.opengl.GLES20.glUniform3fv (this.getUniformLocation (name), count, v, 0);
}, "~S,~N,~A");
Clazz.defineMethod (c$, "setUniform3fv", 
function (loc, count, v) {
android.opengl.GLES20.glUniform3fv (loc, count, v, 0);
}, "~N,~N,~A");
Clazz.defineMethod (c$, "setUniform4f", 
function (name, x, y, z, w) {
android.opengl.GLES20.glUniform4f (this.getUniformLocation (name), x, y, z, w);
}, "~S,~N,~N,~N,~N");
Clazz.defineMethod (c$, "setUniform4f", 
function (loc, x, y, z, w) {
android.opengl.GLES20.glUniform4f (loc, x, y, z, w);
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "setUniform4fv", 
function (name, count, v) {
android.opengl.GLES20.glUniform4fv (this.getUniformLocation (name), count, v, 0);
}, "~S,~N,~A");
Clazz.defineMethod (c$, "setUniform4fv", 
function (loc, count, v) {
android.opengl.GLES20.glUniform4fv (loc, count, v, 0);
}, "~N,~N,~A");
Clazz.defineMethod (c$, "setUniformMatrix4fv", 
function (name, m) {
android.opengl.GLES20.glUniformMatrix4fv (this.getUniformLocation (name), 1, false, m, 0);
}, "~S,~A");
Clazz.defineMethod (c$, "setUniformMatrix4fv", 
function (loc, m) {
android.opengl.GLES20.glUniformMatrix4fv (loc, 1, false, m, 0);
}, "~N,~A");
Clazz.defineMethod (c$, "setUniformMatrix3fv", 
function (name, m) {
android.opengl.GLES20.glUniformMatrix3fv (this.getUniformLocation (name), 1, false, m, 0);
}, "~S,~A");
Clazz.defineMethod (c$, "setUniformMatrix3fv", 
function (loc, m) {
android.opengl.GLES20.glUniformMatrix3fv (loc, 1, false, m, 0);
}, "~N,~A");
Clazz.defineMethod (c$, "createProgram", 
($fz = function (vertexShader, fragmentShader) {
var vertexShaderId = vertexShader.compile ();
var fragmentShaderId = fragmentShader.compile ();
android.opengl.GLES20.glReleaseShaderCompiler ();
var program = android.opengl.GLES20.glCreateProgram ();
if (program == 0) {
android.util.Log.e ("ShaderProgram", "ERROR: Creating program " + this.name + " failed.");
return 0;
}android.opengl.GLES20.glAttachShader (program, vertexShaderId);
android.opengl.GLES20.glAttachShader (program, fragmentShaderId);
android.opengl.GLES20.glLinkProgram (program);
var linked =  Clazz.newArray (1, 0);
android.opengl.GLES20.glGetProgramiv (program, 35714, linked, 0);
if (linked[0] != 0) {
var infoLog = android.opengl.GLES20.glGetProgramInfoLog (program);
if (infoLog.length > 0) {
if (linked[0] != 0) {
android.util.Log.w ("ShaderProgram", "WARNING: Linked program " + this.name + " with warnings:\n" + infoLog);
} else {
android.util.Log.e ("ShaderProgram", "ERROR: Linking program " + this.name + " failed:\n" + infoLog);
}}if (linked[0] != 0) {
android.util.Log.i ("ShaderProgram", "Linked program " + this.name + " successfully.");
} else {
android.opengl.GLES20.glDeleteProgram (program);
return 0;
}}var value =  Clazz.newArray (1, 0);
android.opengl.GLES20.glGetProgramiv (program, 35721, value, 0);
this.activeAttributes = value[1];
android.opengl.GLES20.glGetProgramiv (program, 35722, value, 0);
this.activeAttributesMaxLength = value[1];
android.opengl.GLES20.glGetProgramiv (program, 35718, value, 0);
this.activeUniforms = value[1];
android.opengl.GLES20.glGetProgramiv (program, 35719, value, 0);
this.activeUniformsMaxLength = value[1];
android.opengl.GLES20.glGetProgramiv (program, 35717, value, 0);
this.attachedShaders = value[1];
android.util.Log.d ("ShaderProgram", "Active attributes: " + this.activeAttributes);
android.util.Log.d ("ShaderProgram", "Active attributes max length: " + this.activeAttributesMaxLength);
android.util.Log.d ("ShaderProgram", "Active uniforms: " + this.activeUniforms);
android.util.Log.d ("ShaderProgram", "Active uniforms max length: " + this.activeUniformsMaxLength);
android.util.Log.d ("ShaderProgram", "Attached shaders: " + this.attachedShaders);
android.util.Log.d ("ShaderProgram", "Attributes");
for (var i = 0; i < this.activeAttributes; i++) {
var name =  Clazz.newArray (this.activeAttributesMaxLength, 0);
var size =  Clazz.newArray (1, 0);
var type =  Clazz.newArray (1, 0);
android.opengl.GLES20.glGetActiveAttrib (program, i, this.activeAttributesMaxLength, null, 0, size, 0, type, 0, name, 0);
var attributeName =  String.instantialize (name);
var attributeLocation = android.opengl.GLES20.glGetAttribLocation (program, attributeName);
var id = -1;
if (attributeName === "a_position") {
id = 0;
} else if (attributeName === "a_normal") {
id = 1;
} else if (attributeName === "a_color") {
id = 2;
} else if (attributeName === "a_texCoord0") {
id = 3;
} else if (attributeName === "a_texCoord1") {
id = 4;
} else if (attributeName === "a_texCoord2") {
id = 5;
} else {
android.util.Log.e ("ShaderProgram", "ERROR: Missing " + attributeName);
return 0;
}this.attributes.add ( new android.opengl.OpenGLES10.AttributeSimple (id, attributeLocation));
var typeString;
switch (type[0]) {
case 5126:
typeString = "GL_FLOAT";
break;
case 35664:
typeString = "GL_FLOAT_VEC2";
break;
case 35665:
typeString = "GL_FLOAT_VEC3";
break;
case 35666:
typeString = "GL_FLOAT_VEC4";
break;
case 35674:
typeString = "GL_FLOAT_MAT2";
break;
case 35675:
typeString = "GL_FLOAT_MAT3";
break;
case 35676:
typeString = "GL_FLOAT_MAT4";
break;
default:
typeString = "Unknown";
android.util.Log.e ("ShaderProgram", "ERROR: Unknown type.");
break;
}
android.util.Log.d ("ShaderProgram", attributeName + ": type " + typeString + " location: " + attributeLocation);
}
android.util.Log.d ("ShaderProgram", "Uniforms");
for (var i = 0; i < this.activeUniforms; i++) {
var name =  Clazz.newArray (this.activeUniformsMaxLength, 0);
var size =  Clazz.newArray (1, 0);
var uniformType =  Clazz.newArray (1, 0);
android.opengl.GLES20.glGetActiveUniform (program, i, this.activeUniformsMaxLength, null, 0, size, 0, uniformType, 0, name, 0);
var uniformName =  String.instantialize (name);
var uniformLocation = android.opengl.GLES20.glGetUniformLocation (program, uniformName);
var id = -1;
if (uniformName === "u_lightModelLocalViewerEnabled") {
id = 7;
} else if (uniformName === "u_lightModelTwoSideEnabled") {
id = 8;
} else if (uniformName === "u_lightingEnabled") {
id = 6;
} else if (uniformName === "u_light0Enabled") {
id = 9;
} else if (uniformName === "u_light1Enabled") {
id = 10;
} else if (uniformName === "u_light2Enabled") {
id = 11;
} else if (uniformName === "u_light0.ambient") {
id = 102;
} else if (uniformName === "u_light1.ambient") {
id = 103;
} else if (uniformName === "u_light2.ambient") {
id = 104;
} else if (uniformName === "u_light0.diffuse") {
id = 105;
} else if (uniformName === "u_light1.diffuse") {
id = 106;
} else if (uniformName === "u_light2.diffuse") {
id = 107;
} else if (uniformName === "u_light0.specular") {
id = 108;
} else if (uniformName === "u_light1.specular") {
id = 109;
} else if (uniformName === "u_light2.specular") {
id = 110;
} else if (uniformName === "u_light0.position") {
id = 111;
} else if (uniformName === "u_light1.position") {
id = 112;
} else if (uniformName === "u_light2.position") {
id = 113;
} else if (uniformName === "u_light0.spotDirection") {
id = 114;
} else if (uniformName === "u_light1.spotDirection") {
id = 115;
} else if (uniformName === "u_light2.spotDirection") {
id = 116;
} else if (uniformName === "u_light0.spotExponent") {
id = 117;
} else if (uniformName === "u_light1.spotExponent") {
id = 118;
} else if (uniformName === "u_light2.spotExponent") {
id = 119;
} else if (uniformName === "u_light0.spotCutoffAngleCos") {
id = 120;
} else if (uniformName === "u_light1.spotCutoffAngleCos") {
id = 121;
} else if (uniformName === "u_light2.spotCutoffAngleCos") {
id = 122;
} else if (uniformName === "u_light0.constantAttenuation") {
id = 123;
} else if (uniformName === "u_light1.constantAttenuation") {
id = 124;
} else if (uniformName === "u_light2.constantAttenuation") {
id = 125;
} else if (uniformName === "u_light0.linearAttenuation") {
id = 126;
} else if (uniformName === "u_light1.linearAttenuation") {
id = 127;
} else if (uniformName === "u_light2.linearAttenuation") {
id = 128;
} else if (uniformName === "u_light0.quadraticAttenuation") {
id = 129;
} else if (uniformName === "u_light1.quadraticAttenuation") {
id = 130;
} else if (uniformName === "u_light2.quadraticAttenuation") {
id = 131;
} else if (uniformName === "u_modelViewMatrix") {
id = 81;
} else if (uniformName === "u_modelViewProjectionMatrix") {
id = 80;
} else if (uniformName === "u_transposeAdjointModelViewMatrix") {
id = 82;
} else if (uniformName === "u_rescaleNormalFactor") {
id = 101;
} else if (uniformName === "u_material.ambient") {
id = 132;
} else if (uniformName === "u_material.diffuse") {
id = 133;
} else if (uniformName === "u_material.specular") {
id = 134;
} else if (uniformName === "u_material.emission") {
id = 135;
} else if (uniformName === "u_material.shininess") {
id = 136;
} else if (uniformName === "u_normalizeEnabled") {
id = 27;
} else if (uniformName === "u_rescaleNormalEnabled") {
id = 26;
} else if (uniformName === "u_alphaTestEnabled") {
id = 19;
} else if (uniformName === "u_alphaFunc") {
id = 30;
} else if (uniformName === "u_alphaFuncValue") {
id = 141;
} else if (uniformName === "u_globalAmbientColor") {
id = 148;
} else if (uniformName === "u_positionEnabled") {
id = 0;
} else if (uniformName === "u_normalEnabled") {
id = 1;
} else if (uniformName === "u_colorEnabled") {
id = 2;
} else if (uniformName === "u_texCoord0Enabled") {
id = 3;
} else if (uniformName === "u_texCoord1Enabled") {
id = 4;
} else if (uniformName === "u_texCoord2Enabled") {
id = 5;
} else if (uniformName === "u_texture0Enabled") {
id = 12;
} else if (uniformName === "u_texture1Enabled") {
id = 13;
} else if (uniformName === "u_texture2Enabled") {
id = 14;
} else if (uniformName === "u_texture0Sampler") {
id = 86;
} else if (uniformName === "u_texture1Sampler") {
id = 87;
} else if (uniformName === "u_texture2Sampler") {
id = 88;
} else if (uniformName === "u_texture0Matrix") {
id = 83;
} else if (uniformName === "u_texture1Matrix") {
id = 84;
} else if (uniformName === "u_texture2Matrix") {
id = 85;
} else if (uniformName === "u_texture0MatrixEnabled") {
id = 15;
} else if (uniformName === "u_texture1MatrixEnabled") {
id = 16;
} else if (uniformName === "u_texture2MatrixEnabled") {
id = 17;
} else if (uniformName === "u_texture0Format") {
id = 31;
} else if (uniformName === "u_texture1Format") {
id = 32;
} else if (uniformName === "u_texture2Format") {
id = 33;
} else if (uniformName === "u_texture0EnvMode") {
id = 34;
} else if (uniformName === "u_texture1EnvMode") {
id = 35;
} else if (uniformName === "u_texture2EnvMode") {
id = 36;
} else if (uniformName === "u_texture0EnvColor") {
id = 89;
} else if (uniformName === "u_texture1EnvColor") {
id = 90;
} else if (uniformName === "u_texture2EnvColor") {
id = 91;
} else if (uniformName === "u_texture0EnvRGBScale") {
id = 92;
} else if (uniformName === "u_texture1EnvRGBScale") {
id = 93;
} else if (uniformName === "u_texture2EnvRGBScale") {
id = 94;
} else if (uniformName === "u_texture0EnvAlphaScale") {
id = 95;
} else if (uniformName === "u_texture1EnvAlphaScale") {
id = 96;
} else if (uniformName === "u_texture2EnvAlphaScale") {
id = 97;
} else if (uniformName === "u_texture0EnvBlurAmount") {
id = 98;
} else if (uniformName === "u_texture1EnvBlurAmount") {
id = 99;
} else if (uniformName === "u_texture2EnvBlurAmount") {
id = 100;
} else if (uniformName === "u_texture0EnvCombineRGB") {
id = 37;
} else if (uniformName === "u_texture1EnvCombineRGB") {
id = 38;
} else if (uniformName === "u_texture2EnvCombineRGB") {
id = 39;
} else if (uniformName === "u_texture0EnvCombineAlpha") {
id = 40;
} else if (uniformName === "u_texture1EnvCombineAlpha") {
id = 41;
} else if (uniformName === "u_texture2EnvCombineAlpha") {
id = 42;
} else if (uniformName === "u_fogEnabled") {
id = 18;
} else if (uniformName === "u_fogColor") {
id = 137;
} else if (uniformName === "u_fogMode") {
id = 28;
} else if (uniformName === "u_fogDensity") {
id = 138;
} else if (uniformName === "u_fogStart") {
id = 139;
} else if (uniformName === "u_fogEnd") {
id = 140;
} else if (uniformName === "u_fogHint") {
id = 29;
} else if (uniformName === "u_lightingHint") {
id = 79;
} else if (uniformName === "u_clipPlane0Enabled") {
id = 20;
} else if (uniformName === "u_clipPlane1Enabled") {
id = 21;
} else if (uniformName === "u_clipPlane2Enabled") {
id = 22;
} else if (uniformName === "u_clipPlane3Enabled") {
id = 23;
} else if (uniformName === "u_clipPlane4Enabled") {
id = 24;
} else if (uniformName === "u_clipPlane5Enabled") {
id = 25;
} else if (uniformName === "u_clipPlane0Equation") {
id = 142;
} else if (uniformName === "u_clipPlane1Equation") {
id = 143;
} else if (uniformName === "u_clipPlane2Equation") {
id = 144;
} else if (uniformName === "u_clipPlane3Equation") {
id = 145;
} else if (uniformName === "u_clipPlane4Equation") {
id = 146;
} else if (uniformName === "u_clipPlane5Equation") {
id = 147;
} else {
android.util.Log.e ("ShaderProgram", "ERROR: Missing " + uniformName);
return 0;
}this.uniforms.add ( new android.opengl.OpenGLES10.UniformSimple (id, uniformLocation));
var typeString;
switch (uniformType[0]) {
case 5126:
typeString = "GL_FLOAT";
break;
case 35664:
typeString = "GL_FLOAT_VEC2";
break;
case 35665:
typeString = "GL_FLOAT_VEC3";
break;
case 35666:
typeString = "GL_FLOAT_VEC4";
break;
case 5124:
typeString = "GL_INT";
break;
case 35667:
typeString = "GL_INT_VEC2";
break;
case 35668:
typeString = "GL_INT_VEC3";
break;
case 35669:
typeString = "GL_INT_VEC4";
break;
case 35670:
typeString = "GL_BOOL";
break;
case 35671:
typeString = "GL_BOOL_VEC2";
break;
case 35672:
typeString = "GL_BOOL_VEC3";
break;
case 35673:
typeString = "GL_BOOL_VEC4";
break;
case 35674:
typeString = "GL_FLOAT_MAT2";
break;
case 35675:
typeString = "GL_FLOAT_MAT3";
break;
case 35676:
typeString = "GL_FLOAT_MAT4";
break;
case 35678:
typeString = "GL_SAMPLER_2D";
break;
case 35680:
typeString = "GL_SAMPLER_CUBE";
break;
default:
typeString = "Unknown";
android.util.Log.e ("ShaderProgram", "ERROR: Unknown type " + uniformType);
break;
}
android.util.Log.d ("ShaderProgram", uniformName + ": type " + typeString + " location: " + uniformLocation);
}
return program;
}, $fz.isPrivate = true, $fz), "android.opengl.OpenGLES10.Shader,android.opengl.OpenGLES10.Shader");
Clazz.defineMethod (c$, "getUniformLocation", 
($fz = function (uniformName) {
var res = android.opengl.GLES20.glGetUniformLocation (this.program, uniformName);
if (res == -1) {
android.util.Log.e ("ShaderProgram", "ERROR: Unknown uniform " + uniformName + " in program " + this.name);
}return res;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineStatics (c$,
"TAG", "ShaderProgram");
});
