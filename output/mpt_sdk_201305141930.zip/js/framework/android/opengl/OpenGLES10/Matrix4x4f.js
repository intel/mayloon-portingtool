﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
c$ = Clazz.decorateAsClass (function () {
this.m = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "Matrix4x4f");
Clazz.prepareFields (c$, function () {
this.m =  Clazz.newArray (16, 0);
});
Clazz.makeConstructor (c$, 
function () {
for (var i = 0; i < 16; i++) {
this.m[i] = 0;
}
});
Clazz.makeConstructor (c$, 
function (other) {
for (var i = 0; i < 16; i++) {
this.m[i] = other.m[i];
}
}, "android.opengl.OpenGLES10.Matrix4x4f");
Clazz.defineMethod (c$, "getItem", 
function (i, j) {
return this.m[i * 4 + j];
}, "~N,~N");
Clazz.defineMethod (c$, "setItem", 
function (i, j, value) {
this.m[i * 4 + j] = value;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "copyFrom", 
function (other) {
for (var i = 0; i < 16; i++) {
this.m[i] = other.m[i];
}
return this;
}, "android.opengl.OpenGLES10.Matrix4x4f");
Clazz.defineMethod (c$, "copyFrom", 
function (other) {
for (var i = 0; i < 16; i++) {
this.m[i] = other[i];
}
return this;
}, "~A");
Clazz.defineMethod (c$, "equalsTo", 
function (other) {
for (var i = 0; i < 16; i++) {
if (this.m[i] != other.m[i]) {
return false;
}}
return true;
}, "android.opengl.OpenGLES10.Matrix4x4f");
Clazz.defineMethod (c$, "notEqualsTo", 
function (other) {
return !this.equalsTo (other);
}, "android.opengl.OpenGLES10.Matrix4x4f");
