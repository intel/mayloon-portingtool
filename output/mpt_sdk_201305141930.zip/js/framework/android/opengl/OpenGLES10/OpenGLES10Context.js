﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (null, "android.opengl.OpenGLES10.OpenGLES10Context", ["android.opengl.GLES20", "android.opengl.OpenGLES10.Matrix3x3f", "$.Matrix4x4f", "$.MatrixStack", "$.OpenGLESMath", "$.OpenGLESState", "$.Vector3f", "$.Vector4f", "android.util.Log", "java.util.Arrays"], function () {
c$ = Clazz.decorateAsClass (function () {
this.matrixStack = null;
this.openGLESState = null;
this.shaderProgramId = 0;
this.colorReadFormat = 0;
this.colorReadType = 0;
this.maxCombinedTextureImageUnits = 0;
this.maxCubeMapTextureSize = 0;
this.maxFragmentUniformVectors = 0;
this.maxRenderBufferSize = 0;
this.maxTextureImageUnits = 0;
this.maxTextureSize = 0;
this.maxVaryingVectors = 0;
this.maxVertexAttribs = 0;
this.maxVertexTextureImageUnits = 0;
this.maxVertexUniformVectors = 0;
this.maxViewportDims = null;
this.numCompressedTextureFormats = 0;
this.numShaderBinaryFormats = 0;
this.shaderBinaryFormats = null;
this.shaderCompilerSupported = false;
this.depthBits = 0;
this.stencilBits = 0;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "OpenGLES10Context");
Clazz.prepareFields (c$, function () {
this.maxViewportDims =  Clazz.newArray (2, 0);
});
Clazz.makeConstructor (c$, 
function () {
this.matrixStack =  new android.opengl.OpenGLES10.MatrixStack (this.openGLESState, this);
this.openGLESState =  new android.opengl.OpenGLES10.OpenGLESState ();
this.shaderProgramId = 0;
this.init ();
this.matrixStack.init ();
this.openGLESState.init (this);
});
Clazz.defineMethod (c$, "init", 
($fz = function () {
var value =  Clazz.newArray (1, 0);
android.opengl.GLES20.glGetIntegerv (35739, value, 0);
this.colorReadFormat = value[0];
android.opengl.GLES20.glGetIntegerv (35738, value, 0);
this.colorReadType = value[0];
android.opengl.GLES20.glGetIntegerv (35661, value, 0);
this.maxCombinedTextureImageUnits = value[0];
this.maxCombinedTextureImageUnits = Math.min (3, this.maxCombinedTextureImageUnits);
android.opengl.GLES20.glGetIntegerv (34076, value, 0);
this.maxCubeMapTextureSize = value[0];
android.opengl.GLES20.glGetIntegerv (36349, value, 0);
this.maxFragmentUniformVectors = value[0];
android.opengl.GLES20.glGetIntegerv (34024, value, 0);
this.maxRenderBufferSize = value[0];
android.opengl.GLES20.glGetIntegerv (3379, value, 0);
this.maxTextureSize = value[0];
android.opengl.GLES20.glGetIntegerv (34930, value, 0);
this.maxTextureImageUnits = value[0];
this.maxTextureImageUnits = Math.min (3, this.maxTextureImageUnits);
android.opengl.GLES20.glGetIntegerv (36348, value, 0);
this.maxVaryingVectors = value[0];
android.opengl.GLES20.glGetIntegerv (34921, value, 0);
this.maxVertexAttribs = value[0];
android.opengl.GLES20.glGetIntegerv (35660, value, 0);
this.maxVertexTextureImageUnits = value[0];
android.opengl.GLES20.glGetIntegerv (36347, value, 0);
this.maxVertexUniformVectors = value[0];
android.opengl.GLES20.glGetIntegerv (3386, this.maxViewportDims, 0);
android.opengl.GLES20.glGetIntegerv (34466, value, 0);
this.numCompressedTextureFormats = value[0];
android.opengl.GLES20.glGetIntegerv (36345, value, 0);
this.numShaderBinaryFormats = value[0];
this.shaderBinaryFormats =  Clazz.newArray (this.numShaderBinaryFormats, 0);
android.opengl.GLES20.glGetIntegerv (36344, this.shaderBinaryFormats, 0);
var tmp =  Clazz.newArray (1, false);
android.opengl.GLES20.glGetBooleanv (36346, tmp, 0);
this.shaderCompilerSupported = tmp[0];
android.opengl.GLES20.glGetIntegerv (3414, value, 0);
this.depthBits = value[0];
android.opengl.GLES20.glGetIntegerv (3415, value, 0);
this.stencilBits = value[0];
this.print ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "print", 
($fz = function () {
android.util.Log.d ("OpenGLES10Context", "OpenGL Implementation Details:");
android.util.Log.d ("OpenGLES10Context", "------------------------------");
android.util.Log.d ("OpenGLES10Context", "Max viewport dimensions: " + this.maxViewportDims[0] + "*" + this.maxViewportDims[1]);
android.util.Log.d ("OpenGLES10Context", "Depth bits: " + this.depthBits);
android.util.Log.d ("OpenGLES10Context", "Stencil bits: " + this.stencilBits);
android.util.Log.d ("OpenGLES10Context", "Color read format: " + this.colorReadFormat);
android.util.Log.d ("OpenGLES10Context", "Color read type: " + this.colorReadType);
android.util.Log.d ("OpenGLES10Context", "Max render buffer size: " + this.maxRenderBufferSize);
android.util.Log.d ("OpenGLES10Context", "Max texture size: " + this.maxTextureSize);
android.util.Log.d ("OpenGLES10Context", "Number of compressed texture formats: " + this.numCompressedTextureFormats);
android.util.Log.d ("OpenGLES10Context", "Max combined texture image units: " + this.maxCombinedTextureImageUnits);
android.util.Log.d ("OpenGLES10Context", "Max cubemap texture size: " + this.maxCubeMapTextureSize);
android.util.Log.d ("OpenGLES10Context", "Shader compiler support: " + this.shaderCompilerSupported);
android.util.Log.d ("OpenGLES10Context", "Number of shader binary formats: " + this.numShaderBinaryFormats);
for (var i = 0; i < this.numShaderBinaryFormats; i++) {
android.util.Log.d ("OpenGLES10Context", "Supported shader binary format: " + this.shaderBinaryFormats[i]);
}
android.util.Log.d ("OpenGLES10Context", "Max vertex attributes: " + this.maxVertexAttribs);
android.util.Log.d ("OpenGLES10Context", "Max vertex uniform vectors: " + this.maxVertexUniformVectors);
android.util.Log.d ("OpenGLES10Context", "Max varying vectors: " + this.maxVaryingVectors);
android.util.Log.d ("OpenGLES10Context", "Max fragment uniform vectors: " + this.maxFragmentUniformVectors);
android.util.Log.d ("OpenGLES10Context", "Max texture image units: " + this.maxTextureImageUnits);
android.util.Log.d ("OpenGLES10Context", "Max vertex texture image units: " + this.maxVertexTextureImageUnits);
android.util.Log.d ("OpenGLES10Context", "------------------------------");
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "dispose", 
function () {
});
Clazz.defineMethod (c$, "glActiveTexture", 
function (texture) {
this.openGLESState.setActiveTexture (texture - 33984);
android.opengl.GLES20.glActiveTexture (texture);
}, "~N");
Clazz.defineMethod (c$, "glAlphaFunc", 
function (func, ref) {
this.openGLESState.setAlphaFunc (func);
this.openGLESState.setAlphaFuncValue (Math.max (Math.min (1, ref), 0));
}, "~N,~N");
Clazz.defineMethod (c$, "glAlphaFuncx", 
function (func, ref) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glBindTexture", 
function (target, texture) {
this.openGLESState.setBoundTexture (texture);
this.openGLESState.setTextureFormat ();
android.opengl.GLES20.glBindTexture (target, texture);
}, "~N,~N");
Clazz.defineMethod (c$, "glBlendFunc", 
function (sfactor, dfactor) {
android.opengl.GLES20.glBlendFunc (sfactor, dfactor);
}, "~N,~N");
Clazz.defineMethod (c$, "glClear", 
function (mask) {
android.opengl.GLES20.glClear (mask);
}, "~N");
Clazz.defineMethod (c$, "glClearColor", 
function (red, green, blue, alpha) {
android.opengl.GLES20.glClearColor (red, green, blue, alpha);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glClearColorx", 
function (red, green, blue, alpha) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glClearDepthf", 
function (depth) {
android.opengl.GLES20.glClearDepthf (depth);
}, "~N");
Clazz.defineMethod (c$, "glClearDepthx", 
function (depth) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N");
Clazz.defineMethod (c$, "glClearStencil", 
function (s) {
android.opengl.GLES20.glClearStencil (s);
}, "~N");
Clazz.defineMethod (c$, "glClientActiveTexture", 
function (texture) {
this.openGLESState.setClientActiveTexture (texture - 33984);
}, "~N");
Clazz.defineMethod (c$, "glColor4f", 
function (red, green, blue, alpha) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glColor4x", 
function (red, green, blue, alpha) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glColorMask", 
function (red, green, blue, alpha) {
android.opengl.GLES20.glColorMask (red, green, blue, alpha);
}, "~B,~B,~B,~B");
Clazz.defineMethod (c$, "glColorPointer", 
function (size, type, stride, pointer) {
this.openGLESState.setColor (size, type, stride, pointer);
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glCompressedTexImage2D", 
function (target, level, internalformat, width, height, border, imageSize, data) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N,~N,~N,~N,~O");
Clazz.defineMethod (c$, "glCompressedTexSubImage2D", 
function (target, level, xoffset, yoffset, width, height, format, imageSize, data) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N,~N,~N,~N,~N,~O");
Clazz.defineMethod (c$, "glCopyTexImage2D", 
function (target, level, internalformat, x, y, width, height, border) {
android.opengl.GLES20.glCopyTexImage2D (target, level, internalformat, x, y, width, height, border);
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glCopyTexSubImage2D", 
function (target, level, xoffset, yoffset, x, y, width, height) {
android.opengl.GLES20.glCopyTexSubImage2D (target, level, xoffset, yoffset, x, y, width, height);
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glCullFace", 
function (mode) {
android.opengl.GLES20.glCullFace (mode);
}, "~N");
Clazz.defineMethod (c$, "glDeleteTextures", 
function (n, textures, offset) {
android.opengl.GLES20.glDeleteTextures (n, textures, offset);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glDepthFunc", 
function (func) {
android.opengl.GLES20.glDepthFunc (func);
}, "~N");
Clazz.defineMethod (c$, "glDepthMask", 
function (flag) {
android.opengl.GLES20.glDepthMask (flag);
}, "~B");
Clazz.defineMethod (c$, "glDepthRangef", 
function (zNear, zFar) {
android.opengl.GLES20.glDepthRangef (zNear, zFar);
}, "~N,~N");
Clazz.defineMethod (c$, "glDepthRangex", 
function (zNear, zFar) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glDisable", 
function (cap) {
switch (cap) {
case 2896:
this.openGLESState.setLighting (false);
break;
case 16384:
case 16385:
case 16386:
case 16387:
case 16388:
case 16389:
case 16390:
case 16391:
this.openGLESState.setLight (cap - 16384, false);
break;
case 3553:
this.openGLESState.setTexture (false);
break;
case 2884:
case 3042:
case 3024:
case 2960:
case 2929:
case 3089:
case 32823:
case 32926:
case 32928:
android.opengl.GLES20.glDisable (cap);
break;
case 2977:
this.openGLESState.setNormalize (false);
break;
case 32826:
this.openGLESState.setRescaleNormal (false);
break;
case 2912:
this.openGLESState.setFog (false);
break;
case 3008:
this.openGLESState.setAlphaTest (false);
break;
case 12288:
case 12289:
case 12290:
case 12291:
case 12292:
case 12293:
this.openGLESState.setClipPlane (cap - 12288, false);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown cap " + cap);
break;
}
}, "~N");
Clazz.defineMethod (c$, "glDisableClientState", 
function (array) {
switch (array) {
case 32884:
this.openGLESState.setPosition (false);
break;
case 32886:
this.openGLESState.setColor (false);
break;
case 32885:
this.openGLESState.setNormal (false);
break;
case 32888:
this.openGLESState.setTexCoord (false);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown argument " + array);
break;
}
}, "~N");
Clazz.defineMethod (c$, "glDrawArrays", 
function (mode, first, count) {
if (this.shaderProgramId == 0) {
this.prepareToDraw ();
}android.opengl.GLES20.glDrawArrays (mode, first, count);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glDrawElements", 
function (mode, count, type, indices) {
if (this.shaderProgramId == 0) {
this.prepareToDraw ();
}android.opengl.GLES20.glDrawElements (mode, count, type, indices);
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glEnable", 
function (cap) {
switch (cap) {
case 2896:
this.openGLESState.setLighting (true);
break;
case 16384:
case 16385:
case 16386:
case 16387:
case 16388:
case 16389:
case 16390:
case 16391:
{
this.openGLESState.setLight (cap - 16384, true);
}break;
case 3553:
this.openGLESState.setTexture (true);
break;
case 2884:
case 3042:
case 3024:
case 2960:
case 2929:
case 3089:
case 32823:
case 32926:
case 32928:
android.opengl.GLES20.glEnable (cap);
break;
case 2977:
this.openGLESState.setNormalize (true);
break;
case 2912:
this.openGLESState.setFog (true);
break;
case 32826:
this.openGLESState.setRescaleNormal (true);
break;
case 3008:
this.openGLESState.setAlphaTest (true);
break;
case 12288:
case 12289:
case 12290:
case 12291:
case 12292:
case 12293:
this.openGLESState.setClipPlane (cap - 12288, true);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown cap " + cap);
break;
}
}, "~N");
Clazz.defineMethod (c$, "glEnableClientState", 
function (array) {
switch (array) {
case 32884:
this.openGLESState.setPosition (true);
break;
case 32886:
this.openGLESState.setColor (true);
break;
case 32885:
this.openGLESState.setNormal (true);
break;
case 32888:
this.openGLESState.setTexCoord (true);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown argument " + array);
break;
}
}, "~N");
Clazz.defineMethod (c$, "glFinish", 
function () {
android.opengl.GLES20.glFinish ();
});
Clazz.defineMethod (c$, "glFlush", 
function () {
android.opengl.GLES20.glFlush ();
});
Clazz.defineMethod (c$, "glFogf", 
function (pname, param) {
switch (pname) {
case 2917:
{
var p = Math.round (param);
if (p == 9729 || p == 2048 || p == 2049) {
this.openGLESState.setFogMode (p);
} else {
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown fog mode " + param);
}break;
}case 2914:
this.openGLESState.setFogDensity (param);
break;
case 2915:
this.openGLESState.setFogStart (param);
break;
case 2916:
this.openGLESState.setFogEnd (param);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown fog parameter " + pname);
break;
}
}, "~N,~N");
Clazz.defineMethod (c$, "glFogfv", 
function (pname, params, offset) {
switch (pname) {
case 2918:
this.openGLESState.setFogColor ( new android.opengl.OpenGLES10.Vector3f (java.util.Arrays.copyOfRange (params, offset, offset + 3)));
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown fog parameter " + pname);
break;
}
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glFogx", 
function (pname, param) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glFogxv", 
function (pname, params) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glFrontFace", 
function (mode) {
android.opengl.GLES20.glFrontFace (mode);
}, "~N");
Clazz.defineMethod (c$, "glFrustumf", 
function (left, right, bottom, top, zNear, zFar) {
this.matrixStack.frustum (left, right, bottom, top, zNear, zFar);
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glFrustumx", 
function (left, right, bottom, top, zNear, zFar) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glGenTextures", 
function (n, textures, offset) {
android.opengl.GLES20.glGenTextures (n, textures, offset);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetError", 
function () {
return android.opengl.GLES20.glGetError ();
});
Clazz.defineMethod (c$, "glGetIntegerv", 
function (pname, params, offset) {
android.opengl.GLES20.glGetIntegerv (pname, params, offset);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetString", 
function (name) {
return android.opengl.GLES20.glGetString (name);
}, "~N");
Clazz.defineMethod (c$, "glHint", 
function (target, mode) {
switch (target) {
case 3156:
this.openGLESState.setFogHint (mode);
break;
default:
android.opengl.GLES20.glHint (target, mode);
break;
}
}, "~N,~N");
Clazz.defineMethod (c$, "glLightModelf", 
function (pname, param) {
switch (pname) {
case 2898:
this.openGLESState.setLightModelTwoSide (param != 0);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown light model" + pname);
break;
}
}, "~N,~N");
Clazz.defineMethod (c$, "glLightModelfv", 
function (pname, params, offset) {
switch (pname) {
case 2899:
this.openGLESState.setGlobalAmbientColor ( new android.opengl.OpenGLES10.Vector4f (java.util.Arrays.copyOfRange (params, offset, offset + 4)));
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown light model" + pname);
break;
}
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glLightModelx", 
function (pname, param) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glLightModelxv", 
function (pname, params) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glLightf", 
function (l, pname, param) {
var lightIndex = l - 16384;
switch (pname) {
case 4613:
this.openGLESState.setLightSpotExponent (lightIndex, param);
if (true) {
if (param > 128) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Spot exponent cannot be over 128");
}}break;
case 4614:
this.openGLESState.setLightSpotCutoffAngleCos (lightIndex, Math.cos (param * 3.141592653589793 / 180.0));
if (true) {
if (param > 90 && param != 180) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Spot cutoff cannot be over 90 and different from 180.");
}}break;
case 4615:
this.openGLESState.setLightConstantAttenuation (lightIndex, param);
break;
case 4616:
this.openGLESState.setLightLinearAttenuation (lightIndex, param);
break;
case 4617:
this.openGLESState.setLightQuadraticAttenuation (lightIndex, param);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown light parameter " + pname);
break;
}
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glLightfv", 
function (l, pname, params, offset) {
var lightIndex = l - 16384;
var value =  new android.opengl.OpenGLES10.Vector4f (java.util.Arrays.copyOfRange (params, offset, params.length));
switch (pname) {
case 4608:
this.openGLESState.setLightAmbient (lightIndex, value);
break;
case 4609:
this.openGLESState.setLightDiffuse (lightIndex, value);
break;
case 4610:
this.openGLESState.setLightSpecular (lightIndex, value);
break;
case 4611:
{
var modelViewMatrix = this.matrixStack.getModelViewMatrix ();
var vec =  new android.opengl.OpenGLES10.Vector4f (java.util.Arrays.copyOfRange (params, offset, params.length));
vec = android.opengl.OpenGLES10.OpenGLESMath.multiply (modelViewMatrix, vec);
this.openGLESState.setLightPosition (lightIndex, vec);
if (true) {
if (vec.getItem (3) == 0.0 && !android.opengl.OpenGLES10.OpenGLESMath.isUnitVector (vec)) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Directional light's position is not unit vector.");
}}}break;
case 4612:
{
var modelViewMatrix = this.matrixStack.getModelViewMatrix ();
var modelViewMatrix3x3 =  new android.opengl.OpenGLES10.Matrix3x3f ();
modelViewMatrix3x3 = android.opengl.OpenGLES10.OpenGLESMath.copyMatrix4x4UpperLeftToMatrix3x3 (modelViewMatrix);
var vec =  new android.opengl.OpenGLES10.Vector3f (java.util.Arrays.copyOfRange (params, offset, params.length));
vec = android.opengl.OpenGLES10.OpenGLESMath.multiply (modelViewMatrix3x3, vec);
this.openGLESState.setLightSpotDirection (lightIndex, vec);
}break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown light parameter " + pname);
break;
}
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glLightx", 
function (light, pname, param) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glLightxv", 
function (light, pname, params) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glLineWidth", 
function (width) {
android.opengl.GLES20.glLineWidth (width);
}, "~N");
Clazz.defineMethod (c$, "glLineWidthx", 
function (width) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N");
Clazz.defineMethod (c$, "glLoadIdentity", 
function () {
this.matrixStack.loadIdentity ();
});
Clazz.defineMethod (c$, "glLoadMatrixf", 
function (m, offset) {
this.matrixStack.loadMatrix (java.util.Arrays.copyOfRange (m, offset, m.length));
}, "~A,~N");
Clazz.defineMethod (c$, "glLoadMatrixx", 
function (m) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N");
Clazz.defineMethod (c$, "glLogicOp", 
function (opcode) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N");
Clazz.defineMethod (c$, "glMaterialf", 
function (face, pname, param) {
switch (pname) {
case 5633:
this.openGLESState.setMaterialShininess (param);
if (true) {
if (param > 128) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Shininess cannot be over 128");
}}break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown material parameter " + pname);
break;
}
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glMaterialfv", 
function (face, pname, params, offset) {
var vec =  new android.opengl.OpenGLES10.Vector4f (java.util.Arrays.copyOfRange (params, offset, offset + 4));
switch (pname) {
case 4608:
this.openGLESState.setMaterialAmbient (vec);
break;
case 4609:
this.openGLESState.setMaterialDiffuse (vec);
break;
case 4610:
this.openGLESState.setMaterialSpecular (vec);
break;
case 5632:
this.openGLESState.setMaterialEmission (vec);
break;
case 5634:
this.openGLESState.setMaterialAmbient (vec);
this.openGLESState.setMaterialDiffuse (vec);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown material parameter " + pname);
break;
}
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glMaterialx", 
function (face, pname, param) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glMaterialxv", 
function (face, pname, params) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glMatrixMode", 
function (mode) {
this.matrixStack.setMatrixMode (mode);
}, "~N");
Clazz.defineMethod (c$, "glMultMatrixf", 
function (m, offset) {
this.matrixStack.multiply (java.util.Arrays.copyOfRange (m, offset, m.length));
}, "~A,~N");
Clazz.defineMethod (c$, "glMultMatrixx", 
function (m) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N");
Clazz.defineMethod (c$, "glMultiTexCoord4f", 
function (target, s, t, r, q) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glMultiTexCoord4x", 
function (target, s, t, r, q) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glNormal3f", 
function (nx, ny, nz) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glNormal3x", 
function (nx, ny, nz) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glNormalPointer", 
function (type, stride, pointer) {
this.openGLESState.setNormal (3, type, stride, pointer);
}, "~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glOrthof", 
function (left, right, bottom, top, zNear, zFar) {
this.matrixStack.ortho (left, right, bottom, top, zNear, zFar);
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glOrthox", 
function (left, right, bottom, top, zNear, zFar) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glPixelStorei", 
function (pname, param) {
this.glPixelStorei (pname, param);
}, "~N,~N");
Clazz.defineMethod (c$, "glPointSize", 
function (size) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N");
Clazz.defineMethod (c$, "glPointSizex", 
function (size) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N");
Clazz.defineMethod (c$, "glPolygonOffset", 
function (factor, units) {
this.glPolygonOffset (factor, units);
}, "~N,~N");
Clazz.defineMethod (c$, "glPolygonOffsetx", 
function (factor, units) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glPopMatrix", 
function () {
this.matrixStack.popMatrix ();
});
Clazz.defineMethod (c$, "glPushMatrix", 
function () {
this.matrixStack.pushMatrix ();
});
Clazz.defineMethod (c$, "glReadPixels", 
function (x, y, width, height, format, type, pixels) {
android.opengl.GLES20.glReadPixels (x, y, width, height, format, type, pixels);
}, "~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glRotatef", 
function (angle, x, y, z) {
this.matrixStack.rotate (-angle, x, y, z);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glRotatex", 
function (angle, x, y, z) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glSampleCoverage", 
function (value, invert) {
android.opengl.GLES20.glSampleCoverage (value, invert);
}, "~N,~B");
Clazz.defineMethod (c$, "glSampleCoveragex", 
function (value, invert) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glScalef", 
function (x, y, z) {
this.matrixStack.scale (x, y, z);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glScalex", 
function (x, y, z) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glScissor", 
function (x, y, width, height) {
android.opengl.GLES20.glScissor (x, y, width, height);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glShadeModel", 
function (mode) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N");
Clazz.defineMethod (c$, "glStencilFunc", 
function (func, ref, mask) {
android.opengl.GLES20.glStencilFunc (func, ref, mask);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glStencilMask", 
function (mask) {
android.opengl.GLES20.glStencilMask (mask);
}, "~N");
Clazz.defineMethod (c$, "glStencilOp", 
function (fail, zfail, zpass) {
android.opengl.GLES20.glStencilOp (fail, zfail, zpass);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexCoordPointer", 
function (size, type, stride, pointer) {
this.openGLESState.setTexCoord (size, type, stride, pointer);
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTexEnvf", 
function (target, pname, param) {
android.util.Log.d ("OpenGLES10Context", "Not implemented");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnvfv", 
function (target, pname, params) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A");
Clazz.defineMethod (c$, "glTexEnvx", 
function (target, pname, param) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnvxv", 
function (target, pname, params) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexImage2D", 
function (target, level, internalformat, width, height, border, format, type, pixels) {
this.openGLESState.setBoundTextureFormat (internalformat);
this.openGLESState.setTextureFormat ();
android.opengl.GLES20.glTexImage2D (target, level, internalformat, width, height, border, format, type, pixels);
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTexParameterf", 
function (target, pname, param) {
android.opengl.GLES20.glTexParameterf (target, pname, param);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexParameterx", 
function (target, pname, param) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexSubImage2D", 
function (target, level, xoffset, yoffset, width, height, format, type, pixels) {
android.opengl.GLES20.glTexSubImage2D (target, level, xoffset, yoffset, width, height, format, type, pixels);
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTranslatef", 
function (x, y, z) {
this.matrixStack.translate (x, y, z);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTranslatex", 
function (x, y, z) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glVertexPointer", 
function (size, type, stride, pointer) {
this.openGLESState.setPosition (size, type, stride, pointer);
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glViewport", 
function (x, y, width, height) {
android.opengl.GLES20.glViewport (x, y, width, height);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glBindBuffer", 
function (target, buffer) {
android.opengl.GLES20.glBindBuffer (target, buffer);
}, "~N,~N");
Clazz.defineMethod (c$, "glBufferData", 
function (target, size, data, usage) {
android.opengl.GLES20.glBufferData (target, size, data, usage);
}, "~N,~N,java.nio.Buffer,~N");
Clazz.defineMethod (c$, "glBufferSubData", 
function (target, offset, size, data) {
android.opengl.GLES20.glBufferSubData (target, offset, size, data);
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glClipPlanef", 
function (plane, equation, offset) {
var tranposeInverseModelViewMatrix =  new android.opengl.OpenGLES10.Matrix4x4f ();
tranposeInverseModelViewMatrix = android.opengl.OpenGLES10.OpenGLESMath.inverse (this.matrixStack.getModelViewMatrix ());
tranposeInverseModelViewMatrix = android.opengl.OpenGLES10.OpenGLESMath.transpose (tranposeInverseModelViewMatrix);
var clipPlane =  new android.opengl.OpenGLES10.Vector4f (java.util.Arrays.copyOfRange (equation, offset, offset + 4));
clipPlane = android.opengl.OpenGLES10.OpenGLESMath.multiply (tranposeInverseModelViewMatrix, clipPlane);
this.openGLESState.setClipPlane (plane - 12288, clipPlane);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glClipPlanex", 
function (plane, equation) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glColor4ub", 
function (red, green, blue, alpha) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDeleteBuffers", 
function (n, buffers, offset) {
android.opengl.GLES20.glDeleteBuffers (n, buffers, offset);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGenBuffers", 
function (n, buffers, offset) {
android.opengl.GLES20.glGenBuffers (n, buffers, offset);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetClipPlanef", 
function (pname, eqn) {
this.openGLESState.getClipPlane (pname - 12288, eqn);
}, "~N,~A");
Clazz.defineMethod (c$, "glGetFloatv", 
function (pname, params, offset) {
switch (pname) {
case 2982:
for (var i = 0; i < 16; i++) {
params[i] = this.matrixStack.getModelViewMatrix ().m[i];
}
break;
default:
android.opengl.GLES20.glGetFloatv (pname, params, offset);
break;
}
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetLightfv", 
function (light, pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetLightxv", 
function (light, pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetMaterialfv", 
function (face, pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetMaterialxv", 
function (face, pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexEnvfv", 
function (env, pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexEnviv", 
function (env, pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexEnvxv", 
function (env, pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexParameterfv", 
function (target, pname, params, offset) {
android.opengl.GLES20.glGetTexParameterfv (target, pname, params, offset);
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexParameteriv", 
function (target, pname, params, offset) {
android.opengl.GLES20.glGetTexParameteriv (target, pname, params, offset);
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexParameterxv", 
function (target, pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetBooleanv", 
function (pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetFixedv", 
function (pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetPointerv", 
function (pname, params) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~A");
Clazz.defineMethod (c$, "glIsBuffer", 
function (buffer) {
return android.opengl.GLES20.glIsBuffer (buffer);
}, "~N");
Clazz.defineMethod (c$, "glIsEnabled", 
function (cap) {
return android.opengl.GLES20.glIsEnabled (cap);
}, "~N");
Clazz.defineMethod (c$, "glIsTexture", 
function (texture) {
return android.opengl.GLES20.glIsTexture (texture);
}, "~N");
Clazz.defineMethod (c$, "glPointParameterf", 
function (pname, param) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glPointParameterfv", 
function (pname, params) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glPointParameterx", 
function (pname, param) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glPointParameterxv", 
function (pname, params) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N");
Clazz.defineMethod (c$, "glTexEnvi", 
function (target, pname, param) {
switch (pname) {
case 8704:
switch (param) {
case 8448:
case 260:
case 8449:
case 3042:
case 7681:
case 34160:
this.openGLESState.setTextureEnvMode (param);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown GL_TEXTURE_ENV_MODE parameter " + param);
break;
}
break;
case 34161:
switch (param) {
case 7681:
case 8448:
case 260:
case 34164:
case 34165:
case 34023:
case 34478:
case 34479:
this.openGLESState.setTextureEnvCombineRGB (param);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown GL_COMBINE_RGB parameter " + param);
break;
}
break;
case 34162:
switch (param) {
case 7681:
case 8448:
case 260:
case 34164:
case 34165:
case 34023:
this.openGLESState.setTextureEnvCombineAlpha (param);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown GL_COMBINE_ALPHA parameter " + param);
break;
}
break;
case 34176:
case 34177:
case 34178:
if (33984 <= param && param <= 34015) {
this.openGLESState.setTextureEnvSrcRGB (pname - 34176, param - 33984);
} else if (param == 5890) {
this.openGLESState.setTextureEnvSrcRGB (pname - 34176, this.openGLESState.getActiveTexture ());
} else {
this.openGLESState.setTextureEnvSrcRGB (pname - 34176, param);
}break;
case 34184:
case 34185:
case 34186:
if (33984 <= param && param <= 34015) {
this.openGLESState.setTextureEnvSrcAlpha (pname - 34184, param - 33984);
} else if (param == 5890) {
this.openGLESState.setTextureEnvSrcAlpha (pname - 34184, this.openGLESState.getActiveTexture ());
} else {
this.openGLESState.setTextureEnvSrcAlpha (pname - 34184, param);
}break;
case 34192:
case 34193:
case 34194:
this.openGLESState.setTextureEnvOperandRGB (pname - 34192, param);
break;
case 34200:
case 34201:
case 34202:
this.openGLESState.setTextureEnvOperandAlpha (pname - 34200, param);
break;
case 34163:
this.openGLESState.setTextureEnvRGBScale (param);
break;
case 3356:
this.openGLESState.setTextureEnvAlphaScale (param);
break;
default:
android.util.Log.d ("OpenGLES10Context", "ERROR: Unknown parameter " + pname);
break;
}
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnviv", 
function (target, pname, params, offset) {
android.util.Log.d ("OpenGLES10Context", "ERROR: Not implemented.");
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexParameteri", 
function (target, pname, param) {
android.opengl.GLES20.glTexParameteri (target, pname, param);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexParameteriv", 
function (target, pname, params, offset) {
android.opengl.GLES20.glTexParameteriv (target, pname, params, offset);
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glCurrentPaletteMatrixOES", 
function (matrixpaletteindex) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N");
Clazz.defineMethod (c$, "glLoadPaletteFromModelViewMatrixOES", 
function () {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
});
Clazz.defineMethod (c$, "glMatrixIndexPointerOES", 
function (size, type, stride, pointer) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N,~N,~N,~O");
Clazz.defineMethod (c$, "glWeightPointerOES", 
function (size, type, stride, pointer) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N,~N,~N,~O");
Clazz.defineMethod (c$, "glPointSizePointerOES", 
function (type, stride, pointer) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N,~N,~O");
Clazz.defineMethod (c$, "glDrawTexsOES", 
function (x, y, z, width, height) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexiOES", 
function (x, y, z, width, height) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexxOES", 
function (x, y, z, width, height) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexsvOES", 
function (coords) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N");
Clazz.defineMethod (c$, "glDrawTexivOES", 
function (coords) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N");
Clazz.defineMethod (c$, "glDrawTexxvOES", 
function (coords) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N");
Clazz.defineMethod (c$, "glDrawTexfOES", 
function (x, y, z, width, height) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexfvOES", 
function (coords) {
android.util.Log.d ("OpenGLES10Context", "WARNING: No effect in OpenGL ES 2.x");
}, "~N");
Clazz.defineMethod (c$, "getCachedShaderAmount", 
function () {
return this.openGLESState.getCachedShaderAmount ();
});
Clazz.defineMethod (c$, "prepareToDraw", 
($fz = function () {
var modelViewMatrix = this.matrixStack.getModelViewMatrix ();
this.openGLESState.setModelViewMatrix (modelViewMatrix);
var projectionMatrix = this.matrixStack.getProjectionMatrix ();
var mvp =  new android.opengl.OpenGLES10.Matrix4x4f ();
mvp = android.opengl.OpenGLES10.OpenGLESMath.multiply (modelViewMatrix, projectionMatrix);
this.openGLESState.setModelViewProjectionMatrix (mvp);
if (this.openGLESState.isNormal ()) {
var modelViewMatrix3x3 =  new android.opengl.OpenGLES10.Matrix3x3f ();
modelViewMatrix3x3 = android.opengl.OpenGLES10.OpenGLESMath.copyMatrix4x4UpperLeftToMatrix3x3 (modelViewMatrix);
modelViewMatrix3x3 = android.opengl.OpenGLES10.OpenGLESMath.adjoint (modelViewMatrix3x3);
modelViewMatrix3x3 = android.opengl.OpenGLES10.OpenGLESMath.transpose (modelViewMatrix3x3);
this.openGLESState.setTransposeAdjointModelViewMatrix (modelViewMatrix3x3);
if (this.openGLESState.isRescaleNormal ()) {
this.openGLESState.setRescaleNormalFactor ((1.0 / Math.sqrt (modelViewMatrix3x3.m[0] * modelViewMatrix3x3.m[0] + modelViewMatrix3x3.m[3] * modelViewMatrix3x3.m[3] + modelViewMatrix3x3.m[6] * modelViewMatrix3x3.m[6])));
}}for (var i = 0; i < this.maxTextureImageUnits; i++) {
if (this.openGLESState.isTexCoord (i)) {
var textureMatrix = this.matrixStack.getTextureMatrix (i);
this.openGLESState.setTextureMatrix (i, textureMatrix);
}}
this.openGLESState.setCurrentProgram ();
}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"TAG", "OpenGLES10Context");
});
