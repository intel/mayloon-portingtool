﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
c$ = Clazz.decorateAsClass (function () {
this.type = 0;
this.name = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "ShaderFile");
Clazz.makeConstructor (c$, 
function (type, name) {
this.name = name;
this.type = type;
}, "~N,~S");
Clazz.defineMethod (c$, "getType", 
function () {
return this.type;
});
Clazz.defineMethod (c$, "setType", 
function (t) {
this.type = t;
}, "~N");
Clazz.defineMethod (c$, "getName", 
function () {
return this.name;
});
