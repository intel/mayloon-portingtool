﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (null, "android.opengl.OpenGLES10.Attribute", ["android.opengl.GLES20"], function () {
c$ = Clazz.decorateAsClass (function () {
this.location = 0;
this.enabled = false;
this.uploaded = false;
this.size = 0;
this.type = 0;
this.normalized = false;
this.stride = 0;
this.ptr = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "Attribute");
Clazz.makeConstructor (c$, 
function () {
this.location = -1;
this.enabled = false;
this.uploaded = false;
});
Clazz.defineMethod (c$, "getLocation", 
function () {
return this.location;
});
Clazz.defineMethod (c$, "setEnabled", 
function (e) {
this.enabled = e;
}, "~B");
Clazz.defineMethod (c$, "setLocation", 
function (loc) {
this.location = loc;
}, "~N");
Clazz.defineMethod (c$, "upload", 
function (program) {
if (this.enabled) {
android.opengl.GLES20.glEnableVertexAttribArray (this.location);
if (!this.uploaded) {
program.setAttributeVertexPointer (this.location, this.size, this.type, this.normalized, this.stride, this.ptr);
this.uploaded = true;
}} else {
android.opengl.GLES20.glDisableVertexAttribArray (this.location);
}}, "android.opengl.OpenGLES10.ShaderProgram");
Clazz.defineMethod (c$, "setValues", 
function (s, t, st, p) {
this.size = s;
this.type = t;
this.stride = st;
this.ptr = p;
this.normalized = false;
this.uploaded = false;
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "setSize", 
function (s) {
this.size = s;
}, "~N");
Clazz.defineMethod (c$, "setType", 
function (t) {
this.type = t;
}, "~N");
Clazz.defineMethod (c$, "setNormalized", 
function (n) {
this.normalized = n;
}, "~B");
Clazz.defineMethod (c$, "setStride", 
function (s) {
this.stride = s;
}, "~N");
Clazz.defineMethod (c$, "setPointer", 
function (p) {
this.ptr = p;
}, "java.nio.Buffer");
});
