﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
c$ = Clazz.decorateAsClass (function () {
this.file = null;
this.additionalSource = null;
this.source = null;
this.sourceExpanded = false;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "ShaderSource");
Clazz.makeConstructor (c$, 
function (file) {
this.file = file;
this.additionalSource =  String.instantialize ();
this.sourceExpanded = false;
}, "android.opengl.OpenGLES10.ShaderFile");
Clazz.makeConstructor (c$, 
function (file, additionalSource) {
this.file = file;
this.additionalSource = additionalSource;
this.sourceExpanded = false;
}, "android.opengl.OpenGLES10.ShaderFile,~S");
Clazz.defineMethod (c$, "appendAdditionalSource", 
function (newAdditionalSource) {
this.additionalSource += newAdditionalSource;
this.sourceExpanded = false;
}, "~S");
Clazz.defineMethod (c$, "getFile", 
function () {
return this.file;
});
Clazz.defineMethod (c$, "getSource", 
function () {
if (!this.sourceExpanded) {
this.expandSource ();
}return this.source;
});
Clazz.defineMethod (c$, "expandSource", 
($fz = function () {
return true;
}, $fz.isPrivate = true, $fz));
