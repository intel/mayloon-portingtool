﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
c$ = Clazz.decorateAsClass (function () {
this.v = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "Vector3f");
Clazz.prepareFields (c$, function () {
this.v =  Clazz.newArray (9, 0);
});
Clazz.makeConstructor (c$, 
function () {
this.v[0] = 0;
this.v[1] = 0;
this.v[2] = 0;
});
Clazz.makeConstructor (c$, 
function (x, y, z) {
this.v[0] = x;
this.v[1] = y;
this.v[2] = z;
}, "~N,~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
this.v[0] = a[0];
this.v[1] = a[1];
this.v[2] = a[2];
}, "~A");
Clazz.makeConstructor (c$, 
function (other) {
this.v[0] = other.v[0];
this.v[1] = other.v[1];
this.v[2] = other.v[2];
}, "android.opengl.OpenGLES10.Vector3f");
Clazz.defineMethod (c$, "copyFrom", 
function (other) {
this.v[0] = other.v[0];
this.v[1] = other.v[1];
this.v[2] = other.v[2];
return this;
}, "android.opengl.OpenGLES10.Vector3f");
Clazz.defineMethod (c$, "equalsfloato", 
function (other) {
for (var i = 0; i < 3; i++) {
if (this.v[i] != other.v[i]) {
return false;
}}
return true;
}, "android.opengl.OpenGLES10.Vector3f");
Clazz.defineMethod (c$, "notEqualsfloato", 
function (other) {
return !this.equalsfloato (other);
}, "android.opengl.OpenGLES10.Vector3f");
Clazz.defineMethod (c$, "getItem", 
function (i) {
return this.v[i];
}, "~N");
Clazz.defineMethod (c$, "unaryNegation", 
function () {
return  new android.opengl.OpenGLES10.Vector3f (-this.v[0], -this.v[1], -this.v[2]);
});
Clazz.defineMethod (c$, "subtract", 
function (vec) {
return  new android.opengl.OpenGLES10.Vector3f (this.v[0] - vec.v[0], this.v[1] - vec.v[1], this.v[2] - vec.v[2]);
}, "android.opengl.OpenGLES10.Vector3f");
Clazz.defineMethod (c$, "add", 
function (vec) {
return  new android.opengl.OpenGLES10.Vector3f (this.v[0] + vec.v[0], this.v[1] + vec.v[1], this.v[2] + vec.v[2]);
}, "android.opengl.OpenGLES10.Vector3f");
Clazz.defineMethod (c$, "multiply", 
function (s) {
return  new android.opengl.OpenGLES10.Vector3f (this.v[0] * s, this.v[1] * s, this.v[2] * s);
}, "~N");
