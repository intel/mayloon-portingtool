﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (null, "android.opengl.OpenGLES10.Shader", ["android.opengl.GLES20", "android.util.Log", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.type = 0;
this.sources = null;
this.id = 0;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "Shader");
Clazz.makeConstructor (c$, 
function (type, sources) {
this.type = type;
this.sources =  new java.util.ArrayList (sources);
}, "~N,java.util.ArrayList");
Clazz.defineMethod (c$, "compile", 
function () {
this.id = android.opengl.GLES20.glCreateShader (this.type);
var typeString = this.type == 35632 ? "Fragment shader" : "Vertex shader";
if (this.id == 0) {
android.util.Log.e ("Shader", "ERROR: Could not create " + typeString);
return 0;
}if (!this.readShaderSource ()) {
android.util.Log.e ("Shader", "ERROR: Could not read " + typeString + " source.");
return 0;
}android.opengl.GLES20.glCompileShader (this.id);
var compiled =  Clazz.newArray (1, 0);
android.opengl.GLES20.glGetShaderiv (this.id, 35713, compiled, 0);
if (compiled[0] == 0) {
var infoLength =  Clazz.newArray (1, 0);
android.opengl.GLES20.glGetShaderiv (this.id, 35716, infoLength, 0);
if (infoLength[0] > 1) {
var infoLog = android.opengl.GLES20.glGetShaderInfoLog (this.id);
if (compiled[0] != 0) {
android.util.Log.w ("Shader", "WARNING: Compiled " + typeString + " with warnings:\n" + infoLog);
} else {
android.util.Log.e ("Shader", "ERROR: Compiling " + typeString + " failed:\n" + infoLog);
}}if (compiled[0] != 0) {
android.util.Log.d ("Shader", "Compiled " + typeString + " successfully.");
} else {
android.opengl.GLES20.glDeleteShader (this.id);
return 0;
}}return this.id;
});
Clazz.defineMethod (c$, "readShaderSource", 
($fz = function () {
var shaderSources = "";
for (var i = 0; i < this.sources.size (); i++) {
shaderSources += this.sources.get (i).getSource ();
}
android.opengl.GLES20.glShaderSource (this.id, shaderSources);
return true;
}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"TAG", "Shader");
});
