﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (null, "android.opengl.OpenGLES10.UniformBase", ["java.util.AbstractMap", "$.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.location = 0;
this.uploaded = false;
this.additionalRequiredShaderFiles = null;
this.father = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "UniformBase");
Clazz.makeConstructor (c$, 
function (location) {
this.additionalRequiredShaderFiles =  new java.util.ArrayList ();
this.location = location;
this.uploaded = false;
this.father = null;
}, "~N");
Clazz.defineMethod (c$, "setLocation", 
function (loc) {
this.location = loc;
this.uploaded = false;
}, "~N");
Clazz.defineMethod (c$, "getLocation", 
function () {
return this.location;
});
Clazz.defineMethod (c$, "addAdditionalRequiredShaderFile", 
function (key, additionalRequiredShaderFile) {
this.additionalRequiredShaderFiles.add ( new java.util.AbstractMap.SimpleEntry (new Integer (key), additionalRequiredShaderFile));
}, "~N,android.opengl.OpenGLES10.ShaderFile");
Clazz.defineMethod (c$, "setFather", 
function (f) {
this.father = f;
}, "android.opengl.OpenGLES10.UniformBase");
});
