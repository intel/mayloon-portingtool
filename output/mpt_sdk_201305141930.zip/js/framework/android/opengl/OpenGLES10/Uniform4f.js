﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (["android.opengl.OpenGLES10.UniformBase", "$.Vector4f"], "android.opengl.OpenGLES10.Uniform4f", ["java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.value = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "Uniform4f", android.opengl.OpenGLES10.UniformBase);
Clazz.prepareFields (c$, function () {
this.value =  new android.opengl.OpenGLES10.Vector4f ();
});
Clazz.makeConstructor (c$, 
function (x, y, z, w) {
Clazz.superConstructor (this, android.opengl.OpenGLES10.Uniform4f, [-1]);
this.value =  new android.opengl.OpenGLES10.Vector4f (x, y, z, w);
}, "~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (value) {
Clazz.superConstructor (this, android.opengl.OpenGLES10.Uniform4f, [-1]);
this.value.copyFrom (value);
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.opengl.OpenGLES10.Uniform4f, [-1]);
});
Clazz.defineMethod (c$, "setValue", 
function (val) {
this.uploaded = false;
this.value.copyFrom (val);
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "getValue", 
function () {
return this.value;
});
Clazz.overrideMethod (c$, "upload", 
function (program) {
if (!this.uploaded) {
program.setUniform4fv (this.location, 1, this.value.v);
this.uploaded = true;
}}, "android.opengl.OpenGLES10.ShaderProgram");
Clazz.overrideMethod (c$, "getAdditionalRequiredShaderFiles", 
function () {
var shaderFiles =  new java.util.ArrayList ();
for (var i = 0; i < this.additionalRequiredShaderFiles.size (); i++) {
if (this.father == null || (((this.father)).getValue ()).booleanValue ()) {
shaderFiles.add (this.additionalRequiredShaderFiles.get (i).getValue ());
}}
return shaderFiles;
});
});
