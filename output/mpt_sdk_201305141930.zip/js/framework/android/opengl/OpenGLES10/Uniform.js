﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (["android.opengl.OpenGLES10.UniformBase"], "android.opengl.OpenGLES10.Uniform", ["java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.value = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "Uniform", android.opengl.OpenGLES10.UniformBase);
Clazz.makeConstructor (c$, 
function (value) {
Clazz.superConstructor (this, android.opengl.OpenGLES10.Uniform, [-1]);
this.value = value;
}, "~O");
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.opengl.OpenGLES10.Uniform, [-1]);
});
Clazz.defineMethod (c$, "setValue", 
function (val) {
if (this.value !== val) {
this.uploaded = false;
this.value = val;
}}, "~O");
Clazz.defineMethod (c$, "getValue", 
function () {
return this.value;
});
Clazz.overrideMethod (c$, "getAdditionalRequiredShaderFiles", 
function () {
var shaderFiles =  new java.util.ArrayList ();
for (var i = 0; i < this.additionalRequiredShaderFiles.size (); i++) {
if (this.father == null || (((this.father)).getValue ()).booleanValue ()) {
shaderFiles.add (this.additionalRequiredShaderFiles.get (i).getValue ());
}}
return shaderFiles;
});
Clazz.overrideMethod (c$, "upload", 
function (program) {
if (this.uploaded) return ;
if (Clazz.instanceOf (this.value, Boolean)) {
program.setUniform1i (this.location, this.value ? 1 : 0);
this.uploaded = true;
return ;
}if (Clazz.instanceOf (this.value, Integer)) {
program.setUniform1i (this.location, (this.value).intValue ());
this.uploaded = true;
return ;
}if (Clazz.instanceOf (this.value, Float)) {
program.setUniform1f (this.location, (this.value).floatValue ());
this.uploaded = true;
return ;
}if (Clazz.instanceOf (this.value, android.opengl.OpenGLES10.Matrix3x3f)) {
var tmp = this.value;
program.setUniformMatrix3fv (this.location, tmp.m);
this.uploaded = true;
return ;
}if (Clazz.instanceOf (this.value, android.opengl.OpenGLES10.Matrix4x4f)) {
var tmp = this.value;
program.setUniformMatrix4fv (this.location, tmp.m);
this.uploaded = true;
return ;
}}, "android.opengl.OpenGLES10.ShaderProgram");
});
