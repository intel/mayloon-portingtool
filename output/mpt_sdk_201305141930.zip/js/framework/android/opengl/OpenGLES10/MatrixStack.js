﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
Clazz.load (["java.util.ArrayList"], "android.opengl.OpenGLES10.MatrixStack", ["android.opengl.OpenGLES10.Matrix4x4f", "$.OpenGLESMath", "android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.openGLESState = null;
this.context = null;
this.mode = 0;
this.modelViewStack = null;
this.projectionStack = null;
this.textureStacks = null;
this.currentStack = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "MatrixStack");
Clazz.prepareFields (c$, function () {
this.modelViewStack =  new java.util.ArrayList ();
this.projectionStack =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
function (s, context) {
this.openGLESState = s;
this.context = context;
}, "android.opengl.OpenGLES10.OpenGLESState,android.opengl.OpenGLES10.OpenGLES10Context");
Clazz.defineMethod (c$, "dispose", 
function () {
this.modelViewStack = null;
this.projectionStack = null;
this.textureStacks = null;
});
Clazz.defineMethod (c$, "init", 
function () {
this.modelViewStack.add ( new android.opengl.OpenGLES10.Matrix4x4f ());
this.modelViewStack.set (0, android.opengl.OpenGLES10.OpenGLESMath.loadIdentity (this.modelViewStack.get (0)));
this.projectionStack.add ( new android.opengl.OpenGLES10.Matrix4x4f ());
this.projectionStack.set (0, android.opengl.OpenGLES10.OpenGLESMath.loadIdentity (this.projectionStack.get (0)));
this.textureStacks =  new java.util.ArrayList (this.context.maxTextureImageUnits);
for (var i = 0; i < this.context.maxTextureImageUnits; i++) {
this.textureStacks.get (i).add ( new android.opengl.OpenGLES10.Matrix4x4f ());
this.textureStacks.get (i).set (0, android.opengl.OpenGLES10.OpenGLESMath.loadIdentity (this.textureStacks.get (i).get (0)));
}
this.currentStack = this.modelViewStack;
});
Clazz.defineMethod (c$, "setMatrixMode", 
function (m) {
this.mode = m;
switch (this.mode) {
case 5888:
this.currentStack = this.modelViewStack;
break;
case 5889:
this.currentStack = this.projectionStack;
break;
case 5890:
this.currentStack = this.textureStacks.get (this.openGLESState.getActiveTexture ());
this.openGLESState.setTextureMatrix (this.openGLESState.getActiveTexture (), true);
break;
default:
android.util.Log.d ("MatrixStack", "ERROR: Unknown matrix mode.");
break;
}
}, "~N");
Clazz.defineMethod (c$, "pushMatrix", 
function () {
this.currentStack.add ( new android.opengl.OpenGLES10.Matrix4x4f (this.currentStack.get (this.currentStack.size () - 1)));
});
Clazz.defineMethod (c$, "popMatrix", 
function () {
this.currentStack.remove (this.currentStack.size () - 1);
});
Clazz.defineMethod (c$, "loadIdentity", 
function () {
this.currentStack.set (this.currentStack.size () - 1, android.opengl.OpenGLES10.OpenGLESMath.loadIdentity (this.currentStack.get (this.currentStack.size () - 1)));
});
Clazz.defineMethod (c$, "loadMatrix", 
function (m) {
var mat = this.currentStack.get (this.currentStack.size () - 1);
mat.copyFrom (m);
this.currentStack.set (this.currentStack.size () - 1, mat);
}, "~A");
Clazz.defineMethod (c$, "translate", 
function (x, y, z) {
this.currentStack.set (this.currentStack.size () - 1, android.opengl.OpenGLES10.OpenGLESMath.translate (this.currentStack.get (this.currentStack.size () - 1), x, y, z));
}, "~N,~N,~N");
Clazz.defineMethod (c$, "rotate", 
function (angle, x, y, z) {
this.currentStack.set (this.currentStack.size () - 1, android.opengl.OpenGLES10.OpenGLESMath.rotate (this.currentStack.get (this.currentStack.size () - 1), angle, x, y, z));
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "scale", 
function (x, y, z) {
this.currentStack.set (this.currentStack.size () - 1, android.opengl.OpenGLES10.OpenGLESMath.scale (this.currentStack.get (this.currentStack.size () - 1), x, y, z));
}, "~N,~N,~N");
Clazz.defineMethod (c$, "frustum", 
function (left, right, bottom, top, zNear, zFar) {
this.currentStack.set (this.currentStack.size () - 1, android.opengl.OpenGLES10.OpenGLESMath.frustum (this.currentStack.get (this.currentStack.size () - 1), left, right, bottom, top, zNear, zFar));
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "ortho", 
function (left, right, bottom, top, zNear, zFar) {
this.currentStack.set (this.currentStack.size () - 1, android.opengl.OpenGLES10.OpenGLESMath.ortho (this.currentStack.get (this.currentStack.size () - 1), left, right, bottom, top, zNear, zFar));
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "multiply", 
function (m) {
this.currentStack.set (this.currentStack.size () - 1, android.opengl.OpenGLES10.OpenGLESMath.multiply (this.currentStack.get (this.currentStack.size () - 1), m));
}, "~A");
Clazz.defineMethod (c$, "getModelViewMatrix", 
function () {
return this.modelViewStack.get (this.modelViewStack.size () - 1);
});
Clazz.defineMethod (c$, "getProjectionMatrix", 
function () {
return this.projectionStack.get (this.projectionStack.size () - 1);
});
Clazz.defineMethod (c$, "getTextureMatrix", 
function (index) {
var matrix = this.textureStacks.get (index);
return matrix.get (matrix.size () - 1);
}, "~N");
});
