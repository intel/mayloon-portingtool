﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
c$ = Clazz.decorateAsClass (function () {
this.id = 0;
this.location = 0;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "UniformSimple");
Clazz.makeConstructor (c$, 
function (id, location) {
this.id = id;
this.location = location;
}, "~N,~N");
Clazz.defineMethod (c$, "getId", 
function () {
return this.id;
});
Clazz.defineMethod (c$, "getLocation", 
function () {
return this.location;
});
