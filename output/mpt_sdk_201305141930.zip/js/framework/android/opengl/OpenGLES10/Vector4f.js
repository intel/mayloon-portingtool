﻿Clazz.declarePackage ("android.opengl.OpenGLES10");
c$ = Clazz.decorateAsClass (function () {
this.v = null;
Clazz.instantialize (this, arguments);
}, android.opengl.OpenGLES10, "Vector4f");
Clazz.prepareFields (c$, function () {
this.v =  Clazz.newArray (4, 0);
});
Clazz.makeConstructor (c$, 
function () {
this.v[0] = 0;
this.v[1] = 0;
this.v[2] = 0;
this.v[3] = 0;
});
Clazz.makeConstructor (c$, 
function (x, y, z, w) {
this.v[0] = x;
this.v[1] = y;
this.v[2] = z;
this.v[3] = w;
}, "~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
this.v[0] = a[0];
this.v[1] = a[1];
this.v[2] = a[2];
this.v[3] = a[3];
}, "~A");
Clazz.makeConstructor (c$, 
function (other) {
this.v[0] = other.v[0];
this.v[1] = other.v[1];
this.v[2] = other.v[2];
this.v[3] = other.v[3];
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "copyFrom", 
function (other) {
this.v[0] = other.v[0];
this.v[1] = other.v[1];
this.v[2] = other.v[2];
this.v[3] = other.v[3];
return this;
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "equalsfloato", 
function (other) {
for (var i = 0; i < 4; i++) {
if (this.v[i] != other.v[i]) {
return false;
}}
return true;
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "notEqualsfloato", 
function (other) {
return !this.equalsfloato (other);
}, "android.opengl.OpenGLES10.Vector4f");
Clazz.defineMethod (c$, "getItem", 
function (i) {
return this.v[i];
}, "~N");
