﻿Clazz.declarePackage ("android.opengl");
Clazz.load (["android.opengl.GLWrapperBase"], "android.opengl.GLErrorWrapper", ["android.opengl.GLException", "java.lang.Thread"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mCheckError = false;
this.mCheckThread = false;
this.mOurThread = null;
Clazz.instantialize (this, arguments);
}, android.opengl, "GLErrorWrapper", android.opengl.GLWrapperBase);
Clazz.makeConstructor (c$, 
function (gl, configFlags) {
Clazz.superConstructor (this, android.opengl.GLErrorWrapper, [gl]);
this.mCheckError = (configFlags & 1) != 0;
this.mCheckThread = (configFlags & 2) != 0;
}, "javax.microedition.khronos.opengles.GL,~N");
Clazz.defineMethod (c$, "checkThread", 
($fz = function () {
if (this.mCheckThread) {
var currentThread = Thread.currentThread ();
if (this.mOurThread == null) {
this.mOurThread = currentThread;
} else {
if (!this.mOurThread.equals (currentThread)) {
throw  new android.opengl.GLException (28672, "OpenGL method called from wrong thread.");
}}}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "checkError", 
($fz = function () {
if (this.mCheckError) {
var glError;
if ((glError = this.mgl.glGetError ()) != 0) {
throw  new android.opengl.GLException (glError);
}}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "glActiveTexture", 
function (texture) {
this.checkThread ();
this.mgl.glActiveTexture (texture);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glAlphaFunc", 
function (func, ref) {
this.checkThread ();
this.mgl.glAlphaFunc (func, ref);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glAlphaFuncx", 
function (func, ref) {
this.checkThread ();
this.mgl.glAlphaFuncx (func, ref);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glBindTexture", 
function (target, texture) {
this.checkThread ();
this.mgl.glBindTexture (target, texture);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glBlendFunc", 
function (sfactor, dfactor) {
this.checkThread ();
this.mgl.glBlendFunc (sfactor, dfactor);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glClear", 
function (mask) {
this.checkThread ();
this.mgl.glClear (mask);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glClearColor", 
function (red, green, blue, alpha) {
this.checkThread ();
this.mgl.glClearColor (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glClearColorx", 
function (red, green, blue, alpha) {
this.checkThread ();
this.mgl.glClearColorx (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glClearDepthf", 
function (depth) {
this.checkThread ();
this.mgl.glClearDepthf (depth);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glClearDepthx", 
function (depth) {
this.checkThread ();
this.mgl.glClearDepthx (depth);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glClearStencil", 
function (s) {
this.checkThread ();
this.mgl.glClearStencil (s);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glClientActiveTexture", 
function (texture) {
this.checkThread ();
this.mgl.glClientActiveTexture (texture);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glColor4f", 
function (red, green, blue, alpha) {
this.checkThread ();
this.mgl.glColor4f (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glColor4x", 
function (red, green, blue, alpha) {
this.checkThread ();
this.mgl.glColor4x (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glColorMask", 
function (red, green, blue, alpha) {
this.checkThread ();
this.mgl.glColorMask (red, green, blue, alpha);
this.checkError ();
}, "~B,~B,~B,~B");
Clazz.defineMethod (c$, "glColorPointer", 
function (size, type, stride, pointer) {
this.checkThread ();
this.mgl.glColorPointer (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glCompressedTexImage2D", 
function (target, level, internalformat, width, height, border, imageSize, data) {
this.checkThread ();
this.mgl.glCompressedTexImage2D (target, level, internalformat, width, height, border, imageSize, data);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glCompressedTexSubImage2D", 
function (target, level, xoffset, yoffset, width, height, format, imageSize, data) {
this.checkThread ();
this.mgl.glCompressedTexSubImage2D (target, level, xoffset, yoffset, width, height, format, imageSize, data);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glCopyTexImage2D", 
function (target, level, internalformat, x, y, width, height, border) {
this.checkThread ();
this.mgl.glCopyTexImage2D (target, level, internalformat, x, y, width, height, border);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glCopyTexSubImage2D", 
function (target, level, xoffset, yoffset, x, y, width, height) {
this.checkThread ();
this.mgl.glCopyTexSubImage2D (target, level, xoffset, yoffset, x, y, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glCullFace", 
function (mode) {
this.checkThread ();
this.mgl.glCullFace (mode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glDeleteTextures", 
function (n, textures, offset) {
this.checkThread ();
this.mgl.glDeleteTextures (n, textures, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glDeleteTextures", 
function (n, textures) {
this.checkThread ();
this.mgl.glDeleteTextures (n, textures);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glDepthFunc", 
function (func) {
this.checkThread ();
this.mgl.glDepthFunc (func);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glDepthMask", 
function (flag) {
this.checkThread ();
this.mgl.glDepthMask (flag);
this.checkError ();
}, "~B");
Clazz.defineMethod (c$, "glDepthRangef", 
function (near, far) {
this.checkThread ();
this.mgl.glDepthRangef (near, far);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glDepthRangex", 
function (near, far) {
this.checkThread ();
this.mgl.glDepthRangex (near, far);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glDisable", 
function (cap) {
this.checkThread ();
this.mgl.glDisable (cap);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glDisableClientState", 
function (array) {
this.checkThread ();
this.mgl.glDisableClientState (array);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glDrawArrays", 
function (mode, first, count) {
this.checkThread ();
this.mgl.glDrawArrays (mode, first, count);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glDrawElements", 
function (mode, count, type, indices) {
this.checkThread ();
this.mgl.glDrawElements (mode, count, type, indices);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glEnable", 
function (cap) {
this.checkThread ();
this.mgl.glEnable (cap);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glEnableClientState", 
function (array) {
this.checkThread ();
this.mgl.glEnableClientState (array);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glFinish", 
function () {
this.checkThread ();
this.mgl.glFinish ();
this.checkError ();
});
Clazz.defineMethod (c$, "glFlush", 
function () {
this.checkThread ();
this.mgl.glFlush ();
this.checkError ();
});
Clazz.defineMethod (c$, "glFogf", 
function (pname, param) {
this.checkThread ();
this.mgl.glFogf (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glFogfv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl.glFogfv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glFogfv", 
function (pname, params) {
this.checkThread ();
this.mgl.glFogfv (pname, params);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glFogx", 
function (pname, param) {
this.checkThread ();
this.mgl.glFogx (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glFogxv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl.glFogxv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glFogxv", 
function (pname, params) {
this.checkThread ();
this.mgl.glFogxv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glFrontFace", 
function (mode) {
this.checkThread ();
this.mgl.glFrontFace (mode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glFrustumf", 
function (left, right, bottom, top, near, far) {
this.checkThread ();
this.mgl.glFrustumf (left, right, bottom, top, near, far);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glFrustumx", 
function (left, right, bottom, top, near, far) {
this.checkThread ();
this.mgl.glFrustumx (left, right, bottom, top, near, far);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glGenTextures", 
function (n, textures, offset) {
this.checkThread ();
this.mgl.glGenTextures (n, textures, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGenTextures", 
function (n, textures) {
this.checkThread ();
this.mgl.glGenTextures (n, textures);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetError", 
function () {
this.checkThread ();
var result = this.mgl.glGetError ();
return result;
});
Clazz.defineMethod (c$, "glGetIntegerv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl.glGetIntegerv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetIntegerv", 
function (pname, params) {
this.checkThread ();
this.mgl.glGetIntegerv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetString", 
function (name) {
this.checkThread ();
var result = this.mgl.glGetString (name);
this.checkError ();
return result;
}, "~N");
Clazz.defineMethod (c$, "glHint", 
function (target, mode) {
this.checkThread ();
this.mgl.glHint (target, mode);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glLightModelf", 
function (pname, param) {
this.checkThread ();
this.mgl.glLightModelf (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glLightModelfv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl.glLightModelfv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glLightModelfv", 
function (pname, params) {
this.checkThread ();
this.mgl.glLightModelfv (pname, params);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glLightModelx", 
function (pname, param) {
this.checkThread ();
this.mgl.glLightModelx (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glLightModelxv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl.glLightModelxv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glLightModelxv", 
function (pname, params) {
this.checkThread ();
this.mgl.glLightModelxv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glLightf", 
function (light, pname, param) {
this.checkThread ();
this.mgl.glLightf (light, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glLightfv", 
function (light, pname, params, offset) {
this.checkThread ();
this.mgl.glLightfv (light, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glLightfv", 
function (light, pname, params) {
this.checkThread ();
this.mgl.glLightfv (light, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glLightx", 
function (light, pname, param) {
this.checkThread ();
this.mgl.glLightx (light, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glLightxv", 
function (light, pname, params, offset) {
this.checkThread ();
this.mgl.glLightxv (light, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glLightxv", 
function (light, pname, params) {
this.checkThread ();
this.mgl.glLightxv (light, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glLineWidth", 
function (width) {
this.checkThread ();
this.mgl.glLineWidth (width);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glLineWidthx", 
function (width) {
this.checkThread ();
this.mgl.glLineWidthx (width);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glLoadIdentity", 
function () {
this.checkThread ();
this.mgl.glLoadIdentity ();
this.checkError ();
});
Clazz.defineMethod (c$, "glLoadMatrixf", 
function (m, offset) {
this.checkThread ();
this.mgl.glLoadMatrixf (m, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glLoadMatrixf", 
function (m) {
this.checkThread ();
this.mgl.glLoadMatrixf (m);
this.checkError ();
}, "java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glLoadMatrixx", 
function (m, offset) {
this.checkThread ();
this.mgl.glLoadMatrixx (m, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glLoadMatrixx", 
function (m) {
this.checkThread ();
this.mgl.glLoadMatrixx (m);
this.checkError ();
}, "java.nio.IntBuffer");
Clazz.defineMethod (c$, "glLogicOp", 
function (opcode) {
this.checkThread ();
this.mgl.glLogicOp (opcode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glMaterialf", 
function (face, pname, param) {
this.checkThread ();
this.mgl.glMaterialf (face, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glMaterialfv", 
function (face, pname, params, offset) {
this.checkThread ();
this.mgl.glMaterialfv (face, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glMaterialfv", 
function (face, pname, params) {
this.checkThread ();
this.mgl.glMaterialfv (face, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glMaterialx", 
function (face, pname, param) {
this.checkThread ();
this.mgl.glMaterialx (face, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glMaterialxv", 
function (face, pname, params, offset) {
this.checkThread ();
this.mgl.glMaterialxv (face, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glMaterialxv", 
function (face, pname, params) {
this.checkThread ();
this.mgl.glMaterialxv (face, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glMatrixMode", 
function (mode) {
this.checkThread ();
this.mgl.glMatrixMode (mode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glMultMatrixf", 
function (m, offset) {
this.checkThread ();
this.mgl.glMultMatrixf (m, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glMultMatrixf", 
function (m) {
this.checkThread ();
this.mgl.glMultMatrixf (m);
this.checkError ();
}, "java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glMultMatrixx", 
function (m, offset) {
this.checkThread ();
this.mgl.glMultMatrixx (m, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glMultMatrixx", 
function (m) {
this.checkThread ();
this.mgl.glMultMatrixx (m);
this.checkError ();
}, "java.nio.IntBuffer");
Clazz.defineMethod (c$, "glMultiTexCoord4f", 
function (target, s, t, r, q) {
this.checkThread ();
this.mgl.glMultiTexCoord4f (target, s, t, r, q);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glMultiTexCoord4x", 
function (target, s, t, r, q) {
this.checkThread ();
this.mgl.glMultiTexCoord4x (target, s, t, r, q);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glNormal3f", 
function (nx, ny, nz) {
this.checkThread ();
this.mgl.glNormal3f (nx, ny, nz);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glNormal3x", 
function (nx, ny, nz) {
this.checkThread ();
this.mgl.glNormal3x (nx, ny, nz);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glNormalPointer", 
function (type, stride, pointer) {
this.checkThread ();
this.mgl.glNormalPointer (type, stride, pointer);
this.checkError ();
}, "~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glOrthof", 
function (left, right, bottom, top, near, far) {
this.checkThread ();
this.mgl.glOrthof (left, right, bottom, top, near, far);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glOrthox", 
function (left, right, bottom, top, near, far) {
this.checkThread ();
this.mgl.glOrthox (left, right, bottom, top, near, far);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glPixelStorei", 
function (pname, param) {
this.checkThread ();
this.mgl.glPixelStorei (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPointSize", 
function (size) {
this.checkThread ();
this.mgl.glPointSize (size);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glPointSizex", 
function (size) {
this.checkThread ();
this.mgl.glPointSizex (size);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glPolygonOffset", 
function (factor, units) {
this.checkThread ();
this.mgl.glPolygonOffset (factor, units);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPolygonOffsetx", 
function (factor, units) {
this.checkThread ();
this.mgl.glPolygonOffsetx (factor, units);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPopMatrix", 
function () {
this.checkThread ();
this.mgl.glPopMatrix ();
this.checkError ();
});
Clazz.defineMethod (c$, "glPushMatrix", 
function () {
this.checkThread ();
this.mgl.glPushMatrix ();
this.checkError ();
});
Clazz.defineMethod (c$, "glReadPixels", 
function (x, y, width, height, format, type, pixels) {
this.checkThread ();
this.mgl.glReadPixels (x, y, width, height, format, type, pixels);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glRotatef", 
function (angle, x, y, z) {
this.checkThread ();
this.mgl.glRotatef (angle, x, y, z);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glRotatex", 
function (angle, x, y, z) {
this.checkThread ();
this.mgl.glRotatex (angle, x, y, z);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glSampleCoverage", 
function (value, invert) {
this.checkThread ();
this.mgl.glSampleCoverage (value, invert);
this.checkError ();
}, "~N,~B");
Clazz.defineMethod (c$, "glSampleCoveragex", 
function (value, invert) {
this.checkThread ();
this.mgl.glSampleCoveragex (value, invert);
this.checkError ();
}, "~N,~B");
Clazz.defineMethod (c$, "glScalef", 
function (x, y, z) {
this.checkThread ();
this.mgl.glScalef (x, y, z);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glScalex", 
function (x, y, z) {
this.checkThread ();
this.mgl.glScalex (x, y, z);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glScissor", 
function (x, y, width, height) {
this.checkThread ();
this.mgl.glScissor (x, y, width, height);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glShadeModel", 
function (mode) {
this.checkThread ();
this.mgl.glShadeModel (mode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glStencilFunc", 
function (func, ref, mask) {
this.checkThread ();
this.mgl.glStencilFunc (func, ref, mask);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glStencilMask", 
function (mask) {
this.checkThread ();
this.mgl.glStencilMask (mask);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glStencilOp", 
function (fail, zfail, zpass) {
this.checkThread ();
this.mgl.glStencilOp (fail, zfail, zpass);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexCoordPointer", 
function (size, type, stride, pointer) {
this.checkThread ();
this.mgl.glTexCoordPointer (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTexEnvf", 
function (target, pname, param) {
this.checkThread ();
this.mgl.glTexEnvf (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnvfv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl.glTexEnvfv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexEnvfv", 
function (target, pname, params) {
this.checkThread ();
this.mgl.glTexEnvfv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glTexEnvx", 
function (target, pname, param) {
this.checkThread ();
this.mgl.glTexEnvx (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnvxv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl.glTexEnvxv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexEnvxv", 
function (target, pname, params) {
this.checkThread ();
this.mgl.glTexEnvxv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glTexImage2D", 
function (target, level, internalformat, width, height, border, format, type, pixels) {
this.checkThread ();
this.mgl.glTexImage2D (target, level, internalformat, width, height, border, format, type, pixels);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTexParameterf", 
function (target, pname, param) {
this.checkThread ();
this.mgl.glTexParameterf (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexParameterx", 
function (target, pname, param) {
this.checkThread ();
this.mgl.glTexParameterx (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexParameteriv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl11.glTexParameteriv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexParameteriv", 
function (target, pname, params) {
this.checkThread ();
this.mgl11.glTexParameteriv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glTexSubImage2D", 
function (target, level, xoffset, yoffset, width, height, format, type, pixels) {
this.checkThread ();
this.mgl.glTexSubImage2D (target, level, xoffset, yoffset, width, height, format, type, pixels);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTranslatef", 
function (x, y, z) {
this.checkThread ();
this.mgl.glTranslatef (x, y, z);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTranslatex", 
function (x, y, z) {
this.checkThread ();
this.mgl.glTranslatex (x, y, z);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glVertexPointer", 
function (size, type, stride, pointer) {
this.checkThread ();
this.mgl.glVertexPointer (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glViewport", 
function (x, y, width, height) {
this.checkThread ();
this.mgl.glViewport (x, y, width, height);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glClipPlanef", 
function (plane, equation, offset) {
this.checkThread ();
this.mgl11.glClipPlanef (plane, equation, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glClipPlanef", 
function (plane, equation) {
this.checkThread ();
this.mgl11.glClipPlanef (plane, equation);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glClipPlanex", 
function (plane, equation, offset) {
this.checkThread ();
this.mgl11.glClipPlanex (plane, equation, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glClipPlanex", 
function (plane, equation) {
this.checkThread ();
this.mgl11.glClipPlanex (plane, equation);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glDrawTexfOES", 
function (x, y, z, width, height) {
this.checkThread ();
this.mgl11Ext.glDrawTexfOES (x, y, z, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexfvOES", 
function (coords, offset) {
this.checkThread ();
this.mgl11Ext.glDrawTexfvOES (coords, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glDrawTexfvOES", 
function (coords) {
this.checkThread ();
this.mgl11Ext.glDrawTexfvOES (coords);
this.checkError ();
}, "java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glDrawTexiOES", 
function (x, y, z, width, height) {
this.checkThread ();
this.mgl11Ext.glDrawTexiOES (x, y, z, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexivOES", 
function (coords, offset) {
this.checkThread ();
this.mgl11Ext.glDrawTexivOES (coords, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glDrawTexivOES", 
function (coords) {
this.checkThread ();
this.mgl11Ext.glDrawTexivOES (coords);
this.checkError ();
}, "java.nio.IntBuffer");
Clazz.defineMethod (c$, "glDrawTexsOES", 
function (x, y, z, width, height) {
this.checkThread ();
this.mgl11Ext.glDrawTexsOES (x, y, z, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexsvOES", 
function (coords, offset) {
this.checkThread ();
this.mgl11Ext.glDrawTexsvOES (coords, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glDrawTexsvOES", 
function (coords) {
this.checkThread ();
this.mgl11Ext.glDrawTexsvOES (coords);
this.checkError ();
}, "java.nio.ShortBuffer");
Clazz.defineMethod (c$, "glDrawTexxOES", 
function (x, y, z, width, height) {
this.checkThread ();
this.mgl11Ext.glDrawTexxOES (x, y, z, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexxvOES", 
function (coords, offset) {
this.checkThread ();
this.mgl11Ext.glDrawTexxvOES (coords, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glDrawTexxvOES", 
function (coords) {
this.checkThread ();
this.mgl11Ext.glDrawTexxvOES (coords);
this.checkError ();
}, "java.nio.IntBuffer");
Clazz.defineMethod (c$, "glQueryMatrixxOES", 
function (mantissa, mantissaOffset, exponent, exponentOffset) {
this.checkThread ();
var valid = this.mgl10Ext.glQueryMatrixxOES (mantissa, mantissaOffset, exponent, exponentOffset);
this.checkError ();
return valid;
}, "~A,~N,~A,~N");
Clazz.defineMethod (c$, "glQueryMatrixxOES", 
function (mantissa, exponent) {
this.checkThread ();
var valid = this.mgl10Ext.glQueryMatrixxOES (mantissa, exponent);
this.checkError ();
return valid;
}, "java.nio.IntBuffer,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glBindBuffer", 
function (target, buffer) {
this.checkThread ();
this.mgl11.glBindBuffer (target, buffer);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glBufferData", 
function (target, size, data, usage) {
this.checkThread ();
this.mgl11.glBufferData (target, size, data, usage);
this.checkError ();
}, "~N,~N,java.nio.Buffer,~N");
Clazz.defineMethod (c$, "glBufferSubData", 
function (target, offset, size, data) {
this.checkThread ();
this.mgl11.glBufferSubData (target, offset, size, data);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glColor4ub", 
function (red, green, blue, alpha) {
this.checkThread ();
this.mgl11.glColor4ub (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glColorPointer", 
function (size, type, stride, offset) {
this.checkThread ();
this.mgl11.glColorPointer (size, type, stride, offset);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDeleteBuffers", 
function (n, buffers, offset) {
this.checkThread ();
this.mgl11.glDeleteBuffers (n, buffers, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glDeleteBuffers", 
function (n, buffers) {
this.checkThread ();
this.mgl11.glDeleteBuffers (n, buffers);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glDrawElements", 
function (mode, count, type, offset) {
this.checkThread ();
this.mgl11.glDrawElements (mode, count, type, offset);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glGenBuffers", 
function (n, buffers, offset) {
this.checkThread ();
this.mgl11.glGenBuffers (n, buffers, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGenBuffers", 
function (n, buffers) {
this.checkThread ();
this.mgl11.glGenBuffers (n, buffers);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetBooleanv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl11.glGetBooleanv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetBooleanv", 
function (pname, params) {
this.checkThread ();
this.mgl11.glGetBooleanv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetBufferParameteriv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetBufferParameteriv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetBufferParameteriv", 
function (target, pname, params) {
this.checkThread ();
this.mgl11.glGetBufferParameteriv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetClipPlanef", 
function (pname, eqn, offset) {
this.checkThread ();
this.mgl11.glGetClipPlanef (pname, eqn, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetClipPlanef", 
function (pname, eqn) {
this.checkThread ();
this.mgl11.glGetClipPlanef (pname, eqn);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetClipPlanex", 
function (pname, eqn, offset) {
this.checkThread ();
this.mgl11.glGetClipPlanex (pname, eqn, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetClipPlanex", 
function (pname, eqn) {
this.checkThread ();
this.mgl11.glGetClipPlanex (pname, eqn);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetFixedv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl11.glGetFixedv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetFixedv", 
function (pname, params) {
this.checkThread ();
this.mgl11.glGetFixedv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetFloatv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl11.glGetFloatv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetFloatv", 
function (pname, params) {
this.checkThread ();
this.mgl11.glGetFloatv (pname, params);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetLightfv", 
function (light, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetLightfv (light, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetLightfv", 
function (light, pname, params) {
this.checkThread ();
this.mgl11.glGetLightfv (light, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetLightxv", 
function (light, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetLightxv (light, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetLightxv", 
function (light, pname, params) {
this.checkThread ();
this.mgl11.glGetLightxv (light, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetMaterialfv", 
function (face, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetMaterialfv (face, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetMaterialfv", 
function (face, pname, params) {
this.checkThread ();
this.mgl11.glGetMaterialfv (face, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetMaterialxv", 
function (face, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetMaterialxv (face, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetMaterialxv", 
function (face, pname, params) {
this.checkThread ();
this.mgl11.glGetMaterialxv (face, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetPointerv", 
function (pname, params) {
this.checkThread ();
this.mgl11.glGetPointerv (pname, params);
this.checkError ();
}, "~N,~A");
Clazz.defineMethod (c$, "glGetTexEnviv", 
function (env, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetTexEnviv (env, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexEnviv", 
function (env, pname, params) {
this.checkThread ();
this.mgl11.glGetTexEnviv (env, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetTexEnvxv", 
function (env, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetTexEnvxv (env, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexEnvxv", 
function (env, pname, params) {
this.checkThread ();
this.mgl11.glGetTexEnvxv (env, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetTexParameterfv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetTexParameterfv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexParameterfv", 
function (target, pname, params) {
this.checkThread ();
this.mgl11.glGetTexParameterfv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetTexParameteriv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetTexParameteriv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexParameteriv", 
function (target, pname, params) {
this.checkThread ();
this.mgl11.glGetTexParameteriv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetTexParameterxv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl11.glGetTexParameterxv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexParameterxv", 
function (target, pname, params) {
this.checkThread ();
this.mgl11.glGetTexParameterxv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glIsBuffer", 
function (buffer) {
this.checkThread ();
var valid = this.mgl11.glIsBuffer (buffer);
this.checkError ();
return valid;
}, "~N");
Clazz.defineMethod (c$, "glIsEnabled", 
function (cap) {
this.checkThread ();
var valid = this.mgl11.glIsEnabled (cap);
this.checkError ();
return valid;
}, "~N");
Clazz.defineMethod (c$, "glIsTexture", 
function (texture) {
this.checkThread ();
var valid = this.mgl11.glIsTexture (texture);
this.checkError ();
return valid;
}, "~N");
Clazz.defineMethod (c$, "glNormalPointer", 
function (type, stride, offset) {
this.checkThread ();
this.mgl11.glNormalPointer (type, stride, offset);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glPointParameterf", 
function (pname, param) {
this.checkThread ();
this.mgl11.glPointParameterf (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPointParameterfv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl11.glPointParameterfv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glPointParameterfv", 
function (pname, params) {
this.checkThread ();
this.mgl11.glPointParameterfv (pname, params);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glPointParameterx", 
function (pname, param) {
this.checkThread ();
this.mgl11.glPointParameterx (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPointParameterxv", 
function (pname, params, offset) {
this.checkThread ();
this.mgl11.glPointParameterxv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glPointParameterxv", 
function (pname, params) {
this.checkThread ();
this.mgl11.glPointParameterxv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glPointSizePointerOES", 
function (type, stride, pointer) {
this.checkThread ();
this.mgl11.glPointSizePointerOES (type, stride, pointer);
this.checkError ();
}, "~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTexCoordPointer", 
function (size, type, stride, offset) {
this.checkThread ();
this.mgl11.glTexCoordPointer (size, type, stride, offset);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnvi", 
function (target, pname, param) {
this.checkThread ();
this.mgl11.glTexEnvi (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnviv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl11.glTexEnviv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexEnviv", 
function (target, pname, params) {
this.checkThread ();
this.mgl11.glTexEnviv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glTexParameterfv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl11.glTexParameterfv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexParameterfv", 
function (target, pname, params) {
this.checkThread ();
this.mgl11.glTexParameterfv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glTexParameteri", 
function (target, pname, param) {
this.checkThread ();
this.mgl11.glTexParameteri (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexParameterxv", 
function (target, pname, params, offset) {
this.checkThread ();
this.mgl11.glTexParameterxv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexParameterxv", 
function (target, pname, params) {
this.checkThread ();
this.mgl11.glTexParameterxv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glVertexPointer", 
function (size, type, stride, offset) {
this.checkThread ();
this.mgl11.glVertexPointer (size, type, stride, offset);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glCurrentPaletteMatrixOES", 
function (matrixpaletteindex) {
this.checkThread ();
this.mgl11Ext.glCurrentPaletteMatrixOES (matrixpaletteindex);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glLoadPaletteFromModelViewMatrixOES", 
function () {
this.checkThread ();
this.mgl11Ext.glLoadPaletteFromModelViewMatrixOES ();
this.checkError ();
});
Clazz.defineMethod (c$, "glMatrixIndexPointerOES", 
function (size, type, stride, pointer) {
this.checkThread ();
this.mgl11Ext.glMatrixIndexPointerOES (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glMatrixIndexPointerOES", 
function (size, type, stride, offset) {
this.checkThread ();
this.mgl11Ext.glMatrixIndexPointerOES (size, type, stride, offset);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glWeightPointerOES", 
function (size, type, stride, pointer) {
this.checkThread ();
this.mgl11Ext.glWeightPointerOES (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glWeightPointerOES", 
function (size, type, stride, offset) {
this.checkThread ();
this.mgl11Ext.glWeightPointerOES (size, type, stride, offset);
this.checkError ();
}, "~N,~N,~N,~N");
});
