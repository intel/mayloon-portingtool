﻿Clazz.declarePackage ("android.opengl");
Clazz.load (["javax.microedition.khronos.opengles.GL", "$.GL10", "$.GL10Ext", "$.GL11", "$.GL11Ext"], "android.opengl.GLWrapperBase", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mgl = null;
this.mgl10Ext = null;
this.mgl11 = null;
this.mgl11Ext = null;
this.mgl11ExtensionPack = null;
Clazz.instantialize (this, arguments);
}, android.opengl, "GLWrapperBase", null, [javax.microedition.khronos.opengles.GL, javax.microedition.khronos.opengles.GL10, javax.microedition.khronos.opengles.GL10Ext, javax.microedition.khronos.opengles.GL11, javax.microedition.khronos.opengles.GL11Ext]);
Clazz.makeConstructor (c$, 
function (gl) {
this.mgl = gl;
if (Clazz.instanceOf (gl, javax.microedition.khronos.opengles.GL10Ext)) {
this.mgl10Ext = gl;
}if (Clazz.instanceOf (gl, javax.microedition.khronos.opengles.GL11)) {
this.mgl11 = gl;
}if (Clazz.instanceOf (gl, javax.microedition.khronos.opengles.GL11Ext)) {
this.mgl11Ext = gl;
}if (Clazz.instanceOf (gl, javax.microedition.khronos.opengles.GL11ExtensionPack)) {
this.mgl11ExtensionPack = gl;
}}, "javax.microedition.khronos.opengles.GL");
});
