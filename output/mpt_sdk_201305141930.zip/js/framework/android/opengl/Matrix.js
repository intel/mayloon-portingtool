﻿Clazz.declarePackage ("android.opengl");
Clazz.load (null, "android.opengl.Matrix", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.declareType (android.opengl, "Matrix");
c$.multiplyMM = Clazz.defineMethod (c$, "multiplyMM", 
function (result, resultOffset, lhs, lhsOffset, rhs, rhsOffset) {
for (var i = 0; i < 4; i++) {
var rhs_i0 = rhs[i * 4 + 0 + rhsOffset];
var ri0 = lhs[0 + 0 + lhsOffset] * rhs_i0;
var ri1 = lhs[0 + 1 + lhsOffset] * rhs_i0;
var ri2 = lhs[0 + 2 + lhsOffset] * rhs_i0;
var ri3 = lhs[0 + 3 + lhsOffset] * rhs_i0;
for (var j = 1; j < 4; j++) {
var rhs_ij = rhs[i * 4 + j + rhsOffset];
ri0 += lhs[4 * j + 0 + lhsOffset] * rhs_ij;
ri1 += lhs[4 * j + 1 + lhsOffset] * rhs_ij;
ri2 += lhs[4 * j + 2 + lhsOffset] * rhs_ij;
ri3 += lhs[4 * j + 3 + lhsOffset] * rhs_ij;
}
result[4 * i + 0 + resultOffset] = ri0;
result[4 * i + 1 + resultOffset] = ri1;
result[4 * i + 2 + resultOffset] = ri2;
result[4 * i + 3 + resultOffset] = ri3;
}
}, "~A,~N,~A,~N,~A,~N");
c$.multiplyMV = Clazz.defineMethod (c$, "multiplyMV", 
function (resultVec, resultVecOffset, lhsMat, lhsMatOffset, rhsVec, rhsVecOffset) {
resultVec[0 + resultVecOffset] = lhsMat[lhsMatOffset + 0 + 0] * rhsVec[rhsVecOffset + 0] + lhsMat[lhsMatOffset + 0 + 4] * rhsVec[rhsVecOffset + 1] + lhsMat[lhsMatOffset + 0 + 8] * rhsVec[rhsVecOffset + 2] + lhsMat[lhsMatOffset + 0 + 12] * rhsVec[rhsVecOffset + 3];
resultVec[1 + resultVecOffset] = lhsMat[lhsMatOffset + 1 + 0] * rhsVec[rhsVecOffset + 0] + lhsMat[lhsMatOffset + 1 + 4] * rhsVec[rhsVecOffset + 1] + lhsMat[lhsMatOffset + 1 + 8] * rhsVec[rhsVecOffset + 2] + lhsMat[lhsMatOffset + 1 + 12] * rhsVec[rhsVecOffset + 3];
resultVec[2 + resultVecOffset] = lhsMat[lhsMatOffset + 2 + 0] * rhsVec[rhsVecOffset + 0] + lhsMat[lhsMatOffset + 2 + 4] * rhsVec[rhsVecOffset + 1] + lhsMat[lhsMatOffset + 2 + 8] * rhsVec[rhsVecOffset + 2] + lhsMat[lhsMatOffset + 2 + 12] * rhsVec[rhsVecOffset + 3];
resultVec[3 + resultVecOffset] = lhsMat[lhsMatOffset + 3 + 0] * rhsVec[rhsVecOffset + 0] + lhsMat[lhsMatOffset + 3 + 4] * rhsVec[rhsVecOffset + 1] + lhsMat[lhsMatOffset + 3 + 8] * rhsVec[rhsVecOffset + 2] + lhsMat[lhsMatOffset + 3 + 12] * rhsVec[rhsVecOffset + 3];
}, "~A,~N,~A,~N,~A,~N");
c$.transposeM = Clazz.defineMethod (c$, "transposeM", 
function (mTrans, mTransOffset, m, mOffset) {
for (var i = 0; i < 4; i++) {
var mBase = i * 4 + mOffset;
mTrans[i + mTransOffset] = m[mBase];
mTrans[i + 4 + mTransOffset] = m[mBase + 1];
mTrans[i + 8 + mTransOffset] = m[mBase + 2];
mTrans[i + 12 + mTransOffset] = m[mBase + 3];
}
}, "~A,~N,~A,~N");
c$.invertM = Clazz.defineMethod (c$, "invertM", 
function (mInv, mInvOffset, m, mOffset) {
var src =  Clazz.newArray (16, 0);
android.opengl.Matrix.transposeM (src, 0, m, mOffset);
var tmp =  Clazz.newArray (12, 0);
tmp[0] = src[10] * src[15];
tmp[1] = src[11] * src[14];
tmp[2] = src[9] * src[15];
tmp[3] = src[11] * src[13];
tmp[4] = src[9] * src[14];
tmp[5] = src[10] * src[13];
tmp[6] = src[8] * src[15];
tmp[7] = src[11] * src[12];
tmp[8] = src[8] * src[14];
tmp[9] = src[10] * src[12];
tmp[10] = src[8] * src[13];
tmp[11] = src[9] * src[12];
var dst =  Clazz.newArray (16, 0);
dst[0] = tmp[0] * src[5] + tmp[3] * src[6] + tmp[4] * src[7];
dst[0] -= tmp[1] * src[5] + tmp[2] * src[6] + tmp[5] * src[7];
dst[1] = tmp[1] * src[4] + tmp[6] * src[6] + tmp[9] * src[7];
dst[1] -= tmp[0] * src[4] + tmp[7] * src[6] + tmp[8] * src[7];
dst[2] = tmp[2] * src[4] + tmp[7] * src[5] + tmp[10] * src[7];
dst[2] -= tmp[3] * src[4] + tmp[6] * src[5] + tmp[11] * src[7];
dst[3] = tmp[5] * src[4] + tmp[8] * src[5] + tmp[11] * src[6];
dst[3] -= tmp[4] * src[4] + tmp[9] * src[5] + tmp[10] * src[6];
dst[4] = tmp[1] * src[1] + tmp[2] * src[2] + tmp[5] * src[3];
dst[4] -= tmp[0] * src[1] + tmp[3] * src[2] + tmp[4] * src[3];
dst[5] = tmp[0] * src[0] + tmp[7] * src[2] + tmp[8] * src[3];
dst[5] -= tmp[1] * src[0] + tmp[6] * src[2] + tmp[9] * src[3];
dst[6] = tmp[3] * src[0] + tmp[6] * src[1] + tmp[11] * src[3];
dst[6] -= tmp[2] * src[0] + tmp[7] * src[1] + tmp[10] * src[3];
dst[7] = tmp[4] * src[0] + tmp[9] * src[1] + tmp[10] * src[2];
dst[7] -= tmp[5] * src[0] + tmp[8] * src[1] + tmp[11] * src[2];
tmp[0] = src[2] * src[7];
tmp[1] = src[3] * src[6];
tmp[2] = src[1] * src[7];
tmp[3] = src[3] * src[5];
tmp[4] = src[1] * src[6];
tmp[5] = src[2] * src[5];
tmp[6] = src[0] * src[7];
tmp[7] = src[3] * src[4];
tmp[8] = src[0] * src[6];
tmp[9] = src[2] * src[4];
tmp[10] = src[0] * src[5];
tmp[11] = src[1] * src[4];
dst[8] = tmp[0] * src[13] + tmp[3] * src[14] + tmp[4] * src[15];
dst[8] -= tmp[1] * src[13] + tmp[2] * src[14] + tmp[5] * src[15];
dst[9] = tmp[1] * src[12] + tmp[6] * src[14] + tmp[9] * src[15];
dst[9] -= tmp[0] * src[12] + tmp[7] * src[14] + tmp[8] * src[15];
dst[10] = tmp[2] * src[12] + tmp[7] * src[13] + tmp[10] * src[15];
dst[10] -= tmp[3] * src[12] + tmp[6] * src[13] + tmp[11] * src[15];
dst[11] = tmp[5] * src[12] + tmp[8] * src[13] + tmp[11] * src[14];
dst[11] -= tmp[4] * src[12] + tmp[9] * src[13] + tmp[10] * src[14];
dst[12] = tmp[2] * src[10] + tmp[5] * src[11] + tmp[1] * src[9];
dst[12] -= tmp[4] * src[11] + tmp[0] * src[9] + tmp[3] * src[10];
dst[13] = tmp[8] * src[11] + tmp[0] * src[8] + tmp[7] * src[10];
dst[13] -= tmp[6] * src[10] + tmp[9] * src[11] + tmp[1] * src[8];
dst[14] = tmp[6] * src[9] + tmp[11] * src[11] + tmp[3] * src[8];
dst[14] -= tmp[10] * src[11] + tmp[2] * src[8] + tmp[7] * src[9];
dst[15] = tmp[10] * src[10] + tmp[4] * src[8] + tmp[9] * src[9];
dst[15] -= tmp[8] * src[9] + tmp[11] * src[10] + tmp[5] * src[8];
var det = src[0] * dst[0] + src[1] * dst[1] + src[2] * dst[2] + src[3] * dst[3];
if (det == 0.0) {
}det = 1 / det;
for (var j = 0; j < 16; j++) mInv[j + mInvOffset] = dst[j] * det;

return true;
}, "~A,~N,~A,~N");
c$.orthoM = Clazz.defineMethod (c$, "orthoM", 
function (m, mOffset, left, right, bottom, top, near, far) {
if (left == right) {
throw  new IllegalArgumentException ("left == right");
}if (bottom == top) {
throw  new IllegalArgumentException ("bottom == top");
}if (near == far) {
throw  new IllegalArgumentException ("near == far");
}var r_width = 1.0 / (right - left);
var r_height = 1.0 / (top - bottom);
var r_depth = 1.0 / (far - near);
var x = 2.0 * (r_width);
var y = 2.0 * (r_height);
var z = -2.0 * (r_depth);
var tx = -(right + left) * r_width;
var ty = -(top + bottom) * r_height;
var tz = -(far + near) * r_depth;
m[mOffset + 0] = x;
m[mOffset + 5] = y;
m[mOffset + 10] = z;
m[mOffset + 12] = tx;
m[mOffset + 13] = ty;
m[mOffset + 14] = tz;
m[mOffset + 15] = 1.0;
m[mOffset + 1] = 0.0;
m[mOffset + 2] = 0.0;
m[mOffset + 3] = 0.0;
m[mOffset + 4] = 0.0;
m[mOffset + 6] = 0.0;
m[mOffset + 7] = 0.0;
m[mOffset + 8] = 0.0;
m[mOffset + 9] = 0.0;
m[mOffset + 11] = 0.0;
}, "~A,~N,~N,~N,~N,~N,~N,~N");
c$.frustumM = Clazz.defineMethod (c$, "frustumM", 
function (m, offset, left, right, bottom, top, near, far) {
if (left == right) {
throw  new IllegalArgumentException ("left == right");
}if (top == bottom) {
throw  new IllegalArgumentException ("top == bottom");
}if (near == far) {
throw  new IllegalArgumentException ("near == far");
}if (near <= 0.0) {
throw  new IllegalArgumentException ("near <= 0.0f");
}if (far <= 0.0) {
throw  new IllegalArgumentException ("far <= 0.0f");
}var r_width = 1.0 / (right - left);
var r_height = 1.0 / (top - bottom);
var r_depth = 1.0 / (near - far);
var x = 2.0 * (near * r_width);
var y = 2.0 * (near * r_height);
var A = 2.0 * ((right + left) * r_width);
var B = (top + bottom) * r_height;
var C = (far + near) * r_depth;
var D = 2.0 * (far * near * r_depth);
m[offset + 0] = x;
m[offset + 5] = y;
m[offset + 8] = A;
m[offset + 9] = B;
m[offset + 10] = C;
m[offset + 14] = D;
m[offset + 11] = -1.0;
m[offset + 1] = 0.0;
m[offset + 2] = 0.0;
m[offset + 3] = 0.0;
m[offset + 4] = 0.0;
m[offset + 6] = 0.0;
m[offset + 7] = 0.0;
m[offset + 12] = 0.0;
m[offset + 13] = 0.0;
m[offset + 15] = 0.0;
}, "~A,~N,~N,~N,~N,~N,~N,~N");
c$.getLength = Clazz.defineMethod (c$, "getLength", 
function (x, y, z) {
return Math.sqrt (x * x + y * y + z * z);
}, "~N,~N,~N");
c$.setIdentityM = Clazz.defineMethod (c$, "setIdentityM", 
function (sm, smOffset) {
for (var i = 0; i < 16; i++) {
sm[smOffset + i] = 0;
}
for (var i = 0; i < 16; i += 5) {
sm[smOffset + i] = 1.0;
}
}, "~A,~N");
c$.scaleM = Clazz.defineMethod (c$, "scaleM", 
function (sm, smOffset, m, mOffset, x, y, z) {
for (var i = 0; i < 4; i++) {
var smi = smOffset + i;
var mi = mOffset + i;
sm[smi] = m[mi] * x;
sm[4 + smi] = m[4 + mi] * y;
sm[8 + smi] = m[8 + mi] * z;
sm[12 + smi] = m[12 + mi];
}
}, "~A,~N,~A,~N,~N,~N,~N");
c$.scaleM = Clazz.defineMethod (c$, "scaleM", 
function (m, mOffset, x, y, z) {
for (var i = 0; i < 4; i++) {
var mi = mOffset + i;
m[mi] *= x;
m[4 + mi] *= y;
m[8 + mi] *= z;
}
}, "~A,~N,~N,~N,~N");
c$.translateM = Clazz.defineMethod (c$, "translateM", 
function (tm, tmOffset, m, mOffset, x, y, z) {
for (var i = 0; i < 12; i++) {
tm[tmOffset + i] = m[mOffset + i];
}
for (var i = 0; i < 4; i++) {
var tmi = tmOffset + i;
var mi = mOffset + i;
tm[12 + tmi] = m[mi] * x + m[4 + mi] * y + m[8 + mi] * z + m[12 + mi];
}
}, "~A,~N,~A,~N,~N,~N,~N");
c$.translateM = Clazz.defineMethod (c$, "translateM", 
function (m, mOffset, x, y, z) {
for (var i = 0; i < 4; i++) {
var mi = mOffset + i;
m[12 + mi] += m[mi] * x + m[4 + mi] * y + m[8 + mi] * z;
}
}, "~A,~N,~N,~N,~N");
c$.rotateM = Clazz.defineMethod (c$, "rotateM", 
function (rm, rmOffset, m, mOffset, a, x, y, z) {
var r =  Clazz.newArray (16, 0);
android.opengl.Matrix.setRotateM (r, 0, a, x, y, z);
android.opengl.Matrix.multiplyMM (rm, rmOffset, m, mOffset, r, 0);
}, "~A,~N,~A,~N,~N,~N,~N,~N");
c$.rotateM = Clazz.defineMethod (c$, "rotateM", 
function (m, mOffset, a, x, y, z) {
var temp =  Clazz.newArray (32, 0);
android.opengl.Matrix.setRotateM (temp, 0, a, x, y, z);
android.opengl.Matrix.multiplyMM (temp, 16, m, mOffset, temp, 0);
System.arraycopy (temp, 16, m, mOffset, 16);
}, "~A,~N,~N,~N,~N,~N");
c$.setRotateM = Clazz.defineMethod (c$, "setRotateM", 
function (rm, rmOffset, a, x, y, z) {
rm[rmOffset + 3] = 0;
rm[rmOffset + 7] = 0;
rm[rmOffset + 11] = 0;
rm[rmOffset + 12] = 0;
rm[rmOffset + 13] = 0;
rm[rmOffset + 14] = 0;
rm[rmOffset + 15] = 1;
a *= (0.017453292519943295);
var s = Math.sin (a);
var c = Math.cos (a);
if (1.0 == x && 0.0 == y && 0.0 == z) {
rm[rmOffset + 5] = c;
rm[rmOffset + 10] = c;
rm[rmOffset + 6] = s;
rm[rmOffset + 9] = -s;
rm[rmOffset + 1] = 0;
rm[rmOffset + 2] = 0;
rm[rmOffset + 4] = 0;
rm[rmOffset + 8] = 0;
rm[rmOffset + 0] = 1;
} else if (0.0 == x && 1.0 == y && 0.0 == z) {
rm[rmOffset + 0] = c;
rm[rmOffset + 10] = c;
rm[rmOffset + 8] = s;
rm[rmOffset + 2] = -s;
rm[rmOffset + 1] = 0;
rm[rmOffset + 4] = 0;
rm[rmOffset + 6] = 0;
rm[rmOffset + 9] = 0;
rm[rmOffset + 5] = 1;
} else if (0.0 == x && 0.0 == y && 1.0 == z) {
rm[rmOffset + 0] = c;
rm[rmOffset + 5] = c;
rm[rmOffset + 1] = s;
rm[rmOffset + 4] = -s;
rm[rmOffset + 2] = 0;
rm[rmOffset + 6] = 0;
rm[rmOffset + 8] = 0;
rm[rmOffset + 9] = 0;
rm[rmOffset + 10] = 1;
} else {
var len = android.opengl.Matrix.getLength (x, y, z);
if (1.0 != len) {
var recipLen = 1.0 / len;
x *= recipLen;
y *= recipLen;
z *= recipLen;
}var nc = 1.0 - c;
var xy = x * y;
var yz = y * z;
var zx = z * x;
var xs = x * s;
var ys = y * s;
var zs = z * s;
rm[rmOffset + 0] = x * x * nc + c;
rm[rmOffset + 4] = xy * nc - zs;
rm[rmOffset + 8] = zx * nc + ys;
rm[rmOffset + 1] = xy * nc + zs;
rm[rmOffset + 5] = y * y * nc + c;
rm[rmOffset + 9] = yz * nc - xs;
rm[rmOffset + 2] = zx * nc - ys;
rm[rmOffset + 6] = yz * nc + xs;
rm[rmOffset + 10] = z * z * nc + c;
}}, "~A,~N,~N,~N,~N,~N");
c$.setRotateEulerM = Clazz.defineMethod (c$, "setRotateEulerM", 
function (rm, rmOffset, x, y, z) {
x *= (0.017453292519943295);
y *= (0.017453292519943295);
z *= (0.017453292519943295);
var cx = Math.cos (x);
var sx = Math.sin (x);
var cy = Math.cos (y);
var sy = Math.sin (y);
var cz = Math.cos (z);
var sz = Math.sin (z);
var cxsy = cx * sy;
var sxsy = sx * sy;
rm[rmOffset + 0] = cy * cz;
rm[rmOffset + 1] = -cy * sz;
rm[rmOffset + 2] = sy;
rm[rmOffset + 3] = 0.0;
rm[rmOffset + 4] = cxsy * cz + cx * sz;
rm[rmOffset + 5] = -cxsy * sz + cx * cz;
rm[rmOffset + 6] = -sx * cy;
rm[rmOffset + 7] = 0.0;
rm[rmOffset + 8] = -sxsy * cz + sx * sz;
rm[rmOffset + 9] = sxsy * sz + sx * cz;
rm[rmOffset + 10] = cx * cy;
rm[rmOffset + 11] = 0.0;
rm[rmOffset + 12] = 0.0;
rm[rmOffset + 13] = 0.0;
rm[rmOffset + 14] = 0.0;
rm[rmOffset + 15] = 1.0;
}, "~A,~N,~N,~N,~N");
c$.setLookAtM = Clazz.defineMethod (c$, "setLookAtM", 
function (rm, rmOffset, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ) {
var fx = centerX - eyeX;
var fy = centerY - eyeY;
var fz = centerZ - eyeZ;
var rlf = 1.0 / android.opengl.Matrix.getLength (fx, fy, fz);
fx *= rlf;
fy *= rlf;
fz *= rlf;
var sx = fy * upZ - fz * upY;
var sy = fz * upX - fx * upZ;
var sz = fx * upY - fy * upX;
var rls = 1.0 / android.opengl.Matrix.getLength (sx, sy, sz);
sx *= rls;
sy *= rls;
sz *= rls;
var ux = sy * fz - sz * fy;
var uy = sz * fx - sx * fz;
var uz = sx * fy - sy * fx;
rm[rmOffset + 0] = sx;
rm[rmOffset + 1] = ux;
rm[rmOffset + 2] = -fx;
rm[rmOffset + 3] = 0.0;
rm[rmOffset + 4] = sy;
rm[rmOffset + 5] = uy;
rm[rmOffset + 6] = -fy;
rm[rmOffset + 7] = 0.0;
rm[rmOffset + 8] = sz;
rm[rmOffset + 9] = uz;
rm[rmOffset + 10] = -fz;
rm[rmOffset + 11] = 0.0;
rm[rmOffset + 12] = 0.0;
rm[rmOffset + 13] = 0.0;
rm[rmOffset + 14] = 0.0;
rm[rmOffset + 15] = 1.0;
android.opengl.Matrix.translateM (rm, rmOffset, -eyeX, -eyeY, -eyeZ);
}, "~A,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N");
});
