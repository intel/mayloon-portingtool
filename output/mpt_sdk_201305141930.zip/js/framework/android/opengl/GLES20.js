﻿Clazz.declarePackage ("android.opengl");
Clazz.load (null, "android.opengl.GLES20", ["java.lang.RuntimeException"], function () {
c$ = Clazz.declareType (android.opengl, "GLES20");
c$.classInit = Clazz.defineMethod (c$, "classInit", 
function () {
android.opengl.GLES20.prototype.mCachedBuffer = null;
var shaderArray = new Array();
// In OpenGLES2.0, 0 is invalid id for shader, so we begin at index 1;
shaderArray.push(-1);
android.opengl.GLES20.prototype.mShaderArray = shaderArray;
var programArray = new Array();
// In OpenGLES2.0, 0 is invalid id for program, so we begin at index 1;
programArray.push(-1);
android.opengl.GLES20.prototype.mProgramArray = programArray;
var uniformLocationArray = new Array();
// In OpenGLES2.0, -1 is invalid id for program, so we begin at index 0;
android.opengl.GLES20.prototype.mUniformLocationArray = uniformLocationArray;
var textureArray = new Array();
// In OpenGLES2.0, 0 is reserved id by system for texture, so we begin at index 1;
textureArray.push(-1);
android.opengl.GLES20.prototype.mTextureArray = textureArray;
var bufferArray = new Array();
// In OpenGLES2.0, -1 is invalid id for buffer id, so we begin at index 0;
android.opengl.GLES20.prototype.mBufferArray = bufferArray;
var frameBufferArray = new Array();
// In OpenGLES2.0, -1 is invalid id for buffer id, so we begin at index 0;
android.opengl.GLES20.prototype.mFrameBufferArray = frameBufferArray;
var renderBufferArray = new Array();
// In OpenGLES2.0, -1 is invalid id for buffer id, so we begin at index 0;
android.opengl.GLES20.prototype.mRenderBufferArray = renderBufferArray;
});
c$.classTerminate = Clazz.defineMethod (c$, "classTerminate", 
function () {
android.opengl.GLES20.prototype.mCachedBuffer = null;
android.opengl.GLES20.prototype.mShaderArray = null;
android.opengl.GLES20.prototype.mProgramArray = null;
android.opengl.GLES20.prototype.mUniformLocationArray = null;
android.opengl.GLES20.prototype.mTextureArray = null;
android.opengl.GLES20.prototype.mBufferArray = null;
android.opengl.GLES20.prototype.mFrameBufferArray = null;
android.opengl.GLES20.prototype.mRenderBufferArray = null;
});
c$.checkWebGLContext = Clazz.defineMethod (c$, "checkWebGLContext", 
($fz = function () {
if (!android.opengl.GLES20.prototype.mContext) {
throw "No WebGL context is found for GLES20!";
}
if (false) {
var error = android.opengl.GLES20.glGetError ();
if (error != 0) {
throw  new RuntimeException ("glError " + error);
}}}, $fz.isPrivate = true, $fz));
c$.glActiveTexture = Clazz.defineMethod (c$, "glActiveTexture", 
function (texture) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.activeTexture(texture);
}, "~N");
c$.glAttachShader = Clazz.defineMethod (c$, "glAttachShader", 
function (program, shader) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
var _shader = android.opengl.GLES20.prototype.mShaderArray[shader];
android.opengl.GLES20.prototype.mContext.attachShader(_program, _shader);
}, "~N,~N");
c$.glBindAttribLocation = Clazz.defineMethod (c$, "glBindAttribLocation", 
function (program, index, name) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
android.opengl.GLES20.prototype.mContext.bindAttribLocation(_program, index, name);
}, "~N,~N,~S");
c$.glBindBuffer = Clazz.defineMethod (c$, "glBindBuffer", 
function (target, buffer) {
android.opengl.GLES20.checkWebGLContext ();
var _buffer = android.opengl.GLES20.prototype.mBufferArray[buffer];
android.opengl.GLES20.prototype.mContext.bindBuffer(target, _buffer);
}, "~N,~N");
c$.glBindFramebuffer = Clazz.defineMethod (c$, "glBindFramebuffer", 
function (target, framebuffer) {
android.opengl.GLES20.checkWebGLContext ();
var _framebuffer = android.opengl.GLES20.prototype.mFrameBufferArray[framebuffer];
android.opengl.GLES20.prototype.mContext.bindFrameBuffer(target, _framebuffer);
}, "~N,~N");
c$.glBindRenderbuffer = Clazz.defineMethod (c$, "glBindRenderbuffer", 
function (target, renderbuffer) {
android.opengl.GLES20.checkWebGLContext ();
var _renderbuffer = android.opengl.GLES20.prototype.mRenderBufferArray[renderbuffer];
android.opengl.GLES20.prototype.mContext.bindRenderBuffer(target, _renderbuffer);
}, "~N,~N");
c$.glBindTexture = Clazz.defineMethod (c$, "glBindTexture", 
function (target, texture) {
android.opengl.GLES20.checkWebGLContext ();
var _texture = android.opengl.GLES20.prototype.mTextureArray[texture];
android.opengl.GLES20.prototype.mContext.bindTexture(target, _texture);
}, "~N,~N");
c$.glBlendColor = Clazz.defineMethod (c$, "glBlendColor", 
function (red, green, blue, alpha) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.blendColor(red, green, blue, alpha);
}, "~N,~N,~N,~N");
c$.glBlendEquation = Clazz.defineMethod (c$, "glBlendEquation", 
function (mode) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.blendEquation(mode);
}, "~N");
c$.glBlendEquationSeparate = Clazz.defineMethod (c$, "glBlendEquationSeparate", 
function (modeRGB, modeAlpha) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.blendEquationSeparate(modeRGB, modeAlpha);
}, "~N,~N");
c$.glBlendFunc = Clazz.defineMethod (c$, "glBlendFunc", 
function (sfactor, dfactor) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.blendFunc(sfactor, dfactor);
}, "~N,~N");
c$.glBlendFuncSeparate = Clazz.defineMethod (c$, "glBlendFuncSeparate", 
function (srcRGB, dstRGB, srcAlpha, dstAlpha) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.blendFuncSeparate(srcRGB, dstRGB, srcAlpha, dstAlpha);
}, "~N,~N,~N,~N");
c$.glBufferData = Clazz.defineMethod (c$, "glBufferData", 
function (target, size, data, usage) {
android.opengl.GLES20.checkWebGLContext ();
var arraybuffer = null;
if (data instanceof java.nio.ByteBuffer) {
arraybuffer = data.backingArray;
} else {
arraybuffer = data.byteBuffer.backingArray;
}
var offset = data.position() * Math.pow(2, data._elementSizeShift);
arraybuffer = arraybuffer.buffer.slice(offset);
android.opengl.GLES20.prototype.mContext.bufferData(target, arraybuffer, usage);
}, "~N,~N,java.nio.Buffer,~N");
c$.glBufferSubData = Clazz.defineMethod (c$, "glBufferSubData", 
function (target, offset, size, data) {
android.opengl.GLES20.checkWebGLContext ();
var arraybuffer = null;
if (data instanceof java.nio.ByteBuffer) {
arraybuffer = data.backingArray;
} else {
arraybuffer = data.byteBuffer.backingArray;
}
var _offset = data.position() * Math.pow(2, data._elementSizeShift);
android.opengl.GLES20.prototype.mContext.bufferSubData(target, offset, arraybuffer.buffer.slice(_offset));
}, "~N,~N,~N,java.nio.Buffer");
c$.glCheckFramebufferStatus = Clazz.defineMethod (c$, "glCheckFramebufferStatus", 
function (target) {
android.opengl.GLES20.checkWebGLContext ();
var status = 0;
status = android.opengl.GLES20.prototype.mContext.checkFramebufferStatus(target);
return status;
}, "~N");
c$.glClear = Clazz.defineMethod (c$, "glClear", 
function (mask) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.clear(mask);
}, "~N");
c$.glClearColor = Clazz.defineMethod (c$, "glClearColor", 
function (red, green, blue, alpha) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.clearColor(red, green, blue, alpha);
}, "~N,~N,~N,~N");
c$.glClearDepthf = Clazz.defineMethod (c$, "glClearDepthf", 
function (depth) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.clearDepth(depth);
}, "~N");
c$.glClearStencil = Clazz.defineMethod (c$, "glClearStencil", 
function (s) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.clearStencil(s);
}, "~N");
c$.glColorMask = Clazz.defineMethod (c$, "glColorMask", 
function (red, green, blue, alpha) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.colorMask(red, green, blue, alpha);
}, "~B,~B,~B,~B");
c$.glCompileShader = Clazz.defineMethod (c$, "glCompileShader", 
function (shader) {
android.opengl.GLES20.checkWebGLContext ();
var _shader = android.opengl.GLES20.prototype.mShaderArray[shader];
android.opengl.GLES20.prototype.mContext.compileShader(_shader);
}, "~N");
c$.glCompressedTexImage2D = Clazz.defineMethod (c$, "glCompressedTexImage2D", 
function (target, level, internalformat, width, height, border, imageSize, data) {
throw  new RuntimeException ("Compressed Texture is not supported");
}, "~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
c$.glCompressedTexSubImage2D = Clazz.defineMethod (c$, "glCompressedTexSubImage2D", 
function (target, level, xoffset, yoffset, width, height, format, imageSize, data) {
throw  new RuntimeException ("Compressed Texture is not supported");
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
c$.glCopyTexImage2D = Clazz.defineMethod (c$, "glCopyTexImage2D", 
function (target, level, internalformat, x, y, width, height, border) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.copyTexImage2D(target, level, internalformat, x, y, width, height, border);
}, "~N,~N,~N,~N,~N,~N,~N,~N");
c$.glCopyTexSubImage2D = Clazz.defineMethod (c$, "glCopyTexSubImage2D", 
function (target, level, xoffset, yoffset, x, y, width, height) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.copyTexSubImage2D(target, level, internalformat, x, y, width, height, border);
}, "~N,~N,~N,~N,~N,~N,~N,~N");
c$.glCreateProgram = Clazz.defineMethod (c$, "glCreateProgram", 
function () {
android.opengl.GLES20.checkWebGLContext ();
var program = android.opengl.GLES20.prototype.mContext.createProgram();
if (program) {
android.opengl.GLES20.prototype.mProgramArray.push(program);
return android.opengl.GLES20.prototype.mProgramArray.length - 1;
}
return 0;
});
c$.glCreateShader = Clazz.defineMethod (c$, "glCreateShader", 
function (type) {
android.opengl.GLES20.checkWebGLContext ();
var shader = android.opengl.GLES20.prototype.mContext.createShader(type);
if (shader) {
android.opengl.GLES20.prototype.mShaderArray.push(shader);
return android.opengl.GLES20.prototype.mShaderArray.length - 1;
}
return 0;
}, "~N");
c$.glCullFace = Clazz.defineMethod (c$, "glCullFace", 
function (mode) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.cullFace(mode);
}, "~N");
c$.glDeleteBuffers = Clazz.defineMethod (c$, "glDeleteBuffers", 
function (n, buffers, offset) {
android.opengl.GLES20.checkWebGLContext ();
for (var i = 0; i < n; i++) {
var buffer = android.opengl.GLES20.prototype.mBufferArray[buffers[offset + i]];
android.opengl.GLES20.prototype.mContext.deleteBuffer(buffer);
}
}, "~N,~A,~N");
c$.glDeleteFramebuffers = Clazz.defineMethod (c$, "glDeleteFramebuffers", 
function (n, framebuffers, offset) {
android.opengl.GLES20.checkWebGLContext ();
for (var i = 0; i < n; i++) {
var buffer = android.opengl.GLES20.prototype.mFrameBufferArray[framebuffers[offset + i]];
android.opengl.GLES20.prototype.mContext.deleteFrameBuffer(buffer);
}
}, "~N,~A,~N");
c$.glDeleteProgram = Clazz.defineMethod (c$, "glDeleteProgram", 
function (program) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
android.opengl.GLES20.prototype.mContext.deleteProgram(_program);
android.opengl.GLES20.prototype.mProgramArray.splice(program, 1);
}, "~N");
c$.glDeleteRenderbuffers = Clazz.defineMethod (c$, "glDeleteRenderbuffers", 
function (n, renderbuffers, offset) {
android.opengl.GLES20.checkWebGLContext ();
for (var i = 0; i < n; i++) {
var buffer = android.opengl.GLES20.prototype.mRenderBufferArray[renderbuffers[offset + i]];
android.opengl.GLES20.prototype.mContext.deleteRenderBuffer(buffer);
}
}, "~N,~A,~N");
c$.glDeleteShader = Clazz.defineMethod (c$, "glDeleteShader", 
function (shader) {
android.opengl.GLES20.checkWebGLContext ();
var _shader = android.opengl.GLES20.prototype.mShaderArray[shader];
android.opengl.GLES20.prototype.mContext.deleteShader(_shader);
android.opengl.GLES20.prototype.mShaderArray.splice(shader, 1);
}, "~N");
c$.glDeleteTextures = Clazz.defineMethod (c$, "glDeleteTextures", 
function (n, textures, offset) {
android.opengl.GLES20.checkWebGLContext ();
for (var i = 0; i < n; i++) {
var texture = android.opengl.GLES20.prototype.mTextureArray[textures[offset + i]];
android.opengl.GLES20.prototype.mContext.deleteTexture(texture);
}
}, "~N,~A,~N");
c$.glDepthFunc = Clazz.defineMethod (c$, "glDepthFunc", 
function (func) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.depthFunc(func);
}, "~N");
c$.glDepthMask = Clazz.defineMethod (c$, "glDepthMask", 
function (flag) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.depthMask(flag);
}, "~B");
c$.glDepthRangef = Clazz.defineMethod (c$, "glDepthRangef", 
function (zNear, zFar) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.depthRange(zNear, zFar);
}, "~N,~N");
c$.glDetachShader = Clazz.defineMethod (c$, "glDetachShader", 
function (program, shader) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
var _shader = android.opengl.GLES20.prototype.mShaderArray[shader];
android.opengl.GLES20.prototype.mContext.detachShader(_program, _shader);
}, "~N,~N");
c$.glDisable = Clazz.defineMethod (c$, "glDisable", 
function (cap) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.disable(cap);
}, "~N");
c$.glDisableVertexAttribArray = Clazz.defineMethod (c$, "glDisableVertexAttribArray", 
function (index) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.disableVertexAttribArray(index);
}, "~N");
c$.glDrawArrays = Clazz.defineMethod (c$, "glDrawArrays", 
function (mode, first, count) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.drawArrays(mode, first, count);
}, "~N,~N,~N");
c$.glDrawElements = Clazz.defineMethod (c$, "glDrawElements", 
function (mode, count, type, offset) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.drawElements(mode, count, type, offset);
}, "~N,~N,~N,~N");
c$.glDrawElements = Clazz.defineMethod (c$, "glDrawElements", 
function (mode, count, type, indices) {
android.opengl.GLES20.checkWebGLContext ();
// WebGL does not support client side arrays, we need to gen
// a buffer object and upload the data into buffer object, then
// bind the buffer object and call vertexAttribPointer.
var buffer = android.opengl.GLES20.prototype.mContext.createBuffer();
android.opengl.GLES20.prototype.mContext.bindBuffer(android.opengl.GLES20.prototype.mContext.ELEMENT_ARRAY_BUFFER, buffer);
var arraybuffer = indices.byteBuffer.backingArray;
var offset = indices.position() * Math.pow(2, indices._elementSizeShift);
android.opengl.GLES20.prototype.mContext.bufferData(android.opengl.GLES20.prototype.mContext.ELEMENT_ARRAY_BUFFER, arraybuffer,
android.opengl.GLES20.prototype.mContext.STATIC_DRAW);
android.opengl.GLES20.prototype.mContext.drawElements(mode, count, type, offset);
}, "~N,~N,~N,java.nio.Buffer");
c$.glEnable = Clazz.defineMethod (c$, "glEnable", 
function (cap) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.enable(cap);
}, "~N");
c$.glEnableVertexAttribArray = Clazz.defineMethod (c$, "glEnableVertexAttribArray", 
function (index) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.enableVertexAttribArray(index);
}, "~N");
c$.glFinish = Clazz.defineMethod (c$, "glFinish", 
function () {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.finish();
});
c$.glFlush = Clazz.defineMethod (c$, "glFlush", 
function () {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.flush();
});
c$.glFramebufferRenderbuffer = Clazz.defineMethod (c$, "glFramebufferRenderbuffer", 
function (target, attachment, renderbuffertarget, renderbuffer) {
android.opengl.GLES20.checkWebGLContext ();
var _renderbuffer = android.opengl.GLES20.prototype.mRenderBufferArray[renderbuffer];
android.opengl.GLES20.prototype.mContext.framebufferRenderbuffer(target, attachment, renderbuffertarget, renderbuffer);
}, "~N,~N,~N,~N");
c$.glFramebufferTexture2D = Clazz.defineMethod (c$, "glFramebufferTexture2D", 
function (target, attachment, textarget, texture, level) {
android.opengl.GLES20.checkWebGLContext ();
var _texture = android.opengl.GLES20.prototype.mTextureArray[texture];
android.opengl.GLES20.prototype.mContext.framebufferTexture2D(target, attachment, textarget, _texture, level);
}, "~N,~N,~N,~N,~N");
c$.glFrontFace = Clazz.defineMethod (c$, "glFrontFace", 
function (mode) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.frontFace(mode);
}, "~N");
c$.glGenBuffers = Clazz.defineMethod (c$, "glGenBuffers", 
function (n, buffers, offset) {
android.opengl.GLES20.checkWebGLContext ();
for (var i = 0; i < n; i++) {
var _buffer = android.opengl.GLES20.prototype.mContext.createBuffer();
android.opengl.GLES20.prototype.mBufferArray.push(_buffer);
buffers[offset + i] = android.opengl.GLES20.prototype.mBufferArray.length - 1;
}
}, "~N,~A,~N");
c$.glGenerateMipmap = Clazz.defineMethod (c$, "glGenerateMipmap", 
function (target) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.generateMipmap(target);
}, "~N");
c$.glGenFramebuffers = Clazz.defineMethod (c$, "glGenFramebuffers", 
function (n, framebuffers, offset) {
android.opengl.GLES20.checkWebGLContext ();
for (var i = 0; i < n; i++) {
var _framebuffer = android.opengl.GLES20.prototype.mContext.createFrameBuffer();
android.opengl.GLES20.prototype.mFrameBufferArray.push(_framebuffer);
framebuffers[offset + i] = android.opengl.GLES20.prototype.mFrameBufferArray.length - 1;
}
}, "~N,~A,~N");
c$.glGenRenderbuffers = Clazz.defineMethod (c$, "glGenRenderbuffers", 
function (n, renderbuffers, offset) {
android.opengl.GLES20.checkWebGLContext ();
for (var i = 0; i < n; i++) {
var _renderbuffer = android.opengl.GLES20.prototype.mContext.createRenderBuffer();
android.opengl.GLES20.prototype.mRenderBufferArray.push(_renderbuffer);
renderbuffers[offset + i] = android.opengl.GLES20.prototype.mRenderBufferArray.length - 1;
}
}, "~N,~A,~N");
c$.glGenTextures = Clazz.defineMethod (c$, "glGenTextures", 
function (n, textures, offset) {
android.opengl.GLES20.checkWebGLContext ();
for (var i = 0; i < n; i++) {
var texture = android.opengl.GLES20.prototype.mContext.createTexture();
if (texture) {
android.opengl.GLES20.prototype.mTextureArray.push(texture);
textures[offset + i] = android.opengl.GLES20.prototype.mTextureArray.length - 1;
} else {
textures[offset + i] = -1;
}
}
}, "~N,~A,~N");
c$.glGetActiveAttrib = Clazz.defineMethod (c$, "glGetActiveAttrib", 
function (program, index, bufsize, length, lengthOffset, size, sizeOffset, type, typeOffset, name, nameOffset) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
var info = android.opengl.GLES20.prototype.mContext.getActiveAttrib(_program, index);
if (info) {
if (size) size[sizeOffset] = info.size;
if (type) type[typeOffset] = info.type;
if (length) length[lengthOffset] = info.name.length;
if (name) {
for ( var i = 0; i < info.name.length; i++) {
name[nameOffset + i] = info.charAt(i);
}
}
}
}, "~N,~N,~N,~A,~N,~A,~N,~A,~N,~A,~N");
c$.glGetActiveUniform = Clazz.defineMethod (c$, "glGetActiveUniform", 
function (program, index, bufsize, length, lengthOffset, size, sizeOffset, type, typeOffset, name, nameOffset) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
var info = android.opengl.GLES20.prototype.mContext.getActiveUniform(_program, index);
if (info) {
if (size) size[sizeOffset] = info.size;
if (type) type[typeOffset] = info.type;
if (length) length[lengthOffset] = info.name.length;
if (name) {
for ( var i = 0; i < info.name.length; i++) {
name[nameOffset + i] = info.charAt(i);
}
}
}
}, "~N,~N,~N,~A,~N,~A,~N,~A,~N,~A,~N");
c$.glGetAttachedShaders = Clazz.defineMethod (c$, "glGetAttachedShaders", 
function (program, maxcount, count, countOffset, shaders, shadersOffset) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
var _shaders = android.opengl.GLES20.prototype.mContext.getAttachedShaders(_program);
for (var i = 0; i < _shaders.length && i < maxcount; i++) {
shaders[shadersOffset] = android.opengl.GLES20.prototype.mShaderArray.indexOf(_shaders[i]);
}
count[countOffset] = i;
}, "~N,~N,~A,~N,~A,~N");
c$.glGetAttribLocation = Clazz.defineMethod (c$, "glGetAttribLocation", 
function (program, name) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
var _location = android.opengl.GLES20.prototype.mContext.getAttribLocation(_program, name);
return _location;
return -1;
}, "~N,~S");
c$.glGetBooleanv = Clazz.defineMethod (c$, "glGetBooleanv", 
function (pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
params[offset] = android.opengl.GLES20.prototype.mContext.getParameter(pname);
}, "~N,~A,~N");
c$.glGetBufferParameteriv = Clazz.defineMethod (c$, "glGetBufferParameteriv", 
function (target, pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
params[offset] = android.opengl.GLES20.prototype.mContext.getBufferParameter(target, pname);
}, "~N,~N,~A,~N");
c$.glGetError = Clazz.defineMethod (c$, "glGetError", 
function () {
if (!android.opengl.GLES20.prototype.mContext) {
throw "No WebGL context is found for GLES20!";
}
var _error = android.opengl.GLES20.prototype.mContext.getError();
return _error;
return 0;
});
c$.glGetFloatv = Clazz.defineMethod (c$, "glGetFloatv", 
function (pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
params[offset] = android.opengl.GLES20.prototype.mContext.getParameter(pname);
}, "~N,~A,~N");
c$.glGetFramebufferAttachmentParameteriv = Clazz.defineMethod (c$, "glGetFramebufferAttachmentParameteriv", 
function (target, attachment, pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _param = android.opengl.GLES20.prototype.mContext.getFramebufferAttachmentParameter(target, attachment, pname);
if (_param) {
if (pname = android.opengl.GLES20.GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME) {
if (_param instanceof WebGLRenderbuffer) {
var _buffer = android.opengl.GLES20.prototype.mRenderBufferArray.indexOf(_param);
params[offset] = _buffer;
} else if (_param instanceof WebGLTexture) {
var _texture = android.opengl.GLES20.prototype.mTextureArray.indexOf(_param);
params[offset] = _texture;
} else {
console.error("Unknow type in glGetFramebufferAttachmentParameteriv");
}
} else {
params[offset] = _param;
}
}
}, "~N,~N,~N,~A,~N");
c$.glGetIntegerv = Clazz.defineMethod (c$, "glGetIntegerv", 
function (pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
var result = android.opengl.GLES20.prototype.mContext.getParameter(pname);
if (pname == android.opengl.GLES20.GL_TEXTURE_BINDING_2D || pname == android.opengl.GLES20.GL_TEXTURE_BINDING_CUBE_MAP) {
result = android.opengl.GLES20.prototype.mTextureArray.indexOf(result);
}
params[offset] = result
}, "~N,~A,~N");
c$.glGetProgramiv = Clazz.defineMethod (c$, "glGetProgramiv", 
function (program, pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
// WebGL does not support these enum because it will return DOMString.
if (pname == android.opengl.GLES20.GL_INFO_LOG_LENGTH ||
pname == android.opengl.GLES20.GL_ACTIVE_ATTRIBUTE_MAX_LENGTH ||
pname == android.opengl.GLES20.GL_ACTIVE_UNIFORM_MAX_LENGTH) {
return;
}
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
var result = android.opengl.GLES20.prototype.mContext.getProgramParameter(_program, pname);
if (result) {
if (pname == android.opengl.GLES20.GL_DELETE_STATUS ||
pname == android.opengl.GLES20.GL_LINK_STATUS ||
pname == android.opengl.GLES20.GL_VALIDATE_STATUS) {
params[offset] = result ? 1 : 0;
} else {
params[offset] = result;
}
}
}, "~N,~N,~A,~N");
c$.glGetProgramInfoLog = Clazz.defineMethod (c$, "glGetProgramInfoLog", 
function (program) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
var _log = android.opengl.GLES20.prototype.mContext.getProgramInfoLog(_program);
return _log;
return null;
}, "~N");
c$.glGetRenderbufferParameteriv = Clazz.defineMethod (c$, "glGetRenderbufferParameteriv", 
function (target, pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
params[offset] = android.opengl.GLES20.prototype.mContext.getRenderbufferParameter(target, pname);
}, "~N,~N,~A,~N");
c$.glGetShaderiv = Clazz.defineMethod (c$, "glGetShaderiv", 
function (shader, pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
// WebGL does not need these two enum because we return DOMString
if (pname == android.opengl.GLES20.GL_INFO_LOG_LENGTH ||
pname == android.opengl.GLES20.GL_SHADER_SOURCE_LENGTH) {
return;
}
var _shader = android.opengl.GLES20.prototype.mShaderArray[shader];
var result = android.opengl.GLES20.prototype.mContext.getShaderParameter(_shader, pname);
if (result) {
if (pname == android.opengl.GLES20.prototype.mContext.SHADER_TYPE) {
params[offset] = result;
} else {
params[offset] = result ? 1 : 0;
}
}
}, "~N,~N,~A,~N");
c$.glGetShaderInfoLog = Clazz.defineMethod (c$, "glGetShaderInfoLog", 
function (shader) {
android.opengl.GLES20.checkWebGLContext ();
var _shader = android.opengl.GLES20.prototype.mShaderArray[shader];
var _log = android.opengl.GLES20.prototype.mContext.getShaderInfoLog(_shader);
return _log;
return null;
}, "~N");
c$.glGetShaderSource = Clazz.defineMethod (c$, "glGetShaderSource", 
function (shader, bufsize, length, lengthOffset, source, sourceOffset) {
android.opengl.GLES20.checkWebGLContext ();
var _shader = android.opengl.GLES20.prototype.mShaderArray[shader];
var _source = android.opengl.GLES20.prototype.mContext.getShaderSource(_shader);
if (_source) {
length[lengthOffset] = _source.length;
for (var i = 0; i < bufsize && i < _source.length; i++) {
source[sourceOffset + i] = _source.charAt(i);
}
}
}, "~N,~N,~A,~N,~A,~N");
c$.glGetString = Clazz.defineMethod (c$, "glGetString", 
function (name) {
android.opengl.GLES20.checkWebGLContext ();
var value = null;
if (name == 7939) {
var extensions = android.opengl.GLES20.prototype.mContext.getSupportedExtensions();
if (extensions) vaule = extensions.toString();
} else {
value = android.opengl.GLES20.prototype.mContext.getParameter(name);
}return value;
}, "~N");
c$.glGetTexParameterfv = Clazz.defineMethod (c$, "glGetTexParameterfv", 
function (target, pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
params[offset] = android.opengl.GLES20.prototype.mContext.getTexParameter(target, pname);
}, "~N,~N,~A,~N");
c$.glGetTexParameteriv = Clazz.defineMethod (c$, "glGetTexParameteriv", 
function (target, pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
params[offset] = android.opengl.GLES20.prototype.mContext.getTexParameter(target, pname);
}, "~N,~N,~A,~N");
c$.glGetUniformLocation = Clazz.defineMethod (c$, "glGetUniformLocation", 
function (program, name) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
var location = android.opengl.GLES20.prototype.mContext.getUniformLocation(_program, name);
if (location) {
android.opengl.GLES20.prototype.mUniformLocationArray.push(location);
return android.opengl.GLES20.prototype.mUniformLocationArray.length - 1;
}
return -1;
}, "~N,~S");
c$.glGetVertexAttribfv = Clazz.defineMethod (c$, "glGetVertexAttribfv", 
function (index, pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
var value = android.opengl.GLES20.prototype.mContext.getVertexAttrib(index, pname);
if (!value) return;
if (pname == 34975) {
var buffer = android.opengl.GLES20.prototype.mBufferArray.indexOf(value);
params[offset] = buffer;
} else if (pname == 34342) {
params[offset + 0] = value[0]; //Float32Array (with 4 elements)
params[offset + 1] = value[1];
params[offset + 2] = value[2];
params[offset + 3] = value[3];
} else if (pname == 34338 || pname == 34922) {
params[offset] = value ? 1 : 0;
} else {
params[offset] = value;
}}, "~N,~N,~A,~N");
c$.glGetVertexAttribiv = Clazz.defineMethod (c$, "glGetVertexAttribiv", 
function (index, pname, params, offset) {
android.opengl.GLES20.checkWebGLContext ();
var value = android.opengl.GLES20.prototype.mContext.getVertexAttrib(index, pname);
if (!value) return;
if (pname == 34975) {
var buffer = android.opengl.GLES20.prototype.mBufferArray.indexOf(value);
params[offset] = buffer;
} else if (pname == 34342) {
params[offset + 0] = value[0]; //Float32Array (with 4 elements)
params[offset + 1] = value[1];
params[offset + 2] = value[2];
params[offset + 3] = value[3];
} else if (pname == 34338 || pname == 34922) {
params[offset] = value ? 1 : 0;
} else {
params[offset] = value;
}}, "~N,~N,~A,~N");
c$.glHint = Clazz.defineMethod (c$, "glHint", 
function (target, mode) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.hint(target, mode);
}, "~N,~N");
c$.glIsBuffer = Clazz.defineMethod (c$, "glIsBuffer", 
function (buffer) {
var result = false;
android.opengl.GLES20.checkWebGLContext ();
var _buffer = android.opengl.GLES20.prototype.mBufferArray[buffer];
result = android.opengl.GLES20.prototype.mContext.isBuffer(_buffer);
return result;
}, "~N");
c$.glIsEnabled = Clazz.defineMethod (c$, "glIsEnabled", 
function (cap) {
var result = false;
android.opengl.GLES20.checkWebGLContext ();
result = android.opengl.GLES20.prototype.mContext.isEnabled(cap);
return result;
}, "~N");
c$.glIsFramebuffer = Clazz.defineMethod (c$, "glIsFramebuffer", 
function (framebuffer) {
var result = false;
android.opengl.GLES20.checkWebGLContext ();
var _buffer = android.opengl.GLES20.prototype.mFrameBufferArray[framebuffer];
result = android.opengl.GLES20.prototype.mContext.isFrameBuffer(_buffer);
return result;
}, "~N");
c$.glIsProgram = Clazz.defineMethod (c$, "glIsProgram", 
function (program) {
var result = false;
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
result = android.opengl.GLES20.prototype.mContext.isProgram(_program);
return result;
}, "~N");
c$.glIsRenderbuffer = Clazz.defineMethod (c$, "glIsRenderbuffer", 
function (renderbuffer) {
var result = false;
android.opengl.GLES20.checkWebGLContext ();
var _renderbuffer = android.opengl.GLES20.prototype.mRenderBufferArray[renderbuffer];
result = android.opengl.GLES20.prototype.mContext.isRenderBuffer(_renderbuffer);
return result;
}, "~N");
c$.glIsShader = Clazz.defineMethod (c$, "glIsShader", 
function (shader) {
var result = false;
android.opengl.GLES20.checkWebGLContext ();
var _shader = android.opengl.GLES20.prototype.mShaderArray[shader];
result = android.opengl.GLES20.prototype.mContext.isShader(_shader);
return result;
}, "~N");
c$.glIsTexture = Clazz.defineMethod (c$, "glIsTexture", 
function (texture) {
var result = false;
android.opengl.GLES20.checkWebGLContext ();
var _texture = android.opengl.GLES20.prototype.mTextureArray[texture];
result = android.opengl.GLES20.prototype.mContext.isTexture(_texture);
return result;
}, "~N");
c$.glLineWidth = Clazz.defineMethod (c$, "glLineWidth", 
function (width) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.lineWidth(width);
}, "~N");
c$.glLinkProgram = Clazz.defineMethod (c$, "glLinkProgram", 
function (program) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
android.opengl.GLES20.prototype.mContext.linkProgram(_program);
}, "~N");
c$.glPixelStorei = Clazz.defineMethod (c$, "glPixelStorei", 
function (pname, param) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.pixelStorei(pname, param);
}, "~N,~N");
c$.glPolygonOffset = Clazz.defineMethod (c$, "glPolygonOffset", 
function (factor, units) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.polygonOffset(factor, units);
}, "~N,~N");
c$.glRenderbufferStorage = Clazz.defineMethod (c$, "glRenderbufferStorage", 
function (target, internalformat, width, height) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.renderbufferStorage(target, internalformat, width, height);
}, "~N,~N,~N,~N");
c$.glSampleCoverage = Clazz.defineMethod (c$, "glSampleCoverage", 
function (value, invert) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.sampleCoverage(value, invert);
}, "~N,~B");
c$.glScissor = Clazz.defineMethod (c$, "glScissor", 
function (x, y, width, height) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.scissor(x, y, width, height);
}, "~N,~N,~N,~N");
c$.glShaderSource = Clazz.defineMethod (c$, "glShaderSource", 
function (shader, string) {
android.opengl.GLES20.checkWebGLContext ();
var _shader = android.opengl.GLES20.prototype.mShaderArray[shader];
android.opengl.GLES20.prototype.mContext.shaderSource(_shader, string);
}, "~N,~S");
c$.glStencilFunc = Clazz.defineMethod (c$, "glStencilFunc", 
function (func, ref, mask) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.stencilFunc(func, ref, mask);
}, "~N,~N,~N");
c$.glStencilFuncSeparate = Clazz.defineMethod (c$, "glStencilFuncSeparate", 
function (face, func, ref, mask) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.stencilFuncSeparate(face, func, ref, mask);
}, "~N,~N,~N,~N");
c$.glStencilMask = Clazz.defineMethod (c$, "glStencilMask", 
function (mask) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.stencilMask(mask);
}, "~N");
c$.glStencilMaskSeparate = Clazz.defineMethod (c$, "glStencilMaskSeparate", 
function (face, mask) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.stencilMaskSeparate(face, mask);
}, "~N,~N");
c$.glStencilOp = Clazz.defineMethod (c$, "glStencilOp", 
function (fail, zfail, zpass) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.stencilOp(fail, zfail, zpass);
}, "~N,~N,~N");
c$.glStencilOpSeparate = Clazz.defineMethod (c$, "glStencilOpSeparate", 
function (face, fail, zfail, zpass) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.stencilOp(fail, zfail, zpass);
}, "~N,~N,~N,~N");
c$.glTexImage2D = Clazz.defineMethod (c$, "glTexImage2D", 
function (target, level, internalformat, width, height, border, format, type, bitmap) {
android.opengl.GLES20.checkWebGLContext ();
bitmap.ensureCachedCanvas();
android.opengl.GLES20.prototype.mContext.texImage2D(target, level, internalformat,
format, type, bitmap.mCachedCanvas);
}, "~N,~N,~N,~N,~N,~N,~N,~N,android.graphics.Bitmap");
c$.glTexImage2D = Clazz.defineMethod (c$, "glTexImage2D", 
function (target, level, internalformat, width, height, border, format, type, pixels) {
android.opengl.GLES20.checkWebGLContext ();
var arraybuffer = null;
if (pixels instanceof java.nio.ByteBuffer) {
arraybuffer = pixels.backingArray;
} else {
arraybuffer = pixels.byteBuffer.backingArray;
}
var offset = pixels.position() * Math.pow(2, pixels._elementSizeShift);
switch (type) {
case android.opengl.GLES20.GL_UNSIGNED_BYTE:
arraybuffer = new Uint8Array(arraybuffer.buffer, offset);
break;
case android.opengl.GLES20.GL_UNSIGNED_SHORT_5_6_5:
case android.opengl.GLES20.GL_UNSIGNED_SHORT_4_4_4_4:
case android.opengl.GLES20.GL_UNSIGNED_SHORT_5_5_5_1:
arraybuffer = new Uint16Array(arraybuffer.buffer, offset);
break;
default:
arraybuffer = new Uint8Array(arraybuffer.buffer, offset);
break;
}
android.opengl.GLES20.prototype.mContext.texImage2D(target, level, internalformat, width, height, border,
format, type, arraybuffer);
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
c$.glTexParameterf = Clazz.defineMethod (c$, "glTexParameterf", 
function (target, pname, param) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.texParameterf(target, pname, param);
}, "~N,~N,~N");
c$.glTexParameteri = Clazz.defineMethod (c$, "glTexParameteri", 
function (target, pname, param) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.texParameteri(target, pname, param);
}, "~N,~N,~N");
c$.glUniform1f = Clazz.defineMethod (c$, "glUniform1f", 
function (location, x) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
android.opengl.GLES20.prototype.mContext.uniform1f(_location, x);
}, "~N,~N");
c$.glUniform1fv = Clazz.defineMethod (c$, "glUniform1fv", 
function (location, count, v, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var uniformArray = v.slice(offset, offset + count);
android.opengl.GLES20.prototype.mContext.uniform1fv(_location, uniformArray);
}, "~N,~N,~A,~N");
c$.glUniform1i = Clazz.defineMethod (c$, "glUniform1i", 
function (location, x) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
android.opengl.GLES20.prototype.mContext.uniform1i(_location, x);
}, "~N,~N");
c$.glUniform1iv = Clazz.defineMethod (c$, "glUniform1iv", 
function (location, count, v, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var uniformArray = value.slice(offset, offset + count);
android.opengl.GLES20.prototype.mContext.uniform1iv(_location, uniformArray);
}, "~N,~N,~A,~N");
c$.glUniform2f = Clazz.defineMethod (c$, "glUniform2f", 
function (location, x, y) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
android.opengl.GLES20.prototype.mContext.uniform2f(_location, x, y);
}, "~N,~N,~N");
c$.glUniform2fv = Clazz.defineMethod (c$, "glUniform2fv", 
function (location, count, v, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var uniformArray = v.slice(offset, offset + count);
android.opengl.GLES20.prototype.mContext.uniform2fv(_location, uniformArray);
}, "~N,~N,~A,~N");
c$.glUniform2i = Clazz.defineMethod (c$, "glUniform2i", 
function (location, x, y) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
android.opengl.GLES20.prototype.mContext.uniform2i(_location, x, y);
}, "~N,~N,~N");
c$.glUniform2iv = Clazz.defineMethod (c$, "glUniform2iv", 
function (location, count, v, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var uniformArray = v.slice(offset, offset + count);
android.opengl.GLES20.prototype.mContext.uniform2iv(_location, uniformArray);
}, "~N,~N,~A,~N");
c$.glUniform3f = Clazz.defineMethod (c$, "glUniform3f", 
function (location, x, y, z) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
android.opengl.GLES20.prototype.mContext.uniform3f(_location, x, y, z);
}, "~N,~N,~N,~N");
c$.glUniform3fv = Clazz.defineMethod (c$, "glUniform3fv", 
function (location, count, v, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var uniformArray = v.slice(offset, offset + count * 3);
android.opengl.GLES20.prototype.mContext.uniform3fv(_location, uniformArray);
}, "~N,~N,~A,~N");
c$.glUniform3i = Clazz.defineMethod (c$, "glUniform3i", 
function (location, x, y, z) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
android.opengl.GLES20.prototype.mContext.uniform3i(_location, x, y, z);
}, "~N,~N,~N,~N");
c$.glUniform3iv = Clazz.defineMethod (c$, "glUniform3iv", 
function (location, count, v, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var uniformArray = v.slice(offset, offset + count);
android.opengl.GLES20.prototype.mContext.uniform3iv(_location, uniformArray);
}, "~N,~N,~A,~N");
c$.glUniform4f = Clazz.defineMethod (c$, "glUniform4f", 
function (location, x, y, z, w) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
android.opengl.GLES20.prototype.mContext.uniform4f(_location, x, y, z, w);
}, "~N,~N,~N,~N,~N");
c$.glUniform4fv = Clazz.defineMethod (c$, "glUniform4fv", 
function (location, count, v, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var uniformArray = v.slice(offset, offset + count * 4);
android.opengl.GLES20.prototype.mContext.uniform4fv(_location, uniformArray);
}, "~N,~N,~A,~N");
c$.glUniform4i = Clazz.defineMethod (c$, "glUniform4i", 
function (location, x, y, z, w) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
android.opengl.GLES20.prototype.mContext.uniform4i(_location, x, y, z, w);
}, "~N,~N,~N,~N,~N");
c$.glUniform4iv = Clazz.defineMethod (c$, "glUniform4iv", 
function (location, count, v, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var uniformArray = v.slice(offset, offset + count);
android.opengl.GLES20.prototype.mContext.uniform4iv(_location, uniformArray);
}, "~N,~N,~A,~N");
c$.glUniformMatrix2fv = Clazz.defineMethod (c$, "glUniformMatrix2fv", 
function (location, count, transpose, value, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var matrixArray = value.slice(offset, offset + count * 4);
android.opengl.GLES20.prototype.mContext.uniformMatrix2fv(_location, transpose, matrixArray);
}, "~N,~N,~B,~A,~N");
c$.glUniformMatrix3fv = Clazz.defineMethod (c$, "glUniformMatrix3fv", 
function (location, count, transpose, value, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var matrixArray = value.slice(offset, offset + count * 9);
android.opengl.GLES20.prototype.mContext.uniformMatrix3fv(_location, transpose, matrixArray);
}, "~N,~N,~B,~A,~N");
c$.glUniformMatrix4fv = Clazz.defineMethod (c$, "glUniformMatrix4fv", 
function (location, count, transpose, value, offset) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var matrixArray = value.slice(offset, offset + count * 16);
android.opengl.GLES20.prototype.mContext.uniformMatrix4fv(_location, transpose, matrixArray);
}, "~N,~N,~B,~A,~N");
c$.glUniformMatrix4fv = Clazz.defineMethod (c$, "glUniformMatrix4fv", 
function (location, count, transpose, value) {
android.opengl.GLES20.checkWebGLContext ();
var _location = android.opengl.GLES20.prototype.mUniformLocationArray[location];
var arraybuffer = value.byteBuffer.backingArray;
var offset = value.position() * Math.pow(2, value._elementSizeShift);
var floatarray = new Float32Array(arraybuffer.buffer, offset, count * 16);
android.opengl.GLES20.prototype.mContext.uniformMatrix4fv(_location, transpose, floatarray);
}, "~N,~N,~B,java.nio.FloatBuffer");
c$.glUseProgram = Clazz.defineMethod (c$, "glUseProgram", 
function (program) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
android.opengl.GLES20.prototype.mContext.useProgram(_program);
}, "~N");
c$.glValidateProgram = Clazz.defineMethod (c$, "glValidateProgram", 
function (program) {
android.opengl.GLES20.checkWebGLContext ();
var _program = android.opengl.GLES20.prototype.mProgramArray[program];
android.opengl.GLES20.prototype.mContext.validateProgram(_program);
}, "~N");
c$.glVertexAttrib1f = Clazz.defineMethod (c$, "glVertexAttrib1f", 
function (indx, x) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.vertexAttrib1f(indx, x);
}, "~N,~N");
c$.glVertexAttrib1fv = Clazz.defineMethod (c$, "glVertexAttrib1fv", 
function (indx, values, offset) {
android.opengl.GLES20.checkWebGLContext ();
var attribArray = value.slice(offset, offset + count);
android.opengl.GLES20.prototype.mContext.vertexAttrib1fv(indx, attribArray);
}, "~N,~A,~N");
c$.glVertexAttrib2f = Clazz.defineMethod (c$, "glVertexAttrib2f", 
function (indx, x, y) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.vertexAttrib2f(indx, x, y);
}, "~N,~N,~N");
c$.glVertexAttrib2fv = Clazz.defineMethod (c$, "glVertexAttrib2fv", 
function (indx, values, offset) {
android.opengl.GLES20.checkWebGLContext ();
var attribArray = value.slice(offset, offset + count * 2);
android.opengl.GLES20.prototype.mContext.vertexAttrib2fv(indx, attribArray);
}, "~N,~A,~N");
c$.glVertexAttrib3f = Clazz.defineMethod (c$, "glVertexAttrib3f", 
function (indx, x, y, z) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.vertexAttrib3f(indx, x, y, z);
}, "~N,~N,~N,~N");
c$.glVertexAttrib3fv = Clazz.defineMethod (c$, "glVertexAttrib3fv", 
function (indx, values, offset) {
android.opengl.GLES20.checkWebGLContext ();
var attribArray = value.slice(offset, offset + count * 3);
android.opengl.GLES20.prototype.mContext.vertexAttrib3fv(indx, attribArray);
}, "~N,~A,~N");
c$.glVertexAttrib4f = Clazz.defineMethod (c$, "glVertexAttrib4f", 
function (indx, x, y, z, w) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.vertexAttrib4f(indx, x, y, z, w);
}, "~N,~N,~N,~N,~N");
c$.glVertexAttrib4fv = Clazz.defineMethod (c$, "glVertexAttrib4fv", 
function (indx, values, offset) {
android.opengl.GLES20.checkWebGLContext ();
var attribArray = value.slice(offset, offset + count * 4);
android.opengl.GLES20.prototype.mContext.vertexAttrib4fv(indx, attribArray);
}, "~N,~A,~N");
c$.glVertexAttribPointer = Clazz.defineMethod (c$, "glVertexAttribPointer", 
function (indx, size, type, normalized, stride, offset) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.vertexAttribPointer(indx, size, type, normalized, stride, offset);
}, "~N,~N,~N,~B,~N,~N");
c$.glVertexAttribPointerBounds = Clazz.defineMethod (c$, "glVertexAttribPointerBounds", 
($fz = function (indx, size, type, normalized, stride, ptr, remaining) {
android.opengl.GLES20.checkWebGLContext ();
// WebGL does not support client side arrays, we need to gen
// a buffer object and upload the data into buffer object, then
// bind the buffer object and call vertexAttribPointer.
if (android.opengl.GLES20.prototype.mCachedBuffer == null) {
android.opengl.GLES20.prototype.mCachedBuffer = android.opengl.GLES20.prototype.mContext.createBuffer();
}
var buffer = android.opengl.GLES20.prototype.mCachedBuffer;
android.opengl.GLES20.prototype.mContext.bindBuffer(android.opengl.GLES20.prototype.mContext.ARRAY_BUFFER, buffer);
var arraybuffer = ptr.byteBuffer.backingArray;
var offset = ptr.position() * Math.pow(2, ptr._elementSizeShift);
android.opengl.GLES20.prototype.mContext.bufferData(android.opengl.GLES20.prototype.mContext.ARRAY_BUFFER, arraybuffer,
android.opengl.GLES20.prototype.mContext.DYNAMIC_DRAW);
android.opengl.GLES20.prototype.mContext.vertexAttribPointer(indx, size, type, normalized, stride, offset);
}, $fz.isPrivate = true, $fz), "~N,~N,~N,~B,~N,java.nio.Buffer,~N");
c$.glVertexAttribPointer = Clazz.defineMethod (c$, "glVertexAttribPointer", 
function (indx, size, type, normalized, stride, ptr) {
android.opengl.GLES20.glVertexAttribPointerBounds (indx, size, type, normalized, stride, ptr, ptr.remaining ());
}, "~N,~N,~N,~B,~N,java.nio.Buffer");
c$.glViewport = Clazz.defineMethod (c$, "glViewport", 
function (x, y, width, height) {
android.opengl.GLES20.checkWebGLContext ();
android.opengl.GLES20.prototype.mContext.viewport(x, y, width, height);
}, "~N,~N,~N,~N");
Clazz.defineStatics (c$,
"GL_ACTIVE_TEXTURE", 0x84E0,
"GL_DEPTH_BUFFER_BIT", 0x00000100,
"GL_STENCIL_BUFFER_BIT", 0x00000400,
"GL_COLOR_BUFFER_BIT", 0x00004000,
"GL_FALSE", 0,
"GL_TRUE", 1,
"GL_POINTS", 0x0000,
"GL_LINES", 0x0001,
"GL_LINE_LOOP", 0x0002,
"GL_LINE_STRIP", 0x0003,
"GL_TRIANGLES", 0x0004,
"GL_TRIANGLE_STRIP", 0x0005,
"GL_TRIANGLE_FAN", 0x0006,
"GL_ZERO", 0,
"GL_ONE", 1,
"GL_SRC_COLOR", 0x0300,
"GL_ONE_MINUS_SRC_COLOR", 0x0301,
"GL_SRC_ALPHA", 0x0302,
"GL_ONE_MINUS_SRC_ALPHA", 0x0303,
"GL_DST_ALPHA", 0x0304,
"GL_ONE_MINUS_DST_ALPHA", 0x0305,
"GL_DST_COLOR", 0x0306,
"GL_ONE_MINUS_DST_COLOR", 0x0307,
"GL_SRC_ALPHA_SATURATE", 0x0308,
"GL_FUNC_ADD", 0x8006,
"GL_BLEND_EQUATION", 0x8009,
"GL_BLEND_EQUATION_RGB", 0x8009,
"GL_BLEND_EQUATION_ALPHA", 0x883D,
"GL_FUNC_SUBTRACT", 0x800A,
"GL_FUNC_REVERSE_SUBTRACT", 0x800B,
"GL_BLEND_DST_RGB", 0x80C8,
"GL_BLEND_SRC_RGB", 0x80C9,
"GL_BLEND_DST_ALPHA", 0x80CA,
"GL_BLEND_SRC_ALPHA", 0x80CB,
"GL_CONSTANT_COLOR", 0x8001,
"GL_ONE_MINUS_CONSTANT_COLOR", 0x8002,
"GL_CONSTANT_ALPHA", 0x8003,
"GL_ONE_MINUS_CONSTANT_ALPHA", 0x8004,
"GL_BLEND_COLOR", 0x8005,
"GL_ARRAY_BUFFER", 0x8892,
"GL_ELEMENT_ARRAY_BUFFER", 0x8893,
"GL_ARRAY_BUFFER_BINDING", 0x8894,
"GL_ELEMENT_ARRAY_BUFFER_BINDING", 0x8895,
"GL_STREAM_DRAW", 0x88E0,
"GL_STATIC_DRAW", 0x88E4,
"GL_DYNAMIC_DRAW", 0x88E8,
"GL_BUFFER_SIZE", 0x8764,
"GL_BUFFER_USAGE", 0x8765,
"GL_CURRENT_VERTEX_ATTRIB", 0x8626,
"GL_FRONT", 0x0404,
"GL_BACK", 0x0405,
"GL_FRONT_AND_BACK", 0x0408,
"GL_TEXTURE_2D", 0x0DE1,
"GL_CULL_FACE", 0x0B44,
"GL_BLEND", 0x0BE2,
"GL_DITHER", 0x0BD0,
"GL_STENCIL_TEST", 0x0B90,
"GL_DEPTH_TEST", 0x0B71,
"GL_SCISSOR_TEST", 0x0C11,
"GL_POLYGON_OFFSET_FILL", 0x8037,
"GL_SAMPLE_ALPHA_TO_COVERAGE", 0x809E,
"GL_SAMPLE_COVERAGE", 0x80A0,
"GL_NO_ERROR", 0,
"GL_INVALID_ENUM", 0x0500,
"GL_INVALID_VALUE", 0x0501,
"GL_INVALID_OPERATION", 0x0502,
"GL_OUT_OF_MEMORY", 0x0505,
"GL_CW", 0x0900,
"GL_CCW", 0x0901,
"GL_LINE_WIDTH", 0x0B21,
"GL_ALIASED_POINT_SIZE_RANGE", 0x846D,
"GL_ALIASED_LINE_WIDTH_RANGE", 0x846E,
"GL_CULL_FACE_MODE", 0x0B45,
"GL_FRONT_FACE", 0x0B46,
"GL_DEPTH_RANGE", 0x0B70,
"GL_DEPTH_WRITEMASK", 0x0B72,
"GL_DEPTH_CLEAR_VALUE", 0x0B73,
"GL_DEPTH_FUNC", 0x0B74,
"GL_STENCIL_CLEAR_VALUE", 0x0B91,
"GL_STENCIL_FUNC", 0x0B92,
"GL_STENCIL_FAIL", 0x0B94,
"GL_STENCIL_PASS_DEPTH_FAIL", 0x0B95,
"GL_STENCIL_PASS_DEPTH_PASS", 0x0B96,
"GL_STENCIL_REF", 0x0B97,
"GL_STENCIL_VALUE_MASK", 0x0B93,
"GL_STENCIL_WRITEMASK", 0x0B98,
"GL_STENCIL_BACK_FUNC", 0x8800,
"GL_STENCIL_BACK_FAIL", 0x8801,
"GL_STENCIL_BACK_PASS_DEPTH_FAIL", 0x8802,
"GL_STENCIL_BACK_PASS_DEPTH_PASS", 0x8803,
"GL_STENCIL_BACK_REF", 0x8CA3,
"GL_STENCIL_BACK_VALUE_MASK", 0x8CA4,
"GL_STENCIL_BACK_WRITEMASK", 0x8CA5,
"GL_VIEWPORT", 0x0BA2,
"GL_SCISSOR_BOX", 0x0C10,
"GL_COLOR_CLEAR_VALUE", 0x0C22,
"GL_COLOR_WRITEMASK", 0x0C23,
"GL_UNPACK_ALIGNMENT", 0x0CF5,
"GL_PACK_ALIGNMENT", 0x0D05,
"GL_MAX_TEXTURE_SIZE", 0x0D33,
"GL_MAX_VIEWPORT_DIMS", 0x0D3A,
"GL_SUBPIXEL_BITS", 0x0D50,
"GL_RED_BITS", 0x0D52,
"GL_GREEN_BITS", 0x0D53,
"GL_BLUE_BITS", 0x0D54,
"GL_ALPHA_BITS", 0x0D55,
"GL_DEPTH_BITS", 0x0D56,
"GL_STENCIL_BITS", 0x0D57,
"GL_POLYGON_OFFSET_UNITS", 0x2A00,
"GL_POLYGON_OFFSET_FACTOR", 0x8038,
"GL_TEXTURE_BINDING_2D", 0x8069,
"GL_SAMPLE_BUFFERS", 0x80A8,
"GL_SAMPLES", 0x80A9,
"GL_SAMPLE_COVERAGE_VALUE", 0x80AA,
"GL_SAMPLE_COVERAGE_INVERT", 0x80AB,
"GL_NUM_COMPRESSED_TEXTURE_FORMATS", 0x86A2,
"GL_COMPRESSED_TEXTURE_FORMATS", 0x86A3,
"GL_DONT_CARE", 0x1100,
"GL_FASTEST", 0x1101,
"GL_NICEST", 0x1102,
"GL_GENERATE_MIPMAP_HINT", 0x8192,
"GL_BYTE", 0x1400,
"GL_UNSIGNED_BYTE", 0x1401,
"GL_SHORT", 0x1402,
"GL_UNSIGNED_SHORT", 0x1403,
"GL_INT", 0x1404,
"GL_UNSIGNED_INT", 0x1405,
"GL_FLOAT", 0x1406,
"GL_FIXED", 0x140C,
"GL_DEPTH_COMPONENT", 0x1902,
"GL_ALPHA", 0x1906,
"GL_RGB", 0x1907,
"GL_RGBA", 0x1908,
"GL_LUMINANCE", 0x1909,
"GL_LUMINANCE_ALPHA", 0x190A,
"GL_UNSIGNED_SHORT_4_4_4_4", 0x8033,
"GL_UNSIGNED_SHORT_5_5_5_1", 0x8034,
"GL_UNSIGNED_SHORT_5_6_5", 0x8363,
"GL_FRAGMENT_SHADER", 0x8B30,
"GL_VERTEX_SHADER", 0x8B31,
"GL_MAX_VERTEX_ATTRIBS", 0x8869,
"GL_MAX_VERTEX_UNIFORM_VECTORS", 0x8DFB,
"GL_MAX_VARYING_VECTORS", 0x8DFC,
"GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS", 0x8B4D,
"GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS", 0x8B4C,
"GL_MAX_TEXTURE_IMAGE_UNITS", 0x8872,
"GL_MAX_FRAGMENT_UNIFORM_VECTORS", 0x8DFD,
"GL_SHADER_TYPE", 0x8B4F,
"GL_DELETE_STATUS", 0x8B80,
"GL_LINK_STATUS", 0x8B82,
"GL_VALIDATE_STATUS", 0x8B83,
"GL_ATTACHED_SHADERS", 0x8B85,
"GL_ACTIVE_UNIFORMS", 0x8B86,
"GL_ACTIVE_UNIFORM_MAX_LENGTH", 0x8B87,
"GL_ACTIVE_ATTRIBUTES", 0x8B89,
"GL_ACTIVE_ATTRIBUTE_MAX_LENGTH", 0x8B8A,
"GL_SHADING_LANGUAGE_VERSION", 0x8B8C,
"GL_CURRENT_PROGRAM", 0x8B8D,
"GL_NEVER", 0x0200,
"GL_LESS", 0x0201,
"GL_EQUAL", 0x0202,
"GL_LEQUAL", 0x0203,
"GL_GREATER", 0x0204,
"GL_NOTEQUAL", 0x0205,
"GL_GEQUAL", 0x0206,
"GL_ALWAYS", 0x0207,
"GL_KEEP", 0x1E00,
"GL_REPLACE", 0x1E01,
"GL_INCR", 0x1E02,
"GL_DECR", 0x1E03,
"GL_INVERT", 0x150A,
"GL_INCR_WRAP", 0x8507,
"GL_DECR_WRAP", 0x8508,
"GL_VENDOR", 0x1F00,
"GL_RENDERER", 0x1F01,
"GL_VERSION", 0x1F02,
"GL_EXTENSIONS", 0x1F03,
"GL_NEAREST", 0x2600,
"GL_LINEAR", 0x2601,
"GL_NEAREST_MIPMAP_NEAREST", 0x2700,
"GL_LINEAR_MIPMAP_NEAREST", 0x2701,
"GL_NEAREST_MIPMAP_LINEAR", 0x2702,
"GL_LINEAR_MIPMAP_LINEAR", 0x2703,
"GL_TEXTURE_MAG_FILTER", 0x2800,
"GL_TEXTURE_MIN_FILTER", 0x2801,
"GL_TEXTURE_WRAP_S", 0x2802,
"GL_TEXTURE_WRAP_T", 0x2803,
"GL_TEXTURE", 0x1702,
"GL_TEXTURE_CUBE_MAP", 0x8513,
"GL_TEXTURE_BINDING_CUBE_MAP", 0x8514,
"GL_TEXTURE_CUBE_MAP_POSITIVE_X", 0x8515,
"GL_TEXTURE_CUBE_MAP_NEGATIVE_X", 0x8516,
"GL_TEXTURE_CUBE_MAP_POSITIVE_Y", 0x8517,
"GL_TEXTURE_CUBE_MAP_NEGATIVE_Y", 0x8518,
"GL_TEXTURE_CUBE_MAP_POSITIVE_Z", 0x8519,
"GL_TEXTURE_CUBE_MAP_NEGATIVE_Z", 0x851A,
"GL_MAX_CUBE_MAP_TEXTURE_SIZE", 0x851C,
"GL_TEXTURE0", 0x84C0,
"GL_TEXTURE1", 0x84C1,
"GL_TEXTURE2", 0x84C2,
"GL_TEXTURE3", 0x84C3,
"GL_TEXTURE4", 0x84C4,
"GL_TEXTURE5", 0x84C5,
"GL_TEXTURE6", 0x84C6,
"GL_TEXTURE7", 0x84C7,
"GL_TEXTURE8", 0x84C8,
"GL_TEXTURE9", 0x84C9,
"GL_TEXTURE10", 0x84CA,
"GL_TEXTURE11", 0x84CB,
"GL_TEXTURE12", 0x84CC,
"GL_TEXTURE13", 0x84CD,
"GL_TEXTURE14", 0x84CE,
"GL_TEXTURE15", 0x84CF,
"GL_TEXTURE16", 0x84D0,
"GL_TEXTURE17", 0x84D1,
"GL_TEXTURE18", 0x84D2,
"GL_TEXTURE19", 0x84D3,
"GL_TEXTURE20", 0x84D4,
"GL_TEXTURE21", 0x84D5,
"GL_TEXTURE22", 0x84D6,
"GL_TEXTURE23", 0x84D7,
"GL_TEXTURE24", 0x84D8,
"GL_TEXTURE25", 0x84D9,
"GL_TEXTURE26", 0x84DA,
"GL_TEXTURE27", 0x84DB,
"GL_TEXTURE28", 0x84DC,
"GL_TEXTURE29", 0x84DD,
"GL_TEXTURE30", 0x84DE,
"GL_TEXTURE31", 0x84DF,
"GL_REPEAT", 0x2901,
"GL_CLAMP_TO_EDGE", 0x812F,
"GL_MIRRORED_REPEAT", 0x8370,
"GL_FLOAT_VEC2", 0x8B50,
"GL_FLOAT_VEC3", 0x8B51,
"GL_FLOAT_VEC4", 0x8B52,
"GL_INT_VEC2", 0x8B53,
"GL_INT_VEC3", 0x8B54,
"GL_INT_VEC4", 0x8B55,
"GL_BOOL", 0x8B56,
"GL_BOOL_VEC2", 0x8B57,
"GL_BOOL_VEC3", 0x8B58,
"GL_BOOL_VEC4", 0x8B59,
"GL_FLOAT_MAT2", 0x8B5A,
"GL_FLOAT_MAT3", 0x8B5B,
"GL_FLOAT_MAT4", 0x8B5C,
"GL_SAMPLER_2D", 0x8B5E,
"GL_SAMPLER_CUBE", 0x8B60,
"GL_VERTEX_ATTRIB_ARRAY_ENABLED", 0x8622,
"GL_VERTEX_ATTRIB_ARRAY_SIZE", 0x8623,
"GL_VERTEX_ATTRIB_ARRAY_STRIDE", 0x8624,
"GL_VERTEX_ATTRIB_ARRAY_TYPE", 0x8625,
"GL_VERTEX_ATTRIB_ARRAY_NORMALIZED", 0x886A,
"GL_VERTEX_ATTRIB_ARRAY_POINTER", 0x8645,
"GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING", 0x889F,
"GL_IMPLEMENTATION_COLOR_READ_TYPE", 0x8B9A,
"GL_IMPLEMENTATION_COLOR_READ_FORMAT", 0x8B9B,
"GL_COMPILE_STATUS", 0x8B81,
"GL_INFO_LOG_LENGTH", 0x8B84,
"GL_SHADER_SOURCE_LENGTH", 0x8B88,
"GL_SHADER_COMPILER", 0x8DFA,
"GL_SHADER_BINARY_FORMATS", 0x8DF8,
"GL_NUM_SHADER_BINARY_FORMATS", 0x8DF9,
"GL_LOW_FLOAT", 0x8DF0,
"GL_MEDIUM_FLOAT", 0x8DF1,
"GL_HIGH_FLOAT", 0x8DF2,
"GL_LOW_INT", 0x8DF3,
"GL_MEDIUM_INT", 0x8DF4,
"GL_HIGH_INT", 0x8DF5,
"GL_FRAMEBUFFER", 0x8D40,
"GL_RENDERBUFFER", 0x8D41,
"GL_RGBA4", 0x8056,
"GL_RGB5_A1", 0x8057,
"GL_RGB565", 0x8D62,
"GL_DEPTH_COMPONENT16", 0x81A5,
"GL_STENCIL_INDEX", 0x1901,
"GL_STENCIL_INDEX8", 0x8D48,
"GL_RENDERBUFFER_WIDTH", 0x8D42,
"GL_RENDERBUFFER_HEIGHT", 0x8D43,
"GL_RENDERBUFFER_INTERNAL_FORMAT", 0x8D44,
"GL_RENDERBUFFER_RED_SIZE", 0x8D50,
"GL_RENDERBUFFER_GREEN_SIZE", 0x8D51,
"GL_RENDERBUFFER_BLUE_SIZE", 0x8D52,
"GL_RENDERBUFFER_ALPHA_SIZE", 0x8D53,
"GL_RENDERBUFFER_DEPTH_SIZE", 0x8D54,
"GL_RENDERBUFFER_STENCIL_SIZE", 0x8D55,
"GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE", 0x8CD0,
"GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME", 0x8CD1,
"GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL", 0x8CD2,
"GL_FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE", 0x8CD3,
"GL_COLOR_ATTACHMENT0", 0x8CE0,
"GL_DEPTH_ATTACHMENT", 0x8D00,
"GL_STENCIL_ATTACHMENT", 0x8D20,
"GL_NONE", 0,
"GL_FRAMEBUFFER_COMPLETE", 0x8CD5,
"GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT", 0x8CD6,
"GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT", 0x8CD7,
"GL_FRAMEBUFFER_INCOMPLETE_DIMENSIONS", 0x8CD9,
"GL_FRAMEBUFFER_UNSUPPORTED", 0x8CDD,
"GL_FRAMEBUFFER_BINDING", 0x8CA6,
"GL_RENDERBUFFER_BINDING", 0x8CA7,
"GL_MAX_RENDERBUFFER_SIZE", 0x84E8,
"GL_INVALID_FRAMEBUFFER_OPERATION", 0x0506,
"DEBUG", false);
});
