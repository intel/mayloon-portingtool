﻿Clazz.declarePackage ("android.opengl");
Clazz.load (null, "android.opengl.GLU", ["android.opengl.Matrix"], function () {
c$ = Clazz.declareType (android.opengl, "GLU");
c$.gluErrorString = Clazz.defineMethod (c$, "gluErrorString", 
function (error) {
switch (error) {
case 0:
return "no error";
case 1280:
return "invalid enum";
case 1281:
return "invalid value";
case 1282:
return "invalid operation";
case 1283:
return "stack overflow";
case 1284:
return "stack underflow";
case 1285:
return "out of memory";
default:
return null;
}
}, "~N");
c$.gluLookAt = Clazz.defineMethod (c$, "gluLookAt", 
function (gl, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ) {
var scratch = android.opengl.GLU.sScratch;
{
android.opengl.Matrix.setLookAtM (scratch, 0, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);
gl.glMultMatrixf (scratch, 0);
}}, "javax.microedition.khronos.opengles.GL10,~N,~N,~N,~N,~N,~N,~N,~N,~N");
c$.gluOrtho2D = Clazz.defineMethod (c$, "gluOrtho2D", 
function (gl, left, right, bottom, top) {
gl.glOrthof (left, right, bottom, top, -1.0, 1.0);
}, "javax.microedition.khronos.opengles.GL10,~N,~N,~N,~N");
c$.gluPerspective = Clazz.defineMethod (c$, "gluPerspective", 
function (gl, fovy, aspect, zNear, zFar) {
var top = zNear * Math.tan (fovy * (0.008726646259971648));
var bottom = -top;
var left = bottom * aspect;
var right = top * aspect;
gl.glFrustumf (left, right, bottom, top, zNear, zFar);
}, "javax.microedition.khronos.opengles.GL10,~N,~N,~N,~N");
c$.gluProject = Clazz.defineMethod (c$, "gluProject", 
function (objX, objY, objZ, model, modelOffset, project, projectOffset, view, viewOffset, win, winOffset) {
var scratch = android.opengl.GLU.sScratch;
{
var M_OFFSET = 0;
var V_OFFSET = 16;
var V2_OFFSET = 20;
android.opengl.Matrix.multiplyMM (scratch, 0, project, projectOffset, model, modelOffset);
scratch[16] = objX;
scratch[17] = objY;
scratch[18] = objZ;
scratch[19] = 1.0;
android.opengl.Matrix.multiplyMV (scratch, 20, scratch, 0, scratch, 16);
var w = scratch[23];
if (w == 0.0) {
return 0;
}var rw = 1.0 / w;
win[winOffset] = view[viewOffset] + view[viewOffset + 2] * (scratch[20] * rw + 1.0) * 0.5;
win[winOffset + 1] = view[viewOffset + 1] + view[viewOffset + 3] * (scratch[21] * rw + 1.0) * 0.5;
win[winOffset + 2] = (scratch[22] * rw + 1.0) * 0.5;
}return 1;
}, "~N,~N,~N,~A,~N,~A,~N,~A,~N,~A,~N");
c$.gluUnProject = Clazz.defineMethod (c$, "gluUnProject", 
function (winX, winY, winZ, model, modelOffset, project, projectOffset, view, viewOffset, obj, objOffset) {
var scratch = android.opengl.GLU.sScratch;
{
var PM_OFFSET = 0;
var INVPM_OFFSET = 16;
var V_OFFSET = 0;
android.opengl.Matrix.multiplyMM (scratch, 0, project, projectOffset, model, modelOffset);
if (!android.opengl.Matrix.invertM (scratch, 16, scratch, 0)) {
return 0;
}scratch[0] = 2.0 * (winX - view[viewOffset + 0]) / view[viewOffset + 2] - 1.0;
scratch[1] = 2.0 * (winY - view[viewOffset + 1]) / view[viewOffset + 3] - 1.0;
scratch[2] = 2.0 * winZ - 1.0;
scratch[3] = 1.0;
android.opengl.Matrix.multiplyMV (obj, objOffset, scratch, 16, scratch, 0);
}return 1;
}, "~N,~N,~N,~A,~N,~A,~N,~A,~N,~A,~N");
Clazz.defineStatics (c$,
"sScratch",  Clazz.newArray (32, 0));
});
