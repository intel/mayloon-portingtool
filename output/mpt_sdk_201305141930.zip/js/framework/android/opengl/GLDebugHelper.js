﻿Clazz.declarePackage ("android.opengl");
Clazz.load (null, "android.opengl.GLDebugHelper", ["android.opengl.EGLLogWrapper", "$.GLErrorWrapper", "$.GLLogWrapper"], function () {
c$ = Clazz.declareType (android.opengl, "GLDebugHelper");
c$.wrap = Clazz.defineMethod (c$, "wrap", 
function (gl, configFlags, log) {
if (configFlags != 0) {
gl =  new android.opengl.GLErrorWrapper (gl, configFlags);
}if (log != null) {
var logArgumentNames = (4 & configFlags) != 0;
gl =  new android.opengl.GLLogWrapper (gl, log, logArgumentNames);
}return gl;
}, "javax.microedition.khronos.opengles.GL,~N,java.io.Writer");
c$.wrap = Clazz.defineMethod (c$, "wrap", 
function (egl, configFlags, log) {
if (log != null) {
egl =  new android.opengl.EGLLogWrapper (egl, configFlags, log);
}return egl;
}, "javax.microedition.khronos.egl.EGL,~N,java.io.Writer");
Clazz.defineStatics (c$,
"CONFIG_CHECK_GL_ERROR", (1),
"CONFIG_CHECK_THREAD", (2),
"CONFIG_LOG_ARGUMENT_NAMES", (4),
"ERROR_WRONG_THREAD", 0x7000);
});
