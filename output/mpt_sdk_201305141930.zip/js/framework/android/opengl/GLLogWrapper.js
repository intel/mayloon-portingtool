﻿Clazz.declarePackage ("android.opengl");
Clazz.load (["android.opengl.GLWrapperBase"], "android.opengl.GLLogWrapper", ["java.lang.Boolean", "$.Float", "$.RuntimeException", "$.StringBuilder", "java.nio.ByteBuffer", "$.ByteOrder", "java.util.Arrays"], function () {
c$ = Clazz.decorateAsClass (function () {
if (!Clazz.isClassDefined ("android.opengl.GLLogWrapper.PointerInfo")) {
android.opengl.GLLogWrapper.$GLLogWrapper$PointerInfo$ ();
}
this.mLog = null;
this.mLogArgumentNames = false;
this.mArgCount = 0;
this.mColorPointer = null;
this.mNormalPointer = null;
this.mTexCoordPointer = null;
this.mVertexPointer = null;
this.mColorArrayEnabled = false;
this.mNormalArrayEnabled = false;
this.mTextureCoordArrayEnabled = false;
this.mVertexArrayEnabled = false;
this.mStringBuilder = null;
Clazz.instantialize (this, arguments);
}, android.opengl, "GLLogWrapper", android.opengl.GLWrapperBase);
Clazz.prepareFields (c$, function () {
this.mColorPointer = Clazz.innerTypeInstance (android.opengl.GLLogWrapper.PointerInfo, this, null);
this.mNormalPointer = Clazz.innerTypeInstance (android.opengl.GLLogWrapper.PointerInfo, this, null);
this.mTexCoordPointer = Clazz.innerTypeInstance (android.opengl.GLLogWrapper.PointerInfo, this, null);
this.mVertexPointer = Clazz.innerTypeInstance (android.opengl.GLLogWrapper.PointerInfo, this, null);
});
Clazz.makeConstructor (c$, 
function (gl, log, logArgumentNames) {
Clazz.superConstructor (this, android.opengl.GLLogWrapper, [gl]);
this.mLog = log;
this.mLogArgumentNames = logArgumentNames;
}, "javax.microedition.khronos.opengles.GL,java.io.Writer,~B");
Clazz.defineMethod (c$, "checkError", 
($fz = function () {
var glError;
if ((glError = this.mgl.glGetError ()) != 0) {
var errorMessage = "glError: " + Integer.toString (glError);
this.logLine (errorMessage);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "logLine", 
($fz = function (message) {
this.log (message + '\n');
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "log", 
($fz = function (message) {
try {
this.mLog.write (message);
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "begin", 
($fz = function (name) {
this.log (name + '(');
this.mArgCount = 0;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, value) {
if (this.mArgCount++ > 0) {
this.log (", ");
}if (this.mLogArgumentNames) {
this.log (name + "=");
}this.log (value);
}, $fz.isPrivate = true, $fz), "~S,~S");
Clazz.defineMethod (c$, "end", 
($fz = function () {
this.log (");\n");
this.flush ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "flush", 
($fz = function () {
try {
this.mLog.flush ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
this.mLog = null;
} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "arg", 
($fz = function (name, value) {
this.arg (name, Boolean.toString (value));
}, $fz.isPrivate = true, $fz), "~S,~B");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, value) {
this.arg (name, Integer.toString (value));
}, $fz.isPrivate = true, $fz), "~S,~N");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, value) {
this.arg (name, Float.toString (value));
}, $fz.isPrivate = true, $fz), "~S,~N");
Clazz.defineMethod (c$, "returns", 
($fz = function (result) {
this.log (") returns " + result + ";\n");
this.flush ();
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "returns", 
($fz = function (result) {
this.returns (Integer.toString (result));
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, n, arr, offset) {
this.arg (name, this.toString (n, 0, arr, offset));
}, $fz.isPrivate = true, $fz), "~S,~N,~A,~N");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, n, arr, offset) {
this.arg (name, this.toString (n, arr, offset));
}, $fz.isPrivate = true, $fz), "~S,~N,~A,~N");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, n, arr, offset) {
this.arg (name, this.toString (n, arr, offset));
}, $fz.isPrivate = true, $fz), "~S,~N,~A,~N");
Clazz.defineMethod (c$, "formattedAppend", 
($fz = function (buf, value, format) {
switch (format) {
case 0:
buf.append (value);
break;
case 1:
buf.append (Float.intBitsToFloat (value));
break;
case 2:
buf.append (value / 65536.0);
break;
}
}, $fz.isPrivate = true, $fz), "StringBuilder,~N,~N");
Clazz.defineMethod (c$, "toString", 
($fz = function (n, format, arr, offset) {
var buf =  new StringBuilder ();
buf.append ("{\n");
var arrLen = arr.length;
for (var i = 0; i < n; i++) {
var index = offset + i;
buf.append (" [" + index + "] = ");
if (index < 0 || index >= arrLen) {
buf.append ("out of bounds");
} else {
this.formattedAppend (buf, arr[index], format);
}buf.append ('\n');
}
buf.append ("}");
return buf.toString ();
}, $fz.isPrivate = true, $fz), "~N,~N,~A,~N");
Clazz.defineMethod (c$, "toString", 
($fz = function (n, arr, offset) {
var buf =  new StringBuilder ();
buf.append ("{\n");
var arrLen = arr.length;
for (var i = 0; i < n; i++) {
var index = offset + i;
buf.append (" [" + index + "] = ");
if (index < 0 || index >= arrLen) {
buf.append ("out of bounds");
} else {
buf.append (arr[index]);
}buf.append ('\n');
}
buf.append ("}");
return buf.toString ();
}, $fz.isPrivate = true, $fz), "~N,~A,~N");
Clazz.defineMethod (c$, "toString", 
($fz = function (n, arr, offset) {
var buf =  new StringBuilder ();
buf.append ("{\n");
var arrLen = arr.length;
for (var i = 0; i < n; i++) {
var index = offset + i;
buf.append ("[" + index + "] = ");
if (index < 0 || index >= arrLen) {
buf.append ("out of bounds");
} else {
buf.append (arr[index]);
}buf.append ('\n');
}
buf.append ("}");
return buf.toString ();
}, $fz.isPrivate = true, $fz), "~N,~A,~N");
Clazz.defineMethod (c$, "toString", 
($fz = function (n, buf) {
var builder =  new StringBuilder ();
builder.append ("{\n");
for (var i = 0; i < n; i++) {
builder.append (" [" + i + "] = " + buf.get (i) + '\n');
}
builder.append ("}");
return builder.toString ();
}, $fz.isPrivate = true, $fz), "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "toString", 
($fz = function (n, format, buf) {
var builder =  new StringBuilder ();
builder.append ("{\n");
for (var i = 0; i < n; i++) {
builder.append (" [" + i + "] = ");
this.formattedAppend (builder, buf.get (i), format);
builder.append ('\n');
}
builder.append ("}");
return builder.toString ();
}, $fz.isPrivate = true, $fz), "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "toString", 
($fz = function (n, buf) {
var builder =  new StringBuilder ();
builder.append ("{\n");
for (var i = 0; i < n; i++) {
builder.append (" [" + i + "] = " + buf.get (i) + '\n');
}
builder.append ("}");
return builder.toString ();
}, $fz.isPrivate = true, $fz), "~N,java.nio.ShortBuffer");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, n, buf) {
this.arg (name, this.toString (n, buf));
}, $fz.isPrivate = true, $fz), "~S,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, n, buf) {
this.arg (name, this.toString (n, 0, buf));
}, $fz.isPrivate = true, $fz), "~S,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, n, buf) {
this.arg (name, this.toString (n, buf));
}, $fz.isPrivate = true, $fz), "~S,~N,java.nio.ShortBuffer");
Clazz.defineMethod (c$, "argPointer", 
($fz = function (size, type, stride, pointer) {
this.arg ("size", size);
this.arg ("type", this.getPointerTypeName (type));
this.arg ("stride", stride);
this.arg ("pointer", pointer.toString ());
}, $fz.isPrivate = true, $fz), "~N,~N,~N,java.nio.Buffer");
c$.getHex = Clazz.defineMethod (c$, "getHex", 
($fz = function (value) {
return "0x" + Integer.toHexString (value);
}, $fz.isPrivate = true, $fz), "~N");
c$.getErrorString = Clazz.defineMethod (c$, "getErrorString", 
function (error) {
switch (error) {
case 0:
return "GL_NO_ERROR";
case 1280:
return "GL_INVALID_ENUM";
case 1281:
return "GL_INVALID_VALUE";
case 1282:
return "GL_INVALID_OPERATION";
case 1283:
return "GL_STACK_OVERFLOW";
case 1284:
return "GL_STACK_UNDERFLOW";
case 1285:
return "GL_OUT_OF_MEMORY";
default:
return android.opengl.GLLogWrapper.getHex (error);
}
}, "~N");
Clazz.defineMethod (c$, "getClearBufferMask", 
($fz = function (mask) {
var b =  new StringBuilder ();
if ((mask & 256) != 0) {
b.append ("GL_DEPTH_BUFFER_BIT");
mask &= -257;
}if ((mask & 1024) != 0) {
if (b.length () > 0) {
b.append (" | ");
}b.append ("GL_STENCIL_BUFFER_BIT");
mask &= -1025;
}if ((mask & 16384) != 0) {
if (b.length () > 0) {
b.append (" | ");
}b.append ("GL_COLOR_BUFFER_BIT");
mask &= -16385;
}if (mask != 0) {
if (b.length () > 0) {
b.append (" | ");
}b.append (android.opengl.GLLogWrapper.getHex (mask));
}return b.toString ();
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getFactor", 
($fz = function (factor) {
switch (factor) {
case 0:
return "GL_ZERO";
case 1:
return "GL_ONE";
case 768:
return "GL_SRC_COLOR";
case 769:
return "GL_ONE_MINUS_SRC_COLOR";
case 774:
return "GL_DST_COLOR";
case 775:
return "GL_ONE_MINUS_DST_COLOR";
case 770:
return "GL_SRC_ALPHA";
case 771:
return "GL_ONE_MINUS_SRC_ALPHA";
case 772:
return "GL_DST_ALPHA";
case 773:
return "GL_ONE_MINUS_DST_ALPHA";
case 776:
return "GL_SRC_ALPHA_SATURATE";
default:
return android.opengl.GLLogWrapper.getHex (factor);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getShadeModel", 
($fz = function (model) {
switch (model) {
case 7424:
return "GL_FLAT";
case 7425:
return "GL_SMOOTH";
default:
return android.opengl.GLLogWrapper.getHex (model);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getTextureTarget", 
($fz = function (target) {
switch (target) {
case 3553:
return "GL_TEXTURE_2D";
default:
return android.opengl.GLLogWrapper.getHex (target);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getTextureEnvTarget", 
($fz = function (target) {
switch (target) {
case 8960:
return "GL_TEXTURE_ENV";
default:
return android.opengl.GLLogWrapper.getHex (target);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getTextureEnvPName", 
($fz = function (pname) {
switch (pname) {
case 8704:
return "GL_TEXTURE_ENV_MODE";
case 8705:
return "GL_TEXTURE_ENV_COLOR";
default:
return android.opengl.GLLogWrapper.getHex (pname);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getTextureEnvParamCount", 
($fz = function (pname) {
switch (pname) {
case 8704:
return 1;
case 8705:
return 4;
default:
return 0;
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getTextureEnvParamName", 
($fz = function (param) {
var iparam = Math.round (param);
if (param == iparam) {
switch (iparam) {
case 7681:
return "GL_REPLACE";
case 8448:
return "GL_MODULATE";
case 8449:
return "GL_DECAL";
case 3042:
return "GL_BLEND";
case 260:
return "GL_ADD";
case 34160:
return "GL_COMBINE";
default:
return android.opengl.GLLogWrapper.getHex (iparam);
}
}return Float.toString (param);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getMatrixMode", 
($fz = function (matrixMode) {
switch (matrixMode) {
case 5888:
return "GL_MODELVIEW";
case 5889:
return "GL_PROJECTION";
case 5890:
return "GL_TEXTURE";
default:
return android.opengl.GLLogWrapper.getHex (matrixMode);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getClientState", 
($fz = function (clientState) {
switch (clientState) {
case 32886:
return "GL_COLOR_ARRAY";
case 32884:
return "GL_VERTEX_ARRAY";
case 32885:
return "GL_NORMAL_ARRAY";
case 32888:
return "GL_TEXTURE_COORD_ARRAY";
default:
return android.opengl.GLLogWrapper.getHex (clientState);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getCap", 
($fz = function (cap) {
switch (cap) {
case 2912:
return "GL_FOG";
case 2896:
return "GL_LIGHTING";
case 3553:
return "GL_TEXTURE_2D";
case 2884:
return "GL_CULL_FACE";
case 3008:
return "GL_ALPHA_TEST";
case 3042:
return "GL_BLEND";
case 3058:
return "GL_COLOR_LOGIC_OP";
case 3024:
return "GL_DITHER";
case 2960:
return "GL_STENCIL_TEST";
case 2929:
return "GL_DEPTH_TEST";
case 16384:
return "GL_LIGHT0";
case 16385:
return "GL_LIGHT1";
case 16386:
return "GL_LIGHT2";
case 16387:
return "GL_LIGHT3";
case 16388:
return "GL_LIGHT4";
case 16389:
return "GL_LIGHT5";
case 16390:
return "GL_LIGHT6";
case 16391:
return "GL_LIGHT7";
case 2832:
return "GL_POINT_SMOOTH";
case 2848:
return "GL_LINE_SMOOTH";
case 2903:
return "GL_COLOR_MATERIAL";
case 2977:
return "GL_NORMALIZE";
case 32826:
return "GL_RESCALE_NORMAL";
case 32884:
return "GL_VERTEX_ARRAY";
case 32885:
return "GL_NORMAL_ARRAY";
case 32886:
return "GL_COLOR_ARRAY";
case 32888:
return "GL_TEXTURE_COORD_ARRAY";
case 32925:
return "GL_MULTISAMPLE";
case 32926:
return "GL_SAMPLE_ALPHA_TO_COVERAGE";
case 32927:
return "GL_SAMPLE_ALPHA_TO_ONE";
case 32928:
return "GL_SAMPLE_COVERAGE";
case 3089:
return "GL_SCISSOR_TEST";
default:
return android.opengl.GLLogWrapper.getHex (cap);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getTexturePName", 
($fz = function (pname) {
switch (pname) {
case 10240:
return "GL_TEXTURE_MAG_FILTER";
case 10241:
return "GL_TEXTURE_MIN_FILTER";
case 10242:
return "GL_TEXTURE_WRAP_S";
case 10243:
return "GL_TEXTURE_WRAP_T";
case 33169:
return "GL_GENERATE_MIPMAP";
case 35741:
return "GL_TEXTURE_CROP_RECT_OES";
default:
return android.opengl.GLLogWrapper.getHex (pname);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getTextureParamName", 
($fz = function (param) {
var iparam = Math.round (param);
if (param == iparam) {
switch (iparam) {
case 33071:
return "GL_CLAMP_TO_EDGE";
case 10497:
return "GL_REPEAT";
case 9728:
return "GL_NEAREST";
case 9729:
return "GL_LINEAR";
case 9984:
return "GL_NEAREST_MIPMAP_NEAREST";
case 9985:
return "GL_LINEAR_MIPMAP_NEAREST";
case 9986:
return "GL_NEAREST_MIPMAP_LINEAR";
case 9987:
return "GL_LINEAR_MIPMAP_LINEAR";
default:
return android.opengl.GLLogWrapper.getHex (iparam);
}
}return Float.toString (param);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getFogPName", 
($fz = function (pname) {
switch (pname) {
case 2914:
return "GL_FOG_DENSITY";
case 2915:
return "GL_FOG_START";
case 2916:
return "GL_FOG_END";
case 2917:
return "GL_FOG_MODE";
case 2918:
return "GL_FOG_COLOR";
default:
return android.opengl.GLLogWrapper.getHex (pname);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getFogParamCount", 
($fz = function (pname) {
switch (pname) {
case 2914:
return 1;
case 2915:
return 1;
case 2916:
return 1;
case 2917:
return 1;
case 2918:
return 4;
default:
return 0;
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getBeginMode", 
($fz = function (mode) {
switch (mode) {
case 0:
return "GL_POINTS";
case 1:
return "GL_LINES";
case 2:
return "GL_LINE_LOOP";
case 3:
return "GL_LINE_STRIP";
case 4:
return "GL_TRIANGLES";
case 5:
return "GL_TRIANGLE_STRIP";
case 6:
return "GL_TRIANGLE_FAN";
default:
return android.opengl.GLLogWrapper.getHex (mode);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getIndexType", 
($fz = function (type) {
switch (type) {
case 5123:
return "GL_UNSIGNED_SHORT";
case 5121:
return "GL_UNSIGNED_BYTE";
default:
return android.opengl.GLLogWrapper.getHex (type);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getIntegerStateName", 
($fz = function (pname) {
switch (pname) {
case 3413:
return "GL_ALPHA_BITS";
case 33902:
return "GL_ALIASED_LINE_WIDTH_RANGE";
case 33901:
return "GL_ALIASED_POINT_SIZE_RANGE";
case 3412:
return "GL_BLUE_BITS";
case 34467:
return "GL_COMPRESSED_TEXTURE_FORMATS";
case 3414:
return "GL_DEPTH_BITS";
case 3411:
return "GL_GREEN_BITS";
case 33001:
return "GL_MAX_ELEMENTS_INDICES";
case 33000:
return "GL_MAX_ELEMENTS_VERTICES";
case 3377:
return "GL_MAX_LIGHTS";
case 3379:
return "GL_MAX_TEXTURE_SIZE";
case 3386:
return "GL_MAX_VIEWPORT_DIMS";
case 3382:
return "GL_MAX_MODELVIEW_STACK_DEPTH";
case 3384:
return "GL_MAX_PROJECTION_STACK_DEPTH";
case 3385:
return "GL_MAX_TEXTURE_STACK_DEPTH";
case 34018:
return "GL_MAX_TEXTURE_UNITS";
case 34466:
return "GL_NUM_COMPRESSED_TEXTURE_FORMATS";
case 3410:
return "GL_RED_BITS";
case 2850:
return "GL_SMOOTH_LINE_WIDTH_RANGE";
case 2834:
return "GL_SMOOTH_POINT_SIZE_RANGE";
case 3415:
return "GL_STENCIL_BITS";
case 3408:
return "GL_SUBPIXEL_BITS";
case 35213:
return "GL_MODELVIEW_MATRIX_FLOAT_AS_INT_BITS_OES";
case 35214:
return "GL_PROJECTION_MATRIX_FLOAT_AS_INT_BITS_OES";
case 35215:
return "GL_TEXTURE_MATRIX_FLOAT_AS_INT_BITS_OES";
default:
return android.opengl.GLLogWrapper.getHex (pname);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getIntegerStateSize", 
($fz = function (pname) {
switch (pname) {
case 3413:
return 1;
case 33902:
return 2;
case 33901:
return 2;
case 3412:
return 1;
case 34467:
{
var buffer =  Clazz.newArray (1, 0);
this.mgl.glGetIntegerv (34466, buffer, 0);
return buffer[0];
}case 3414:
return 1;
case 3411:
return 1;
case 33001:
return 1;
case 33000:
return 1;
case 3377:
return 1;
case 3379:
return 1;
case 3386:
return 2;
case 3382:
return 1;
case 3384:
return 1;
case 3385:
return 1;
case 34018:
return 1;
case 34466:
return 1;
case 3410:
return 1;
case 2850:
return 2;
case 2834:
return 2;
case 3415:
return 1;
case 3408:
return 1;
case 35213:
case 35214:
case 35215:
return 16;
default:
return 0;
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getIntegerStateFormat", 
($fz = function (pname) {
switch (pname) {
case 35213:
case 35214:
case 35215:
return 1;
default:
return 0;
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getHintTarget", 
($fz = function (target) {
switch (target) {
case 3156:
return "GL_FOG_HINT";
case 3154:
return "GL_LINE_SMOOTH_HINT";
case 3152:
return "GL_PERSPECTIVE_CORRECTION_HINT";
case 3153:
return "GL_POINT_SMOOTH_HINT";
case 3155:
return "GL_POLYGON_SMOOTH_HINT";
case 33170:
return "GL_GENERATE_MIPMAP_HINT";
default:
return android.opengl.GLLogWrapper.getHex (target);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getHintMode", 
($fz = function (mode) {
switch (mode) {
case 4353:
return "GL_FASTEST";
case 4354:
return "GL_NICEST";
case 4352:
return "GL_DONT_CARE";
default:
return android.opengl.GLLogWrapper.getHex (mode);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getFaceName", 
($fz = function (face) {
switch (face) {
case 1032:
return "GL_FRONT_AND_BACK";
default:
return android.opengl.GLLogWrapper.getHex (face);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getMaterialPName", 
($fz = function (pname) {
switch (pname) {
case 4608:
return "GL_AMBIENT";
case 4609:
return "GL_DIFFUSE";
case 4610:
return "GL_SPECULAR";
case 5632:
return "GL_EMISSION";
case 5633:
return "GL_SHININESS";
case 5634:
return "GL_AMBIENT_AND_DIFFUSE";
default:
return android.opengl.GLLogWrapper.getHex (pname);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getMaterialParamCount", 
($fz = function (pname) {
switch (pname) {
case 4608:
return 4;
case 4609:
return 4;
case 4610:
return 4;
case 5632:
return 4;
case 5633:
return 1;
case 5634:
return 4;
default:
return 0;
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getLightName", 
($fz = function (light) {
if (light >= 16384 && light <= 16391) {
return "GL_LIGHT" + Integer.toString (light);
}return android.opengl.GLLogWrapper.getHex (light);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getLightPName", 
($fz = function (pname) {
switch (pname) {
case 4608:
return "GL_AMBIENT";
case 4609:
return "GL_DIFFUSE";
case 4610:
return "GL_SPECULAR";
case 4611:
return "GL_POSITION";
case 4612:
return "GL_SPOT_DIRECTION";
case 4613:
return "GL_SPOT_EXPONENT";
case 4614:
return "GL_SPOT_CUTOFF";
case 4615:
return "GL_CONSTANT_ATTENUATION";
case 4616:
return "GL_LINEAR_ATTENUATION";
case 4617:
return "GL_QUADRATIC_ATTENUATION";
default:
return android.opengl.GLLogWrapper.getHex (pname);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getLightParamCount", 
($fz = function (pname) {
switch (pname) {
case 4608:
return 4;
case 4609:
return 4;
case 4610:
return 4;
case 4611:
return 4;
case 4612:
return 3;
case 4613:
return 1;
case 4614:
return 1;
case 4615:
return 1;
case 4616:
return 1;
case 4617:
return 1;
default:
return 0;
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getLightModelPName", 
($fz = function (pname) {
switch (pname) {
case 2899:
return "GL_LIGHT_MODEL_AMBIENT";
case 2898:
return "GL_LIGHT_MODEL_TWO_SIDE";
default:
return android.opengl.GLLogWrapper.getHex (pname);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getLightModelParamCount", 
($fz = function (pname) {
switch (pname) {
case 2899:
return 4;
case 2898:
return 1;
default:
return 0;
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getPointerTypeName", 
($fz = function (type) {
switch (type) {
case 5120:
return "GL_BYTE";
case 5121:
return "GL_UNSIGNED_BYTE";
case 5122:
return "GL_SHORT";
case 5132:
return "GL_FIXED";
case 5126:
return "GL_FLOAT";
default:
return android.opengl.GLLogWrapper.getHex (type);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "toByteBuffer", 
($fz = function (byteCount, input) {
var result = null;
var convertWholeBuffer = (byteCount < 0);
if (Clazz.instanceOf (input, java.nio.ByteBuffer)) {
var input2 = input;
var position = input2.position ();
if (convertWholeBuffer) {
byteCount = input2.limit () - position;
}result = java.nio.ByteBuffer.allocate (byteCount).order (input2.order ());
for (var i = 0; i < byteCount; i++) {
result.put (input2.get ());
}
input2.position (position);
} else if (Clazz.instanceOf (input, java.nio.CharBuffer)) {
var input2 = input;
var position = input2.position ();
if (convertWholeBuffer) {
byteCount = (input2.limit () - position) * 2;
}result = java.nio.ByteBuffer.allocate (byteCount).order (input2.order ());
var result2 = result.asCharBuffer ();
for (var i = 0; i < Math.floor (byteCount / 2); i++) {
result2.put (input2.get ());
}
input2.position (position);
} else if (Clazz.instanceOf (input, java.nio.ShortBuffer)) {
var input2 = input;
var position = input2.position ();
if (convertWholeBuffer) {
byteCount = (input2.limit () - position) * 2;
}result = java.nio.ByteBuffer.allocate (byteCount).order (input2.order ());
var result2 = result.asShortBuffer ();
for (var i = 0; i < Math.floor (byteCount / 2); i++) {
result2.put (input2.get ());
}
input2.position (position);
} else if (Clazz.instanceOf (input, java.nio.IntBuffer)) {
var input2 = input;
var position = input2.position ();
if (convertWholeBuffer) {
byteCount = (input2.limit () - position) * 4;
}result = java.nio.ByteBuffer.allocate (byteCount).order (input2.order ());
var result2 = result.asIntBuffer ();
for (var i = 0; i < Math.floor (byteCount / 4); i++) {
result2.put (input2.get ());
}
input2.position (position);
} else if (Clazz.instanceOf (input, java.nio.FloatBuffer)) {
var input2 = input;
var position = input2.position ();
if (convertWholeBuffer) {
byteCount = (input2.limit () - position) * 4;
}result = java.nio.ByteBuffer.allocate (byteCount).order (input2.order ());
var result2 = result.asFloatBuffer ();
for (var i = 0; i < Math.floor (byteCount / 4); i++) {
result2.put (input2.get ());
}
input2.position (position);
} else if (Clazz.instanceOf (input, java.nio.DoubleBuffer)) {
var input2 = input;
var position = input2.position ();
if (convertWholeBuffer) {
byteCount = (input2.limit () - position) * 8;
}result = java.nio.ByteBuffer.allocate (byteCount).order (input2.order ());
var result2 = result.asDoubleBuffer ();
for (var i = 0; i < Math.floor (byteCount / 8); i++) {
result2.put (input2.get ());
}
input2.position (position);
} else if (Clazz.instanceOf (input, java.nio.LongBuffer)) {
var input2 = input;
var position = input2.position ();
if (convertWholeBuffer) {
byteCount = (input2.limit () - position) * 8;
}result = java.nio.ByteBuffer.allocate (byteCount).order (input2.order ());
var result2 = result.asLongBuffer ();
for (var i = 0; i < Math.floor (byteCount / 8); i++) {
result2.put (input2.get ());
}
input2.position (position);
} else {
throw  new RuntimeException ("Unimplemented Buffer subclass.");
}result.rewind ();
result.order (java.nio.ByteOrder.nativeOrder ());
return result;
}, $fz.isPrivate = true, $fz), "~N,java.nio.Buffer");
Clazz.defineMethod (c$, "toCharIndices", 
($fz = function (count, type, indices) {
var result =  Clazz.newArray (count, '\0');
switch (type) {
case 5121:
{
var byteBuffer = this.toByteBuffer (count, indices);
var array = byteBuffer.array ();
var offset = byteBuffer.arrayOffset ();
for (var i = 0; i < count; i++) {
result[i] = String.fromCharCode ((0xff & array[offset + i]));
}
}break;
case 5123:
{
var charBuffer;
if (Clazz.instanceOf (indices, java.nio.CharBuffer)) {
charBuffer = indices;
} else {
var byteBuffer = this.toByteBuffer (count * 2, indices);
charBuffer = byteBuffer.asCharBuffer ();
}var oldPosition = charBuffer.position ();
charBuffer.position (0);
charBuffer.get (result);
charBuffer.position (oldPosition);
}break;
default:
break;
}
return result;
}, $fz.isPrivate = true, $fz), "~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "doArrayElement", 
($fz = function (builder, enabled, name, pointer, index) {
if (!enabled) {
return ;
}builder.append (" ");
builder.append (name + ":{");
if (pointer == null || pointer.mTempByteBuffer == null) {
builder.append ("undefined }");
return ;
}if (pointer.mStride < 0) {
builder.append ("invalid stride");
return ;
}var stride = pointer.getStride ();
var byteBuffer = pointer.mTempByteBuffer;
var size = pointer.mSize;
var type = pointer.mType;
var sizeofType = pointer.sizeof (type);
var byteOffset = stride * index;
for (var i = 0; i < size; i++) {
if (i > 0) {
builder.append (", ");
}switch (type) {
case 5120:
{
var d = byteBuffer.get (byteOffset);
builder.append (Integer.toString (d));
}break;
case 5121:
{
var d = byteBuffer.get (byteOffset);
builder.append (Integer.toString (0xff & d));
}break;
case 5122:
{
var shortBuffer = byteBuffer.asShortBuffer ();
var d = shortBuffer.get (Math.floor (byteOffset / 2));
builder.append (Integer.toString (d));
}break;
case 5132:
{
var intBuffer = byteBuffer.asIntBuffer ();
var d = intBuffer.get (Math.floor (byteOffset / 4));
builder.append (Integer.toString (d));
}break;
case 5126:
{
var intBuffer = byteBuffer.asFloatBuffer ();
var d = intBuffer.get (Math.floor (byteOffset / 4));
builder.append (Float.toString (d));
}break;
default:
builder.append ("?");
break;
}
byteOffset += sizeofType;
}
builder.append ("}");
}, $fz.isPrivate = true, $fz), "StringBuilder,~B,~S,android.opengl.GLLogWrapper.PointerInfo,~N");
Clazz.defineMethod (c$, "doElement", 
($fz = function (builder, ordinal, vertexIndex) {
builder.append (" [" + ordinal + " : " + vertexIndex + "] =");
this.doArrayElement (builder, this.mVertexArrayEnabled, "v", this.mVertexPointer, vertexIndex);
this.doArrayElement (builder, this.mNormalArrayEnabled, "n", this.mNormalPointer, vertexIndex);
this.doArrayElement (builder, this.mColorArrayEnabled, "c", this.mColorPointer, vertexIndex);
this.doArrayElement (builder, this.mTextureCoordArrayEnabled, "t", this.mTexCoordPointer, vertexIndex);
builder.append ("\n");
}, $fz.isPrivate = true, $fz), "StringBuilder,~N,~N");
Clazz.defineMethod (c$, "bindArrays", 
($fz = function () {
if (this.mColorArrayEnabled) this.mColorPointer.bindByteBuffer ();
if (this.mNormalArrayEnabled) this.mNormalPointer.bindByteBuffer ();
if (this.mTextureCoordArrayEnabled) this.mTexCoordPointer.bindByteBuffer ();
if (this.mVertexArrayEnabled) this.mVertexPointer.bindByteBuffer ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "unbindArrays", 
($fz = function () {
if (this.mColorArrayEnabled) this.mColorPointer.unbindByteBuffer ();
if (this.mNormalArrayEnabled) this.mNormalPointer.unbindByteBuffer ();
if (this.mTextureCoordArrayEnabled) this.mTexCoordPointer.unbindByteBuffer ();
if (this.mVertexArrayEnabled) this.mVertexPointer.unbindByteBuffer ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "startLogIndices", 
($fz = function () {
this.mStringBuilder =  new StringBuilder ();
this.mStringBuilder.append ("\n");
this.bindArrays ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "endLogIndices", 
($fz = function () {
this.log (this.mStringBuilder.toString ());
this.unbindArrays ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "glActiveTexture", 
function (texture) {
this.begin ("glActiveTexture");
this.arg ("texture", texture);
this.end ();
this.mgl.glActiveTexture (texture);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glAlphaFunc", 
function (func, ref) {
this.begin ("glAlphaFunc");
this.arg ("func", func);
this.arg ("ref", ref);
this.end ();
this.mgl.glAlphaFunc (func, ref);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glAlphaFuncx", 
function (func, ref) {
this.begin ("glAlphaFuncx");
this.arg ("func", func);
this.arg ("ref", ref);
this.end ();
this.mgl.glAlphaFuncx (func, ref);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glBindTexture", 
function (target, texture) {
this.begin ("glBindTexture");
this.arg ("target", this.getTextureTarget (target));
this.arg ("texture", texture);
this.end ();
this.mgl.glBindTexture (target, texture);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glBlendFunc", 
function (sfactor, dfactor) {
this.begin ("glBlendFunc");
this.arg ("sfactor", this.getFactor (sfactor));
this.arg ("dfactor", this.getFactor (dfactor));
this.end ();
this.mgl.glBlendFunc (sfactor, dfactor);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glClear", 
function (mask) {
this.begin ("glClear");
this.arg ("mask", this.getClearBufferMask (mask));
this.end ();
this.mgl.glClear (mask);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glClearColor", 
function (red, green, blue, alpha) {
this.begin ("glClearColor");
this.arg ("red", red);
this.arg ("green", green);
this.arg ("blue", blue);
this.arg ("alpha", alpha);
this.end ();
this.mgl.glClearColor (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glClearColorx", 
function (red, green, blue, alpha) {
this.begin ("glClearColor");
this.arg ("red", red);
this.arg ("green", green);
this.arg ("blue", blue);
this.arg ("alpha", alpha);
this.end ();
this.mgl.glClearColorx (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glClearDepthf", 
function (depth) {
this.begin ("glClearDepthf");
this.arg ("depth", depth);
this.end ();
this.mgl.glClearDepthf (depth);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glClearDepthx", 
function (depth) {
this.begin ("glClearDepthx");
this.arg ("depth", depth);
this.end ();
this.mgl.glClearDepthx (depth);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glClearStencil", 
function (s) {
this.begin ("glClearStencil");
this.arg ("s", s);
this.end ();
this.mgl.glClearStencil (s);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glClientActiveTexture", 
function (texture) {
this.begin ("glClientActiveTexture");
this.arg ("texture", texture);
this.end ();
this.mgl.glClientActiveTexture (texture);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glColor4f", 
function (red, green, blue, alpha) {
this.begin ("glColor4f");
this.arg ("red", red);
this.arg ("green", green);
this.arg ("blue", blue);
this.arg ("alpha", alpha);
this.end ();
this.mgl.glColor4f (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glColor4x", 
function (red, green, blue, alpha) {
this.begin ("glColor4x");
this.arg ("red", red);
this.arg ("green", green);
this.arg ("blue", blue);
this.arg ("alpha", alpha);
this.end ();
this.mgl.glColor4x (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glColorMask", 
function (red, green, blue, alpha) {
this.begin ("glColorMask");
this.arg ("red", red);
this.arg ("green", green);
this.arg ("blue", blue);
this.arg ("alpha", alpha);
this.end ();
this.mgl.glColorMask (red, green, blue, alpha);
this.checkError ();
}, "~B,~B,~B,~B");
Clazz.defineMethod (c$, "glColorPointer", 
function (size, type, stride, pointer) {
this.begin ("glColorPointer");
this.argPointer (size, type, stride, pointer);
this.end ();
this.mColorPointer = Clazz.innerTypeInstance (android.opengl.GLLogWrapper.PointerInfo, this, null, size, type, stride, pointer);
this.mgl.glColorPointer (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glCompressedTexImage2D", 
function (target, level, internalformat, width, height, border, imageSize, data) {
this.begin ("glCompressedTexImage2D");
this.arg ("target", this.getTextureTarget (target));
this.arg ("level", level);
this.arg ("internalformat", internalformat);
this.arg ("width", width);
this.arg ("height", height);
this.arg ("border", border);
this.arg ("imageSize", imageSize);
this.arg ("data", data.toString ());
this.end ();
this.mgl.glCompressedTexImage2D (target, level, internalformat, width, height, border, imageSize, data);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glCompressedTexSubImage2D", 
function (target, level, xoffset, yoffset, width, height, format, imageSize, data) {
this.begin ("glCompressedTexSubImage2D");
this.arg ("target", this.getTextureTarget (target));
this.arg ("level", level);
this.arg ("xoffset", xoffset);
this.arg ("yoffset", yoffset);
this.arg ("width", width);
this.arg ("height", height);
this.arg ("format", format);
this.arg ("imageSize", imageSize);
this.arg ("data", data.toString ());
this.end ();
this.mgl.glCompressedTexSubImage2D (target, level, xoffset, yoffset, width, height, format, imageSize, data);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glCopyTexImage2D", 
function (target, level, internalformat, x, y, width, height, border) {
this.begin ("glCopyTexImage2D");
this.arg ("target", this.getTextureTarget (target));
this.arg ("level", level);
this.arg ("internalformat", internalformat);
this.arg ("x", x);
this.arg ("y", y);
this.arg ("width", width);
this.arg ("height", height);
this.arg ("border", border);
this.end ();
this.mgl.glCopyTexImage2D (target, level, internalformat, x, y, width, height, border);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glCopyTexSubImage2D", 
function (target, level, xoffset, yoffset, x, y, width, height) {
this.begin ("glCopyTexSubImage2D");
this.arg ("target", this.getTextureTarget (target));
this.arg ("level", level);
this.arg ("xoffset", xoffset);
this.arg ("yoffset", yoffset);
this.arg ("x", x);
this.arg ("y", y);
this.arg ("width", width);
this.arg ("height", height);
this.end ();
this.mgl.glCopyTexSubImage2D (target, level, xoffset, yoffset, x, y, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glCullFace", 
function (mode) {
this.begin ("glCullFace");
this.arg ("mode", mode);
this.end ();
this.mgl.glCullFace (mode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glDeleteTextures", 
function (n, textures, offset) {
this.begin ("glDeleteTextures");
this.arg ("n", n);
this.arg ("textures", n, textures, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glDeleteTextures (n, textures, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glDeleteTextures", 
function (n, textures) {
this.begin ("glDeleteTextures");
this.arg ("n", n);
this.arg ("textures", n, textures);
this.end ();
this.mgl.glDeleteTextures (n, textures);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glDepthFunc", 
function (func) {
this.begin ("glDepthFunc");
this.arg ("func", func);
this.end ();
this.mgl.glDepthFunc (func);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glDepthMask", 
function (flag) {
this.begin ("glDepthMask");
this.arg ("flag", flag);
this.end ();
this.mgl.glDepthMask (flag);
this.checkError ();
}, "~B");
Clazz.defineMethod (c$, "glDepthRangef", 
function (near, far) {
this.begin ("glDepthRangef");
this.arg ("near", near);
this.arg ("far", far);
this.end ();
this.mgl.glDepthRangef (near, far);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glDepthRangex", 
function (near, far) {
this.begin ("glDepthRangex");
this.arg ("near", near);
this.arg ("far", far);
this.end ();
this.mgl.glDepthRangex (near, far);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glDisable", 
function (cap) {
this.begin ("glDisable");
this.arg ("cap", this.getCap (cap));
this.end ();
this.mgl.glDisable (cap);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glDisableClientState", 
function (array) {
this.begin ("glDisableClientState");
this.arg ("array", this.getClientState (array));
this.end ();
switch (array) {
case 32886:
this.mColorArrayEnabled = false;
break;
case 32885:
this.mNormalArrayEnabled = false;
break;
case 32888:
this.mTextureCoordArrayEnabled = false;
break;
case 32884:
this.mVertexArrayEnabled = false;
break;
}
this.mgl.glDisableClientState (array);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glDrawArrays", 
function (mode, first, count) {
this.begin ("glDrawArrays");
this.arg ("mode", mode);
this.arg ("first", first);
this.arg ("count", count);
this.startLogIndices ();
for (var i = 0; i < count; i++) {
this.doElement (this.mStringBuilder, i, first + i);
}
this.endLogIndices ();
this.end ();
this.mgl.glDrawArrays (mode, first, count);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glDrawElements", 
function (mode, count, type, indices) {
this.begin ("glDrawElements");
this.arg ("mode", this.getBeginMode (mode));
this.arg ("count", count);
this.arg ("type", this.getIndexType (type));
var indexArray = this.toCharIndices (count, type, indices);
var indexArrayLength = indexArray.length;
this.startLogIndices ();
for (var i = 0; i < indexArrayLength; i++) {
this.doElement (this.mStringBuilder, i, indexArray[i].charCodeAt (0));
}
this.endLogIndices ();
this.end ();
this.mgl.glDrawElements (mode, count, type, indices);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glEnable", 
function (cap) {
this.begin ("glEnable");
this.arg ("cap", this.getCap (cap));
this.end ();
this.mgl.glEnable (cap);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glEnableClientState", 
function (array) {
this.begin ("glEnableClientState");
this.arg ("array", this.getClientState (array));
this.end ();
switch (array) {
case 32886:
this.mColorArrayEnabled = true;
break;
case 32885:
this.mNormalArrayEnabled = true;
break;
case 32888:
this.mTextureCoordArrayEnabled = true;
break;
case 32884:
this.mVertexArrayEnabled = true;
break;
}
this.mgl.glEnableClientState (array);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glFinish", 
function () {
this.begin ("glFinish");
this.end ();
this.mgl.glFinish ();
this.checkError ();
});
Clazz.defineMethod (c$, "glFlush", 
function () {
this.begin ("glFlush");
this.end ();
this.mgl.glFlush ();
this.checkError ();
});
Clazz.defineMethod (c$, "glFogf", 
function (pname, param) {
this.begin ("glFogf");
this.arg ("pname", pname);
this.arg ("param", param);
this.end ();
this.mgl.glFogf (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glFogfv", 
function (pname, params, offset) {
this.begin ("glFogfv");
this.arg ("pname", this.getFogPName (pname));
this.arg ("params", this.getFogParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glFogfv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glFogfv", 
function (pname, params) {
this.begin ("glFogfv");
this.arg ("pname", this.getFogPName (pname));
this.arg ("params", this.getFogParamCount (pname), params);
this.end ();
this.mgl.glFogfv (pname, params);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glFogx", 
function (pname, param) {
this.begin ("glFogx");
this.arg ("pname", this.getFogPName (pname));
this.arg ("param", param);
this.end ();
this.mgl.glFogx (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glFogxv", 
function (pname, params, offset) {
this.begin ("glFogxv");
this.arg ("pname", this.getFogPName (pname));
this.arg ("params", this.getFogParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glFogxv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glFogxv", 
function (pname, params) {
this.begin ("glFogxv");
this.arg ("pname", this.getFogPName (pname));
this.arg ("params", this.getFogParamCount (pname), params);
this.end ();
this.mgl.glFogxv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glFrontFace", 
function (mode) {
this.begin ("glFrontFace");
this.arg ("mode", mode);
this.end ();
this.mgl.glFrontFace (mode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glFrustumf", 
function (left, right, bottom, top, near, far) {
this.begin ("glFrustumf");
this.arg ("left", left);
this.arg ("right", right);
this.arg ("bottom", bottom);
this.arg ("top", top);
this.arg ("near", near);
this.arg ("far", far);
this.end ();
this.mgl.glFrustumf (left, right, bottom, top, near, far);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glFrustumx", 
function (left, right, bottom, top, near, far) {
this.begin ("glFrustumx");
this.arg ("left", left);
this.arg ("right", right);
this.arg ("bottom", bottom);
this.arg ("top", top);
this.arg ("near", near);
this.arg ("far", far);
this.end ();
this.mgl.glFrustumx (left, right, bottom, top, near, far);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glGenTextures", 
function (n, textures, offset) {
this.begin ("glGenTextures");
this.arg ("n", n);
this.arg ("textures", java.util.Arrays.toString (textures));
this.arg ("offset", offset);
this.mgl.glGenTextures (n, textures, offset);
this.returns (this.toString (n, 0, textures, offset));
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGenTextures", 
function (n, textures) {
this.begin ("glGenTextures");
this.arg ("n", n);
this.arg ("textures", textures.toString ());
this.mgl.glGenTextures (n, textures);
this.returns (this.toString (n, 0, textures));
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetError", 
function () {
this.begin ("glGetError");
var result = this.mgl.glGetError ();
this.returns (result);
return result;
});
Clazz.defineMethod (c$, "glGetIntegerv", 
function (pname, params, offset) {
this.begin ("glGetIntegerv");
this.arg ("pname", this.getIntegerStateName (pname));
this.arg ("params", java.util.Arrays.toString (params));
this.arg ("offset", offset);
this.mgl.glGetIntegerv (pname, params, offset);
this.returns (this.toString (this.getIntegerStateSize (pname), this.getIntegerStateFormat (pname), params, offset));
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetIntegerv", 
function (pname, params) {
this.begin ("glGetIntegerv");
this.arg ("pname", this.getIntegerStateName (pname));
this.arg ("params", params.toString ());
this.mgl.glGetIntegerv (pname, params);
this.returns (this.toString (this.getIntegerStateSize (pname), this.getIntegerStateFormat (pname), params));
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetString", 
function (name) {
this.begin ("glGetString");
this.arg ("name", name);
var result = this.mgl.glGetString (name);
this.returns (result);
this.checkError ();
return result;
}, "~N");
Clazz.defineMethod (c$, "glHint", 
function (target, mode) {
this.begin ("glHint");
this.arg ("target", this.getHintTarget (target));
this.arg ("mode", this.getHintMode (mode));
this.end ();
this.mgl.glHint (target, mode);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glLightModelf", 
function (pname, param) {
this.begin ("glLightModelf");
this.arg ("pname", this.getLightModelPName (pname));
this.arg ("param", param);
this.end ();
this.mgl.glLightModelf (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glLightModelfv", 
function (pname, params, offset) {
this.begin ("glLightModelfv");
this.arg ("pname", this.getLightModelPName (pname));
this.arg ("params", this.getLightModelParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glLightModelfv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glLightModelfv", 
function (pname, params) {
this.begin ("glLightModelfv");
this.arg ("pname", this.getLightModelPName (pname));
this.arg ("params", this.getLightModelParamCount (pname), params);
this.end ();
this.mgl.glLightModelfv (pname, params);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glLightModelx", 
function (pname, param) {
this.begin ("glLightModelx");
this.arg ("pname", this.getLightModelPName (pname));
this.arg ("param", param);
this.end ();
this.mgl.glLightModelx (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glLightModelxv", 
function (pname, params, offset) {
this.begin ("glLightModelxv");
this.arg ("pname", this.getLightModelPName (pname));
this.arg ("params", this.getLightModelParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glLightModelxv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glLightModelxv", 
function (pname, params) {
this.begin ("glLightModelfv");
this.arg ("pname", this.getLightModelPName (pname));
this.arg ("params", this.getLightModelParamCount (pname), params);
this.end ();
this.mgl.glLightModelxv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glLightf", 
function (light, pname, param) {
this.begin ("glLightf");
this.arg ("light", this.getLightName (light));
this.arg ("pname", this.getLightPName (pname));
this.arg ("param", param);
this.end ();
this.mgl.glLightf (light, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glLightfv", 
function (light, pname, params, offset) {
this.begin ("glLightfv");
this.arg ("light", this.getLightName (light));
this.arg ("pname", this.getLightPName (pname));
this.arg ("params", this.getLightParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glLightfv (light, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glLightfv", 
function (light, pname, params) {
this.begin ("glLightfv");
this.arg ("light", this.getLightName (light));
this.arg ("pname", this.getLightPName (pname));
this.arg ("params", this.getLightParamCount (pname), params);
this.end ();
this.mgl.glLightfv (light, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glLightx", 
function (light, pname, param) {
this.begin ("glLightx");
this.arg ("light", this.getLightName (light));
this.arg ("pname", this.getLightPName (pname));
this.arg ("param", param);
this.end ();
this.mgl.glLightx (light, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glLightxv", 
function (light, pname, params, offset) {
this.begin ("glLightxv");
this.arg ("light", this.getLightName (light));
this.arg ("pname", this.getLightPName (pname));
this.arg ("params", this.getLightParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glLightxv (light, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glLightxv", 
function (light, pname, params) {
this.begin ("glLightxv");
this.arg ("light", this.getLightName (light));
this.arg ("pname", this.getLightPName (pname));
this.arg ("params", this.getLightParamCount (pname), params);
this.end ();
this.mgl.glLightxv (light, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glLineWidth", 
function (width) {
this.begin ("glLineWidth");
this.arg ("width", width);
this.end ();
this.mgl.glLineWidth (width);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glLineWidthx", 
function (width) {
this.begin ("glLineWidthx");
this.arg ("width", width);
this.end ();
this.mgl.glLineWidthx (width);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glLoadIdentity", 
function () {
this.begin ("glLoadIdentity");
this.end ();
this.mgl.glLoadIdentity ();
this.checkError ();
});
Clazz.defineMethod (c$, "glLoadMatrixf", 
function (m, offset) {
this.begin ("glLoadMatrixf");
this.arg ("m", 16, m, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glLoadMatrixf (m, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glLoadMatrixf", 
function (m) {
this.begin ("glLoadMatrixf");
this.arg ("m", 16, m);
this.end ();
this.mgl.glLoadMatrixf (m);
this.checkError ();
}, "java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glLoadMatrixx", 
function (m, offset) {
this.begin ("glLoadMatrixx");
this.arg ("m", 16, m, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glLoadMatrixx (m, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glLoadMatrixx", 
function (m) {
this.begin ("glLoadMatrixx");
this.arg ("m", 16, m);
this.end ();
this.mgl.glLoadMatrixx (m);
this.checkError ();
}, "java.nio.IntBuffer");
Clazz.defineMethod (c$, "glLogicOp", 
function (opcode) {
this.begin ("glLogicOp");
this.arg ("opcode", opcode);
this.end ();
this.mgl.glLogicOp (opcode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glMaterialf", 
function (face, pname, param) {
this.begin ("glMaterialf");
this.arg ("face", this.getFaceName (face));
this.arg ("pname", this.getMaterialPName (pname));
this.arg ("param", param);
this.end ();
this.mgl.glMaterialf (face, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glMaterialfv", 
function (face, pname, params, offset) {
this.begin ("glMaterialfv");
this.arg ("face", this.getFaceName (face));
this.arg ("pname", this.getMaterialPName (pname));
this.arg ("params", this.getMaterialParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glMaterialfv (face, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glMaterialfv", 
function (face, pname, params) {
this.begin ("glMaterialfv");
this.arg ("face", this.getFaceName (face));
this.arg ("pname", this.getMaterialPName (pname));
this.arg ("params", this.getMaterialParamCount (pname), params);
this.end ();
this.mgl.glMaterialfv (face, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glMaterialx", 
function (face, pname, param) {
this.begin ("glMaterialx");
this.arg ("face", this.getFaceName (face));
this.arg ("pname", this.getMaterialPName (pname));
this.arg ("param", param);
this.end ();
this.mgl.glMaterialx (face, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glMaterialxv", 
function (face, pname, params, offset) {
this.begin ("glMaterialxv");
this.arg ("face", this.getFaceName (face));
this.arg ("pname", this.getMaterialPName (pname));
this.arg ("params", this.getMaterialParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glMaterialxv (face, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glMaterialxv", 
function (face, pname, params) {
this.begin ("glMaterialxv");
this.arg ("face", this.getFaceName (face));
this.arg ("pname", this.getMaterialPName (pname));
this.arg ("params", this.getMaterialParamCount (pname), params);
this.end ();
this.mgl.glMaterialxv (face, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glMatrixMode", 
function (mode) {
this.begin ("glMatrixMode");
this.arg ("mode", this.getMatrixMode (mode));
this.end ();
this.mgl.glMatrixMode (mode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glMultMatrixf", 
function (m, offset) {
this.begin ("glMultMatrixf");
this.arg ("m", 16, m, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glMultMatrixf (m, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glMultMatrixf", 
function (m) {
this.begin ("glMultMatrixf");
this.arg ("m", 16, m);
this.end ();
this.mgl.glMultMatrixf (m);
this.checkError ();
}, "java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glMultMatrixx", 
function (m, offset) {
this.begin ("glMultMatrixx");
this.arg ("m", 16, m, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glMultMatrixx (m, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glMultMatrixx", 
function (m) {
this.begin ("glMultMatrixx");
this.arg ("m", 16, m);
this.end ();
this.mgl.glMultMatrixx (m);
this.checkError ();
}, "java.nio.IntBuffer");
Clazz.defineMethod (c$, "glMultiTexCoord4f", 
function (target, s, t, r, q) {
this.begin ("glMultiTexCoord4f");
this.arg ("target", target);
this.arg ("s", s);
this.arg ("t", t);
this.arg ("r", r);
this.arg ("q", q);
this.end ();
this.mgl.glMultiTexCoord4f (target, s, t, r, q);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glMultiTexCoord4x", 
function (target, s, t, r, q) {
this.begin ("glMultiTexCoord4x");
this.arg ("target", target);
this.arg ("s", s);
this.arg ("t", t);
this.arg ("r", r);
this.arg ("q", q);
this.end ();
this.mgl.glMultiTexCoord4x (target, s, t, r, q);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glNormal3f", 
function (nx, ny, nz) {
this.begin ("glNormal3f");
this.arg ("nx", nx);
this.arg ("ny", ny);
this.arg ("nz", nz);
this.end ();
this.mgl.glNormal3f (nx, ny, nz);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glNormal3x", 
function (nx, ny, nz) {
this.begin ("glNormal3x");
this.arg ("nx", nx);
this.arg ("ny", ny);
this.arg ("nz", nz);
this.end ();
this.mgl.glNormal3x (nx, ny, nz);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glNormalPointer", 
function (type, stride, pointer) {
this.begin ("glNormalPointer");
this.arg ("type", type);
this.arg ("stride", stride);
this.arg ("pointer", pointer.toString ());
this.end ();
this.mNormalPointer = Clazz.innerTypeInstance (android.opengl.GLLogWrapper.PointerInfo, this, null, 3, type, stride, pointer);
this.mgl.glNormalPointer (type, stride, pointer);
this.checkError ();
}, "~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glOrthof", 
function (left, right, bottom, top, near, far) {
this.begin ("glOrthof");
this.arg ("left", left);
this.arg ("right", right);
this.arg ("bottom", bottom);
this.arg ("top", top);
this.arg ("near", near);
this.arg ("far", far);
this.end ();
this.mgl.glOrthof (left, right, bottom, top, near, far);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glOrthox", 
function (left, right, bottom, top, near, far) {
this.begin ("glOrthox");
this.arg ("left", left);
this.arg ("right", right);
this.arg ("bottom", bottom);
this.arg ("top", top);
this.arg ("near", near);
this.arg ("far", far);
this.end ();
this.mgl.glOrthox (left, right, bottom, top, near, far);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glPixelStorei", 
function (pname, param) {
this.begin ("glPixelStorei");
this.arg ("pname", pname);
this.arg ("param", param);
this.end ();
this.mgl.glPixelStorei (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPointSize", 
function (size) {
this.begin ("glPointSize");
this.arg ("size", size);
this.end ();
this.mgl.glPointSize (size);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glPointSizex", 
function (size) {
this.begin ("glPointSizex");
this.arg ("size", size);
this.end ();
this.mgl.glPointSizex (size);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glPolygonOffset", 
function (factor, units) {
this.begin ("glPolygonOffset");
this.arg ("factor", factor);
this.arg ("units", units);
this.end ();
this.mgl.glPolygonOffset (factor, units);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPolygonOffsetx", 
function (factor, units) {
this.begin ("glPolygonOffsetx");
this.arg ("factor", factor);
this.arg ("units", units);
this.end ();
this.mgl.glPolygonOffsetx (factor, units);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPopMatrix", 
function () {
this.begin ("glPopMatrix");
this.end ();
this.mgl.glPopMatrix ();
this.checkError ();
});
Clazz.defineMethod (c$, "glPushMatrix", 
function () {
this.begin ("glPushMatrix");
this.end ();
this.mgl.glPushMatrix ();
this.checkError ();
});
Clazz.defineMethod (c$, "glReadPixels", 
function (x, y, width, height, format, type, pixels) {
this.begin ("glReadPixels");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("width", width);
this.arg ("height", height);
this.arg ("format", format);
this.arg ("type", type);
this.arg ("pixels", pixels.toString ());
this.end ();
this.mgl.glReadPixels (x, y, width, height, format, type, pixels);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glRotatef", 
function (angle, x, y, z) {
this.begin ("glRotatef");
this.arg ("angle", angle);
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.end ();
this.mgl.glRotatef (angle, x, y, z);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glRotatex", 
function (angle, x, y, z) {
this.begin ("glRotatex");
this.arg ("angle", angle);
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.end ();
this.mgl.glRotatex (angle, x, y, z);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glSampleCoverage", 
function (value, invert) {
this.begin ("glSampleCoveragex");
this.arg ("value", value);
this.arg ("invert", invert);
this.end ();
this.mgl.glSampleCoverage (value, invert);
this.checkError ();
}, "~N,~B");
Clazz.defineMethod (c$, "glSampleCoveragex", 
function (value, invert) {
this.begin ("glSampleCoveragex");
this.arg ("value", value);
this.arg ("invert", invert);
this.end ();
this.mgl.glSampleCoveragex (value, invert);
this.checkError ();
}, "~N,~B");
Clazz.defineMethod (c$, "glScalef", 
function (x, y, z) {
this.begin ("glScalef");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.end ();
this.mgl.glScalef (x, y, z);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glScalex", 
function (x, y, z) {
this.begin ("glScalex");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.end ();
this.mgl.glScalex (x, y, z);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glScissor", 
function (x, y, width, height) {
this.begin ("glScissor");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("width", width);
this.arg ("height", height);
this.end ();
this.mgl.glScissor (x, y, width, height);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glShadeModel", 
function (mode) {
this.begin ("glShadeModel");
this.arg ("mode", this.getShadeModel (mode));
this.end ();
this.mgl.glShadeModel (mode);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glStencilFunc", 
function (func, ref, mask) {
this.begin ("glStencilFunc");
this.arg ("func", func);
this.arg ("ref", ref);
this.arg ("mask", mask);
this.end ();
this.mgl.glStencilFunc (func, ref, mask);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glStencilMask", 
function (mask) {
this.begin ("glStencilMask");
this.arg ("mask", mask);
this.end ();
this.mgl.glStencilMask (mask);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glStencilOp", 
function (fail, zfail, zpass) {
this.begin ("glStencilOp");
this.arg ("fail", fail);
this.arg ("zfail", zfail);
this.arg ("zpass", zpass);
this.end ();
this.mgl.glStencilOp (fail, zfail, zpass);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexCoordPointer", 
function (size, type, stride, pointer) {
this.begin ("glTexCoordPointer");
this.argPointer (size, type, stride, pointer);
this.end ();
this.mTexCoordPointer = Clazz.innerTypeInstance (android.opengl.GLLogWrapper.PointerInfo, this, null, size, type, stride, pointer);
this.mgl.glTexCoordPointer (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTexEnvf", 
function (target, pname, param) {
this.begin ("glTexEnvf");
this.arg ("target", this.getTextureEnvTarget (target));
this.arg ("pname", this.getTextureEnvPName (pname));
this.arg ("param", this.getTextureEnvParamName (param));
this.end ();
this.mgl.glTexEnvf (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnvfv", 
function (target, pname, params, offset) {
this.begin ("glTexEnvfv");
this.arg ("target", this.getTextureEnvTarget (target));
this.arg ("pname", this.getTextureEnvPName (pname));
this.arg ("params", this.getTextureEnvParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glTexEnvfv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexEnvfv", 
function (target, pname, params) {
this.begin ("glTexEnvfv");
this.arg ("target", this.getTextureEnvTarget (target));
this.arg ("pname", this.getTextureEnvPName (pname));
this.arg ("params", this.getTextureEnvParamCount (pname), params);
this.end ();
this.mgl.glTexEnvfv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glTexEnvx", 
function (target, pname, param) {
this.begin ("glTexEnvx");
this.arg ("target", this.getTextureEnvTarget (target));
this.arg ("pname", this.getTextureEnvPName (pname));
this.arg ("param", param);
this.end ();
this.mgl.glTexEnvx (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnvxv", 
function (target, pname, params, offset) {
this.begin ("glTexEnvxv");
this.arg ("target", this.getTextureEnvTarget (target));
this.arg ("pname", this.getTextureEnvPName (pname));
this.arg ("params", this.getTextureEnvParamCount (pname), params, offset);
this.arg ("offset", offset);
this.end ();
this.mgl.glTexEnvxv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexEnvxv", 
function (target, pname, params) {
this.begin ("glTexEnvxv");
this.arg ("target", this.getTextureEnvTarget (target));
this.arg ("pname", this.getTextureEnvPName (pname));
this.arg ("params", this.getTextureEnvParamCount (pname), params);
this.end ();
this.mgl.glTexEnvxv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glTexImage2D", 
function (target, level, internalformat, width, height, border, format, type, pixels) {
this.begin ("glTexImage2D");
this.arg ("target", target);
this.arg ("level", level);
this.arg ("internalformat", internalformat);
this.arg ("width", width);
this.arg ("height", height);
this.arg ("border", border);
this.arg ("format", format);
this.arg ("type", type);
this.arg ("pixels", pixels.toString ());
this.end ();
this.mgl.glTexImage2D (target, level, internalformat, width, height, border, format, type, pixels);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTexParameterf", 
function (target, pname, param) {
this.begin ("glTexParameterf");
this.arg ("target", this.getTextureTarget (target));
this.arg ("pname", this.getTexturePName (pname));
this.arg ("param", this.getTextureParamName (param));
this.end ();
this.mgl.glTexParameterf (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexParameterx", 
function (target, pname, param) {
this.begin ("glTexParameterx");
this.arg ("target", this.getTextureTarget (target));
this.arg ("pname", this.getTexturePName (pname));
this.arg ("param", param);
this.end ();
this.mgl.glTexParameterx (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexParameteriv", 
function (target, pname, params, offset) {
this.begin ("glTexParameteriv");
this.arg ("target", this.getTextureTarget (target));
this.arg ("pname", this.getTexturePName (pname));
this.arg ("params", 4, params, offset);
this.end ();
this.mgl11.glTexParameteriv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexParameteriv", 
function (target, pname, params) {
this.begin ("glTexParameteriv");
this.arg ("target", this.getTextureTarget (target));
this.arg ("pname", this.getTexturePName (pname));
this.arg ("params", 4, params);
this.end ();
this.mgl11.glTexParameteriv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glTexSubImage2D", 
function (target, level, xoffset, yoffset, width, height, format, type, pixels) {
this.begin ("glTexSubImage2D");
this.arg ("target", this.getTextureTarget (target));
this.arg ("level", level);
this.arg ("xoffset", xoffset);
this.arg ("yoffset", yoffset);
this.arg ("width", width);
this.arg ("height", height);
this.arg ("format", format);
this.arg ("type", type);
this.arg ("pixels", pixels.toString ());
this.end ();
this.mgl.glTexSubImage2D (target, level, xoffset, yoffset, width, height, format, type, pixels);
this.checkError ();
}, "~N,~N,~N,~N,~N,~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTranslatef", 
function (x, y, z) {
this.begin ("glTranslatef");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.end ();
this.mgl.glTranslatef (x, y, z);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTranslatex", 
function (x, y, z) {
this.begin ("glTranslatex");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.end ();
this.mgl.glTranslatex (x, y, z);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glVertexPointer", 
function (size, type, stride, pointer) {
this.begin ("glVertexPointer");
this.argPointer (size, type, stride, pointer);
this.end ();
this.mVertexPointer = Clazz.innerTypeInstance (android.opengl.GLLogWrapper.PointerInfo, this, null, size, type, stride, pointer);
this.mgl.glVertexPointer (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glViewport", 
function (x, y, width, height) {
this.begin ("glViewport");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("width", width);
this.arg ("height", height);
this.end ();
this.mgl.glViewport (x, y, width, height);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glClipPlanef", 
function (plane, equation, offset) {
this.begin ("glClipPlanef");
this.arg ("plane", plane);
this.arg ("equation", 4, equation, offset);
this.arg ("offset", offset);
this.end ();
this.mgl11.glClipPlanef (plane, equation, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glClipPlanef", 
function (plane, equation) {
this.begin ("glClipPlanef");
this.arg ("plane", plane);
this.arg ("equation", 4, equation);
this.end ();
this.mgl11.glClipPlanef (plane, equation);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glClipPlanex", 
function (plane, equation, offset) {
this.begin ("glClipPlanex");
this.arg ("plane", plane);
this.arg ("equation", 4, equation, offset);
this.arg ("offset", offset);
this.end ();
this.mgl11.glClipPlanex (plane, equation, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glClipPlanex", 
function (plane, equation) {
this.begin ("glClipPlanef");
this.arg ("plane", plane);
this.arg ("equation", 4, equation);
this.end ();
this.mgl11.glClipPlanex (plane, equation);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glDrawTexfOES", 
function (x, y, z, width, height) {
this.begin ("glDrawTexfOES");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.arg ("width", width);
this.arg ("height", height);
this.end ();
this.mgl11Ext.glDrawTexfOES (x, y, z, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexfvOES", 
function (coords, offset) {
this.begin ("glDrawTexfvOES");
this.arg ("coords", 5, coords, offset);
this.arg ("offset", offset);
this.end ();
this.mgl11Ext.glDrawTexfvOES (coords, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glDrawTexfvOES", 
function (coords) {
this.begin ("glDrawTexfvOES");
this.arg ("coords", 5, coords);
this.end ();
this.mgl11Ext.glDrawTexfvOES (coords);
this.checkError ();
}, "java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glDrawTexiOES", 
function (x, y, z, width, height) {
this.begin ("glDrawTexiOES");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.arg ("width", width);
this.arg ("height", height);
this.end ();
this.mgl11Ext.glDrawTexiOES (x, y, z, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexivOES", 
function (coords, offset) {
this.begin ("glDrawTexivOES");
this.arg ("coords", 5, coords, offset);
this.arg ("offset", offset);
this.end ();
this.mgl11Ext.glDrawTexivOES (coords, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glDrawTexivOES", 
function (coords) {
this.begin ("glDrawTexivOES");
this.arg ("coords", 5, coords);
this.end ();
this.mgl11Ext.glDrawTexivOES (coords);
this.checkError ();
}, "java.nio.IntBuffer");
Clazz.defineMethod (c$, "glDrawTexsOES", 
function (x, y, z, width, height) {
this.begin ("glDrawTexsOES");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.arg ("width", width);
this.arg ("height", height);
this.end ();
this.mgl11Ext.glDrawTexsOES (x, y, z, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexsvOES", 
function (coords, offset) {
this.begin ("glDrawTexsvOES");
this.arg ("coords", 5, coords, offset);
this.arg ("offset", offset);
this.end ();
this.mgl11Ext.glDrawTexsvOES (coords, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glDrawTexsvOES", 
function (coords) {
this.begin ("glDrawTexsvOES");
this.arg ("coords", 5, coords);
this.end ();
this.mgl11Ext.glDrawTexsvOES (coords);
this.checkError ();
}, "java.nio.ShortBuffer");
Clazz.defineMethod (c$, "glDrawTexxOES", 
function (x, y, z, width, height) {
this.begin ("glDrawTexxOES");
this.arg ("x", x);
this.arg ("y", y);
this.arg ("z", z);
this.arg ("width", width);
this.arg ("height", height);
this.end ();
this.mgl11Ext.glDrawTexxOES (x, y, z, width, height);
this.checkError ();
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawTexxvOES", 
function (coords, offset) {
this.begin ("glDrawTexxvOES");
this.arg ("coords", 5, coords, offset);
this.arg ("offset", offset);
this.end ();
this.mgl11Ext.glDrawTexxvOES (coords, offset);
this.checkError ();
}, "~A,~N");
Clazz.defineMethod (c$, "glDrawTexxvOES", 
function (coords) {
this.begin ("glDrawTexxvOES");
this.arg ("coords", 5, coords);
this.end ();
this.mgl11Ext.glDrawTexxvOES (coords);
this.checkError ();
}, "java.nio.IntBuffer");
Clazz.defineMethod (c$, "glQueryMatrixxOES", 
function (mantissa, mantissaOffset, exponent, exponentOffset) {
this.begin ("glQueryMatrixxOES");
this.arg ("mantissa", java.util.Arrays.toString (mantissa));
this.arg ("exponent", java.util.Arrays.toString (exponent));
this.end ();
var valid = this.mgl10Ext.glQueryMatrixxOES (mantissa, mantissaOffset, exponent, exponentOffset);
this.returns (this.toString (16, 2, mantissa, mantissaOffset));
this.returns (this.toString (16, 0, exponent, exponentOffset));
this.checkError ();
return valid;
}, "~A,~N,~A,~N");
Clazz.defineMethod (c$, "glQueryMatrixxOES", 
function (mantissa, exponent) {
this.begin ("glQueryMatrixxOES");
this.arg ("mantissa", mantissa.toString ());
this.arg ("exponent", exponent.toString ());
this.end ();
var valid = this.mgl10Ext.glQueryMatrixxOES (mantissa, exponent);
this.returns (this.toString (16, 2, mantissa));
this.returns (this.toString (16, 0, exponent));
this.checkError ();
return valid;
}, "java.nio.IntBuffer,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glBindBuffer", 
function (target, buffer) {
this.begin ("glBindBuffer");
this.arg ("target", target);
this.arg ("buffer", buffer);
this.end ();
this.mgl11.glBindBuffer (target, buffer);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glBufferData", 
function (target, size, data, usage) {
this.begin ("glBufferData");
this.arg ("target", target);
this.arg ("size", size);
this.arg ("data", data.toString ());
this.arg ("usage", usage);
this.end ();
this.mgl11.glBufferData (target, size, data, usage);
this.checkError ();
}, "~N,~N,java.nio.Buffer,~N");
Clazz.defineMethod (c$, "glBufferSubData", 
function (target, offset, size, data) {
this.begin ("glBufferSubData");
this.arg ("target", target);
this.arg ("offset", offset);
this.arg ("size", size);
this.arg ("data", data.toString ());
this.end ();
this.mgl11.glBufferSubData (target, offset, size, data);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glColor4ub", 
function (red, green, blue, alpha) {
this.begin ("glColor4ub");
this.arg ("red", red);
this.arg ("green", green);
this.arg ("blue", blue);
this.arg ("alpha", alpha);
this.end ();
this.mgl11.glColor4ub (red, green, blue, alpha);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDeleteBuffers", 
function (n, buffers, offset) {
this.begin ("glDeleteBuffers");
this.arg ("n", n);
this.arg ("buffers", buffers.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glDeleteBuffers (n, buffers, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glDeleteBuffers", 
function (n, buffers) {
this.begin ("glDeleteBuffers");
this.arg ("n", n);
this.arg ("buffers", buffers.toString ());
this.end ();
this.mgl11.glDeleteBuffers (n, buffers);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGenBuffers", 
function (n, buffers, offset) {
this.begin ("glGenBuffers");
this.arg ("n", n);
this.arg ("buffers", buffers.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGenBuffers (n, buffers, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGenBuffers", 
function (n, buffers) {
this.begin ("glGenBuffers");
this.arg ("n", n);
this.arg ("buffers", buffers.toString ());
this.end ();
this.mgl11.glGenBuffers (n, buffers);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetBooleanv", 
function (pname, params, offset) {
this.begin ("glGetBooleanv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetBooleanv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetBooleanv", 
function (pname, params) {
this.begin ("glGetBooleanv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetBooleanv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetBufferParameteriv", 
function (target, pname, params, offset) {
this.begin ("glGetBufferParameteriv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetBufferParameteriv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetBufferParameteriv", 
function (target, pname, params) {
this.begin ("glGetBufferParameteriv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetBufferParameteriv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetClipPlanef", 
function (pname, eqn, offset) {
this.begin ("glGetClipPlanef");
this.arg ("pname", pname);
this.arg ("eqn", eqn.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetClipPlanef (pname, eqn, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetClipPlanef", 
function (pname, eqn) {
this.begin ("glGetClipPlanef");
this.arg ("pname", pname);
this.arg ("eqn", eqn.toString ());
this.end ();
this.mgl11.glGetClipPlanef (pname, eqn);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetClipPlanex", 
function (pname, eqn, offset) {
this.begin ("glGetClipPlanex");
this.arg ("pname", pname);
this.arg ("eqn", eqn.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetClipPlanex (pname, eqn, offset);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetClipPlanex", 
function (pname, eqn) {
this.begin ("glGetClipPlanex");
this.arg ("pname", pname);
this.arg ("eqn", eqn.toString ());
this.end ();
this.mgl11.glGetClipPlanex (pname, eqn);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetFixedv", 
function (pname, params, offset) {
this.begin ("glGetFixedv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetFixedv (pname, params, offset);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetFixedv", 
function (pname, params) {
this.begin ("glGetFixedv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetFixedv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetFloatv", 
function (pname, params, offset) {
this.begin ("glGetFloatv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetFloatv (pname, params, offset);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glGetFloatv", 
function (pname, params) {
this.begin ("glGetFloatv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetFloatv (pname, params);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetLightfv", 
function (light, pname, params, offset) {
this.begin ("glGetLightfv");
this.arg ("light", light);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetLightfv (light, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetLightfv", 
function (light, pname, params) {
this.begin ("glGetLightfv");
this.arg ("light", light);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetLightfv (light, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetLightxv", 
function (light, pname, params, offset) {
this.begin ("glGetLightxv");
this.arg ("light", light);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetLightxv (light, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetLightxv", 
function (light, pname, params) {
this.begin ("glGetLightxv");
this.arg ("light", light);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetLightxv (light, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetMaterialfv", 
function (face, pname, params, offset) {
this.begin ("glGetMaterialfv");
this.arg ("face", face);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetMaterialfv (face, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetMaterialfv", 
function (face, pname, params) {
this.begin ("glGetMaterialfv");
this.arg ("face", face);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetMaterialfv (face, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetMaterialxv", 
function (face, pname, params, offset) {
this.begin ("glGetMaterialxv");
this.arg ("face", face);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetMaterialxv (face, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetMaterialxv", 
function (face, pname, params) {
this.begin ("glGetMaterialxv");
this.arg ("face", face);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetMaterialxv (face, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetTexEnviv", 
function (env, pname, params, offset) {
this.begin ("glGetTexEnviv");
this.arg ("env", env);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetTexEnviv (env, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexEnviv", 
function (env, pname, params) {
this.begin ("glGetTexEnviv");
this.arg ("env", env);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetTexEnviv (env, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetTexEnvxv", 
function (env, pname, params, offset) {
this.begin ("glGetTexEnviv");
this.arg ("env", env);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetTexEnviv (env, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexEnvxv", 
function (env, pname, params) {
this.begin ("glGetTexEnviv");
this.arg ("env", env);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetTexEnvxv (env, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetTexParameterfv", 
function (target, pname, params, offset) {
this.begin ("glGetTexParameterfv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetTexParameterfv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexParameterfv", 
function (target, pname, params) {
this.begin ("glGetTexParameterfv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetTexParameterfv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glGetTexParameteriv", 
function (target, pname, params, offset) {
this.begin ("glGetTexParameteriv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetTexEnviv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexParameteriv", 
function (target, pname, params) {
this.begin ("glGetTexParameteriv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetTexParameteriv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glGetTexParameterxv", 
function (target, pname, params, offset) {
this.begin ("glGetTexParameterxv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glGetTexParameterxv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glGetTexParameterxv", 
function (target, pname, params) {
this.begin ("glGetTexParameterxv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetTexParameterxv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glIsBuffer", 
function (buffer) {
this.begin ("glIsBuffer");
this.arg ("buffer", buffer);
this.end ();
var result = this.mgl11.glIsBuffer (buffer);
this.checkError ();
return result;
}, "~N");
Clazz.defineMethod (c$, "glIsEnabled", 
function (cap) {
this.begin ("glIsEnabled");
this.arg ("cap", cap);
this.end ();
var result = this.mgl11.glIsEnabled (cap);
this.checkError ();
return result;
}, "~N");
Clazz.defineMethod (c$, "glIsTexture", 
function (texture) {
this.begin ("glIsTexture");
this.arg ("texture", texture);
this.end ();
var result = this.mgl11.glIsTexture (texture);
this.checkError ();
return result;
}, "~N");
Clazz.defineMethod (c$, "glPointParameterf", 
function (pname, param) {
this.begin ("glPointParameterf");
this.arg ("pname", pname);
this.arg ("param", param);
this.end ();
this.mgl11.glPointParameterf (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPointParameterfv", 
function (pname, params, offset) {
this.begin ("glPointParameterfv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glPointParameterfv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glPointParameterfv", 
function (pname, params) {
this.begin ("glPointParameterfv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glPointParameterfv (pname, params);
this.checkError ();
}, "~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glPointParameterx", 
function (pname, param) {
this.begin ("glPointParameterfv");
this.arg ("pname", pname);
this.arg ("param", param);
this.end ();
this.mgl11.glPointParameterx (pname, param);
this.checkError ();
}, "~N,~N");
Clazz.defineMethod (c$, "glPointParameterxv", 
function (pname, params, offset) {
this.begin ("glPointParameterxv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glPointParameterxv (pname, params, offset);
this.checkError ();
}, "~N,~A,~N");
Clazz.defineMethod (c$, "glPointParameterxv", 
function (pname, params) {
this.begin ("glPointParameterxv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glPointParameterxv (pname, params);
this.checkError ();
}, "~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glPointSizePointerOES", 
function (type, stride, pointer) {
this.begin ("glPointSizePointerOES");
this.arg ("type", type);
this.arg ("stride", stride);
this.arg ("params", pointer.toString ());
this.end ();
this.mgl11.glPointSizePointerOES (type, stride, pointer);
this.checkError ();
}, "~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glTexEnvi", 
function (target, pname, param) {
this.begin ("glTexEnvi");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("param", param);
this.end ();
this.mgl11.glTexEnvi (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexEnviv", 
function (target, pname, params, offset) {
this.begin ("glTexEnviv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glTexEnviv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexEnviv", 
function (target, pname, params) {
this.begin ("glTexEnviv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glTexEnviv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glTexParameterfv", 
function (target, pname, params, offset) {
this.begin ("glTexParameterfv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glTexParameterfv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexParameterfv", 
function (target, pname, params) {
this.begin ("glTexParameterfv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glTexParameterfv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.FloatBuffer");
Clazz.defineMethod (c$, "glTexParameteri", 
function (target, pname, param) {
this.begin ("glTexParameterxv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("param", param);
this.end ();
this.mgl11.glTexParameteri (target, pname, param);
this.checkError ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexParameterxv", 
function (target, pname, params, offset) {
this.begin ("glTexParameterxv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.arg ("offset", offset);
this.end ();
this.mgl11.glTexParameterxv (target, pname, params, offset);
this.checkError ();
}, "~N,~N,~A,~N");
Clazz.defineMethod (c$, "glTexParameterxv", 
function (target, pname, params) {
this.begin ("glTexParameterxv");
this.arg ("target", target);
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glTexParameterxv (target, pname, params);
this.checkError ();
}, "~N,~N,java.nio.IntBuffer");
Clazz.defineMethod (c$, "glColorPointer", 
function (size, type, stride, offset) {
this.begin ("glColorPointer");
this.arg ("size", size);
this.arg ("type", type);
this.arg ("stride", stride);
this.arg ("offset", offset);
this.end ();
this.mgl11.glColorPointer (size, type, stride, offset);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glDrawElements", 
function (mode, count, type, offset) {
this.begin ("glDrawElements");
this.arg ("mode", mode);
this.arg ("count", count);
this.arg ("type", type);
this.arg ("offset", offset);
this.end ();
this.mgl11.glDrawElements (mode, count, type, offset);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glGetPointerv", 
function (pname, params) {
this.begin ("glGetPointerv");
this.arg ("pname", pname);
this.arg ("params", params.toString ());
this.end ();
this.mgl11.glGetPointerv (pname, params);
this.checkError ();
}, "~N,~A");
Clazz.defineMethod (c$, "glNormalPointer", 
function (type, stride, offset) {
this.begin ("glNormalPointer");
this.arg ("type", type);
this.arg ("stride", stride);
this.arg ("offset", offset);
this.end ();
this.mgl11.glNormalPointer (type, stride, offset);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "glTexCoordPointer", 
function (size, type, stride, offset) {
this.begin ("glTexCoordPointer");
this.arg ("size", size);
this.arg ("type", type);
this.arg ("stride", stride);
this.arg ("offset", offset);
this.end ();
this.mgl11.glTexCoordPointer (size, type, stride, offset);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glVertexPointer", 
function (size, type, stride, offset) {
this.begin ("glVertexPointer");
this.arg ("size", size);
this.arg ("type", type);
this.arg ("stride", stride);
this.arg ("offset", offset);
this.end ();
this.mgl11.glVertexPointer (size, type, stride, offset);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glCurrentPaletteMatrixOES", 
function (matrixpaletteindex) {
this.begin ("glCurrentPaletteMatrixOES");
this.arg ("matrixpaletteindex", matrixpaletteindex);
this.end ();
this.mgl11Ext.glCurrentPaletteMatrixOES (matrixpaletteindex);
this.checkError ();
}, "~N");
Clazz.defineMethod (c$, "glLoadPaletteFromModelViewMatrixOES", 
function () {
this.begin ("glLoadPaletteFromModelViewMatrixOES");
this.end ();
this.mgl11Ext.glLoadPaletteFromModelViewMatrixOES ();
this.checkError ();
});
Clazz.defineMethod (c$, "glMatrixIndexPointerOES", 
function (size, type, stride, pointer) {
this.begin ("glMatrixIndexPointerOES");
this.argPointer (size, type, stride, pointer);
this.end ();
this.mgl11Ext.glMatrixIndexPointerOES (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glMatrixIndexPointerOES", 
function (size, type, stride, offset) {
this.begin ("glMatrixIndexPointerOES");
this.arg ("size", size);
this.arg ("type", type);
this.arg ("stride", stride);
this.arg ("offset", offset);
this.end ();
this.mgl11Ext.glMatrixIndexPointerOES (size, type, stride, offset);
this.checkError ();
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "glWeightPointerOES", 
function (size, type, stride, pointer) {
this.begin ("glWeightPointerOES");
this.argPointer (size, type, stride, pointer);
this.end ();
this.mgl11Ext.glWeightPointerOES (size, type, stride, pointer);
this.checkError ();
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "glWeightPointerOES", 
function (size, type, stride, offset) {
this.begin ("glWeightPointerOES");
this.arg ("size", size);
this.arg ("type", type);
this.arg ("stride", stride);
this.arg ("offset", offset);
this.end ();
this.mgl11Ext.glWeightPointerOES (size, type, stride, offset);
this.checkError ();
}, "~N,~N,~N,~N");
c$.$GLLogWrapper$PointerInfo$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mSize = 0;
this.mType = 0;
this.mStride = 0;
this.mPointer = null;
this.mTempByteBuffer = null;
Clazz.instantialize (this, arguments);
}, android.opengl.GLLogWrapper, "PointerInfo");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
this.mSize = a;
this.mType = b;
this.mStride = c;
this.mPointer = d;
}, "~N,~N,~N,java.nio.Buffer");
Clazz.defineMethod (c$, "sizeof", 
function (a) {
switch (a) {
case 5121:
return 1;
case 5120:
return 1;
case 5122:
return 2;
case 5132:
return 4;
case 5126:
return 4;
default:
return 0;
}
}, "~N");
Clazz.defineMethod (c$, "getStride", 
function () {
return this.mStride > 0 ? this.mStride : this.sizeof (this.mType) * this.mSize;
});
Clazz.defineMethod (c$, "bindByteBuffer", 
function () {
this.mTempByteBuffer = this.mPointer == null ? null : this.b$["android.opengl.GLLogWrapper"].toByteBuffer (-1, this.mPointer);
});
Clazz.defineMethod (c$, "unbindByteBuffer", 
function () {
this.mTempByteBuffer = null;
});
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"FORMAT_INT", 0,
"FORMAT_FLOAT", 1,
"FORMAT_FIXED", 2);
});
