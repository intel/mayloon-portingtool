﻿Clazz.declarePackage ("android.opengl");
Clazz.load (null, "android.opengl.GLUtils", ["android.opengl.GLES20", "android.util.Log", "java.lang.IllegalArgumentException", "$.NullPointerException"], function () {
c$ = Clazz.declareType (android.opengl, "GLUtils");
c$.getInternalFormat = Clazz.defineMethod (c$, "getInternalFormat", 
function (bitmap) {
if (bitmap == null) {
throw  new NullPointerException ("getInternalFormat can't be used with a null Bitmap");
}var result = android.opengl.GLUtils.native_getInternalFormat (bitmap);
if (result < 0) {
throw  new IllegalArgumentException ("Unknown internalformat");
}return result;
}, "android.graphics.Bitmap");
c$.getType = Clazz.defineMethod (c$, "getType", 
function (bitmap) {
if (bitmap == null) {
throw  new NullPointerException ("getType can't be used with a null Bitmap");
}var result = android.opengl.GLUtils.native_getType (bitmap);
if (result < 0) {
throw  new IllegalArgumentException ("Unknown type");
}return result;
}, "android.graphics.Bitmap");
c$.texImage2D = Clazz.defineMethod (c$, "texImage2D", 
function (target, level, internalformat, bitmap, border) {
if (bitmap == null) {
throw  new NullPointerException ("texImage2D can't be used with a null Bitmap");
}if (android.opengl.GLUtils.native_texImage2D (target, level, internalformat, bitmap, -1, border) != 0) {
throw  new IllegalArgumentException ("invalid Bitmap format");
}}, "~N,~N,~N,android.graphics.Bitmap,~N");
c$.texImage2D = Clazz.defineMethod (c$, "texImage2D", 
function (target, level, internalformat, bitmap, type, border) {
if (bitmap == null) {
throw  new NullPointerException ("texImage2D can't be used with a null Bitmap");
}if (android.opengl.GLUtils.native_texImage2D (target, level, internalformat, bitmap, type, border) != 0) {
throw  new IllegalArgumentException ("invalid Bitmap format");
}}, "~N,~N,~N,android.graphics.Bitmap,~N,~N");
c$.texImage2D = Clazz.defineMethod (c$, "texImage2D", 
function (target, level, bitmap, border) {
if (bitmap == null) {
throw  new NullPointerException ("texImage2D can't be used with a null Bitmap");
}if (android.opengl.GLUtils.native_texImage2D (target, level, -1, bitmap, -1, border) != 0) {
throw  new IllegalArgumentException ("invalid Bitmap format");
}}, "~N,~N,android.graphics.Bitmap,~N");
c$.texSubImage2D = Clazz.defineMethod (c$, "texSubImage2D", 
function (target, level, xoffset, yoffset, bitmap) {
if (bitmap == null) {
throw  new NullPointerException ("texSubImage2D can't be used with a null Bitmap");
}var type = android.opengl.GLUtils.getType (bitmap);
if (android.opengl.GLUtils.native_texSubImage2D (target, level, xoffset, yoffset, bitmap, -1, type) != 0) {
throw  new IllegalArgumentException ("invalid Bitmap format");
}}, "~N,~N,~N,~N,android.graphics.Bitmap");
c$.texSubImage2D = Clazz.defineMethod (c$, "texSubImage2D", 
function (target, level, xoffset, yoffset, bitmap, format, type) {
if (bitmap == null) {
throw  new NullPointerException ("texSubImage2D can't be used with a null Bitmap");
}if (android.opengl.GLUtils.native_texSubImage2D (target, level, xoffset, yoffset, bitmap, format, type) != 0) {
throw  new IllegalArgumentException ("invalid Bitmap format");
}}, "~N,~N,~N,~N,android.graphics.Bitmap,~N,~N");
c$.native_getInternalFormat = Clazz.defineMethod (c$, "native_getInternalFormat", 
($fz = function (bitmap) {
var config = bitmap.getConfig ();
switch (config.nativeInt) {
case 2:
return 6406;
case 5:
return 6408;
case 6:
return 6408;
case 4:
return 6407;
default:
return -1;
}
}, $fz.isPrivate = true, $fz), "android.graphics.Bitmap");
c$.native_getType = Clazz.defineMethod (c$, "native_getType", 
($fz = function (bitmap) {
var config = bitmap.getConfig ();
switch (config.nativeInt) {
case 2:
return 5121;
case 5:
return 32819;
case 6:
return 5121;
case 4:
return 33635;
default:
return -1;
}
}, $fz.isPrivate = true, $fz), "android.graphics.Bitmap");
c$.checkFormat = Clazz.defineMethod (c$, "checkFormat", 
($fz = function (bitmap, format, type) {
var config = bitmap.getConfig ();
switch (config.nativeInt) {
case 6:
case 2:
if (type == 5121) return 0;
case 5:
case 4:
switch (type) {
case 32819:
case 33635:
case 32820:
return 0;
case 5121:
if (format == 6410) return 0;
}
break;
default:
break;
}
return -1;
}, $fz.isPrivate = true, $fz), "android.graphics.Bitmap,~N,~N");
c$.native_texImage2D = Clazz.defineMethod (c$, "native_texImage2D", 
($fz = function (target, level, internalformat, bitmap, type, border) {
if (internalformat < 0) {
internalformat = android.opengl.GLUtils.native_getInternalFormat (bitmap);
}if (type < 0) {
type = android.opengl.GLUtils.native_getType (bitmap);
}var err = android.opengl.GLUtils.checkFormat (bitmap, internalformat, type);
if (err != 0) {
return err;
}if (internalformat == 35734) {
android.util.Log.e ("GLUtils", "Compressed texture is not supported!");
return -1;
} else {
android.opengl.GLES20.glTexImage2D (target, level, internalformat, bitmap.getWidth (), bitmap.getHeight (), border, internalformat, type, bitmap);
return 0;
}}, $fz.isPrivate = true, $fz), "~N,~N,~N,android.graphics.Bitmap,~N,~N");
});
