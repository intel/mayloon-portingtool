﻿Clazz.declarePackage ("android.opengl");
Clazz.load (["javax.microedition.khronos.egl.EGL11"], "android.opengl.EGLLogWrapper", ["android.opengl.GLException", "java.lang.Boolean", "$.StringBuilder", "javax.microedition.khronos.egl.EGL10"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mEgl10 = null;
this.mLog = null;
this.mLogArgumentNames = false;
this.mCheckError = false;
this.mArgCount = 0;
Clazz.instantialize (this, arguments);
}, android.opengl, "EGLLogWrapper", null, javax.microedition.khronos.egl.EGL11);
Clazz.makeConstructor (c$, 
function (egl, configFlags, log) {
this.mEgl10 = egl;
this.mLog = log;
this.mLogArgumentNames = (4 & configFlags) != 0;
this.mCheckError = (1 & configFlags) != 0;
}, "javax.microedition.khronos.egl.EGL,~N,java.io.Writer");
Clazz.defineMethod (c$, "eglChooseConfig", 
function (display, attrib_list, configs, config_size, num_config) {
this.begin ("eglChooseConfig");
this.arg ("display", display);
this.arg ("attrib_list", attrib_list);
this.arg ("config_size", config_size);
this.end ();
var result = this.mEgl10.eglChooseConfig (display, attrib_list, configs, config_size, num_config);
this.arg ("configs", configs);
this.arg ("num_config", num_config);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,~A,~A,~N,~A");
Clazz.defineMethod (c$, "eglCopyBuffers", 
function (display, surface, native_pixmap) {
this.begin ("eglCopyBuffers");
this.arg ("display", display);
this.arg ("surface", surface);
this.arg ("native_pixmap", native_pixmap);
this.end ();
var result = this.mEgl10.eglCopyBuffers (display, surface, native_pixmap);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLSurface,~O");
Clazz.defineMethod (c$, "eglCreateContext", 
function (display, config, share_context, attrib_list) {
this.begin ("eglCreateContext");
this.arg ("display", display);
this.arg ("config", config);
this.arg ("share_context", share_context);
this.arg ("attrib_list", attrib_list);
this.end ();
var result = this.mEgl10.eglCreateContext (display, config, share_context, attrib_list);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLConfig,javax.microedition.khronos.egl.EGLContext,~A");
Clazz.defineMethod (c$, "eglCreatePbufferSurface", 
function (display, config, attrib_list) {
this.begin ("eglCreatePbufferSurface");
this.arg ("display", display);
this.arg ("config", config);
this.arg ("attrib_list", attrib_list);
this.end ();
var result = this.mEgl10.eglCreatePbufferSurface (display, config, attrib_list);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLConfig,~A");
Clazz.defineMethod (c$, "eglCreatePixmapSurface", 
function (display, config, native_pixmap, attrib_list) {
this.begin ("eglCreatePixmapSurface");
this.arg ("display", display);
this.arg ("config", config);
this.arg ("native_pixmap", native_pixmap);
this.arg ("attrib_list", attrib_list);
this.end ();
var result = this.mEgl10.eglCreatePixmapSurface (display, config, native_pixmap, attrib_list);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLConfig,~O,~A");
Clazz.defineMethod (c$, "eglCreateWindowSurface", 
function (display, config, native_window, attrib_list) {
this.begin ("eglCreateWindowSurface");
this.arg ("display", display);
this.arg ("config", config);
this.arg ("native_window", native_window);
this.arg ("attrib_list", attrib_list);
this.end ();
var result = this.mEgl10.eglCreateWindowSurface (display, config, native_window, attrib_list);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLConfig,~O,~A");
Clazz.defineMethod (c$, "eglDestroyContext", 
function (display, context) {
this.begin ("eglDestroyContext");
this.arg ("display", display);
this.arg ("context", context);
this.end ();
var result = this.mEgl10.eglDestroyContext (display, context);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLContext");
Clazz.defineMethod (c$, "eglDestroySurface", 
function (display, surface) {
this.begin ("eglDestroySurface");
this.arg ("display", display);
this.arg ("surface", surface);
this.end ();
var result = this.mEgl10.eglDestroySurface (display, surface);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLSurface");
Clazz.defineMethod (c$, "eglGetConfigAttrib", 
function (display, config, attribute, value) {
this.begin ("eglGetConfigAttrib");
this.arg ("display", display);
this.arg ("config", config);
this.arg ("attribute", attribute);
this.end ();
var result = this.mEgl10.eglGetConfigAttrib (display, config, attribute, value);
this.arg ("value", value);
this.returns (result);
this.checkError ();
return false;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLConfig,~N,~A");
Clazz.defineMethod (c$, "eglGetConfigs", 
function (display, configs, config_size, num_config) {
this.begin ("eglGetConfigs");
this.arg ("display", display);
this.arg ("config_size", config_size);
this.end ();
var result = this.mEgl10.eglGetConfigs (display, configs, config_size, num_config);
this.arg ("configs", configs);
this.arg ("num_config", num_config);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,~A,~N,~A");
Clazz.defineMethod (c$, "eglGetCurrentContext", 
function () {
this.begin ("eglGetCurrentContext");
this.end ();
var result = this.mEgl10.eglGetCurrentContext ();
this.returns (result);
this.checkError ();
return result;
});
Clazz.defineMethod (c$, "eglGetCurrentDisplay", 
function () {
this.begin ("eglGetCurrentDisplay");
this.end ();
var result = this.mEgl10.eglGetCurrentDisplay ();
this.returns (result);
this.checkError ();
return result;
});
Clazz.defineMethod (c$, "eglGetCurrentSurface", 
function (readdraw) {
this.begin ("eglGetCurrentSurface");
this.arg ("readdraw", readdraw);
this.end ();
var result = this.mEgl10.eglGetCurrentSurface (readdraw);
this.returns (result);
this.checkError ();
return result;
}, "~N");
Clazz.defineMethod (c$, "eglGetDisplay", 
function (native_display) {
this.begin ("eglGetDisplay");
this.arg ("native_display", native_display);
this.end ();
var result = this.mEgl10.eglGetDisplay (native_display);
this.returns (result);
this.checkError ();
return result;
}, "~O");
Clazz.defineMethod (c$, "eglGetError", 
function () {
this.begin ("eglGetError");
this.end ();
var result = this.mEgl10.eglGetError ();
this.returns (android.opengl.EGLLogWrapper.getErrorString (result));
return result;
});
Clazz.defineMethod (c$, "eglInitialize", 
function (display, major_minor) {
this.begin ("eglInitialize");
this.arg ("display", display);
this.end ();
var result = this.mEgl10.eglInitialize (display, major_minor);
this.returns (result);
this.arg ("major_minor", major_minor);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,~A");
Clazz.defineMethod (c$, "eglMakeCurrent", 
function (display, draw, read, context) {
this.begin ("eglMakeCurrent");
this.arg ("display", display);
this.arg ("draw", draw);
this.arg ("read", read);
this.arg ("context", context);
this.end ();
var result = this.mEgl10.eglMakeCurrent (display, draw, read, context);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLSurface,javax.microedition.khronos.egl.EGLSurface,javax.microedition.khronos.egl.EGLContext");
Clazz.defineMethod (c$, "eglQueryContext", 
function (display, context, attribute, value) {
this.begin ("eglQueryContext");
this.arg ("display", display);
this.arg ("context", context);
this.arg ("attribute", attribute);
this.end ();
var result = this.mEgl10.eglQueryContext (display, context, attribute, value);
this.returns (value[0]);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLContext,~N,~A");
Clazz.defineMethod (c$, "eglQueryString", 
function (display, name) {
this.begin ("eglQueryString");
this.arg ("display", display);
this.arg ("name", name);
this.end ();
var result = this.mEgl10.eglQueryString (display, name);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,~N");
Clazz.defineMethod (c$, "eglQuerySurface", 
function (display, surface, attribute, value) {
this.begin ("eglQuerySurface");
this.arg ("display", display);
this.arg ("surface", surface);
this.arg ("attribute", attribute);
this.end ();
var result = this.mEgl10.eglQuerySurface (display, surface, attribute, value);
this.returns (value[0]);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLSurface,~N,~A");
Clazz.defineMethod (c$, "eglSwapBuffers", 
function (display, surface) {
this.begin ("eglInitialize");
this.arg ("display", display);
this.arg ("surface", surface);
this.end ();
var result = this.mEgl10.eglSwapBuffers (display, surface);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay,javax.microedition.khronos.egl.EGLSurface");
Clazz.defineMethod (c$, "eglTerminate", 
function (display) {
this.begin ("eglTerminate");
this.arg ("display", display);
this.end ();
var result = this.mEgl10.eglTerminate (display);
this.returns (result);
this.checkError ();
return result;
}, "javax.microedition.khronos.egl.EGLDisplay");
Clazz.defineMethod (c$, "eglWaitGL", 
function () {
this.begin ("eglWaitGL");
this.end ();
var result = this.mEgl10.eglWaitGL ();
this.returns (result);
this.checkError ();
return result;
});
Clazz.defineMethod (c$, "eglWaitNative", 
function (engine, bindTarget) {
this.begin ("eglWaitNative");
this.arg ("engine", engine);
this.arg ("bindTarget", bindTarget);
this.end ();
var result = this.mEgl10.eglWaitNative (engine, bindTarget);
this.returns (result);
this.checkError ();
return result;
}, "~N,~O");
Clazz.defineMethod (c$, "checkError", 
($fz = function () {
var eglError;
if ((eglError = this.mEgl10.eglGetError ()) != 12288) {
var errorMessage = "eglError: " + android.opengl.EGLLogWrapper.getErrorString (eglError);
this.logLine (errorMessage);
if (this.mCheckError) {
throw  new android.opengl.GLException (eglError, errorMessage);
}}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "logLine", 
($fz = function (message) {
this.log (message + '\n');
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "log", 
($fz = function (message) {
try {
this.mLog.write (message);
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "begin", 
($fz = function (name) {
this.log (name + '(');
this.mArgCount = 0;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, value) {
if (this.mArgCount++ > 0) {
this.log (", ");
}if (this.mLogArgumentNames) {
this.log (name + "=");
}this.log (value);
}, $fz.isPrivate = true, $fz), "~S,~S");
Clazz.defineMethod (c$, "end", 
($fz = function () {
this.log (");\n");
this.flush ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "flush", 
($fz = function () {
try {
this.mLog.flush ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
this.mLog = null;
} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "arg", 
($fz = function (name, value) {
this.arg (name, Integer.toString (value));
}, $fz.isPrivate = true, $fz), "~S,~N");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, object) {
this.arg (name, this.toString (object));
}, $fz.isPrivate = true, $fz), "~S,~O");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, object) {
if (object === javax.microedition.khronos.egl.EGL10.EGL_DEFAULT_DISPLAY) {
this.arg (name, "EGL10.EGL_DEFAULT_DISPLAY");
} else if (object === javax.microedition.khronos.egl.EGL10.EGL_NO_DISPLAY) {
this.arg (name, "EGL10.EGL_NO_DISPLAY");
} else {
this.arg (name, this.toString (object));
}}, $fz.isPrivate = true, $fz), "~S,javax.microedition.khronos.egl.EGLDisplay");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, object) {
if (object === javax.microedition.khronos.egl.EGL10.EGL_NO_CONTEXT) {
this.arg (name, "EGL10.EGL_NO_CONTEXT");
} else {
this.arg (name, this.toString (object));
}}, $fz.isPrivate = true, $fz), "~S,javax.microedition.khronos.egl.EGLContext");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, object) {
if (object === javax.microedition.khronos.egl.EGL10.EGL_NO_SURFACE) {
this.arg (name, "EGL10.EGL_NO_SURFACE");
} else {
this.arg (name, this.toString (object));
}}, $fz.isPrivate = true, $fz), "~S,javax.microedition.khronos.egl.EGLSurface");
Clazz.defineMethod (c$, "returns", 
($fz = function (result) {
this.log (" returns " + result + ";\n");
this.flush ();
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "returns", 
($fz = function (result) {
this.returns (Integer.toString (result));
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "returns", 
($fz = function (result) {
this.returns (Boolean.toString (result));
}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "returns", 
($fz = function (result) {
this.returns (this.toString (result));
}, $fz.isPrivate = true, $fz), "~O");
Clazz.defineMethod (c$, "toString", 
($fz = function (obj) {
if (obj == null) {
return "null";
} else {
return obj.toString ();
}}, $fz.isPrivate = true, $fz), "~O");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, arr) {
if (arr == null) {
this.arg (name, "null");
} else {
this.arg (name, this.toString (arr.length, arr, 0));
}}, $fz.isPrivate = true, $fz), "~S,~A");
Clazz.defineMethod (c$, "arg", 
($fz = function (name, arr) {
if (arr == null) {
this.arg (name, "null");
} else {
this.arg (name, this.toString (arr.length, arr, 0));
}}, $fz.isPrivate = true, $fz), "~S,~A");
Clazz.defineMethod (c$, "toString", 
($fz = function (n, arr, offset) {
var buf =  new StringBuilder ();
buf.append ("{\n");
var arrLen = arr.length;
for (var i = 0; i < n; i++) {
var index = offset + i;
buf.append (" [" + index + "] = ");
if (index < 0 || index >= arrLen) {
buf.append ("out of bounds");
} else {
buf.append (arr[index]);
}buf.append ('\n');
}
buf.append ("}");
return buf.toString ();
}, $fz.isPrivate = true, $fz), "~N,~A,~N");
Clazz.defineMethod (c$, "toString", 
($fz = function (n, arr, offset) {
var buf =  new StringBuilder ();
buf.append ("{\n");
var arrLen = arr.length;
for (var i = 0; i < n; i++) {
var index = offset + i;
buf.append (" [" + index + "] = ");
if (index < 0 || index >= arrLen) {
buf.append ("out of bounds");
} else {
buf.append (arr[index]);
}buf.append ('\n');
}
buf.append ("}");
return buf.toString ();
}, $fz.isPrivate = true, $fz), "~N,~A,~N");
c$.getHex = Clazz.defineMethod (c$, "getHex", 
($fz = function (value) {
return "0x" + Integer.toHexString (value);
}, $fz.isPrivate = true, $fz), "~N");
c$.getErrorString = Clazz.defineMethod (c$, "getErrorString", 
function (error) {
switch (error) {
case 12288:
return "EGL_SUCCESS";
case 12289:
return "EGL_NOT_INITIALIZED";
case 12290:
return "EGL_BAD_ACCESS";
case 12291:
return "EGL_BAD_ALLOC";
case 12292:
return "EGL_BAD_ATTRIBUTE";
case 12293:
return "EGL_BAD_CONFIG";
case 12294:
return "EGL_BAD_CONTEXT";
case 12295:
return "EGL_BAD_CURRENT_SURFACE";
case 12296:
return "EGL_BAD_DISPLAY";
case 12297:
return "EGL_BAD_MATCH";
case 12298:
return "EGL_BAD_NATIVE_PIXMAP";
case 12299:
return "EGL_BAD_NATIVE_WINDOW";
case 12300:
return "EGL_BAD_PARAMETER";
case 12301:
return "EGL_BAD_SURFACE";
case 12302:
return "EGL_CONTEXT_LOST";
default:
return android.opengl.EGLLogWrapper.getHex (error);
}
}, "~N");
});
