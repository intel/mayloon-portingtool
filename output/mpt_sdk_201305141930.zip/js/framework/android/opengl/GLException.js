﻿Clazz.declarePackage ("android.opengl");
Clazz.load (["java.lang.RuntimeException"], "android.opengl.GLException", ["android.opengl.GLU"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mError = 0;
Clazz.instantialize (this, arguments);
}, android.opengl, "GLException", RuntimeException);
Clazz.makeConstructor (c$, 
function (error) {
Clazz.superConstructor (this, android.opengl.GLException, [android.opengl.GLException.getErrorString (error)]);
this.mError = error;
}, "~N");
Clazz.makeConstructor (c$, 
function (error, string) {
Clazz.superConstructor (this, android.opengl.GLException, [string]);
this.mError = error;
}, "~N,~S");
c$.getErrorString = Clazz.defineMethod (c$, "getErrorString", 
($fz = function (error) {
var errorString = android.opengl.GLU.gluErrorString (error);
if (errorString == null) {
errorString = "Unknown error 0x" + Integer.toHexString (error);
}return errorString;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getError", 
function () {
return this.mError;
});
});
