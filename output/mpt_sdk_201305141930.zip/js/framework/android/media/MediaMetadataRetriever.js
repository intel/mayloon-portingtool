﻿Clazz.declarePackage ("android.media");
Clazz.load (null, "android.media.MediaMetadataRetriever", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mNativeContext = 0;
Clazz.instantialize (this, arguments);
}, android.media, "MediaMetadataRetriever");
Clazz.makeConstructor (c$, 
function () {
this.native_setup ();
});
Clazz.defineMethod (c$, "setDataSource", 
function (fd) {
this.setDataSource (fd, 0, 0x7ffffffffffffff);
}, "java.io.FileDescriptor");
Clazz.defineMethod (c$, "setDataSource", 
function (context, uri) {
if (uri == null) {
throw  new IllegalArgumentException ();
}var scheme = uri.getScheme ();
if (scheme == null || scheme.equals ("file")) {
this.setDataSource (uri.getPath ());
return ;
}var fd = null;
try {
var resolver = context.getContentResolver ();
try {
fd = resolver.openAssetFileDescriptor (uri, "r");
} catch (e) {
if (Clazz.instanceOf (e, java.io.FileNotFoundException)) {
throw  new IllegalArgumentException ();
} else {
throw e;
}
}
if (fd == null) {
throw  new IllegalArgumentException ();
}var descriptor = fd.getFileDescriptor ();
if (!descriptor.valid ()) {
throw  new IllegalArgumentException ();
}if (fd.getDeclaredLength () < 0) {
this.setDataSource (descriptor);
} else {
this.setDataSource (descriptor, fd.getStartOffset (), fd.getDeclaredLength ());
}return ;
} catch (ex) {
if (Clazz.instanceOf (ex, SecurityException)) {
} else {
throw ex;
}
} finally {
try {
if (fd != null) {
fd.close ();
}} catch (ioEx) {
if (Clazz.instanceOf (ioEx, java.io.IOException)) {
} else {
throw ioEx;
}
}
}
this.setDataSource (uri.toString ());
}, "android.content.Context,android.net.Uri");
Clazz.defineMethod (c$, "getFrameAtTime", 
function (timeUs, option) {
if (option < 0 || option > 3) {
throw  new IllegalArgumentException ("Unsupported option: " + option);
}return this._getFrameAtTime (timeUs, option);
}, "~N,~N");
Clazz.defineMethod (c$, "getFrameAtTime", 
function (timeUs) {
return this.getFrameAtTime (timeUs, 2);
}, "~N");
Clazz.defineMethod (c$, "getFrameAtTime", 
function () {
return this.getFrameAtTime (-1, 2);
});
Clazz.defineMethod (c$, "getEmbeddedPicture", 
function () {
return this.getEmbeddedPicture (65535);
});
Clazz.defineMethod (c$, "finalize", 
function () {
try {
this.native_finalize ();
} finally {
Clazz.superCall (this, android.media.MediaMetadataRetriever, "finalize", []);
}
});
{
System.loadLibrary ("media_jni");
android.media.MediaMetadataRetriever.native_init ();
}Clazz.defineStatics (c$,
"EMBEDDED_PICTURE_TYPE_ANY", 0xFFFF,
"OPTION_PREVIOUS_SYNC", 0x00,
"OPTION_NEXT_SYNC", 0x01,
"OPTION_CLOSEST_SYNC", 0x02,
"OPTION_CLOSEST", 0x03,
"METADATA_KEY_CD_TRACK_NUMBER", 0,
"METADATA_KEY_ALBUM", 1,
"METADATA_KEY_ARTIST", 2,
"METADATA_KEY_AUTHOR", 3,
"METADATA_KEY_COMPOSER", 4,
"METADATA_KEY_DATE", 5,
"METADATA_KEY_GENRE", 6,
"METADATA_KEY_TITLE", 7,
"METADATA_KEY_YEAR", 8,
"METADATA_KEY_DURATION", 9,
"METADATA_KEY_NUM_TRACKS", 10,
"METADATA_KEY_WRITER", 11,
"METADATA_KEY_MIMETYPE", 12,
"METADATA_KEY_ALBUMARTIST", 13,
"METADATA_KEY_DISC_NUMBER", 14,
"METADATA_KEY_COMPILATION", 15);
});
