﻿Clazz.declarePackage ("android.media");
Clazz.load (["android.media.MediaScannerClient", "android.graphics.BitmapFactory"], "android.media.MediaScanner", ["android.content.ContentUris", "$.ContentValues", "android.media.ExifInterface", "$.MediaFile", "android.net.Uri", "android.os.SystemProperties", "android.provider.MediaStore", "$.Settings", "android.text.TextUtils", "android.util.Log", "java.io.BufferedReader", "$.File", "$.FileInputStream", "$.InputStreamReader", "java.lang.Character", "$.IllegalArgumentException", "$.Long", "java.util.ArrayList", "$.HashMap", "$.HashSet"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mNativeContext = 0;
this.mContext = null;
this.mMediaProvider = null;
this.mAudioUri = null;
this.mVideoUri = null;
this.mImagesUri = null;
this.mThumbsUri = null;
this.mGenresUri = null;
this.mPlaylistsUri = null;
this.mProcessPlaylists = false;
this.mProcessGenres = false;
this.mOriginalCount = 0;
this.mDefaultRingtoneSet = false;
this.mDefaultNotificationSet = false;
this.mDefaultAlarmSet = false;
this.mDefaultRingtoneFilename = null;
this.mDefaultNotificationFilename = null;
this.mDefaultAlarmAlertFilename = null;
this.mCaseInsensitivePaths = false;
this.mBitmapOptions = null;
this.mFileCache = null;
this.mPlayLists = null;
this.mGenreCache = null;
this.mClient = null;
if (!Clazz.isClassDefined ("android.media.MediaScanner.MyMediaScannerClient")) {
android.media.MediaScanner.$MediaScanner$MyMediaScannerClient$ ();
}
Clazz.instantialize (this, arguments);
}, android.media, "MediaScanner");
Clazz.prepareFields (c$, function () {
this.mBitmapOptions =  new android.graphics.BitmapFactory.Options ();
this.mClient = Clazz.innerTypeInstance (android.media.MediaScanner.MyMediaScannerClient, this, null);
});
Clazz.makeConstructor (c$, 
function (c) {
this.native_setup ();
this.mContext = c;
this.mBitmapOptions.inSampleSize = 1;
this.mBitmapOptions.inJustDecodeBounds = true;
this.setDefaultRingtoneFileNames ();
}, "android.content.Context");
Clazz.defineMethod (c$, "setDefaultRingtoneFileNames", 
($fz = function () {
this.mDefaultRingtoneFilename = android.os.SystemProperties.get ("ro.config.ringtone");
this.mDefaultNotificationFilename = android.os.SystemProperties.get ("ro.config.notification_sound");
this.mDefaultAlarmAlertFilename = android.os.SystemProperties.get ("ro.config.alarm_alert");
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "prescan", 
($fz = function (filePath) {
var c = null;
var where = null;
var selectionArgs = null;
if (this.mFileCache == null) {
this.mFileCache =  new java.util.HashMap ();
} else {
this.mFileCache.clear ();
}if (this.mPlayLists == null) {
this.mPlayLists =  new java.util.ArrayList ();
} else {
this.mPlayLists.clear ();
}try {
if (filePath != null) {
where = "_data=?";
selectionArgs = [filePath];
}c = this.mMediaProvider.query (this.mAudioUri, android.media.MediaScanner.AUDIO_PROJECTION, where, selectionArgs, null);
if (c != null) {
try {
while (c.moveToNext ()) {
var rowId = c.getLong (0);
var path = c.getString (1);
var lastModified = c.getLong (2);
if (path.startsWith ("/")) {
var key = path;
if (this.mCaseInsensitivePaths) {
key = path.toLowerCase ();
}this.mFileCache.put (key,  new android.media.MediaScanner.FileCacheEntry (this.mAudioUri, rowId, path, lastModified));
}}
} finally {
c.close ();
c = null;
}
}if (filePath != null) {
where = "_data=?";
} else {
where = null;
}c = this.mMediaProvider.query (this.mVideoUri, android.media.MediaScanner.VIDEO_PROJECTION, where, selectionArgs, null);
if (c != null) {
try {
while (c.moveToNext ()) {
var rowId = c.getLong (0);
var path = c.getString (1);
var lastModified = c.getLong (2);
if (path.startsWith ("/")) {
var key = path;
if (this.mCaseInsensitivePaths) {
key = path.toLowerCase ();
}this.mFileCache.put (key,  new android.media.MediaScanner.FileCacheEntry (this.mVideoUri, rowId, path, lastModified));
}}
} finally {
c.close ();
c = null;
}
}if (filePath != null) {
where = "_data=?";
} else {
where = null;
}this.mOriginalCount = 0;
c = this.mMediaProvider.query (this.mImagesUri, android.media.MediaScanner.IMAGES_PROJECTION, where, selectionArgs, null);
if (c != null) {
try {
this.mOriginalCount = c.getCount ();
while (c.moveToNext ()) {
var rowId = c.getLong (0);
var path = c.getString (1);
var lastModified = c.getLong (2);
if (path.startsWith ("/")) {
var key = path;
if (this.mCaseInsensitivePaths) {
key = path.toLowerCase ();
}this.mFileCache.put (key,  new android.media.MediaScanner.FileCacheEntry (this.mImagesUri, rowId, path, lastModified));
}}
} finally {
c.close ();
c = null;
}
}if (this.mProcessPlaylists) {
if (filePath != null) {
where = "_data=?";
} else {
where = null;
}c = this.mMediaProvider.query (this.mPlaylistsUri, android.media.MediaScanner.PLAYLISTS_PROJECTION, where, selectionArgs, null);
if (c != null) {
try {
while (c.moveToNext ()) {
var path = c.getString (1);
if (path != null && path.length > 0) {
var rowId = c.getLong (0);
var lastModified = c.getLong (2);
var key = path;
if (this.mCaseInsensitivePaths) {
key = path.toLowerCase ();
}this.mFileCache.put (key,  new android.media.MediaScanner.FileCacheEntry (this.mPlaylistsUri, rowId, path, lastModified));
}}
} finally {
c.close ();
c = null;
}
}}} finally {
if (c != null) {
c.close ();
}}
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "inScanDirectory", 
($fz = function (path, directories) {
for (var i = 0; i < directories.length; i++) {
if (path.startsWith (directories[i])) {
return true;
}}
return false;
}, $fz.isPrivate = true, $fz), "~S,~A");
Clazz.defineMethod (c$, "pruneDeadThumbnailFiles", 
($fz = function () {
var existingFiles =  new java.util.HashSet ();
var directory = "/sdcard/DCIM/.thumbnails";
var files = ( new java.io.File (directory)).list ();
if (files == null) files =  new Array (0);
for (var i = 0; i < files.length; i++) {
var fullPathString = directory + "/" + files[i];
existingFiles.add (fullPathString);
}
var c = this.mMediaProvider.query (this.mThumbsUri, ["_data"], null, null, null);
android.util.Log.v ("MediaScanner", "pruneDeadThumbnailFiles... " + c);
if (c != null && c.moveToFirst ()) {
do {
var fullPathString = c.getString (0);
existingFiles.remove (fullPathString);
} while (c.moveToNext ());
}for (var fileToDelete, $fileToDelete = existingFiles.iterator (); $fileToDelete.hasNext () && ((fileToDelete = $fileToDelete.next ()) || true);) {
if (false) android.util.Log.v ("MediaScanner", "fileToDelete is " + fileToDelete);
try {
( new java.io.File (fileToDelete)).$delete ();
} catch (ex) {
if (Clazz.instanceOf (ex, SecurityException)) {
} else {
throw ex;
}
}
}
android.util.Log.v ("MediaScanner", "/pruneDeadThumbnailFiles... " + c);
if (c != null) {
c.close ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "postscan", 
($fz = function (directories) {
var iterator = this.mFileCache.values ().iterator ();
while (iterator.hasNext ()) {
var entry = iterator.next ();
var path = entry.mPath;
var fileMissing = false;
if (!entry.mSeenInFileSystem) {
if (this.inScanDirectory (path, directories)) {
fileMissing = true;
} else {
var testFile =  new java.io.File (path);
if (!testFile.exists ()) {
fileMissing = true;
}}}if (fileMissing) {
var mediaFileType = android.media.MediaFile.getFileType (path);
var fileType = (mediaFileType == null ? 0 : mediaFileType.fileType);
if (android.media.MediaFile.isPlayListFileType (fileType)) {
var values =  new android.content.ContentValues ();
values.put ("_data", "");
values.put ("date_modified", new Integer (0));
this.mMediaProvider.update (android.content.ContentUris.withAppendedId (this.mPlaylistsUri, entry.mRowId), values, null, null);
} else {
this.mMediaProvider.$delete (android.content.ContentUris.withAppendedId (entry.mTableUri, entry.mRowId), null, null);
iterator.remove ();
}}}
if (this.mProcessPlaylists) {
this.processPlayLists ();
}if (this.mOriginalCount == 0 && this.mImagesUri.equals (android.provider.MediaStore.Images.Media.getContentUri ("external"))) this.pruneDeadThumbnailFiles ();
this.mGenreCache = null;
this.mPlayLists = null;
this.mFileCache = null;
this.mMediaProvider = null;
}, $fz.isPrivate = true, $fz), "~A");
Clazz.defineMethod (c$, "initialize", 
($fz = function (volumeName) {
this.mMediaProvider = this.mContext.getContentResolver ().acquireProvider ("media");
this.mAudioUri = android.provider.MediaStore.Audio.Media.getContentUri (volumeName);
this.mVideoUri = android.provider.MediaStore.Video.Media.getContentUri (volumeName);
this.mImagesUri = android.provider.MediaStore.Images.Media.getContentUri (volumeName);
this.mThumbsUri = android.provider.MediaStore.Images.Thumbnails.getContentUri (volumeName);
if (!volumeName.equals ("internal")) {
this.mProcessPlaylists = true;
this.mProcessGenres = true;
this.mGenreCache =  new java.util.HashMap ();
this.mGenresUri = android.provider.MediaStore.Audio.Genres.getContentUri (volumeName);
this.mPlaylistsUri = android.provider.MediaStore.Audio.Playlists.getContentUri (volumeName);
this.mCaseInsensitivePaths = true;
}}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "scanDirectories", 
function (directories, volumeName) {
try {
var start = System.currentTimeMillis ();
this.initialize (volumeName);
this.prescan (null);
var prescan = System.currentTimeMillis ();
for (var i = 0; i < directories.length; i++) {
this.processDirectory (directories[i], android.media.MediaFile.sFileExtensions, this.mClient);
}
var scan = System.currentTimeMillis ();
this.postscan (directories);
var end = System.currentTimeMillis ();
if (true) {
android.util.Log.d ("MediaScanner", " prescan time: " + (prescan - start) + "ms\n");
android.util.Log.d ("MediaScanner", "    scan time: " + (scan - prescan) + "ms\n");
android.util.Log.d ("MediaScanner", "postscan time: " + (end - scan) + "ms\n");
android.util.Log.d ("MediaScanner", "   total time: " + (end - start) + "ms\n");
}} catch (e$$) {
if (Clazz.instanceOf (e$$, android.database.SQLException)) {
var e = e$$;
{
android.util.Log.e ("MediaScanner", "SQLException in MediaScanner.scan()", e);
}
} else if (Clazz.instanceOf (e$$, UnsupportedOperationException)) {
var e = e$$;
{
android.util.Log.e ("MediaScanner", "UnsupportedOperationException in MediaScanner.scan()", e);
}
} else if (Clazz.instanceOf (e$$, android.os.RemoteException)) {
var e = e$$;
{
android.util.Log.e ("MediaScanner", "RemoteException in MediaScanner.scan()", e);
}
} else {
throw e$$;
}
}
}, "~A,~S");
Clazz.defineMethod (c$, "scanSingleFile", 
function (path, volumeName, mimeType) {
try {
this.initialize (volumeName);
this.prescan (path);
var file =  new java.io.File (path);
var lastModifiedSeconds = Math.floor (file.lastModified () / 1000);
return this.mClient.doScanFile (path, mimeType, lastModifiedSeconds, file.length (), true);
} catch (e) {
if (Clazz.instanceOf (e, android.os.RemoteException)) {
android.util.Log.e ("MediaScanner", "RemoteException in MediaScanner.scanFile()", e);
return null;
} else {
throw e;
}
}
}, "~S,~S,~S");
Clazz.defineMethod (c$, "matchPaths", 
($fz = function (path1, path2) {
var result = 0;
var end1 = path1.length;
var end2 = path2.length;
while (end1 > 0 && end2 > 0) {
var slash1 = path1.lastIndexOf ('/', end1 - 1);
var slash2 = path2.lastIndexOf ('/', end2 - 1);
var backSlash1 = path1.lastIndexOf ('\\', end1 - 1);
var backSlash2 = path2.lastIndexOf ('\\', end2 - 1);
var start1 = (slash1 > backSlash1 ? slash1 : backSlash1);
var start2 = (slash2 > backSlash2 ? slash2 : backSlash2);
if (start1 < 0) start1 = 0;
 else start1++;
if (start2 < 0) start2 = 0;
 else start2++;
var length = end1 - start1;
if (end2 - start2 != length) break;
if (path1.regionMatches (true, start1, path2, start2, length)) {
result++;
end1 = start1 - 1;
end2 = start2 - 1;
} else break;
}
return result;
}, $fz.isPrivate = true, $fz), "~S,~S");
Clazz.defineMethod (c$, "addPlayListEntry", 
($fz = function (entry, playListDirectory, uri, values, index) {
var entryLength = entry.length;
while (entryLength > 0 && Character.isWhitespace (entry.charAt (entryLength - 1))) entryLength--;

if (entryLength < 3) return false;
if (entryLength < entry.length) entry = entry.substring (0, entryLength);
var ch1 = entry.charAt (0);
var fullPath = ((ch1).charCodeAt (0) == ('/').charCodeAt (0) || (Character.isLetter (ch1) && (entry.charAt (1)).charCodeAt (0) == (':').charCodeAt (0) && (entry.charAt (2)).charCodeAt (0) == ('\\').charCodeAt (0)));
if (!fullPath) entry = playListDirectory + entry;
var bestMatch = null;
var bestMatchLength = 0;
var iterator = this.mFileCache.values ().iterator ();
while (iterator.hasNext ()) {
var cacheEntry = iterator.next ();
var path = cacheEntry.mPath;
if (path.equalsIgnoreCase (entry)) {
bestMatch = cacheEntry;
break;
}var matchLength = this.matchPaths (path, entry);
if (matchLength > bestMatchLength) {
bestMatch = cacheEntry;
bestMatchLength = matchLength;
}}
if (bestMatch == null || !this.mAudioUri.equals (bestMatch.mTableUri)) {
return false;
}values.clear ();
values.put ("play_order", Integer.$valueOf (index));
values.put ("audio_id", Long.$valueOf (bestMatch.mRowId));
this.mMediaProvider.insert (uri, values);
return true;
}, $fz.isPrivate = true, $fz), "~S,~S,android.net.Uri,android.content.ContentValues,~N");
Clazz.defineMethod (c$, "processM3uPlayList", 
($fz = function (path, playListDirectory, uri, values) {
var reader = null;
try {
var f =  new java.io.File (path);
if (f.exists ()) {
reader =  new java.io.BufferedReader ( new java.io.InputStreamReader ( new java.io.FileInputStream (f)), 8192);
var line = reader.readLine ();
var index = 0;
while (line != null) {
if (line.length > 0 && (line.charAt (0)).charCodeAt (0) != ('#').charCodeAt (0)) {
values.clear ();
if (this.addPlayListEntry (line, playListDirectory, uri, values, index)) index++;
}line = reader.readLine ();
}
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
android.util.Log.e ("MediaScanner", "IOException in MediaScanner.processM3uPlayList()", e);
} else {
throw e;
}
} finally {
try {
if (reader != null) reader.close ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
android.util.Log.e ("MediaScanner", "IOException in MediaScanner.processM3uPlayList()", e);
} else {
throw e;
}
}
}
}, $fz.isPrivate = true, $fz), "~S,~S,android.net.Uri,android.content.ContentValues");
Clazz.defineMethod (c$, "processPlsPlayList", 
($fz = function (path, playListDirectory, uri, values) {
var reader = null;
try {
var f =  new java.io.File (path);
if (f.exists ()) {
reader =  new java.io.BufferedReader ( new java.io.InputStreamReader ( new java.io.FileInputStream (f)), 8192);
var line = reader.readLine ();
var index = 0;
while (line != null) {
if (line.startsWith ("File")) {
var equals = line.indexOf ('=');
if (equals > 0) {
values.clear ();
if (this.addPlayListEntry (line.substring (equals + 1), playListDirectory, uri, values, index)) index++;
}}line = reader.readLine ();
}
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
android.util.Log.e ("MediaScanner", "IOException in MediaScanner.processPlsPlayList()", e);
} else {
throw e;
}
} finally {
try {
if (reader != null) reader.close ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
android.util.Log.e ("MediaScanner", "IOException in MediaScanner.processPlsPlayList()", e);
} else {
throw e;
}
}
}
}, $fz.isPrivate = true, $fz), "~S,~S,android.net.Uri,android.content.ContentValues");
Clazz.defineMethod (c$, "processWplPlayList", 
($fz = function (path, playListDirectory, uri) {
}, $fz.isPrivate = true, $fz), "~S,~S,android.net.Uri");
Clazz.defineMethod (c$, "processPlayLists", 
($fz = function () {
var iterator = this.mPlayLists.iterator ();
while (iterator.hasNext ()) {
var entry = iterator.next ();
var path = entry.mPath;
if (entry.mLastModifiedChanged) {
var values =  new android.content.ContentValues ();
var lastSlash = path.lastIndexOf ('/');
if (lastSlash < 0) throw  new IllegalArgumentException ("bad path " + path);
var uri;
var membersUri;
var rowId = entry.mRowId;
if (rowId == 0) {
var lastDot = path.lastIndexOf ('.');
var name = (lastDot < 0 ? path.substring (lastSlash + 1) : path.substring (lastSlash + 1, lastDot));
values.put ("name", name);
values.put ("_data", path);
values.put ("date_modified", new Long (entry.mLastModified));
uri = this.mMediaProvider.insert (this.mPlaylistsUri, values);
rowId = android.content.ContentUris.parseId (uri);
membersUri = android.net.Uri.withAppendedPath (uri, "members");
} else {
uri = android.content.ContentUris.withAppendedId (this.mPlaylistsUri, rowId);
values.put ("date_modified", new Long (entry.mLastModified));
this.mMediaProvider.update (uri, values, null, null);
membersUri = android.net.Uri.withAppendedPath (uri, "members");
this.mMediaProvider.$delete (membersUri, null, null);
}var playListDirectory = path.substring (0, lastSlash + 1);
var mediaFileType = android.media.MediaFile.getFileType (path);
var fileType = (mediaFileType == null ? 0 : mediaFileType.fileType);
if (fileType == 41) this.processM3uPlayList (path, playListDirectory, membersUri, values);
 else if (fileType == 42) this.processPlsPlayList (path, playListDirectory, membersUri, values);
 else if (fileType == 43) this.processWplPlayList (path, playListDirectory, membersUri);
var cursor = this.mMediaProvider.query (membersUri, android.media.MediaScanner.PLAYLIST_MEMBERS_PROJECTION, null, null, null);
try {
if (cursor == null || cursor.getCount () == 0) {
android.util.Log.d ("MediaScanner", "playlist is empty - deleting");
this.mMediaProvider.$delete (uri, null, null);
}} finally {
if (cursor != null) cursor.close ();
}
}}
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "finalize", 
function () {
this.mContext.getContentResolver ().releaseProvider (this.mMediaProvider);
this.native_finalize ();
});
c$.$MediaScanner$MyMediaScannerClient$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mArtist = null;
this.mAlbumArtist = null;
this.mAlbum = null;
this.mTitle = null;
this.mComposer = null;
this.mGenre = null;
this.mMimeType = null;
this.mFileType = 0;
this.mTrack = 0;
this.mYear = 0;
this.mDuration = 0;
this.mPath = null;
this.mLastModified = 0;
this.mFileSize = 0;
this.mWriter = null;
this.mCompilation = 0;
Clazz.instantialize (this, arguments);
}, android.media.MediaScanner, "MyMediaScannerClient", null, android.media.MediaScannerClient);
Clazz.defineMethod (c$, "beginFile", 
function (a, b, c, d) {
var e = a.lastIndexOf ('/');
if (e >= 0 && e + 2 < a.length) {
if (a.regionMatches (e + 1, "._", 0, 2)) {
return null;
}if (a.regionMatches (true, a.length - 4, ".jpg", 0, 4)) {
if (a.regionMatches (true, e + 1, "AlbumArt_{", 0, 10) || a.regionMatches (true, e + 1, "AlbumArt.", 0, 9)) {
return null;
}var f = a.length - e - 1;
if ((f == 17 && a.regionMatches (true, e + 1, "AlbumArtSmall", 0, 13)) || (f == 10 && a.regionMatches (true, e + 1, "Folder", 0, 6))) {
return null;
}}}this.mMimeType = null;
if (b != null) {
this.mFileType = android.media.MediaFile.getFileTypeForMimeType (b);
if (this.mFileType != 0) {
this.mMimeType = b;
}}this.mFileSize = d;
if (this.mMimeType == null) {
var f = android.media.MediaFile.getFileType (a);
if (f != null) {
this.mFileType = f.fileType;
this.mMimeType = f.mimeType;
}}var f = a;
if (this.b$["android.media.MediaScanner"].mCaseInsensitivePaths) {
f = a.toLowerCase ();
}var g = this.b$["android.media.MediaScanner"].mFileCache.get (f);
if (g == null) {
g =  new android.media.MediaScanner.FileCacheEntry (null, 0, a, 0);
this.b$["android.media.MediaScanner"].mFileCache.put (f, g);
}g.mSeenInFileSystem = true;
var h = c - g.mLastModified;
if (h > 1 || h < -1) {
g.mLastModified = c;
g.mLastModifiedChanged = true;
}if (this.b$["android.media.MediaScanner"].mProcessPlaylists && android.media.MediaFile.isPlayListFileType (this.mFileType)) {
this.b$["android.media.MediaScanner"].mPlayLists.add (g);
return null;
}this.mArtist = null;
this.mAlbumArtist = null;
this.mAlbum = null;
this.mTitle = null;
this.mComposer = null;
this.mGenre = null;
this.mTrack = 0;
this.mYear = 0;
this.mDuration = 0;
this.mPath = a;
this.mLastModified = c;
this.mWriter = null;
this.mCompilation = 0;
return g;
}, "~S,~S,~N,~N");
Clazz.defineMethod (c$, "scanFile", 
function (a, b, c) {
this.doScanFile (a, null, b, c, false);
}, "~S,~N,~N");
Clazz.defineMethod (c$, "scanFile", 
function (a, b, c, d) {
this.doScanFile (a, b, c, d, false);
}, "~S,~S,~N,~N");
Clazz.defineMethod (c$, "doScanFile", 
function (a, b, c, d, e) {
var f = null;
try {
var g = this.beginFile (a, b, c, d);
if (g != null && (g.mLastModifiedChanged || e)) {
var h = a.toLowerCase ();
var i = (h.indexOf ("/ringtones/") > 0);
var j = (h.indexOf ("/notifications/") > 0);
var k = (h.indexOf ("/alarms/") > 0);
var l = (h.indexOf ("/podcasts/") > 0);
var m = (h.indexOf ("/music/") > 0) || (!i && !j && !k && !l);
if (!android.media.MediaFile.isImageFileType (this.mFileType)) {
this.b$["android.media.MediaScanner"].processFile (a, b, this);
}f = this.endFile (g, i, j, k, m, l);
}} catch (e) {
if (Clazz.instanceOf (e, android.os.RemoteException)) {
android.util.Log.e ("MediaScanner", "RemoteException in MediaScanner.scanFile()", e);
} else {
throw e;
}
}
return f;
}, "~S,~S,~N,~N,~B");
Clazz.defineMethod (c$, "parseSubstring", 
($fz = function (a, b, c) {
var d = a.length;
if (b == d) return c;
var e = a.charAt (b++);
if ((e).charCodeAt (0) < ('0').charCodeAt (0) || (e).charCodeAt (0) > ('9').charCodeAt (0)) return c;
var f = (e).charCodeAt (0) - ('0').charCodeAt (0);
while (b < d) {
e = a.charAt (b++);
if ((e).charCodeAt (0) < ('0').charCodeAt (0) || (e).charCodeAt (0) > ('9').charCodeAt (0)) return f;
f = f * 10 + ((e).charCodeAt (0) - ('0').charCodeAt (0));
}
return f;
}, $fz.isPrivate = true, $fz), "~S,~N,~N");
Clazz.overrideMethod (c$, "handleStringTag", 
function (a, b) {
if (a.equalsIgnoreCase ("title") || a.startsWith ("title;")) {
this.mTitle = b;
} else if (a.equalsIgnoreCase ("artist") || a.startsWith ("artist;")) {
this.mArtist = b.trim ();
} else if (a.equalsIgnoreCase ("albumartist") || a.startsWith ("albumartist;")) {
this.mAlbumArtist = b.trim ();
} else if (a.equalsIgnoreCase ("album") || a.startsWith ("album;")) {
this.mAlbum = b.trim ();
} else if (a.equalsIgnoreCase ("composer") || a.startsWith ("composer;")) {
this.mComposer = b.trim ();
} else if (a.equalsIgnoreCase ("genre") || a.startsWith ("genre;")) {
if (b.length > 0) {
var c = -1;
var d = b.charAt (0);
if ((d).charCodeAt (0) == ('(').charCodeAt (0)) {
c = this.parseSubstring (b, 1, -1);
} else if ((d).charCodeAt (0) >= ('0').charCodeAt (0) && (d).charCodeAt (0) <= ('9').charCodeAt (0)) {
c = this.parseSubstring (b, 0, -1);
}if (c >= 0 && c < android.media.MediaScanner.ID3_GENRES.length) {
b = android.media.MediaScanner.ID3_GENRES[c];
} else if (c == 255) {
b = null;
}}this.mGenre = b;
} else if (a.equalsIgnoreCase ("year") || a.startsWith ("year;")) {
this.mYear = this.parseSubstring (b, 0, 0);
} else if (a.equalsIgnoreCase ("tracknumber") || a.startsWith ("tracknumber;")) {
var c = this.parseSubstring (b, 0, 0);
this.mTrack = (Math.floor (this.mTrack / 1000)) * 1000 + c;
} else if (a.equalsIgnoreCase ("discnumber") || a.equals ("set") || a.startsWith ("set;")) {
var c = this.parseSubstring (b, 0, 0);
this.mTrack = (c * 1000) + (this.mTrack % 1000);
} else if (a.equalsIgnoreCase ("duration")) {
this.mDuration = this.parseSubstring (b, 0, 0);
} else if (a.equalsIgnoreCase ("writer") || a.startsWith ("writer;")) {
this.mWriter = b.trim ();
} else if (a.equalsIgnoreCase ("compilation")) {
this.mCompilation = this.parseSubstring (b, 0, 0);
}}, "~S,~S");
Clazz.overrideMethod (c$, "setMimeType", 
function (a) {
if ("audio/mp4".equals (this.mMimeType) && a.startsWith ("video")) {
return ;
}this.mMimeType = a;
this.mFileType = android.media.MediaFile.getFileTypeForMimeType (a);
}, "~S");
Clazz.defineMethod (c$, "toValues", 
($fz = function () {
var a =  new android.content.ContentValues ();
a.put ("_data", this.mPath);
a.put ("title", this.mTitle);
a.put ("date_modified", new Long (this.mLastModified));
a.put ("_size", new Long (this.mFileSize));
a.put ("mime_type", this.mMimeType);
if (android.media.MediaFile.isVideoFileType (this.mFileType)) {
a.put ("artist", (this.mArtist != null && this.mArtist.length > 0 ? this.mArtist : "<unknown>"));
a.put ("album", (this.mAlbum != null && this.mAlbum.length > 0 ? this.mAlbum : "<unknown>"));
a.put ("duration", new Integer (this.mDuration));
} else if (android.media.MediaFile.isImageFileType (this.mFileType)) {
} else if (android.media.MediaFile.isAudioFileType (this.mFileType)) {
a.put ("artist", (this.mArtist != null && this.mArtist.length > 0) ? this.mArtist : "<unknown>");
a.put ("album_artist", (this.mAlbumArtist != null && this.mAlbumArtist.length > 0) ? this.mAlbumArtist : null);
a.put ("album", (this.mAlbum != null && this.mAlbum.length > 0) ? this.mAlbum : "<unknown>");
a.put ("composer", this.mComposer);
if (this.mYear != 0) {
a.put ("year", new Integer (this.mYear));
}a.put ("track", new Integer (this.mTrack));
a.put ("duration", new Integer (this.mDuration));
a.put ("compilation", new Integer (this.mCompilation));
}return a;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "endFile", 
($fz = function (a, b, c, d, e, f) {
var g;
var h = android.media.MediaFile.isAudioFileType (this.mFileType);
var i = android.media.MediaFile.isVideoFileType (this.mFileType);
var j = android.media.MediaFile.isImageFileType (this.mFileType);
if (i) {
g = this.b$["android.media.MediaScanner"].mVideoUri;
} else if (j) {
g = this.b$["android.media.MediaScanner"].mImagesUri;
} else if (h) {
g = this.b$["android.media.MediaScanner"].mAudioUri;
} else {
return null;
}a.mTableUri = g;
if (this.mArtist == null || this.mArtist.length == 0) {
this.mArtist = this.mAlbumArtist;
}var k = this.toValues ();
var l = k.getAsString ("title");
if (l == null || android.text.TextUtils.isEmpty (l.trim ())) {
l = k.getAsString ("_data");
var m = l.lastIndexOf ('/');
if (m >= 0) {
m++;
if (m < l.length) {
l = l.substring (m);
}}var n = l.lastIndexOf ('.');
if (n > 0) {
l = l.substring (0, n);
}k.put ("title", l);
}var m = k.getAsString ("album");
if ("<unknown>".equals (m)) {
m = k.getAsString ("_data");
var n = m.lastIndexOf ('/');
if (n >= 0) {
var o = 0;
while (true) {
var p = m.indexOf ('/', o + 1);
if (p < 0 || p >= n) {
break;
}o = p;
}
if (o != 0) {
m = m.substring (o + 1, n);
k.put ("album", m);
}}}var n = a.mRowId;
if (h && n == 0) {
k.put ("is_ringtone", new Boolean (b));
k.put ("is_notification", new Boolean (c));
k.put ("is_alarm", new Boolean (d));
k.put ("is_music", new Boolean (e));
k.put ("is_podcast", new Boolean (f));
} else if (this.mFileType == 31) {
var o = null;
try {
o =  new android.media.ExifInterface (a.mPath);
} catch (ex) {
if (Clazz.instanceOf (ex, java.io.IOException)) {
} else {
throw ex;
}
}
if (o != null) {
var p =  Clazz.newArray (2, 0);
if (o.getLatLong (p)) {
k.put ("latitude", new Float (p[0]));
k.put ("longitude", new Float (p[1]));
}var q = o.getGpsDateTime ();
if (q != -1) {
k.put ("datetaken", new Long (q));
}var r = o.getAttributeInt ("Orientation", -1);
if (r != -1) {
var s;
switch (r) {
case 6:
s = 90;
break;
case 3:
s = 180;
break;
case 8:
s = 270;
break;
default:
s = 0;
break;
}
k.put ("orientation", new Integer (s));
}}}var o = null;
if (n == 0) {
o = this.b$["android.media.MediaScanner"].mMediaProvider.insert (g, k);
if (o != null) {
n = android.content.ContentUris.parseId (o);
a.mRowId = n;
}} else {
o = android.content.ContentUris.withAppendedId (g, n);
this.b$["android.media.MediaScanner"].mMediaProvider.update (o, k, null, null);
}if (this.b$["android.media.MediaScanner"].mProcessGenres && this.mGenre != null) {
var p = this.mGenre;
var q = this.b$["android.media.MediaScanner"].mGenreCache.get (p);
if (q == null) {
var r = null;
try {
r = this.b$["android.media.MediaScanner"].mMediaProvider.query (this.b$["android.media.MediaScanner"].mGenresUri, android.media.MediaScanner.GENRE_LOOKUP_PROJECTION, "name=?", [p], null);
if (r == null || r.getCount () == 0) {
k.clear ();
k.put ("name", p);
q = this.b$["android.media.MediaScanner"].mMediaProvider.insert (this.b$["android.media.MediaScanner"].mGenresUri, k);
} else {
r.moveToNext ();
q = android.content.ContentUris.withAppendedId (this.b$["android.media.MediaScanner"].mGenresUri, r.getLong (0));
}if (q != null) {
q = android.net.Uri.withAppendedPath (q, "members");
this.b$["android.media.MediaScanner"].mGenreCache.put (p, q);
}} finally {
if (r != null) {
r.close ();
}}
}if (q != null) {
k.clear ();
k.put ("audio_id", Long.$valueOf (n));
this.b$["android.media.MediaScanner"].mMediaProvider.insert (q, k);
}}if (c && !this.b$["android.media.MediaScanner"].mDefaultNotificationSet) {
if (android.text.TextUtils.isEmpty (this.b$["android.media.MediaScanner"].mDefaultNotificationFilename) || this.doesPathHaveFilename (a.mPath, this.b$["android.media.MediaScanner"].mDefaultNotificationFilename)) {
this.setSettingIfNotSet ("notification_sound", g, n);
this.b$["android.media.MediaScanner"].mDefaultNotificationSet = true;
}} else if (b && !this.b$["android.media.MediaScanner"].mDefaultRingtoneSet) {
if (android.text.TextUtils.isEmpty (this.b$["android.media.MediaScanner"].mDefaultRingtoneFilename) || this.doesPathHaveFilename (a.mPath, this.b$["android.media.MediaScanner"].mDefaultRingtoneFilename)) {
this.setSettingIfNotSet ("ringtone", g, n);
this.b$["android.media.MediaScanner"].mDefaultRingtoneSet = true;
}} else if (d && !this.b$["android.media.MediaScanner"].mDefaultAlarmSet) {
if (android.text.TextUtils.isEmpty (this.b$["android.media.MediaScanner"].mDefaultAlarmAlertFilename) || this.doesPathHaveFilename (a.mPath, this.b$["android.media.MediaScanner"].mDefaultAlarmAlertFilename)) {
this.setSettingIfNotSet ("alarm_alert", g, n);
this.b$["android.media.MediaScanner"].mDefaultAlarmSet = true;
}}return o;
}, $fz.isPrivate = true, $fz), "android.media.MediaScanner.FileCacheEntry,~B,~B,~B,~B,~B");
Clazz.defineMethod (c$, "doesPathHaveFilename", 
($fz = function (a, b) {
var c = a.lastIndexOf (java.io.File.separatorChar) + 1;
var d = b.length;
return a.regionMatches (c, b, 0, d) && c + d == a.length;
}, $fz.isPrivate = true, $fz), "~S,~S");
Clazz.defineMethod (c$, "setSettingIfNotSet", 
($fz = function (a, b, c) {
var d = android.provider.Settings.System.getString (this.b$["android.media.MediaScanner"].mContext.getContentResolver (), a);
if (android.text.TextUtils.isEmpty (d)) {
android.provider.Settings.System.putString (this.b$["android.media.MediaScanner"].mContext.getContentResolver (), a, android.content.ContentUris.withAppendedId (b, c).toString ());
}}, $fz.isPrivate = true, $fz), "~S,android.net.Uri,~N");
Clazz.overrideMethod (c$, "addNoMediaFolder", 
function (a) {
var b =  new android.content.ContentValues ();
b.put ("_data", "");
var c = [a + '%'];
this.b$["android.media.MediaScanner"].mMediaProvider.update (android.provider.MediaStore.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, b, "_data LIKE ?", c);
this.b$["android.media.MediaScanner"].mMediaProvider.update (android.provider.MediaStore.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, b, "_data LIKE ?", c);
}, "~S");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mTableUri = null;
this.mRowId = 0;
this.mPath = null;
this.mLastModified = 0;
this.mSeenInFileSystem = false;
this.mLastModifiedChanged = false;
Clazz.instantialize (this, arguments);
}, android.media.MediaScanner, "FileCacheEntry");
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
this.mTableUri = a;
this.mRowId = b;
this.mPath = c;
this.mLastModified = d;
this.mSeenInFileSystem = false;
this.mLastModifiedChanged = false;
}, "android.net.Uri,~N,~S,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return this.mPath;
});
c$ = Clazz.p0p ();
{
System.loadLibrary ("media_jni");
android.media.MediaScanner.native_init ();
}Clazz.defineStatics (c$,
"TAG", "MediaScanner");
c$.AUDIO_PROJECTION = c$.prototype.AUDIO_PROJECTION = ["_id", "_data", "date_modified"];
Clazz.defineStatics (c$,
"ID_AUDIO_COLUMN_INDEX", 0,
"PATH_AUDIO_COLUMN_INDEX", 1,
"DATE_MODIFIED_AUDIO_COLUMN_INDEX", 2);
c$.VIDEO_PROJECTION = c$.prototype.VIDEO_PROJECTION = ["_id", "_data", "date_modified"];
Clazz.defineStatics (c$,
"ID_VIDEO_COLUMN_INDEX", 0,
"PATH_VIDEO_COLUMN_INDEX", 1,
"DATE_MODIFIED_VIDEO_COLUMN_INDEX", 2);
c$.IMAGES_PROJECTION = c$.prototype.IMAGES_PROJECTION = ["_id", "_data", "date_modified"];
Clazz.defineStatics (c$,
"ID_IMAGES_COLUMN_INDEX", 0,
"PATH_IMAGES_COLUMN_INDEX", 1,
"DATE_MODIFIED_IMAGES_COLUMN_INDEX", 2);
c$.PLAYLISTS_PROJECTION = c$.prototype.PLAYLISTS_PROJECTION = ["_id", "_data", "date_modified"];
c$.PLAYLIST_MEMBERS_PROJECTION = c$.prototype.PLAYLIST_MEMBERS_PROJECTION = ["playlist_id"];
Clazz.defineStatics (c$,
"ID_PLAYLISTS_COLUMN_INDEX", 0,
"PATH_PLAYLISTS_COLUMN_INDEX", 1,
"DATE_MODIFIED_PLAYLISTS_COLUMN_INDEX", 2);
c$.GENRE_LOOKUP_PROJECTION = c$.prototype.GENRE_LOOKUP_PROJECTION = ["_id", "name"];
Clazz.defineStatics (c$,
"RINGTONES_DIR", "/ringtones/",
"NOTIFICATIONS_DIR", "/notifications/",
"ALARMS_DIR", "/alarms/",
"MUSIC_DIR", "/music/",
"PODCAST_DIR", "/podcasts/",
"ID3_GENRES", ["Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial", "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise", "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes", "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk", "Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle", "Duet", "Punk Rock", "Drum Solo", "A capella", "Euro-House", "Dance Hall"],
"DEFAULT_RINGTONE_PROPERTY_PREFIX", "ro.config.");
});
