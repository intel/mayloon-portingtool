﻿Clazz.declarePackage ("android.media");
Clazz.load (null, "android.media.ThumbnailUtils", ["android.graphics.Bitmap", "$.BitmapFactory", "$.Canvas", "$.Matrix", "$.Rect", "android.media.ExifInterface", "$.MediaFile", "$.MediaMetadataRetriever", "android.util.Log", "java.io.FileInputStream"], function () {
c$ = Clazz.declareType (android.media, "ThumbnailUtils");
c$.createImageThumbnail = Clazz.defineMethod (c$, "createImageThumbnail", 
function (filePath, kind) {
var wantMini = (kind == 1);
var targetSize = wantMini ? 320 : 96;
var maxPixels = wantMini ? 196608 : 16384;
var sizedThumbnailBitmap =  new android.media.ThumbnailUtils.SizedThumbnailBitmap ();
var bitmap = null;
var fileType = android.media.MediaFile.getFileType (filePath);
if (fileType != null && fileType.fileType == 31) {
android.media.ThumbnailUtils.createThumbnailFromEXIF (filePath, targetSize, maxPixels, sizedThumbnailBitmap);
bitmap = sizedThumbnailBitmap.mBitmap;
}if (bitmap == null) {
try {
var fd =  new java.io.FileInputStream (filePath).getFD ();
var options =  new android.graphics.BitmapFactory.Options ();
options.inSampleSize = 1;
options.inJustDecodeBounds = true;
android.graphics.BitmapFactory.decodeFileDescriptor (fd, null, options);
if (options.mCancel || options.outWidth == -1 || options.outHeight == -1) {
return null;
}options.inSampleSize = android.media.ThumbnailUtils.computeSampleSize (options, targetSize, maxPixels);
options.inJustDecodeBounds = false;
options.inDither = false;
options.inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888;
bitmap = android.graphics.BitmapFactory.decodeFileDescriptor (fd, null, options);
} catch (e$$) {
if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
android.util.Log.e ("ThumbnailUtils", "", ex);
}
} else if (Clazz.instanceOf (e$$, OutOfMemoryError)) {
var oom = e$$;
{
android.util.Log.e ("ThumbnailUtils", "Unable to decode file " + filePath + ". OutOfMemoryError.", oom);
}
} else {
throw e$$;
}
}
}if (kind == 3) {
bitmap = android.media.ThumbnailUtils.extractThumbnail (bitmap, 96, 96, 2);
}return bitmap;
}, "~S,~N");
c$.createVideoThumbnail = Clazz.defineMethod (c$, "createVideoThumbnail", 
function (filePath, kind) {
var bitmap = null;
var retriever =  new android.media.MediaMetadataRetriever ();
try {
retriever.setDataSource (filePath);
bitmap = retriever.getFrameAtTime (-1);
} catch (e$$) {
if (Clazz.instanceOf (e$$, IllegalArgumentException)) {
var ex = e$$;
{
}
} else if (Clazz.instanceOf (e$$, RuntimeException)) {
var ex = e$$;
{
}
} else {
throw e$$;
}
} finally {
try {
retriever.release ();
} catch (ex) {
if (Clazz.instanceOf (ex, RuntimeException)) {
} else {
throw ex;
}
}
}
if (kind == 3 && bitmap != null) {
bitmap = android.media.ThumbnailUtils.extractThumbnail (bitmap, 96, 96, 2);
}return bitmap;
}, "~S,~N");
c$.extractThumbnail = Clazz.defineMethod (c$, "extractThumbnail", 
function (source, width, height) {
return android.media.ThumbnailUtils.extractThumbnail (source, width, height, 0);
}, "android.graphics.Bitmap,~N,~N");
c$.extractThumbnail = Clazz.defineMethod (c$, "extractThumbnail", 
function (source, width, height, options) {
if (source == null) {
return null;
}var scale;
if (source.getWidth () < source.getHeight ()) {
scale = width / source.getWidth ();
} else {
scale = height / source.getHeight ();
}var matrix =  new android.graphics.Matrix ();
matrix.setScale (scale, scale);
var thumbnail = android.media.ThumbnailUtils.transform (matrix, source, width, height, 1 | options);
return thumbnail;
}, "android.graphics.Bitmap,~N,~N,~N");
c$.computeSampleSize = Clazz.defineMethod (c$, "computeSampleSize", 
($fz = function (options, minSideLength, maxNumOfPixels) {
var initialSize = android.media.ThumbnailUtils.computeInitialSampleSize (options, minSideLength, maxNumOfPixels);
var roundedSize;
if (initialSize <= 8) {
roundedSize = 1;
while (roundedSize < initialSize) {
roundedSize <<= 1;
}
} else {
roundedSize = Math.floor ((initialSize + 7) / 8) * 8;
}return roundedSize;
}, $fz.isPrivate = true, $fz), "android.graphics.BitmapFactory.Options,~N,~N");
c$.computeInitialSampleSize = Clazz.defineMethod (c$, "computeInitialSampleSize", 
($fz = function (options, minSideLength, maxNumOfPixels) {
var w = options.outWidth;
var h = options.outHeight;
var lowerBound = (maxNumOfPixels == -1) ? 1 : Math.round (Math.ceil (Math.sqrt (w * h / maxNumOfPixels)));
var upperBound = (minSideLength == -1) ? 128 : Math.round (Math.min (Math.floor (w / minSideLength), Math.floor (h / minSideLength)));
if (upperBound < lowerBound) {
return lowerBound;
}if ((maxNumOfPixels == -1) && (minSideLength == -1)) {
return 1;
} else if (minSideLength == -1) {
return lowerBound;
} else {
return upperBound;
}}, $fz.isPrivate = true, $fz), "android.graphics.BitmapFactory.Options,~N,~N");
c$.closeSilently = Clazz.defineMethod (c$, "closeSilently", 
($fz = function (c) {
if (c == null) return ;
try {
c.close ();
} catch (t) {
}
}, $fz.isPrivate = true, $fz), "android.os.ParcelFileDescriptor");
c$.makeInputStream = Clazz.defineMethod (c$, "makeInputStream", 
($fz = function (uri, cr) {
try {
return cr.openFileDescriptor (uri, "r");
} catch (ex) {
if (Clazz.instanceOf (ex, java.io.IOException)) {
return null;
} else {
throw ex;
}
}
}, $fz.isPrivate = true, $fz), "android.net.Uri,android.content.ContentResolver");
c$.transform = Clazz.defineMethod (c$, "transform", 
($fz = function (scaler, source, targetWidth, targetHeight, options) {
var scaleUp = (options & 1) != 0;
var recycle = (options & 2) != 0;
var deltaX = source.getWidth () - targetWidth;
var deltaY = source.getHeight () - targetHeight;
if (!scaleUp && (deltaX < 0 || deltaY < 0)) {
var b2 = android.graphics.Bitmap.createBitmap (targetWidth, targetHeight, android.graphics.Bitmap.Bitmap.Config.ARGB_8888);
var c =  new android.graphics.Canvas (b2);
var deltaXHalf = Math.max (0, Math.floor (deltaX / 2));
var deltaYHalf = Math.max (0, Math.floor (deltaY / 2));
var src =  new android.graphics.Rect (deltaXHalf, deltaYHalf, deltaXHalf + Math.min (targetWidth, source.getWidth ()), deltaYHalf + Math.min (targetHeight, source.getHeight ()));
var dstX = Math.floor ((targetWidth - src.width ()) / 2);
var dstY = Math.floor ((targetHeight - src.height ()) / 2);
var dst =  new android.graphics.Rect (dstX, dstY, targetWidth - dstX, targetHeight - dstY);
c.drawBitmap (source, src, dst, null);
if (recycle) {
source.recycle ();
}return b2;
}var bitmapWidthF = source.getWidth ();
var bitmapHeightF = source.getHeight ();
var bitmapAspect = bitmapWidthF / bitmapHeightF;
var viewAspect = targetWidth / targetHeight;
if (bitmapAspect > viewAspect) {
var scale = targetHeight / bitmapHeightF;
if (scale < .9 || scale > 1) {
scaler.setScale (scale, scale);
} else {
scaler = null;
}} else {
var scale = targetWidth / bitmapWidthF;
if (scale < .9 || scale > 1) {
scaler.setScale (scale, scale);
} else {
scaler = null;
}}var b1;
if (scaler != null) {
b1 = android.graphics.Bitmap.createBitmap (source, 0, 0, source.getWidth (), source.getHeight (), scaler, true);
} else {
b1 = source;
}if (recycle && b1 !== source) {
source.recycle ();
}var dx1 = Math.max (0, b1.getWidth () - targetWidth);
var dy1 = Math.max (0, b1.getHeight () - targetHeight);
var b2 = android.graphics.Bitmap.createBitmap (b1, Math.floor (dx1 / 2), Math.floor (dy1 / 2), targetWidth, targetHeight);
if (b2 !== b1) {
if (recycle || b1 !== source) {
b1.recycle ();
}}return b2;
}, $fz.isPrivate = true, $fz), "android.graphics.Matrix,android.graphics.Bitmap,~N,~N,~N");
c$.createThumbnailFromEXIF = Clazz.defineMethod (c$, "createThumbnailFromEXIF", 
($fz = function (filePath, targetSize, maxPixels, sizedThumbBitmap) {
if (filePath == null) return ;
var exif = null;
var thumbData = null;
try {
exif =  new android.media.ExifInterface (filePath);
if (exif != null) {
thumbData = exif.getThumbnail ();
}} catch (ex) {
if (Clazz.instanceOf (ex, java.io.IOException)) {
android.util.Log.w ("ThumbnailUtils", ex);
} else {
throw ex;
}
}
var fullOptions =  new android.graphics.BitmapFactory.Options ();
var exifOptions =  new android.graphics.BitmapFactory.Options ();
var exifThumbWidth = 0;
var fullThumbWidth = 0;
if (thumbData != null) {
exifOptions.inJustDecodeBounds = true;
android.graphics.BitmapFactory.decodeByteArray (thumbData, 0, thumbData.length, exifOptions);
exifOptions.inSampleSize = android.media.ThumbnailUtils.computeSampleSize (exifOptions, targetSize, maxPixels);
exifThumbWidth = Math.floor (exifOptions.outWidth / exifOptions.inSampleSize);
}fullOptions.inJustDecodeBounds = true;
android.graphics.BitmapFactory.decodeFile (filePath, fullOptions);
fullOptions.inSampleSize = android.media.ThumbnailUtils.computeSampleSize (fullOptions, targetSize, maxPixels);
fullThumbWidth = Math.floor (fullOptions.outWidth / fullOptions.inSampleSize);
if (thumbData != null && exifThumbWidth >= fullThumbWidth) {
var width = exifOptions.outWidth;
var height = exifOptions.outHeight;
exifOptions.inJustDecodeBounds = false;
sizedThumbBitmap.mBitmap = android.graphics.BitmapFactory.decodeByteArray (thumbData, 0, thumbData.length, exifOptions);
if (sizedThumbBitmap.mBitmap != null) {
sizedThumbBitmap.mThumbnailData = thumbData;
sizedThumbBitmap.mThumbnailWidth = width;
sizedThumbBitmap.mThumbnailHeight = height;
}} else {
fullOptions.inJustDecodeBounds = false;
sizedThumbBitmap.mBitmap = android.graphics.BitmapFactory.decodeFile (filePath, fullOptions);
}}, $fz.isPrivate = true, $fz), "~S,~N,~N,android.media.ThumbnailUtils.SizedThumbnailBitmap");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mThumbnailData = null;
this.mBitmap = null;
this.mThumbnailWidth = 0;
this.mThumbnailHeight = 0;
Clazz.instantialize (this, arguments);
}, android.media.ThumbnailUtils, "SizedThumbnailBitmap");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "ThumbnailUtils",
"MAX_NUM_PIXELS_THUMBNAIL", 196608,
"MAX_NUM_PIXELS_MICRO_THUMBNAIL", 16384,
"UNCONSTRAINED", -1,
"OPTIONS_NONE", 0x0,
"OPTIONS_SCALE_UP", 0x1,
"OPTIONS_RECYCLE_INPUT", 0x2,
"TARGET_SIZE_MINI_THUMBNAIL", 320,
"TARGET_SIZE_MICRO_THUMBNAIL", 96);
});
