﻿Clazz.declarePackage ("android.media");
Clazz.load (["java.util.HashMap"], "android.media.MediaFile", ["android.media.DecoderCapabilities", "java.lang.StringBuilder"], function () {
c$ = Clazz.declareType (android.media, "MediaFile");
c$.addFileType = Clazz.defineMethod (c$, "addFileType", 
function (extension, fileType, mimeType) {
android.media.MediaFile.sFileTypeMap.put (extension,  new android.media.MediaFile.MediaFileType (fileType, mimeType));
android.media.MediaFile.sMimeTypeMap.put (mimeType, Integer.$valueOf (fileType));
}, "~S,~N,~S");
c$.isWMAEnabled = Clazz.defineMethod (c$, "isWMAEnabled", 
($fz = function () {
var decoders = android.media.DecoderCapabilities.getAudioDecoders ();
for (var decoder, $decoder = decoders.iterator (); $decoder.hasNext () && ((decoder = $decoder.next ()) || true);) {
if (decoder === android.media.DecoderCapabilities.AudioDecoder.AUDIO_DECODER_WMA) {
return true;
}}
return false;
}, $fz.isPrivate = true, $fz));
c$.isWMVEnabled = Clazz.defineMethod (c$, "isWMVEnabled", 
($fz = function () {
var decoders = android.media.DecoderCapabilities.getVideoDecoders ();
for (var decoder, $decoder = decoders.iterator (); $decoder.hasNext () && ((decoder = $decoder.next ()) || true);) {
if (decoder === android.media.DecoderCapabilities.VideoDecoder.VIDEO_DECODER_WMV) {
return true;
}}
return false;
}, $fz.isPrivate = true, $fz));
c$.isAudioFileType = Clazz.defineMethod (c$, "isAudioFileType", 
function (fileType) {
return ((fileType >= 1 && fileType <= 9) || (fileType >= 11 && fileType <= 13));
}, "~N");
c$.isVideoFileType = Clazz.defineMethod (c$, "isVideoFileType", 
function (fileType) {
return (fileType >= 21 && fileType <= 28);
}, "~N");
c$.isImageFileType = Clazz.defineMethod (c$, "isImageFileType", 
function (fileType) {
return (fileType >= 31 && fileType <= 35);
}, "~N");
c$.isPlayListFileType = Clazz.defineMethod (c$, "isPlayListFileType", 
function (fileType) {
return (fileType >= 41 && fileType <= 43);
}, "~N");
c$.getFileType = Clazz.defineMethod (c$, "getFileType", 
function (path) {
var lastDot = path.lastIndexOf (".");
if (lastDot < 0) return null;
return android.media.MediaFile.sFileTypeMap.get (path.substring (lastDot + 1).toUpperCase ());
}, "~S");
c$.getFileTypeForMimeType = Clazz.defineMethod (c$, "getFileTypeForMimeType", 
function (mimeType) {
var value = android.media.MediaFile.sMimeTypeMap.get (mimeType);
return (value == null ? 0 : value.intValue ());
}, "~S");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.fileType = 0;
this.mimeType = null;
Clazz.instantialize (this, arguments);
}, android.media.MediaFile, "MediaFileType");
Clazz.makeConstructor (c$, 
function (a, b) {
this.fileType = a;
this.mimeType = b;
}, "~N,~S");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"sFileExtensions", null,
"FILE_TYPE_MP3", 1,
"FILE_TYPE_M4A", 2,
"FILE_TYPE_WAV", 3,
"FILE_TYPE_AMR", 4,
"FILE_TYPE_AWB", 5,
"FILE_TYPE_WMA", 6,
"FILE_TYPE_OGG", 7,
"FILE_TYPE_AAC", 8,
"FILE_TYPE_MKA", 9,
"FIRST_AUDIO_FILE_TYPE", 1,
"LAST_AUDIO_FILE_TYPE", 9,
"FILE_TYPE_MID", 11,
"FILE_TYPE_SMF", 12,
"FILE_TYPE_IMY", 13,
"FIRST_MIDI_FILE_TYPE", 11,
"LAST_MIDI_FILE_TYPE", 13,
"FILE_TYPE_MP4", 21,
"FILE_TYPE_M4V", 22,
"FILE_TYPE_3GPP", 23,
"FILE_TYPE_3GPP2", 24,
"FILE_TYPE_WMV", 25,
"FILE_TYPE_ASF", 26,
"FILE_TYPE_MKV", 27,
"FILE_TYPE_MP2TS", 28,
"FIRST_VIDEO_FILE_TYPE", 21,
"LAST_VIDEO_FILE_TYPE", 28,
"FILE_TYPE_JPEG", 31,
"FILE_TYPE_GIF", 32,
"FILE_TYPE_PNG", 33,
"FILE_TYPE_BMP", 34,
"FILE_TYPE_WBMP", 35,
"FIRST_IMAGE_FILE_TYPE", 31,
"LAST_IMAGE_FILE_TYPE", 35,
"FILE_TYPE_M3U", 41,
"FILE_TYPE_PLS", 42,
"FILE_TYPE_WPL", 43,
"FIRST_PLAYLIST_FILE_TYPE", 41,
"LAST_PLAYLIST_FILE_TYPE", 43);
c$.sFileTypeMap = c$.prototype.sFileTypeMap =  new java.util.HashMap ();
c$.sMimeTypeMap = c$.prototype.sMimeTypeMap =  new java.util.HashMap ();
{
android.media.MediaFile.addFileType ("MP3", 1, "audio/mpeg");
android.media.MediaFile.addFileType ("M4A", 2, "audio/mp4");
android.media.MediaFile.addFileType ("WAV", 3, "audio/x-wav");
android.media.MediaFile.addFileType ("AMR", 4, "audio/amr");
android.media.MediaFile.addFileType ("AWB", 5, "audio/amr-wb");
if (android.media.MediaFile.isWMAEnabled ()) {
android.media.MediaFile.addFileType ("WMA", 6, "audio/x-ms-wma");
}android.media.MediaFile.addFileType ("OGG", 7, "application/ogg");
android.media.MediaFile.addFileType ("OGA", 7, "application/ogg");
android.media.MediaFile.addFileType ("AAC", 8, "audio/aac");
android.media.MediaFile.addFileType ("MKA", 9, "audio/x-matroska");
android.media.MediaFile.addFileType ("MID", 11, "audio/midi");
android.media.MediaFile.addFileType ("MIDI", 11, "audio/midi");
android.media.MediaFile.addFileType ("XMF", 11, "audio/midi");
android.media.MediaFile.addFileType ("RTTTL", 11, "audio/midi");
android.media.MediaFile.addFileType ("SMF", 12, "audio/sp-midi");
android.media.MediaFile.addFileType ("IMY", 13, "audio/imelody");
android.media.MediaFile.addFileType ("RTX", 11, "audio/midi");
android.media.MediaFile.addFileType ("OTA", 11, "audio/midi");
android.media.MediaFile.addFileType ("MPEG", 21, "video/mpeg");
android.media.MediaFile.addFileType ("MP4", 21, "video/mp4");
android.media.MediaFile.addFileType ("M4V", 22, "video/mp4");
android.media.MediaFile.addFileType ("3GP", 23, "video/3gpp");
android.media.MediaFile.addFileType ("3GPP", 23, "video/3gpp");
android.media.MediaFile.addFileType ("3G2", 24, "video/3gpp2");
android.media.MediaFile.addFileType ("3GPP2", 24, "video/3gpp2");
android.media.MediaFile.addFileType ("MKV", 27, "video/x-matroska");
android.media.MediaFile.addFileType ("WEBM", 27, "video/x-matroska");
android.media.MediaFile.addFileType ("TS", 28, "video/mp2ts");
if (android.media.MediaFile.isWMVEnabled ()) {
android.media.MediaFile.addFileType ("WMV", 25, "video/x-ms-wmv");
android.media.MediaFile.addFileType ("ASF", 26, "video/x-ms-asf");
}android.media.MediaFile.addFileType ("JPG", 31, "image/jpeg");
android.media.MediaFile.addFileType ("JPEG", 31, "image/jpeg");
android.media.MediaFile.addFileType ("GIF", 32, "image/gif");
android.media.MediaFile.addFileType ("PNG", 33, "image/png");
android.media.MediaFile.addFileType ("BMP", 34, "image/x-ms-bmp");
android.media.MediaFile.addFileType ("WBMP", 35, "image/vnd.wap.wbmp");
android.media.MediaFile.addFileType ("M3U", 41, "audio/x-mpegurl");
android.media.MediaFile.addFileType ("PLS", 42, "audio/x-scpls");
android.media.MediaFile.addFileType ("WPL", 43, "application/vnd.ms-wpl");
var builder =  new StringBuilder ();
var iterator = android.media.MediaFile.sFileTypeMap.keySet ().iterator ();
while (iterator.hasNext ()) {
if (builder.length () > 0) {
builder.append (',');
}builder.append (iterator.next ());
}
($t$ = android.media.MediaFile.sFileExtensions = builder.toString (), android.media.MediaFile.prototype.sFileExtensions = android.media.MediaFile.sFileExtensions, $t$);
}});
