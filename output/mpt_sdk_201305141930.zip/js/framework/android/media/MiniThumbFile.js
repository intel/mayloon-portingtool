﻿Clazz.declarePackage ("android.media");
Clazz.load (["java.util.Hashtable"], "android.media.MiniThumbFile", ["android.net.Uri", "android.os.Environment", "android.util.Log", "java.io.File", "$.RandomAccessFile", "java.nio.ByteBuffer"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mUri = null;
this.mMiniThumbFile = null;
this.mChannel = null;
this.mBuffer = null;
Clazz.instantialize (this, arguments);
}, android.media, "MiniThumbFile");
c$.reset = Clazz.defineMethod (c$, "reset", 
function () {
for (var file, $file = android.media.MiniThumbFile.sThumbFiles.values ().iterator (); $file.hasNext () && ((file = $file.next ()) || true);) {
file.deactivate ();
}
android.media.MiniThumbFile.sThumbFiles.clear ();
});
c$.instance = Clazz.defineMethod (c$, "instance", 
function (uri) {
var type = uri.getPathSegments ().get (1);
var file = android.media.MiniThumbFile.sThumbFiles.get (type);
if (file == null) {
file =  new android.media.MiniThumbFile (android.net.Uri.parse ("content://media/external/" + type + "/media"));
android.media.MiniThumbFile.sThumbFiles.put (type, file);
}return file;
}, "android.net.Uri");
Clazz.defineMethod (c$, "randomAccessFilePath", 
($fz = function (version) {
var directoryName = android.os.Environment.getExternalStorageDirectory ().toString () + "/DCIM/.thumbnails";
return directoryName + "/.thumbdata" + version + "-" + this.mUri.hashCode ();
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "removeOldFile", 
($fz = function () {
var oldPath = this.randomAccessFilePath (2);
var oldFile =  new java.io.File (oldPath);
if (oldFile.exists ()) {
try {
oldFile.$delete ();
} catch (ex) {
if (Clazz.instanceOf (ex, SecurityException)) {
} else {
throw ex;
}
}
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "miniThumbDataFile", 
($fz = function () {
if (this.mMiniThumbFile == null) {
this.removeOldFile ();
var path = this.randomAccessFilePath (3);
var directory =  new java.io.File (path).getParentFile ();
if (!directory.isDirectory ()) {
if (!directory.mkdirs ()) {
android.util.Log.e ("MiniThumbFile", "Unable to create .thumbnails directory " + directory.toString ());
}}var f =  new java.io.File (path);
try {
this.mMiniThumbFile =  new java.io.RandomAccessFile (f, "rw");
} catch (ex) {
if (Clazz.instanceOf (ex, java.io.IOException)) {
try {
this.mMiniThumbFile =  new java.io.RandomAccessFile (f, "r");
} catch (ex2) {
if (Clazz.instanceOf (ex2, java.io.IOException)) {
} else {
throw ex2;
}
}
} else {
throw ex;
}
}
if (this.mMiniThumbFile != null) {
this.mChannel = this.mMiniThumbFile.getChannel ();
}}return this.mMiniThumbFile;
}, $fz.isPrivate = true, $fz));
Clazz.makeConstructor (c$, 
function (uri) {
this.mUri = uri;
this.mBuffer = java.nio.ByteBuffer.allocateDirect (10000);
}, "android.net.Uri");
Clazz.defineMethod (c$, "deactivate", 
function () {
if (this.mMiniThumbFile != null) {
try {
this.mMiniThumbFile.close ();
this.mMiniThumbFile = null;
} catch (ex) {
if (Clazz.instanceOf (ex, java.io.IOException)) {
} else {
throw ex;
}
}
}});
Clazz.defineMethod (c$, "getMagic", 
function (id) {
var r = this.miniThumbDataFile ();
if (r != null) {
var pos = id * 10000;
var lock = null;
try {
this.mBuffer.clear ();
this.mBuffer.limit (9);
lock = this.mChannel.lock (pos, 9, true);
if (this.mChannel.read (this.mBuffer, pos) == 9) {
this.mBuffer.position (0);
if (this.mBuffer.get () == 1) {
return this.mBuffer.getLong ();
}}} catch (e$$) {
if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
android.util.Log.v ("MiniThumbFile", "Got exception checking file magic: ", ex);
}
} else if (Clazz.instanceOf (e$$, RuntimeException)) {
var ex = e$$;
{
android.util.Log.e ("MiniThumbFile", "Got exception when reading magic, id = " + id + ", disk full or mount read-only? " + ex.getClass ());
}
} else {
throw e$$;
}
} finally {
try {
if (lock != null) lock.release ();
} catch (ex) {
if (Clazz.instanceOf (ex, java.io.IOException)) {
} else {
throw ex;
}
}
}
}return 0;
}, "~N");
Clazz.defineMethod (c$, "saveMiniThumbToFile", 
function (data, id, magic) {
var r = this.miniThumbDataFile ();
if (r == null) return ;
var pos = id * 10000;
var lock = null;
try {
if (data != null) {
if (data.length > 9987) {
return ;
}this.mBuffer.clear ();
this.mBuffer.put (1);
this.mBuffer.putLong (magic);
this.mBuffer.putInt (data.length);
this.mBuffer.put (data);
this.mBuffer.flip ();
lock = this.mChannel.lock (pos, 10000, false);
this.mChannel.write (this.mBuffer, pos);
}} catch (e$$) {
if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
android.util.Log.e ("MiniThumbFile", "couldn't save mini thumbnail data for " + id + "; ", ex);
throw ex;
}
} else if (Clazz.instanceOf (e$$, RuntimeException)) {
var ex = e$$;
{
android.util.Log.e ("MiniThumbFile", "couldn't save mini thumbnail data for " + id + "; disk full or mount read-only? " + ex.getClass ());
}
} else {
throw e$$;
}
} finally {
try {
if (lock != null) lock.release ();
} catch (ex) {
if (Clazz.instanceOf (ex, java.io.IOException)) {
} else {
throw ex;
}
}
}
}, "~A,~N,~N");
Clazz.defineMethod (c$, "getMiniThumbFromFile", 
function (id, data) {
var r = this.miniThumbDataFile ();
if (r == null) return null;
var pos = id * 10000;
var lock = null;
try {
this.mBuffer.clear ();
lock = this.mChannel.lock (pos, 10000, true);
var size = this.mChannel.read (this.mBuffer, pos);
if (size > 13) {
this.mBuffer.position (0);
var flag = this.mBuffer.get ();
var magic = this.mBuffer.getLong ();
var length = this.mBuffer.getInt ();
if (size >= 1 + 8 + 4 + length && data.length >= length) {
this.mBuffer.get (data, 0, length);
return data;
}}} catch (e$$) {
if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
android.util.Log.w ("MiniThumbFile", "got exception when reading thumbnail id=" + id + ", exception: " + ex);
}
} else if (Clazz.instanceOf (e$$, RuntimeException)) {
var ex = e$$;
{
android.util.Log.e ("MiniThumbFile", "Got exception when reading thumbnail, id = " + id + ", disk full or mount read-only? " + ex.getClass ());
}
} else {
throw e$$;
}
} finally {
try {
if (lock != null) lock.release ();
} catch (ex) {
if (Clazz.instanceOf (ex, java.io.IOException)) {
} else {
throw ex;
}
}
}
return null;
}, "~N,~A");
Clazz.defineStatics (c$,
"TAG", "MiniThumbFile",
"MINI_THUMB_DATA_FILE_VERSION", 3,
"BYTES_PER_MINTHUMB", 10000,
"HEADER_SIZE", 13);
c$.sThumbFiles = c$.prototype.sThumbFiles =  new java.util.Hashtable ();
});
