﻿Clazz.declarePackage ("android.media");
c$ = Clazz.declareType (android.media, "AudioSystem");
c$.getNumStreamTypes = Clazz.defineMethod (c$, "getNumStreamTypes", 
function () {
return 10;
});
c$.setMode = Clazz.defineMethod (c$, "setMode", 
function (mode) {
return 1;
}, "~N");
c$.getMode = Clazz.defineMethod (c$, "getMode", 
function () {
return -2;
});
c$.setRouting = Clazz.defineMethod (c$, "setRouting", 
function (mode, routes, mask) {
return 1;
}, "~N,~N,~N");
c$.getRouting = Clazz.defineMethod (c$, "getRouting", 
function (mode) {
return 0;
}, "~N");
c$.setErrorCallback = Clazz.defineMethod (c$, "setErrorCallback", 
function (cb) {
($t$ = android.media.AudioSystem.mErrorCallback = cb, android.media.AudioSystem.prototype.mErrorCallback = android.media.AudioSystem.mErrorCallback, $t$);
}, "android.media.AudioSystem.ErrorCallback");
Clazz.declareInterface (android.media.AudioSystem, "ErrorCallback");
Clazz.defineStatics (c$,
"STREAM_VOICE_CALL", 0,
"STREAM_SYSTEM", 1,
"STREAM_RING", 2,
"STREAM_MUSIC", 3,
"STREAM_ALARM", 4,
"STREAM_NOTIFICATION", 5,
"STREAM_BLUETOOTH_SCO", 6,
"STREAM_SYSTEM_ENFORCED", 7,
"STREAM_DTMF", 8,
"STREAM_TTS", 9,
"NUM_STREAMS", 5,
"NUM_STREAM_TYPES", 10,
"MODE_INVALID", -2,
"MODE_CURRENT", -1,
"MODE_NORMAL", 0,
"MODE_RINGTONE", 1,
"MODE_IN_CALL", 2,
"MODE_IN_COMMUNICATION", 3,
"NUM_MODES", 4,
"ROUTE_EARPIECE", (1),
"ROUTE_SPEAKER", (2),
"ROUTE_BLUETOOTH", (4),
"ROUTE_BLUETOOTH_SCO", (4),
"ROUTE_HEADSET", (8),
"ROUTE_BLUETOOTH_A2DP", (16),
"ROUTE_ALL", 0xFFFFFFFF,
"AUDIO_STATUS_OK", 0,
"AUDIO_STATUS_ERROR", 1,
"AUDIO_STATUS_SERVER_DIED", 100,
"mErrorCallback", null,
"DEVICE_OUT_EARPIECE", 0x1,
"DEVICE_OUT_SPEAKER", 0x2,
"DEVICE_OUT_WIRED_HEADSET", 0x4,
"DEVICE_OUT_WIRED_HEADPHONE", 0x8,
"DEVICE_OUT_BLUETOOTH_SCO", 0x10,
"DEVICE_OUT_BLUETOOTH_SCO_HEADSET", 0x20,
"DEVICE_OUT_BLUETOOTH_SCO_CARKIT", 0x40,
"DEVICE_OUT_BLUETOOTH_A2DP", 0x80,
"DEVICE_OUT_BLUETOOTH_A2DP_HEADPHONES", 0x100,
"DEVICE_OUT_BLUETOOTH_A2DP_SPEAKER", 0x200,
"DEVICE_OUT_AUX_DIGITAL", 0x400,
"DEVICE_OUT_DEFAULT", 0x8000,
"DEVICE_IN_COMMUNICATION", 0x10000,
"DEVICE_IN_AMBIENT", 0x20000,
"DEVICE_IN_BUILTIN_MIC1", 0x40000,
"DEVICE_IN_BUILTIN_MIC2", 0x80000,
"DEVICE_IN_MIC_ARRAY", 0x100000,
"DEVICE_IN_BLUETOOTH_SCO_HEADSET", 0x200000,
"DEVICE_IN_WIRED_HEADSET", 0x400000,
"DEVICE_IN_AUX_DIGITAL", 0x800000,
"DEVICE_IN_DEFAULT", 0x80000000,
"DEVICE_STATE_UNAVAILABLE", 0,
"DEVICE_STATE_AVAILABLE", 1,
"PHONE_STATE_OFFCALL", 0,
"PHONE_STATE_RINGING", 1,
"PHONE_STATE_INCALL", 2,
"FORCE_NONE", 0,
"FORCE_SPEAKER", 1,
"FORCE_HEADPHONES", 2,
"FORCE_BT_SCO", 3,
"FORCE_BT_A2DP", 4,
"FORCE_WIRED_ACCESSORY", 5,
"FORCE_BT_CAR_DOCK", 6,
"FORCE_BT_DESK_DOCK", 7,
"FORCE_DEFAULT", 0,
"FOR_COMMUNICATION", 0,
"FOR_MEDIA", 1,
"FOR_RECORD", 2,
"FOR_DOCK", 3);
