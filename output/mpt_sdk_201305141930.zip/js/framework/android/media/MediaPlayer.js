﻿Clazz.declarePackage ("android.media");
Clazz.load (["android.os.Handler"], "android.media.MediaPlayer", ["android.os.Looper", "$.Parcel", "android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mNativeContext = 0;
this.mListenerContext = 0;
this.mSurface = null;
this.mSurfaceHolder = null;
this.mEventHandler = null;
this.mWakeLock = null;
this.mScreenOnWhilePlaying = false;
this.mStayAwake = false;
this.mDirectPath = null;
this.mPlayer = null;
this.mJavaCanvas = null;
this.isMediaPlaying = false;
this.mLooping = false;
this.mPlayerVolume = 1.0;
if (!Clazz.isClassDefined ("android.media.MediaPlayer.EventHandler")) {
android.media.MediaPlayer.$MediaPlayer$EventHandler$ ();
}
this.mOnPreparedListener = null;
this.mOnCompletionListener = null;
this.mOnBufferingUpdateListener = null;
this.mOnSeekCompleteListener = null;
this.mOnVideoSizeChangedListener = null;
this.mOnErrorListener = null;
this.mOnInfoListener = null;
Clazz.instantialize (this, arguments);
}, android.media, "MediaPlayer");
Clazz.makeConstructor (c$, 
function () {
var looper;
if ((looper = android.os.Looper.myLooper ()) != null) {
this.mEventHandler = Clazz.innerTypeInstance (android.media.MediaPlayer.EventHandler, this, null, this, looper);
} else if ((looper = android.os.Looper.getMainLooper ()) != null) {
this.mEventHandler = Clazz.innerTypeInstance (android.media.MediaPlayer.EventHandler, this, null, this, looper);
} else {
this.mEventHandler = null;
}});
Clazz.defineMethod (c$, "newRequest", 
function () {
var parcel = android.os.Parcel.obtain ();
parcel.writeInterfaceToken ("android.media.IMediaPlayer");
return parcel;
});
Clazz.defineMethod (c$, "invoke", 
function (request, reply) {
var retcode = this.native_invoke (request, reply);
reply.setDataPosition (0);
return retcode;
}, "android.os.Parcel,android.os.Parcel");
Clazz.defineMethod (c$, "setDisplay", 
function (sh) {
this.mSurfaceHolder = sh;
}, "android.view.SurfaceHolder");
c$.create = Clazz.defineMethod (c$, "create", 
function (context, uri) {
return android.media.MediaPlayer.create (context, uri, null);
}, "android.content.Context,android.net.Uri");
c$.create = Clazz.defineMethod (c$, "create", 
function (context, uri, holder) {
try {
var mp =  new android.media.MediaPlayer ();
mp.setDataSource (context, uri);
if (holder != null) {
mp.setDisplay (holder);
}mp.prepare ();
return mp;
} catch (e$$) {
if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
android.util.Log.d ("MediaPlayer", "create failed:", ex);
}
} else if (Clazz.instanceOf (e$$, IllegalArgumentException)) {
var ex = e$$;
{
android.util.Log.d ("MediaPlayer", "create failed:", ex);
}
} else if (Clazz.instanceOf (e$$, SecurityException)) {
var ex = e$$;
{
android.util.Log.d ("MediaPlayer", "create failed:", ex);
}
} else {
throw e$$;
}
}
return null;
}, "android.content.Context,android.net.Uri,android.view.SurfaceHolder");
c$.create = Clazz.defineMethod (c$, "create", 
function (context, resid) {
try {
var afd = context.getResources ().openRawResourceFd (resid);
if (afd == null) return null;
var mp =  new android.media.MediaPlayer ();
mp.setDataSource (afd.getRealPath ());
mp.prepare ();
return mp;
} catch (e$$) {
if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
android.util.Log.d ("MediaPlayer", "create failed:", ex);
}
} else if (Clazz.instanceOf (e$$, IllegalArgumentException)) {
var ex = e$$;
{
android.util.Log.d ("MediaPlayer", "create failed:", ex);
}
} else if (Clazz.instanceOf (e$$, SecurityException)) {
var ex = e$$;
{
android.util.Log.d ("MediaPlayer", "create failed:", ex);
}
} else {
throw e$$;
}
}
return null;
}, "android.content.Context,~N");
Clazz.defineMethod (c$, "setDataSource", 
function (context, uri) {
this.setDataSource (context, uri, null);
}, "android.content.Context,android.net.Uri");
Clazz.defineMethod (c$, "setDataSource", 
function (context, uri, headers) {
var scheme = uri.getScheme ();
if (scheme == null || scheme.equals ("file")) {
this.setDataSource (uri.getPath ());
return ;
}return ;
}, "android.content.Context,android.net.Uri,java.util.Map");
Clazz.defineMethod (c$, "setDataSource", 
function (path) {
this.mDirectPath = path;
}, "~S");
Clazz.defineMethod (c$, "setDataSource", 
function (fd) {
}, "java.io.FileDescriptor");
Clazz.defineMethod (c$, "_prepare", 
function () {
if ( this.mPlayer == null ) {
this.mPlayer = document.createElement('video');
}
this.mPlayer.src = this.mDirectPath;
this.mPlayer.loop = this.mLooping;
this.mPlayer.volume = this.mPlayerVolume;
});
Clazz.defineMethod (c$, "_setupCanvas", 
($fz = function () {
if (this.mSurfaceHolder != null) {
this.mJavaCanvas = this.mSurfaceHolder.lockCanvas ();
var that = this;
var canvas = document.getElementById(this.mJavaCanvas.getHTML5CanvasID());
//alert(mJavaCanvas.getHTML5CanvasID());
//var canvas = document.getElementById('1_fgCanvas');
var intId = setInterval(function() {
if ( that.mPlayer == null ) {
clearInterval(intId);
} else {
var ctx = canvas.getContext("2d");
try {
//ctx.drawImage(that.mPlayer, 0, 0,
//              that.mPlayer.videoWidth, that.mPlayer.videoHeight);
ctx.drawImage(that.mPlayer, 0, 0);
} catch ( e ) {
if ( e.name == "INDEX_SIZE_ERR" ) {
// we're playing an audio stream
clearInterval(intId); // No longer try to draw video on surface
}
}
}
}, 33);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "prepare", 
function () {
this._prepare ();
});
Clazz.defineMethod (c$, "start", 
function () {
this._setupCanvas ();
this._start ();
});
Clazz.defineMethod (c$, "_start", 
($fz = function () {
if ( this.mPlayer == null ) {
this._prepare();
}
this.mPlayer.play();
// Set the flag
this.isMediaPlaying = true;
var that = this;
this.mPlayer.addEventListener('ended', function (e) {
that.isMediaPlaying = false;
}, false);
this.mPlayer.addEventListener('error', function (e) {
that.isMediaPlaying = false;
// TODO: that.mOnErrorListener
}, false);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "stop", 
function () {
this._stop ();
});
Clazz.defineMethod (c$, "_stop", 
($fz = function () {
this.mSurfaceHolder.unlockCanvasAndPost (this.mJavaCanvas);
this.mJavaCanvas = null;
this.mPlayer.pause();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "pause", 
function () {
this._pause ();
});
Clazz.defineMethod (c$, "_pause", 
($fz = function () {
this.mPlayer.pause();
this.isMediaPlaying = false;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setWakeMode", 
function (context, mode) {
var washeld = false;
if (this.mWakeLock != null) {
if (this.mWakeLock.isHeld ()) {
washeld = true;
this.mWakeLock.release ();
}this.mWakeLock = null;
}var pm = context.getSystemService ("power");
this.mWakeLock = pm.newWakeLock (mode | 536870912, android.media.MediaPlayer.getName ());
this.mWakeLock.setReferenceCounted (false);
if (washeld) {
this.mWakeLock.acquire ();
}}, "android.content.Context,~N");
Clazz.defineMethod (c$, "setScreenOnWhilePlaying", 
function (screenOn) {
if (this.mScreenOnWhilePlaying != screenOn) {
this.mScreenOnWhilePlaying = screenOn;
this.updateSurfaceScreenOn ();
}}, "~B");
Clazz.defineMethod (c$, "stayAwake", 
($fz = function (awake) {
if (this.mWakeLock != null) {
if (awake && !this.mWakeLock.isHeld ()) {
this.mWakeLock.acquire ();
} else if (!awake && this.mWakeLock.isHeld ()) {
this.mWakeLock.release ();
}}this.mStayAwake = awake;
this.updateSurfaceScreenOn ();
}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "updateSurfaceScreenOn", 
($fz = function () {
if (this.mSurfaceHolder != null) {
this.mSurfaceHolder.setKeepScreenOn (this.mScreenOnWhilePlaying && this.mStayAwake);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getVideoWidth", 
function () {
if ( this.mPlayer != null ) {
return this.mPlayer.videoWidth;
}
return 0;
});
Clazz.defineMethod (c$, "getVideoHeight", 
function () {
if ( this.mPlayer != null ) {
return this.mPlayer.videoHeight;
}
return 0;
});
Clazz.defineMethod (c$, "isPlaying", 
function () {
return this.isMediaPlaying;
});
Clazz.defineMethod (c$, "seekTo", 
function (msec) {
if ( this.mPlayer != null ) {
this.mPlayer.currentTime = msec / 1000.0;
}
}, "~N");
Clazz.defineMethod (c$, "getCurrentPosition", 
function () {
if ( this.mPlayer != null ) {
return this.mPlayer.currentTime * 1000;
}
return 0;
});
Clazz.defineMethod (c$, "getDuration", 
function () {
if ( this.mPlayer != null ) {
return this.mPlayer.duration * 1000;
}
return 0;
});
Clazz.defineMethod (c$, "setMetadataFilter", 
function (allow, block) {
var request = this.newRequest ();
request.writeInt (allow.size ());
for (var t, $t = allow.iterator (); $t.hasNext () && ((t = $t.next ()) || true);) {
request.writeInt ((t).intValue ());
}
request.writeInt (block.size ());
for (var t, $t = block.iterator (); $t.hasNext () && ((t = $t.next ()) || true);) {
request.writeInt ((t).intValue ());
}
return this.native_setMetadataFilter (request);
}, "java.util.Set,java.util.Set");
Clazz.defineMethod (c$, "release", 
function () {
this.mOnPreparedListener = null;
this.mOnBufferingUpdateListener = null;
this.mOnCompletionListener = null;
this.mOnSeekCompleteListener = null;
this.mOnErrorListener = null;
this.mOnInfoListener = null;
this.mOnVideoSizeChangedListener = null;
this._release ();
});
Clazz.defineMethod (c$, "_release", 
($fz = function () {
this.mPlayer.pause();
this.mPlayer.src = "";
this.mPlayer = null;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "reset", 
function () {
this.stayAwake (false);
this._reset ();
this.mEventHandler.removeCallbacksAndMessages (null);
});
Clazz.defineMethod (c$, "suspend", 
function () {
if (this.native_suspend_resume (true) < 0) {
return false;
}this.stayAwake (false);
this.mEventHandler.removeCallbacksAndMessages (null);
return true;
});
Clazz.defineMethod (c$, "resume", 
function () {
if (this.native_suspend_resume (false) < 0) {
return false;
}if (this.isPlaying ()) {
this.stayAwake (true);
}return true;
});
Clazz.defineMethod (c$, "setAudioStreamType", 
function (streamtype) {
}, "~N");
Clazz.defineMethod (c$, "setLooping", 
function (looping) {
this.mLooping = looping;
if ( this.mPlayer != null ) {
this.mPlayer.loop = looping;
}
}, "~B");
Clazz.defineMethod (c$, "isLooping", 
function () {
return this.mLooping;
});
Clazz.defineMethod (c$, "setVolume", 
function (leftVolume, rightVolume) {
if (rightVolume < leftVolume) {
leftVolume = rightVolume;
}this.mPlayerVolume = leftVolume;
if ( this.mPlayer != null ) {
this.mPlayer.volume = this.mPlayerVolume; // also in range [0.0f ~ 1.0f]
}
}, "~N,~N");
c$.native_init = Clazz.defineMethod (c$, "native_init", 
($fz = function () {
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "finalize", 
function () {
this.native_finalize ();
});
Clazz.defineMethod (c$, "setOnPreparedListener", 
function (listener) {
this.mOnPreparedListener = listener;
}, "android.media.MediaPlayer.OnPreparedListener");
Clazz.defineMethod (c$, "setOnCompletionListener", 
function (listener) {
this.mOnCompletionListener = listener;
}, "android.media.MediaPlayer.OnCompletionListener");
Clazz.defineMethod (c$, "setOnBufferingUpdateListener", 
function (listener) {
this.mOnBufferingUpdateListener = listener;
}, "android.media.MediaPlayer.OnBufferingUpdateListener");
Clazz.defineMethod (c$, "setOnSeekCompleteListener", 
function (listener) {
this.mOnSeekCompleteListener = listener;
}, "android.media.MediaPlayer.OnSeekCompleteListener");
Clazz.defineMethod (c$, "setOnVideoSizeChangedListener", 
function (listener) {
this.mOnVideoSizeChangedListener = listener;
}, "android.media.MediaPlayer.OnVideoSizeChangedListener");
Clazz.defineMethod (c$, "setOnErrorListener", 
function (listener) {
this.mOnErrorListener = listener;
}, "android.media.MediaPlayer.OnErrorListener");
Clazz.defineMethod (c$, "setOnInfoListener", 
function (listener) {
this.mOnInfoListener = listener;
}, "android.media.MediaPlayer.OnInfoListener");
c$.$MediaPlayer$EventHandler$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mMediaPlayer = null;
Clazz.instantialize (this, arguments);
}, android.media.MediaPlayer, "EventHandler", android.os.Handler);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.media.MediaPlayer.EventHandler, [b]);
this.mMediaPlayer = a;
}, "android.media.MediaPlayer,android.os.Looper");
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
if (this.mMediaPlayer.mNativeContext == 0) {
android.util.Log.w ("MediaPlayer", "mediaplayer went away with unhandled events");
return ;
}switch (a.what) {
case 1:
if (this.b$["android.media.MediaPlayer"].mOnPreparedListener != null) this.b$["android.media.MediaPlayer"].mOnPreparedListener.onPrepared (this.mMediaPlayer);
return ;
case 2:
if (this.b$["android.media.MediaPlayer"].mOnCompletionListener != null) this.b$["android.media.MediaPlayer"].mOnCompletionListener.onCompletion (this.mMediaPlayer);
this.b$["android.media.MediaPlayer"].stayAwake (false);
return ;
case 3:
if (this.b$["android.media.MediaPlayer"].mOnBufferingUpdateListener != null) this.b$["android.media.MediaPlayer"].mOnBufferingUpdateListener.onBufferingUpdate (this.mMediaPlayer, a.arg1);
return ;
case 4:
if (this.b$["android.media.MediaPlayer"].mOnSeekCompleteListener != null) this.b$["android.media.MediaPlayer"].mOnSeekCompleteListener.onSeekComplete (this.mMediaPlayer);
return ;
case 5:
if (this.b$["android.media.MediaPlayer"].mOnVideoSizeChangedListener != null) this.b$["android.media.MediaPlayer"].mOnVideoSizeChangedListener.onVideoSizeChanged (this.mMediaPlayer, a.arg1, a.arg2);
return ;
case 100:
android.util.Log.e ("MediaPlayer", "Error (" + a.arg1 + "," + a.arg2 + ")");
var b = false;
if (this.b$["android.media.MediaPlayer"].mOnErrorListener != null) {
b = this.b$["android.media.MediaPlayer"].mOnErrorListener.onError (this.mMediaPlayer, a.arg1, a.arg2);
}if (this.b$["android.media.MediaPlayer"].mOnCompletionListener != null && !b) {
this.b$["android.media.MediaPlayer"].mOnCompletionListener.onCompletion (this.mMediaPlayer);
}this.b$["android.media.MediaPlayer"].stayAwake (false);
return ;
case 200:
android.util.Log.i ("MediaPlayer", "Info (" + a.arg1 + "," + a.arg2 + ")");
if (this.b$["android.media.MediaPlayer"].mOnInfoListener != null) {
this.b$["android.media.MediaPlayer"].mOnInfoListener.onInfo (this.mMediaPlayer, a.arg1, a.arg2);
}return ;
case 0:
break;
default:
android.util.Log.e ("MediaPlayer", "Unknown message type " + a.what);
return ;
}
}, "android.os.Message");
c$ = Clazz.p0p ();
};
Clazz.declareInterface (android.media.MediaPlayer, "OnPreparedListener");
Clazz.declareInterface (android.media.MediaPlayer, "OnCompletionListener");
Clazz.declareInterface (android.media.MediaPlayer, "OnBufferingUpdateListener");
Clazz.declareInterface (android.media.MediaPlayer, "OnSeekCompleteListener");
Clazz.declareInterface (android.media.MediaPlayer, "OnVideoSizeChangedListener");
Clazz.declareInterface (android.media.MediaPlayer, "OnErrorListener");
Clazz.declareInterface (android.media.MediaPlayer, "OnInfoListener");
Clazz.defineStatics (c$,
"METADATA_UPDATE_ONLY", true,
"METADATA_ALL", false,
"APPLY_METADATA_FILTER", true,
"BYPASS_METADATA_FILTER", false);
{
android.media.MediaPlayer.native_init ();
}Clazz.defineStatics (c$,
"TAG", "MediaPlayer",
"IMEDIA_PLAYER", "android.media.IMediaPlayer",
"MEDIA_NOP", 0,
"MEDIA_PREPARED", 1,
"MEDIA_PLAYBACK_COMPLETE", 2,
"MEDIA_BUFFERING_UPDATE", 3,
"MEDIA_SEEK_COMPLETE", 4,
"MEDIA_SET_VIDEO_SIZE", 5,
"MEDIA_ERROR", 100,
"MEDIA_INFO", 200,
"MEDIA_ERROR_UNKNOWN", 1,
"MEDIA_ERROR_SERVER_DIED", 100,
"MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK", 200,
"MEDIA_INFO_UNKNOWN", 1,
"MEDIA_INFO_VIDEO_TRACK_LAGGING", 700,
"MEDIA_INFO_BUFFERING_START", 701,
"MEDIA_INFO_BUFFERING_END", 702,
"MEDIA_INFO_BAD_INTERLEAVING", 800,
"MEDIA_INFO_NOT_SEEKABLE", 801,
"MEDIA_INFO_METADATA_UPDATE", 802);
});
