﻿Clazz.declarePackage ("android.media");
Clazz.load (["java.lang.Enum"], "android.media.DecoderCapabilities", ["java.util.ArrayList"], function () {
c$ = Clazz.declareType (android.media, "DecoderCapabilities");
c$.getVideoDecoders = Clazz.defineMethod (c$, "getVideoDecoders", 
function () {
var decoderList =  new java.util.ArrayList ();
var nDecoders = android.media.DecoderCapabilities.native_get_num_video_decoders ();
for (var i = 0; i < nDecoders; ++i) {
decoderList.add (android.media.DecoderCapabilities.VideoDecoder.values ()[android.media.DecoderCapabilities.native_get_video_decoder_type (i)]);
}
return decoderList;
});
c$.getAudioDecoders = Clazz.defineMethod (c$, "getAudioDecoders", 
function () {
var decoderList =  new java.util.ArrayList ();
var nDecoders = android.media.DecoderCapabilities.native_get_num_audio_decoders ();
for (var i = 0; i < nDecoders; ++i) {
decoderList.add (android.media.DecoderCapabilities.AudioDecoder.values ()[android.media.DecoderCapabilities.native_get_audio_decoder_type (i)]);
}
return decoderList;
});
Clazz.pu$h ();
c$ = Clazz.declareType (android.media.DecoderCapabilities, "VideoDecoder", Enum);
Clazz.defineEnumConstant (c$, "VIDEO_DECODER_WMV", 0, []);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.media.DecoderCapabilities, "AudioDecoder", Enum);
Clazz.defineEnumConstant (c$, "AUDIO_DECODER_WMA", 0, []);
c$ = Clazz.p0p ();
{
System.loadLibrary ("media_jni");
android.media.DecoderCapabilities.native_init ();
}});
