﻿Clazz.declarePackage ("android.media");
Clazz.declareInterface (android.media, "MediaScannerClient");
