﻿Clazz.declarePackage ("android.media");
c$ = Clazz.decorateAsClass (function () {
this.mContext = null;
Clazz.instantialize (this, arguments);
}, android.media, "AudioManager");
Clazz.makeConstructor (c$, 
function (context) {
this.mContext = context;
}, "android.content.Context");
Clazz.defineMethod (c$, "unregisterMediaButtonEventReceiver", 
function (eventReceiver) {
console.log("Missing method: unregisterMediaButtonEventReceiver");
}, "android.content.ComponentName");
Clazz.defineMethod (c$, "getParameters", 
function (keys) {
console.log("Missing method: getParameters");
}, "~S");
Clazz.defineMethod (c$, "setWiredHeadsetOn", 
function (on) {
console.log("Missing method: setWiredHeadsetOn");
}, "~B");
Clazz.defineMethod (c$, "loadSoundEffects", 
function () {
console.log("Missing method: loadSoundEffects");
});
Clazz.defineMethod (c$, "setBluetoothScoOn", 
function (on) {
console.log("Missing method: setBluetoothScoOn");
}, "~B");
Clazz.defineMethod (c$, "setBluetoothA2dpOn", 
function (on) {
console.log("Missing method: setBluetoothA2dpOn");
}, "~B");
Clazz.defineMethod (c$, "getRouting", 
function (mode) {
console.log("Missing method: getRouting");
}, "~N");
Clazz.defineMethod (c$, "isMicrophoneMute", 
function () {
console.log("Missing method: isMicrophoneMute");
});
Clazz.defineMethod (c$, "setMicrophoneMute", 
function (on) {
console.log("Missing method: setMicrophoneMute");
}, "~B");
Clazz.defineMethod (c$, "getRingerMode", 
function () {
console.log("Missing method: getRingerMode");
});
Clazz.defineMethod (c$, "getStreamVolume", 
function (streamType) {
console.log("Missing method: getStreamVolume");
}, "~N");
Clazz.defineMethod (c$, "isSpeakerphoneOn", 
function () {
console.log("Missing method: isSpeakerphoneOn");
});
Clazz.defineMethod (c$, "setMode", 
function (mode) {
console.log("Missing method: setMode");
}, "~N");
Clazz.defineMethod (c$, "setRingerMode", 
function (ringerMode) {
console.log("Missing method: setRingerMode");
}, "~N");
Clazz.defineMethod (c$, "shouldVibrate", 
function (vibrateType) {
console.log("Missing method: shouldVibrate");
}, "~N");
Clazz.defineMethod (c$, "abandonAudioFocus", 
function (audioFocusChangeListener) {
console.log("Missing method: abandonAudioFocus");
}, "~O");
Clazz.defineMethod (c$, "isWiredHeadsetOn", 
function () {
console.log("Missing method: isWiredHeadsetOn");
});
Clazz.defineMethod (c$, "isBluetoothScoAvailableOffCall", 
function () {
console.log("Missing method: isBluetoothScoAvailableOffCall");
});
Clazz.defineMethod (c$, "setParameter", 
function (key, value) {
console.log("Missing method: setParameter");
}, "~S,~S");
Clazz.defineMethod (c$, "startBluetoothSco", 
function () {
console.log("Missing method: startBluetoothSco");
});
Clazz.defineMethod (c$, "stopBluetoothSco", 
function () {
console.log("Missing method: stopBluetoothSco");
});
Clazz.defineMethod (c$, "playSoundEffect", 
function (effectType) {
console.log("Missing method: playSoundEffect");
}, "~N");
Clazz.defineMethod (c$, "isBluetoothA2dpOn", 
function () {
console.log("Missing method: isBluetoothA2dpOn");
});
Clazz.defineMethod (c$, "setParameters", 
function (keyValuePairs) {
console.log("Missing method: setParameters");
}, "~S");
Clazz.defineMethod (c$, "unloadSoundEffects", 
function () {
console.log("Missing method: unloadSoundEffects");
});
Clazz.defineMethod (c$, "getStreamMaxVolume", 
function (streamType) {
console.log("Missing method: getStreamMaxVolume");
}, "~N");
Clazz.defineMethod (c$, "getMode", 
function () {
console.log("Missing method: getMode");
});
Clazz.defineMethod (c$, "getVibrateSetting", 
function (vibrateType) {
console.log("Missing method: getVibrateSetting");
}, "~N");
Clazz.defineMethod (c$, "setSpeakerphoneOn", 
function (on) {
console.log("Missing method: setSpeakerphoneOn");
}, "~B");
Clazz.defineMethod (c$, "isBluetoothScoOn", 
function () {
console.log("Missing method: isBluetoothScoOn");
});
Clazz.defineMethod (c$, "isMusicActive", 
function () {
console.log("Missing method: isMusicActive");
});
Clazz.defineMethod (c$, "playSoundEffect", 
function (effectType, volume) {
console.log("Missing method: playSoundEffect");
}, "~N,~N");
Clazz.defineStatics (c$,
"TAG", "AudioManager",
"DEBUG", false);
c$.localLOGV = c$.prototype.localLOGV = android.media.AudioManager.DEBUG || false;
Clazz.defineStatics (c$,
"ACTION_AUDIO_BECOMING_NOISY", "android.media.AUDIO_BECOMING_NOISY",
"RINGER_MODE_CHANGED_ACTION", "android.media.RINGER_MODE_CHANGED",
"EXTRA_RINGER_MODE", "android.media.EXTRA_RINGER_MODE",
"VIBRATE_SETTING_CHANGED_ACTION", "android.media.VIBRATE_SETTING_CHANGED",
"VOLUME_CHANGED_ACTION", "android.media.VOLUME_CHANGED_ACTION",
"EXTRA_VIBRATE_SETTING", "android.media.EXTRA_VIBRATE_SETTING",
"EXTRA_VIBRATE_TYPE", "android.media.EXTRA_VIBRATE_TYPE",
"EXTRA_VOLUME_STREAM_TYPE", "android.media.EXTRA_VOLUME_STREAM_TYPE",
"EXTRA_VOLUME_STREAM_VALUE", "android.media.EXTRA_VOLUME_STREAM_VALUE",
"EXTRA_PREV_VOLUME_STREAM_VALUE", "android.media.EXTRA_PREV_VOLUME_STREAM_VALUE",
"STREAM_VOICE_CALL", 0,
"STREAM_SYSTEM", 1,
"STREAM_RING", 2,
"STREAM_MUSIC", 3,
"STREAM_ALARM", 4,
"STREAM_NOTIFICATION", 5,
"STREAM_BLUETOOTH_SCO", 6,
"STREAM_SYSTEM_ENFORCED", 7,
"STREAM_DTMF", 8,
"STREAM_TTS", 9,
"NUM_STREAMS", 5,
"DEFAULT_STREAM_VOLUME", [4, 7, 5, 11, 6, 5, 7, 7, 11, 11],
"ADJUST_RAISE", 1,
"ADJUST_LOWER", -1,
"ADJUST_SAME", 0,
"FLAG_SHOW_UI", 1,
"FLAG_ALLOW_RINGER_MODES", 2,
"FLAG_PLAY_SOUND", 4,
"FLAG_REMOVE_SOUND_AND_VIBRATE", 8,
"FLAG_VIBRATE", 16,
"RINGER_MODE_SILENT", 0,
"RINGER_MODE_VIBRATE", 1,
"RINGER_MODE_NORMAL", 2,
"VIBRATE_TYPE_RINGER", 0,
"VIBRATE_TYPE_NOTIFICATION", 1,
"VIBRATE_SETTING_OFF", 0,
"VIBRATE_SETTING_ON", 1,
"VIBRATE_SETTING_ONLY_SILENT", 2,
"USE_DEFAULT_STREAM_TYPE", -2147483648);
