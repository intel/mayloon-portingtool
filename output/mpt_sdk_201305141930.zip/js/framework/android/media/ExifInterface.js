﻿Clazz.declarePackage ("android.media");
Clazz.load (null, "android.media.ExifInterface", ["java.lang.Double", "$.IllegalArgumentException", "$.StringBuilder", "java.text.ParsePosition", "$.SimpleDateFormat", "java.util.HashMap", "$.TimeZone"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFilename = null;
this.mAttributes = null;
this.mHasThumbnail = false;
Clazz.instantialize (this, arguments);
}, android.media, "ExifInterface");
Clazz.makeConstructor (c$, 
function (filename) {
this.mFilename = filename;
this.loadAttributes ();
}, "~S");
Clazz.defineMethod (c$, "getAttribute", 
function (tag) {
return this.mAttributes.get (tag);
}, "~S");
Clazz.defineMethod (c$, "getAttributeInt", 
function (tag, defaultValue) {
var value = this.mAttributes.get (tag);
if (value == null) return defaultValue;
try {
return Integer.$valueOf (value);
} catch (ex) {
if (Clazz.instanceOf (ex, NumberFormatException)) {
return defaultValue;
} else {
throw ex;
}
}
}, "~S,~N");
Clazz.defineMethod (c$, "getAttributeDouble", 
function (tag, defaultValue) {
var value = this.mAttributes.get (tag);
if (value == null) return defaultValue;
try {
var index = value.indexOf ("/");
if (index == -1) return defaultValue;
var denom = Double.parseDouble (value.substring (index + 1));
if (denom == 0) return defaultValue;
var num = Double.parseDouble (value.substring (0, index));
return num / denom;
} catch (ex) {
if (Clazz.instanceOf (ex, NumberFormatException)) {
return defaultValue;
} else {
throw ex;
}
}
}, "~S,~N");
Clazz.defineMethod (c$, "setAttribute", 
function (tag, value) {
this.mAttributes.put (tag, value);
}, "~S,~S");
Clazz.defineMethod (c$, "loadAttributes", 
($fz = function () {
this.mAttributes =  new java.util.HashMap ();
var attrStr;
{
attrStr = this.getAttributesNative (this.mFilename);
}var ptr = attrStr.indexOf (' ');
var count = Integer.parseInt (attrStr.substring (0, ptr));
++ptr;
for (var i = 0; i < count; i++) {
var equalPos = attrStr.indexOf ('=', ptr);
var attrName = attrStr.substring (ptr, equalPos);
ptr = equalPos + 1;
var lenPos = attrStr.indexOf (' ', ptr);
var attrLen = Integer.parseInt (attrStr.substring (ptr, lenPos));
ptr = lenPos + 1;
var attrValue = attrStr.substring (ptr, ptr + attrLen);
ptr += attrLen;
if (attrName.equals ("hasThumbnail")) {
this.mHasThumbnail = attrValue.equalsIgnoreCase ("true");
} else {
this.mAttributes.put (attrName, attrValue);
}}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "saveAttributes", 
function () {
var sb =  new StringBuilder ();
var size = this.mAttributes.size ();
if (this.mAttributes.containsKey ("hasThumbnail")) {
--size;
}sb.append (size + " ");
for (var iter, $iter = this.mAttributes.entrySet ().iterator (); $iter.hasNext () && ((iter = $iter.next ()) || true);) {
var key = iter.getKey ();
if (key.equals ("hasThumbnail")) {
continue ;}var val = iter.getValue ();
sb.append (key + "=");
sb.append (val.length + " ");
sb.append (val);
}
var s = sb.toString ();
{
this.saveAttributesNative (this.mFilename, s);
this.commitChangesNative (this.mFilename);
}});
Clazz.defineMethod (c$, "hasThumbnail", 
function () {
return this.mHasThumbnail;
});
Clazz.defineMethod (c$, "getThumbnail", 
function () {
{
return this.getThumbnailNative (this.mFilename);
}});
Clazz.defineMethod (c$, "getLatLong", 
function (output) {
var latValue = this.mAttributes.get ("GPSLatitude");
var latRef = this.mAttributes.get ("GPSLatitudeRef");
var lngValue = this.mAttributes.get ("GPSLongitude");
var lngRef = this.mAttributes.get ("GPSLongitudeRef");
if (latValue != null && latRef != null && lngValue != null && lngRef != null) {
try {
output[0] = android.media.ExifInterface.convertRationalLatLonToFloat (latValue, latRef);
output[1] = android.media.ExifInterface.convertRationalLatLonToFloat (lngValue, lngRef);
return true;
} catch (e) {
if (Clazz.instanceOf (e, IllegalArgumentException)) {
} else {
throw e;
}
}
}return false;
}, "~A");
Clazz.defineMethod (c$, "getAltitude", 
function (defaultValue) {
var altitude = this.getAttributeDouble ("GPSAltitude", -1);
var ref = this.getAttributeInt ("GPSAltitudeRef", -1);
if (altitude >= 0 && ref >= 0) {
return (altitude * ((ref == 1) ? -1 : 1));
} else {
return defaultValue;
}}, "~N");
Clazz.defineMethod (c$, "getDateTime", 
function () {
var dateTimeString = this.mAttributes.get ("DateTime");
if (dateTimeString == null) return -1;
var pos =  new java.text.ParsePosition (0);
try {
var datetime = android.media.ExifInterface.sFormatter.parse (dateTimeString, pos);
if (datetime == null) return -1;
return datetime.getTime ();
} catch (ex) {
if (Clazz.instanceOf (ex, IllegalArgumentException)) {
return -1;
} else {
throw ex;
}
}
});
Clazz.defineMethod (c$, "getGpsDateTime", 
function () {
var date = this.mAttributes.get ("GPSDateStamp");
var time = this.mAttributes.get ("GPSTimeStamp");
if (date == null || time == null) return -1;
var dateTimeString = date + ' ' + time;
if (dateTimeString == null) return -1;
var pos =  new java.text.ParsePosition (0);
try {
var datetime = android.media.ExifInterface.sFormatter.parse (dateTimeString, pos);
if (datetime == null) return -1;
return datetime.getTime ();
} catch (ex) {
if (Clazz.instanceOf (ex, IllegalArgumentException)) {
return -1;
} else {
throw ex;
}
}
});
c$.convertRationalLatLonToFloat = Clazz.defineMethod (c$, "convertRationalLatLonToFloat", 
($fz = function (rationalString, ref) {
try {
var parts = rationalString.$plit (",");
var pair;
pair = parts[0].$plit ("/");
var degrees = Double.parseDouble (pair[0].trim ()) / Double.parseDouble (pair[1].trim ());
pair = parts[1].$plit ("/");
var minutes = Double.parseDouble (pair[0].trim ()) / Double.parseDouble (pair[1].trim ());
pair = parts[2].$plit ("/");
var seconds = Double.parseDouble (pair[0].trim ()) / Double.parseDouble (pair[1].trim ());
var result = degrees + (minutes / 60.0) + (seconds / 3600.0);
if ((ref.equals ("S") || ref.equals ("W"))) {
return -result;
}return result;
} catch (e$$) {
if (Clazz.instanceOf (e$$, NumberFormatException)) {
var e = e$$;
{
throw  new IllegalArgumentException ();
}
} else if (Clazz.instanceOf (e$$, ArrayIndexOutOfBoundsException)) {
var e = e$$;
{
throw  new IllegalArgumentException ();
}
} else {
throw e$$;
}
}
}, $fz.isPrivate = true, $fz), "~S,~S");
Clazz.defineStatics (c$,
"TAG_ORIENTATION", "Orientation",
"TAG_DATETIME", "DateTime",
"TAG_MAKE", "Make",
"TAG_MODEL", "Model",
"TAG_FLASH", "Flash",
"TAG_IMAGE_WIDTH", "ImageWidth",
"TAG_IMAGE_LENGTH", "ImageLength",
"TAG_GPS_LATITUDE", "GPSLatitude",
"TAG_GPS_LONGITUDE", "GPSLongitude",
"TAG_GPS_LATITUDE_REF", "GPSLatitudeRef",
"TAG_GPS_LONGITUDE_REF", "GPSLongitudeRef",
"TAG_GPS_ALTITUDE", "GPSAltitude",
"TAG_GPS_ALTITUDE_REF", "GPSAltitudeRef",
"TAG_GPS_TIMESTAMP", "GPSTimeStamp",
"TAG_GPS_DATESTAMP", "GPSDateStamp",
"TAG_WHITE_BALANCE", "WhiteBalance",
"TAG_FOCAL_LENGTH", "FocalLength",
"TAG_GPS_PROCESSING_METHOD", "GPSProcessingMethod",
"ORIENTATION_UNDEFINED", 0,
"ORIENTATION_NORMAL", 1,
"ORIENTATION_FLIP_HORIZONTAL", 2,
"ORIENTATION_ROTATE_180", 3,
"ORIENTATION_FLIP_VERTICAL", 4,
"ORIENTATION_TRANSPOSE", 5,
"ORIENTATION_ROTATE_90", 6,
"ORIENTATION_TRANSVERSE", 7,
"ORIENTATION_ROTATE_270", 8,
"WHITEBALANCE_AUTO", 0,
"WHITEBALANCE_MANUAL", 1,
"sFormatter", null);
{
System.loadLibrary ("exif");
($t$ = android.media.ExifInterface.sFormatter =  new java.text.SimpleDateFormat ("yyyy:MM:dd HH:mm:ss"), android.media.ExifInterface.prototype.sFormatter = android.media.ExifInterface.sFormatter, $t$);
android.media.ExifInterface.sFormatter.setTimeZone (java.util.TimeZone.getTimeZone ("UTC"));
}c$.sLock = c$.prototype.sLock =  new JavaObject ();
});
