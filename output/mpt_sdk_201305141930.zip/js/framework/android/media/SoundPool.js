﻿Clazz.declarePackage ("android.media");
Clazz.load (["android.os.Handler"], "android.media.SoundPool", ["android.media.MediaPlayer", "android.os.ParcelFileDescriptor", "android.util.AndroidRuntimeException", "$.Log", "java.io.File"], function () {
c$ = Clazz.decorateAsClass (function () {
this.playerArray = null;
this.indexCounter = 0;
this.mNativeContext = 0;
this.mEventHandler = null;
this.mOnLoadCompleteListener = null;
if (!Clazz.isClassDefined ("android.media.SoundPool.EventHandler")) {
android.media.SoundPool.$SoundPool$EventHandler$ ();
}
Clazz.instantialize (this, arguments);
}, android.media, "SoundPool");
Clazz.makeConstructor (c$, 
function (maxStreams, streamType, srcQuality) {
this.playerArray =  new Array (maxStreams);
this.indexCounter = 0;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "load", 
function (path, priority) {
if (path.startsWith ("http:")) return this._load (path, priority);
var id = 0;
try {
var f =  new java.io.File (path);
if (f != null) {
var fd = android.os.ParcelFileDescriptor.open (f, 268435456);
if (fd != null) {
id = this._load (fd.getFileDescriptor (), 0, f.length (), priority);
fd.close ();
}}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
android.util.Log.e ("SoundPool", "error loading " + path);
} else {
throw e;
}
}
return id;
}, "~S,~N");
Clazz.defineMethod (c$, "load", 
function (context, resId, priority) {
this.playerArray[this.indexCounter] = android.media.MediaPlayer.create (context, resId);
return this.indexCounter++;
}, "android.content.Context,~N,~N");
Clazz.defineMethod (c$, "load", 
function (afd, priority) {
if (afd != null) {
var len = afd.getLength ();
if (len < 0) {
throw  new android.util.AndroidRuntimeException ("no length for fd");
}return this._load (afd.getFileDescriptor (), afd.getStartOffset (), len, priority);
} else {
return 0;
}}, "android.content.res.AssetFileDescriptor,~N");
Clazz.defineMethod (c$, "load", 
function (fd, offset, length, priority) {
return this._load (fd, offset, length, priority);
}, "java.io.FileDescriptor,~N,~N,~N");
Clazz.defineMethod (c$, "play", 
function (soundID, leftVolume, rightVolume, priority, loop, rate) {
this.playerArray[soundID].setVolume (leftVolume, rightVolume);
this.playerArray[soundID].setLooping (loop != 0);
this.playerArray[soundID].start ();
return 1;
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "setOnLoadCompleteListener", 
function (listener) {
this.mOnLoadCompleteListener = listener;
}, "android.media.SoundPool.OnLoadCompleteListener");
Clazz.overrideMethod (c$, "finalize", 
function () {
this.release ();
});
c$.$SoundPool$EventHandler$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mSoundPool = null;
Clazz.instantialize (this, arguments);
}, android.media.SoundPool, "EventHandler", android.os.Handler);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.media.SoundPool.EventHandler, [b]);
this.mSoundPool = a;
}, "android.media.SoundPool,android.os.Looper");
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
switch (a.what) {
case 1:
if (false) android.util.Log.d ("SoundPool", "Sample " + a.arg1 + " loaded");
if (this.b$["android.media.SoundPool"].mOnLoadCompleteListener != null) {
this.b$["android.media.SoundPool"].mOnLoadCompleteListener.onLoadComplete (this.mSoundPool, a.arg1, a.arg2);
}break;
default:
android.util.Log.e ("SoundPool", "Unknown message type " + a.what);
return ;
}
}, "android.os.Message");
c$ = Clazz.p0p ();
};
Clazz.declareInterface (android.media.SoundPool, "OnLoadCompleteListener");
Clazz.defineStatics (c$,
"TAG", "SoundPool",
"DEBUG", false,
"SAMPLE_LOADED", 1);
});
