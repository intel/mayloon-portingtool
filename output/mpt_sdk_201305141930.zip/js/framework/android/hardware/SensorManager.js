﻿Clazz.declarePackage ("android.hardware");
Clazz.load (["android.hardware.SensorEventListener", "android.util.Log", "$.SparseArray", "$.SparseBooleanArray", "$.SparseIntArray", "java.util.ArrayList", "$.HashMap"], "android.hardware.SensorManager", ["android.content.Context", "android.hardware.Sensor", "$.SensorEvent", "android.os.Handler", "$.Message", "java.lang.Thread", "java.util.Collections"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mMainLooper = null;
this.mLegacyListenersMap = null;
if (!Clazz.isClassDefined ("android.hardware.SensorManager.ListenerDelegate")) {
android.hardware.SensorManager.$SensorManager$ListenerDelegate$ ();
}
if (!Clazz.isClassDefined ("android.hardware.SensorManager.LegacyListener")) {
android.hardware.SensorManager.$SensorManager$LegacyListener$ ();
}
if (!Clazz.isClassDefined ("android.hardware.SensorManager.LmsFilter")) {
android.hardware.SensorManager.$SensorManager$LmsFilter$ ();
}
Clazz.instantialize (this, arguments);
}, android.hardware, "SensorManager");
Clazz.prepareFields (c$, function () {
this.mLegacyListenersMap =  new java.util.HashMap ();
});
Clazz.makeConstructor (c$, 
function (mainLooper) {
this.mMainLooper = mainLooper;
{
if (!android.hardware.SensorManager.sSensorModuleInitialized) {
($t$ = android.hardware.SensorManager.sSensorModuleInitialized = true, android.hardware.SensorManager.prototype.sSensorModuleInitialized = android.hardware.SensorManager.sSensorModuleInitialized, $t$);
android.hardware.SensorManager.nativeClassInit ();
($t$ = android.hardware.SensorManager.sWindowManager = android.content.Context.getSystemContext ().getSystemService ("window"), android.hardware.SensorManager.prototype.sWindowManager = android.hardware.SensorManager.sWindowManager, $t$);
if (android.hardware.SensorManager.sWindowManager != null) {
}android.hardware.SensorManager.sensors_module_init ();
var fullList = android.hardware.SensorManager.sFullSensorsList;
var i = 0;
do {
var sensor =  new android.hardware.Sensor ();
i = android.hardware.SensorManager.sensors_module_get_next_sensor (sensor, i);
if (i >= 0) {
sensor.setLegacyType (this.getLegacySensorType (sensor.getType ()));
fullList.add (sensor);
android.hardware.SensorManager.sHandleToSensor.append (sensor.getHandle (), sensor);
}} while (i > 0);
($t$ = android.hardware.SensorManager.sSensorThread =  new android.hardware.SensorManager.SensorThread (), android.hardware.SensorManager.prototype.sSensorThread = android.hardware.SensorManager.sSensorThread, $t$);
}}}, "android.os.Looper");
Clazz.defineMethod (c$, "getLegacySensorType", 
($fz = function (type) {
switch (type) {
case 1:
return 2;
case 2:
return 8;
case 3:
return 128;
case 7:
return 4;
}
return 0;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getSensors", 
function () {
var result = 0;
var fullList = android.hardware.SensorManager.sFullSensorsList;
for (var i, $i = fullList.iterator (); $i.hasNext () && ((i = $i.next ()) || true);) {
switch (i.getType ()) {
case 1:
result |= 2;
break;
case 2:
result |= 8;
break;
case 3:
result |= 129;
break;
}
}
return result;
});
Clazz.defineMethod (c$, "getSensorList", 
function (type) {
var list;
var fullList = android.hardware.SensorManager.sFullSensorsList;
{
list = android.hardware.SensorManager.sSensorListByType.get (type);
if (list == null) {
if (type == -1) {
list = fullList;
} else {
list =  new java.util.ArrayList ();
for (var i, $i = fullList.iterator (); $i.hasNext () && ((i = $i.next ()) || true);) {
if (i.getType () == type) list.add (i);
}
}list = java.util.Collections.unmodifiableList (list);
android.hardware.SensorManager.sSensorListByType.append (type, list);
}}return list;
}, "~N");
Clazz.defineMethod (c$, "getDefaultSensor", 
function (type) {
var l = this.getSensorList (type);
return l.isEmpty () ? null : l.get (0);
}, "~N");
Clazz.defineMethod (c$, "registerListener", 
function (listener, sensors) {
return this.registerListener (listener, sensors, 3);
}, "android.hardware.SensorListener,~N");
Clazz.defineMethod (c$, "registerListener", 
function (listener, sensors, rate) {
if (listener == null) {
return false;
}var result = false;
result = this.registerLegacyListener (2, 1, listener, sensors, rate) || result;
result = this.registerLegacyListener (8, 2, listener, sensors, rate) || result;
result = this.registerLegacyListener (128, 3, listener, sensors, rate) || result;
result = this.registerLegacyListener (1, 3, listener, sensors, rate) || result;
result = this.registerLegacyListener (4, 7, listener, sensors, rate) || result;
return result;
}, "android.hardware.SensorListener,~N,~N");
Clazz.defineMethod (c$, "registerLegacyListener", 
($fz = function (legacyType, type, listener, sensors, rate) {
if (listener == null) {
return false;
}var result = false;
if ((sensors & legacyType) != 0) {
var sensor = this.getDefaultSensor (type);
if (sensor != null) {
var legacyListener = null;
{
legacyListener = this.mLegacyListenersMap.get (listener);
if (legacyListener == null) {
legacyListener = Clazz.innerTypeInstance (android.hardware.SensorManager.LegacyListener, this, null, listener);
this.mLegacyListenersMap.put (listener, legacyListener);
}}legacyListener.registerSensor (legacyType);
result = this.registerListener (legacyListener, sensor, rate);
}}return result;
}, $fz.isPrivate = true, $fz), "~N,~N,android.hardware.SensorListener,~N,~N");
Clazz.defineMethod (c$, "unregisterListener", 
function (listener, sensors) {
this.unregisterLegacyListener (2, 1, listener, sensors);
this.unregisterLegacyListener (8, 2, listener, sensors);
this.unregisterLegacyListener (128, 3, listener, sensors);
this.unregisterLegacyListener (1, 3, listener, sensors);
this.unregisterLegacyListener (4, 7, listener, sensors);
}, "android.hardware.SensorListener,~N");
Clazz.defineMethod (c$, "unregisterLegacyListener", 
($fz = function (legacyType, type, listener, sensors) {
if (listener == null) {
return ;
}var legacyListener = null;
{
legacyListener = this.mLegacyListenersMap.get (listener);
}if (legacyListener != null) {
if ((sensors & legacyType) != 0) {
var sensor = this.getDefaultSensor (type);
if (sensor != null) {
if (legacyListener.unregisterSensor (legacyType)) {
this.unregisterListener (legacyListener, sensor);
{
var found = false;
for (var i, $i = android.hardware.SensorManager.sListeners.iterator (); $i.hasNext () && ((i = $i.next ()) || true);) {
if (i.getListener () === legacyListener) {
found = true;
break;
}}
if (!found) {
{
this.mLegacyListenersMap.remove (listener);
}}}}}}}}, $fz.isPrivate = true, $fz), "~N,~N,android.hardware.SensorListener,~N");
Clazz.defineMethod (c$, "unregisterListener", 
function (listener) {
this.unregisterListener (listener, 255);
}, "android.hardware.SensorListener");
Clazz.defineMethod (c$, "unregisterListener", 
function (listener, sensor) {
this.unregisterListener (listener, sensor);
}, "android.hardware.SensorEventListener,android.hardware.Sensor");
Clazz.defineMethod (c$, "unregisterListener", 
function (listener) {
this.unregisterListener (listener);
}, "android.hardware.SensorEventListener");
Clazz.defineMethod (c$, "registerListener", 
function (listener, sensor, rate) {
return this.registerListener (listener, sensor, rate, null);
}, "android.hardware.SensorEventListener,android.hardware.Sensor,~N");
Clazz.defineMethod (c$, "enableSensorLocked", 
($fz = function (sensor, delay) {
var result = false;
for (var i, $i = android.hardware.SensorManager.sListeners.iterator (); $i.hasNext () && ((i = $i.next ()) || true);) {
if (i.hasSensor (sensor)) {
var name = sensor.getName ();
var handle = sensor.getHandle ();
result = android.hardware.SensorManager.sensors_enable_sensor (android.hardware.SensorManager.sQueue, name, handle, delay);
break;
}}
return result;
}, $fz.isPrivate = true, $fz), "android.hardware.Sensor,~N");
Clazz.defineMethod (c$, "disableSensorLocked", 
($fz = function (sensor) {
for (var i, $i = android.hardware.SensorManager.sListeners.iterator (); $i.hasNext () && ((i = $i.next ()) || true);) {
if (i.hasSensor (sensor)) {
return true;
}}
var name = sensor.getName ();
var handle = sensor.getHandle ();
return android.hardware.SensorManager.sensors_enable_sensor (android.hardware.SensorManager.sQueue, name, handle, -1);
}, $fz.isPrivate = true, $fz), "android.hardware.Sensor");
Clazz.defineMethod (c$, "registerListener", 
function (listener, sensor, rate, handler) {
if (listener == null || sensor == null) {
return false;
}var result = true;
var delay = -1;
switch (rate) {
case 0:
delay = 0;
break;
case 1:
delay = 20000;
break;
case 2:
delay = 60000;
break;
case 3:
delay = 200000;
break;
default:
delay = rate;
break;
}
{
var l = null;
for (var i, $i = android.hardware.SensorManager.sListeners.iterator (); $i.hasNext () && ((i = $i.next ()) || true);) {
if (i.getListener () === listener) {
l = i;
break;
}}
if (l == null) {
l = Clazz.innerTypeInstance (android.hardware.SensorManager.ListenerDelegate, this, null, listener, sensor, handler);
android.hardware.SensorManager.sListeners.add (l);
if (!android.hardware.SensorManager.sListeners.isEmpty ()) {
if (android.hardware.SensorManager.sSensorThread.startLocked ()) {
if (!this.enableSensorLocked (sensor, delay)) {
android.hardware.SensorManager.sListeners.remove (l);
result = false;
}} else {
android.hardware.SensorManager.sListeners.remove (l);
result = false;
}} else {
result = false;
}} else {
l.addSensor (sensor);
if (!this.enableSensorLocked (sensor, delay)) {
l.removeSensor (sensor);
result = false;
}}}return result;
}, "android.hardware.SensorEventListener,android.hardware.Sensor,~N,android.os.Handler");
Clazz.defineMethod (c$, "unregisterListener", 
($fz = function (listener, sensor) {
if (listener == null || sensor == null) {
return ;
}{
var size = android.hardware.SensorManager.sListeners.size ();
for (var i = 0; i < size; i++) {
var l = android.hardware.SensorManager.sListeners.get (i);
if (l.getListener () === listener) {
if (l.removeSensor (sensor) == 0) {
android.hardware.SensorManager.sListeners.remove (i);
}break;
}}
this.disableSensorLocked (sensor);
}}, $fz.isPrivate = true, $fz), "~O,android.hardware.Sensor");
Clazz.defineMethod (c$, "unregisterListener", 
($fz = function (listener) {
if (listener == null) {
return ;
}{
var size = android.hardware.SensorManager.sListeners.size ();
for (var i = 0; i < size; i++) {
var l = android.hardware.SensorManager.sListeners.get (i);
if (l.getListener () === listener) {
android.hardware.SensorManager.sListeners.remove (i);
for (var sensor, $sensor = l.getSensors ().iterator (); $sensor.hasNext () && ((sensor = $sensor.next ()) || true);) {
this.disableSensorLocked (sensor);
}
break;
}}
}}, $fz.isPrivate = true, $fz), "~O");
c$.getRotationMatrix = Clazz.defineMethod (c$, "getRotationMatrix", 
function (R, I, gravity, geomagnetic) {
var Ax = gravity[0];
var Ay = gravity[1];
var Az = gravity[2];
var Ex = geomagnetic[0];
var Ey = geomagnetic[1];
var Ez = geomagnetic[2];
var Hx = Ey * Az - Ez * Ay;
var Hy = Ez * Ax - Ex * Az;
var Hz = Ex * Ay - Ey * Ax;
var normH = Math.sqrt (Hx * Hx + Hy * Hy + Hz * Hz);
if (normH < 0.1) {
return false;
}var invH = 1.0 / normH;
Hx *= invH;
Hy *= invH;
Hz *= invH;
var invA = 1.0 / Math.sqrt (Ax * Ax + Ay * Ay + Az * Az);
Ax *= invA;
Ay *= invA;
Az *= invA;
var Mx = Ay * Hz - Az * Hy;
var My = Az * Hx - Ax * Hz;
var Mz = Ax * Hy - Ay * Hx;
if (R != null) {
if (R.length == 9) {
R[0] = Hx;
R[1] = Hy;
R[2] = Hz;
R[3] = Mx;
R[4] = My;
R[5] = Mz;
R[6] = Ax;
R[7] = Ay;
R[8] = Az;
} else if (R.length == 16) {
R[0] = Hx;
R[1] = Hy;
R[2] = Hz;
R[3] = 0;
R[4] = Mx;
R[5] = My;
R[6] = Mz;
R[7] = 0;
R[8] = Ax;
R[9] = Ay;
R[10] = Az;
R[11] = 0;
R[12] = 0;
R[13] = 0;
R[14] = 0;
R[15] = 1;
}}if (I != null) {
var invE = 1.0 / Math.sqrt (Ex * Ex + Ey * Ey + Ez * Ez);
var c = (Ex * Mx + Ey * My + Ez * Mz) * invE;
var s = (Ex * Ax + Ey * Ay + Ez * Az) * invE;
if (I.length == 9) {
I[0] = 1;
I[1] = 0;
I[2] = 0;
I[3] = 0;
I[4] = c;
I[5] = s;
I[6] = 0;
I[7] = -s;
I[8] = c;
} else if (I.length == 16) {
I[0] = 1;
I[1] = 0;
I[2] = 0;
I[4] = 0;
I[5] = c;
I[6] = s;
I[8] = 0;
I[9] = -s;
I[10] = c;
I[3] = I[7] = I[11] = I[12] = I[13] = I[14] = 0;
I[15] = 1;
}}return true;
}, "~A,~A,~A,~A");
c$.getInclination = Clazz.defineMethod (c$, "getInclination", 
function (I) {
if (I.length == 9) {
return Math.atan2 (I[5], I[4]);
} else {
return Math.atan2 (I[6], I[5]);
}}, "~A");
c$.remapCoordinateSystem = Clazz.defineMethod (c$, "remapCoordinateSystem", 
function (inR, X, Y, outR) {
if (inR === outR) {
var temp = android.hardware.SensorManager.mTempMatrix;
{
if (android.hardware.SensorManager.remapCoordinateSystemImpl (inR, X, Y, temp)) {
var size = outR.length;
for (var i = 0; i < size; i++) outR[i] = temp[i];

return true;
}}}return android.hardware.SensorManager.remapCoordinateSystemImpl (inR, X, Y, outR);
}, "~A,~N,~N,~A");
c$.remapCoordinateSystemImpl = Clazz.defineMethod (c$, "remapCoordinateSystemImpl", 
($fz = function (inR, X, Y, outR) {
var length = outR.length;
if (inR.length != length) return false;
if ((X & 0x7C) != 0 || (Y & 0x7C) != 0) return false;
if (((X & 0x3) == 0) || ((Y & 0x3) == 0)) return false;
if ((X & 0x3) == (Y & 0x3)) return false;
var Z = X ^ Y;
var x = (X & 0x3) - 1;
var y = (Y & 0x3) - 1;
var z = (Z & 0x3) - 1;
var axis_y = (z + 1) % 3;
var axis_z = (z + 2) % 3;
if (((x ^ axis_y) | (y ^ axis_z)) != 0) Z ^= 0x80;
var sx = (X >= 0x80);
var sy = (Y >= 0x80);
var sz = (Z >= 0x80);
var rowLength = ((length == 16) ? 4 : 3);
for (var j = 0; j < 3; j++) {
var offset = j * rowLength;
for (var i = 0; i < 3; i++) {
if (x == i) outR[offset + i] = sx ? -inR[offset + 0] : inR[offset + 0];
if (y == i) outR[offset + i] = sy ? -inR[offset + 1] : inR[offset + 1];
if (z == i) outR[offset + i] = sz ? -inR[offset + 2] : inR[offset + 2];
}
}
if (length == 16) {
outR[3] = outR[7] = outR[11] = outR[12] = outR[13] = outR[14] = 0;
outR[15] = 1;
}return true;
}, $fz.isPrivate = true, $fz), "~A,~N,~N,~A");
c$.getOrientation = Clazz.defineMethod (c$, "getOrientation", 
function (R, values) {
if (R.length == 9) {
values[0] = Math.atan2 (R[1], R[4]);
values[1] = Math.asin (-R[7]);
values[2] = Math.atan2 (-R[6], R[8]);
} else {
values[0] = Math.atan2 (R[1], R[5]);
values[1] = Math.asin (-R[9]);
values[2] = Math.atan2 (-R[8], R[10]);
}return values;
}, "~A,~A");
c$.getAltitude = Clazz.defineMethod (c$, "getAltitude", 
function (p0, p) {
var coef = 0.19029495;
return 44330.0 * (1.0 - Math.pow (p / p0, 0.19029495));
}, "~N,~N");
Clazz.defineMethod (c$, "onRotationChanged", 
function (rotation) {
{
($t$ = android.hardware.SensorManager.sRotation = rotation, android.hardware.SensorManager.prototype.sRotation = android.hardware.SensorManager.sRotation, $t$);
}}, "~N");
c$.getRotation = Clazz.defineMethod (c$, "getRotation", 
function () {
{
return android.hardware.SensorManager.sRotation;
}});
c$.getAngleChange = Clazz.defineMethod (c$, "getAngleChange", 
function (angleChange, R, prevR) {
var rd1 = 0;
var rd4 = 0;
var rd6 = 0;
var rd7 = 0;
var rd8 = 0;
var ri0 = 0;
var ri1 = 0;
var ri2 = 0;
var ri3 = 0;
var ri4 = 0;
var ri5 = 0;
var ri6 = 0;
var ri7 = 0;
var ri8 = 0;
var pri0 = 0;
var pri1 = 0;
var pri2 = 0;
var pri3 = 0;
var pri4 = 0;
var pri5 = 0;
var pri6 = 0;
var pri7 = 0;
var pri8 = 0;
var i;
var j;
var k;
if (R.length == 9) {
ri0 = R[0];
ri1 = R[1];
ri2 = R[2];
ri3 = R[3];
ri4 = R[4];
ri5 = R[5];
ri6 = R[6];
ri7 = R[7];
ri8 = R[8];
} else if (R.length == 16) {
ri0 = R[0];
ri1 = R[1];
ri2 = R[2];
ri3 = R[4];
ri4 = R[5];
ri5 = R[6];
ri6 = R[8];
ri7 = R[9];
ri8 = R[10];
}if (prevR.length == 9) {
pri0 = prevR[0];
pri1 = prevR[1];
pri2 = prevR[2];
pri3 = prevR[3];
pri4 = prevR[4];
pri5 = prevR[5];
pri6 = prevR[6];
pri7 = prevR[7];
pri8 = prevR[8];
} else if (prevR.length == 16) {
pri0 = prevR[0];
pri1 = prevR[1];
pri2 = prevR[2];
pri3 = prevR[4];
pri4 = prevR[5];
pri5 = prevR[6];
pri6 = prevR[8];
pri7 = prevR[9];
pri8 = prevR[10];
}rd1 = pri0 * ri1 + pri3 * ri4 + pri6 * ri7;
rd4 = pri1 * ri1 + pri4 * ri4 + pri7 * ri7;
rd6 = pri2 * ri0 + pri5 * ri3 + pri8 * ri6;
rd7 = pri2 * ri1 + pri5 * ri4 + pri8 * ri7;
rd8 = pri2 * ri2 + pri5 * ri5 + pri8 * ri8;
angleChange[0] = Math.atan2 (rd1, rd4);
angleChange[1] = Math.asin (-rd7);
angleChange[2] = Math.atan2 (-rd6, rd8);
}, "~A,~A,~A");
c$.getRotationMatrixFromVector = Clazz.defineMethod (c$, "getRotationMatrixFromVector", 
function (R, rotationVector) {
var q0;
var q1 = rotationVector[0];
var q2 = rotationVector[1];
var q3 = rotationVector[2];
if (rotationVector.length == 4) {
q0 = rotationVector[3];
} else {
q0 = 1 - q1 * q1 - q2 * q2 - q3 * q3;
q0 = (q0 > 0) ? Math.sqrt (q0) : 0;
}var sq_q1 = 2 * q1 * q1;
var sq_q2 = 2 * q2 * q2;
var sq_q3 = 2 * q3 * q3;
var q1_q2 = 2 * q1 * q2;
var q3_q0 = 2 * q3 * q0;
var q1_q3 = 2 * q1 * q3;
var q2_q0 = 2 * q2 * q0;
var q2_q3 = 2 * q2 * q3;
var q1_q0 = 2 * q1 * q0;
if (R.length == 9) {
R[0] = 1 - sq_q2 - sq_q3;
R[1] = q1_q2 - q3_q0;
R[2] = q1_q3 + q2_q0;
R[3] = q1_q2 + q3_q0;
R[4] = 1 - sq_q1 - sq_q3;
R[5] = q2_q3 - q1_q0;
R[6] = q1_q3 - q2_q0;
R[7] = q2_q3 + q1_q0;
R[8] = 1 - sq_q1 - sq_q2;
} else if (R.length == 16) {
R[0] = 1 - sq_q2 - sq_q3;
R[1] = q1_q2 - q3_q0;
R[2] = q1_q3 + q2_q0;
R[3] = 0.0;
R[4] = q1_q2 + q3_q0;
R[5] = 1 - sq_q1 - sq_q3;
R[6] = q2_q3 - q1_q0;
R[7] = 0.0;
R[8] = q1_q3 - q2_q0;
R[9] = q2_q3 + q1_q0;
R[10] = 1 - sq_q1 - sq_q2;
R[11] = 0.0;
R[12] = R[13] = R[14] = 0.0;
R[15] = 1.0;
}}, "~A,~A");
c$.getQuaternionFromVector = Clazz.defineMethod (c$, "getQuaternionFromVector", 
function (Q, rv) {
if (rv.length == 4) {
Q[0] = rv[3];
} else {
Q[0] = 1 - rv[0] * rv[0] - rv[1] * rv[1] - rv[2] * rv[2];
Q[0] = (Q[0] > 0) ? Math.sqrt (Q[0]) : 0;
}Q[1] = rv[0];
Q[2] = rv[1];
Q[3] = rv[2];
}, "~A,~A");
c$.$SensorManager$ListenerDelegate$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mSensorEventListener = null;
this.mSensorList = null;
this.mHandler = null;
this.mValuesPool = null;
this.mSensors = null;
this.mFirstEvent = null;
this.mSensorAccuracies = null;
Clazz.instantialize (this, arguments);
}, android.hardware.SensorManager, "ListenerDelegate");
Clazz.prepareFields (c$, function () {
this.mSensorList =  new java.util.ArrayList ();
this.mSensors =  new android.util.SparseBooleanArray ();
this.mFirstEvent =  new android.util.SparseBooleanArray ();
this.mSensorAccuracies =  new android.util.SparseIntArray ();
});
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.mSensorEventListener = a;
var d = (c != null) ? c.getLooper () : this.b$["android.hardware.SensorManager"].mMainLooper;
this.mHandler = ((Clazz.isClassDefined ("android.hardware.SensorManager$ListenerDelegate$1") ? 0 : android.hardware.SensorManager.ListenerDelegate.$SensorManager$ListenerDelegate$1$ ()), Clazz.innerTypeInstance (android.hardware.SensorManager$ListenerDelegate$1, this, null, d));
this.addSensor (b);
}, "android.hardware.SensorEventListener,android.hardware.Sensor,android.os.Handler");
Clazz.defineMethod (c$, "createSensorEvent", 
function () {
return  new android.hardware.SensorEvent (3);
});
Clazz.defineMethod (c$, "getFromPool", 
function () {
var a = null;
{
a = this.mValuesPool;
this.mValuesPool = null;
}if (a == null) {
a = this.createSensorEvent ();
}return a;
});
Clazz.defineMethod (c$, "returnToPool", 
function (a) {
{
if (this.mValuesPool == null) {
this.mValuesPool = a;
}}}, "android.hardware.SensorEvent");
Clazz.defineMethod (c$, "getListener", 
function () {
return this.mSensorEventListener;
});
Clazz.defineMethod (c$, "addSensor", 
function (a) {
this.mSensors.put (a.getHandle (), true);
this.mSensorList.add (a);
}, "android.hardware.Sensor");
Clazz.defineMethod (c$, "removeSensor", 
function (a) {
this.mSensors.$delete (a.getHandle ());
this.mSensorList.remove (a);
return this.mSensors.size ();
}, "android.hardware.Sensor");
Clazz.defineMethod (c$, "hasSensor", 
function (a) {
return this.mSensors.get (a.getHandle ());
}, "android.hardware.Sensor");
Clazz.defineMethod (c$, "getSensors", 
function () {
return this.mSensorList;
});
Clazz.defineMethod (c$, "onSensorChangedLocked", 
function (a, b, c, d) {
var e = this.getFromPool ();
var f = e.values;
f[0] = b[0];
f[1] = b[1];
f[2] = b[2];
e.timestamp = c[0];
e.accuracy = d;
e.sensor = a;
var g = android.os.Message.obtain ();
g.what = 0;
g.obj = e;
this.mHandler.sendMessage (g);
}, "android.hardware.Sensor,~A,~A,~N");
c$.$SensorManager$ListenerDelegate$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.hardware, "SensorManager$ListenerDelegate$1", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
var b = a.obj;
var c = b.sensor.getHandle ();
switch (b.sensor.getType ()) {
case 2:
case 3:
var d = this.b$["android.hardware.SensorManager.ListenerDelegate"].mSensorAccuracies.get (c);
if ((b.accuracy >= 0) && (d != b.accuracy)) {
this.b$["android.hardware.SensorManager.ListenerDelegate"].mSensorAccuracies.put (c, b.accuracy);
this.b$["android.hardware.SensorManager.ListenerDelegate"].mSensorEventListener.onAccuracyChanged (b.sensor, b.accuracy);
}break;
default:
if (this.b$["android.hardware.SensorManager.ListenerDelegate"].mFirstEvent.get (c) == false) {
this.b$["android.hardware.SensorManager.ListenerDelegate"].mFirstEvent.put (c, true);
this.b$["android.hardware.SensorManager.ListenerDelegate"].mSensorEventListener.onAccuracyChanged (b.sensor, 3);
}break;
}
this.b$["android.hardware.SensorManager.ListenerDelegate"].mSensorEventListener.onSensorChanged (b);
this.b$["android.hardware.SensorManager.ListenerDelegate"].returnToPool (b);
}, "android.os.Message");
c$ = Clazz.p0p ();
};
c$ = Clazz.p0p ();
};
c$.$SensorManager$LegacyListener$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mValues = null;
this.mTarget = null;
this.mSensors = 0;
this.mYawfilter = null;
Clazz.instantialize (this, arguments);
}, android.hardware.SensorManager, "LegacyListener", null, android.hardware.SensorEventListener);
Clazz.prepareFields (c$, function () {
this.mValues =  Clazz.newArray (6, 0);
this.mYawfilter = Clazz.innerTypeInstance (android.hardware.SensorManager.LmsFilter, this, null);
});
Clazz.makeConstructor (c$, 
function (a) {
this.mTarget = a;
this.mSensors = 0;
}, "android.hardware.SensorListener");
Clazz.defineMethod (c$, "registerSensor", 
function (a) {
this.mSensors |= a;
}, "~N");
Clazz.defineMethod (c$, "unregisterSensor", 
function (a) {
this.mSensors &= ~a;
var b = 129;
if (((a & b) != 0) && ((this.mSensors & b) != 0)) {
return false;
}return true;
}, "~N");
Clazz.overrideMethod (c$, "onAccuracyChanged", 
function (a, b) {
try {
this.mTarget.onAccuracyChanged (a.getLegacyType (), b);
} catch (e) {
if (Clazz.instanceOf (e, AbstractMethodError)) {
} else {
throw e;
}
}
}, "android.hardware.Sensor,~N");
Clazz.overrideMethod (c$, "onSensorChanged", 
function (a) {
var b = this.mValues;
b[0] = a.values[0];
b[1] = a.values[1];
b[2] = a.values[2];
var c = a.sensor.getLegacyType ();
this.mapSensorDataToWindow (c, b, android.hardware.SensorManager.getRotation ());
if (a.sensor.getType () == 3) {
if ((this.mSensors & 128) != 0) {
this.mTarget.onSensorChanged (128, b);
}if ((this.mSensors & 1) != 0) {
b[0] = this.mYawfilter.filter (a.timestamp, b[0]);
this.mTarget.onSensorChanged (1, b);
}} else {
this.mTarget.onSensorChanged (c, b);
}}, "android.hardware.SensorEvent");
Clazz.defineMethod (c$, "mapSensorDataToWindow", 
($fz = function (a, b, c) {
var d = b[0];
var e = b[1];
var f = b[2];
switch (a) {
case 1:
case 128:
f = -f;
break;
case 2:
d = -d;
e = -e;
f = -f;
break;
case 8:
d = -d;
e = -e;
break;
}
b[0] = d;
b[1] = e;
b[2] = f;
b[3] = d;
b[4] = e;
b[5] = f;
if ((c & 1) != 0) {
switch (a) {
case 2:
case 8:
b[0] = -e;
b[1] = d;
b[2] = f;
break;
case 1:
case 128:
b[0] = d + ((d < 270) ? 90 : -270);
b[1] = f;
b[2] = e;
break;
}
}if ((c & 2) != 0) {
d = b[0];
e = b[1];
f = b[2];
switch (a) {
case 2:
case 8:
b[0] = -d;
b[1] = -e;
b[2] = f;
break;
case 1:
case 128:
b[0] = (d >= 180) ? (d - 180) : (d + 180);
b[1] = -e;
b[2] = -f;
break;
}
}}, $fz.isPrivate = true, $fz), "~N,~A,~N");
c$ = Clazz.p0p ();
};
c$.$SensorManager$LmsFilter$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mV = null;
this.mT = null;
this.mIndex = 0;
Clazz.instantialize (this, arguments);
}, android.hardware.SensorManager, "LmsFilter");
Clazz.prepareFields (c$, function () {
this.mV =  Clazz.newArray (24, 0);
this.mT =  Clazz.newArray (24, 0);
});
Clazz.makeConstructor (c$, 
function () {
this.mIndex = 12;
});
Clazz.defineMethod (c$, "filter", 
function (a, b) {
var c = b;
var d = 1.0E-9;
var e = a * 1.0E-9;
var f = this.mV[this.mIndex];
if ((c - f) > 180) {
c -= 360;
} else if ((f - c) > 180) {
c += 360;
}this.mIndex++;
if (this.mIndex >= 24) this.mIndex = 12;
this.mV[this.mIndex] = c;
this.mT[this.mIndex] = e;
this.mV[this.mIndex - 12] = c;
this.mT[this.mIndex - 12] = e;
var g;
var h;
var i;
var j;
var k;
var l;
var m;
var n;
g = h = i = j = k = 0;
for (n = 0; n < 11; n++) {
var o = this.mIndex - 1 - n;
var p = this.mV[o];
var q = 0.5 * (this.mT[o] + this.mT[o + 1]) - e;
var r = this.mT[o] - this.mT[o + 1];
r *= r;
g += p * r;
h += q * (q * r);
i += (q * r);
j += p * (q * r);
k += r;
}
m = (g * h + i * j) / (k * h + i * i);
l = (k * m - g) / i;
var o = m + 0.08 * l;
o *= (0.0027777778);
if (((o >= 0) ? o : -o) >= 0.5) o = o - Math.ceil (o + 0.5) + 1.0;
if (o < 0) o += 1.0;
o *= 360.0;
return o;
}, "~N,~N");
Clazz.defineStatics (c$,
"SENSORS_RATE_MS", 20,
"COUNT", 12,
"PREDICTION_RATIO", 0.33333334,
"PREDICTION_TIME", 0.08);
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mThread = null;
this.mSensorsReady = false;
if (!Clazz.isClassDefined ("android.hardware.SensorManager.SensorThread.SensorThreadRunnable")) {
android.hardware.SensorManager.SensorThread.$SensorManager$SensorThread$SensorThreadRunnable$ ();
}
Clazz.instantialize (this, arguments);
}, android.hardware.SensorManager, "SensorThread");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.overrideMethod (c$, "finalize", 
function () {
});
Clazz.defineMethod (c$, "startLocked", 
function () {
try {
if (this.mThread == null) {
this.mSensorsReady = false;
var a = Clazz.innerTypeInstance (android.hardware.SensorManager.SensorThread.SensorThreadRunnable, this, null);
var b =  new Thread (a, android.hardware.SensorManager.SensorThread.getName ());
b.start ();
{
while (this.mSensorsReady == false) {
a.wait ();
}
}this.mThread = b;
}} catch (e) {
if (Clazz.instanceOf (e, InterruptedException)) {
} else {
throw e;
}
}
return this.mThread == null ? false : true;
});
c$.$SensorManager$SensorThread$SensorThreadRunnable$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.hardware.SensorManager.SensorThread, "SensorThreadRunnable", null, Runnable);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "open", 
($fz = function () {
($t$ = android.hardware.SensorManager.sQueue = android.hardware.SensorManager.sensors_create_queue (), android.hardware.SensorManager.prototype.sQueue = android.hardware.SensorManager.sQueue, $t$);
return true;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "run", 
function () {
var a =  Clazz.newArray (3, 0);
var b =  Clazz.newArray (1, 0);
var c =  Clazz.newArray (1, 0);
if (!this.open ()) {
return ;
}{
this.b$["android.hardware.SensorManager.SensorThread"].mSensorsReady = true;
this.notify ();
}while (true) {
var d = android.hardware.SensorManager.sensors_data_poll (android.hardware.SensorManager.sQueue, a, b, c);
var e = b[0];
{
if (d == -1 || android.hardware.SensorManager.sListeners.isEmpty ()) {
if (d == -1 && !android.hardware.SensorManager.sListeners.isEmpty ()) {
android.util.Log.e ("SensorManager", "_sensors_data_poll() failed, we bail out: sensors=" + d);
}android.hardware.SensorManager.sensors_destroy_queue (android.hardware.SensorManager.sQueue);
($t$ = android.hardware.SensorManager.sQueue = 0, android.hardware.SensorManager.prototype.sQueue = android.hardware.SensorManager.sQueue, $t$);
this.b$["android.hardware.SensorManager.SensorThread"].mThread = null;
break;
}var f = android.hardware.SensorManager.sHandleToSensor.get (d);
if (f != null) {
var g = android.hardware.SensorManager.sListeners.size ();
for (var h = 0; h < g; h++) {
var i = android.hardware.SensorManager.sListeners.get (h);
if (i.hasSensor (f)) {
i.onSensorChangedLocked (f, a, c, e);
}}
}}}
});
c$ = Clazz.p0p ();
};
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "SensorManager",
"mTempMatrix",  Clazz.newArray (16, 0),
"SENSOR_ORIENTATION", 1,
"SENSOR_ACCELEROMETER", 2,
"SENSOR_TEMPERATURE", 4,
"SENSOR_MAGNETIC_FIELD", 8,
"SENSOR_LIGHT", 16,
"SENSOR_PROXIMITY", 32,
"SENSOR_TRICORDER", 64,
"SENSOR_ORIENTATION_RAW", 128,
"SENSOR_ALL", 0x7F,
"SENSOR_MIN", 1,
"SENSOR_MAX", (64),
"DATA_X", 0,
"DATA_Y", 1,
"DATA_Z", 2,
"RAW_DATA_INDEX", 3,
"RAW_DATA_X", 3,
"RAW_DATA_Y", 4,
"RAW_DATA_Z", 5,
"STANDARD_GRAVITY", 9.80665,
"GRAVITY_SUN", 275.0,
"GRAVITY_MERCURY", 3.70,
"GRAVITY_VENUS", 8.87,
"GRAVITY_EARTH", 9.80665,
"GRAVITY_MOON", 1.6,
"GRAVITY_MARS", 3.71,
"GRAVITY_JUPITER", 23.12,
"GRAVITY_SATURN", 8.96,
"GRAVITY_URANUS", 8.69,
"GRAVITY_NEPTUNE", 11.0,
"GRAVITY_PLUTO", 0.6,
"GRAVITY_DEATH_STAR_I", 0.000000353036145,
"GRAVITY_THE_ISLAND", 4.815162342,
"MAGNETIC_FIELD_EARTH_MAX", 60.0,
"MAGNETIC_FIELD_EARTH_MIN", 30.0,
"PRESSURE_STANDARD_ATMOSPHERE", 1013.25,
"LIGHT_SUNLIGHT_MAX", 120000.0,
"LIGHT_SUNLIGHT", 110000.0,
"LIGHT_SHADE", 20000.0,
"LIGHT_OVERCAST", 10000.0,
"LIGHT_SUNRISE", 400.0,
"LIGHT_CLOUDY", 100.0,
"LIGHT_FULLMOON", 0.25,
"LIGHT_NO_MOON", 0.001,
"SENSOR_DELAY_FASTEST", 0,
"SENSOR_DELAY_GAME", 1,
"SENSOR_DELAY_UI", 2,
"SENSOR_DELAY_NORMAL", 3,
"SENSOR_STATUS_UNRELIABLE", 0,
"SENSOR_STATUS_ACCURACY_LOW", 1,
"SENSOR_STATUS_ACCURACY_MEDIUM", 2,
"SENSOR_STATUS_ACCURACY_HIGH", 3,
"AXIS_X", 1,
"AXIS_Y", 2,
"AXIS_Z", 3,
"AXIS_MINUS_X", 129,
"AXIS_MINUS_Y", 130,
"AXIS_MINUS_Z", 131,
"SENSOR_DISABLE", -1,
"sSensorModuleInitialized", false);
c$.sFullSensorsList = c$.prototype.sFullSensorsList =  new java.util.ArrayList ();
c$.sSensorListByType = c$.prototype.sSensorListByType =  new android.util.SparseArray ();
Clazz.defineStatics (c$,
"sWindowManager", null,
"sRotation", 0,
"sSensorThread", null,
"sQueue", 0);
c$.sHandleToSensor = c$.prototype.sHandleToSensor =  new android.util.SparseArray ();
c$.sListeners = c$.prototype.sListeners =  new java.util.ArrayList ();
});
