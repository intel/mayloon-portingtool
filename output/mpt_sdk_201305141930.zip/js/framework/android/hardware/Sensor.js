﻿Clazz.declarePackage ("android.hardware");
c$ = Clazz.decorateAsClass (function () {
this.mName = null;
this.mVendor = null;
this.mVersion = 0;
this.mHandle = 0;
this.mType = 0;
this.mMaxRange = 0;
this.mResolution = 0;
this.mPower = 0;
this.mMinDelay = 0;
this.mLegacyType = 0;
Clazz.instantialize (this, arguments);
}, android.hardware, "Sensor");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "getName", 
function () {
return this.mName;
});
Clazz.defineMethod (c$, "getVendor", 
function () {
return this.mVendor;
});
Clazz.defineMethod (c$, "getType", 
function () {
return this.mType;
});
Clazz.defineMethod (c$, "getVersion", 
function () {
return this.mVersion;
});
Clazz.defineMethod (c$, "getMaximumRange", 
function () {
return this.mMaxRange;
});
Clazz.defineMethod (c$, "getResolution", 
function () {
return this.mResolution;
});
Clazz.defineMethod (c$, "getPower", 
function () {
return this.mPower;
});
Clazz.defineMethod (c$, "getMinDelay", 
function () {
return this.mMinDelay;
});
Clazz.defineMethod (c$, "getHandle", 
function () {
return this.mHandle;
});
Clazz.defineMethod (c$, "setRange", 
function (max, res) {
this.mMaxRange = max;
this.mResolution = res;
}, "~N,~N");
Clazz.defineMethod (c$, "setLegacyType", 
function (legacyType) {
this.mLegacyType = legacyType;
}, "~N");
Clazz.defineMethod (c$, "getLegacyType", 
function () {
return this.mLegacyType;
});
Clazz.defineStatics (c$,
"TYPE_ACCELEROMETER", 1,
"TYPE_MAGNETIC_FIELD", 2,
"TYPE_ORIENTATION", 3,
"TYPE_GYROSCOPE", 4,
"TYPE_LIGHT", 5,
"TYPE_PRESSURE", 6,
"TYPE_TEMPERATURE", 7,
"TYPE_PROXIMITY", 8,
"TYPE_GRAVITY", 9,
"TYPE_LINEAR_ACCELERATION", 10,
"TYPE_ROTATION_VECTOR", 11,
"TYPE_RELATIVE_HUMIDITY", 12,
"TYPE_ALL", -1);
