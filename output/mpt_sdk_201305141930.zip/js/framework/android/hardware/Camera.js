﻿Clazz.declarePackage ("android.hardware");
Clazz.load (["android.os.Handler"], "android.hardware.Camera", ["android.os.Looper", "$.Message", "android.util.Base64", "$.Log", "android.view.HTML5Event", "java.lang.Double", "$.Float", "$.IllegalArgumentException", "$.Long", "$.StringBuilder", "java.util.ArrayList", "$.HashMap", "$.StringTokenizer"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mNativeContext = 0;
this.mEventHandler = null;
this.mShutterCallback = null;
this.mRawImageCallback = null;
this.mJpegCallback = null;
this.mPreviewCallback = null;
this.mPostviewCallback = null;
this.mAutoFocusCallback = null;
this.mZoomListener = null;
this.mErrorCallback = null;
this.mOneShot = false;
this.mWithBuffer = false;
this.fgcanvasid = null;
if (!Clazz.isClassDefined ("android.hardware.Camera.EventHandler")) {
android.hardware.Camera.$Camera$EventHandler$ ();
}
if (!Clazz.isClassDefined ("android.hardware.Camera.Size")) {
android.hardware.Camera.$Camera$Size$ ();
}
if (!Clazz.isClassDefined ("android.hardware.Camera.Parameters")) {
android.hardware.Camera.$Camera$Parameters$ ();
}
Clazz.instantialize (this, arguments);
}, android.hardware, "Camera");
c$.getNumberOfCameras = Clazz.defineMethod (c$, "getNumberOfCameras", 
function () {
return 0;
});
c$.open = Clazz.defineMethod (c$, "open", 
function (cameraId) {
return  new android.hardware.Camera (cameraId);
}, "~N");
c$.open = Clazz.defineMethod (c$, "open", 
function () {
return  new android.hardware.Camera (0);
});
Clazz.makeConstructor (c$, 
function (cameraId) {
this.mShutterCallback = null;
this.mRawImageCallback = null;
this.mJpegCallback = null;
this.mPreviewCallback = null;
this.mPostviewCallback = null;
this.mZoomListener = null;
this.fgcanvasid = null;
var looper;
if ((looper = android.os.Looper.myLooper ()) != null) {
this.mEventHandler = Clazz.innerTypeInstance (android.hardware.Camera.EventHandler, this, null, this, looper);
} else if ((looper = android.os.Looper.getMainLooper ()) != null) {
this.mEventHandler = Clazz.innerTypeInstance (android.hardware.Camera.EventHandler, this, null, this, looper);
} else {
this.mEventHandler = null;
}}, "~N");
Clazz.overrideMethod (c$, "finalize", 
function () {
this.native_release ();
});
Clazz.defineMethod (c$, "release", 
function () {
this.native_release ();
});
Clazz.defineMethod (c$, "setPreviewDisplay", 
function (holder) {
this.fgcanvasid = holder.getCanvasID ();
android.util.Log.v ("fgcanvasid", this.fgcanvasid);
var viewRootId = "";
var fgcanvas = document.getElementById(this.fgcanvasid);
videoview = document.createElement("video");
videoview.id = "1987";
videoview.style.position = "absolute";
videoview.style.zIndex = fgcanvas.style.zIndex;
videoview.style.width = fgcanvas.parentNode.style.width;
videoview.style.height = fgcanvas.parentNode.style.height;
videoview.style.left = fgcanvas.parentNode.style.left;
videoview.style.top = fgcanvas.parentNode.style.top;
videoview.autoplay = "autoplay";
fgcanvas.parentNode.appendChild(videoview);
viewRootId = fgcanvas.parentNode.id;
android.util.Log.v ("viewRootId", viewRootId);
android.util.Log.d ("Camera", "Attaching handlers");
for (var i = 0; i < android.view.HTML5Event.eventType.length; i++) {
var eventTypeName = android.view.HTML5Event.eventType[i];
videoview.addEventListener(eventTypeName, this.eventForwarder, true);
}
}, "android.view.SurfaceHolder");
Clazz.defineMethod (c$, "startPreview", 
function () {
var url;
var video = document.getElementById("1987");
navigator.webkitGetUserMedia("video", function(s){url = webkitURL.createObjectURL(s);alert("create url: " + url);video.src = url;}, function(e){alert("error: " + e.name);});
alert("Requested access to local media");
});
Clazz.defineMethod (c$, "stopPreview", 
function () {
});
Clazz.defineMethod (c$, "setPreviewCallback", 
function (cb) {
this.mPreviewCallback = cb;
this.mOneShot = false;
this.mWithBuffer = false;
this.setHasPreviewCallback (cb != null, false);
}, "android.hardware.Camera.PreviewCallback");
Clazz.defineMethod (c$, "setOneShotPreviewCallback", 
function (cb) {
this.mPreviewCallback = cb;
this.mOneShot = true;
this.mWithBuffer = false;
this.setHasPreviewCallback (cb != null, false);
}, "android.hardware.Camera.PreviewCallback");
Clazz.defineMethod (c$, "setPreviewCallbackWithBuffer", 
function (cb) {
this.mPreviewCallback = cb;
this.mOneShot = false;
this.mWithBuffer = true;
this.setHasPreviewCallback (cb != null, true);
}, "android.hardware.Camera.PreviewCallback");
Clazz.defineMethod (c$, "autoFocus", 
function (cb) {
this.mAutoFocusCallback = cb;
this.native_autoFocus ();
}, "android.hardware.Camera.AutoFocusCallback");
Clazz.defineMethod (c$, "cancelAutoFocus", 
function () {
this.mAutoFocusCallback = null;
this.native_cancelAutoFocus ();
});
Clazz.defineMethod (c$, "takePicture", 
function (shutter, raw, jpeg) {
this.takePicture (shutter, raw, null, jpeg);
}, "android.hardware.Camera.ShutterCallback,android.hardware.Camera.PictureCallback,android.hardware.Camera.PictureCallback");
Clazz.defineMethod (c$, "takePicture", 
function (shutter, raw, postview, jpeg) {
this.mShutterCallback = shutter;
this.mRawImageCallback = raw;
this.mPostviewCallback = postview;
this.mJpegCallback = jpeg;
var data = "";
var temp = document.getElementById(this.fgcanvasid);
var video = document.getElementById("1987");
var height = parseInt(temp.parentNode.style.height)- 50;
var width = parseInt(temp.parentNode.style.width);
temp.style.zIndex = 101;
var ctx = temp.getContext('2d');
ctx.fillStyle = "#ffffff";
//  * ctx.fillRect(0, 0, width, height);
ctx.drawImage(video, 320, 240, 640, 480);   //640,480 should be the width and height of the imageview, but imageview.getwidth() and imageview.getheight()are not implemented.
var imgData = temp.toDataURL("image/png");
data = imgData.substr(22);
var imageByte = android.util.Base64.decode (data, 0);
var msg =  new android.os.Message ();
msg.what = 256;
msg.obj = imageByte;
this.mEventHandler.sendMessage (msg);
android.util.Log.v ("sendMessage", "CAMERA_MSG_COMPRESSED_IMAGE");
}, "android.hardware.Camera.ShutterCallback,android.hardware.Camera.PictureCallback,android.hardware.Camera.PictureCallback,android.hardware.Camera.PictureCallback");
Clazz.defineMethod (c$, "setZoomChangeListener", 
function (listener) {
this.mZoomListener = listener;
}, "android.hardware.Camera.OnZoomChangeListener");
Clazz.defineMethod (c$, "setErrorCallback", 
function (cb) {
this.mErrorCallback = cb;
}, "android.hardware.Camera.ErrorCallback");
Clazz.defineMethod (c$, "setParameters", 
function (params) {
this.native_setParameters (params.flatten ());
}, "android.hardware.Camera.Parameters");
Clazz.defineMethod (c$, "getParameters", 
function () {
return null;
});
c$.$Camera$EventHandler$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mCamera = null;
Clazz.instantialize (this, arguments);
}, android.hardware.Camera, "EventHandler", android.os.Handler);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.hardware.Camera.EventHandler, [b]);
this.mCamera = a;
}, "android.hardware.Camera,android.os.Looper");
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
switch (a.what) {
case 2:
if (this.b$["android.hardware.Camera"].mShutterCallback != null) {
this.b$["android.hardware.Camera"].mShutterCallback.onShutter ();
}return ;
case 128:
if (this.b$["android.hardware.Camera"].mRawImageCallback != null) {
this.b$["android.hardware.Camera"].mRawImageCallback.onPictureTaken (a.obj, this.mCamera);
}return ;
case 256:
if (this.b$["android.hardware.Camera"].mJpegCallback != null) {
this.b$["android.hardware.Camera"].mJpegCallback.onPictureTaken (a.obj, this.mCamera);
}return ;
case 16:
if (this.b$["android.hardware.Camera"].mPreviewCallback != null) {
var b = this.b$["android.hardware.Camera"].mPreviewCallback;
if (this.b$["android.hardware.Camera"].mOneShot) {
this.b$["android.hardware.Camera"].mPreviewCallback = null;
} else if (!this.b$["android.hardware.Camera"].mWithBuffer) {
this.b$["android.hardware.Camera"].setHasPreviewCallback (true, false);
}b.onPreviewFrame (a.obj, this.mCamera);
}return ;
case 64:
android.util.Log.v ("catch message", "");
if (this.b$["android.hardware.Camera"].mPostviewCallback != null) {
this.b$["android.hardware.Camera"].mPostviewCallback.onPictureTaken (a.obj, this.mCamera);
android.util.Log.v ("mPostviewCallback.onPictureTaken", "");
}return ;
case 4:
if (this.b$["android.hardware.Camera"].mAutoFocusCallback != null) {
this.b$["android.hardware.Camera"].mAutoFocusCallback.onAutoFocus (a.arg1 == 0 ? false : true, this.mCamera);
}return ;
case 8:
if (this.b$["android.hardware.Camera"].mZoomListener != null) {
this.b$["android.hardware.Camera"].mZoomListener.onZoomChange (a.arg1, a.arg2 != 0, this.mCamera);
}return ;
case 1:
android.util.Log.e ("Camera", "Error " + a.arg1);
if (this.b$["android.hardware.Camera"].mErrorCallback != null) {
this.b$["android.hardware.Camera"].mErrorCallback.onError (a.arg1, this.mCamera);
}return ;
default:
android.util.Log.e ("Camera", "Unknown message type " + a.what);
return ;
}
}, "android.os.Message");
c$ = Clazz.p0p ();
};
c$.$Camera$Size$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.width = 0;
this.height = 0;
Clazz.instantialize (this, arguments);
}, android.hardware.Camera, "Size");
Clazz.makeConstructor (c$, 
function (a, b) {
this.width = a;
this.height = b;
}, "~N,~N");
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (!(Clazz.instanceOf (a, android.hardware.Camera.Size))) {
return false;
}var b = a;
return this.width == b.width && this.height == b.height;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.width * 32713 + this.height;
});
c$ = Clazz.p0p ();
};
c$.$Camera$Parameters$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mMap = null;
Clazz.instantialize (this, arguments);
}, android.hardware.Camera, "Parameters");
Clazz.defineMethod (c$, "dump", 
function () {
android.util.Log.e ("Camera", "dump: size=" + this.mMap.size ());
for (var k, $k = this.mMap.keySet ().iterator (); $k.hasNext () && ((k = $k.next ()) || true);) {
android.util.Log.e ("Camera", "dump: " + k + "=" + this.mMap.get (k));
}
});
Clazz.defineMethod (c$, "flatten", 
function () {
var a =  new StringBuilder ();
for (var k, $k = this.mMap.keySet ().iterator (); $k.hasNext () && ((k = $k.next ()) || true);) {
a.append (k);
a.append ("=");
a.append (this.mMap.get (k));
a.append (";");
}
a.deleteCharAt (a.length () - 1);
return a.toString ();
});
Clazz.defineMethod (c$, "unflatten", 
function (a) {
this.mMap.clear ();
var b =  new java.util.StringTokenizer (a, ";");
while (b.hasMoreElements ()) {
var c = b.nextToken ();
var d = c.indexOf ('=');
if (d == -1) {
continue ;}var e = c.substring (0, d);
var f = c.substring (d + 1);
this.mMap.put (e, f);
}
}, "~S");
Clazz.defineMethod (c$, "remove", 
function (a) {
this.mMap.remove (a);
}, "~S");
Clazz.defineMethod (c$, "set", 
function (a, b) {
if (a.indexOf ('=') != -1 || a.indexOf (';') != -1) {
android.util.Log.e ("Camera", "Key \"" + a + "\" contains invalid character (= or ;)");
return ;
}if (b.indexOf ('=') != -1 || b.indexOf (';') != -1) {
android.util.Log.e ("Camera", "Value \"" + b + "\" contains invalid character (= or ;)");
return ;
}this.mMap.put (a, b);
}, "~S,~S");
Clazz.defineMethod (c$, "set", 
function (a, b) {
this.mMap.put (a, Integer.toString (b));
}, "~S,~N");
Clazz.defineMethod (c$, "get", 
function (a) {
return this.mMap.get (a);
}, "~S");
Clazz.defineMethod (c$, "getInt", 
function (a) {
return Integer.parseInt (this.mMap.get (a));
}, "~S");
Clazz.defineMethod (c$, "setPreviewSize", 
function (a, b) {
var c = Integer.toString (a) + "x" + Integer.toString (b);
this.set ("preview-size", c);
}, "~N,~N");
Clazz.defineMethod (c$, "getPreviewSize", 
function () {
var a = this.get ("preview-size");
return this.strToSize (a);
});
Clazz.defineMethod (c$, "getSupportedPreviewSizes", 
function () {
var a = this.get ("preview-size-values");
return this.splitSize (a);
});
Clazz.defineMethod (c$, "setJpegThumbnailSize", 
function (a, b) {
this.set ("jpeg-thumbnail-width", a);
this.set ("jpeg-thumbnail-height", b);
}, "~N,~N");
Clazz.defineMethod (c$, "getJpegThumbnailSize", 
function () {
return Clazz.innerTypeInstance (android.hardware.Camera.Size, this, null, this.getInt ("jpeg-thumbnail-width"), this.getInt ("jpeg-thumbnail-height"));
});
Clazz.defineMethod (c$, "getSupportedJpegThumbnailSizes", 
function () {
var a = this.get ("jpeg-thumbnail-size-values");
return this.splitSize (a);
});
Clazz.defineMethod (c$, "setJpegThumbnailQuality", 
function (a) {
this.set ("jpeg-thumbnail-quality", a);
}, "~N");
Clazz.defineMethod (c$, "getJpegThumbnailQuality", 
function () {
return this.getInt ("jpeg-thumbnail-quality");
});
Clazz.defineMethod (c$, "setJpegQuality", 
function (a) {
this.set ("jpeg-quality", a);
}, "~N");
Clazz.defineMethod (c$, "getJpegQuality", 
function () {
return this.getInt ("jpeg-quality");
});
Clazz.defineMethod (c$, "setPreviewFrameRate", 
function (a) {
this.set ("preview-frame-rate", a);
}, "~N");
Clazz.defineMethod (c$, "getPreviewFrameRate", 
function () {
return this.getInt ("preview-frame-rate");
});
Clazz.defineMethod (c$, "getSupportedPreviewFrameRates", 
function () {
var a = this.get ("preview-frame-rate-values");
return this.splitInt (a);
});
Clazz.defineMethod (c$, "setPreviewFpsRange", 
function (a, b) {
this.set ("preview-fps-range", "" + a + "," + b);
}, "~N,~N");
Clazz.defineMethod (c$, "getPreviewFpsRange", 
function (a) {
if (a == null || a.length != 2) {
throw  new IllegalArgumentException ("range must be an array with two elements.");
}this.splitInt (this.get ("preview-fps-range"), a);
}, "~A");
Clazz.defineMethod (c$, "getSupportedPreviewFpsRange", 
function () {
var a = this.get ("preview-fps-range-values");
return this.splitRange (a);
});
Clazz.defineMethod (c$, "setPictureSize", 
function (a, b) {
var c = Integer.toString (a) + "x" + Integer.toString (b);
this.set ("picture-size", c);
}, "~N,~N");
Clazz.defineMethod (c$, "getPictureSize", 
function () {
var a = this.get ("picture-size");
return this.strToSize (a);
});
Clazz.defineMethod (c$, "getSupportedPictureSizes", 
function () {
var a = this.get ("picture-size-values");
return this.splitSize (a);
});
Clazz.defineMethod (c$, "setRotation", 
function (a) {
if (a == 0 || a == 90 || a == 180 || a == 270) {
this.set ("rotation", Integer.toString (a));
} else {
throw  new IllegalArgumentException ("Invalid rotation=" + a);
}}, "~N");
Clazz.defineMethod (c$, "setGpsLatitude", 
function (a) {
this.set ("gps-latitude", Double.toString (a));
}, "~N");
Clazz.defineMethod (c$, "setGpsLongitude", 
function (a) {
this.set ("gps-longitude", Double.toString (a));
}, "~N");
Clazz.defineMethod (c$, "setGpsAltitude", 
function (a) {
this.set ("gps-altitude", Double.toString (a));
}, "~N");
Clazz.defineMethod (c$, "setGpsTimestamp", 
function (a) {
this.set ("gps-timestamp", Long.toString (a));
}, "~N");
Clazz.defineMethod (c$, "setGpsProcessingMethod", 
function (a) {
this.set ("gps-processing-method", a);
}, "~S");
Clazz.defineMethod (c$, "removeGpsData", 
function () {
this.remove ("gps-latitude");
this.remove ("gps-longitude");
this.remove ("gps-altitude");
this.remove ("gps-timestamp");
this.remove ("gps-processing-method");
});
Clazz.defineMethod (c$, "getWhiteBalance", 
function () {
return this.get ("whitebalance");
});
Clazz.defineMethod (c$, "setWhiteBalance", 
function (a) {
this.set ("whitebalance", a);
}, "~S");
Clazz.defineMethod (c$, "getSupportedWhiteBalance", 
function () {
var a = this.get ("whitebalance-values");
return this.split (a);
});
Clazz.defineMethod (c$, "getColorEffect", 
function () {
return this.get ("effect");
});
Clazz.defineMethod (c$, "setColorEffect", 
function (a) {
this.set ("effect", a);
}, "~S");
Clazz.defineMethod (c$, "getSupportedColorEffects", 
function () {
var a = this.get ("effect-values");
return this.split (a);
});
Clazz.defineMethod (c$, "getAntibanding", 
function () {
return this.get ("antibanding");
});
Clazz.defineMethod (c$, "setAntibanding", 
function (a) {
this.set ("antibanding", a);
}, "~S");
Clazz.defineMethod (c$, "getSupportedAntibanding", 
function () {
var a = this.get ("antibanding-values");
return this.split (a);
});
Clazz.defineMethod (c$, "getSceneMode", 
function () {
return this.get ("scene-mode");
});
Clazz.defineMethod (c$, "setSceneMode", 
function (a) {
this.set ("scene-mode", a);
}, "~S");
Clazz.defineMethod (c$, "getSupportedSceneModes", 
function () {
var a = this.get ("scene-mode-values");
return this.split (a);
});
Clazz.defineMethod (c$, "getFlashMode", 
function () {
return this.get ("flash-mode");
});
Clazz.defineMethod (c$, "setFlashMode", 
function (a) {
this.set ("flash-mode", a);
}, "~S");
Clazz.defineMethod (c$, "getSupportedFlashModes", 
function () {
var a = this.get ("flash-mode-values");
return this.split (a);
});
Clazz.defineMethod (c$, "getFocusMode", 
function () {
return this.get ("focus-mode");
});
Clazz.defineMethod (c$, "setFocusMode", 
function (a) {
this.set ("focus-mode", a);
}, "~S");
Clazz.defineMethod (c$, "getSupportedFocusModes", 
function () {
var a = this.get ("focus-mode-values");
return this.split (a);
});
Clazz.defineMethod (c$, "getFocalLength", 
function () {
return Float.parseFloat (this.get ("focal-length"));
});
Clazz.defineMethod (c$, "getHorizontalViewAngle", 
function () {
return Float.parseFloat (this.get ("horizontal-view-angle"));
});
Clazz.defineMethod (c$, "getVerticalViewAngle", 
function () {
return Float.parseFloat (this.get ("vertical-view-angle"));
});
Clazz.defineMethod (c$, "getExposureCompensation", 
function () {
return this.getInt ("exposure-compensation", 0);
});
Clazz.defineMethod (c$, "setExposureCompensation", 
function (a) {
this.set ("exposure-compensation", a);
}, "~N");
Clazz.defineMethod (c$, "getMaxExposureCompensation", 
function () {
return this.getInt ("max-exposure-compensation", 0);
});
Clazz.defineMethod (c$, "getMinExposureCompensation", 
function () {
return this.getInt ("min-exposure-compensation", 0);
});
Clazz.defineMethod (c$, "getExposureCompensationStep", 
function () {
return this.getFloat ("exposure-compensation-step", 0);
});
Clazz.defineMethod (c$, "getZoom", 
function () {
return this.getInt ("zoom", 0);
});
Clazz.defineMethod (c$, "setZoom", 
function (a) {
this.set ("zoom", a);
}, "~N");
Clazz.defineMethod (c$, "isZoomSupported", 
function () {
var a = this.get ("zoom-supported");
return "true".equals (a);
});
Clazz.defineMethod (c$, "getMaxZoom", 
function () {
return this.getInt ("max-zoom", 0);
});
Clazz.defineMethod (c$, "getZoomRatios", 
function () {
return this.splitInt (this.get ("zoom-ratios"));
});
Clazz.defineMethod (c$, "isSmoothZoomSupported", 
function () {
var a = this.get ("smooth-zoom-supported");
return "true".equals (a);
});
Clazz.defineMethod (c$, "getFocusDistances", 
function (a) {
if (a == null || a.length != 3) {
throw  new IllegalArgumentException ("output must be an float array with three elements.");
}this.splitFloat (this.get ("focus-distances"), a);
}, "~A");
Clazz.defineMethod (c$, "split", 
($fz = function (a) {
if (a == null) return null;
var b =  new java.util.StringTokenizer (a, ",");
var c =  new java.util.ArrayList ();
while (b.hasMoreElements ()) {
c.add (b.nextToken ());
}
return c;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "splitInt", 
($fz = function (a) {
if (a == null) return null;
var b =  new java.util.StringTokenizer (a, ",");
var c =  new java.util.ArrayList ();
while (b.hasMoreElements ()) {
var d = b.nextToken ();
c.add (new Integer (Integer.parseInt (d)));
}
if (c.size () == 0) return null;
return c;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "splitInt", 
($fz = function (a, b) {
if (a == null) return ;
var c =  new java.util.StringTokenizer (a, ",");
var d = 0;
while (c.hasMoreElements ()) {
var e = c.nextToken ();
b[d++] = Integer.parseInt (e);
}
}, $fz.isPrivate = true, $fz), "~S,~A");
Clazz.defineMethod (c$, "splitFloat", 
($fz = function (a, b) {
if (a == null) return ;
var c =  new java.util.StringTokenizer (a, ",");
var d = 0;
while (c.hasMoreElements ()) {
var e = c.nextToken ();
b[d++] = Float.parseFloat (e);
}
}, $fz.isPrivate = true, $fz), "~S,~A");
Clazz.defineMethod (c$, "getFloat", 
($fz = function (a, b) {
try {
return Float.parseFloat (this.mMap.get (a));
} catch (ex) {
if (Clazz.instanceOf (ex, NumberFormatException)) {
return b;
} else {
throw ex;
}
}
}, $fz.isPrivate = true, $fz), "~S,~N");
Clazz.defineMethod (c$, "getInt", 
($fz = function (a, b) {
try {
return Integer.parseInt (this.mMap.get (a));
} catch (ex) {
if (Clazz.instanceOf (ex, NumberFormatException)) {
return b;
} else {
throw ex;
}
}
}, $fz.isPrivate = true, $fz), "~S,~N");
Clazz.defineMethod (c$, "splitSize", 
($fz = function (a) {
if (a == null) return null;
var b =  new java.util.StringTokenizer (a, ",");
var c =  new java.util.ArrayList ();
while (b.hasMoreElements ()) {
var d = this.strToSize (b.nextToken ());
if (d != null) c.add (d);
}
if (c.size () == 0) return null;
return c;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "strToSize", 
($fz = function (a) {
if (a == null) return null;
var b = a.indexOf ('x');
if (b != -1) {
var c = a.substring (0, b);
var d = a.substring (b + 1);
return Clazz.innerTypeInstance (android.hardware.Camera.Size, this, null, Integer.parseInt (c), Integer.parseInt (d));
}android.util.Log.e ("Camera", "Invalid size parameter string=" + a);
return null;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "splitRange", 
($fz = function (a) {
if (a == null || (a.charAt (0)).charCodeAt (0) != ('(').charCodeAt (0) || (a.charAt (a.length - 1)).charCodeAt (0) != (')').charCodeAt (0)) {
android.util.Log.e ("Camera", "Invalid range list string=" + a);
return null;
}var b =  new java.util.ArrayList ();
var c;
var d = 1;
do {
var e =  Clazz.newArray (2, 0);
c = a.indexOf ("),(", d);
if (c == -1) c = a.length - 1;
this.splitInt (a.substring (d, c), e);
b.add (e);
d = c + 3;
} while (c != a.length - 1);
if (b.size () == 0) return null;
return b;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineStatics (c$,
"KEY_PREVIEW_SIZE", "preview-size",
"KEY_PREVIEW_FORMAT", "preview-format",
"KEY_PREVIEW_FRAME_RATE", "preview-frame-rate",
"KEY_PREVIEW_FPS_RANGE", "preview-fps-range",
"KEY_PICTURE_SIZE", "picture-size",
"KEY_PICTURE_FORMAT", "picture-format",
"KEY_JPEG_THUMBNAIL_SIZE", "jpeg-thumbnail-size",
"KEY_JPEG_THUMBNAIL_WIDTH", "jpeg-thumbnail-width",
"KEY_JPEG_THUMBNAIL_HEIGHT", "jpeg-thumbnail-height",
"KEY_JPEG_THUMBNAIL_QUALITY", "jpeg-thumbnail-quality",
"KEY_JPEG_QUALITY", "jpeg-quality",
"KEY_ROTATION", "rotation",
"KEY_GPS_LATITUDE", "gps-latitude",
"KEY_GPS_LONGITUDE", "gps-longitude",
"KEY_GPS_ALTITUDE", "gps-altitude",
"KEY_GPS_TIMESTAMP", "gps-timestamp",
"KEY_GPS_PROCESSING_METHOD", "gps-processing-method",
"KEY_WHITE_BALANCE", "whitebalance",
"KEY_EFFECT", "effect",
"KEY_ANTIBANDING", "antibanding",
"KEY_SCENE_MODE", "scene-mode",
"KEY_FLASH_MODE", "flash-mode",
"KEY_FOCUS_MODE", "focus-mode",
"KEY_FOCAL_LENGTH", "focal-length",
"KEY_HORIZONTAL_VIEW_ANGLE", "horizontal-view-angle",
"KEY_VERTICAL_VIEW_ANGLE", "vertical-view-angle",
"KEY_EXPOSURE_COMPENSATION", "exposure-compensation",
"KEY_MAX_EXPOSURE_COMPENSATION", "max-exposure-compensation",
"KEY_MIN_EXPOSURE_COMPENSATION", "min-exposure-compensation",
"KEY_EXPOSURE_COMPENSATION_STEP", "exposure-compensation-step",
"KEY_ZOOM", "zoom",
"KEY_MAX_ZOOM", "max-zoom",
"KEY_ZOOM_RATIOS", "zoom-ratios",
"KEY_ZOOM_SUPPORTED", "zoom-supported",
"KEY_SMOOTH_ZOOM_SUPPORTED", "smooth-zoom-supported",
"KEY_FOCUS_DISTANCES", "focus-distances",
"SUPPORTED_VALUES_SUFFIX", "-values",
"TRUE", "true",
"WHITE_BALANCE_AUTO", "auto",
"WHITE_BALANCE_INCANDESCENT", "incandescent",
"WHITE_BALANCE_FLUORESCENT", "fluorescent",
"WHITE_BALANCE_WARM_FLUORESCENT", "warm-fluorescent",
"WHITE_BALANCE_DAYLIGHT", "daylight",
"WHITE_BALANCE_CLOUDY_DAYLIGHT", "cloudy-daylight",
"WHITE_BALANCE_TWILIGHT", "twilight",
"WHITE_BALANCE_SHADE", "shade",
"EFFECT_NONE", "none",
"EFFECT_MONO", "mono",
"EFFECT_NEGATIVE", "negative",
"EFFECT_SOLARIZE", "solarize",
"EFFECT_SEPIA", "sepia",
"EFFECT_POSTERIZE", "posterize",
"EFFECT_WHITEBOARD", "whiteboard",
"EFFECT_BLACKBOARD", "blackboard",
"EFFECT_AQUA", "aqua",
"ANTIBANDING_AUTO", "auto",
"ANTIBANDING_50HZ", "50hz",
"ANTIBANDING_60HZ", "60hz",
"ANTIBANDING_OFF", "off",
"FLASH_MODE_OFF", "off",
"FLASH_MODE_AUTO", "auto",
"FLASH_MODE_ON", "on",
"FLASH_MODE_RED_EYE", "red-eye",
"FLASH_MODE_TORCH", "torch",
"SCENE_MODE_AUTO", "auto",
"SCENE_MODE_ACTION", "action",
"SCENE_MODE_PORTRAIT", "portrait",
"SCENE_MODE_LANDSCAPE", "landscape",
"SCENE_MODE_NIGHT", "night",
"SCENE_MODE_NIGHT_PORTRAIT", "night-portrait",
"SCENE_MODE_THEATRE", "theatre",
"SCENE_MODE_BEACH", "beach",
"SCENE_MODE_SNOW", "snow",
"SCENE_MODE_SUNSET", "sunset",
"SCENE_MODE_STEADYPHOTO", "steadyphoto",
"SCENE_MODE_FIREWORKS", "fireworks",
"SCENE_MODE_SPORTS", "sports",
"SCENE_MODE_PARTY", "party",
"SCENE_MODE_CANDLELIGHT", "candlelight",
"SCENE_MODE_BARCODE", "barcode",
"FOCUS_MODE_AUTO", "auto",
"FOCUS_MODE_INFINITY", "infinity",
"FOCUS_MODE_MACRO", "macro",
"FOCUS_MODE_FIXED", "fixed",
"FOCUS_MODE_EDOF", "edof",
"FOCUS_MODE_CONTINUOUS_VIDEO", "continuous-video",
"FOCUS_DISTANCE_NEAR_INDEX", 0,
"FOCUS_DISTANCE_OPTIMAL_INDEX", 1,
"FOCUS_DISTANCE_FAR_INDEX", 2,
"PREVIEW_FPS_MIN_INDEX", 0,
"PREVIEW_FPS_MAX_INDEX", 1,
"PIXEL_FORMAT_YUV422SP", "yuv422sp",
"PIXEL_FORMAT_YUV420SP", "yuv420sp",
"PIXEL_FORMAT_YUV422I", "yuv422i-yuyv",
"PIXEL_FORMAT_RGB565", "rgb565",
"PIXEL_FORMAT_JPEG", "jpeg");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.facing = 0;
this.orientation = 0;
Clazz.instantialize (this, arguments);
}, android.hardware.Camera, "CameraInfo");
Clazz.defineStatics (c$,
"CAMERA_FACING_BACK", 0,
"CAMERA_FACING_FRONT", 1);
c$ = Clazz.p0p ();
Clazz.declareInterface (android.hardware.Camera, "PreviewCallback");
Clazz.declareInterface (android.hardware.Camera, "AutoFocusCallback");
Clazz.declareInterface (android.hardware.Camera, "ShutterCallback");
Clazz.declareInterface (android.hardware.Camera, "PictureCallback");
Clazz.declareInterface (android.hardware.Camera, "OnZoomChangeListener");
Clazz.declareInterface (android.hardware.Camera, "ErrorCallback");
Clazz.defineStatics (c$,
"TAG", "Camera",
"CAMERA_MSG_ERROR", 0x001,
"CAMERA_MSG_SHUTTER", 0x002,
"CAMERA_MSG_FOCUS", 0x004,
"CAMERA_MSG_ZOOM", 0x008,
"CAMERA_MSG_PREVIEW_FRAME", 0x010,
"CAMERA_MSG_VIDEO_FRAME", 0x020,
"CAMERA_MSG_POSTVIEW_FRAME", 0x040,
"CAMERA_MSG_RAW_IMAGE", 0x080,
"CAMERA_MSG_COMPRESSED_IMAGE", 0x100,
"CAMERA_MSG_ALL_MSGS", 0x1FF,
"CAMERA_ERROR_UNKNOWN", 1,
"CAMERA_ERROR_SERVER_DIED", 100);
});
