﻿Clazz.declarePackage ("android.hardware");
c$ = Clazz.decorateAsClass (function () {
this.values = null;
this.sensor = null;
this.accuracy = 0;
this.timestamp = 0;
Clazz.instantialize (this, arguments);
}, android.hardware, "SensorEvent");
Clazz.makeConstructor (c$, 
function (size) {
this.values =  Clazz.newArray (size, 0);
}, "~N");
