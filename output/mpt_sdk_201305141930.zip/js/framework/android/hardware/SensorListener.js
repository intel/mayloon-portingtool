﻿Clazz.declarePackage ("android.hardware");
Clazz.declareInterface (android.hardware, "SensorListener");
