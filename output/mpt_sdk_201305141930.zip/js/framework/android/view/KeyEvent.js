﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.os.Parcelable", "android.view.InputEvent", "android.util.SparseIntArray"], "android.view.KeyEvent", ["android.util.Log", "android.view.KeyCharacterMap", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mMetaState = 0;
this.mAction = 0;
this.mKeyCode = 0;
this.mScanCode = 0;
this.mRepeatCount = 0;
this.mFlags = 0;
this.mDownTime = 0;
this.mEventTime = 0;
this.mCharacters = null;
Clazz.instantialize (this, arguments);
}, android.view, "KeyEvent", android.view.InputEvent, android.os.Parcelable);
c$.getMaxKeyCode = Clazz.defineMethod (c$, "getMaxKeyCode", 
function () {
return 110;
});
c$.getDeadChar = Clazz.defineMethod (c$, "getDeadChar", 
function (accent, c) {
return android.view.KeyCharacterMap.getDeadChar (accent, c);
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (action, code) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mAction = action;
this.mKeyCode = code;
this.mRepeatCount = 0;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (downTime, eventTime, action, code, repeat) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mDownTime = downTime;
this.mEventTime = eventTime;
this.mAction = action;
this.mKeyCode = code;
this.mRepeatCount = repeat;
}, "~N,~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (downTime, eventTime, action, code, repeat, metaState) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mDownTime = downTime;
this.mEventTime = eventTime;
this.mAction = action;
this.mKeyCode = code;
this.mRepeatCount = repeat;
this.mMetaState = metaState;
}, "~N,~N,~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (downTime, eventTime, action, code, repeat, metaState, deviceId, scancode) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mDownTime = downTime;
this.mEventTime = eventTime;
this.mAction = action;
this.mKeyCode = code;
this.mRepeatCount = repeat;
this.mMetaState = metaState;
this.mDeviceId = deviceId;
this.mScanCode = scancode;
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (downTime, eventTime, action, code, repeat, metaState, deviceId, scancode, flags) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mDownTime = downTime;
this.mEventTime = eventTime;
this.mAction = action;
this.mKeyCode = code;
this.mRepeatCount = repeat;
this.mMetaState = metaState;
this.mDeviceId = deviceId;
this.mScanCode = scancode;
this.mFlags = flags;
}, "~N,~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (downTime, eventTime, action, code, repeat, metaState, deviceId, scancode, flags, source) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mDownTime = downTime;
this.mEventTime = eventTime;
this.mAction = action;
this.mKeyCode = code;
this.mRepeatCount = repeat;
this.mMetaState = metaState;
this.mDeviceId = deviceId;
this.mScanCode = scancode;
this.mFlags = flags;
this.mSource = source;
}, "~N,~N,~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (time, characters, deviceId, flags) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mDownTime = time;
this.mEventTime = time;
this.mCharacters = characters;
this.mAction = 2;
this.mKeyCode = 0;
this.mRepeatCount = 0;
this.mDeviceId = deviceId;
this.mFlags = flags;
this.mSource = 257;
}, "~N,~S,~N,~N");
Clazz.makeConstructor (c$, 
function (origEvent) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mDownTime = origEvent.mDownTime;
this.mEventTime = origEvent.mEventTime;
this.mAction = origEvent.mAction;
this.mKeyCode = origEvent.mKeyCode;
this.mRepeatCount = origEvent.mRepeatCount;
this.mMetaState = origEvent.mMetaState;
this.mDeviceId = origEvent.mDeviceId;
this.mSource = origEvent.mSource;
this.mScanCode = origEvent.mScanCode;
this.mFlags = origEvent.mFlags;
this.mCharacters = origEvent.mCharacters;
}, "android.view.KeyEvent");
Clazz.makeConstructor (c$, 
function (origEvent, eventTime, newRepeat) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mDownTime = origEvent.mDownTime;
this.mEventTime = eventTime;
this.mAction = origEvent.mAction;
this.mKeyCode = origEvent.mKeyCode;
this.mRepeatCount = newRepeat;
this.mMetaState = origEvent.mMetaState;
this.mDeviceId = origEvent.mDeviceId;
this.mSource = origEvent.mSource;
this.mScanCode = origEvent.mScanCode;
this.mFlags = origEvent.mFlags;
this.mCharacters = origEvent.mCharacters;
}, "android.view.KeyEvent,~N,~N");
c$.changeTimeRepeat = Clazz.defineMethod (c$, "changeTimeRepeat", 
function (event, eventTime, newRepeat) {
return  new android.view.KeyEvent (event, eventTime, newRepeat);
}, "android.view.KeyEvent,~N,~N");
c$.changeTimeRepeat = Clazz.defineMethod (c$, "changeTimeRepeat", 
function (event, eventTime, newRepeat, newFlags) {
var ret =  new android.view.KeyEvent (event);
ret.mEventTime = eventTime;
ret.mRepeatCount = newRepeat;
ret.mFlags = newFlags;
return ret;
}, "android.view.KeyEvent,~N,~N,~N");
Clazz.makeConstructor (c$, 
($fz = function (origEvent, action) {
Clazz.superConstructor (this, android.view.KeyEvent, []);
this.mDownTime = origEvent.mDownTime;
this.mEventTime = origEvent.mEventTime;
this.mAction = action;
this.mKeyCode = origEvent.mKeyCode;
this.mRepeatCount = origEvent.mRepeatCount;
this.mMetaState = origEvent.mMetaState;
this.mDeviceId = origEvent.mDeviceId;
this.mSource = origEvent.mSource;
this.mScanCode = origEvent.mScanCode;
this.mFlags = origEvent.mFlags;
}, $fz.isPrivate = true, $fz), "android.view.KeyEvent,~N");
c$.changeAction = Clazz.defineMethod (c$, "changeAction", 
function (event, action) {
return  new android.view.KeyEvent (event, action);
}, "android.view.KeyEvent,~N");
c$.changeFlags = Clazz.defineMethod (c$, "changeFlags", 
function (event, flags) {
event =  new android.view.KeyEvent (event);
event.mFlags = flags;
return event;
}, "android.view.KeyEvent,~N");
Clazz.defineMethod (c$, "isDown", 
function () {
return this.mAction == 0;
});
Clazz.defineMethod (c$, "isSystem", 
function () {
return this.native_isSystemKey (this.mKeyCode);
});
Clazz.defineMethod (c$, "hasDefaultAction", 
function () {
return this.native_hasDefaultAction (this.mKeyCode);
});
Clazz.defineMethod (c$, "getMetaState", 
function () {
return this.mMetaState;
});
Clazz.defineMethod (c$, "getFlags", 
function () {
return this.mFlags;
});
c$.isModifierKey = Clazz.defineMethod (c$, "isModifierKey", 
function (keyCode) {
return keyCode == 59 || keyCode == 60 || keyCode == 57 || keyCode == 58 || keyCode == 63;
}, "~N");
Clazz.defineMethod (c$, "isAltPressed", 
function () {
return (this.mMetaState & 2) != 0;
});
Clazz.defineMethod (c$, "isShiftPressed", 
function () {
return (this.mMetaState & 1) != 0;
});
Clazz.defineMethod (c$, "isSymPressed", 
function () {
return (this.mMetaState & 4) != 0;
});
Clazz.defineMethod (c$, "getAction", 
function () {
return this.mAction;
});
Clazz.defineMethod (c$, "isCanceled", 
function () {
return (this.mFlags & 32) != 0;
});
Clazz.defineMethod (c$, "startTracking", 
function () {
this.mFlags |= 1073741824;
});
Clazz.defineMethod (c$, "isTracking", 
function () {
return (this.mFlags & 512) != 0;
});
Clazz.defineMethod (c$, "isLongPress", 
function () {
return (this.mFlags & 128) != 0;
});
Clazz.defineMethod (c$, "getKeyCode", 
function () {
return this.mKeyCode;
});
Clazz.defineMethod (c$, "getCharacters", 
function () {
return this.mCharacters;
});
Clazz.defineMethod (c$, "getScanCode", 
function () {
return this.mScanCode;
});
Clazz.defineMethod (c$, "getRepeatCount", 
function () {
return this.mRepeatCount;
});
Clazz.defineMethod (c$, "getDownTime", 
function () {
return this.mDownTime;
});
Clazz.defineMethod (c$, "getEventTime", 
function () {
return this.mEventTime;
});
Clazz.defineMethod (c$, "getKeyboardDevice", 
function () {
return this.mDeviceId;
});
Clazz.defineMethod (c$, "getDisplayLabel", 
function () {
return android.view.KeyCharacterMap.load (this.mDeviceId).getDisplayLabel (this.mKeyCode);
});
Clazz.defineMethod (c$, "getKeyData", 
function (results) {
return android.view.KeyCharacterMap.load (this.mDeviceId).getKeyData (this.mKeyCode, results);
}, "android.view.KeyCharacterMap.KeyData");
Clazz.defineMethod (c$, "getMatch", 
function (chars) {
return this.getMatch (chars, 0);
}, "~A");
Clazz.defineMethod (c$, "getMatch", 
function (chars, modifiers) {
return android.view.KeyCharacterMap.load (this.mDeviceId).getMatch (this.mKeyCode, chars, modifiers);
}, "~A,~N");
Clazz.defineMethod (c$, "getNumber", 
function () {
return android.view.KeyCharacterMap.load (this.mDeviceId).getNumber (this.mKeyCode);
});
Clazz.defineMethod (c$, "dispatch", 
function (receiver) {
return this.dispatch (receiver, null, null);
}, "android.view.KeyEvent.Callback");
Clazz.defineMethod (c$, "dispatch", 
function (receiver, state, target) {
switch (this.mAction) {
case 0:
{
if (false) System.out.println ("Event dispatch ACTION_DOWN");
this.mFlags &= -1073741825;
if (false) android.util.Log.v ("KeyEvent", "Key down to " + target + " in " + state + ": " + this);
var res = receiver.onKeyDown (this.mKeyCode, this);
if (state != null) {
if (res && this.mRepeatCount == 0 && (this.mFlags & 1073741824) != 0) {
if (false) android.util.Log.v ("KeyEvent", "  Start tracking!");
state.startTracking (this, target);
} else if (this.isLongPress () && state.isTracking (this)) {
try {
if (receiver.onKeyLongPress (this.mKeyCode, this)) {
if (false) android.util.Log.v ("KeyEvent", "  Clear from long press!");
state.performedLongPress (this);
res = true;
}} catch (e) {
if (Clazz.instanceOf (e, AbstractMethodError)) {
} else {
throw e;
}
}
}}return res;
}case 1:
if (false) System.out.println ("Event dispatch ACTION_UP");
if (false) android.util.Log.v ("KeyEvent", "Key up to " + target + " in " + state + ": " + this);
if (state != null) {
state.handleUpEvent (this);
}return receiver.onKeyUp (this.mKeyCode, this);
case 2:
var count = this.mRepeatCount;
var code = this.mKeyCode;
if (receiver.onKeyMultiple (code, count, this)) {
return true;
}if (code != 0) {
this.mAction = 0;
this.mRepeatCount = 0;
var handled = receiver.onKeyDown (code, this);
if (handled) {
this.mAction = 1;
receiver.onKeyUp (code, this);
}this.mAction = 2;
this.mRepeatCount = count;
return handled;
}return false;
}
return false;
}, "android.view.KeyEvent.Callback,android.view.KeyEvent.DispatcherState,~O");
Clazz.overrideMethod (c$, "toString", 
function () {
return "KeyEvent{action=" + this.mAction + " code=" + this.mKeyCode + " repeat=" + this.mRepeatCount + " meta=" + this.mMetaState + " scancode=" + this.mScanCode + " mFlags=" + this.mFlags + "}";
});
Clazz.defineMethod (c$, "getUnicodeChar", 
function (meta) {
console.log("Missing method: getUnicodeChar");
}, "~N");
Clazz.defineMethod (c$, "getUnicodeChar", 
function () {
console.log("Missing method: getUnicodeChar");
});
Clazz.defineMethod (c$, "isPrintingKey", 
function () {
console.log("Missing method: isPrintingKey");
});
Clazz.declareInterface (android.view.KeyEvent, "Callback");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mDownKeyCode = 0;
this.mDownTarget = null;
this.mActiveLongPresses = null;
Clazz.instantialize (this, arguments);
}, android.view.KeyEvent, "DispatcherState");
Clazz.prepareFields (c$, function () {
this.mActiveLongPresses =  new android.util.SparseIntArray ();
});
Clazz.defineMethod (c$, "reset", 
function () {
if (false) android.util.Log.v ("KeyEvent", "Reset: " + this);
this.mDownKeyCode = 0;
this.mDownTarget = null;
this.mActiveLongPresses.clear ();
});
Clazz.defineMethod (c$, "reset", 
function (a) {
if (this.mDownTarget === a) {
if (false) android.util.Log.v ("KeyEvent", "Reset in " + a + ": " + this);
this.mDownKeyCode = 0;
this.mDownTarget = null;
}}, "~O");
Clazz.defineMethod (c$, "startTracking", 
function (a, b) {
if (a.getAction () != 0) {
throw  new IllegalArgumentException ("Can only start tracking on a down event");
}if (false) android.util.Log.v ("KeyEvent", "Start trackingt in " + b + ": " + this);
this.mDownKeyCode = a.getKeyCode ();
this.mDownTarget = b;
}, "android.view.KeyEvent,~O");
Clazz.defineMethod (c$, "isTracking", 
function (a) {
return this.mDownKeyCode == a.getKeyCode ();
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "performedLongPress", 
function (a) {
this.mActiveLongPresses.put (a.getKeyCode (), 1);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "handleUpEvent", 
function (a) {
var b = a.getKeyCode ();
if (false) android.util.Log.v ("KeyEvent", "Handle key up " + a + ": " + this);
var c = this.mActiveLongPresses.indexOfKey (b);
if (c >= 0) {
if (false) android.util.Log.v ("KeyEvent", "  Index: " + c);
a.mFlags |= 288;
this.mActiveLongPresses.removeAt (c);
}if (this.mDownKeyCode == b) {
if (false) android.util.Log.v ("KeyEvent", "  Tracking!");
a.mFlags |= 512;
this.mDownKeyCode = 0;
this.mDownTarget = null;
}}, "android.view.KeyEvent");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"KEYCODE_UNKNOWN", 0,
"KEYCODE_SOFT_LEFT", 1,
"KEYCODE_SOFT_RIGHT", 2,
"KEYCODE_HOME", 3,
"KEYCODE_CALL", 5,
"KEYCODE_ENDCALL", 6,
"KEYCODE_0", 48,
"KEYCODE_1", 49,
"KEYCODE_2", 50,
"KEYCODE_3", 51,
"KEYCODE_4", 52,
"KEYCODE_5", 53,
"KEYCODE_6", 54,
"KEYCODE_7", 55,
"KEYCODE_8", 56,
"KEYCODE_9", 57,
"KEYCODE_STAR", 17,
"KEYCODE_POUND", 18,
"KEYCODE_DPAD_CENTER", 23,
"KEYCODE_VOLUME_UP", 24,
"KEYCODE_VOLUME_DOWN", 25,
"KEYCODE_POWER", 26,
"KEYCODE_CAMERA", 27,
"KEYCODE_CLEAR", 28,
"KEYCODE_DPAD_UP", 38,
"KEYCODE_DPAD_DOWN", 40,
"KEYCODE_DPAD_LEFT", 37,
"KEYCODE_DPAD_RIGHT", 39,
"KEYCODE_A", 65,
"KEYCODE_B", 66,
"KEYCODE_C", 67,
"KEYCODE_D", 68,
"KEYCODE_E", 69,
"KEYCODE_F", 70,
"KEYCODE_G", 71,
"KEYCODE_H", 72,
"KEYCODE_I", 73,
"KEYCODE_J", 74,
"KEYCODE_K", 75,
"KEYCODE_L", 76,
"KEYCODE_M", 77,
"KEYCODE_N", 78,
"KEYCODE_O", 79,
"KEYCODE_P", 80,
"KEYCODE_Q", 81,
"KEYCODE_R", 82,
"KEYCODE_S", 83,
"KEYCODE_T", 84,
"KEYCODE_U", 85,
"KEYCODE_V", 86,
"KEYCODE_W", 87,
"KEYCODE_X", 88,
"KEYCODE_Y", 89,
"KEYCODE_Z", 90,
"KEYCODE_COMMA", 55,
"KEYCODE_PERIOD", 56,
"KEYCODE_ALT_LEFT", 57,
"KEYCODE_ALT_RIGHT", 58,
"KEYCODE_SHIFT_LEFT", 59,
"KEYCODE_SHIFT_RIGHT", 60,
"KEYCODE_TAB", 61,
"KEYCODE_SPACE", 62,
"KEYCODE_SYM", 63,
"KEYCODE_EXPLORER", 64,
"KEYCODE_ENVELOPE", 65,
"KEYCODE_ENTER", 13,
"KEYCODE_DEL", 46,
"KEYCODE_GRAVE", 68,
"KEYCODE_MINUS", 69,
"KEYCODE_EQUALS", 70,
"KEYCODE_LEFT_BRACKET", 71,
"KEYCODE_RIGHT_BRACKET", 72,
"KEYCODE_BACKSLASH", 73,
"KEYCODE_SEMICOLON", 74,
"KEYCODE_APOSTROPHE", 75,
"KEYCODE_SLASH", 76,
"KEYCODE_AT", 77,
"KEYCODE_NUM", 78,
"KEYCODE_HEADSETHOOK", 79,
"KEYCODE_FOCUS", 80,
"KEYCODE_PLUS", 81,
"KEYCODE_NOTIFICATION", 83,
"KEYCODE_SEARCH", 84,
"KEYCODE_MEDIA_PLAY_PAUSE", 85,
"KEYCODE_MEDIA_STOP", 86,
"KEYCODE_MEDIA_NEXT", 87,
"KEYCODE_MEDIA_PREVIOUS", 88,
"KEYCODE_MEDIA_REWIND", 89,
"KEYCODE_MEDIA_FAST_FORWARD", 90,
"KEYCODE_MUTE", 91,
"KEYCODE_PAGE_UP", 92,
"KEYCODE_PAGE_DOWN", 93,
"KEYCODE_PICTSYMBOLS", 94,
"KEYCODE_SWITCH_CHARSET", 95,
"KEYCODE_BUTTON_A", 96,
"KEYCODE_BUTTON_B", 97,
"KEYCODE_BUTTON_C", 98,
"KEYCODE_BUTTON_X", 99,
"KEYCODE_BUTTON_Y", 100,
"KEYCODE_BUTTON_Z", 101,
"KEYCODE_BUTTON_L1", 102,
"KEYCODE_BUTTON_R1", 103,
"KEYCODE_BUTTON_L2", 104,
"KEYCODE_BUTTON_R2", 105,
"KEYCODE_BUTTON_THUMBL", 106,
"KEYCODE_BUTTON_THUMBR", 107,
"KEYCODE_BUTTON_START", 108,
"KEYCODE_BUTTON_SELECT", 109,
"KEYCODE_BUTTON_MODE", 110,
"KEYCODE_BACK", 115,
"KEYCODE_MENU", 118,
"LAST_KEYCODE", 110,
"MAX_KEYCODE", 84,
"ACTION_DOWN", 0,
"ACTION_UP", 1,
"ACTION_MULTIPLE", 2,
"META_ALT_ON", 0x02,
"META_ALT_LEFT_ON", 0x10,
"META_ALT_RIGHT_ON", 0x20,
"META_SHIFT_ON", 0x1,
"META_SHIFT_LEFT_ON", 0x40,
"META_SHIFT_RIGHT_ON", 0x80,
"META_SYM_ON", 0x4,
"FLAG_WOKE_HERE", 0x1,
"FLAG_SOFT_KEYBOARD", 0x2,
"FLAG_KEEP_TOUCH_MODE", 0x4,
"FLAG_FROM_SYSTEM", 0x8,
"FLAG_EDITOR_ACTION", 0x10,
"FLAG_CANCELED", 0x20,
"FLAG_VIRTUAL_HARD_KEY", 0x40,
"FLAG_LONG_PRESS", 0x80,
"FLAG_CANCELED_LONG_PRESS", 0x100,
"FLAG_TRACKING", 0x200,
"FLAG_START_TRACKING", 0x40000000,
"DEBUG", false,
"TAG", "KeyEvent");
});
