﻿Clazz.declarePackage ("android.view");
c$ = Clazz.decorateAsClass (function () {
this.mClient = 0;
Clazz.instantialize (this, arguments);
}, android.view, "SurfaceSession");
Clazz.makeConstructor (c$, 
function () {
this.init ();
});
Clazz.defineMethod (c$, "kill", 
function () {
});
Clazz.overrideMethod (c$, "finalize", 
function () {
this.destroy ();
});
Clazz.defineMethod (c$, "init", 
($fz = function () {
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "destroy", 
($fz = function () {
}, $fz.isPrivate = true, $fz));
