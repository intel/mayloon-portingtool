﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.util.SparseArray"], "android.view.ViewConfiguration", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mEdgeSlop = 0;
this.mFadingEdgeLength = 0;
this.mMinimumFlingVelocity = 0;
this.mMaximumFlingVelocity = 0;
this.mScrollbarSize = 0;
this.mTouchSlop = 0;
this.mPagingTouchSlop = 0;
this.mDoubleTapSlop = 0;
this.mWindowTouchSlop = 0;
this.mMaximumDrawingCacheSize = 0;
this.mOverscrollDistance = 0;
this.mOverflingDistance = 0;
Clazz.instantialize (this, arguments);
}, android.view, "ViewConfiguration");
Clazz.makeConstructor (c$, 
function () {
this.mEdgeSlop = 12;
this.mFadingEdgeLength = 12;
this.mMinimumFlingVelocity = 50;
this.mMaximumFlingVelocity = 4000;
this.mScrollbarSize = 10;
this.mTouchSlop = 16;
this.mPagingTouchSlop = 32;
this.mDoubleTapSlop = 100;
this.mWindowTouchSlop = 16;
this.mMaximumDrawingCacheSize = 614400;
this.mOverscrollDistance = 0;
this.mOverflingDistance = 4;
});
Clazz.makeConstructor (c$, 
($fz = function (context) {
var metrics = context.getResources ().getDisplayMetrics ();
var density = metrics.density;
this.mEdgeSlop = Math.round ((density * 12 + 0.5));
this.mFadingEdgeLength = Math.round ((density * 12 + 0.5));
this.mMinimumFlingVelocity = Math.round ((density * 50 + 0.5));
this.mMaximumFlingVelocity = Math.round ((density * 4000 + 0.5));
this.mScrollbarSize = Math.round ((density * 10 + 0.5));
this.mTouchSlop = Math.round ((density * 16 + 0.5));
this.mPagingTouchSlop = Math.round ((density * 32 + 0.5));
this.mDoubleTapSlop = Math.round ((density * 100 + 0.5));
this.mWindowTouchSlop = Math.round ((density * 16 + 0.5));
this.mMaximumDrawingCacheSize = 4 * metrics.widthPixels * metrics.heightPixels;
this.mOverscrollDistance = Math.round ((density * 0 + 0.5));
this.mOverflingDistance = Math.round ((density * 4 + 0.5));
}, $fz.isPrivate = true, $fz), "android.content.Context");
c$.get = Clazz.defineMethod (c$, "get", 
function (context) {
var metrics = context.getResources ().getDisplayMetrics ();
var density = Math.round ((100.0 * metrics.density));
var configuration = android.view.ViewConfiguration.sConfigurations.get (density);
if (configuration == null) {
configuration =  new android.view.ViewConfiguration (context);
android.view.ViewConfiguration.sConfigurations.put (density, configuration);
}return configuration;
}, "android.content.Context");
c$.getScrollBarSize = Clazz.defineMethod (c$, "getScrollBarSize", 
function () {
return 10;
});
Clazz.defineMethod (c$, "getScaledScrollBarSize", 
function () {
return this.mScrollbarSize;
});
c$.getScrollBarFadeDuration = Clazz.defineMethod (c$, "getScrollBarFadeDuration", 
function () {
return 250;
});
c$.getScrollDefaultDelay = Clazz.defineMethod (c$, "getScrollDefaultDelay", 
function () {
return 300;
});
c$.getFadingEdgeLength = Clazz.defineMethod (c$, "getFadingEdgeLength", 
function () {
return 12;
});
Clazz.defineMethod (c$, "getScaledFadingEdgeLength", 
function () {
return this.mFadingEdgeLength;
});
c$.getPressedStateDuration = Clazz.defineMethod (c$, "getPressedStateDuration", 
function () {
return 125;
});
c$.getLongPressTimeout = Clazz.defineMethod (c$, "getLongPressTimeout", 
function () {
return 500;
});
c$.getTapTimeout = Clazz.defineMethod (c$, "getTapTimeout", 
function () {
return 115;
});
c$.getJumpTapTimeout = Clazz.defineMethod (c$, "getJumpTapTimeout", 
function () {
return 500;
});
c$.getDoubleTapTimeout = Clazz.defineMethod (c$, "getDoubleTapTimeout", 
function () {
return 300;
});
c$.getEdgeSlop = Clazz.defineMethod (c$, "getEdgeSlop", 
function () {
return 12;
});
Clazz.defineMethod (c$, "getScaledEdgeSlop", 
function () {
return this.mEdgeSlop;
});
c$.getTouchSlop = Clazz.defineMethod (c$, "getTouchSlop", 
function () {
return 16;
});
Clazz.defineMethod (c$, "getScaledTouchSlop", 
function () {
return this.mTouchSlop;
});
Clazz.defineMethod (c$, "getScaledPagingTouchSlop", 
function () {
return this.mPagingTouchSlop;
});
c$.getDoubleTapSlop = Clazz.defineMethod (c$, "getDoubleTapSlop", 
function () {
return 100;
});
Clazz.defineMethod (c$, "getScaledDoubleTapSlop", 
function () {
return this.mDoubleTapSlop;
});
c$.getWindowTouchSlop = Clazz.defineMethod (c$, "getWindowTouchSlop", 
function () {
return 16;
});
Clazz.defineMethod (c$, "getScaledWindowTouchSlop", 
function () {
return this.mWindowTouchSlop;
});
c$.getMinimumFlingVelocity = Clazz.defineMethod (c$, "getMinimumFlingVelocity", 
function () {
return 50;
});
Clazz.defineMethod (c$, "getScaledMinimumFlingVelocity", 
function () {
return this.mMinimumFlingVelocity;
});
c$.getMaximumFlingVelocity = Clazz.defineMethod (c$, "getMaximumFlingVelocity", 
function () {
return 4000;
});
Clazz.defineMethod (c$, "getScaledMaximumFlingVelocity", 
function () {
return this.mMaximumFlingVelocity;
});
c$.getMaximumDrawingCacheSize = Clazz.defineMethod (c$, "getMaximumDrawingCacheSize", 
function () {
return 614400;
});
Clazz.defineMethod (c$, "getScaledMaximumDrawingCacheSize", 
function () {
return this.mMaximumDrawingCacheSize;
});
Clazz.defineMethod (c$, "getScaledOverscrollDistance", 
function () {
return this.mOverscrollDistance;
});
Clazz.defineMethod (c$, "getScaledOverflingDistance", 
function () {
return this.mOverflingDistance;
});
c$.getZoomControlsTimeout = Clazz.defineMethod (c$, "getZoomControlsTimeout", 
function () {
return 3000;
});
c$.getGlobalActionKeyTimeout = Clazz.defineMethod (c$, "getGlobalActionKeyTimeout", 
function () {
return 500;
});
c$.getScrollFriction = Clazz.defineMethod (c$, "getScrollFriction", 
function () {
return android.view.ViewConfiguration.SCROLL_FRICTION;
});
Clazz.defineStatics (c$,
"SCROLL_BAR_SIZE", 10,
"SCROLL_BAR_FADE_DURATION", 250,
"SCROLL_BAR_DEFAULT_DELAY", 300,
"FADING_EDGE_LENGTH", 12,
"PRESSED_STATE_DURATION", 125,
"LONG_PRESS_TIMEOUT", 500,
"GLOBAL_ACTIONS_KEY_TIMEOUT", 500,
"TAP_TIMEOUT", 115,
"JUMP_TAP_TIMEOUT", 500,
"DOUBLE_TAP_TIMEOUT", 300,
"ZOOM_CONTROLS_TIMEOUT", 3000,
"EDGE_SLOP", 12,
"TOUCH_SLOP", 16,
"PAGING_TOUCH_SLOP", 32,
"DOUBLE_TAP_SLOP", 100,
"WINDOW_TOUCH_SLOP", 16,
"MINIMUM_FLING_VELOCITY", 50,
"MAXIMUM_FLING_VELOCITY", 4000,
"MAXIMUM_DRAWING_CACHE_SIZE", 614400,
"SCROLL_FRICTION", 0.015,
"OVERSCROLL_DISTANCE", 0,
"OVERFLING_DISTANCE", 4);
c$.sConfigurations = c$.prototype.sConfigurations =  new android.util.SparseArray (2);
});
