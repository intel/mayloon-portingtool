﻿Clazz.declarePackage ("android.view");
Clazz.load (null, "android.view.InputQueue", ["java.lang.IllegalArgumentException", "$.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mChannel = null;
Clazz.instantialize (this, arguments);
}, android.view, "InputQueue");
Clazz.makeConstructor (c$, 
function (channel) {
this.mChannel = channel;
}, "android.view.InputChannel");
Clazz.defineMethod (c$, "getInputChannel", 
function () {
return this.mChannel;
});
c$.registerInputChannel = Clazz.defineMethod (c$, "registerInputChannel", 
function (inputChannel, inputHandler, messageQueue) {
if (inputChannel == null) {
throw  new IllegalArgumentException ("inputChannel must not be null");
}if (inputHandler == null) {
throw  new IllegalArgumentException ("inputHandler must not be null");
}if (messageQueue == null) {
throw  new IllegalArgumentException ("messageQueue must not be null");
}{
android.view.InputQueue.nativeRegisterInputChannel (inputChannel, inputHandler, messageQueue);
}}, "android.view.InputChannel,android.view.InputHandler,android.os.MessageQueue");
c$.unregisterInputChannel = Clazz.defineMethod (c$, "unregisterInputChannel", 
function (inputChannel) {
if (inputChannel == null) {
throw  new IllegalArgumentException ("inputChannel must not be null");
}{
android.view.InputQueue.nativeUnregisterInputChannel (inputChannel);
}}, "android.view.InputChannel");
Clazz.declareInterface (android.view.InputQueue, "Callback");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mRecycleNext = null;
this.mFinishedToken = 0;
Clazz.instantialize (this, arguments);
}, android.view.InputQueue, "FinishedCallback", null, Runnable);
Clazz.makeConstructor (c$, 
($fz = function () {
}, $fz.isPrivate = true, $fz));
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (a) {
{
var b = android.view.InputQueue.FinishedCallback.sRecycleHead;
if (b != null) {
($t$ = android.view.InputQueue.FinishedCallback.sRecycleHead = b.mRecycleNext, android.view.InputQueue.FinishedCallback.prototype.sRecycleHead = android.view.InputQueue.FinishedCallback.sRecycleHead, $t$);
($t$ = android.view.InputQueue.FinishedCallback.sRecycleCount -= 1, android.view.InputQueue.FinishedCallback.prototype.sRecycleCount = android.view.InputQueue.FinishedCallback.sRecycleCount, $t$);
b.mRecycleNext = null;
} else {
b =  new android.view.InputQueue.FinishedCallback ();
}b.mFinishedToken = a;
return b;
}}, "~N");
Clazz.overrideMethod (c$, "run", 
function () {
{
if (this.mFinishedToken == -1) {
throw  new IllegalStateException ("Event finished callback already invoked.");
}android.view.InputQueue.nativeFinished (this.mFinishedToken);
this.mFinishedToken = -1;
if (android.view.InputQueue.FinishedCallback.sRecycleCount < 4) {
this.mRecycleNext = android.view.InputQueue.FinishedCallback.sRecycleHead;
($t$ = android.view.InputQueue.FinishedCallback.sRecycleHead = this, android.view.InputQueue.FinishedCallback.prototype.sRecycleHead = android.view.InputQueue.FinishedCallback.sRecycleHead, $t$);
($t$ = android.view.InputQueue.FinishedCallback.sRecycleCount += 1, android.view.InputQueue.FinishedCallback.prototype.sRecycleCount = android.view.InputQueue.FinishedCallback.sRecycleCount, $t$);
}}});
Clazz.defineStatics (c$,
"DEBUG_RECYCLING", false,
"RECYCLE_MAX_COUNT", 4,
"sRecycleHead", null,
"sRecycleCount", 0);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "InputQueue",
"DEBUG", false);
c$.sLock = c$.prototype.sLock =  new JavaObject ();
});
