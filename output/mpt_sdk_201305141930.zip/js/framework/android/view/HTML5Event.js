﻿Clazz.declarePackage ("android.view");
Clazz.load (null, "android.view.HTML5Event", ["android.view.KeyEvent"], function () {
c$ = Clazz.declareType (android.view, "HTML5Event");
c$.isMouseEvent = Clazz.defineMethod (c$, "isMouseEvent", 
function (event) {
event = event.trim ();
if (event.equals ("mousedown") || event.equals ("mousemove") || event.equals ("mouseup") || event.equals ("mouseenter") || event.equals ("mouseleave") || event.equals ("click") || event.equals ("dblclick")) return true;
 else return false;
}, "~S");
c$.isKeyEvent = Clazz.defineMethod (c$, "isKeyEvent", 
function (event) {
event = event.trim ();
if (event.equals ("keydown") || event.equals ("keypress") || event.equals ("keyup")) return true;
 else return false;
}, "~S");
c$.toKeyEvent = Clazz.defineMethod (c$, "toKeyEvent", 
function (eventType, keyCode) {
var keyEvent = null;
if (eventType.equals ("keydown")) {
keyEvent =  new android.view.KeyEvent (0, keyCode);
} else if (eventType.equals ("keyup")) {
keyEvent =  new android.view.KeyEvent (1, keyCode);
} else if (eventType.equals ("keypress")) {
}return keyEvent;
}, "~S,~N");
Clazz.defineStatics (c$,
"eventType", ["abort", "blur", "click", "compositionstart", "compositionupdate", "compositionend", "dblclick", "DOMActivate", "DOMAttributeNameChanged", "DOMAttrModified", "DOMCharacterDataModified", "DOMElementNameChanged", "DOMFocusIn", "DOMFocusOut", "DOMNodeInserted", "DOMNodeInsertedIntoDocument", "DOMNodeRemoved", "DOMNodeRemovedFromDocument", "error", "focus", "focusin", "focusout", "keydown", "keypress", "keyup", "load", "mousedown", "mouseenter", "mouseleave", "mousemove", "mouseout", "mouseover", "mouseup", "resize", "scroll", "select", "textinput", "unload", "wheel"]);
});
