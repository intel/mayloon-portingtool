﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator", "java.lang.IllegalStateException"], "android.view.AbsSavedState", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mSuperState = null;
Clazz.instantialize (this, arguments);
}, android.view, "AbsSavedState", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function (superState) {
if (superState == null) {
throw  new IllegalArgumentException ("superState must not be null");
}this.mSuperState = superState !== android.view.AbsSavedState.EMPTY_STATE ? superState : null;
}, "android.os.Parcelable");
Clazz.makeConstructor (c$, 
function (source) {
var superState = source.readParcelable (null);
this.mSuperState = superState != null ? superState : android.view.AbsSavedState.EMPTY_STATE;
}, "android.os.Parcel");
Clazz.defineMethod (c$, "getSuperState", 
function () {
return this.mSuperState;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
dest.writeParcelable (this.mSuperState, flags);
}, "android.os.Parcel,~N");
c$.$AbsSavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view, "AbsSavedState$1", android.view.AbsSavedState);
c$ = Clazz.p0p ();
};
c$.$AbsSavedState$2$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view, "AbsSavedState$2", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
var superState = $in.readParcelable (null);
if (superState != null) {
throw  new IllegalStateException ("superState must be null");
}return android.view.AbsSavedState.EMPTY_STATE;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
c$.EMPTY_STATE = c$.prototype.EMPTY_STATE = ((Clazz.isClassDefined ("android.view.AbsSavedState$1") ? 0 : android.view.AbsSavedState.$AbsSavedState$1$ ()), Clazz.innerTypeInstance (android.view.AbsSavedState$1, this, null));
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.view.AbsSavedState$2") ? 0 : android.view.AbsSavedState.$AbsSavedState$2$ ()), Clazz.innerTypeInstance (android.view.AbsSavedState$2, this, null));
});
