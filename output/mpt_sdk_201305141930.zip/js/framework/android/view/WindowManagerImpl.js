﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.view.View", "$.WindowManager", "$.Display"], "android.view.WindowManagerImpl", ["android.view.ViewRoot", "java.lang.IllegalArgumentException", "$.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mViews = null;
this.mRoots = null;
this.mParams = null;
this.mDisplay = null;
if (!Clazz.isClassDefined ("android.view.WindowManagerImpl.ToastView")) {
android.view.WindowManagerImpl.$WindowManagerImpl$ToastView$ ();
}
Clazz.instantialize (this, arguments);
}, android.view, "WindowManagerImpl", android.view.WindowManager);
Clazz.prepareFields (c$, function () {
this.mDisplay =  new android.view.Display (0);
});
c$.getDefault = Clazz.defineMethod (c$, "getDefault", 
function () {
if (android.view.WindowManagerImpl.mWindowManager == null) ($t$ = android.view.WindowManagerImpl.mWindowManager =  new android.view.WindowManagerImpl (), android.view.WindowManagerImpl.prototype.mWindowManager = android.view.WindowManagerImpl.mWindowManager, $t$);
return android.view.WindowManagerImpl.mWindowManager;
});
Clazz.overrideMethod (c$, "getDefaultDisplay", 
function () {
return this.mDisplay;
});
Clazz.defineMethod (c$, "addView", 
function (view) {
this.addView (view,  new android.view.WindowManager.LayoutParams (2, 0, -1));
}, "android.view.View");
Clazz.defineMethod (c$, "addView", 
function (view, params) {
this.addView (view, params, false);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addViewNesting", 
function (view, params) {
this.addView (view, params, false);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addView", 
($fz = function (view, params, nest) {
var wparams = params;
var root;
var panelParentView = null;
var index = this.findViewLocked (view, false);
if (index >= 0) {
if (!nest) {
throw  new IllegalStateException ("View " + view + " has already been added to the window manager.");
}root = this.mRoots[index];
root.mAddNesting++;
view.setLayoutParams (wparams);
root.setLayoutParams (wparams, true);
return ;
}if (wparams.type >= 1000 && wparams.type <= 1999) {
System.out.println ("WindowManagerImplshould not go here");
var count = this.mViews != null ? this.mViews.length : 0;
for (var i = 0; i < count; i++) {
}
}root =  new android.view.ViewRoot (view.getContext ());
root.mAddNesting = 1;
view.setLayoutParams (wparams);
if (this.mViews == null) {
index = 1;
this.mViews =  new Array (1);
this.mRoots =  new Array (1);
this.mParams =  new Array (1);
} else {
index = this.mViews.length + 1;
var old = this.mViews;
this.mViews =  new Array (index);
System.arraycopy (old, 0, this.mViews, 0, index - 1);
old = this.mRoots;
this.mRoots =  new Array (index);
System.arraycopy (old, 0, this.mRoots, 0, index - 1);
old = this.mParams;
this.mParams =  new Array (index);
System.arraycopy (old, 0, this.mParams, 0, index - 1);
}index--;
this.mViews[index] = view;
this.mRoots[index] = root;
this.mParams[index] = wparams;
try {
root.setView (view, wparams, panelParentView);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz), "android.view.View,android.view.ViewGroup.LayoutParams,~B");
Clazz.defineMethod (c$, "findViewLocked", 
($fz = function (view, required) {
var count = this.mViews != null ? this.mViews.length : 0;
for (var i = 0; i < count; i++) {
if (this.mViews[i] === view) {
return i;
}}
if (required) {
throw  new IllegalArgumentException ("View not attached to window manager");
}return -1;
}, $fz.isPrivate = true, $fz), "android.view.View,~B");
Clazz.overrideMethod (c$, "updateViewLayout", 
function (view, params) {
if (!(Clazz.instanceOf (params, android.view.WindowManager.LayoutParams))) {
throw  new IllegalArgumentException ("Params must be WindowManager.LayoutParams");
}var wparams = params;
view.setLayoutParams (wparams);
var index = this.findViewLocked (view, true);
var root = this.mRoots[index];
this.mParams[index] = wparams;
root.setLayoutParams (wparams, false);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.overrideMethod (c$, "removeView", 
function (view) {
var index = this.findViewLocked (view, true);
var curView = this.removeViewLocked (index);
if (curView === view) {
return ;
}throw  new IllegalStateException ("Calling with view " + view + " but the ViewRoot is attached to " + curView);
}, "android.view.View");
Clazz.defineMethod (c$, "removeViewLocked", 
function (index) {
var root = this.mRoots[index];
var view = root.getView ();
root.mAddNesting--;
if (root.mAddNesting > 0) {
return view;
}root.die (false);
this.finishRemoveViewLocked (view, index);
return view;
}, "~N");
Clazz.defineMethod (c$, "finishRemoveViewLocked", 
function (view, index) {
var count = this.mViews.length;
var tmpViews =  new Array (count - 1);
android.view.WindowManagerImpl.removeItem (tmpViews, this.mViews, index);
this.mViews = tmpViews;
var tmpRoots =  new Array (count - 1);
android.view.WindowManagerImpl.removeItem (tmpRoots, this.mRoots, index);
this.mRoots = tmpRoots;
var tmpParams =  new Array (count - 1);
android.view.WindowManagerImpl.removeItem (tmpParams, this.mParams, index);
this.mParams = tmpParams;
view.assignParent (null, true);
}, "android.view.View,~N");
c$.removeItem = Clazz.defineMethod (c$, "removeItem", 
($fz = function (dst, src, index) {
if (dst.length > 0) {
if (index > 0) {
System.arraycopy (src, 0, dst, 0, index);
}if (index < dst.length) {
System.arraycopy (src, index + 1, dst, index, src.length - index - 1);
}}}, $fz.isPrivate = true, $fz), "~A,~A,~N");
Clazz.defineMethod (c$, "getRootViewLayoutParameter", 
function (view) {
var vp = view.getParent ();
while (vp != null && !(Clazz.instanceOf (vp, android.view.ViewRoot))) {
vp = vp.getParent ();
}
if (vp == null) return null;
var vr = vp;
var N = this.mRoots.length;
for (var i = 0; i < N; ++i) {
if (this.mRoots[i] === vr) {
return this.mParams[i];
}}
return null;
}, "android.view.View");
Clazz.overrideMethod (c$, "removeViewImmediate", 
function (view) {
var index = this.findViewLocked (view, true);
var root = this.mRoots[index];
var curView = root.getView ();
root.mAddNesting = 0;
root.die (true);
this.finishRemoveViewLocked (curView, index);
if (curView === view) {
return ;
}throw  new IllegalStateException ("Calling with view " + view + " but the ViewRoot is attached to " + curView);
}, "android.view.View");
c$.$WindowManagerImpl$ToastView$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.view.WindowManagerImpl, "ToastView", android.view.View);
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"TAG", "WindowManagerImpl",
"mWindowManager", null);
});
