﻿Clazz.declarePackage ("android.view");
c$ = Clazz.declareType (android.view, "Gravity");
c$.apply = Clazz.defineMethod (c$, "apply", 
function (gravity, w, h, container, outRect) {
android.view.Gravity.apply (gravity, w, h, container, 0, 0, outRect);
}, "~N,~N,~N,android.graphics.Rect,android.graphics.Rect");
c$.apply = Clazz.defineMethod (c$, "apply", 
function (gravity, w, h, container, outRect, layoutDirection) {
var absGravity = android.view.Gravity.getAbsoluteGravity (gravity, layoutDirection);
android.view.Gravity.apply (absGravity, w, h, container, 0, 0, outRect);
}, "~N,~N,~N,android.graphics.Rect,android.graphics.Rect,~N");
c$.apply = Clazz.defineMethod (c$, "apply", 
function (gravity, w, h, container, xAdj, yAdj, outRect) {
switch (gravity & (6)) {
case 0:
outRect.left = container.left + (Math.floor ((container.right - container.left - w) / 2)) + xAdj;
outRect.right = outRect.left + w;
if ((gravity & (8)) == (8)) {
if (outRect.left < container.left) {
outRect.left = container.left;
}if (outRect.right > container.right) {
outRect.right = container.right;
}}break;
case 2:
outRect.left = container.left + xAdj;
outRect.right = outRect.left + w;
if ((gravity & (8)) == (8)) {
if (outRect.right > container.right) {
outRect.right = container.right;
}}break;
case 4:
outRect.right = container.right - xAdj;
outRect.left = outRect.right - w;
if ((gravity & (8)) == (8)) {
if (outRect.left < container.left) {
outRect.left = container.left;
}}break;
default:
outRect.left = container.left + xAdj;
outRect.right = container.right + xAdj;
break;
}
switch (gravity & (96)) {
case 0:
outRect.top = container.top + (Math.floor ((container.bottom - container.top - h) / 2)) + yAdj;
outRect.bottom = outRect.top + h;
if ((gravity & (128)) == (128)) {
if (outRect.top < container.top) {
outRect.top = container.top;
}if (outRect.bottom > container.bottom) {
outRect.bottom = container.bottom;
}}break;
case 32:
outRect.top = container.top + yAdj;
outRect.bottom = outRect.top + h;
if ((gravity & (128)) == (128)) {
if (outRect.bottom > container.bottom) {
outRect.bottom = container.bottom;
}}break;
case 64:
outRect.bottom = container.bottom - yAdj;
outRect.top = outRect.bottom - h;
if ((gravity & (128)) == (128)) {
if (outRect.top < container.top) {
outRect.top = container.top;
}}break;
default:
outRect.top = container.top + yAdj;
outRect.bottom = container.bottom + yAdj;
break;
}
}, "~N,~N,~N,android.graphics.Rect,~N,~N,android.graphics.Rect");
c$.applyDisplay = Clazz.defineMethod (c$, "applyDisplay", 
function (gravity, display, inoutObj) {
if ((gravity & 268435456) != 0) {
if (inoutObj.top < display.top) inoutObj.top = display.top;
if (inoutObj.bottom > display.bottom) inoutObj.bottom = display.bottom;
} else {
var off = 0;
if (inoutObj.top < display.top) off = display.top - inoutObj.top;
 else if (inoutObj.bottom > display.bottom) off = display.bottom - inoutObj.bottom;
if (off != 0) {
if (inoutObj.height () > (display.bottom - display.top)) {
inoutObj.top = display.top;
inoutObj.bottom = display.bottom;
} else {
inoutObj.top += off;
inoutObj.bottom += off;
}}}if ((gravity & 16777216) != 0) {
if (inoutObj.left < display.left) inoutObj.left = display.left;
if (inoutObj.right > display.right) inoutObj.right = display.right;
} else {
var off = 0;
if (inoutObj.left < display.left) off = display.left - inoutObj.left;
 else if (inoutObj.right > display.right) off = display.right - inoutObj.right;
if (off != 0) {
if (inoutObj.width () > (display.right - display.left)) {
inoutObj.left = display.left;
inoutObj.right = display.right;
} else {
inoutObj.left += off;
inoutObj.right += off;
}}}}, "~N,android.graphics.Rect,android.graphics.Rect");
c$.isVertical = Clazz.defineMethod (c$, "isVertical", 
function (gravity) {
return gravity > 0 && (gravity & 112) != 0;
}, "~N");
c$.isHorizontal = Clazz.defineMethod (c$, "isHorizontal", 
function (gravity) {
return gravity > 0 && (gravity & 7) != 0;
}, "~N");
c$.getAbsoluteGravity = Clazz.defineMethod (c$, "getAbsoluteGravity", 
function (gravity, layoutDirection) {
var result = gravity;
if ((result & 8388608) > 0) {
if ((result & 8388611) == 8388611) {
result &= -8388612;
if (layoutDirection == 1073741824) {
result |= 5;
} else {
result |= 3;
}} else if ((result & 8388613) == 8388613) {
result &= -8388614;
if (layoutDirection == 1073741824) {
result |= 3;
} else {
result |= 5;
}}result &= -8388609;
}return result;
}, "~N,~N");
Clazz.defineStatics (c$,
"NO_GRAVITY", 0x0000,
"AXIS_SPECIFIED", 0x0001,
"AXIS_PULL_BEFORE", 0x0002,
"AXIS_PULL_AFTER", 0x0004,
"AXIS_CLIP", 0x0008,
"AXIS_X_SHIFT", 0,
"AXIS_Y_SHIFT", 4,
"TOP", 48,
"BOTTOM", 80,
"LEFT", 3,
"RIGHT", 5,
"CENTER_VERTICAL", 16,
"FILL_VERTICAL", 112,
"CENTER_HORIZONTAL", 1,
"FILL_HORIZONTAL", 7,
"CENTER", 17,
"FILL", 119,
"CLIP_VERTICAL", 128,
"CLIP_HORIZONTAL", 8,
"RELATIVE_LAYOUT_DIRECTION", 0x00800000,
"HORIZONTAL_GRAVITY_MASK", 7,
"VERTICAL_GRAVITY_MASK", 112,
"DISPLAY_CLIP_VERTICAL", 0x10000000,
"DISPLAY_CLIP_HORIZONTAL", 0x01000000,
"START", 8388611,
"END", 8388613,
"RELATIVE_HORIZONTAL_GRAVITY_MASK", 8388615);
