﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.content.Context", "android.util.AttributeSet", "java.util.HashMap"], "android.view.LayoutInflater", ["android.util.Log", "android.view.InflateException", "com.android.internal.view.menu.IconMenuItemView", "$.IconMenuView", "java.lang.AssertionError", "$.Boolean", "$.ClassNotFoundException", "$.IllegalStateException", "$.NullPointerException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mLoadedClasses = null;
this.mContext = null;
this.mFactorySet = false;
this.mFactory = null;
this.mFilter = null;
this.mConstructorArgs = null;
this.mFilterMap = null;
Clazz.instantialize (this, arguments);
}, android.view, "LayoutInflater");
Clazz.prepareFields (c$, function () {
this.mLoadedClasses =  new java.util.HashMap ();
this.mConstructorArgs =  new Array (2);
});
Clazz.makeConstructor (c$, 
function (context) {
this.mContext = context;
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (original, newContext) {
this.mContext = newContext;
this.mFactory = original.mFactory;
this.mFilter = original.mFilter;
}, "android.view.LayoutInflater,android.content.Context");
c$.from = Clazz.defineMethod (c$, "from", 
function (context) {
var LayoutInflater = context.getSystemService ("layout_inflater");
if (LayoutInflater == null) {
throw  new AssertionError ("LayoutInflater not found.");
}return LayoutInflater;
}, "android.content.Context");
Clazz.defineMethod (c$, "cloneInContext", 
function (newContext) {
return  new android.view.LayoutInflater (this, newContext);
}, "android.content.Context");
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.defineMethod (c$, "getFactory", 
function () {
return this.mFactory;
});
Clazz.defineMethod (c$, "setFactory", 
function (factory) {
if (this.mFactorySet) {
throw  new IllegalStateException ("A factory has already been set on this LayoutInflater");
}if (factory == null) {
throw  new NullPointerException ("Given factory can not be null");
}this.mFactorySet = true;
if (this.mFactory == null) {
this.mFactory = factory;
} else {
this.mFactory =  new android.view.LayoutInflater.FactoryMerger (factory, this.mFactory);
}}, "android.view.LayoutInflater.Factory");
Clazz.defineMethod (c$, "getFilter", 
function () {
return this.mFilter;
});
Clazz.defineMethod (c$, "setFilter", 
function (filter) {
this.mFilter = filter;
if (filter != null) {
this.mFilterMap =  new java.util.HashMap ();
}}, "android.view.LayoutInflater.Filter");
Clazz.defineMethod (c$, "inflate", 
function (resource, root) {
return this.inflate (resource, root, root != null);
}, "~N,android.view.ViewGroup");
Clazz.defineMethod (c$, "inflate", 
function (parser, root) {
return this.inflate (parser, root, root != null);
}, "org.xmlpull.v1.XmlPullParser,android.view.ViewGroup");
Clazz.defineMethod (c$, "inflate", 
function (resource, root, attachToRoot) {
var parser = this.getContext ().getResources ().getLayout (resource);
try {
return this.inflate (parser, root, attachToRoot);
} finally {
parser.close ();
}
}, "~N,android.view.ViewGroup,~B");
Clazz.defineMethod (c$, "inflate", 
function (parser, root, attachToRoot) {
var attrs = parser;
var lastContext = this.mConstructorArgs[0];
this.mConstructorArgs[0] = this.mContext;
var result = root;
var type = -1;
try {
if (parser == null) {
throw  new RuntimeException ("LayoutInflater.inflate -> parser is null");
}while ((type = parser.next ()) != 2 && type != 1) {
}
if (type != 2) {
throw  new android.view.InflateException (parser.getPositionDescription () + ": No start tag found!");
}var name = parser.getName ();
if ("merge".equals (name)) {
if (root == null || !attachToRoot) {
throw  new android.view.InflateException ("<merge /> can be used only with a valid ViewGroup root and attachToRoot=true");
}this.rInflate (parser, root, attrs);
} else {
var temp = this.createViewFromTag (name, attrs);
android.util.Log.i ("LayoutInflater", "inflate>>>createView success");
var params = null;
if (root != null) {
params = root.generateLayoutParams (attrs);
if (attachToRoot == false) {
root.addView (temp, params, false);
} else {
root.addView (temp, params);
}}this.rInflate (parser, temp, attrs);
if (root == null || attachToRoot == false) {
result = temp;
}}} catch (e$$) {
if (Clazz.instanceOf (e$$, org.xmlpull.v1.XmlPullParserException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else {
throw e$$;
}
} finally {
this.mConstructorArgs[0] = lastContext;
this.mConstructorArgs[1] = null;
}
return result;
}, "org.xmlpull.v1.XmlPullParser,android.view.ViewGroup,~B");
Clazz.defineMethod (c$, "createView", 
function (name, prefix, attrs) {
android.util.Log.i ("LayoutInflater", "createView:" + name + ":" + prefix);
var constructor = android.view.LayoutInflater.sConstructorMap.get (name);
var clazz = null;
try {
if (constructor == null) {
var classPath = prefix != null ? (prefix + name) : name;
if (null == clazz) {
clazz = Class.forName (classPath);
}if (clazz == null) {
android.util.Log.e ("LayoutInflater", "createView:" + clazz);
throw  new ClassNotFoundException ("LayoutInflater.createView:<" + classPath + "> class not found");
}if (this.mFilter != null && clazz != null) {
android.util.Log.i ("LayoutInflater", "mFilter is not null");
var allowed = this.mFilter.onLoadClass (clazz);
if (!allowed) {
this.failNotAllowed (name, prefix, attrs);
}}constructor = clazz.getConstructor (android.view.LayoutInflater.mConstructorSignature);
if (null == constructor) {
android.util.Log.i ("LayoutInflater", "constructor is null");
}android.view.LayoutInflater.sConstructorMap.put (name, constructor);
} else {
if (this.mFilter != null) {
var allowedState = this.mFilterMap.get (name);
if (allowedState == null) {
} else if (allowedState.equals (Boolean.FALSE)) {
this.failNotAllowed (name, prefix, attrs);
}}}var args = this.mConstructorArgs;
args[1] = attrs;
return constructor.newInstance (args);
} catch (e$$) {
if (Clazz.instanceOf (e$$, NoSuchMethodException)) {
var e = e$$;
{
var ie =  new android.view.InflateException (attrs.getPositionDescription () + ": Error inflating class " + (prefix != null ? (prefix + name) : name));
ie.initCause (e);
throw ie;
}
} else if (Clazz.instanceOf (e$$, ClassNotFoundException)) {
var e = e$$;
{
throw e;
}
} else if (Clazz.instanceOf (e$$, Exception)) {
var e = e$$;
{
var ie =  new android.view.InflateException (attrs.getPositionDescription () + ": Error inflating class " + (clazz == null ? "<unknown>" : clazz.getName ()));
ie.initCause (e);
e.printStackTrace ();
throw ie;
}
} else {
throw e$$;
}
}
}, "~S,~S,android.util.AttributeSet");
Clazz.defineMethod (c$, "failNotAllowed", 
($fz = function (name, prefix, attrs) {
var ie =  new android.view.InflateException (attrs.getPositionDescription () + ": Class not allowed to be inflated " + (prefix != null ? (prefix + name) : name));
throw ie;
}, $fz.isPrivate = true, $fz), "~S,~S,android.util.AttributeSet");
Clazz.defineMethod (c$, "onCreateView", 
function (name, attrs) {
var view = null;
for (var prefix, $prefix = 0, $$prefix = android.view.LayoutInflater.sClassPrefixList; $prefix < $$prefix.length && ((prefix = $$prefix[$prefix]) || true); $prefix++) {
try {
var classPath = prefix + name;
var clazz = Class.forName (classPath);
if (clazz != null) {
view = this.createView (name, prefix, attrs);
}} catch (e) {
if (Clazz.instanceOf (e, ClassNotFoundException)) {
} else {
throw e;
}
}
if (view != null) {
break;
}}
return view;
}, "~S,android.util.AttributeSet");
Clazz.defineMethod (c$, "createViewFromTag", 
function (name, attrs) {
var view = null;
if (name.equals ("view")) {
name = attrs.getAttributeValue (null, "class");
}try {
view = (this.mFactory == null) ? null : this.mFactory.onCreateView (name, this.mContext, attrs);
if (view == null) {
if (-1 == name.indexOf ('.')) {
view = this.onCreateView (name, attrs);
} else {
view = this.createView (name, null, attrs);
}}android.util.Log.i ("LayoutInflater", "******** Creating view: " + name + " Done! UIID: " + view.getUIElementID () + ", ID: " + view.getId ());
if (view.getUIElementID () == 47) System.out.println ();
} catch (e$$) {
if (Clazz.instanceOf (e$$, android.view.InflateException)) {
var e = e$$;
{
view = this.loadCustomView (name, attrs);
}
} else if (Clazz.instanceOf (e$$, Exception)) {
var e = e$$;
{
var ie =  new android.view.InflateException (attrs.getPositionDescription () + ": Error inflating class " + name);
ie.initCause (e);
throw ie;
}
} else {
throw e$$;
}
} finally {
return view;
}
}, "~S,android.util.AttributeSet");
Clazz.defineMethod (c$, "loadCustomView", 
($fz = function (name, attrs) {
var customView = null;
if ("com.android.internal.view.menu.IconMenuView".equals (name)) {
customView =  new com.android.internal.view.menu.IconMenuView (this.mContext, attrs);
return customView;
} else if ("com.android.internal.view.menu.IconMenuItemView".equals (name)) {
customView =  new com.android.internal.view.menu.IconMenuItemView (this.mContext, attrs);
return customView;
} else {
return null;
}}, $fz.isPrivate = true, $fz), "~S,android.util.AttributeSet");
Clazz.defineMethod (c$, "rInflate", 
($fz = function (parser, parent, attrs) {
android.util.Log.i ("LayoutInflater", "in rInflate, for View: " + parent.getUIElementID ());
var depth = parser.getDepth ();
var type;
try {
while (((type = parser.next ()) != 3 || parser.getDepth () > depth) && type != 1) {
if (type != 2) {
continue ;}var name = parser.getName ();
var view = this.createViewFromTag (name, attrs);
var viewGroup = parent;
var params = viewGroup.generateLayoutParams (attrs);
viewGroup.addView (view, params);
this.rInflate (parser, view, attrs);
}
} catch (e$$) {
if (Clazz.instanceOf (e$$, org.xmlpull.v1.XmlPullParserException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else {
throw e$$;
}
}
parent.onFinishInflate ();
}, $fz.isPrivate = true, $fz), "org.xmlpull.v1.XmlPullParser,android.view.View,android.util.AttributeSet");
Clazz.declareInterface (android.view.LayoutInflater, "Filter");
Clazz.declareInterface (android.view.LayoutInflater, "Factory");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mF1 = null;
this.mF2 = null;
Clazz.instantialize (this, arguments);
}, android.view.LayoutInflater, "FactoryMerger", null, android.view.LayoutInflater.Factory);
Clazz.makeConstructor (c$, 
function (a, b) {
this.mF1 = a;
this.mF2 = b;
}, "android.view.LayoutInflater.Factory,android.view.LayoutInflater.Factory");
Clazz.defineMethod (c$, "onCreateView", 
function (a, b, c) {
var d = this.mF1.onCreateView (a, b, c);
if (d != null) return d;
return this.mF2.onCreateView (a, b, c);
}, "~S,android.content.Context,android.util.AttributeSet");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"sClassPrefixList", ["android.widget.", "android.webkit.", "android.view."],
"TAG", "LayoutInflater",
"TAG_MERGE", "merge");
c$.mConstructorSignature = c$.prototype.mConstructorSignature = [android.content.Context, android.util.AttributeSet];
c$.sConstructorMap = c$.prototype.sConstructorMap =  new java.util.HashMap ();
});
