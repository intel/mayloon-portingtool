﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.view.InputEvent"], "android.view.MotionEvent", ["java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDownTimeNano = 0;
this.mAction = 0;
this.mXOffset = 0;
this.mYOffset = 0;
this.mXPrecision = 0;
this.mYPrecision = 0;
this.mEdgeFlags = 0;
this.mMetaState = 0;
this.mFlags = 0;
this.mNumPointers = 0;
this.mNumSamples = 0;
this.mLastDataSampleIndex = 0;
this.mLastEventTimeNanoSampleIndex = 0;
this.mPointerIdentifiers = null;
this.mDataSamples = null;
this.mEventTimeNanoSamples = null;
this.mNext = null;
this.mRecycledLocation = null;
this.mRecycled = false;
Clazz.instantialize (this, arguments);
}, android.view, "MotionEvent", android.view.InputEvent);
Clazz.makeConstructor (c$, 
($fz = function (pointerCount, sampleCount) {
Clazz.superConstructor (this, android.view.MotionEvent, []);
this.mPointerIdentifiers =  Clazz.newArray (pointerCount, 0);
this.mDataSamples =  Clazz.newArray (pointerCount * sampleCount * 9, 0);
this.mEventTimeNanoSamples =  Clazz.newArray (sampleCount, 0);
}, $fz.isPrivate = true, $fz), "~N,~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
($fz = function (pointerCount, sampleCount) {
var ev;
{
if (android.view.MotionEvent.gRecyclerTop == null) {
if (pointerCount < 5) {
pointerCount = 5;
}if (sampleCount < 8) {
sampleCount = 8;
}return  new android.view.MotionEvent (pointerCount, sampleCount);
}ev = android.view.MotionEvent.gRecyclerTop;
($t$ = android.view.MotionEvent.gRecyclerTop = ev.mNext, android.view.MotionEvent.prototype.gRecyclerTop = android.view.MotionEvent.gRecyclerTop, $t$);
($t$ = android.view.MotionEvent.gRecyclerUsed -= 1, android.view.MotionEvent.prototype.gRecyclerUsed = android.view.MotionEvent.gRecyclerUsed, $t$);
}ev.mRecycledLocation = null;
ev.mRecycled = false;
ev.mNext = null;
if (ev.mPointerIdentifiers.length < pointerCount) {
ev.mPointerIdentifiers =  Clazz.newArray (pointerCount, 0);
}if (ev.mEventTimeNanoSamples.length < sampleCount) {
ev.mEventTimeNanoSamples =  Clazz.newArray (sampleCount, 0);
}var neededDataSamplesLength = pointerCount * sampleCount * 9;
if (ev.mDataSamples.length < neededDataSamplesLength) {
ev.mDataSamples =  Clazz.newArray (neededDataSamplesLength, 0);
}return ev;
}, $fz.isPrivate = true, $fz), "~N,~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (downTime, eventTime, action, pointers, pointerIds, pointerCoords, metaState, xPrecision, yPrecision, deviceId, edgeFlags, source, flags) {
var ev = android.view.MotionEvent.obtain (pointers, 1);
ev.mDeviceId = deviceId;
ev.mSource = source;
ev.mEdgeFlags = edgeFlags;
ev.mDownTimeNano = downTime * 1000000;
ev.mAction = action;
ev.mFlags = flags;
ev.mMetaState = metaState;
ev.mXOffset = 0;
ev.mYOffset = 0;
ev.mXPrecision = xPrecision;
ev.mYPrecision = yPrecision;
ev.mNumPointers = pointers;
ev.mNumSamples = 1;
ev.mLastDataSampleIndex = 0;
ev.mLastEventTimeNanoSampleIndex = 0;
System.arraycopy (pointerIds, 0, ev.mPointerIdentifiers, 0, pointers);
ev.mEventTimeNanoSamples[0] = eventTime * 1000000;
ev.setPointerCoordsAtSampleIndex (0, pointerCoords);
return ev;
}, "~N,~N,~N,~N,~A,~A,~N,~N,~N,~N,~N,~N,~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (downTime, eventTime, action, x, y, pressure, size, metaState, xPrecision, yPrecision, deviceId, edgeFlags) {
var ev = android.view.MotionEvent.obtain (1, 1);
ev.mDeviceId = deviceId;
ev.mSource = 0;
ev.mEdgeFlags = edgeFlags;
ev.mDownTimeNano = downTime * 1000000;
ev.mAction = action;
ev.mFlags = 0;
ev.mMetaState = metaState;
ev.mXOffset = 0;
ev.mYOffset = 0;
ev.mXPrecision = xPrecision;
ev.mYPrecision = yPrecision;
ev.mNumPointers = 1;
ev.mNumSamples = 1;
ev.mLastDataSampleIndex = 0;
ev.mLastEventTimeNanoSampleIndex = 0;
ev.mPointerIdentifiers[0] = 0;
ev.mEventTimeNanoSamples[0] = eventTime * 1000000;
ev.setPointerCoordsAtSampleIndex (0, x, y, pressure, size);
return ev;
}, "~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (downTime, eventTime, action, pointers, x, y, pressure, size, metaState, xPrecision, yPrecision, deviceId, edgeFlags) {
return android.view.MotionEvent.obtain (downTime, eventTime, action, x, y, pressure, size, metaState, xPrecision, yPrecision, deviceId, edgeFlags);
}, "~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (downTime, eventTime, action, x, y, metaState) {
return android.view.MotionEvent.obtain (downTime, eventTime, action, x, y, 1.0, 1.0, metaState, 1.0, 1.0, 0, 0);
}, "~N,~N,~N,~N,~N,~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (o) {
var ev = android.view.MotionEvent.obtain (o.mNumPointers, o.mNumSamples);
ev.mDeviceId = o.mDeviceId;
ev.mSource = o.mSource;
ev.mEdgeFlags = o.mEdgeFlags;
ev.mDownTimeNano = o.mDownTimeNano;
ev.mAction = o.mAction;
ev.mFlags = o.mFlags;
ev.mMetaState = o.mMetaState;
ev.mXOffset = o.mXOffset;
ev.mYOffset = o.mYOffset;
ev.mXPrecision = o.mXPrecision;
ev.mYPrecision = o.mYPrecision;
var numPointers = ev.mNumPointers = o.mNumPointers;
var numSamples = ev.mNumSamples = o.mNumSamples;
ev.mLastDataSampleIndex = o.mLastDataSampleIndex;
ev.mLastEventTimeNanoSampleIndex = o.mLastEventTimeNanoSampleIndex;
System.arraycopy (o.mPointerIdentifiers, 0, ev.mPointerIdentifiers, 0, numPointers);
System.arraycopy (o.mEventTimeNanoSamples, 0, ev.mEventTimeNanoSamples, 0, numSamples);
System.arraycopy (o.mDataSamples, 0, ev.mDataSamples, 0, numPointers * numSamples * 9);
return ev;
}, "android.view.MotionEvent");
c$.obtainNoHistory = Clazz.defineMethod (c$, "obtainNoHistory", 
function (o) {
var ev = android.view.MotionEvent.obtain (o.mNumPointers, 1);
ev.mDeviceId = o.mDeviceId;
ev.mSource = o.mSource;
ev.mEdgeFlags = o.mEdgeFlags;
ev.mDownTimeNano = o.mDownTimeNano;
ev.mAction = o.mAction;
o.mFlags = o.mFlags;
ev.mMetaState = o.mMetaState;
ev.mXOffset = o.mXOffset;
ev.mYOffset = o.mYOffset;
ev.mXPrecision = o.mXPrecision;
ev.mYPrecision = o.mYPrecision;
var numPointers = ev.mNumPointers = o.mNumPointers;
ev.mNumSamples = 1;
ev.mLastDataSampleIndex = 0;
ev.mLastEventTimeNanoSampleIndex = 0;
System.arraycopy (o.mPointerIdentifiers, 0, ev.mPointerIdentifiers, 0, numPointers);
ev.mEventTimeNanoSamples[0] = o.mEventTimeNanoSamples[o.mLastEventTimeNanoSampleIndex];
System.arraycopy (o.mDataSamples, o.mLastDataSampleIndex, ev.mDataSamples, 0, numPointers * 9);
return ev;
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "recycle", 
function () {
if (false) {
if (this.mRecycledLocation != null) {
throw  new RuntimeException (this.toString () + " recycled twice!", this.mRecycledLocation);
}this.mRecycledLocation =  new RuntimeException ("Last recycled here");
} else {
if (this.mRecycled) {
throw  new RuntimeException (this.toString () + " recycled twice!");
}this.mRecycled = true;
}{
if (android.view.MotionEvent.gRecyclerUsed < 10) {
($t$ = android.view.MotionEvent.gRecyclerUsed ++, android.view.MotionEvent.prototype.gRecyclerUsed = android.view.MotionEvent.gRecyclerUsed, $t$);
this.mNumSamples = 0;
this.mNext = android.view.MotionEvent.gRecyclerTop;
($t$ = android.view.MotionEvent.gRecyclerTop = this, android.view.MotionEvent.prototype.gRecyclerTop = android.view.MotionEvent.gRecyclerTop, $t$);
}}});
Clazz.defineMethod (c$, "scale", 
function (scale) {
this.mXOffset *= scale;
this.mYOffset *= scale;
this.mXPrecision *= scale;
this.mYPrecision *= scale;
var history = this.mDataSamples;
var length = this.mNumPointers * this.mNumSamples * 9;
for (var i = 0; i < length; i += 9) {
history[i + 0] *= scale;
history[i + 1] *= scale;
history[i + 3] *= scale;
history[i + 4] *= scale;
history[i + 5] *= scale;
history[i + 6] *= scale;
history[i + 7] *= scale;
}
}, "~N");
Clazz.defineMethod (c$, "getAction", 
function () {
return this.mAction;
});
Clazz.defineMethod (c$, "getActionMasked", 
function () {
return this.mAction & 255;
});
Clazz.defineMethod (c$, "getActionIndex", 
function () {
return (this.mAction & 65280) >> 8;
});
Clazz.defineMethod (c$, "getFlags", 
function () {
return this.mFlags;
});
Clazz.defineMethod (c$, "getDownTime", 
function () {
return Math.floor (this.mDownTimeNano / 1000000);
});
Clazz.defineMethod (c$, "getEventTime", 
function () {
return Math.floor (this.mEventTimeNanoSamples[this.mLastEventTimeNanoSampleIndex] / 1000000);
});
Clazz.defineMethod (c$, "getEventTimeNano", 
function () {
return this.mEventTimeNanoSamples[this.mLastEventTimeNanoSampleIndex];
});
Clazz.defineMethod (c$, "getX", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 0] + this.mXOffset;
});
Clazz.defineMethod (c$, "getY", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 1] + this.mYOffset;
});
Clazz.defineMethod (c$, "getPressure", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 2];
});
Clazz.defineMethod (c$, "getSize", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 3];
});
Clazz.defineMethod (c$, "getTouchMajor", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 4];
});
Clazz.defineMethod (c$, "getTouchMinor", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 5];
});
Clazz.defineMethod (c$, "getToolMajor", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 6];
});
Clazz.defineMethod (c$, "getToolMinor", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 7];
});
Clazz.defineMethod (c$, "getOrientation", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 8];
});
Clazz.defineMethod (c$, "getPointerCount", 
function () {
return this.mNumPointers;
});
Clazz.defineMethod (c$, "getPointerId", 
function (pointerIndex) {
return this.mPointerIdentifiers[pointerIndex];
}, "~N");
Clazz.defineMethod (c$, "findPointerIndex", 
function (pointerId) {
var i = this.mNumPointers;
while (i > 0) {
i--;
if (this.mPointerIdentifiers[i] == pointerId) {
return i;
}}
return -1;
}, "~N");
Clazz.defineMethod (c$, "getX", 
function (pointerIndex) {
return this.mDataSamples[this.mLastDataSampleIndex + pointerIndex * 9 + 0] + this.mXOffset;
}, "~N");
Clazz.defineMethod (c$, "getY", 
function (pointerIndex) {
return this.mDataSamples[this.mLastDataSampleIndex + pointerIndex * 9 + 1] + this.mYOffset;
}, "~N");
Clazz.defineMethod (c$, "getPressure", 
function (pointerIndex) {
return this.mDataSamples[this.mLastDataSampleIndex + pointerIndex * 9 + 2];
}, "~N");
Clazz.defineMethod (c$, "getSize", 
function (pointerIndex) {
return this.mDataSamples[this.mLastDataSampleIndex + pointerIndex * 9 + 3];
}, "~N");
Clazz.defineMethod (c$, "getTouchMajor", 
function (pointerIndex) {
return this.mDataSamples[this.mLastDataSampleIndex + pointerIndex * 9 + 4];
}, "~N");
Clazz.defineMethod (c$, "getTouchMinor", 
function (pointerIndex) {
return this.mDataSamples[this.mLastDataSampleIndex + pointerIndex * 9 + 5];
}, "~N");
Clazz.defineMethod (c$, "getToolMajor", 
function (pointerIndex) {
return this.mDataSamples[this.mLastDataSampleIndex + pointerIndex * 9 + 6];
}, "~N");
Clazz.defineMethod (c$, "getToolMinor", 
function (pointerIndex) {
return this.mDataSamples[this.mLastDataSampleIndex + pointerIndex * 9 + 7];
}, "~N");
Clazz.defineMethod (c$, "getOrientation", 
function (pointerIndex) {
return this.mDataSamples[this.mLastDataSampleIndex + pointerIndex * 9 + 8];
}, "~N");
Clazz.defineMethod (c$, "getPointerCoords", 
function (pointerIndex, outPointerCoords) {
var sampleIndex = this.mLastDataSampleIndex + pointerIndex * 9;
this.getPointerCoordsAtSampleIndex (sampleIndex, outPointerCoords);
}, "~N,android.view.MotionEvent.PointerCoords");
Clazz.defineMethod (c$, "getMetaState", 
function () {
return this.mMetaState;
});
Clazz.defineMethod (c$, "getRawX", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 0];
});
Clazz.defineMethod (c$, "getRawY", 
function () {
return this.mDataSamples[this.mLastDataSampleIndex + 1];
});
Clazz.defineMethod (c$, "getXPrecision", 
function () {
return this.mXPrecision;
});
Clazz.defineMethod (c$, "getYPrecision", 
function () {
return this.mYPrecision;
});
Clazz.defineMethod (c$, "getHistorySize", 
function () {
return this.mLastEventTimeNanoSampleIndex;
});
Clazz.defineMethod (c$, "getHistoricalEventTime", 
function (pos) {
return Math.floor (this.mEventTimeNanoSamples[pos] / 1000000);
}, "~N");
Clazz.defineMethod (c$, "getHistoricalX", 
function (pos) {
return this.mDataSamples[pos * this.mNumPointers * 9 + 0] + this.mXOffset;
}, "~N");
Clazz.defineMethod (c$, "getHistoricalY", 
function (pos) {
return this.mDataSamples[pos * this.mNumPointers * 9 + 1] + this.mYOffset;
}, "~N");
Clazz.defineMethod (c$, "getHistoricalPressure", 
function (pos) {
return this.mDataSamples[pos * this.mNumPointers * 9 + 2];
}, "~N");
Clazz.defineMethod (c$, "getHistoricalSize", 
function (pos) {
return this.mDataSamples[pos * this.mNumPointers * 9 + 3];
}, "~N");
Clazz.defineMethod (c$, "getHistoricalTouchMajor", 
function (pos) {
return this.mDataSamples[pos * this.mNumPointers * 9 + 4];
}, "~N");
Clazz.defineMethod (c$, "getHistoricalTouchMinor", 
function (pos) {
return this.mDataSamples[pos * this.mNumPointers * 9 + 5];
}, "~N");
Clazz.defineMethod (c$, "getHistoricalToolMajor", 
function (pos) {
return this.mDataSamples[pos * this.mNumPointers * 9 + 6];
}, "~N");
Clazz.defineMethod (c$, "getHistoricalToolMinor", 
function (pos) {
return this.mDataSamples[pos * this.mNumPointers * 9 + 7];
}, "~N");
Clazz.defineMethod (c$, "getHistoricalOrientation", 
function (pos) {
return this.mDataSamples[pos * this.mNumPointers * 9 + 8];
}, "~N");
Clazz.defineMethod (c$, "getHistoricalX", 
function (pointerIndex, pos) {
return this.mDataSamples[(pos * this.mNumPointers + pointerIndex) * 9 + 0] + this.mXOffset;
}, "~N,~N");
Clazz.defineMethod (c$, "getHistoricalY", 
function (pointerIndex, pos) {
return this.mDataSamples[(pos * this.mNumPointers + pointerIndex) * 9 + 1] + this.mYOffset;
}, "~N,~N");
Clazz.defineMethod (c$, "getHistoricalPressure", 
function (pointerIndex, pos) {
return this.mDataSamples[(pos * this.mNumPointers + pointerIndex) * 9 + 2];
}, "~N,~N");
Clazz.defineMethod (c$, "getHistoricalSize", 
function (pointerIndex, pos) {
return this.mDataSamples[(pos * this.mNumPointers + pointerIndex) * 9 + 3];
}, "~N,~N");
Clazz.defineMethod (c$, "getHistoricalTouchMajor", 
function (pointerIndex, pos) {
return this.mDataSamples[(pos * this.mNumPointers + pointerIndex) * 9 + 4];
}, "~N,~N");
Clazz.defineMethod (c$, "getHistoricalTouchMinor", 
function (pointerIndex, pos) {
return this.mDataSamples[(pos * this.mNumPointers + pointerIndex) * 9 + 5];
}, "~N,~N");
Clazz.defineMethod (c$, "getHistoricalToolMajor", 
function (pointerIndex, pos) {
return this.mDataSamples[(pos * this.mNumPointers + pointerIndex) * 9 + 6];
}, "~N,~N");
Clazz.defineMethod (c$, "getHistoricalToolMinor", 
function (pointerIndex, pos) {
return this.mDataSamples[(pos * this.mNumPointers + pointerIndex) * 9 + 7];
}, "~N,~N");
Clazz.defineMethod (c$, "getHistoricalOrientation", 
function (pointerIndex, pos) {
return this.mDataSamples[(pos * this.mNumPointers + pointerIndex) * 9 + 8];
}, "~N,~N");
Clazz.defineMethod (c$, "getHistoricalPointerCoords", 
function (pointerIndex, pos, outPointerCoords) {
var sampleIndex = (pos * this.mNumPointers + pointerIndex) * 9;
this.getPointerCoordsAtSampleIndex (sampleIndex, outPointerCoords);
}, "~N,~N,android.view.MotionEvent.PointerCoords");
Clazz.defineMethod (c$, "getEdgeFlags", 
function () {
return this.mEdgeFlags;
});
Clazz.defineMethod (c$, "setEdgeFlags", 
function (flags) {
this.mEdgeFlags = flags;
}, "~N");
Clazz.defineMethod (c$, "setAction", 
function (action) {
this.mAction = action;
}, "~N");
Clazz.defineMethod (c$, "offsetLocation", 
function (deltaX, deltaY) {
this.mXOffset += deltaX;
this.mYOffset += deltaY;
}, "~N,~N");
Clazz.defineMethod (c$, "setLocation", 
function (x, y) {
var dataSamples = this.mDataSamples;
var lastDataSampleIndex = this.mLastDataSampleIndex;
this.mXOffset = x - dataSamples[lastDataSampleIndex + 0];
this.mYOffset = y - dataSamples[lastDataSampleIndex + 1];
}, "~N,~N");
Clazz.defineMethod (c$, "getPointerCoordsAtSampleIndex", 
($fz = function (sampleIndex, outPointerCoords) {
var dataSamples = this.mDataSamples;
outPointerCoords.x = dataSamples[sampleIndex + 0] + this.mXOffset;
outPointerCoords.y = dataSamples[sampleIndex + 1] + this.mYOffset;
outPointerCoords.pressure = dataSamples[sampleIndex + 2];
outPointerCoords.size = dataSamples[sampleIndex + 3];
outPointerCoords.touchMajor = dataSamples[sampleIndex + 4];
outPointerCoords.touchMinor = dataSamples[sampleIndex + 5];
outPointerCoords.toolMajor = dataSamples[sampleIndex + 6];
outPointerCoords.toolMinor = dataSamples[sampleIndex + 7];
outPointerCoords.orientation = dataSamples[sampleIndex + 8];
}, $fz.isPrivate = true, $fz), "~N,android.view.MotionEvent.PointerCoords");
Clazz.defineMethod (c$, "setPointerCoordsAtSampleIndex", 
($fz = function (sampleIndex, pointerCoords) {
var numPointers = this.mNumPointers;
for (var i = 0; i < numPointers; i++) {
this.setPointerCoordsAtSampleIndex (sampleIndex, pointerCoords[i]);
sampleIndex += 9;
}
}, $fz.isPrivate = true, $fz), "~N,~A");
Clazz.defineMethod (c$, "setPointerCoordsAtSampleIndex", 
($fz = function (sampleIndex, pointerCoords) {
var dataSamples = this.mDataSamples;
dataSamples[sampleIndex + 0] = pointerCoords.x - this.mXOffset;
dataSamples[sampleIndex + 1] = pointerCoords.y - this.mYOffset;
dataSamples[sampleIndex + 2] = pointerCoords.pressure;
dataSamples[sampleIndex + 3] = pointerCoords.size;
dataSamples[sampleIndex + 4] = pointerCoords.touchMajor;
dataSamples[sampleIndex + 5] = pointerCoords.touchMinor;
dataSamples[sampleIndex + 6] = pointerCoords.toolMajor;
dataSamples[sampleIndex + 7] = pointerCoords.toolMinor;
dataSamples[sampleIndex + 8] = pointerCoords.orientation;
}, $fz.isPrivate = true, $fz), "~N,android.view.MotionEvent.PointerCoords");
Clazz.defineMethod (c$, "setPointerCoordsAtSampleIndex", 
($fz = function (sampleIndex, x, y, pressure, size) {
var dataSamples = this.mDataSamples;
dataSamples[sampleIndex + 0] = x - this.mXOffset;
dataSamples[sampleIndex + 1] = y - this.mYOffset;
dataSamples[sampleIndex + 2] = pressure;
dataSamples[sampleIndex + 3] = size;
dataSamples[sampleIndex + 4] = pressure;
dataSamples[sampleIndex + 5] = pressure;
dataSamples[sampleIndex + 6] = size;
dataSamples[sampleIndex + 7] = size;
dataSamples[sampleIndex + 8] = 0;
}, $fz.isPrivate = true, $fz), "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "incrementNumSamplesAndReserveStorage", 
($fz = function (dataSampleStride) {
if (this.mNumSamples == this.mEventTimeNanoSamples.length) {
var newEventTimeNanoSamples =  Clazz.newArray (this.mNumSamples + 8, 0);
System.arraycopy (this.mEventTimeNanoSamples, 0, newEventTimeNanoSamples, 0, this.mNumSamples);
this.mEventTimeNanoSamples = newEventTimeNanoSamples;
}var nextDataSampleIndex = this.mLastDataSampleIndex + dataSampleStride;
if (nextDataSampleIndex + dataSampleStride > this.mDataSamples.length) {
var newDataSamples =  Clazz.newArray (nextDataSampleIndex + 8 * dataSampleStride, 0);
System.arraycopy (this.mDataSamples, 0, newDataSamples, 0, nextDataSampleIndex);
this.mDataSamples = newDataSamples;
}this.mLastEventTimeNanoSampleIndex = this.mNumSamples;
this.mLastDataSampleIndex = nextDataSampleIndex;
this.mNumSamples += 1;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "addBatch", 
function (eventTime, x, y, pressure, size, metaState) {
this.incrementNumSamplesAndReserveStorage (9);
this.mEventTimeNanoSamples[this.mLastEventTimeNanoSampleIndex] = eventTime * 1000000;
this.setPointerCoordsAtSampleIndex (this.mLastDataSampleIndex, x, y, pressure, size);
this.mMetaState |= metaState;
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "addBatch", 
function (eventTime, pointerCoords, metaState) {
var dataSampleStride = this.mNumPointers * 9;
this.incrementNumSamplesAndReserveStorage (dataSampleStride);
this.mEventTimeNanoSamples[this.mLastEventTimeNanoSampleIndex] = eventTime * 1000000;
this.setPointerCoordsAtSampleIndex (this.mLastDataSampleIndex, pointerCoords);
this.mMetaState |= metaState;
}, "~N,~A,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return "{action=" + this.mAction + " x=" + this.getX () + " y=" + this.getY () + "}";
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.x = 0;
this.y = 0;
this.pressure = 0;
this.size = 0;
this.touchMajor = 0;
this.touchMinor = 0;
this.toolMajor = 0;
this.toolMinor = 0;
this.orientation = 0;
Clazz.instantialize (this, arguments);
}, android.view.MotionEvent, "PointerCoords");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"MS_PER_NS", 1000000,
"TRACK_RECYCLED_LOCATION", false,
"ACTION_MASK", 0xff,
"ACTION_DOWN", 0,
"ACTION_UP", 1,
"ACTION_MOVE", 2,
"ACTION_CANCEL", 3,
"ACTION_OUTSIDE", 4,
"ACTION_POINTER_DOWN", 5,
"ACTION_POINTER_UP", 6,
"ACTION_POINTER_INDEX_MASK", 0xff00,
"ACTION_POINTER_INDEX_SHIFT", 8,
"ACTION_POINTER_1_DOWN", 5,
"ACTION_POINTER_2_DOWN", 261,
"ACTION_POINTER_3_DOWN", 517,
"ACTION_POINTER_1_UP", 6,
"ACTION_POINTER_2_UP", 262,
"ACTION_POINTER_3_UP", 518,
"ACTION_POINTER_ID_MASK", 0xff00,
"ACTION_POINTER_ID_SHIFT", 8,
"FLAG_WINDOW_IS_OBSCURED", 0x1,
"EDGE_TOP", 0x00000001,
"EDGE_BOTTOM", 0x00000002,
"EDGE_LEFT", 0x00000004,
"EDGE_RIGHT", 0x00000008,
"SAMPLE_X", 0,
"SAMPLE_Y", 1,
"SAMPLE_PRESSURE", 2,
"SAMPLE_SIZE", 3,
"SAMPLE_TOUCH_MAJOR", 4,
"SAMPLE_TOUCH_MINOR", 5,
"SAMPLE_TOOL_MAJOR", 6,
"SAMPLE_TOOL_MINOR", 7,
"SAMPLE_ORIENTATION", 8,
"NUM_SAMPLE_DATA", 9,
"BASE_AVAIL_POINTERS", 5,
"BASE_AVAIL_SAMPLES", 8,
"MAX_RECYCLED", 10);
c$.gRecyclerLock = c$.prototype.gRecyclerLock =  new JavaObject ();
Clazz.defineStatics (c$,
"gRecyclerUsed", 0,
"gRecyclerTop", null);
});
