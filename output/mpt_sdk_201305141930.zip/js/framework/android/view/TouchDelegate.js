﻿Clazz.declarePackage ("android.view");
Clazz.load (null, "android.view.TouchDelegate", ["android.graphics.Rect", "android.view.ViewConfiguration"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDelegateView = null;
this.mBounds = null;
this.mSlopBounds = null;
this.mDelegateTargeted = false;
this.mSlop = 0;
Clazz.instantialize (this, arguments);
}, android.view, "TouchDelegate");
Clazz.makeConstructor (c$, 
function (bounds, delegateView) {
this.mBounds = bounds;
this.mSlop = android.view.ViewConfiguration.get (delegateView.getContext ()).getScaledTouchSlop ();
this.mSlopBounds =  new android.graphics.Rect (bounds);
this.mSlopBounds.inset (-this.mSlop, -this.mSlop);
this.mDelegateView = delegateView;
}, "android.graphics.Rect,android.view.View");
Clazz.defineMethod (c$, "onTouchEvent", 
function (event) {
var x = Math.round (event.getX ());
var y = Math.round (event.getY ());
var sendToDelegate = false;
var hit = true;
var handled = false;
switch (event.getAction ()) {
case 0:
var bounds = this.mBounds;
if (bounds.contains (x, y)) {
this.mDelegateTargeted = true;
sendToDelegate = true;
}break;
case 1:
case 2:
sendToDelegate = this.mDelegateTargeted;
if (sendToDelegate) {
var slopBounds = this.mSlopBounds;
if (!slopBounds.contains (x, y)) {
hit = false;
}}break;
case 3:
sendToDelegate = this.mDelegateTargeted;
this.mDelegateTargeted = false;
break;
}
if (sendToDelegate) {
var delegateView = this.mDelegateView;
if (hit) {
event.setLocation (Math.floor (delegateView.getWidth () / 2), Math.floor (delegateView.getHeight () / 2));
} else {
var slop = this.mSlop;
event.setLocation (-(slop * 2), -(slop * 2));
}handled = delegateView.dispatchTouchEvent (event);
}return handled;
}, "android.view.MotionEvent");
Clazz.defineStatics (c$,
"ABOVE", 1,
"BELOW", 2,
"TO_LEFT", 4,
"TO_RIGHT", 8);
});
