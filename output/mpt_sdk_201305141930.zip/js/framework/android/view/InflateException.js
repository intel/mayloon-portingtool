﻿Clazz.declarePackage ("android.view");
Clazz.load (["java.lang.RuntimeException"], "android.view.InflateException", null, function () {
c$ = Clazz.declareType (android.view, "InflateException", RuntimeException);
});
