﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.view.View", "android.content.res.Configuration", "android.graphics.Canvas", "$.Rect", "android.os.Handler", "$.SystemClock", "android.util.Log", "android.view.Surface", "$.SurfaceHolder", "android.view.ViewTreeObserver.OnScrollChangedListener", "android.view.WindowManager", "java.lang.Thread", "java.util.ArrayList"], "android.view.SurfaceView", ["android.graphics.PixelFormat", "$.PorterDuff", "$.Region", "java.lang.ref.WeakReference"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mCallbacks = null;
this.mLocation = null;
this.mSurface = null;
this.mDrawingStopped = true;
this.mLayout = null;
this.mWindow = null;
this.mVisibleInsets = null;
this.mWinFrame = null;
this.mContentInsets = null;
this.mConfiguration = null;
this.mWindowType = 1001;
this.mIsCreating = false;
this.mHandler = null;
this.mScrollChangedListener = null;
this.mRequestedVisible = false;
this.mWindowVisibility = false;
this.mViewVisibility = false;
this.mRequestedWidth = -1;
this.mRequestedHeight = -1;
this.mRequestedFormat = 4;
this.mRequestedType = -1;
this.mHaveFrame = false;
this.mDestroyReportNeeded = false;
this.mNewSurfaceNeeded = false;
this.mLastLockTime = 0;
this.mVisible = false;
this.$mLeft = -1;
this.$mTop = -1;
this.mWidth = -1;
this.mHeight = -1;
this.mFormat = -1;
this.mType = -1;
this.mSurfaceFrame = null;
this.mLastSurfaceWidth = -1;
this.mLastSurfaceHeight = -1;
this.mUpdateWindowNeeded = false;
this.mReportDrawNeeded = false;
this.mSurfaceHolder = null;
Clazz.instantialize (this, arguments);
}, android.view, "SurfaceView", android.view.View);
Clazz.prepareFields (c$, function () {
this.mCallbacks =  new java.util.ArrayList ();
this.mLocation =  Clazz.newArray (2, 0);
this.mSurface =  new android.view.Surface ();
this.mLayout =  new android.view.WindowManager.LayoutParams ();
this.mVisibleInsets =  new android.graphics.Rect ();
this.mWinFrame =  new android.graphics.Rect ();
this.mContentInsets =  new android.graphics.Rect ();
this.mConfiguration =  new android.content.res.Configuration ();
this.mHandler = ((Clazz.isClassDefined ("android.view.SurfaceView$1") ? 0 : android.view.SurfaceView.$SurfaceView$1$ ()), Clazz.innerTypeInstance (android.view.SurfaceView$1, this, null));
this.mScrollChangedListener = ((Clazz.isClassDefined ("android.view.SurfaceView$2") ? 0 : android.view.SurfaceView.$SurfaceView$2$ ()), Clazz.innerTypeInstance (android.view.SurfaceView$2, this, null));
this.mSurfaceFrame =  new android.graphics.Rect ();
this.mSurfaceHolder = ((Clazz.isClassDefined ("android.view.SurfaceView$3") ? 0 : android.view.SurfaceView.$SurfaceView$3$ ()), Clazz.innerTypeInstance (android.view.SurfaceView$3, this, null));
});
Clazz.makeConstructor (c$, 
function (context) {
Clazz.superConstructor (this, android.view.SurfaceView, [context]);
this.init ();
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.view.SurfaceView, [context, attrs]);
this.init ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.view.SurfaceView, [context, attrs, defStyle]);
this.init ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "init", 
($fz = function () {
this.setWillNotDraw (true);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getHolder", 
function () {
return this.mSurfaceHolder;
});
Clazz.defineMethod (c$, "onAttachedToWindow", 
function () {
Clazz.superCall (this, android.view.SurfaceView, "onAttachedToWindow", []);
this.mParent.requestTransparentRegion (this);
this.mLayout.setTitle ("SurfaceView");
this.mViewVisibility = this.getVisibility () == 0;
});
Clazz.defineMethod (c$, "onWindowVisibilityChanged", 
function (visibility) {
Clazz.superCall (this, android.view.SurfaceView, "onWindowVisibilityChanged", [visibility]);
this.mWindowVisibility = visibility == 0;
this.mRequestedVisible = this.mWindowVisibility && this.mViewVisibility;
this.updateWindow (false, false);
}, "~N");
Clazz.defineMethod (c$, "setVisibility", 
function (visibility) {
Clazz.superCall (this, android.view.SurfaceView, "setVisibility", [visibility]);
this.mViewVisibility = visibility == 0;
this.mRequestedVisible = this.mWindowVisibility && this.mViewVisibility;
this.updateWindow (false, false);
}, "~N");
Clazz.defineMethod (c$, "showSurface", 
function () {
});
Clazz.defineMethod (c$, "hideSurface", 
function () {
});
Clazz.defineMethod (c$, "onDetachedFromWindow", 
function () {
this.mRequestedVisible = false;
this.updateWindow (false, false);
this.mHaveFrame = false;
if (this.mWindow != null) {
this.mWindow = null;
}this.mLayout.token = null;
Clazz.superCall (this, android.view.SurfaceView, "onDetachedFromWindow", []);
});
Clazz.overrideMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
var width = android.view.View.getDefaultSize (this.mRequestedWidth, widthMeasureSpec);
var height = android.view.View.getDefaultSize (this.mRequestedHeight, heightMeasureSpec);
this.setMeasuredDimension (width, height);
}, "~N,~N");
Clazz.defineMethod (c$, "setFrame", 
function (left, top, right, bottom) {
var result = Clazz.superCall (this, android.view.SurfaceView, "setFrame", [left, top, right, bottom]);
this.updateWindow (false, false);
return result;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "gatherTransparentRegion", 
function (region) {
var opaque = true;
if ((this.mPrivateFlags & 128) == 0) {
} else if (region != null) {
var w = this.getWidth ();
var h = this.getHeight ();
if (w > 0 && h > 0) {
this.getLocationInWindow (this.mLocation);
var l = this.mLocation[0];
var t = this.mLocation[1];
region.op (l, t, l + w, t + h, android.graphics.Region.Op.UNION);
}}if (android.graphics.PixelFormat.formatHasAlpha (this.mRequestedFormat)) {
opaque = false;
}return opaque;
}, "android.graphics.Region");
Clazz.defineMethod (c$, "draw", 
function (canvas) {
if (this.mWindowType != 1000) {
if ((this.mPrivateFlags & 128) == 0) {
canvas.drawColor (0, android.graphics.PorterDuff.Mode.CLEAR);
}}Clazz.superCall (this, android.view.SurfaceView, "draw", [canvas]);
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "dispatchDraw", 
function (canvas) {
if (this.mWindowType != 1000) {
if ((this.mPrivateFlags & 128) == 128) {
canvas.drawColor (0, android.graphics.PorterDuff.Mode.CLEAR);
}}this.mHaveFrame = true;
this.updateWindow (false, false);
Clazz.superCall (this, android.view.SurfaceView, "dispatchDraw", [canvas]);
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "setZOrderMediaOverlay", 
function (isMediaOverlay) {
this.mWindowType = isMediaOverlay ? 1004 : 1001;
}, "~B");
Clazz.defineMethod (c$, "setZOrderOnTop", 
function (onTop) {
if (onTop) {
this.mWindowType = 1000;
this.mLayout.flags |= 131072;
} else {
this.mWindowType = 1001;
this.mLayout.flags &= -131073;
}}, "~B");
Clazz.defineMethod (c$, "setWindowType", 
function (type) {
this.mWindowType = type;
}, "~N");
Clazz.defineMethod (c$, "updateWindow", 
($fz = function (force, redrawNeeded) {
if (!this.mHaveFrame) {
return ;
}var viewRoot = this.getRootView ().getParent ();
if (viewRoot != null) {
}var res = this.getContext ().getResources ();
var myWidth = this.mRequestedWidth;
if (myWidth <= 0) myWidth = this.getWidth ();
var myHeight = this.mRequestedHeight;
if (myHeight <= 0) myHeight = this.getHeight ();
this.getLocationInWindow (this.mLocation);
var creating = this.mWindow == null;
var formatChanged = this.mFormat != this.mRequestedFormat;
var sizeChanged = this.mWidth != myWidth || this.mHeight != myHeight;
var visibleChanged = this.mVisible != this.mRequestedVisible || this.mNewSurfaceNeeded;
var typeChanged = this.mType != this.mRequestedType;
if (force || creating || formatChanged || sizeChanged || visibleChanged || typeChanged || this.$mLeft != this.mLocation[0] || this.$mTop != this.mLocation[1] || this.mUpdateWindowNeeded || this.mReportDrawNeeded || redrawNeeded) {
if (true) android.util.Log.i ("SurfaceView", "Changes: creating=" + creating + " format=" + formatChanged + " size=" + sizeChanged + " visible=" + visibleChanged + " left=" + (this.$mLeft != this.mLocation[0]) + " top=" + (this.$mTop != this.mLocation[1]));
try {
var visible = this.mVisible = this.mRequestedVisible;
this.$mLeft = this.mLocation[0];
this.$mTop = this.mLocation[1];
this.mWidth = myWidth;
this.mHeight = myHeight;
this.mFormat = this.mRequestedFormat;
this.mType = this.mRequestedType;
this.mLayout.x = this.$mLeft;
this.mLayout.y = this.$mTop;
this.mLayout.width = this.getWidth ();
this.mLayout.height = this.getHeight ();
this.mLayout.format = this.mRequestedFormat;
this.mLayout.flags |= 16920;
this.mLayout.memoryType = this.mRequestedType;
if (this.mWindow == null) {
this.mWindow =  new android.view.SurfaceView.MyWindow (this);
this.mLayout.type = this.mWindowType;
this.mLayout.gravity = 51;
}if (visibleChanged && (!visible || this.mNewSurfaceNeeded)) {
this.reportSurfaceDestroyed ();
}this.mNewSurfaceNeeded = false;
var realSizeChanged;
var reportDrawNeeded;
try {
this.mUpdateWindowNeeded = false;
reportDrawNeeded = this.mReportDrawNeeded;
this.mReportDrawNeeded = false;
this.mDrawingStopped = !visible;
if (true) android.util.Log.i ("SurfaceView", "New surface: " + this.mSurface + ", vis=" + visible + ", frame=" + this.mWinFrame);
this.mSurfaceFrame.left = 0;
this.mSurfaceFrame.top = 0;
this.mSurfaceFrame.right = this.mWinFrame.width ();
this.mSurfaceFrame.bottom = this.mWinFrame.height ();
var surfaceWidth = this.mSurfaceFrame.right;
var surfaceHeight = this.mSurfaceFrame.bottom;
realSizeChanged = this.mLastSurfaceWidth != surfaceWidth || this.mLastSurfaceHeight != surfaceHeight;
this.mLastSurfaceWidth = surfaceWidth;
this.mLastSurfaceHeight = surfaceHeight;
} finally {
}
try {
redrawNeeded = new Boolean (redrawNeeded | ( new Boolean (creating | reportDrawNeeded).valueOf ())).valueOf ();
if (visible) {
this.mDestroyReportNeeded = true;
var callbacks;
{
callbacks =  new Array (this.mCallbacks.size ());
this.mCallbacks.toArray (callbacks);
}if (visibleChanged) {
this.mIsCreating = true;
for (var c, $c = 0, $$c = callbacks; $c < $$c.length && ((c = $$c[$c]) || true); $c++) {
c.surfaceCreated (this.mSurfaceHolder);
}
}if (creating || formatChanged || sizeChanged || visibleChanged || realSizeChanged) {
for (var c, $c = 0, $$c = callbacks; $c < $$c.length && ((c = $$c[$c]) || true); $c++) {
c.surfaceChanged (this.mSurfaceHolder, this.mFormat, myWidth, myHeight);
}
}if (redrawNeeded) {
for (var c, $c = 0, $$c = callbacks; $c < $$c.length && ((c = $$c[$c]) || true); $c++) {
if (Clazz.instanceOf (c, android.view.SurfaceHolder.Callback2)) {
(c).surfaceRedrawNeeded (this.mSurfaceHolder);
}}
}} else {
this.mSurface.release ();
}} finally {
this.mIsCreating = false;
}
} catch (ex) {
if (Clazz.instanceOf (ex, Exception)) {
} else {
throw ex;
}
}
if (true) android.util.Log.v ("SurfaceView", "Layout: x=" + this.mLayout.x + " y=" + this.mLayout.y + " w=" + this.mLayout.width + " h=" + this.mLayout.height + ", frame=" + this.mSurfaceFrame);
}}, $fz.isPrivate = true, $fz), "~B,~B");
Clazz.defineMethod (c$, "reportSurfaceDestroyed", 
($fz = function () {
if (this.mDestroyReportNeeded) {
this.mDestroyReportNeeded = false;
var callbacks;
{
callbacks =  new Array (this.mCallbacks.size ());
this.mCallbacks.toArray (callbacks);
}for (var c, $c = 0, $$c = callbacks; $c < $$c.length && ((c = $$c[$c]) || true); $c++) {
c.surfaceDestroyed (this.mSurfaceHolder);
}
}Clazz.superCall (this, android.view.SurfaceView, "onDetachedFromWindow", []);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "handleGetNewSurface", 
function () {
this.mNewSurfaceNeeded = true;
this.updateWindow (false, false);
});
Clazz.defineMethod (c$, "isFixedSize", 
function () {
return (this.mRequestedWidth != -1 || this.mRequestedHeight != -1);
});
c$.$SurfaceView$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view, "SurfaceView$1", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (msg) {
switch (msg.what) {
case 1:
{
this.b$["android.view.SurfaceView"].setKeepScreenOn (msg.arg1 != 0);
}break;
case 2:
{
this.b$["android.view.SurfaceView"].handleGetNewSurface ();
}break;
case 3:
{
this.b$["android.view.SurfaceView"].updateWindow (false, false);
}break;
}
}, "android.os.Message");
c$ = Clazz.p0p ();
};
c$.$SurfaceView$2$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view, "SurfaceView$2", null, android.view.ViewTreeObserver.OnScrollChangedListener);
Clazz.overrideMethod (c$, "onScrollChanged", 
function () {
this.b$["android.view.SurfaceView"].updateWindow (false, false);
});
c$ = Clazz.p0p ();
};
c$.$SurfaceView$3$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view, "SurfaceView$3", null, android.view.SurfaceHolder);
Clazz.overrideMethod (c$, "isCreating", 
function () {
return this.b$["android.view.SurfaceView"].mIsCreating;
});
Clazz.overrideMethod (c$, "getCanvasID", 
function () {
var canvasid = null;
var viewRoot = this.b$["android.view.SurfaceView"].getRootView ().getParent ();
canvasid = viewRoot.getFgCanvasId();
return canvasid;
});
Clazz.overrideMethod (c$, "addCallback", 
function (callback) {
{
if (this.b$["android.view.SurfaceView"].mCallbacks.contains (callback) == false) {
this.b$["android.view.SurfaceView"].mCallbacks.add (callback);
}}}, "android.view.SurfaceHolder.Callback");
Clazz.overrideMethod (c$, "removeCallback", 
function (callback) {
{
this.b$["android.view.SurfaceView"].mCallbacks.remove (callback);
}}, "android.view.SurfaceHolder.Callback");
Clazz.overrideMethod (c$, "setFixedSize", 
function (width, height) {
if (this.b$["android.view.SurfaceView"].mRequestedWidth != width || this.b$["android.view.SurfaceView"].mRequestedHeight != height) {
this.b$["android.view.SurfaceView"].mRequestedWidth = width;
this.b$["android.view.SurfaceView"].mRequestedHeight = height;
this.b$["android.view.SurfaceView"].requestLayout ();
}}, "~N,~N");
Clazz.overrideMethod (c$, "setSizeFromLayout", 
function () {
if (this.b$["android.view.SurfaceView"].mRequestedWidth != -1 || this.b$["android.view.SurfaceView"].mRequestedHeight != -1) {
this.b$["android.view.SurfaceView"].mRequestedWidth = this.b$["android.view.SurfaceView"].mRequestedHeight = -1;
this.b$["android.view.SurfaceView"].requestLayout ();
}});
Clazz.overrideMethod (c$, "setFormat", 
function (format) {
if (format == -1) format = 4;
this.b$["android.view.SurfaceView"].mRequestedFormat = format;
if (this.b$["android.view.SurfaceView"].mWindow != null) {
this.b$["android.view.SurfaceView"].updateWindow (false, false);
}}, "~N");
Clazz.overrideMethod (c$, "setType", 
function (type) {
switch (type) {
case 1:
case 2:
type = 0;
break;
}
switch (type) {
case 0:
case 3:
this.b$["android.view.SurfaceView"].mRequestedType = type;
if (this.b$["android.view.SurfaceView"].mWindow != null) {
this.b$["android.view.SurfaceView"].updateWindow (false, false);
}break;
}
}, "~N");
Clazz.overrideMethod (c$, "setKeepScreenOn", 
function (screenOn) {
var msg = this.b$["android.view.SurfaceView"].mHandler.obtainMessage (1);
msg.arg1 = screenOn ? 1 : 0;
this.b$["android.view.SurfaceView"].mHandler.sendMessage (msg);
}, "~B");
Clazz.defineMethod (c$, "lockCanvas", 
function () {
return this.lockCanvas ( new android.graphics.Rect (0, 0, this.b$["android.view.SurfaceView"].getRight () - this.b$["android.view.SurfaceView"].getLeft (), this.b$["android.view.SurfaceView"].getBottom () - this.b$["android.view.SurfaceView"].getTop ()));
});
Clazz.defineMethod (c$, "lockCanvas", 
function (dirty) {
try {
var viewRoot = this.b$["android.view.SurfaceView"].getRootView ().getParent ();
if (viewRoot == null) {
return null;
}var surfaceViewCanvasID = viewRoot.getCanvasId () + "-SurfaceView";
var zInx = this.b$["android.view.SurfaceView"].getZIndex () + 1;
var canvas = document.getElementById(surfaceViewCanvasID);
if (canvas == null) {
canvas = document.createElement('canvas');
canvas.id = surfaceViewCanvasID;
canvas.style.zIndex = zInx;//2147483647; // Maximum z-index value of most browsers
canvas.style.position = 'absolute';
}
if(dirty != null) {
canvas.style.left = this.b$["android.view.SurfaceView"].getLeft() + dirty.left + 'px';
canvas.style.top = this.b$["android.view.SurfaceView"].getTop() + dirty.top + 'px';
canvas.width = dirty.width();
canvas.height = dirty.height();
}
else {
canvas.style.left = this.b$["android.view.SurfaceView"].getLeft() + 'px';
canvas.style.top = this.b$["android.view.SurfaceView"].getTop()  + 'px';
canvas.width = this.b$["android.view.SurfaceView"].getWidth();
canvas.height = this.b$["android.view.SurfaceView"].getHeight();
}
try{
document.getElementById(viewRoot.getCanvasId()).parentNode.appendChild(canvas);
}catch(e){
return null;
}
var c =  new android.graphics.Canvas (null, surfaceViewCanvasID);
c.chooseCanvas (android.graphics.Canvas.SURFACEVIEW_CANVAS);
return c;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
return null;
} else {
throw e;
}
}
}, "android.graphics.Rect");
Clazz.overrideMethod (c$, "unlockCanvasAndPost", 
function (canvas) {
var viewRoot = this.b$["android.view.SurfaceView"].getRootView ().getParent ();
if (viewRoot == null) {
return ;
}}, "android.graphics.Canvas");
Clazz.overrideMethod (c$, "getSurface", 
function () {
return this.b$["android.view.SurfaceView"].mSurface;
});
Clazz.overrideMethod (c$, "getSurfaceFrame", 
function () {
return this.b$["android.view.SurfaceView"].mSurfaceFrame;
});
c$.LOG_TAG = "SurfaceHolder";
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mSurfaceView = null;
this.mCurWidth = -1;
this.mCurHeight = -1;
Clazz.instantialize (this, arguments);
}, android.view.SurfaceView, "MyWindow");
Clazz.makeConstructor (c$, 
function (a) {
this.mSurfaceView =  new java.lang.ref.WeakReference (a);
}, "android.view.SurfaceView");
Clazz.defineMethod (c$, "resized", 
function (a, b, c, d, e, f) {
var g = this.mSurfaceView.get ();
if (g != null) {
if (true) android.util.Log.v ("SurfaceView", g + " got resized: w=" + a + " h=" + b + ", cur w=" + this.mCurWidth + " h=" + this.mCurHeight);
try {
if (e) {
g.mUpdateWindowNeeded = true;
g.mReportDrawNeeded = true;
g.mHandler.sendEmptyMessage (3);
} else if (g.mWinFrame.width () != a || g.mWinFrame.height () != b) {
g.mUpdateWindowNeeded = true;
g.mHandler.sendEmptyMessage (3);
}} finally {
}
}}, "~N,~N,android.graphics.Rect,android.graphics.Rect,~B,android.content.res.Configuration");
Clazz.defineMethod (c$, "dispatchAppVisibility", 
function (a) {
}, "~B");
Clazz.defineMethod (c$, "dispatchGetNewSurface", 
function () {
var a = this.mSurfaceView.get ();
if (a != null) {
var b = a.mHandler.obtainMessage (2);
a.mHandler.sendMessage (b);
}});
Clazz.defineMethod (c$, "windowFocusChanged", 
function (a, b) {
android.util.Log.w ("SurfaceView", "Unexpected focus in surface: focus=" + a + ", touchEnabled=" + b);
}, "~B,~B");
Clazz.defineMethod (c$, "executeCommand", 
function (a, b, c) {
}, "~S,~S,android.os.ParcelFileDescriptor");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "SurfaceView",
"DEBUG", true,
"localLOGV", true ? true : false,
"KEEP_SCREEN_ON_MSG", 1,
"GET_NEW_SURFACE_MSG", 2,
"UPDATE_WINDOW_MSG", 3);
});
