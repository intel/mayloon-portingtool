﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.view.Menu"], "android.view.SubMenu", null, function () {
Clazz.declareInterface (android.view, "SubMenu", android.view.Menu);
});
