﻿Clazz.declarePackage ("android.view");
c$ = Clazz.decorateAsClass (function () {
this.mDisplay = 0;
this.mPixelFormat = 0;
this.mRefreshRate = 0;
this.mDensity = 0;
this.mDpiX = 0;
this.mDpiY = 0;
Clazz.instantialize (this, arguments);
}, android.view, "Display");
Clazz.makeConstructor (c$, 
function (display) {
{
if (!android.view.Display.mInitialized) {
android.view.Display.nativeClassInit ();
($t$ = android.view.Display.mInitialized = true, android.view.Display.prototype.mInitialized = android.view.Display.mInitialized, $t$);
}}this.mDisplay = display;
this.init (display);
}, "~N");
Clazz.defineMethod (c$, "getDisplayId", 
function () {
return this.mDisplay;
});
c$.getDisplayCount = Clazz.defineMethod (c$, "getDisplayCount", 
function () {
return 1000;
});
Clazz.defineMethod (c$, "getWidth", 
function () {
var width = 480;
width = window.innerWidth;
return width;
});
Clazz.defineMethod (c$, "getHeight", 
function () {
var height = 800;
height = window.innerHeight;
return height;
});
Clazz.defineMethod (c$, "getRotation", 
function () {
return this.getOrientation ();
});
Clazz.defineMethod (c$, "getOrientation", 
function () {
if (window.DeviceOrientationEvent) {
console.log("DeviceOrientation is supported on this device");
window.addEventListener("deviceorientation",
function dzorien(evt) { android.view.Display.orientation = evt.alpha; },true);
} else if (window.OrientationEvent) {
console.log("DeviceOrientation is supported on this device via MozOrientation");
window.addEventListener('MozOrientation',
function mozorien(evt) { android.view.Display.orientation = evt.alpha;});
};
return android.view.Display.orientation;
});
Clazz.defineMethod (c$, "getPixelFormat", 
function () {
return this.mPixelFormat;
});
Clazz.defineMethod (c$, "getRefreshRate", 
function () {
return this.mRefreshRate;
});
Clazz.defineMethod (c$, "getMetrics", 
function (outMetrics) {
outMetrics.setToDefaults ();
outMetrics.widthPixels = this.getWidth ();
outMetrics.heightPixels = this.getHeight ();
this.mDensity = outMetrics.density;
outMetrics.xdpi = this.getWidth () / outMetrics.density;
outMetrics.ydpi = this.getHeight () / outMetrics.density;
}, "android.util.DisplayMetrics");
c$.nativeClassInit = Clazz.defineMethod (c$, "nativeClassInit", 
($fz = function () {
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "init", 
($fz = function (display) {
this.mDensity = 1.0;
this.mRefreshRate = 60;
this.mPixelFormat = 1;
}, $fz.isPrivate = true, $fz), "~N");
c$.createMetricsBasedDisplay = Clazz.defineMethod (c$, "createMetricsBasedDisplay", 
function (displayId, metrics) {
return  new android.view.Display.CompatibleDisplay (displayId, metrics);
}, "~N,android.util.DisplayMetrics");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mMetrics = null;
Clazz.instantialize (this, arguments);
}, android.view.Display, "CompatibleDisplay", android.view.Display);
Clazz.makeConstructor (c$, 
($fz = function (a, b) {
Clazz.superConstructor (this, android.view.Display.CompatibleDisplay, [a]);
this.mMetrics = b;
}, $fz.isPrivate = true, $fz), "~N,android.util.DisplayMetrics");
Clazz.overrideMethod (c$, "getWidth", 
function () {
return this.mMetrics.widthPixels;
});
Clazz.overrideMethod (c$, "getHeight", 
function () {
return this.mMetrics.heightPixels;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DEFAULT_DISPLAY", 0,
"orientation", 1);
c$.mStaticInit = c$.prototype.mStaticInit =  new JavaObject ();
Clazz.defineStatics (c$,
"mInitialized", false);
