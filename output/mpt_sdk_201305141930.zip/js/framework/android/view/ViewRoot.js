﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.os.Handler", "android.view.View", "$.ViewParent", "android.util.SparseArray", "android.view.WindowManager", "java.util.ArrayList"], "android.view.ViewRoot", ["android.content.Context", "android.graphics.Canvas", "$.PixelFormat", "$.Rect", "android.os.SystemClock", "android.util.Log", "android.view.Gravity", "$.HTML5Event", "$.InputQueue", "$.MotionEvent", "$.ViewConfiguration", "$.ViewGroup", "java.lang.IllegalArgumentException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mTmpLocation = null;
this.mPendingEvents = null;
this.mPendingEventSeq = 0;
this.mWindowAttributes = null;
this.mView = null;
this.mFocusedView = null;
this.mRealFocusedView = null;
this.mViewVisibility = 0;
this.mAppVisible = true;
this.mIsCreating = false;
this.mDrawingAllowed = false;
this.mWidth = 0;
this.mHeight = 0;
this.mIsAnimating = false;
this.mAttachInfo = null;
this.mInputChannel = null;
this.mInputQueueCallback = null;
this.mInputQueue = null;
this.mTraversalScheduled = false;
this.mWillDrawSoon = false;
this.mLayoutRequested = false;
this.mFirst = false;
this.mReportNextDraw = false;
this.mFullRedrawNeeded = false;
this.mNewSurfaceNeeded = false;
this.mHasHadWindowFocus = false;
this.mLastWasImTarget = false;
this.mWindowAttributesChanged = false;
this.mAdded = false;
this.mAddedTouchMode = false;
this.mWinFrame = null;
this.mAddNesting = 0;
this.mScrollMayChange = false;
this.mSoftInputMode = 0;
this.mLastScrolledFocus = null;
this.mScrollY = 0;
this.mCurScrollY = 0;
this.mUseGL = false;
this.mGlWanted = false;
this.mAttached = false;
this.mViewConfiguration = null;
this.mViewRootID = null;
this.mTempRect = null;
this.mVisRect = null;
this.mCanvas = null;
this.mDirty = null;
Clazz.instantialize (this, arguments);
}, android.view, "ViewRoot", android.os.Handler, [android.view.ViewParent, android.view.View.AttachInfo.Callbacks]);
Clazz.prepareFields (c$, function () {
this.mTmpLocation =  Clazz.newArray (2, 0);
this.mPendingEvents =  new android.util.SparseArray ();
this.mWindowAttributes =  new android.view.WindowManager.LayoutParams ();
});
Clazz.defineMethod (c$, "getViewRootID", 
function () {
return this.mViewRootID;
});
Clazz.defineMethod (c$, "getCanvasSuffix", 
($fz = function () {
return "_AppCanvas";
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getCanvasId", 
function () {
return this.getViewRootID () + this.getCanvasSuffix ();
});
c$.getAViewRootID = Clazz.defineMethod (c$, "getAViewRootID", 
($fz = function () {
return ($t$ = android.view.ViewRoot.viewRootID ++, android.view.ViewRoot.prototype.viewRootID = android.view.ViewRoot.viewRootID, $t$);
}, $fz.isPrivate = true, $fz));
Clazz.makeConstructor (c$, 
function (context) {
Clazz.superConstructor (this, android.view.ViewRoot, []);
this.mWidth = -1;
this.mHeight = -1;
this.mFirst = true;
this.mAdded = false;
var w = 480;
var h = 800;
w = window.innerWidth;
h = window.innerHeight;
this.mWinFrame =  new android.graphics.Rect (0, 0, w, h);
this.mAttachInfo =  new android.view.View.AttachInfo (null, this, this);
this.mViewConfiguration = android.view.ViewConfiguration.get (context);
this.mDirty =  new android.graphics.Rect ();
this.mViewRootID = "ViewRoot_" + android.view.ViewRoot.getAViewRootID ();
this.mTempRect =  new android.graphics.Rect ();
this.mVisRect =  new android.graphics.Rect ();
var rootView = document.getElementById(this.mViewRootID);
if (rootView != null)
alert("rootView != null ??!! rootViewID: " + this.mViewRootID);
rootView = document.createElement("span");
rootView.style.position = "absolute";
rootView.style.display = "block";
rootView.style.visibility = "hidden";
rootView.id = this.mViewRootID;
rootView.style.left = "0px";
rootView.style.top = "0px";
rootView.tabIndex = "-1";
rootView.style["background-color"] = "silver";
document.body.appendChild(rootView);
// Canvas to draw on
var canvas = document.createElement("canvas");
canvas.id = this.mViewRootID + this.getCanvasSuffix();
canvas.style.position = "absolute";
canvas.getContext("2d").globalCompositeOperation = 'destination-atop';
canvas.getContext("2d").fillStyle = 'rgba(255,255,255,1)';
rootView.appendChild(canvas);
this.attachHandlerToView (this.mViewRootID);
this.mCanvas =  new android.graphics.Canvas (this.getCanvasId ());
android.view.ViewRoot.viewRootList.add (this);
}, "android.content.Context");
Clazz.defineMethod (c$, "attachHandlerToView", 
function (uid) {
var elem = document.getElementById(uid);
if (elem == null) return;
var viewRoot = this;
android.util.Log.d ("ViewRoot", "Attaching handlers");
for (var i = 0; i < android.view.HTML5Event.eventType.length; i++) {
var eventTypeName = android.view.HTML5Event.eventType[i];
elem.addEventListener(eventTypeName, function(event){viewRoot.eventForwarder(event);}, true);
}
}, "~S");
c$.simulateBack = Clazz.defineMethod (c$, "simulateBack", 
function () {
var keyEvent = android.view.HTML5Event.toKeyEvent ("keydown", 115);
var viewRoot = android.view.ViewRoot.viewRootList.get (android.view.ViewRoot.viewRootList.size () - 1);
viewRoot.deliverKeyEventToViewHierarchy (keyEvent, false);
});
c$.simulateMenu = Clazz.defineMethod (c$, "simulateMenu", 
function () {
var keyEvent = android.view.HTML5Event.toKeyEvent ("keydown", 118);
var viewRoot = android.view.ViewRoot.viewRootList.get (android.view.ViewRoot.viewRootList.size () - 1);
viewRoot.deliverKeyEventToViewHierarchy (keyEvent, false);
});
c$.getInstanceCount = Clazz.defineMethod (c$, "getInstanceCount", 
function () {
return android.view.ViewRoot.sInstanceCount;
});
Clazz.defineMethod (c$, "eventForwarder", 
function (e) {
var eventType = null;
var divID = "";
spanID = e.target.id;
eventType = e.type;
var span = document.getElementById(spanID);
if (span == null) {
alert("finding: " + span + ", for eventType: " + e.type);
return;
}
//span.hidden = "hidden";
if (android.view.HTML5Event.isMouseEvent(eventType)) {
var targetElem = document.elementFromPoint(e.clientX, e.clientY);
if (targetElem == null) return;
}
//span.hidden = null;
var keyCode = -1;
if (android.view.HTML5Event.isKeyEvent (eventType)) {
keyCode = e.keyCode ? e.keyCode : e.which;
var keyEvent = android.view.HTML5Event.toKeyEvent (eventType, keyCode);
var viewRoot = android.view.ViewRoot.viewRootList.get (android.view.ViewRoot.viewRootList.size () - 1);
viewRoot.deliverKeyEventToViewHierarchy (keyEvent, false);
} else if (eventType === "focusout") {
var thisText = e.target;
if ((thisText.tagName == "INPUT") && (thisText.style.textAlign == "right")) {
thisText.scrollLeft = thisText.scrollWidth - thisText.clientWidth
+ thisText.style.paddingRight.substr(0, thisText.style.paddingRight.length - 2)
+ thisText.style.paddingLeft.substr(0, thisText.style.paddingLeft.length - 2);
}
} else {
var x = 0;
var y = 0;
x = e.pageX; y = e.pageY;
this.dispatchPointerEvent (e, eventType, x, y);
}}, "~O");
Clazz.defineMethod (c$, "deliverKeyEventToViewHierarchy", 
($fz = function (event, sendDone) {
try {
if (this.mView != null && this.mAdded && event != null) {
var action = event.getAction ();
var isDown = (action == 0);
var keyHandled = this.mView.dispatchKeyEvent (event);
if (!keyHandled && isDown) {
var direction = 0;
switch (event.getKeyCode ()) {
case 37:
direction = 17;
break;
case 39:
direction = 66;
break;
case 38:
direction = 33;
break;
case 40:
direction = 130;
break;
}
if (direction != 0) {
var focused = this.mView != null ? this.mView.findFocus () : null;
if (focused != null) {
var v = focused.focusSearch (direction);
var focusPassed = false;
if (v != null && v !== focused) {
focused.getFocusedRect (this.mTempRect);
if (Clazz.instanceOf (this.mView, android.view.ViewGroup)) {
(this.mView).offsetDescendantRectToMyCoords (focused, this.mTempRect);
(this.mView).offsetRectIntoDescendantCoords (v, this.mTempRect);
}focusPassed = v.requestFocus (direction, this.mTempRect);
}if (!focusPassed) {
this.mView.dispatchUnhandledMove (focused, direction);
}}}}}} finally {
}
}, $fz.isPrivate = true, $fz), "android.view.KeyEvent,~B");
Clazz.defineMethod (c$, "dispatchPointerEvent", 
function (e, eventType, x, y) {
e.stopPropagation();
var cur = (android.content.Context.getSystemContext ().getSystemService ("activity")).mCurActivity;
if (cur == null) {
android.util.Log.e ("ViewRoot", "mCurActivity is null?!");
return ;
}var action;
if (eventType.equals ("mousedown")) {
action = 0;
} else if (eventType.equals ("mouseup")) {
action = 1;
} else if (eventType.equals ("mouseleave") || eventType.equals ("mouseout")) {
action = 3;
} else if (eventType.equals ("mouseenter") || eventType.equals ("mouseover")) {
return ;
} else if (eventType.equals ("mousemove")) {
action = 2;
} else {
return ;
}if (this.mView != null) x = x - this.mAttachInfo.mWindowLeft;
y = y - this.mAttachInfo.mWindowTop;
this.mView.dispatchTouchEvent (android.view.MotionEvent.obtain (0, 0, action, x, y, 0));
}, "~O,~S,~N,~N");
c$.isInTouchMode = Clazz.defineMethod (c$, "isInTouchMode", 
function () {
return false;
});
Clazz.defineMethod (c$, "getView", 
function () {
return this.mView;
});
Clazz.overrideMethod (c$, "requestLayout", 
function () {
this.mLayoutRequested = true;
this.scheduleTraversals ();
});
Clazz.overrideMethod (c$, "isLayoutRequested", 
function () {
return this.mLayoutRequested;
});
Clazz.overrideMethod (c$, "getParent", 
function () {
return null;
});
Clazz.overrideMethod (c$, "bringChildToFront", 
function (child) {
}, "android.view.View");
Clazz.defineMethod (c$, "scheduleTraversals", 
function () {
if (!this.mTraversalScheduled) {
this.mTraversalScheduled = true;
this.sendEmptyMessage (1000);
}});
Clazz.defineMethod (c$, "unscheduleTraversals", 
function () {
if (this.mTraversalScheduled) {
this.mTraversalScheduled = false;
this.removeMessages (1000);
}});
Clazz.defineMethod (c$, "setView", 
function (view, attrs, panelParentView) {
if (!(Clazz.instanceOf (view, android.view.Window.DecorView))) {
throw  new IllegalArgumentException ("view must be an instance of DecorView");
}if (this.mView == null) {
this.mView = view;
this.mWindowAttributes.copyFrom (attrs);
attrs = this.mWindowAttributes;
this.mSoftInputMode = attrs.softInputMode;
this.mWindowAttributesChanged = true;
this.mAttachInfo.mRootView = view;
this.mAttachInfo.mApplicationScale = 1.0;
this.mAdded = true;
this.makeHostView (view);
this.requestLayout ();
}}, "android.view.View,android.view.WindowManager.LayoutParams,android.view.View");
Clazz.defineMethod (c$, "makeHostView", 
($fz = function (view) {
view.assignParent (this, true);
if (!(Clazz.instanceOf (view, android.view.Window.DecorView))) {
view.zIndex = 10;
var thisView = document.getElementById(view.getUIElementID());
if (null == thisView) {
thisView = document.createElement("span");
thisView.style.position = "absolute";
thisView.id = view.getUIElementID();
thisView.style.display = "block";
}
document.body.appendChild(thisView);
return ;
}var decorViewID = view.getUIElementID ();
var decorZIndex = view.getZIndex ();
if (view.getWidth () != 0 && view.getHeight () != 0) {
this.mWinFrame =  new android.graphics.Rect (0, 0, view.getWidth (), view.getHeight ());
}var rootView = document.getElementById(this.mViewRootID);
rootView.style.zIndex = decorZIndex;
// Canvas to draw on
rootView.childNodes[0].style.zIndex = decorZIndex - 1;
// attach decorView
var decorView = document.getElementById(decorViewID);
if (decorView == null) {
alert("decorView is not created in DOM tree when being attached to a ViewRoot");
}
if (!android.util.DebugUtils.DEBUG_VIEW_IN_BROWSER) {
decorView.id = this.mViewRootID + "_DecorView";
}
decorView.style.zIndex = decorZIndex;
rootView.appendChild(decorView);
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "setOuterDimension", 
($fz = function (width, height) {
this.mWidth = width;
this.mHeight = height;
var rootView = document.getElementById(this.mViewRootID);
if (rootView != null) {
rootView.style.width = width + "px";
rootView.style.height = height + "px";
var appCanvas = rootView.childNodes[0];
if (appCanvas != null) {
if (appCanvas.width != width || appCanvas.height != height) {
appCanvas.width = width;
appCanvas.height = height;
}
}
}
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "setOuterPosition", 
($fz = function (left, top) {
var rootView = document.getElementById(this.mViewRootID);
if (rootView != null) {
rootView.style.left = left + "px";
rootView.style.top = top + "px";
}
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "setVisibility", 
function (visibility) {
var visible = "visible";
if (visibility != 0) visible = "hidden";
var thisView = document.getElementById(this.mViewRootID);
if (thisView != null)
thisView.style.visibility = visible;
}, "~N");
Clazz.defineMethod (c$, "performTraversals", 
($fz = function () {
var host = this.mView;
if (false) {
System.out.println ("======================================");
System.out.println ("performTraversals Start");
}if (host == null || !this.mAdded) return ;
this.mTraversalScheduled = false;
this.mWillDrawSoon = true;
var windowResizesToFitContent = false;
var fullRedrawNeeded = this.mFullRedrawNeeded;
var newSurface = false;
var surfaceChanged = false;
var lp = this.mWindowAttributes;
var desiredWindowWidth;
var desiredWindowHeight;
var childWidthMeasureSpec;
var childHeightMeasureSpec;
var attachInfo = this.mAttachInfo;
var viewVisibility = this.getHostVisibility ();
this.setVisibility (viewVisibility);
var viewVisibilityChanged = this.mViewVisibility != viewVisibility || this.mNewSurfaceNeeded;
var params = null;
if (this.mWindowAttributesChanged) {
this.mWindowAttributesChanged = false;
surfaceChanged = true;
params = lp;
}var frame = this.mWinFrame;
if (this.mFirst) {
newSurface = true;
fullRedrawNeeded = true;
this.mLayoutRequested = true;
var packageMetrics = this.mView.getContext ().getResources ().getDisplayMetrics ();
desiredWindowWidth = packageMetrics.widthPixels;
desiredWindowHeight = packageMetrics.heightPixels;
attachInfo.mHasWindowFocus = false;
attachInfo.mWindowVisibility = viewVisibility;
attachInfo.mRecomputeGlobalAttributes = false;
attachInfo.mKeepScreenOn = false;
viewVisibilityChanged = false;
if (!this.mAttached) {
this.mAttached = true;
host.dispatchAttachedToWindow (attachInfo, 0);
}} else {
desiredWindowWidth = frame.width ();
desiredWindowHeight = frame.height ();
if (desiredWindowWidth != this.mWidth || desiredWindowHeight != this.mHeight) {
fullRedrawNeeded = true;
this.mLayoutRequested = true;
windowResizesToFitContent = true;
}}if (viewVisibilityChanged) {
android.util.Log.d ("ViewRoot", "viewVisibilityChanged: " + viewVisibility);
attachInfo.mWindowVisibility = viewVisibility;
host.dispatchWindowVisibilityChanged (viewVisibility);
if (viewVisibility == 8) {
this.mHasHadWindowFocus = false;
}}var insetsChanged = false;
if (this.mLayoutRequested) {
if (this.mFirst) {
this.mAttachInfo.mInTouchMode = !this.mAddedTouchMode;
} else {
if (lp.width == -2 || lp.height == -2) {
windowResizesToFitContent = true;
var packageMetrics = this.mView.getContext ().getResources ().getDisplayMetrics ();
desiredWindowWidth = packageMetrics.widthPixels;
desiredWindowHeight = packageMetrics.heightPixels;
}}this.setOuterDimension (desiredWindowWidth, desiredWindowHeight);
childWidthMeasureSpec = this.getRootMeasureSpec (desiredWindowWidth, lp.width);
childHeightMeasureSpec = this.getRootMeasureSpec (desiredWindowHeight, lp.height);
host.measure (childWidthMeasureSpec, childHeightMeasureSpec);
if (false) {
System.out.println ("======================================");
System.out.println ("performTraversals -- after measure");
}}if (attachInfo.mRecomputeGlobalAttributes) {
attachInfo.mRecomputeGlobalAttributes = false;
var oldVal = attachInfo.mKeepScreenOn;
attachInfo.mKeepScreenOn = false;
host.dispatchCollectViewAttributes (0);
if (attachInfo.mKeepScreenOn != oldVal) {
params = lp;
}}if (this.mFirst || attachInfo.mViewVisibilityChanged) {
attachInfo.mViewVisibilityChanged = false;
var resizeMode = this.mSoftInputMode & 240;
if (resizeMode == 0) {
var N = attachInfo.mScrollContainers.size ();
for (var i = 0; i < N; i++) {
if (attachInfo.mScrollContainers.get (i).isShown ()) {
resizeMode = 16;
}}
if (resizeMode == 0) {
resizeMode = 32;
}if ((lp.softInputMode & 240) != resizeMode) {
lp.softInputMode = (lp.softInputMode & -241) | resizeMode;
params = lp;
}}}if (params != null && (host.mPrivateFlags & 512) != 0) {
if (!android.graphics.PixelFormat.formatHasAlpha (params.format)) {
params.format = -3;
}}var windowShouldResize = this.mLayoutRequested && windowResizesToFitContent && ((this.mWidth != host.mMeasuredWidth || this.mHeight != host.mMeasuredHeight) || (lp.width == -2 && frame.width () < desiredWindowWidth && frame.width () != this.mWidth) || (lp.height == -2 && frame.height () < desiredWindowHeight && frame.height () != this.mHeight));
var computesInternalInsets = attachInfo.mTreeObserver.hasComputeInternalInsetsListeners ();
var insetsPending = false;
var relayoutResult = 0;
if (this.mFirst || windowShouldResize || insetsChanged || viewVisibilityChanged || params != null) {
var contentInsetsChanged = false;
var fl = 0;
if (params != null) {
fl = params.flags;
if (attachInfo.mKeepScreenOn) {
params.flags |= 128;
}}if (params != null) {
relayoutResult = this.relayoutWindow (params, this.mView.mMeasuredWidth, this.mView.mMeasuredHeight, viewVisibility, insetsPending, frame, null, null);
}if (params != null) {
params.flags = fl;
}attachInfo.mWindowLeft = frame.left;
attachInfo.mWindowTop = frame.top;
this.setOuterDimension (frame.width (), frame.height ());
this.mWidth = frame.width ();
this.mHeight = frame.height ();
if (this.mWidth != host.mMeasuredWidth || this.mHeight != host.mMeasuredHeight || contentInsetsChanged) {
childWidthMeasureSpec = this.getRootMeasureSpec (this.mWidth, lp.width);
childHeightMeasureSpec = this.getRootMeasureSpec (this.mHeight, lp.height);
host.measure (childWidthMeasureSpec, childHeightMeasureSpec);
var width = host.mMeasuredWidth;
var height = host.mMeasuredHeight;
var measureAgain = false;
if (lp.horizontalWeight > 0.0) {
width += Math.round (((this.mWidth - width) * lp.horizontalWeight));
childWidthMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (width, 1073741824);
measureAgain = true;
}if (lp.verticalWeight > 0.0) {
height += Math.round (((this.mHeight - height) * lp.verticalWeight));
childHeightMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (height, 1073741824);
measureAgain = true;
}if (measureAgain) {
System.out.println ("Measure Again");
host.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}this.mLayoutRequested = true;
}}var didLayout = this.mLayoutRequested;
var triggerGlobalLayoutListener = didLayout || attachInfo.mRecomputeGlobalAttributes;
if (didLayout) {
this.mLayoutRequested = false;
this.mScrollMayChange = true;
this.setOuterPosition (attachInfo.mWindowLeft, attachInfo.mWindowTop);
host.layout (0, 0, host.mMeasuredWidth, host.mMeasuredHeight);
if ((host.mPrivateFlags & 512) != 0) {
host.getLocationInWindow (this.mTmpLocation);
}if (false) {
System.out.println ("======================================");
System.out.println ("performTraversals -- after setFrame");
}}if (triggerGlobalLayoutListener) {
attachInfo.mRecomputeGlobalAttributes = false;
attachInfo.mTreeObserver.dispatchOnGlobalLayout ();
}if (computesInternalInsets) {
var insets = attachInfo.mGivenInternalInsets;
var givenContent = attachInfo.mGivenInternalInsets.contentInsets;
var givenVisible = attachInfo.mGivenInternalInsets.visibleInsets;
givenContent.left = givenContent.top = givenContent.right = givenContent.bottom = givenVisible.left = givenVisible.top = givenVisible.right = givenVisible.bottom = 0;
attachInfo.mTreeObserver.dispatchOnComputeInternalInsets (insets);
}if (this.mFirst) {
if (this.mView != null) {
if (!this.mView.hasFocus ()) {
this.mView.requestFocus (2);
this.mFocusedView = this.mRealFocusedView = this.mView.findFocus ();
} else {
this.mRealFocusedView = this.mView.findFocus ();
}}}this.mFirst = false;
this.mWillDrawSoon = false;
this.mNewSurfaceNeeded = false;
this.mViewVisibility = viewVisibility;
if (this.mAttachInfo.mHasWindowFocus) {
var imTarget = android.view.WindowManager.LayoutParams.mayUseInputMethod (this.mWindowAttributes.flags);
if (imTarget != this.mLastWasImTarget) {
this.mLastWasImTarget = imTarget;
}}var cancelDraw = attachInfo.mTreeObserver.dispatchOnPreDraw ();
if (!cancelDraw && !newSurface) {
this.mFullRedrawNeeded = false;
this.draw (fullRedrawNeeded);
} else {
if (fullRedrawNeeded) {
this.mFullRedrawNeeded = true;
}if (newSurface) newSurface = false;
this.scheduleTraversals ();
}if (false) {
System.out.println ("======================================");
System.out.println ("performTraversals Finish");
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getHostVisibility", 
function () {
return this.mAppVisible ? this.mView.getVisibility () : 8;
});
Clazz.overrideMethod (c$, "requestTransparentRegion", 
function (child) {
if (this.mView === child) {
this.mView.mPrivateFlags |= 512;
this.mWindowAttributesChanged = true;
this.requestLayout ();
}}, "android.view.View");
Clazz.defineMethod (c$, "getRootMeasureSpec", 
($fz = function (windowSize, rootDimension) {
var measureSpec;
switch (rootDimension) {
case -1:
measureSpec = android.view.View.MeasureSpec.makeMeasureSpec (windowSize, 1073741824);
break;
case -2:
measureSpec = android.view.View.MeasureSpec.makeMeasureSpec (windowSize, -2147483648);
break;
default:
measureSpec = android.view.View.MeasureSpec.makeMeasureSpec (rootDimension, 1073741824);
break;
}
return measureSpec;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.overrideMethod (c$, "playSoundEffect", 
function (effectId) {
}, "~N");
Clazz.overrideMethod (c$, "performHapticFeedback", 
function (effectId, always) {
return false;
}, "~N,~B");
Clazz.overrideMethod (c$, "invalidateChild", 
function (child, dirty) {
if (false) System.out.println ("invalidateChild");
if (this.mCurScrollY != 0) {
this.mTempRect.set (dirty);
dirty = this.mTempRect;
if (this.mCurScrollY != 0) {
dirty.offset (0, -this.mCurScrollY);
}if (this.mAttachInfo.mScalingRequired) {
dirty.inset (-1, -1);
}}this.mDirty.union (dirty);
if (!this.mWillDrawSoon) {
this.scheduleTraversals ();
}}, "android.view.View,android.graphics.Rect");
Clazz.overrideMethod (c$, "invalidateChildInParent", 
function (location, dirty) {
this.invalidateChild (null, dirty);
return null;
}, "~A,android.graphics.Rect");
Clazz.overrideMethod (c$, "requestChildFocus", 
function (child, focused) {
}, "android.view.View,android.view.View");
Clazz.overrideMethod (c$, "recomputeViewAttributes", 
function (child) {
}, "android.view.View");
Clazz.overrideMethod (c$, "clearChildFocus", 
function (child) {
}, "android.view.View");
Clazz.overrideMethod (c$, "getChildVisibleRect", 
function (child, r, offset) {
if (child !== this.mView) {
throw  new RuntimeException ("child is not mine, honest!");
}return r.intersect (0, 0, this.mWidth, this.mHeight);
}, "android.view.View,android.graphics.Rect,android.graphics.Point");
Clazz.overrideMethod (c$, "focusSearch", 
function (v, direction) {
return null;
}, "android.view.View,~N");
Clazz.overrideMethod (c$, "focusableViewAvailable", 
function (v) {
}, "android.view.View");
Clazz.overrideMethod (c$, "showContextMenuForChild", 
function (originalView) {
return false;
}, "android.view.View");
Clazz.overrideMethod (c$, "childDrawableStateChanged", 
function (child) {
}, "android.view.View");
Clazz.overrideMethod (c$, "requestDisallowInterceptTouchEvent", 
function (disallowIntercept) {
}, "~B");
Clazz.overrideMethod (c$, "requestChildRectangleOnScreen", 
function (child, rectangle, immediate) {
return false;
}, "android.view.View,android.graphics.Rect,~B");
Clazz.defineMethod (c$, "setLayoutParams", 
function (attrs, newView) {
var oldSoftInputMode = this.mWindowAttributes.softInputMode;
var compatibleWindowFlag = this.mWindowAttributes.flags & 536870912;
this.mWindowAttributes.copyFrom (attrs);
this.mWindowAttributes.flags |= compatibleWindowFlag;
if (newView) {
this.mSoftInputMode = attrs.softInputMode;
this.requestLayout ();
}if ((attrs.softInputMode & 240) == 0) {
this.mWindowAttributes.softInputMode = (this.mWindowAttributes.softInputMode & -241) | (oldSoftInputMode & 240);
}this.mWindowAttributesChanged = true;
this.scheduleTraversals ();
}, "android.view.WindowManager.LayoutParams,~B");
Clazz.defineMethod (c$, "relayoutWindow", 
($fz = function (params, requestedWidth, requestedHeight, viewVisibility, insetsPending, outFrame, outContentInsets, outVisibleInsets) {
var appScale = this.mAttachInfo.mApplicationScale;
var restore = false;
if (params != null) {
if (false) android.util.Log.d ("ViewRoot", "WindowLayout in layoutWindow:" + params);
}this.performLayoutLockedInner (params, requestedWidth, requestedHeight, viewVisibility, insetsPending, outFrame, outContentInsets, outVisibleInsets);
var relayoutResult = 0;
return relayoutResult;
}, $fz.isPrivate = true, $fz), "android.view.WindowManager.LayoutParams,~N,~N,~N,~B,android.graphics.Rect,android.graphics.Rect,android.graphics.Rect");
Clazz.defineMethod (c$, "performLayoutLockedInner", 
($fz = function (attrs, requestedWidth, requestedHeight, viewVisibility, insetsPending, outFrame, outContentInsets, outVisibleInset) {
if (viewVisibility == 8) {
return ;
}var mW;
var mH;
var mCurLeft;
var mCurTop;
var mCurRight;
var mCurBottom;
var mContentLeft;
var mContentTop;
var mContentRight;
var mContentBottom;
var mDockLeft;
var mDockTop;
var mDockRight;
var mDockBottom;
var packageMetrics = this.mView.getContext ().getResources ().getDisplayMetrics ();
mW = packageMetrics.widthPixels;
mH = packageMetrics.heightPixels;
mDockLeft = mContentLeft = mCurLeft = 0;
mDockTop = mContentTop = mCurTop = 0;
mDockRight = mContentRight = mCurRight = mW;
mDockBottom = mContentBottom = mCurBottom = mH;
var fl = attrs.flags;
var sim = attrs.softInputMode;
var pf =  new android.graphics.Rect ();
var df =  new android.graphics.Rect ();
var cf =  new android.graphics.Rect ();
var vf =  new android.graphics.Rect ();
var attached = false;
if (attrs.type == 2011) {
pf.left = df.left = cf.left = vf.left = mDockLeft;
pf.top = df.top = cf.top = vf.top = mDockTop;
pf.right = df.right = cf.right = vf.right = mDockRight;
pf.bottom = df.bottom = cf.bottom = vf.bottom = mDockBottom;
attrs.gravity = 80;
} else {
if ((fl & (66816)) == (65792)) {
if (attached) {
} else {
pf.left = df.left = 0;
pf.top = df.top = 0;
pf.right = df.right = mW;
pf.bottom = df.bottom = mH;
if ((sim & 240) != 16) {
cf.left = mDockLeft;
cf.top = mDockTop;
cf.right = mDockRight;
cf.bottom = mDockBottom;
} else {
cf.left = mContentLeft;
cf.top = mContentTop;
cf.right = mContentRight;
cf.bottom = mContentBottom;
}vf.left = mCurLeft;
vf.top = mCurTop;
vf.right = mCurRight;
vf.bottom = mCurBottom;
}} else if ((fl & 256) != 0) {
pf.left = df.left = cf.left = 0;
pf.top = df.top = cf.top = 0;
pf.right = df.right = cf.right = mW;
pf.bottom = df.bottom = cf.bottom = mH;
vf.left = mCurLeft;
vf.top = mCurTop;
vf.right = mCurRight;
vf.bottom = mCurBottom;
} else if (attached) {
} else {
pf.left = mContentLeft;
pf.top = mContentTop;
pf.right = mContentRight;
pf.bottom = mContentBottom;
if ((sim & 240) != 16) {
df.left = cf.left = mDockLeft;
df.top = cf.top = mDockTop;
df.right = cf.right = mDockRight;
df.bottom = cf.bottom = mDockBottom;
} else {
df.left = cf.left = mContentLeft;
df.top = cf.top = mContentTop;
df.right = cf.right = mContentRight;
df.bottom = cf.bottom = mContentBottom;
}vf.left = mCurLeft;
vf.top = mCurTop;
vf.right = mCurRight;
vf.bottom = mCurBottom;
}}this.computeFrameLw (attrs, requestedWidth, requestedHeight, outFrame, outContentInsets, outVisibleInset, pf, df, cf, vf);
}, $fz.isPrivate = true, $fz), "android.view.WindowManager.LayoutParams,~N,~N,~N,~B,android.graphics.Rect,android.graphics.Rect,android.graphics.Rect");
Clazz.defineMethod (c$, "computeFrameLw", 
function (mAttrs, requestedWidth, requestedHeight, outFrame, outContentInsets, outVisibleInset, pf, df, cf, vf) {
var mRequestedWidth = requestedWidth;
var mRequestedHeight = requestedHeight;
var container =  new android.graphics.Rect ();
container.set (pf);
var display =  new android.graphics.Rect ();
display.set (df);
var pw = container.right - container.left;
var ph = container.bottom - container.top;
var w;
var h;
if ((mAttrs.flags & mAttrs.FLAG_SCALED) != 0) {
w = mAttrs.width < 0 ? pw : mAttrs.width;
h = mAttrs.height < 0 ? ph : mAttrs.height;
} else {
w = mAttrs.width == mAttrs.MATCH_PARENT ? pw : mRequestedWidth;
h = mAttrs.height == mAttrs.MATCH_PARENT ? ph : mRequestedHeight;
}var content =  new android.graphics.Rect ();
content.set (cf);
var visible =  new android.graphics.Rect ();
;visible.set (vf);
var frame =  new android.graphics.Rect ();
android.view.Gravity.apply (mAttrs.gravity, w, h, container, Math.round ((mAttrs.x + mAttrs.horizontalMargin * pw)), Math.round ((mAttrs.y + mAttrs.verticalMargin * ph)), frame);
android.view.Gravity.applyDisplay (mAttrs.gravity, df, frame);
if (content.left < frame.left) content.left = frame.left;
if (content.top < frame.top) content.top = frame.top;
if (content.right > frame.right) content.right = frame.right;
if (content.bottom > frame.bottom) content.bottom = frame.bottom;
if (visible.left < frame.left) visible.left = frame.left;
if (visible.top < frame.top) visible.top = frame.top;
if (visible.right > frame.right) visible.right = frame.right;
if (visible.bottom > frame.bottom) visible.bottom = frame.bottom;
var contentInsets =  new android.graphics.Rect ();
contentInsets.left = content.left - frame.left;
contentInsets.top = content.top - frame.top;
contentInsets.right = frame.right - content.right;
contentInsets.bottom = frame.bottom - content.bottom;
var visibleInsets =  new android.graphics.Rect ();
visibleInsets.left = visible.left - frame.left;
visibleInsets.top = visible.top - frame.top;
visibleInsets.right = frame.right - visible.right;
visibleInsets.bottom = frame.bottom - visible.bottom;
if (outFrame != null) outFrame.set (frame);
if (outContentInsets != null) outContentInsets.set (contentInsets);
if (outVisibleInset != null) outVisibleInset.set (visibleInsets);
}, "android.view.WindowManager.LayoutParams,~N,~N,android.graphics.Rect,android.graphics.Rect,android.graphics.Rect,android.graphics.Rect,android.graphics.Rect,android.graphics.Rect,android.graphics.Rect");
Clazz.defineMethod (c$, "die", 
function (b) {
if (this.mAdded) {
this.mAdded = false;
this.dispatchDetachedFromWindow ();
}}, "~B");
Clazz.defineMethod (c$, "dispatchDetachedFromWindow", 
function () {
android.util.Log.i ("ViewRoot", "dispatchDetachedFromWindow");
if (this.mView != null && this.mAttached) {
this.mView.dispatchDetachedFromWindow ();
this.mAttached = false;
}this.mView = null;
this.mAttachInfo.mRootView = null;
if (this.mInputChannel != null) {
if (this.mInputQueueCallback != null) {
this.mInputQueueCallback.onInputQueueDestroyed (this.mInputQueue);
this.mInputQueueCallback = null;
} else {
android.view.InputQueue.unregisterInputChannel (this.mInputChannel);
}}if (this.mInputChannel != null) {
this.mInputChannel.dispose ();
this.mInputChannel = null;
}this.reset ();
});
Clazz.defineMethod (c$, "draw", 
($fz = function (fullRedrawNeeded) {
if (this.mAttachInfo.mViewScrollChanged) {
this.mAttachInfo.mViewScrollChanged = false;
this.mAttachInfo.mTreeObserver.dispatchOnScrollChanged ();
}var yoff = this.mScrollY;
if (this.mCurScrollY != yoff) {
this.mCurScrollY = yoff;
fullRedrawNeeded = true;
}var appScale = this.mAttachInfo.mApplicationScale;
var dirty = this.mDirty;
if (fullRedrawNeeded) {
this.mAttachInfo.mIgnoreDirtyState = true;
dirty.union (0, 0, Math.round ((this.mWidth * appScale)), Math.round ((this.mHeight * appScale)));
}this.mCanvas.setDimension (this.mWidth, this.mHeight);
if (!dirty.isEmpty () || this.mIsAnimating) {
var canvas;
var left = dirty.left;
var top = dirty.top;
var right = dirty.right;
var bottom = dirty.bottom;
canvas = this.mCanvas;
dirty.setEmpty ();
this.mIsAnimating = false;
this.mAttachInfo.mDrawingTime = android.os.SystemClock.uptimeMillis ();
this.mView.mPrivateFlags |= 32;
var saveCount = canvas.save ();
try {
canvas.clipRect (left, top, right, bottom);
canvas.translate (0, -yoff);
this.mView.draw (canvas);
} finally {
this.mAttachInfo.mIgnoreDirtyState = false;
canvas.restoreToCount (saveCount);
}
}if (android.view.ViewRoot.sDrawTime != 0 && android.view.ViewRoot.DBG_FPS) {
var now = System.currentTimeMillis ();
var internal = now - android.view.ViewRoot.sDrawTime;
android.util.Log.i ("ViewRoot", "Show FPS:" + internal);
}($t$ = android.view.ViewRoot.sDrawTime = System.currentTimeMillis (), android.view.ViewRoot.prototype.sDrawTime = android.view.ViewRoot.sDrawTime, $t$);
}, $fz.isPrivate = true, $fz), "~B");
Clazz.overrideMethod (c$, "handleMessage", 
function (msg) {
switch (msg.what) {
case 1:
(msg.obj).invalidate ();
break;
case 2:
var info = msg.obj;
info.target.invalidate (info.left, info.top, info.right, info.bottom);
info.release ();
break;
case 1000:
this.performTraversals ();
break;
case 1010:
android.util.Log.e ("ViewRoot", "FINISHED_EVENT is not handled now!");
break;
case 1005:
android.util.Log.e ("ViewRoot", "DISPATCH_KEY is not handled now!");
break;
case 1006:
{
var event = msg.obj;
android.util.Log.e ("ViewRoot", "DISPATCH_POINTER is not handled now!");
}break;
case 1007:
{
var event = msg.obj;
android.util.Log.e ("ViewRoot", "DISPATCH_TRACKBALL is not handled now!");
}break;
case 1008:
android.util.Log.e ("ViewRoot", "DISPATCH_APP_VISIBILITY is not handled now!");
break;
case 1009:
android.util.Log.e ("ViewRoot", "DISPATCH_GET_NEW_SURFACE is not handled now!");
break;
case 1002:
android.util.Log.e ("ViewRoot", "RESIZED is not handled now!");
case 1003:
android.util.Log.e ("ViewRoot", "RESIZED_REPORT is not handled now!");
break;
case 1004:
{
android.util.Log.e ("ViewRoot", "WINDOW_FOCUS_CHANGED is not handled now!");
}break;
case 1001:
android.util.Log.e ("ViewRoot", "DIE is not handled now!");
break;
case 1011:
{
android.util.Log.e ("ViewRoot", "DISPATCH_KEY_FROM_IME is not handled now!");
}break;
case 1012:
{
android.util.Log.e ("ViewRoot", "FINISH_INPUT_CONNECTION is not handled now!");
}break;
case 1013:
{
android.util.Log.e ("ViewRoot", "CHECK_FOCUS is not handled now!");
}break;
case 1014:
{
android.util.Log.e ("ViewRoot", "CLOSE_SYSTEM_DIALOGS is not handled now!");
}break;
}
}, "android.os.Message");
Clazz.defineMethod (c$, "reset", 
function () {
android.util.Log.d ("ViewRoot", "In reset");
android.view.ViewRoot.viewRootList.remove (this);
var rootView = document.getElementById(this.mViewRootID);
if (rootView != null) {
rootView.parentNode.removeChild(rootView);
}
});
c$.getRunQueue = Clazz.defineMethod (c$, "getRunQueue", 
function () {
var rq = android.view.ViewRoot.sRunQueues;
if (rq != null) {
return rq;
}rq =  new android.view.ViewRoot.RunQueue ();
($t$ = android.view.ViewRoot.sRunQueues = rq, android.view.ViewRoot.prototype.sRunQueues = android.view.ViewRoot.sRunQueues, $t$);
return rq;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mActions = null;
Clazz.instantialize (this, arguments);
}, android.view.ViewRoot, "RunQueue");
Clazz.prepareFields (c$, function () {
this.mActions =  new java.util.ArrayList ();
});
Clazz.defineMethod (c$, "post", 
function (a) {
this.postDelayed (a, 0);
}, "Runnable");
Clazz.defineMethod (c$, "postDelayed", 
function (a, b) {
var c =  new android.view.ViewRoot.RunQueue.HandlerAction ();
c.action = a;
c.delay = b;
{
this.mActions.add (c);
}}, "Runnable,~N");
Clazz.defineMethod (c$, "removeCallbacks", 
function (a) {
var b =  new android.view.ViewRoot.RunQueue.HandlerAction ();
b.action = a;
{
var c = this.mActions;
while (c.remove (b)) {
}
}}, "Runnable");
Clazz.defineMethod (c$, "executeActions", 
function (a) {
{
var b = this.mActions;
var c = b.size ();
for (var d = 0; d < c; d++) {
var e = b.get (d);
a.postDelayed (e.action, e.delay);
}
b.clear ();
}}, "android.os.Handler");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.action = null;
this.delay = 0;
Clazz.instantialize (this, arguments);
}, android.view.ViewRoot.RunQueue, "HandlerAction");
Clazz.defineMethod (c$, "equals", 
function (a) {
if (this === a) return true;
if (a == null || this.getClass () !== a.getClass ()) return false;
var b = a;
return !(this.action != null ? !this.action.equals (b.action) : b.action != null);
}, "~O");
Clazz.defineMethod (c$, "hashCode", 
function () {
var a = this.action != null ? this.action.hashCode () : 0;
a = 31 * a + (this.delay ^ (this.delay >>> 32));
return a;
});
c$ = Clazz.p0p ();
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DBG", false,
"$TAG", "ViewRoot",
"sInstanceCount", 0,
"mInitialized", false);
c$.sRunQueues = c$.prototype.sRunQueues =  new android.view.ViewRoot.RunQueue ();
Clazz.defineStatics (c$,
"sDrawTime", 0,
"DBG_FPS", false,
"viewRootID", 0);
c$.viewRootList = c$.prototype.viewRootList =  new java.util.ArrayList ();
Clazz.defineStatics (c$,
"DO_TRAVERSAL", 1000,
"DIE", 1001,
"RESIZED", 1002,
"RESIZED_REPORT", 1003,
"WINDOW_FOCUS_CHANGED", 1004,
"DISPATCH_KEY", 1005,
"DISPATCH_POINTER", 1006,
"DISPATCH_TRACKBALL", 1007,
"DISPATCH_APP_VISIBILITY", 1008,
"DISPATCH_GET_NEW_SURFACE", 1009,
"FINISHED_EVENT", 1010,
"DISPATCH_KEY_FROM_IME", 1011,
"FINISH_INPUT_CONNECTION", 1012,
"CHECK_FOCUS", 1013,
"CLOSE_SYSTEM_DIALOGS", 1014);
});
