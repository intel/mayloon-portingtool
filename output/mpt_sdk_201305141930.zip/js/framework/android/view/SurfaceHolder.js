﻿Clazz.declarePackage ("android.view");
Clazz.load (["java.lang.RuntimeException"], "android.view.SurfaceHolder", null, function () {
c$ = Clazz.declareInterface (android.view, "SurfaceHolder");
Clazz.pu$h ();
c$ = Clazz.declareType (android.view.SurfaceHolder, "BadSurfaceTypeException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.view.SurfaceHolder.BadSurfaceTypeException, []);
});
c$ = Clazz.p0p ();
Clazz.declareInterface (android.view.SurfaceHolder, "Callback");
Clazz.declareInterface (android.view.SurfaceHolder, "Callback2", android.view.SurfaceHolder.Callback);
Clazz.defineStatics (c$,
"SURFACE_TYPE_NORMAL", 0,
"SURFACE_TYPE_HARDWARE", 1,
"SURFACE_TYPE_GPU", 2,
"SURFACE_TYPE_PUSH_BUFFERS", 3);
});
