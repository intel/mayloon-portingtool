﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.graphics.drawable.Drawable", "android.view.AbsSavedState", "$.KeyEvent", "android.graphics.Rect", "android.os.Parcelable.Creator", "android.view.ViewTreeObserver", "java.util.ArrayList"], "android.view.View", ["android.graphics.Canvas", "$.Matrix", "$.Paint", "$.Point", "android.graphics.drawable.ColorDrawable", "android.os.Message", "android.util.DebugUtils", "$.LocaleUtil", "$.Log", "$.SparseArray", "android.view.LayoutInflater", "$.ViewConfiguration", "$.ViewRoot", "android.view.accessibility.AccessibilityEvent", "$.AccessibilityManager", "android.view.animation.AnimationUtils", "android.widget.ScrollBarDrawable", "com.android.internal.R", "java.lang.IllegalArgumentException", "$.IllegalStateException", "$.NullPointerException", "$.RuntimeException", "$.StringBuilder", "java.util.Locale", "$.WeakHashMap"], function () {
c$ = Clazz.decorateAsClass (function () {
this.zIndex = 0;
this.mCurrentAnimation = null;
this.mMeasuredWidth = 0;
this.mMeasuredHeight = 0;
this.mID = -1;
this.mTag = null;
this.mScrollCache = null;
this.mOverScrollMode = 0;
this.mParent = null;
this.mAttachInfo = null;
this.mPrivateFlags = 0;
this.mPrivateFlags2 = 0;
this.mWindowAttachCount = 0;
this.mLayoutParams = null;
this.mViewFlags = 0;
this.mLeft = 0;
this.mRight = 0;
this.mTop = 0;
this.mBottom = 0;
this.mScrollX = 0;
this.mScrollY = 0;
this.mPaddingLeft = 0;
this.mPaddingRight = 0;
this.mPaddingTop = 0;
this.mPaddingBottom = 0;
this.mContentDescription = null;
this.mUserPaddingRight = 0;
this.mUserPaddingBottom = 0;
this.mOldWidthMeasureSpec = -2147483648;
this.mOldHeightMeasureSpec = -2147483648;
this.mResources = null;
this.mBGDrawable = null;
this.mBackgroundResource = 0;
this.mBackgroundSizeChanged = false;
this.mOnFocusChangeListener = null;
this.mOnClickListener = null;
this.mOnLongClickListener = null;
this.mOnCreateContextMenuListener = null;
this.mOnKeyListener = null;
this.mContext = null;
this.mDrawableState = null;
this.mNextFocusLeftId = -1;
this.mNextFocusRightId = -1;
this.mNextFocusUpId = -1;
this.mNextFocusDownId = -1;
this.mHasPerformedLongPress = false;
this.mMinHeight = 0;
this.mMinWidth = 0;
this.mDrawingCacheBackgroundColor = 0;
this.mTouchDelegate = null;
this.mTouchSlop = 0;
this.bgColor = "transparent";
this.mOnTouchListener = null;
this.mResolvedTextDirection = 0;
this.mUIElementID = 0;
Clazz.instantialize (this, arguments);
}, android.view, "View", null, [android.graphics.drawable.Drawable.Callback, android.view.KeyEvent.Callback]);
Clazz.defineMethod (c$, "getZIndex", 
function () {
var root = this.getRootView ();
return root.zIndex;
});
Clazz.makeConstructor (c$, 
function (context) {
if (false) System.out.println ("constructing View10");
this.mContext = context;
this.mResources = context != null ? context.getResources () : null;
this.mViewFlags = 402653184;
this.setOverScrollMode (1);
this.mUIElementID = android.view.View.getAnElementID ();
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 0);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
if (false) System.out.println ("constructing View1");
this.mContext = context;
this.mResources = context != null ? context.getResources () : null;
this.mViewFlags = 402653184;
if (context == null) {
throw  new NullPointerException ();
}this.mTouchSlop = android.view.ViewConfiguration.get (context).getScaledTouchSlop ();
this.setOverScrollMode (1);
this.mUIElementID = android.view.View.getAnElementID ();
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.View, defStyle, 0);
var background = null;
var leftPadding = -1;
var topPadding = -1;
var rightPadding = -1;
var bottomPadding = -1;
var padding = -1;
var viewFlagValues = 0;
var viewFlagMasks = 0;
var setScrollContainer = false;
var x = 0;
var y = 0;
var scrollbarStyle = 0;
var overScrollMode = this.mOverScrollMode;
var N = a.getIndexCount ();
for (var i = 0; i < N; i++) {
var attr = a.getIndex (i);
switch (attr) {
case 12:
background = a.getDrawable (attr);
break;
case 13:
padding = a.getDimensionPixelSize (attr, -1);
break;
case 14:
leftPadding = a.getDimensionPixelSize (attr, -1);
break;
case 15:
topPadding = a.getDimensionPixelSize (attr, -1);
break;
case 16:
rightPadding = a.getDimensionPixelSize (attr, -1);
break;
case 17:
bottomPadding = a.getDimensionPixelSize (attr, -1);
break;
case 10:
x = a.getDimensionPixelOffset (attr, 0);
break;
case 11:
y = a.getDimensionPixelOffset (attr, 0);
break;
case 8:
this.mID = a.getResourceId (attr, -1);
break;
case 9:
this.mTag = a.getText (attr);
break;
case 21:
if (a.getBoolean (attr, false)) {
viewFlagValues |= 2;
viewFlagMasks |= 2;
}break;
case 18:
if (a.getBoolean (attr, false)) {
viewFlagValues |= 1;
viewFlagMasks |= 1;
}break;
case 19:
if (a.getBoolean (attr, false)) {
viewFlagValues |= 262145;
viewFlagMasks |= 262145;
}break;
case 29:
if (a.getBoolean (attr, false)) {
viewFlagValues |= 16384;
viewFlagMasks |= 16384;
}break;
case 30:
if (a.getBoolean (attr, false)) {
viewFlagValues |= 2097152;
viewFlagMasks |= 2097152;
}break;
case 31:
if (!a.getBoolean (attr, true)) {
viewFlagValues |= 65536;
viewFlagMasks |= 65536;
}break;
case 33:
if (a.getBoolean (attr, false)) {
viewFlagValues |= 4194304;
viewFlagMasks |= 4194304;
}break;
case 20:
var visibility = a.getInt (attr, 0);
if (visibility != 0) {
viewFlagValues |= android.view.View.VISIBILITY_FLAGS[visibility];
viewFlagMasks |= 12;
}break;
case 32:
var cacheQuality = a.getInt (attr, 0);
if (cacheQuality != 0) {
viewFlagValues |= android.view.View.DRAWING_CACHE_QUALITY_FLAGS[cacheQuality];
viewFlagMasks |= 1572864;
}break;
case 41:
this.mContentDescription = a.getString (attr);
break;
case 36:
if (!a.getBoolean (attr, true)) {
viewFlagValues &= -134217729;
viewFlagMasks |= 134217728;
}break;
case 39:
if (!a.getBoolean (attr, true)) {
viewFlagValues &= -268435457;
viewFlagMasks |= 268435456;
}break;
case 22:
var scrollbars = a.getInt (attr, 0);
if (scrollbars != 0) {
viewFlagValues |= scrollbars;
viewFlagMasks |= 768;
this.initializeScrollbars (a);
}break;
case 23:
var fadingEdge = a.getInt (attr, 0);
if (fadingEdge != 0) {
viewFlagValues |= fadingEdge;
viewFlagMasks |= 12288;
this.initializeFadingEdge (a);
}break;
case 7:
scrollbarStyle = a.getInt (attr, 0);
if (scrollbarStyle != 0) {
viewFlagValues |= scrollbarStyle & 50331648;
viewFlagMasks |= 50331648;
}break;
case 38:
setScrollContainer = true;
if (a.getBoolean (attr, false)) {
this.setScrollContainer (true);
}break;
case 37:
if (a.getBoolean (attr, false)) {
viewFlagValues |= 67108864;
viewFlagMasks |= 67108864;
}break;
case 46:
if (a.getBoolean (attr, false)) {
viewFlagValues |= 1024;
viewFlagMasks |= 1024;
}break;
case 25:
this.mNextFocusLeftId = a.getResourceId (attr, -1);
break;
case 26:
this.mNextFocusRightId = a.getResourceId (attr, -1);
break;
case 27:
this.mNextFocusUpId = a.getResourceId (attr, -1);
break;
case 28:
this.mNextFocusDownId = a.getResourceId (attr, -1);
break;
case 34:
this.mMinWidth = a.getDimensionPixelSize (attr, 0);
break;
case 35:
this.mMinHeight = a.getDimensionPixelSize (attr, 0);
break;
case 40:
if (context.isRestricted ()) {
throw  new IllegalStateException ("The android:onClick attribute cannot be used within a restricted context");
}var handlerName = a.getString (attr);
if (handlerName != null) {
this.setOnClickListener (((Clazz.isClassDefined ("android.view.View$1") ? 0 : android.view.View.$View$1$ ()), Clazz.innerTypeInstance (android.view.View$1, this, Clazz.cloneFinals ("handlerName", handlerName))));
}break;
case 45:
overScrollMode = a.getInt (attr, 1);
break;
}
}
this.setOverScrollMode (overScrollMode);
if (false) System.out.println ("constructing View3");
if (background != null) {
this.setBackgroundDrawable (background);
}if (padding >= 0) {
leftPadding = padding;
topPadding = padding;
rightPadding = padding;
bottomPadding = padding;
}this.setPadding (leftPadding >= 0 ? leftPadding : this.mPaddingLeft, topPadding >= 0 ? topPadding : this.mPaddingTop, rightPadding >= 0 ? rightPadding : this.mPaddingRight, bottomPadding >= 0 ? bottomPadding : this.mPaddingBottom);
if (viewFlagMasks != 0) {
this.setFlags (viewFlagValues, viewFlagMasks);
}if (scrollbarStyle != 0) {
this.recomputePadding ();
}if (x != 0 || y != 0) {
}if (!setScrollContainer && (viewFlagValues & 512) != 0) {
this.setScrollContainer (true);
}this.computeOpaqueFlags ();
a.recycle ();
if (false) System.out.println ("constructing View2");
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "setBackgroundColor", 
function (color) {
this.setBackgroundDrawable ( new android.graphics.drawable.ColorDrawable (color));
}, "~N");
Clazz.defineMethod (c$, "setBackgroundDrawable", 
function (d) {
var requestLayout = false;
this.mBackgroundResource = 0;
if (this.mBGDrawable != null) {
this.mBGDrawable.setCallback (null);
this.unscheduleDrawable (this.mBGDrawable);
}if (d != null) {
var padding =  new android.graphics.Rect ();
;if (d.getPadding (padding)) {
this.setPadding (padding.left, padding.top, padding.right, padding.bottom);
}if (this.mBGDrawable == null || this.mBGDrawable.getMinimumHeight () != d.getMinimumHeight () || this.mBGDrawable.getMinimumWidth () != d.getMinimumWidth ()) {
requestLayout = true;
}d.setCallback (this);
if (d.isStateful ()) {
d.setState (this.getDrawableState ());
}d.setVisible (this.getVisibility () == 0, false);
this.mBGDrawable = d;
if ((this.mPrivateFlags & 128) != 0) {
this.mPrivateFlags &= -129;
this.mPrivateFlags |= 256;
requestLayout = true;
}} else {
this.mBGDrawable = null;
if ((this.mPrivateFlags & 256) != 0) {
this.mPrivateFlags &= -257;
this.mPrivateFlags |= 128;
}requestLayout = true;
}this.computeOpaqueFlags ();
if (requestLayout) {
this.requestLayout ();
}this.mBackgroundSizeChanged = true;
this.invalidate ();
}, "android.graphics.drawable.Drawable");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "initializeFadingEdge", 
function (a) {
this.initScrollCache ();
this.mScrollCache.fadingEdgeLength = a.getDimensionPixelSize (24, android.view.ViewConfiguration.get (this.mContext).getScaledFadingEdgeLength ());
}, "android.content.res.TypedArray");
Clazz.defineMethod (c$, "getVerticalFadingEdgeLength", 
function () {
if (this.isVerticalFadingEdgeEnabled ()) {
var cache = this.mScrollCache;
if (cache != null) {
return cache.fadingEdgeLength;
}}return 0;
});
Clazz.defineMethod (c$, "setFadingEdgeLength", 
function (length) {
this.initScrollCache ();
this.mScrollCache.fadingEdgeLength = length;
}, "~N");
Clazz.defineMethod (c$, "getHorizontalFadingEdgeLength", 
function () {
if (this.isHorizontalFadingEdgeEnabled ()) {
var cache = this.mScrollCache;
if (cache != null) {
return cache.fadingEdgeLength;
}}return 0;
});
Clazz.defineMethod (c$, "setOnFocusChangeListener", 
function (l) {
this.mOnFocusChangeListener = l;
}, "android.view.View.OnFocusChangeListener");
Clazz.defineMethod (c$, "getOnFocusChangeListener", 
function () {
return this.mOnFocusChangeListener;
});
Clazz.defineMethod (c$, "setOnClickListener", 
function (l) {
if (!this.isClickable ()) {
this.setClickable (true);
}this.mOnClickListener = l;
}, "android.view.View.OnClickListener");
Clazz.defineMethod (c$, "setOnLongClickListener", 
function (l) {
if (!this.isLongClickable ()) {
this.setLongClickable (true);
}this.mOnLongClickListener = l;
}, "android.view.View.OnLongClickListener");
Clazz.defineMethod (c$, "setOnCreateContextMenuListener", 
function (l) {
if (!this.isLongClickable ()) {
this.setLongClickable (true);
}this.mOnCreateContextMenuListener = l;
}, "android.view.View.OnCreateContextMenuListener");
Clazz.defineMethod (c$, "performClick", 
function () {
if (this.mOnClickListener != null) {
this.mOnClickListener.onClick (this);
return true;
}return false;
});
Clazz.defineMethod (c$, "performLongClick", 
function () {
var handled = false;
if (this.mOnLongClickListener != null) {
handled = this.mOnLongClickListener.onLongClick (this);
}if (!handled) {
handled = this.showContextMenu ();
}return handled;
});
Clazz.defineMethod (c$, "showContextMenu", 
function () {
return this.getParent ().showContextMenuForChild (this);
});
Clazz.defineMethod (c$, "setOnKeyListener", 
function (l) {
this.mOnKeyListener = l;
}, "android.view.View.OnKeyListener");
Clazz.defineMethod (c$, "handleFocusGainInternal", 
function (direction, previouslyFocusedRect) {
if (false) {
System.out.println (this + " requestFocus()");
}if ((this.mPrivateFlags & 2) == 0) {
this.mPrivateFlags |= 2;
if (this.mParent != null) {
this.mParent.requestChildFocus (this, this);
}this.onFocusChanged (true, direction, previouslyFocusedRect);
}}, "~N,android.graphics.Rect");
Clazz.defineMethod (c$, "requestRectangleOnScreen", 
function (rectangle) {
return this.requestRectangleOnScreen (rectangle, false);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "requestRectangleOnScreen", 
function (rectangle, immediate) {
var child = this;
var parent = this.mParent;
var scrolled = false;
while (parent != null) {
scrolled = new Boolean (scrolled | parent.requestChildRectangleOnScreen (child, rectangle, immediate)).valueOf ();
rectangle.offset (child.getLeft (), child.getTop ());
rectangle.offset (-child.getScrollX (), -child.getScrollY ());
if (!(Clazz.instanceOf (parent, android.view.View))) {
break;
}child = parent;
parent = child.getParent ();
}
return scrolled;
}, "android.graphics.Rect,~B");
Clazz.defineMethod (c$, "clearFocus", 
function () {
if (false) {
System.out.println (this + " clearFocus()");
}if ((this.mPrivateFlags & 2) != 0) {
this.mPrivateFlags &= -3;
if (this.mParent != null) {
this.mParent.clearChildFocus (this);
}this.onFocusChanged (false, 0, null);
}});
Clazz.defineMethod (c$, "clearFocusForRemoval", 
function () {
if ((this.mPrivateFlags & 2) != 0) {
this.mPrivateFlags &= -3;
this.onFocusChanged (false, 0, null);
}});
Clazz.defineMethod (c$, "unFocus", 
function () {
if ((this.mPrivateFlags & 2) != 0) {
this.mPrivateFlags &= -3;
this.onFocusChanged (false, 0, null);
}});
Clazz.defineMethod (c$, "refreshDrawableState", 
function () {
this.mPrivateFlags |= 1024;
this.drawableStateChanged ();
var parent = this.mParent;
if (parent != null) {
parent.childDrawableStateChanged (this);
}});
Clazz.defineMethod (c$, "hasFocus", 
function () {
return (this.mPrivateFlags & 2) != 0;
});
Clazz.defineMethod (c$, "hasFocusable", 
function () {
return (this.mViewFlags & 12) == 0 && this.isFocusable ();
});
Clazz.defineMethod (c$, "onFocusChanged", 
function (gainFocus, direction, previouslyFocusedRect) {
this.invalidate ();
if (this.mOnFocusChangeListener != null) {
this.mOnFocusChangeListener.onFocusChange (this, gainFocus);
}if (this.mAttachInfo != null) {
this.mAttachInfo.mKeyDispatchState.reset (this);
}}, "~B,~N,android.graphics.Rect");
Clazz.defineMethod (c$, "sendAccessibilityEvent", 
function (eventType) {
if (android.view.accessibility.AccessibilityManager.getInstance (this.mContext).isEnabled ()) {
this.sendAccessibilityEventUnchecked (android.view.accessibility.AccessibilityEvent.obtain (eventType));
}}, "~N");
Clazz.defineMethod (c$, "sendAccessibilityEventUnchecked", 
function (event) {
event.setClassName (this.getClass ().getName ());
event.setPackageName (this.getContext ().getPackageName ());
event.setEnabled (this.isEnabled ());
event.setContentDescription (this.mContentDescription);
if (event.getEventType () == 8 && this.mAttachInfo != null) {
var focusablesTempList = this.mAttachInfo.mFocusablesTempList;
this.getRootView ().addFocusables (focusablesTempList, 2, 0);
event.setItemCount (focusablesTempList.size ());
event.setCurrentItemIndex (focusablesTempList.indexOf (this));
focusablesTempList.clear ();
}this.dispatchPopulateAccessibilityEvent (event);
android.view.accessibility.AccessibilityManager.getInstance (this.mContext).sendAccessibilityEvent (event);
}, "android.view.accessibility.AccessibilityEvent");
Clazz.defineMethod (c$, "dispatchPopulateAccessibilityEvent", 
function (event) {
return false;
}, "android.view.accessibility.AccessibilityEvent");
Clazz.defineMethod (c$, "getContentDescription", 
function () {
return this.mContentDescription;
});
Clazz.defineMethod (c$, "setContentDescription", 
function (contentDescription) {
this.mContentDescription = contentDescription;
}, "CharSequence");
Clazz.defineMethod (c$, "isFocused", 
function () {
return (this.mPrivateFlags & 2) != 0;
});
Clazz.defineMethod (c$, "findFocus", 
function () {
return (this.mPrivateFlags & 2) != 0 ? this : null;
});
Clazz.defineMethod (c$, "setScrollContainer", 
function (isScrollContainer) {
if (isScrollContainer) {
if (this.mAttachInfo != null && (this.mPrivateFlags & 1048576) == 0) {
this.mAttachInfo.mScrollContainers.add (this);
this.mPrivateFlags |= 1048576;
}this.mPrivateFlags |= 524288;
} else {
if ((this.mPrivateFlags & 1048576) != 0) {
this.mAttachInfo.mScrollContainers.remove (this);
}this.mPrivateFlags &= -1572865;
}}, "~B");
Clazz.defineMethod (c$, "getDrawingCacheQuality", 
function () {
return this.mViewFlags & 1572864;
});
Clazz.defineMethod (c$, "setDrawingCacheQuality", 
function (quality) {
this.setFlags (quality, 1572864);
}, "~N");
Clazz.defineMethod (c$, "getKeepScreenOn", 
function () {
return (this.mViewFlags & 67108864) != 0;
});
Clazz.defineMethod (c$, "setKeepScreenOn", 
function (keepScreenOn) {
this.setFlags (keepScreenOn ? 67108864 : 0, 67108864);
}, "~B");
Clazz.defineMethod (c$, "getNextFocusLeftId", 
function () {
return this.mNextFocusLeftId;
});
Clazz.defineMethod (c$, "setNextFocusLeftId", 
function (nextFocusLeftId) {
this.mNextFocusLeftId = nextFocusLeftId;
}, "~N");
Clazz.defineMethod (c$, "getNextFocusRightId", 
function () {
return this.mNextFocusRightId;
});
Clazz.defineMethod (c$, "setNextFocusRightId", 
function (nextFocusRightId) {
this.mNextFocusRightId = nextFocusRightId;
}, "~N");
Clazz.defineMethod (c$, "getNextFocusUpId", 
function () {
return this.mNextFocusUpId;
});
Clazz.defineMethod (c$, "setNextFocusUpId", 
function (nextFocusUpId) {
this.mNextFocusUpId = nextFocusUpId;
}, "~N");
Clazz.defineMethod (c$, "getNextFocusDownId", 
function () {
return this.mNextFocusDownId;
});
Clazz.defineMethod (c$, "setNextFocusDownId", 
function (nextFocusDownId) {
this.mNextFocusDownId = nextFocusDownId;
}, "~N");
Clazz.defineMethod (c$, "isShown", 
function () {
var current = this;
do {
if ((current.mViewFlags & 12) != 0) {
return false;
}var parent = current.mParent;
if (parent == null) {
return false;
}if (!(Clazz.instanceOf (parent, android.view.View))) {
return true;
}current = parent;
} while (current != null);
return false;
});
Clazz.defineMethod (c$, "fitSystemWindows", 
function (insets) {
if ((this.mViewFlags & 2) == 2) {
this.mPaddingLeft = insets.left;
this.mPaddingTop = insets.top;
this.mPaddingRight = insets.right;
this.mPaddingBottom = insets.bottom;
this.requestLayout ();
return true;
}return false;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "isFitsSystemWindowsFlagSet", 
function () {
return (this.mViewFlags & 2) == 2;
});
Clazz.defineMethod (c$, "getVisibility", 
function () {
return this.mViewFlags & 12;
});
Clazz.defineMethod (c$, "setVisibility", 
function (visibility) {
this.setFlags (visibility, 12);
var visible = "visible";
if (visibility != 0) visible = "hidden";
if (android.util.DebugUtils.DEBUG_VIEW_IN_BROWSER) {
var thisView = document.getElementById(mUIElementID);
if (thisView != null) thisView.style.visibility = visible;
} else {
if (Clazz.instanceOf (this, android.view.ViewGroup)) (this).setVisibilityRec (visible);
if (this.mBGDrawable != null) this.mBGDrawable.setVisible (visibility == 0, false);
}this.requestLayout ();
this.invalidate ();
}, "~N");
Clazz.defineMethod (c$, "isEnabled", 
function () {
return (this.mViewFlags & 32) == 0;
});
Clazz.defineMethod (c$, "setEnabled", 
function (enabled) {
if (enabled == this.isEnabled ()) return ;
this.setFlags (enabled ? 0 : 32, 32);
this.invalidate ();
}, "~B");
Clazz.defineMethod (c$, "setFocusable", 
function (focusable) {
if (!focusable) {
this.setFlags (0, 262144);
}this.setFlags (focusable ? 1 : 0, 1);
}, "~B");
Clazz.defineMethod (c$, "setFocusableInTouchMode", 
function (focusableInTouchMode) {
this.setFlags (focusableInTouchMode ? 262144 : 0, 262144);
if (focusableInTouchMode) {
this.setFlags (1, 1);
}}, "~B");
Clazz.defineMethod (c$, "setSoundEffectsEnabled", 
function (soundEffectsEnabled) {
this.setFlags (soundEffectsEnabled ? 134217728 : 0, 134217728);
}, "~B");
Clazz.defineMethod (c$, "isSoundEffectsEnabled", 
function () {
return 134217728 == (this.mViewFlags & 134217728);
});
Clazz.defineMethod (c$, "setHapticFeedbackEnabled", 
function (hapticFeedbackEnabled) {
this.setFlags (hapticFeedbackEnabled ? 268435456 : 0, 268435456);
}, "~B");
Clazz.defineMethod (c$, "isHapticFeedbackEnabled", 
function () {
return 268435456 == (this.mViewFlags & 268435456);
});
Clazz.defineMethod (c$, "setWillNotDraw", 
function (willNotDraw) {
this.setFlags (willNotDraw ? 128 : 0, 128);
}, "~B");
Clazz.defineMethod (c$, "willNotDraw", 
function () {
return (this.mViewFlags & 128) == 128;
});
Clazz.defineMethod (c$, "setWillNotCacheDrawing", 
function (willNotCacheDrawing) {
this.setFlags (willNotCacheDrawing ? 131072 : 0, 131072);
}, "~B");
Clazz.defineMethod (c$, "willNotCacheDrawing", 
function () {
return (this.mViewFlags & 131072) == 131072;
});
Clazz.defineMethod (c$, "isClickable", 
function () {
return (this.mViewFlags & 16384) == 16384;
});
Clazz.defineMethod (c$, "setClickable", 
function (clickable) {
this.setFlags (clickable ? 16384 : 0, 16384);
}, "~B");
Clazz.defineMethod (c$, "isLongClickable", 
function () {
return (this.mViewFlags & 2097152) == 2097152;
});
Clazz.defineMethod (c$, "setLongClickable", 
function (longClickable) {
this.setFlags (longClickable ? 2097152 : 0, 2097152);
}, "~B");
Clazz.defineMethod (c$, "setPressed", 
function (pressed) {
if (pressed) {
this.mPrivateFlags |= 16384;
} else {
this.mPrivateFlags &= -16385;
}this.dispatchSetPressed (pressed);
}, "~B");
Clazz.defineMethod (c$, "dispatchSetPressed", 
function (pressed) {
}, "~B");
Clazz.defineMethod (c$, "isPressed", 
function () {
return (this.mPrivateFlags & 16384) == 16384;
});
Clazz.defineMethod (c$, "isSaveEnabled", 
function () {
return (this.mViewFlags & 65536) != 65536;
});
Clazz.defineMethod (c$, "setSaveEnabled", 
function (enabled) {
this.setFlags (enabled ? 0 : 65536, 65536);
}, "~B");
Clazz.defineMethod (c$, "getFilterTouchesWhenObscured", 
function () {
return (this.mViewFlags & 1024) != 0;
});
Clazz.defineMethod (c$, "setFilterTouchesWhenObscured", 
function (enabled) {
this.setFlags (enabled ? 0 : 1024, 1024);
}, "~B");
Clazz.defineMethod (c$, "isFocusable", 
function () {
return 1 == (this.mViewFlags & 1);
});
Clazz.defineMethod (c$, "isFocusableInTouchMode", 
function () {
return 262144 == (this.mViewFlags & 262144);
});
Clazz.defineMethod (c$, "focusSearch", 
function (direction) {
if (this.mParent != null) {
return this.mParent.focusSearch (this, direction);
} else {
return null;
}}, "~N");
Clazz.defineMethod (c$, "dispatchUnhandledMove", 
function (focused, direction) {
return false;
}, "android.view.View,~N");
Clazz.defineMethod (c$, "findUserSetNextFocus", 
function (root, direction) {
switch (direction) {
case 17:
if (this.mNextFocusLeftId == -1) return null;
return android.view.View.findViewShouldExist (root, this.mNextFocusLeftId);
case 66:
if (this.mNextFocusRightId == -1) return null;
return android.view.View.findViewShouldExist (root, this.mNextFocusRightId);
case 33:
if (this.mNextFocusUpId == -1) return null;
return android.view.View.findViewShouldExist (root, this.mNextFocusUpId);
case 130:
if (this.mNextFocusDownId == -1) return null;
return android.view.View.findViewShouldExist (root, this.mNextFocusDownId);
}
return null;
}, "android.view.View,~N");
c$.findViewShouldExist = Clazz.defineMethod (c$, "findViewShouldExist", 
($fz = function (root, childViewId) {
var result = root.findViewById (childViewId);
if (result == null) {
}return result;
}, $fz.isPrivate = true, $fz), "android.view.View,~N");
Clazz.defineMethod (c$, "getFocusables", 
function (direction) {
var result =  new java.util.ArrayList (24);
this.addFocusables (result, direction);
return result;
}, "~N");
Clazz.defineMethod (c$, "addFocusables", 
function (views, direction) {
this.addFocusables (views, direction, 1);
}, "java.util.ArrayList,~N");
Clazz.defineMethod (c$, "addFocusables", 
function (views, direction, focusableMode) {
if (!this.isFocusable ()) {
return ;
}if ((focusableMode & 1) == 1 && this.isInTouchMode () && !this.isFocusableInTouchMode ()) {
return ;
}if (views != null) {
views.add (this);
}}, "java.util.ArrayList,~N,~N");
Clazz.defineMethod (c$, "getTouchables", 
function () {
var result =  new java.util.ArrayList ();
this.addTouchables (result);
return result;
});
Clazz.defineMethod (c$, "addTouchables", 
function (views) {
var viewFlags = this.mViewFlags;
if (((viewFlags & 16384) == 16384 || (viewFlags & 2097152) == 2097152) && (viewFlags & 32) == 0) {
views.add (this);
}}, "java.util.ArrayList");
Clazz.defineMethod (c$, "requestFocus", 
function () {
return this.requestFocus (130);
});
Clazz.defineMethod (c$, "requestFocus", 
function (direction) {
return this.requestFocus (direction, null);
}, "~N");
Clazz.defineMethod (c$, "requestFocus", 
function (direction, previouslyFocusedRect) {
if ((this.mViewFlags & 1) != 1 || (this.mViewFlags & 12) != 0) {
return false;
}if (this.isInTouchMode () && (262144 != (this.mViewFlags & 262144))) {
return false;
}if (this.hasAncestorThatBlocksDescendantFocus ()) {
return false;
}this.handleFocusGainInternal (direction, previouslyFocusedRect);
return true;
}, "~N,android.graphics.Rect");
Clazz.defineMethod (c$, "requestFocusFromTouch", 
function () {
return this.requestFocus (130);
});
Clazz.defineMethod (c$, "hasAncestorThatBlocksDescendantFocus", 
($fz = function () {
var ancestor = this.mParent;
while (Clazz.instanceOf (ancestor, android.view.ViewGroup)) {
var vgAncestor = ancestor;
if (vgAncestor.getDescendantFocusability () == 393216) {
return true;
} else {
ancestor = vgAncestor.getParent ();
}}
return false;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "dispatchStartTemporaryDetach", 
function () {
this.onStartTemporaryDetach ();
});
Clazz.defineMethod (c$, "onStartTemporaryDetach", 
function () {
this.mPrivateFlags |= 67108864;
});
Clazz.defineMethod (c$, "dispatchFinishTemporaryDetach", 
function () {
this.onFinishTemporaryDetach ();
});
Clazz.defineMethod (c$, "onFinishTemporaryDetach", 
function () {
});
Clazz.defineMethod (c$, "getKeyDispatcherState", 
function () {
return this.mAttachInfo != null ? this.mAttachInfo.mKeyDispatchState : null;
});
Clazz.defineMethod (c$, "dispatchKeyEventPreIme", 
function (event) {
return this.onKeyPreIme (event.getKeyCode (), event);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "dispatchKeyEvent", 
function (event) {
if (this.mOnKeyListener != null && (this.mViewFlags & 32) == 0 && this.mOnKeyListener.onKey (this, event.getKeyCode (), event)) {
return true;
}return event.dispatch (this, this.mAttachInfo != null ? this.mAttachInfo.mKeyDispatchState : null, this);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "dispatchKeyShortcutEvent", 
function (event) {
return this.onKeyShortcut (event.getKeyCode (), event);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "dispatchWindowFocusChanged", 
function (hasFocus) {
this.onWindowFocusChanged (hasFocus);
}, "~B");
Clazz.defineMethod (c$, "dispatchWindowVisibilityChanged", 
function (visibility) {
this.onWindowVisibilityChanged (visibility);
}, "~N");
Clazz.defineMethod (c$, "onWindowFocusChanged", 
function (hasWindowFocus) {
}, "~B");
Clazz.defineMethod (c$, "hasWindowFocus", 
function () {
return this.mAttachInfo != null && this.mAttachInfo.mHasWindowFocus;
});
Clazz.defineMethod (c$, "dispatchDisplayHint", 
function (hint) {
this.onDisplayHint (hint);
}, "~N");
Clazz.defineMethod (c$, "onDisplayHint", 
function (hint) {
}, "~N");
Clazz.defineMethod (c$, "dispatchCollectViewAttributes", 
function (visibility) {
this.performCollectViewAttributes (visibility);
}, "~N");
Clazz.defineMethod (c$, "performCollectViewAttributes", 
function (visibility) {
if (((visibility | this.mViewFlags) & (67108876)) == (67108864)) {
this.mAttachInfo.mKeepScreenOn = true;
}}, "~N");
Clazz.defineMethod (c$, "needGlobalAttributesUpdate", 
function (force) {
var ai = this.mAttachInfo;
if (ai != null) {
if (ai.mKeepScreenOn || force) {
ai.mRecomputeGlobalAttributes = true;
}}}, "~B");
Clazz.defineMethod (c$, "isInTouchMode", 
function () {
if (this.mAttachInfo != null) {
return this.mAttachInfo.mInTouchMode;
} else {
return android.view.ViewRoot.isInTouchMode ();
}});
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.defineMethod (c$, "onKeyPreIme", 
function (keyCode, event) {
return false;
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onTouchEvent", 
function (event) {
var viewFlags = this.mViewFlags;
if ((viewFlags & 32) == 32) {
return (((viewFlags & 16384) == 16384 || (viewFlags & 2097152) == 2097152));
}if (this.mTouchDelegate != null) {
if (this.mTouchDelegate.onTouchEvent (event)) {
return true;
}}if (((viewFlags & 16384) == 16384 || (viewFlags & 2097152) == 2097152)) {
switch (event.getAction ()) {
case 1:
var prepressed = (this.mPrivateFlags & 33554432) != 0;
if ((this.mPrivateFlags & 16384) != 0 || prepressed) {
var focusTaken = false;
if (this.isFocusable () && this.isFocusableInTouchMode () && !this.isFocused ()) {
focusTaken = this.requestFocus ();
}if (!focusTaken) {
this.performClick ();
}}break;
case 0:
this.mPrivateFlags |= 33554432;
break;
case 3:
this.mPrivateFlags &= -16385;
this.refreshDrawableState ();
break;
case 2:
if ((this.mPrivateFlags & 16384) != 0) {
this.mPrivateFlags &= -16385;
this.refreshDrawableState ();
}break;
}
return true;
}return false;
}, "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onKeyDown", 
function (keyCode, event) {
var result = false;
switch (keyCode) {
case 23:
case 13:
{
if ((this.mViewFlags & 32) == 32) {
return true;
}if (((this.mViewFlags & 16384) == 16384 || (this.mViewFlags & 2097152) == 2097152) && (event.getRepeatCount () == 0)) {
this.setPressed (true);
if ((this.mViewFlags & 2097152) == 2097152) {
}return true;
}break;
}}
return result;
}, "~N,android.view.KeyEvent");
Clazz.overrideMethod (c$, "onKeyLongPress", 
function (keyCode, event) {
return false;
}, "~N,android.view.KeyEvent");
Clazz.overrideMethod (c$, "onKeyUp", 
function (keyCode, event) {
var result = false;
switch (keyCode) {
case 23:
case 13:
{
if ((this.mViewFlags & 32) == 32) {
return true;
}if ((this.mViewFlags & 16384) == 16384 && this.isPressed ()) {
this.setPressed (false);
if (!this.mHasPerformedLongPress) {
result = this.performClick ();
}}break;
}}
return result;
}, "~N,android.view.KeyEvent");
Clazz.overrideMethod (c$, "onKeyMultiple", 
function (keyCode, repeatCount, event) {
return false;
}, "~N,~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyShortcut", 
function (keyCode, event) {
return false;
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onCheckIsTextEditor", 
function () {
return false;
});
Clazz.defineMethod (c$, "checkInputConnectionProxy", 
function (view) {
return false;
}, "android.view.View");
Clazz.defineMethod (c$, "removeCallbacks", 
function (action) {
var handler;
if (this.mAttachInfo != null) {
handler = this.mAttachInfo.mHandler;
} else {
return true;
}handler.removeCallbacks (action);
return true;
}, "Runnable");
Clazz.defineMethod (c$, "setFlags", 
function (flags, mask) {
var old = this.mViewFlags;
this.mViewFlags = (this.mViewFlags & ~mask) | (flags & mask);
var changed = this.mViewFlags ^ old;
if (changed == 0) {
return ;
}var privateFlags = this.mPrivateFlags;
if (((changed & 1) != 0) && ((privateFlags & 16) != 0)) {
if (((old & 1) == 1) && ((privateFlags & 2) != 0)) {
this.clearFocus ();
} else if (((old & 1) == 0) && ((privateFlags & 2) == 0)) {
if (this.mParent != null) this.mParent.focusableViewAvailable (this);
}}if ((flags & 12) == 0) {
if ((changed & 12) != 0) {
this.mPrivateFlags |= 32;
this.needGlobalAttributesUpdate (true);
if ((this.mParent != null) && (this.mBottom > this.mTop) && (this.mRight > this.mLeft)) {
this.mParent.focusableViewAvailable (this);
}}}if ((changed & 8) != 0) {
this.needGlobalAttributesUpdate (false);
this.requestLayout ();
this.invalidate ();
if (((this.mViewFlags & 12) == 8)) {
if (this.hasFocus ()) this.clearFocus ();
}if (this.mAttachInfo != null) {
this.mAttachInfo.mViewVisibilityChanged = true;
}}if ((changed & 4) != 0) {
this.needGlobalAttributesUpdate (false);
this.invalidate ();
if (((this.mViewFlags & 12) == 4) && this.hasFocus ()) {
if (this.getRootView () !== this) {
this.clearFocus ();
}}if (this.mAttachInfo != null) {
this.mAttachInfo.mViewVisibilityChanged = true;
}}if ((changed & 12) != 0) {
}if ((changed & 131072) != 0) {
}if ((changed & 32768) != 0) {
this.mPrivateFlags &= -32769;
}if ((changed & 1572864) != 0) {
this.mPrivateFlags &= -32769;
}if ((changed & 128) != 0) {
if ((this.mViewFlags & 128) != 0) {
if (this.mBGDrawable != null) {
this.mPrivateFlags &= -129;
this.mPrivateFlags |= 256;
} else {
this.mPrivateFlags |= 128;
}} else {
this.mPrivateFlags &= -129;
}this.requestLayout ();
this.invalidate ();
}if ((changed & 67108864) != 0) {
if (this.mParent != null) {
this.mParent.recomputeViewAttributes (this);
}}}, "~N,~N");
Clazz.defineMethod (c$, "bringToFront", 
function () {
if (this.mParent != null) {
this.mParent.bringChildToFront (this);
}});
Clazz.defineMethod (c$, "onScrollChanged", 
function (l, t, oldl, oldt) {
this.mBackgroundSizeChanged = true;
var ai = this.mAttachInfo;
if (ai != null) {
ai.mViewScrollChanged = true;
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "onSizeChanged", 
function (w, h, oldw, oldh) {
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "getParent", 
function () {
return this.mParent;
});
Clazz.defineMethod (c$, "getScrollX", 
function () {
return this.mScrollX;
});
Clazz.defineMethod (c$, "getScrollY", 
function () {
return this.mScrollY;
});
Clazz.defineMethod (c$, "getWidth", 
function () {
return this.mRight - this.mLeft;
});
Clazz.defineMethod (c$, "getHeight", 
function () {
return this.mBottom - this.mTop;
});
Clazz.defineMethod (c$, "getDrawingRect", 
function (outRect) {
outRect.left = this.mScrollX;
outRect.top = this.mScrollY;
outRect.right = this.mScrollX + (this.mRight - this.mLeft);
outRect.bottom = this.mScrollY + (this.mBottom - this.mTop);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "getMeasuredWidth", 
function () {
return this.mMeasuredWidth;
});
Clazz.defineMethod (c$, "getMeasuredHeight", 
function () {
return this.mMeasuredHeight;
});
Clazz.defineMethod (c$, "getTop", 
function () {
return this.mTop;
});
Clazz.defineMethod (c$, "getAbsoluteTop", 
function () {
var absoluteTop = this.mTop;
var parent = this;
while (parent.mParent != null && Clazz.instanceOf (parent.mParent, android.view.View)) {
parent = parent.mParent;
absoluteTop += parent.mTop;
}
return absoluteTop;
});
Clazz.defineMethod (c$, "getBottom", 
function () {
return this.mBottom;
});
Clazz.defineMethod (c$, "getLeft", 
function () {
return this.mLeft;
});
Clazz.defineMethod (c$, "getAbsoluteLeft", 
function () {
var absoluteLeft = this.mLeft;
var parent = this;
while (parent.mParent != null && Clazz.instanceOf (parent.mParent, android.view.View)) {
parent = parent.mParent;
absoluteLeft += parent.mLeft;
}
return absoluteLeft;
});
Clazz.defineMethod (c$, "getRight", 
function () {
return this.mRight;
});
Clazz.defineMethod (c$, "getHitRect", 
function (outRect) {
outRect.set (this.mLeft, this.mTop, this.mRight, this.mBottom);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "getFocusedRect", 
function (r) {
this.getDrawingRect (r);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "getGlobalVisibleRect", 
function (r, globalOffset) {
var width = this.mRight - this.mLeft;
var height = this.mBottom - this.mTop;
if (width > 0 && height > 0) {
r.set (0, 0, width, height);
if (globalOffset != null) {
globalOffset.set (-this.mScrollX, -this.mScrollY);
}return this.mParent == null || this.mParent.getChildVisibleRect (this, r, globalOffset);
}return false;
}, "android.graphics.Rect,android.graphics.Point");
Clazz.defineMethod (c$, "getGlobalVisibleRect", 
function (r) {
return this.getGlobalVisibleRect (r, null);
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "getLocalVisibleRect", 
function (r) {
var offset =  new android.graphics.Point ();
if (this.getGlobalVisibleRect (r, offset)) {
r.offset (-offset.x, -offset.y);
return true;
}return false;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "offsetTopAndBottom", 
function (offset) {
this.mTop += offset;
this.mBottom += offset;
}, "~N");
Clazz.defineMethod (c$, "offsetLeftAndRight", 
function (offset) {
this.mLeft += offset;
this.mRight += offset;
}, "~N");
Clazz.defineMethod (c$, "getLayoutParams", 
function () {
return this.mLayoutParams;
});
Clazz.defineMethod (c$, "setLayoutParams", 
function (params) {
if (params == null) {
throw  new NullPointerException ("params == null");
}this.mLayoutParams = params;
this.requestLayout ();
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "awakenScrollBars", 
function () {
return this.mScrollCache != null && this.awakenScrollBars (this.mScrollCache.scrollBarDefaultDelayBeforeFade, true);
});
Clazz.defineMethod (c$, "awakenScrollBars", 
function (startDelay) {
return this.awakenScrollBars (startDelay, true);
}, "~N");
Clazz.defineMethod (c$, "awakenScrollBars", 
function (startDelay, invalidate) {
return false;
}, "~N,~B");
Clazz.defineMethod (c$, "invalidate", 
function (dirty) {
if ((this.mPrivateFlags & (48)) == (48)) {
this.mPrivateFlags &= -32769;
var p = this.mParent;
var ai = this.mAttachInfo;
if (p != null && ai != null) {
var scrollX = this.mScrollX;
var scrollY = this.mScrollY;
var r = ai.mTmpInvalRect;
r.set (dirty.left - scrollX, dirty.top - scrollY, dirty.right - scrollX, dirty.bottom - scrollY);
this.mParent.invalidateChild (this, r);
}}}, "android.graphics.Rect");
Clazz.defineMethod (c$, "invalidate", 
function (l, t, r, b) {
if ((this.mPrivateFlags & (48)) == (48)) {
this.mPrivateFlags &= -32769;
var p = this.mParent;
var ai = this.mAttachInfo;
if (p != null && ai != null && l < r && t < b) {
var scrollX = this.mScrollX;
var scrollY = this.mScrollY;
var tmpr = ai.mTmpInvalRect;
tmpr.set (l - scrollX, t - scrollY, r - scrollX, b - scrollY);
p.invalidateChild (this, tmpr);
}}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "invalidate", 
function () {
if ((this.mPrivateFlags & (48)) == (48)) {
this.mPrivateFlags &= -32801;
var p = this.mParent;
var ai = this.mAttachInfo;
if (p != null && ai != null) {
var r = ai.mTmpInvalRect;
r.set (0, 0, this.mRight - this.mLeft, this.mBottom - this.mTop);
p.invalidateChild (this, r);
}}});
Clazz.defineMethod (c$, "isOpaque", 
function () {
return (this.mPrivateFlags & 25165824) == 25165824;
});
Clazz.defineMethod (c$, "computeOpaqueFlags", 
($fz = function () {
if (this.mBGDrawable != null && this.mBGDrawable.getOpacity () == -1) {
this.mPrivateFlags |= 8388608;
} else {
this.mPrivateFlags &= -8388609;
}var flags = this.mViewFlags;
if (((flags & 512) == 0 && (flags & 256) == 0) || (flags & 50331648) == 0) {
this.mPrivateFlags |= 16777216;
} else {
this.mPrivateFlags &= -16777217;
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "hasOpaqueScrollbars", 
function () {
return (this.mPrivateFlags & 16777216) == 16777216;
});
Clazz.defineMethod (c$, "getHandler", 
function () {
if (this.mAttachInfo != null) {
return this.mAttachInfo.mHandler;
}return null;
});
Clazz.defineMethod (c$, "computeScroll", 
function () {
});
Clazz.defineMethod (c$, "isHorizontalFadingEdgeEnabled", 
function () {
return (this.mViewFlags & 4096) == 4096;
});
Clazz.defineMethod (c$, "setHorizontalFadingEdgeEnabled", 
function (horizontalFadingEdgeEnabled) {
if (this.isHorizontalFadingEdgeEnabled () != horizontalFadingEdgeEnabled) {
if (horizontalFadingEdgeEnabled) {
}this.mViewFlags ^= 4096;
}}, "~B");
Clazz.defineMethod (c$, "isVerticalFadingEdgeEnabled", 
function () {
return (this.mViewFlags & 8192) == 8192;
});
Clazz.defineMethod (c$, "setVerticalFadingEdgeEnabled", 
function (verticalFadingEdgeEnabled) {
if (this.isVerticalFadingEdgeEnabled () != verticalFadingEdgeEnabled) {
if (verticalFadingEdgeEnabled) {
}this.mViewFlags ^= 8192;
}}, "~B");
Clazz.defineMethod (c$, "getTopFadingEdgeStrength", 
function () {
return this.computeVerticalScrollOffset () > 0 ? 1.0 : 0.0;
});
Clazz.defineMethod (c$, "getBottomFadingEdgeStrength", 
function () {
return this.computeVerticalScrollOffset () + this.computeVerticalScrollExtent () < this.computeVerticalScrollRange () ? 1.0 : 0.0;
});
Clazz.defineMethod (c$, "getLeftFadingEdgeStrength", 
function () {
return this.computeHorizontalScrollOffset () > 0 ? 1.0 : 0.0;
});
Clazz.defineMethod (c$, "getRightFadingEdgeStrength", 
function () {
return this.computeHorizontalScrollOffset () + this.computeHorizontalScrollExtent () < this.computeHorizontalScrollRange () ? 1.0 : 0.0;
});
Clazz.defineMethod (c$, "getVerticalScrollbarWidth", 
function () {
var cache = this.mScrollCache;
if (cache != null) {
var scrollBar = cache.scrollBar;
if (scrollBar != null) {
var size = scrollBar.getSize (true);
if (size <= 0) {
size = cache.scrollBarSize;
}return size;
}return 0;
}return 0;
});
Clazz.defineMethod (c$, "getHorizontalScrollbarHeight", 
function () {
var cache = this.mScrollCache;
if (cache != null) {
var scrollBar = cache.scrollBar;
if (scrollBar != null) {
var size = scrollBar.getSize (false);
if (size <= 0) {
size = cache.scrollBarSize;
}return size;
}return 0;
}return 0;
});
Clazz.defineMethod (c$, "initializeScrollbars", 
function (a) {
this.initScrollCache ();
var scrollabilityCache = this.mScrollCache;
if (scrollabilityCache.scrollBar == null) {
scrollabilityCache.scrollBar =  new android.widget.ScrollBarDrawable ();
}var fadeScrollbars = a.getBoolean (44, true);
if (!fadeScrollbars) {
scrollabilityCache.state = 1;
}scrollabilityCache.fadeScrollBars = fadeScrollbars;
scrollabilityCache.scrollBarFadeDuration = a.getInt (42, android.view.ViewConfiguration.getScrollBarFadeDuration ());
scrollabilityCache.scrollBarDefaultDelayBeforeFade = a.getInt (43, android.view.ViewConfiguration.getScrollDefaultDelay ());
scrollabilityCache.scrollBarSize = a.getDimensionPixelSize (0, android.view.ViewConfiguration.get (this.mContext).getScaledScrollBarSize ());
var track = a.getDrawable (3);
scrollabilityCache.scrollBar.setHorizontalTrackDrawable (track);
var thumb = a.getDrawable (1);
if (thumb != null) {
scrollabilityCache.scrollBar.setHorizontalThumbDrawable (thumb);
}var alwaysDraw = a.getBoolean (5, false);
if (alwaysDraw) {
scrollabilityCache.scrollBar.setAlwaysDrawHorizontalTrack (true);
}track = a.getDrawable (4);
scrollabilityCache.scrollBar.setVerticalTrackDrawable (track);
thumb = a.getDrawable (2);
if (thumb != null) {
scrollabilityCache.scrollBar.setVerticalThumbDrawable (thumb);
}alwaysDraw = a.getBoolean (6, false);
if (alwaysDraw) {
scrollabilityCache.scrollBar.setAlwaysDrawVerticalTrack (true);
}this.recomputePadding ();
}, "android.content.res.TypedArray");
Clazz.defineMethod (c$, "initScrollCache", 
($fz = function () {
if (this.mScrollCache == null) {
this.mScrollCache =  new android.view.View.ScrollabilityCache (android.view.ViewConfiguration.get (this.mContext), this);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "isHorizontalScrollBarEnabled", 
function () {
return (this.mViewFlags & 256) == 256;
});
Clazz.defineMethod (c$, "setHorizontalScrollBarEnabled", 
function (horizontalScrollBarEnabled) {
if (this.isHorizontalScrollBarEnabled () != horizontalScrollBarEnabled) {
this.mViewFlags ^= 256;
this.computeOpaqueFlags ();
this.recomputePadding ();
}}, "~B");
Clazz.defineMethod (c$, "isVerticalScrollBarEnabled", 
function () {
return (this.mViewFlags & 512) == 512;
});
Clazz.defineMethod (c$, "setVerticalScrollBarEnabled", 
function (verticalScrollBarEnabled) {
if (this.isVerticalScrollBarEnabled () != verticalScrollBarEnabled) {
this.mViewFlags ^= 512;
this.computeOpaqueFlags ();
this.recomputePadding ();
}}, "~B");
Clazz.defineMethod (c$, "recomputePadding", 
($fz = function () {
this.setPadding (this.mPaddingLeft, this.mPaddingTop, this.mUserPaddingRight, this.mUserPaddingBottom);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setScrollBarStyle", 
function (style) {
if (style != (this.mViewFlags & 50331648)) {
this.mViewFlags = (this.mViewFlags & -50331649) | (style & 50331648);
this.computeOpaqueFlags ();
this.recomputePadding ();
}}, "~N");
Clazz.defineMethod (c$, "getScrollBarStyle", 
function () {
return this.mViewFlags & 50331648;
});
Clazz.defineMethod (c$, "computeHorizontalScrollRange", 
function () {
return this.getWidth ();
});
Clazz.defineMethod (c$, "computeHorizontalScrollOffset", 
function () {
return this.mScrollX;
});
Clazz.defineMethod (c$, "computeHorizontalScrollExtent", 
function () {
return this.getWidth ();
});
Clazz.defineMethod (c$, "computeVerticalScrollRange", 
function () {
return this.getHeight ();
});
Clazz.defineMethod (c$, "computeVerticalScrollOffset", 
function () {
return this.mScrollY;
});
Clazz.defineMethod (c$, "computeVerticalScrollExtent", 
function () {
return this.getHeight ();
});
Clazz.defineMethod (c$, "isVerticalScrollBarHidden", 
function () {
return false;
});
Clazz.defineMethod (c$, "onDraw", 
function (canvas) {
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "assignParent", 
function (parent, modifyDom) {
if (modifyDom == true) {
if (this.mParent == null) {
this.mParent = parent;
} else if (parent == null) {
this.mParent = null;
return ;
} else {
throw  new RuntimeException ("view " + this.getUIElementID () + " being added, but" + " it already has a parent");
}}var parentUIID = (parent).getUIElementID ();
var thisViewId = this.getUIElementID ();
var pending = false;
if (android.util.DebugUtils.DEBUG_VIEW_IN_BROWSER) {
var thisView = document.getElementById(this.mUIElementID);
if (null == thisView) {
thisView = document.createElement("span");
thisView.style.position = "absolute";
thisView.id = this.mUIElementID;
if (modifyDom == true) {
thisView.style.display = "block";
} else {
thisView.style.display = "none";
}
thisView.style.background = "transparent";
var thisParent = document.getElementById(parentUIID);
if(!thisParent){
// Assign it to the top element, temporarily
thisParent = document.getElementById(0);
pending = true;
}
thisParent.appendChild(thisView);
} else {
if (modifyDom == true) {
thisView.style.display = "block";
} else {
thisView.style.display = "none";
}
}
}if (pending) {
if (Clazz.instanceOf (parent, android.view.ViewGroup)) {
var group = parent;
group.addPendingChild (this);
}} else if (Clazz.instanceOf (this, android.view.ViewGroup)) {
var group = this;
group.fixPendingChildren ();
}}, "android.view.ViewParent,~B");
Clazz.defineMethod (c$, "fixParent", 
function (parent, modifyDom) {
this.mParent = parent;
if (android.util.DebugUtils.DEBUG_VIEW_IN_BROWSER) {
var parentUIID = (parent).getUIElementID ();
var thisViewId = this.getUIElementID ();
var thisView = document.getElementById(this.mUIElementID);
var thisParent = document.getElementById(parentUIID);
if(thisParent){
thisView.parentNode.removeChild(thisView);
thisParent.appendChild(thisView);
}
System.out.println ("View fixParent done: Parent ID " + parentUIID + " this view ID " + thisViewId);
}}, "android.view.ViewParent,~B");
Clazz.defineMethod (c$, "onAttachedToWindow", 
function () {
if ((this.mPrivateFlags & 512) != 0) {
this.mParent.requestTransparentRegion (this);
}if ((this.mPrivateFlags & 134217728) != 0) {
this.mPrivateFlags &= -134217729;
}});
Clazz.defineMethod (c$, "onDetachedFromWindow", 
function () {
this.mPrivateFlags &= -67108865;
});
Clazz.defineMethod (c$, "getWindowAttachCount", 
function () {
return this.mWindowAttachCount;
});
Clazz.defineMethod (c$, "dispatchAttachedToWindow", 
function (info, visibility) {
this.mAttachInfo = info;
this.mWindowAttachCount++;
if ((this.mPrivateFlags & 524288) != 0) {
this.mAttachInfo.mScrollContainers.add (this);
this.mPrivateFlags |= 1048576;
}this.performCollectViewAttributes (visibility);
this.onAttachedToWindow ();
var vis = info.mWindowVisibility;
if (vis != 8) {
this.onWindowVisibilityChanged (vis);
}}, "android.view.View.AttachInfo,~N");
Clazz.defineMethod (c$, "onWindowVisibilityChanged", 
function (visibility) {
if (visibility == 0) {
this.initialAwakenScrollBars ();
}}, "~N");
Clazz.defineMethod (c$, "initialAwakenScrollBars", 
($fz = function () {
return this.mScrollCache != null && this.awakenScrollBars (this.mScrollCache.scrollBarDefaultDelayBeforeFade * 4, true);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "dispatchDetachedFromWindow", 
function () {
this.onDetachedFromWindow ();
if ((this.mPrivateFlags & 1048576) != 0) {
this.mAttachInfo.mScrollContainers.remove (this);
this.mPrivateFlags &= -1048577;
}this.mAttachInfo = null;
});
Clazz.defineMethod (c$, "saveHierarchyState", 
function (container) {
this.dispatchSaveInstanceState (container);
}, "android.util.SparseArray");
Clazz.defineMethod (c$, "dispatchSaveInstanceState", 
function (container) {
if (this.mID != -1 && (this.mViewFlags & 65536) == 0) {
this.mPrivateFlags &= -131073;
var state = this.onSaveInstanceState ();
if ((this.mPrivateFlags & 131072) == 0) {
throw  new IllegalStateException ("Derived class did not call super.onSaveInstanceState()");
}if (state != null) {
container.put (this.mID, state);
}}}, "android.util.SparseArray");
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
this.mPrivateFlags |= 131072;
return android.view.View.BaseSavedState.EMPTY_STATE;
});
Clazz.defineMethod (c$, "restoreHierarchyState", 
function (container) {
this.dispatchRestoreInstanceState (container);
}, "android.util.SparseArray");
Clazz.defineMethod (c$, "dispatchRestoreInstanceState", 
function (container) {
if (this.mID != -1) {
var state = container.get (this.mID);
if (state != null) {
this.mPrivateFlags &= -131073;
this.onRestoreInstanceState (state);
if ((this.mPrivateFlags & 131072) == 0) {
throw  new IllegalStateException ("Derived class did not call super.onRestoreInstanceState()");
}}}}, "android.util.SparseArray");
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
this.mPrivateFlags |= 131072;
if (state !== android.view.View.BaseSavedState.EMPTY_STATE && state != null) {
throw  new IllegalArgumentException ("Wrong state class, expecting View State but received " + state.getClass ().toString () + " instead. This usually happens " + "when two views of different type have the same id in the same hierarchy. ");
}}, "android.os.Parcelable");
Clazz.defineMethod (c$, "getDrawingTime", 
function () {
return this.mAttachInfo != null ? this.mAttachInfo.mDrawingTime : 0;
});
Clazz.defineMethod (c$, "setDuplicateParentStateEnabled", 
function (enabled) {
this.setFlags (enabled ? 4194304 : 0, 4194304);
}, "~B");
Clazz.defineMethod (c$, "isDuplicateParentStateEnabled", 
function () {
return (this.mViewFlags & 4194304) == 4194304;
});
Clazz.defineMethod (c$, "setDrawingCacheEnabled", 
function (enabled) {
this.setFlags (enabled ? 32768 : 0, 32768);
}, "~B");
Clazz.defineMethod (c$, "isDrawingCacheEnabled", 
function () {
return (this.mViewFlags & 32768) == 32768;
});
Clazz.defineMethod (c$, "setBackgroundResource", 
function (resid) {
if (resid != 0 && resid == this.mBackgroundResource) {
return ;
}var d = null;
if (resid != 0) {
d = this.mResources.getDrawable (resid);
}this.setBackgroundDrawable (d);
this.mBackgroundResource = resid;
}, "~N");
Clazz.defineMethod (c$, "dispatchTouchEvent", 
function (event) {
if (this.mOnTouchListener != null && (this.mViewFlags & 32) == 0 && this.mOnTouchListener.onTouch (this, event)) {
return true;
}return this.onTouchEvent (event);
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "setOnTouchListener", 
function (l) {
this.mOnTouchListener = l;
}, "android.view.View.OnTouchListener");
Clazz.defineMethod (c$, "getBackground", 
function () {
return this.mBGDrawable;
});
Clazz.defineMethod (c$, "setDrawingCacheBackgroundColor", 
function (color) {
if (color != this.mDrawingCacheBackgroundColor) {
this.mDrawingCacheBackgroundColor = color;
this.mPrivateFlags &= -32769;
}}, "~N");
Clazz.defineMethod (c$, "getDrawingCacheBackgroundColor", 
function () {
return this.mDrawingCacheBackgroundColor;
});
Clazz.defineMethod (c$, "isInEditMode", 
function () {
return false;
});
Clazz.defineMethod (c$, "isPaddingOffsetRequired", 
function () {
return false;
});
Clazz.defineMethod (c$, "getLeftPaddingOffset", 
function () {
return 0;
});
Clazz.defineMethod (c$, "getRightPaddingOffset", 
function () {
return 0;
});
Clazz.defineMethod (c$, "getTopPaddingOffset", 
function () {
return 0;
});
Clazz.defineMethod (c$, "getBottomPaddingOffset", 
function () {
return 0;
});
Clazz.defineMethod (c$, "draw", 
function (canvas) {
var privateFlags = this.mPrivateFlags;
var dirtyOpaque = (privateFlags & 6291456) == 4194304 && (this.mAttachInfo == null || !this.mAttachInfo.mIgnoreDirtyState);
this.mPrivateFlags = (privateFlags & -6291457) | 32;
var saveCount;
if (!dirtyOpaque) {
var background = this.mBGDrawable;
if (background != null) {
var scrollX = this.mScrollX;
var scrollY = this.mScrollY;
if (this.mBackgroundSizeChanged) {
background.setBounds (0, 0, this.mRight - this.mLeft, this.mBottom - this.mTop);
this.mBackgroundSizeChanged = false;
}canvas.chooseCanvas (android.graphics.Canvas.APP_CANVAS);
if ((scrollX | scrollY) == 0) {
background.draw (canvas);
} else {
canvas.translate (scrollX, scrollY);
background.draw (canvas);
canvas.translate (-scrollX, -scrollY);
}}}var viewFlags = this.mViewFlags;
var horizontalEdges = (viewFlags & 4096) != 0;
var verticalEdges = (viewFlags & 8192) != 0;
if (!verticalEdges && !horizontalEdges) {
if ((false == dirtyOpaque) && ((viewFlags & 12) == 0)) {
canvas.chooseCanvas (android.graphics.Canvas.APP_CANVAS);
this.onDraw (canvas);
}this.dispatchDraw (canvas);
return ;
}android.util.Log.d ("View", "View.draw, Full fledged routine");
var drawTop = false;
var drawBottom = false;
var drawLeft = false;
var drawRight = false;
var topFadeStrength = 0.0;
var bottomFadeStrength = 0.0;
var leftFadeStrength = 0.0;
var rightFadeStrength = 0.0;
var paddingLeft = this.mPaddingLeft;
var paddingTop = this.mPaddingTop;
var offsetRequired = this.isPaddingOffsetRequired ();
if (offsetRequired) {
paddingLeft += this.getLeftPaddingOffset ();
paddingTop += this.getTopPaddingOffset ();
}var left = this.mScrollX + paddingLeft;
var right = left + this.mRight - this.mLeft - this.mPaddingRight - paddingLeft;
var top = this.mScrollY + paddingTop;
var bottom = top + this.mBottom - this.mTop - this.mPaddingBottom - paddingTop;
if (offsetRequired) {
right += this.getRightPaddingOffset ();
bottom += this.getBottomPaddingOffset ();
}var scrollabilityCache = this.mScrollCache;
var length = scrollabilityCache.fadingEdgeLength;
if (verticalEdges && (top + length > bottom - length)) {
length = Math.floor ((bottom - top) / 2);
}if (horizontalEdges && (left + length > right - length)) {
length = Math.floor ((right - left) / 2);
}if (verticalEdges) {
topFadeStrength = Math.max (0.0, Math.min (1.0, this.getTopFadingEdgeStrength ()));
drawTop = topFadeStrength >= 0.0;
bottomFadeStrength = Math.max (0.0, Math.min (1.0, this.getBottomFadingEdgeStrength ()));
drawBottom = bottomFadeStrength >= 0.0;
}if (horizontalEdges) {
leftFadeStrength = Math.max (0.0, Math.min (1.0, this.getLeftFadingEdgeStrength ()));
drawLeft = leftFadeStrength >= 0.0;
rightFadeStrength = Math.max (0.0, Math.min (1.0, this.getRightFadingEdgeStrength ()));
drawRight = rightFadeStrength >= 0.0;
}saveCount = canvas.getSaveCount ();
if (!dirtyOpaque) this.onDraw (canvas);
this.dispatchDraw (canvas);
canvas.restoreToCount (saveCount);
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "getSolidColor", 
function () {
return 0;
});
Clazz.defineMethod (c$, "getResolvedLayoutDirection", 
function () {
this.resolveLayoutDirectionIfNeeded ();
return ((this.mPrivateFlags2 & 4) == 4) ? 1073741824 : 0;
});
Clazz.defineMethod (c$, "resolveLayoutDirectionIfNeeded", 
($fz = function () {
if ((this.mPrivateFlags2 & 8) == 8) return ;
this.mPrivateFlags2 &= -5;
this.resetResolvedTextDirection ();
switch (this.getLayoutDirection ()) {
case -2147483648:
if (this.mParent == null) return ;
if (Clazz.instanceOf (this.mParent, android.view.ViewGroup)) {
var viewGroup = (this.mParent);
if (!viewGroup.canResolveLayoutDirection ()) {
return ;
}if (viewGroup.getResolvedLayoutDirection () == 1073741824) {
this.mPrivateFlags2 |= 4;
}}break;
case 1073741824:
this.mPrivateFlags2 |= 4;
break;
case -1073741824:
if (android.view.View.isLayoutDirectionRtl (java.util.Locale.getDefault ())) {
this.mPrivateFlags2 |= 4;
}break;
default:
}
this.mPrivateFlags2 |= 8;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getLayoutDirection", 
function () {
return this.mViewFlags & -1073741824;
});
Clazz.defineMethod (c$, "canResolveLayoutDirection", 
function () {
switch (this.getLayoutDirection ()) {
case -2147483648:
return (this.mParent != null);
default:
return true;
}
});
c$.isLayoutDirectionRtl = Clazz.defineMethod (c$, "isLayoutDirectionRtl", 
function (locale) {
return (1 == android.util.LocaleUtil.getLayoutDirectionFromLocale (locale));
}, "java.util.Locale");
Clazz.defineMethod (c$, "isLayoutRequested", 
function () {
return (this.mPrivateFlags & 4096) == 4096;
});
Clazz.defineMethod (c$, "layout", 
function (l, t, r, b) {
var changed = this.setFrame (l, t, r, b);
if (changed || (this.mPrivateFlags & 8192) == 8192) {
this.onLayout (changed, l, t, r, b);
this.mPrivateFlags &= -8193;
}this.mPrivateFlags &= -4097;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "onLayout", 
function (changed, left, top, right, bottom) {
}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "setFrame", 
function (left, top, right, bottom) {
var changed = false;
if (this.mLeft != left || this.mRight != right || this.mTop != top || this.mBottom != bottom) {
changed = true;
var drawn = this.mPrivateFlags & 32;
this.invalidate ();
var oldWidth = this.mRight - this.mLeft;
var oldHeight = this.mBottom - this.mTop;
this.mLeft = left;
this.mTop = top;
this.mRight = right;
this.mBottom = bottom;
if (android.util.DebugUtils.DEBUG_VIEW_IN_BROWSER) {
thisView = document.getElementById(this.mUIElementID);
thisView.style.left = this.mLeft + "px";
thisView.style.top = this.mTop + "px";
thisView.style.right = this.mRight + "px";
thisView.style.bottom = this.mBottom + "px";
}this.mPrivateFlags |= 16;
var newWidth = right - left;
var newHeight = bottom - top;
if (newWidth != oldWidth || newHeight != oldHeight) {
this.onSizeChanged (newWidth, newHeight, oldWidth, oldHeight);
}if ((this.mViewFlags & 12) == 0) {
this.mPrivateFlags |= 32;
this.invalidate ();
}this.mPrivateFlags |= drawn;
this.mBackgroundSizeChanged = true;
}return changed;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "onFinishInflate", 
function () {
});
Clazz.defineMethod (c$, "getResources", 
function () {
return this.mResources;
});
Clazz.defineMethod (c$, "getDrawableState", 
function () {
if ((this.mDrawableState != null) && ((this.mPrivateFlags & 1024) == 0)) {
return this.mDrawableState;
} else {
this.mDrawableState = this.onCreateDrawableState (0);
this.mPrivateFlags &= -1025;
return this.mDrawableState;
}});
Clazz.defineMethod (c$, "onCreateDrawableState", 
function (extraSpace) {
if ((this.mViewFlags & 4194304) == 4194304 && Clazz.instanceOf (this.mParent, android.view.View)) {
return (this.mParent).onCreateDrawableState (extraSpace);
}var drawableState;
var privateFlags = this.mPrivateFlags;
var viewStateIndex = (((privateFlags & 16384) != 0) ? 1 : 0);
viewStateIndex = (viewStateIndex << 1) + (((this.mViewFlags & 32) == 0) ? 1 : 0);
viewStateIndex = (viewStateIndex << 1) + (this.isFocused () ? 1 : 0);
viewStateIndex = (viewStateIndex << 1) + (((privateFlags & 4) != 0) ? 1 : 0);
var hasWindowFocus = this.hasWindowFocus ();
viewStateIndex = (viewStateIndex << 1) + (hasWindowFocus ? 1 : 0);
drawableState = android.view.View.VIEW_STATE_SETS[viewStateIndex];
if (extraSpace == 0) {
return drawableState;
}var fullState;
if (drawableState != null) {
fullState =  Clazz.newArray (drawableState.length + extraSpace, 0);
System.arraycopy (drawableState, 0, fullState, 0, drawableState.length);
} else {
fullState =  Clazz.newArray (extraSpace, 0);
}return fullState;
}, "~N");
c$.mergeDrawableStates = Clazz.defineMethod (c$, "mergeDrawableStates", 
function (baseState, additionalState) {
var N = baseState.length;
var i = N - 1;
while (i >= 0 && baseState[i] == 0) {
i--;
}
System.arraycopy (additionalState, 0, baseState, i + 1, additionalState.length);
return baseState;
}, "~A,~A");
Clazz.defineMethod (c$, "setPadding", 
function (left, top, right, bottom) {
var changed = false;
this.mUserPaddingRight = right;
this.mUserPaddingBottom = bottom;
if (this.mPaddingLeft != left) {
changed = true;
this.mPaddingLeft = left;
}if (this.mPaddingTop != top) {
changed = true;
this.mPaddingTop = top;
}if (this.mPaddingRight != right) {
changed = true;
this.mPaddingRight = right;
}if (this.mPaddingBottom != bottom) {
changed = true;
this.mPaddingBottom = bottom;
}if (changed) {
this.requestLayout ();
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "getPaddingTop", 
function () {
return this.mPaddingTop;
});
Clazz.defineMethod (c$, "resetResolvedTextDirection", 
function () {
this.mResolvedTextDirection = 0;
});
Clazz.defineMethod (c$, "getPaddingBottom", 
function () {
return this.mPaddingBottom;
});
Clazz.defineMethod (c$, "getPaddingLeft", 
function () {
return this.mPaddingLeft;
});
Clazz.defineMethod (c$, "getPaddingRight", 
function () {
return this.mPaddingRight;
});
Clazz.defineMethod (c$, "setSelected", 
function (selected) {
if (((this.mPrivateFlags & 4) != 0) != selected) {
this.mPrivateFlags = (this.mPrivateFlags & -5) | (selected ? 4 : 0);
this.invalidate ();
this.dispatchSetSelected (selected);
}}, "~B");
Clazz.defineMethod (c$, "dispatchSetSelected", 
function (selected) {
}, "~B");
Clazz.defineMethod (c$, "isSelected", 
function () {
return (this.mPrivateFlags & 4) != 0;
});
Clazz.defineMethod (c$, "getViewTreeObserver", 
function () {
if (this.mAttachInfo != null) {
return this.mAttachInfo.mTreeObserver;
}return null;
});
Clazz.defineMethod (c$, "getRootView", 
function () {
var parent = this;
while (parent.mParent != null && Clazz.instanceOf (parent.mParent, android.view.View)) {
parent = parent.mParent;
}
return parent;
});
Clazz.defineMethod (c$, "getLocationOnScreen", 
function (location) {
this.getLocationInWindow (location);
var info = this.mAttachInfo;
if (info != null) {
location[0] += info.mWindowLeft;
location[1] += info.mWindowTop;
}}, "~A");
Clazz.defineMethod (c$, "getLocationInWindow", 
function (location) {
if (location == null || location.length < 2) {
throw  new IllegalArgumentException ("location must be an array of two integers");
}location[0] = this.mLeft;
location[1] = this.mTop;
var viewParent = this.mParent;
while (Clazz.instanceOf (viewParent, android.view.View)) {
var view = viewParent;
location[0] += view.mLeft - view.mScrollX;
location[1] += view.mTop - view.mScrollY;
viewParent = view.mParent;
}
if (Clazz.instanceOf (viewParent, android.view.ViewRoot)) {
var vr = viewParent;
location[1] -= vr.mCurScrollY;
}}, "~A");
Clazz.defineMethod (c$, "findViewTraversal", 
function (id) {
if (id == this.mID) {
return this;
}return null;
}, "~N");
Clazz.defineMethod (c$, "findViewWithTagTraversal", 
function (tag) {
if (tag != null && tag.equals (this.mTag)) {
return this;
}return null;
}, "~O");
Clazz.defineMethod (c$, "findViewById", 
function (id) {
if (id < 0) {
return null;
}return this.findViewTraversal (id);
}, "~N");
Clazz.defineMethod (c$, "findViewWithTag", 
function (tag) {
if (tag == null) {
return null;
}return this.findViewWithTagTraversal (tag);
}, "~O");
Clazz.defineMethod (c$, "setId", 
function (id) {
this.mID = id;
}, "~N");
Clazz.defineMethod (c$, "setIsRootNamespace", 
function (isRoot) {
if (isRoot) {
this.mPrivateFlags |= 8;
} else {
this.mPrivateFlags &= -9;
}}, "~B");
Clazz.defineMethod (c$, "isRootNamespace", 
function () {
return (this.mPrivateFlags & 8) != 0;
});
Clazz.defineMethod (c$, "getId", 
function () {
return this.mID;
});
Clazz.defineMethod (c$, "getTag", 
function () {
return this.mTag;
});
Clazz.defineMethod (c$, "setTag", 
function (tag) {
this.mTag = tag;
}, "~O");
Clazz.defineMethod (c$, "getTag", 
function (key) {
var tags = null;
{
if (android.view.View.sTags != null) {
tags = android.view.View.sTags.get (this);
}}if (tags != null) return tags.get (key);
return null;
}, "~N");
Clazz.defineMethod (c$, "setTag", 
function (key, tag) {
if ((key >>> 24) < 2) {
throw  new IllegalArgumentException ("The key must be an application-specific resource id.");
}android.view.View.setTagInternal (this, key, tag);
}, "~N,~O");
Clazz.defineMethod (c$, "setTagInternal", 
function (key, tag) {
if ((key >>> 24) != 0x1) {
throw  new IllegalArgumentException ("The key must be a framework-specific resource id.");
}android.view.View.setTagInternal (this, key, tag);
}, "~N,~O");
c$.setTagInternal = Clazz.defineMethod (c$, "setTagInternal", 
($fz = function (view, key, tag) {
var tags = null;
{
if (android.view.View.sTags == null) {
($t$ = android.view.View.sTags =  new java.util.WeakHashMap (), android.view.View.prototype.sTags = android.view.View.sTags, $t$);
} else {
tags = android.view.View.sTags.get (view);
}}if (tags == null) {
tags =  new android.util.SparseArray (2);
{
android.view.View.sTags.put (view, tags);
}}tags.put (key, tag);
}, $fz.isPrivate = true, $fz), "android.view.View,~N,~O");
Clazz.defineMethod (c$, "dispatchConsistencyCheck", 
function (consistency) {
return this.onConsistencyCheck (consistency);
}, "~N");
Clazz.defineMethod (c$, "onConsistencyCheck", 
function (consistency) {
return false;
}, "~N");
c$.debugIndent = Clazz.defineMethod (c$, "debugIndent", 
function (depth) {
var spaces =  new StringBuilder ((depth * 2 + 3) * 2);
for (var i = 0; i < (depth * 2) + 3; i++) {
spaces.append (' ').append (' ');
}
return spaces.toString ();
}, "~N");
Clazz.defineMethod (c$, "getBaseline", 
function () {
return -1;
});
Clazz.defineMethod (c$, "requestLayout", 
function () {
this.mPrivateFlags |= 4096;
if (this.mParent != null && this.mParent.isLayoutRequested () == false) {
this.mParent.requestLayout ();
}});
Clazz.defineMethod (c$, "forceLayout", 
function () {
this.mPrivateFlags |= 4096;
});
Clazz.defineMethod (c$, "measure", 
function (widthMeasureSpec, heightMeasureSpec) {
if ((this.mPrivateFlags & 4096) == 4096 || widthMeasureSpec != this.mOldWidthMeasureSpec || heightMeasureSpec != this.mOldHeightMeasureSpec) {
this.mPrivateFlags &= -2049;
this.onMeasure (widthMeasureSpec, heightMeasureSpec);
if ((this.mPrivateFlags & 2048) != 2048) {
throw  new IllegalStateException ("onMeasure() did not set the measured dimension by calling setMeasuredDimension()");
}this.mPrivateFlags |= 8192;
}this.mOldWidthMeasureSpec = widthMeasureSpec;
this.mOldHeightMeasureSpec = heightMeasureSpec;
}, "~N,~N");
Clazz.defineMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
this.setMeasuredDimension (android.view.View.getDefaultSize (this.getSuggestedMinimumWidth (), widthMeasureSpec), android.view.View.getDefaultSize (this.getSuggestedMinimumHeight (), heightMeasureSpec));
}, "~N,~N");
Clazz.defineMethod (c$, "setMeasuredDimension", 
function (measuredWidth, measuredHeight) {
this.basicSetDimension (measuredWidth, measuredHeight);
}, "~N,~N");
Clazz.defineMethod (c$, "basicSetDimension", 
function (measuredWidth, measuredHeight) {
this.mMeasuredWidth = measuredWidth;
this.mMeasuredHeight = measuredHeight;
if (android.util.DebugUtils.DEBUG_VIEW_IN_BROWSER) {
thisView = document.getElementById(this.mUIElementID);
if(thisView != null && thisView.tagName != "TEXTAREA") {
thisView.style.width = this.mMeasuredWidth + "px";
thisView.style.height = this.mMeasuredHeight + "px";
}
}this.mPrivateFlags |= 2048;
}, "~N,~N");
c$.resolveSize = Clazz.defineMethod (c$, "resolveSize", 
function (size, measureSpec) {
var result = size;
var specMode = android.view.View.MeasureSpec.getMode (measureSpec);
var specSize = android.view.View.MeasureSpec.getSize (measureSpec);
switch (specMode) {
case 0:
result = size;
break;
case -2147483648:
result = Math.min (size, specSize);
break;
case 1073741824:
result = specSize;
break;
}
return result;
}, "~N,~N");
c$.getDefaultSize = Clazz.defineMethod (c$, "getDefaultSize", 
function (size, measureSpec) {
var result = size;
var specMode = android.view.View.MeasureSpec.getMode (measureSpec);
var specSize = android.view.View.MeasureSpec.getSize (measureSpec);
switch (specMode) {
case 0:
result = size;
break;
case -2147483648:
case 1073741824:
result = specSize;
break;
}
return result;
}, "~N,~N");
Clazz.defineMethod (c$, "getSuggestedMinimumHeight", 
function () {
var suggestedMinHeight = this.mMinHeight;
if (this.mBGDrawable != null) {
var bgMinHeight = this.mBGDrawable.getMinimumHeight ();
if (suggestedMinHeight < bgMinHeight) {
suggestedMinHeight = bgMinHeight;
}}return suggestedMinHeight;
});
Clazz.defineMethod (c$, "getSuggestedMinimumWidth", 
function () {
var suggestedMinWidth = this.mMinWidth;
if (this.mBGDrawable != null) {
var bgMinWidth = this.mBGDrawable.getMinimumWidth ();
if (suggestedMinWidth < bgMinWidth) {
suggestedMinWidth = bgMinWidth;
}}return suggestedMinWidth;
});
Clazz.defineMethod (c$, "setMinimumHeight", 
function (minHeight) {
this.mMinHeight = minHeight;
}, "~N");
Clazz.defineMethod (c$, "setMinimumWidth", 
function (minWidth) {
this.mMinWidth = minWidth;
}, "~N");
Clazz.defineMethod (c$, "getAnimation", 
function () {
return this.mCurrentAnimation;
});
Clazz.defineMethod (c$, "startAnimation", 
function (animation) {
animation.setStartTime (-1);
this.setAnimation (animation);
this.invalidate ();
}, "android.view.animation.Animation");
Clazz.defineMethod (c$, "clearAnimation", 
function () {
if (this.mCurrentAnimation != null) {
this.mCurrentAnimation.detach ();
}this.mCurrentAnimation = null;
});
Clazz.defineMethod (c$, "setAnimation", 
function (animation) {
this.mCurrentAnimation = animation;
if (animation != null) {
animation.reset ();
}}, "android.view.animation.Animation");
Clazz.defineMethod (c$, "onAnimationStart", 
function () {
this.mPrivateFlags |= 65536;
});
Clazz.defineMethod (c$, "onAnimationEnd", 
function () {
this.mPrivateFlags &= -65537;
});
Clazz.defineMethod (c$, "onSetAlpha", 
function (alpha) {
return false;
}, "~N");
Clazz.defineMethod (c$, "playSoundEffect", 
function (soundConstant) {
if (this.mAttachInfo == null || this.mAttachInfo.mRootCallbacks == null || !this.isSoundEffectsEnabled ()) {
return ;
}this.mAttachInfo.mRootCallbacks.playSoundEffect (soundConstant);
}, "~N");
Clazz.defineMethod (c$, "onCloseSystemDialogs", 
function (reason) {
}, "~S");
c$.stateSetUnion = Clazz.defineMethod (c$, "stateSetUnion", 
($fz = function (stateSet1, stateSet2) {
var stateSet1Length = stateSet1.length;
var stateSet2Length = stateSet2.length;
var newSet =  Clazz.newArray (stateSet1Length + stateSet2Length, 0);
var k = 0;
var i = 0;
var j = 0;
for (var viewState, $viewState = 0, $$viewState = com.android.internal.R.styleable.ViewDrawableStates; $viewState < $$viewState.length && ((viewState = $$viewState[$viewState]) || true); $viewState++) {
if (i < stateSet1Length && stateSet1[i] == viewState) {
newSet[k++] = viewState;
i++;
} else if (j < stateSet2Length && stateSet2[j] == viewState) {
newSet[k++] = viewState;
j++;
}if (k > 1) {
}}
return newSet;
}, $fz.isPrivate = true, $fz), "~A,~A");
c$.inflate = Clazz.defineMethod (c$, "inflate", 
function (context, resource, root) {
var factory = android.view.LayoutInflater.from (context);
return factory.inflate (resource, root);
}, "android.content.Context,~N,android.view.ViewGroup");
Clazz.defineMethod (c$, "overScrollBy", 
function (deltaX, deltaY, scrollX, scrollY, scrollRangeX, scrollRangeY, maxOverScrollX, maxOverScrollY, isTouchEvent) {
var overScrollMode = this.mOverScrollMode;
var canScrollHorizontal = this.computeHorizontalScrollRange () > this.computeHorizontalScrollExtent ();
var canScrollVertical = this.computeVerticalScrollRange () > this.computeVerticalScrollExtent ();
var overScrollHorizontal = overScrollMode == 0 || (overScrollMode == 1 && canScrollHorizontal);
var overScrollVertical = overScrollMode == 0 || (overScrollMode == 1 && canScrollVertical);
var newScrollX = scrollX + deltaX;
if (!overScrollHorizontal) {
maxOverScrollX = 0;
}var newScrollY = scrollY + deltaY;
if (!overScrollVertical) {
maxOverScrollY = 0;
}var left = -maxOverScrollX;
var right = maxOverScrollX + scrollRangeX;
var top = -maxOverScrollY;
var bottom = maxOverScrollY + scrollRangeY;
var clampedX = false;
if (newScrollX > right) {
newScrollX = right;
clampedX = true;
} else if (newScrollX < left) {
newScrollX = left;
clampedX = true;
}var clampedY = false;
if (newScrollY > bottom) {
newScrollY = bottom;
clampedY = true;
} else if (newScrollY < top) {
newScrollY = top;
clampedY = true;
}this.onOverScrolled (newScrollX, newScrollY, clampedX, clampedY);
return clampedX || clampedY;
}, "~N,~N,~N,~N,~N,~N,~N,~N,~B");
Clazz.defineMethod (c$, "onOverScrolled", 
function (scrollX, scrollY, clampedX, clampedY) {
}, "~N,~N,~B,~B");
Clazz.defineMethod (c$, "getOverScrollMode", 
function () {
return this.mOverScrollMode;
});
Clazz.defineMethod (c$, "setOverScrollMode", 
function (overScrollMode) {
if (overScrollMode != 0 && overScrollMode != 1 && overScrollMode != 2) {
throw  new IllegalArgumentException ("Invalid overscroll mode " + overScrollMode);
}this.mOverScrollMode = overScrollMode;
}, "~N");
Clazz.defineMethod (c$, "getUIElementID", 
function () {
return this.mUIElementID;
});
c$.getAnElementID = Clazz.defineMethod (c$, "getAnElementID", 
($fz = function () {
if (null == android.view.View.sUIElementsID)
{
android.view.View.sUIElementsID = 0;
}
return ($t$ = android.view.View.sUIElementsID ++, android.view.View.prototype.sUIElementsID = android.view.View.sUIElementsID, $t$);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "findViewByElementId", 
function (viewElementId) {
if (viewElementId < 0) {
return null;
}return this.findElementViewTraversal (viewElementId);
}, "~N");
Clazz.defineMethod (c$, "findElementViewTraversal", 
function (viewElementId) {
if (viewElementId == this.mUIElementID) {
return this;
}return null;
}, "~N");
Clazz.defineMethod (c$, "destroy", 
function () {
if (android.util.DebugUtils.DEBUG_VIEW_IN_BROWSER) {
var thisView = document.getElementById(this.mUIElementID);
if (thisView != null && thisView.parentNode != null) {
thisView.parentNode.removeChild(thisView);
}
}});
Clazz.defineMethod (c$, "dispatchDraw", 
function (canvas) {
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "verifyDrawable", 
function (who) {
return who === this.mBGDrawable;
}, "android.graphics.drawable.Drawable");
Clazz.overrideMethod (c$, "invalidateDrawable", 
function (who) {
if (this.verifyDrawable (who)) {
var dirty = who.getBounds ();
var scrollX = this.mScrollX;
var scrollY = this.mScrollY;
this.invalidate (dirty.left + scrollX, dirty.top + scrollY, dirty.right + scrollX, dirty.bottom + scrollY);
}}, "android.graphics.drawable.Drawable");
Clazz.overrideMethod (c$, "scheduleDrawable", 
function (who, what, when) {
if (this.verifyDrawable (who) && what != null) {
if (this.mAttachInfo != null) {
this.mAttachInfo.mHandler.postAtTime (what, who, when);
}}}, "android.graphics.drawable.Drawable,Runnable,~N");
Clazz.defineMethod (c$, "unscheduleDrawable", 
function (who, what) {
if (this.verifyDrawable (who) && what != null) {
if (this.mAttachInfo != null) {
this.mAttachInfo.mHandler.removeCallbacks (what, who);
}}}, "android.graphics.drawable.Drawable,Runnable");
Clazz.defineMethod (c$, "unscheduleDrawable", 
function (who) {
if (this.mAttachInfo != null) {
this.mAttachInfo.mHandler.removeCallbacksAndMessages (who);
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "drawableStateChanged", 
function () {
var d = this.mBGDrawable;
if (d != null && d.isStateful ()) {
d.setState (this.getDrawableState ());
}});
Clazz.defineMethod (c$, "scrollTo", 
function (x, y) {
if (this.mScrollX != x || this.mScrollY != y) {
var oldX = this.mScrollX;
var oldY = this.mScrollY;
this.mScrollX = x;
this.mScrollY = y;
this.onScrollChanged (this.mScrollX, this.mScrollY, oldX, oldY);
if (!this.awakenScrollBars ()) {
this.invalidate ();
}}}, "~N,~N");
Clazz.defineMethod (c$, "scrollBy", 
function (x, y) {
this.scrollTo (this.mScrollX + x, this.mScrollY + y);
}, "~N,~N");
Clazz.defineMethod (c$, "post", 
function (action) {
var handler;
if (this.mAttachInfo != null) {
handler = this.mAttachInfo.mHandler;
} else {
android.view.ViewRoot.getRunQueue ().post (action);
return true;
}return handler.post (action);
}, "Runnable");
Clazz.defineMethod (c$, "postDelayed", 
function (action, delayMillis) {
var handler;
if (this.mAttachInfo != null) {
handler = this.mAttachInfo.mHandler;
} else {
android.view.ViewRoot.getRunQueue ().postDelayed (action, delayMillis);
return true;
}return handler.postDelayed (action, delayMillis);
}, "Runnable,~N");
Clazz.defineMethod (c$, "postInvalidate", 
function () {
this.postInvalidateDelayed (0);
});
Clazz.defineMethod (c$, "postInvalidate", 
function (left, top, right, bottom) {
this.postInvalidateDelayed (0, left, top, right, bottom);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "postInvalidateDelayed", 
function (delayMilliseconds) {
if (this.mAttachInfo != null) {
var msg = android.os.Message.obtain ();
msg.what = 1;
msg.obj = this;
this.mAttachInfo.mHandler.sendMessageDelayed (msg, delayMilliseconds);
}}, "~N");
Clazz.defineMethod (c$, "postInvalidateDelayed", 
function (delayMilliseconds, left, top, right, bottom) {
if (this.mAttachInfo != null) {
var info = android.view.View.AttachInfo.InvalidateInfo.acquire ();
info.target = this;
info.left = left;
info.top = top;
info.right = right;
info.bottom = bottom;
var msg = android.os.Message.obtain ();
msg.what = 2;
msg.obj = info;
this.mAttachInfo.mHandler.sendMessageDelayed (msg, delayMilliseconds);
}}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "createContextMenu", 
function (menu) {
}, "android.view.ContextMenu");
Clazz.defineMethod (c$, "onCreateContextMenu", 
function (menu, v, menuInfo) {
console.log("Missing method: onCreateContextMenu");
}, "android.view.ContextMenu,android.view.View,android.view.ContextMenu.ContextMenuInfo");
Clazz.defineMethod (c$, "destroyDrawingCache", 
function () {
console.log("Missing method: destroyDrawingCache");
});
Clazz.defineMethod (c$, "cancelLongPress", 
function () {
console.log("Missing method: cancelLongPress");
});
Clazz.defineMethod (c$, "onFilterTouchEventForSecurity", 
function (event) {
console.log("Missing method: onFilterTouchEventForSecurity");
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "performHapticFeedback", 
function (feedbackConstant) {
console.log("Missing method: performHapticFeedback");
}, "~N");
Clazz.defineMethod (c$, "setScrollbarFadingEnabled", 
function (fadeScrollbars) {
console.log("Missing method: setScrollbarFadingEnabled");
}, "~B");
Clazz.defineMethod (c$, "isScrollbarFadingEnabled", 
function () {
console.log("Missing method: isScrollbarFadingEnabled");
});
Clazz.defineMethod (c$, "onTrackballEvent", 
function (event) {
console.log("Missing method: onTrackballEvent");
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "performHapticFeedback", 
function (feedbackConstant, flags) {
console.log("Missing method: performHapticFeedback");
}, "~N,~N");
Clazz.defineMethod (c$, "getWindowVisibility", 
function () {
console.log("Missing method: getWindowVisibility");
});
Clazz.defineMethod (c$, "buildDrawingCache", 
function () {
console.log("Missing method: buildDrawingCache");
});
Clazz.defineMethod (c$, "dispatchTrackballEvent", 
function (event) {
console.log("Missing method: dispatchTrackballEvent");
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "performHapticFeedback", 
function (effectId, always) {
console.log("Missing method: performHapticFeedback");
}, "~N,~B");
Clazz.defineMethod (c$, "buildDrawingCache", 
function (autoScale) {
console.log("Missing method: buildDrawingCache");
}, "~B");
c$.$View$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mHandler = null;
Clazz.instantialize (this, arguments);
}, android.view, "View$1", null, android.view.View.OnClickListener);
Clazz.defineMethod (c$, "onClick", 
function (v) {
if (this.mHandler == null) {
try {
this.mHandler = this.b$["android.view.View"].getContext ().getClass ().getMethod (this.f$.handlerName, [android.view.View]);
} catch (e) {
if (Clazz.instanceOf (e, NoSuchMethodException)) {
var id = this.b$["android.view.View"].getId ();
var idText = id == -1 ? "" : " with id '" + id + "'";
throw  new IllegalStateException ("Could not find a method " + this.f$.handlerName + "(View) in the activity " + this.b$["android.view.View"].getContext ().getClass () + " for onClick handler" + " on view " + this.b$["android.view.View"].getClass () + idText, e);
} else {
throw e;
}
}
}try {
this.mHandler.invoke (this.b$["android.view.View"].getContext (), [this.b$["android.view.View"]]);
} catch (e$$) {
if (Clazz.instanceOf (e$$, IllegalAccessException)) {
var e = e$$;
{
throw  new IllegalStateException ("Could not execute non public method of the activity", e);
}
} else if (Clazz.instanceOf (e$$, Exception)) {
var e = e$$;
{
throw  new IllegalStateException ("Could not execute method of the activity", e);
}
} else {
throw e$$;
}
}
}, "android.view.View");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.declareType (android.view.View, "BaseSavedState", android.view.AbsSavedState);
c$.$View$BaseSavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view, "View$BaseSavedState$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.view.View.BaseSavedState (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.$CREATOR = c$.prototype.$CREATOR = ((Clazz.isClassDefined ("android.view.View$BaseSavedState$1") ? 0 : android.view.View.BaseSavedState.$View$BaseSavedState$1$ ()), Clazz.innerTypeInstance (android.view.View$BaseSavedState$1, this, null));
c$ = Clazz.p0p ();
Clazz.declareInterface (android.view.View, "OnCreateContextMenuListener");
Clazz.pu$h ();
c$ = Clazz.declareType (android.view.View, "MeasureSpec");
c$.makeMeasureSpec = Clazz.defineMethod (c$, "makeMeasureSpec", 
function (a, b) {
return a + b;
}, "~N,~N");
c$.getMode = Clazz.defineMethod (c$, "getMode", 
function (a) {
return (a & -1073741824);
}, "~N");
c$.getSize = Clazz.defineMethod (c$, "getSize", 
function (a) {
return (a & 1073741823);
}, "~N");
c$.toString = Clazz.defineMethod (c$, "toString", 
function (a) {
var b = android.view.View.MeasureSpec.getMode (a);
var c = android.view.View.MeasureSpec.getSize (a);
var d =  new StringBuilder ("MeasureSpec: ");
if (b == 0) d.append ("UNSPECIFIED ");
 else if (b == 1073741824) d.append ("EXACTLY ");
 else if (b == -2147483648) d.append ("AT_MOST ");
 else d.append (b).append (" ");
d.append (c);
return d.toString ();
}, "~N");
Clazz.defineStatics (c$,
"MODE_SHIFT", 30,
"MODE_MASK", -1073741824,
"UNSPECIFIED", 0,
"EXACTLY", 1073741824,
"AT_MOST", -2147483648);
c$ = Clazz.p0p ();
Clazz.declareInterface (android.view.View, "OnKeyListener");
Clazz.declareInterface (android.view.View, "OnLongClickListener");
Clazz.declareInterface (android.view.View, "OnFocusChangeListener");
Clazz.declareInterface (android.view.View, "OnClickListener");
Clazz.declareInterface (android.view.View, "OnTouchListener");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.fadeScrollBars = false;
this.fadingEdgeLength = 0;
this.scrollBarDefaultDelayBeforeFade = 0;
this.scrollBarFadeDuration = 0;
this.scrollBarSize = 0;
this.scrollBar = null;
this.interpolatorValues = null;
this.host = null;
this.paint = null;
this.matrix = null;
this.mOpaque = null;
this.mTransparent = null;
this.fadeStartTime = 0;
this.state = 0;
this.mLastColor = 0;
Clazz.instantialize (this, arguments);
}, android.view.View, "ScrollabilityCache", null, Runnable);
Clazz.prepareFields (c$, function () {
this.mOpaque = [255.0];
this.mTransparent = [0.0];
});
Clazz.makeConstructor (c$, 
function (a, b) {
this.fadingEdgeLength = a.getScaledFadingEdgeLength ();
this.scrollBarSize = a.getScaledScrollBarSize ();
this.scrollBarDefaultDelayBeforeFade = android.view.ViewConfiguration.getScrollDefaultDelay ();
this.scrollBarFadeDuration = android.view.ViewConfiguration.getScrollBarFadeDuration ();
this.paint =  new android.graphics.Paint ();
this.matrix =  new android.graphics.Matrix ();
this.host = b;
}, "android.view.ViewConfiguration,android.view.View");
Clazz.defineMethod (c$, "setFadeColor", 
function (a) {
if (a != 0 && a != this.mLastColor) {
this.mLastColor = a;
a |= 0xFF000000;
}}, "~N");
Clazz.overrideMethod (c$, "run", 
function () {
var a = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
if (a >= this.fadeStartTime) {
var b = a;
var c = 0;
this.state = 2;
this.host.invalidate ();
}});
Clazz.defineStatics (c$,
"OFF", 0,
"ON", 1,
"FADING", 2);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mWindow = null;
this.mRootCallbacks = null;
this.mRootView = null;
this.mApplicationScale = 0;
this.mScalingRequired = false;
this.mWindowLeft = 0;
this.mWindowTop = 0;
this.mUse32BitDrawingCache = false;
this.mContentInsets = null;
this.mVisibleInsets = null;
this.mGivenInternalInsets = null;
this.mScrollContainers = null;
this.mKeyDispatchState = null;
this.mHasWindowFocus = false;
this.mWindowVisibility = 0;
this.mDrawingTime = 0;
this.mIgnoreDirtyState = false;
this.mInTouchMode = false;
this.mRecomputeGlobalAttributes = false;
this.mKeepScreenOn = false;
this.mViewVisibilityChanged = false;
this.mViewScrollChanged = false;
this.mTransparentLocation = null;
this.mInvalidateChildLocation = null;
this.mTreeObserver = null;
this.mCanvas = null;
this.mHandler = null;
this.mTmpInvalRect = null;
this.mFocusablesTempList = null;
Clazz.instantialize (this, arguments);
}, android.view.View, "AttachInfo");
Clazz.prepareFields (c$, function () {
this.mContentInsets =  new android.graphics.Rect ();
this.mVisibleInsets =  new android.graphics.Rect ();
this.mGivenInternalInsets =  new android.view.ViewTreeObserver.InternalInsetsInfo ();
this.mScrollContainers =  new java.util.ArrayList ();
this.mKeyDispatchState =  new android.view.KeyEvent.DispatcherState ();
this.mTransparentLocation =  Clazz.newArray (2, 0);
this.mInvalidateChildLocation =  Clazz.newArray (2, 0);
this.mTreeObserver =  new android.view.ViewTreeObserver ();
this.mTmpInvalRect =  new android.graphics.Rect ();
this.mFocusablesTempList =  new java.util.ArrayList (24);
});
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.mWindow = a;
this.mHandler = b;
this.mRootCallbacks = c;
}, "android.view.Window,android.os.Handler,android.view.View.AttachInfo.Callbacks");
Clazz.declareInterface (android.view.View.AttachInfo, "Callbacks");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mNext = null;
this.target = null;
this.left = 0;
this.top = 0;
this.right = 0;
this.bottom = 0;
Clazz.instantialize (this, arguments);
}, android.view.View.AttachInfo, "InvalidateInfo");
Clazz.defineMethod (c$, "setNextPoolable", 
function (a) {
this.mNext = a;
}, "android.view.View.AttachInfo.InvalidateInfo");
Clazz.defineMethod (c$, "getNextPoolable", 
function () {
return this.mNext;
});
c$.acquire = Clazz.defineMethod (c$, "acquire", 
function () {
return  new android.view.View.AttachInfo.InvalidateInfo ();
});
Clazz.defineMethod (c$, "release", 
function () {
});
Clazz.defineStatics (c$,
"POOL_LIMIT", 10);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"INVALIDATE_MSG", 0x1,
"INVALIDATE_RECT_MSG", 0x2);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DBG", false,
"VIEW_LOG_TAG", "View",
"NO_ID", -1,
"NOT_FOCUSABLE", 0x00000000,
"FOCUSABLE", 0x00000001,
"FOCUSABLE_MASK", 0x00000001,
"FITS_SYSTEM_WINDOWS", 0x00000002,
"VISIBLE", 0x00000000,
"INVISIBLE", 0x00000004,
"GONE", 0x00000008,
"VISIBILITY_MASK", 0x0000000C,
"VISIBILITY_FLAGS", [0, 4, 8],
"ENABLED", 0x00000000,
"DISABLED", 0x00000020,
"ENABLED_MASK", 0x00000020,
"WILL_NOT_DRAW", 0x00000080,
"DRAW_MASK", 0x00000080,
"SCROLLBARS_NONE", 0x00000000,
"SCROLLBARS_HORIZONTAL", 0x00000100,
"SCROLLBARS_VERTICAL", 0x00000200,
"SCROLLBARS_MASK", 0x00000300,
"FILTER_TOUCHES_WHEN_OBSCURED", 0x00000400,
"FADING_EDGE_NONE", 0x00000000,
"FADING_EDGE_HORIZONTAL", 0x00001000,
"FADING_EDGE_VERTICAL", 0x00002000,
"FADING_EDGE_MASK", 0x00003000,
"CLICKABLE", 0x00004000,
"DRAWING_CACHE_ENABLED", 0x00008000,
"SAVE_DISABLED", 0x000010000,
"SAVE_DISABLED_MASK", 0x000010000,
"WILL_NOT_CACHE_DRAWING", 0x000020000,
"FOCUSABLE_IN_TOUCH_MODE", 0x00040000,
"DRAWING_CACHE_QUALITY_LOW", 0x00080000,
"DRAWING_CACHE_QUALITY_HIGH", 0x00100000,
"DRAWING_CACHE_QUALITY_AUTO", 0x00000000,
"DRAWING_CACHE_QUALITY_FLAGS", [0, 524288, 1048576],
"DRAWING_CACHE_QUALITY_MASK", 0x00180000,
"LONG_CLICKABLE", 0x00200000,
"DUPLICATE_PARENT_STATE", 0x00400000,
"SCROLLBARS_INSIDE_OVERLAY", 0,
"SCROLLBARS_INSIDE_INSET", 0x01000000,
"SCROLLBARS_OUTSIDE_OVERLAY", 0x02000000,
"SCROLLBARS_OUTSIDE_INSET", 0x03000000,
"SCROLLBARS_INSET_MASK", 0x01000000,
"SCROLLBARS_OUTSIDE_MASK", 0x02000000,
"SCROLLBARS_STYLE_MASK", 0x03000000,
"KEEP_SCREEN_ON", 0x04000000,
"SOUND_EFFECTS_ENABLED", 0x08000000,
"HAPTIC_FEEDBACK_ENABLED", 0x10000000,
"FOCUSABLES_ALL", 0x00000000,
"FOCUSABLES_TOUCH_MODE", 0x00000001,
"FOCUS_BACKWARD", 0x00000001,
"FOCUS_FORWARD", 0x00000002,
"FOCUS_LEFT", 0x00000011,
"FOCUS_UP", 0x00000021,
"FOCUS_RIGHT", 0x00000042,
"FOCUS_DOWN", 0x00000082,
"EMPTY_STATE_SET", [],
"ENABLED_STATE_SET", [16842910],
"FOCUSED_STATE_SET", [16842908],
"SELECTED_STATE_SET", [16842913],
"PRESSED_STATE_SET", [16842919],
"WINDOW_FOCUSED_STATE_SET", [16842909]);
c$.ENABLED_FOCUSED_STATE_SET = c$.prototype.ENABLED_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.ENABLED_STATE_SET, android.view.View.FOCUSED_STATE_SET);
c$.ENABLED_SELECTED_STATE_SET = c$.prototype.ENABLED_SELECTED_STATE_SET = android.view.View.stateSetUnion (android.view.View.ENABLED_STATE_SET, android.view.View.SELECTED_STATE_SET);
c$.ENABLED_WINDOW_FOCUSED_STATE_SET = c$.prototype.ENABLED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.ENABLED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.FOCUSED_SELECTED_STATE_SET = c$.prototype.FOCUSED_SELECTED_STATE_SET = android.view.View.stateSetUnion (android.view.View.FOCUSED_STATE_SET, android.view.View.SELECTED_STATE_SET);
c$.FOCUSED_WINDOW_FOCUSED_STATE_SET = c$.prototype.FOCUSED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.FOCUSED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.SELECTED_WINDOW_FOCUSED_STATE_SET = c$.prototype.SELECTED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.SELECTED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.ENABLED_FOCUSED_SELECTED_STATE_SET = c$.prototype.ENABLED_FOCUSED_SELECTED_STATE_SET = android.view.View.stateSetUnion (android.view.View.ENABLED_FOCUSED_STATE_SET, android.view.View.SELECTED_STATE_SET);
c$.ENABLED_FOCUSED_WINDOW_FOCUSED_STATE_SET = c$.prototype.ENABLED_FOCUSED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.ENABLED_FOCUSED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.ENABLED_SELECTED_WINDOW_FOCUSED_STATE_SET = c$.prototype.ENABLED_SELECTED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.ENABLED_SELECTED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET = c$.prototype.FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.FOCUSED_SELECTED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.ENABLED_FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET = c$.prototype.ENABLED_FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.ENABLED_FOCUSED_SELECTED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.PRESSED_WINDOW_FOCUSED_STATE_SET = c$.prototype.PRESSED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
Clazz.defineStatics (c$,
"LAYOUT_DIRECTION_MASK", 0xC0000000);
c$.PRESSED_SELECTED_STATE_SET = c$.prototype.PRESSED_SELECTED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_STATE_SET, android.view.View.SELECTED_STATE_SET);
c$.PRESSED_SELECTED_WINDOW_FOCUSED_STATE_SET = c$.prototype.PRESSED_SELECTED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_SELECTED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.PRESSED_FOCUSED_STATE_SET = c$.prototype.PRESSED_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_STATE_SET, android.view.View.FOCUSED_STATE_SET);
c$.PRESSED_FOCUSED_WINDOW_FOCUSED_STATE_SET = c$.prototype.PRESSED_FOCUSED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_FOCUSED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.PRESSED_FOCUSED_SELECTED_STATE_SET = c$.prototype.PRESSED_FOCUSED_SELECTED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_FOCUSED_STATE_SET, android.view.View.SELECTED_STATE_SET);
c$.PRESSED_FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET = c$.prototype.PRESSED_FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_FOCUSED_SELECTED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.PRESSED_ENABLED_STATE_SET = c$.prototype.PRESSED_ENABLED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_STATE_SET, android.view.View.ENABLED_STATE_SET);
c$.PRESSED_ENABLED_WINDOW_FOCUSED_STATE_SET = c$.prototype.PRESSED_ENABLED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_ENABLED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.PRESSED_ENABLED_SELECTED_STATE_SET = c$.prototype.PRESSED_ENABLED_SELECTED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_ENABLED_STATE_SET, android.view.View.SELECTED_STATE_SET);
c$.PRESSED_ENABLED_SELECTED_WINDOW_FOCUSED_STATE_SET = c$.prototype.PRESSED_ENABLED_SELECTED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_ENABLED_SELECTED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.PRESSED_ENABLED_FOCUSED_STATE_SET = c$.prototype.PRESSED_ENABLED_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_ENABLED_STATE_SET, android.view.View.FOCUSED_STATE_SET);
c$.PRESSED_ENABLED_FOCUSED_WINDOW_FOCUSED_STATE_SET = c$.prototype.PRESSED_ENABLED_FOCUSED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_ENABLED_FOCUSED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.PRESSED_ENABLED_FOCUSED_SELECTED_STATE_SET = c$.prototype.PRESSED_ENABLED_FOCUSED_SELECTED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_ENABLED_FOCUSED_STATE_SET, android.view.View.SELECTED_STATE_SET);
c$.PRESSED_ENABLED_FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET = c$.prototype.PRESSED_ENABLED_FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET = android.view.View.stateSetUnion (android.view.View.PRESSED_ENABLED_FOCUSED_SELECTED_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET);
c$.VIEW_STATE_SETS = c$.prototype.VIEW_STATE_SETS = [android.view.View.EMPTY_STATE_SET, android.view.View.WINDOW_FOCUSED_STATE_SET, android.view.View.SELECTED_STATE_SET, android.view.View.SELECTED_WINDOW_FOCUSED_STATE_SET, android.view.View.FOCUSED_STATE_SET, android.view.View.FOCUSED_WINDOW_FOCUSED_STATE_SET, android.view.View.FOCUSED_SELECTED_STATE_SET, android.view.View.FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET, android.view.View.ENABLED_STATE_SET, android.view.View.ENABLED_WINDOW_FOCUSED_STATE_SET, android.view.View.ENABLED_SELECTED_STATE_SET, android.view.View.ENABLED_SELECTED_WINDOW_FOCUSED_STATE_SET, android.view.View.ENABLED_FOCUSED_STATE_SET, android.view.View.ENABLED_FOCUSED_WINDOW_FOCUSED_STATE_SET, android.view.View.ENABLED_FOCUSED_SELECTED_STATE_SET, android.view.View.ENABLED_FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET, android.view.View.PRESSED_STATE_SET, android.view.View.PRESSED_WINDOW_FOCUSED_STATE_SET, android.view.View.PRESSED_SELECTED_STATE_SET, android.view.View.PRESSED_SELECTED_WINDOW_FOCUSED_STATE_SET, android.view.View.PRESSED_FOCUSED_STATE_SET, android.view.View.PRESSED_FOCUSED_WINDOW_FOCUSED_STATE_SET, android.view.View.PRESSED_FOCUSED_SELECTED_STATE_SET, android.view.View.PRESSED_FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET, android.view.View.PRESSED_ENABLED_STATE_SET, android.view.View.PRESSED_ENABLED_WINDOW_FOCUSED_STATE_SET, android.view.View.PRESSED_ENABLED_SELECTED_STATE_SET, android.view.View.PRESSED_ENABLED_SELECTED_WINDOW_FOCUSED_STATE_SET, android.view.View.PRESSED_ENABLED_FOCUSED_STATE_SET, android.view.View.PRESSED_ENABLED_FOCUSED_WINDOW_FOCUSED_STATE_SET, android.view.View.PRESSED_ENABLED_FOCUSED_SELECTED_STATE_SET, android.view.View.PRESSED_ENABLED_FOCUSED_SELECTED_WINDOW_FOCUSED_STATE_SET];
Clazz.defineStatics (c$,
"LAST_STATE_SET", [16842918],
"FIRST_STATE_SET", [16842916],
"MIDDLE_STATE_SET", [16842917],
"SINGLE_STATE_SET", [16842915],
"PRESSED_LAST_STATE_SET", [16842918, 16842919],
"PRESSED_FIRST_STATE_SET", [16842916, 16842919],
"PRESSED_MIDDLE_STATE_SET", [16842917, 16842919],
"PRESSED_SINGLE_STATE_SET", [16842915, 16842919]);
c$.sThreadLocal = c$.prototype.sThreadLocal =  new android.graphics.Rect ();
Clazz.defineStatics (c$,
"sTags", null);
c$.sTagsLock = c$.prototype.sTagsLock =  new JavaObject ();
Clazz.defineStatics (c$,
"WANTS_FOCUS", 0x00000001,
"FOCUSED", 0x00000002,
"SELECTED", 0x00000004,
"IS_ROOT_NAMESPACE", 0x00000008,
"HAS_BOUNDS", 0x00000010,
"DRAWN", 0x00000020,
"DRAW_ANIMATION", 0x00000040,
"SKIP_DRAW", 0x00000080,
"ONLY_DRAWS_BACKGROUND", 0x00000100,
"REQUEST_TRANSPARENT_REGIONS", 0x00000200,
"DRAWABLE_STATE_DIRTY", 0x00000400,
"MEASURED_DIMENSION_SET", 0x00000800,
"FORCE_LAYOUT", 0x00001000,
"LAYOUT_REQUIRED", 0x00002000,
"PRESSED", 0x00004000,
"PREPRESSED", 0x02000000,
"DRAWING_CACHE_VALID", 0x00008000,
"ANIMATION_STARTED", 0x00010000,
"SAVE_STATE_CALLED", 0x00020000,
"ALPHA_SET", 0x00040000,
"SCROLL_CONTAINER", 0x00080000,
"SCROLL_CONTAINER_ADDED", 0x00100000,
"DIRTY", 0x00200000,
"DIRTY_OPAQUE", 0x00400000,
"DIRTY_MASK", 0x00600000,
"OPAQUE_BACKGROUND", 0x00800000,
"OPAQUE_SCROLLBARS", 0x01000000,
"OPAQUE_MASK", 0x01800000,
"CANCEL_NEXT_UP_EVENT", 0x04000000,
"LAYOUT_DIRECTION_LTR", 0x00000000,
"LAYOUT_DIRECTION_RTL", 0x40000000,
"LAYOUT_DIRECTION_LOCALE", 0xC0000000,
"AWAKEN_SCROLL_BARS_ON_ATTACH", 0x08000000,
"OVER_SCROLL_ALWAYS", 0,
"OVER_SCROLL_IF_CONTENT_SCROLLS", 1,
"OVER_SCROLL_NEVER", 2,
"LAYOUT_DIRECTION_RESOLVED_RTL", 0x00000004,
"LAYOUT_DIRECTION_RESOLVED", 0x00000008,
"LAYOUT_DIRECTION_INHERIT", 0x80000000,
"TEXT_DIRECTION_INHERIT", 0,
"sUIElementsID", 0);
});
