﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.os.Parcelable", "android.view.WindowManager", "android.widget.FrameLayout", "com.android.internal.view.menu.MenuBuilder", "android.graphics.Rect", "android.os.Parcelable.Creator"], "android.view.Window", ["android.content.Context", "$.Intent", "android.graphics.drawable.Drawable", "android.os.Bundle", "android.util.DebugUtils", "$.Log", "$.SparseArray", "android.view.LayoutInflater", "$.ViewGroup", "$.WindowManagerImpl", "com.android.internal.R", "com.android.internal.view.menu.MenuDialogHelper", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mContentParent = null;
this.mLayoutInflater = null;
this.mContext = null;
this.mTitle = null;
this.mTitleColor = 0;
this.mContextMenu = null;
this.mBackgroundResource = 0;
this.mBackgroundDrawable = null;
this.mFrameResource = 0;
this.mTextColor = 0;
this.mWindowStyle = null;
this.mCallback = null;
this.mIsActive = false;
this.mWindowAttributes = null;
this.mDecor = null;
this.mIsFloating = false;
this.mPanels = null;
this.mDrawables = null;
this.mLeftIconView = null;
this.mRightIconView = null;
this.mFeatures = 577;
this.mLocalFeatures = 577;
this.mContextMenuHelper = null;
if (!Clazz.isClassDefined ("android.view.Window.DecorView")) {
android.view.Window.$Window$DecorView$ ();
}
this.mPreparedPanel = null;
this.mAppToken = null;
this.mAppName = null;
this.mWindowManager = null;
this.mContainer = null;
this.mHasChildren = false;
if (!Clazz.isClassDefined ("android.view.Window.LocalWindowManager")) {
android.view.Window.$Window$LocalWindowManager$ ();
}
this.mForcedWindowFlags = 0;
if (!Clazz.isClassDefined ("android.view.Window.ContextMenuCallback")) {
android.view.Window.$Window$ContextMenuCallback$ ();
}
Clazz.instantialize (this, arguments);
}, android.view, "Window", null, com.android.internal.view.menu.MenuBuilder.Callback);
Clazz.prepareFields (c$, function () {
this.mWindowAttributes =  new android.view.WindowManager.LayoutParams ();
});
Clazz.defineMethod (c$, "getForcedWindowFlags", 
function () {
return this.mForcedWindowFlags;
});
Clazz.defineMethod (c$, "getDecorView", 
function () {
if (this.mDecor == null) {
this.installDecor ();
}return this.mDecor;
});
Clazz.defineMethod (c$, "isActive", 
function () {
return this.mIsActive;
});
Clazz.defineMethod (c$, "findViewById", 
function (id) {
return this.getDecorView ().findViewById (id);
}, "~N");
Clazz.defineMethod (c$, "setCallback", 
function (callback) {
this.mCallback = callback;
}, "android.view.Window.Callback");
Clazz.defineMethod (c$, "getCallback", 
function () {
return this.mCallback;
});
Clazz.defineMethod (c$, "setContentView", 
function (layoutResID) {
if (this.mContentParent == null) {
this.installDecor ();
} else {
this.mContentParent.removeAllViews ();
}this.mLayoutInflater.inflate (layoutResID, this.mContentParent);
var cb = this.getCallback ();
if (cb != null) {
cb.onContentChanged ();
}}, "~N");
Clazz.defineMethod (c$, "setContentView", 
function (view) {
this.setContentView (view,  new android.view.ViewGroup.LayoutParams (-1, -1));
}, "android.view.View");
Clazz.defineMethod (c$, "setContentView", 
function (view, params) {
if (this.mContentParent == null) {
this.installDecor ();
} else {
this.mContentParent.removeAllViews ();
}this.mContentParent.addView (view, params);
var cb = this.getCallback ();
if (cb != null) {
cb.onContentChanged ();
}}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addContentView", 
function (view, params) {
if (this.mContentParent == null) {
this.installDecor ();
}this.mContentParent.addView (view, params);
var cb = this.getCallback ();
if (cb != null) {
cb.onContentChanged ();
}}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "getCurrentFocus", 
function () {
return this.mDecor != null ? this.mDecor.findFocus () : null;
});
Clazz.defineMethod (c$, "getLayoutInflater", 
function () {
return this.mLayoutInflater;
});
Clazz.defineMethod (c$, "setTitle", 
function (title) {
var tmp = title.toString ();
document.title = tmp;
this.mTitle = title;
}, "CharSequence");
Clazz.defineMethod (c$, "setTitleColor", 
function (textColor) {
this.mTitleColor = textColor;
}, "~N");
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.defineMethod (c$, "getWindowStyle", 
function () {
{
if (this.mWindowStyle == null) {
this.mWindowStyle = this.mContext.obtainStyledAttributes (com.android.internal.R.styleable.Window);
}return this.mWindowStyle;
}});
Clazz.defineMethod (c$, "generateDecor", 
function () {
return Clazz.innerTypeInstance (android.view.Window.DecorView, this, null, this.getContext ());
});
Clazz.defineMethod (c$, "generateDecor", 
function (ctx) {
return Clazz.innerTypeInstance (android.view.Window.DecorView, this, null, ctx);
}, "android.content.Context");
Clazz.defineMethod (c$, "installDecor", 
($fz = function () {
if (this.mDecor == null) {
this.mDecor = this.generateDecor ();
this.mDecor.setDescendantFocusability (262144);
this.mDecor.setIsRootNamespace (true);
}if (this.mContentParent == null) {
this.mContentParent = this.generateLayout (this.mDecor);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "generateLayout", 
function (decor) {
var a = this.getWindowStyle ();
if (false) {
System.out.println ("From style:");
var s = "Attrs:";
for (var i = 0; i < com.android.internal.R.styleable.Window.length; i++) {
s = s + " " + Integer.toHexString (com.android.internal.R.styleable.Window[i]) + "=" + a.getString (i);
}
System.out.println (s);
}this.mIsFloating = a.getBoolean (4, false);
var flagsToUpdate = (65792) & (~this.getForcedWindowFlags ());
if (this.mIsFloating) {
this.setLayout (-2, -2);
this.setFlags (0, flagsToUpdate);
} else {
this.setFlags (65792, flagsToUpdate);
}if (a.getBoolean (3, false)) {
this.requestFeature (1);
}if (a.getBoolean (9, false)) {
this.setFlags (1024, 1024 & (~this.getForcedWindowFlags ()));
}if (a.getBoolean (14, false)) {
this.setFlags (1048576, 1048576 & (~this.getForcedWindowFlags ()));
}var params = this.getAttributes ();
if (a.getBoolean (11, this.mIsFloating)) {
if ((this.getForcedWindowFlags () & 2) == 0) {
params.flags |= 2;
}params.dimAmount = a.getFloat (0, 0.5);
}if (params.windowAnimations == 0) {
params.windowAnimations = a.getResourceId (8, 0);
}if (this.getContainer () == null) {
if (this.mBackgroundDrawable == null) {
if (this.mBackgroundResource == 0) {
this.mBackgroundResource = a.getResourceId (1, 0);
}if (this.mFrameResource == 0) {
this.mFrameResource = a.getResourceId (2, 0);
}if (false) {
System.out.println ("Background: " + Integer.toHexString (this.mBackgroundResource) + " Frame: ");
}}this.mTextColor = a.getColor (7, 0xFF000000);
}this.requestFeature (1);
var features = this.getLocalFeatures ();
var layoutResource = 17367127;
if ((features & (24)) != 0) {
if (this.mIsFloating) {
layoutResource = 17367075;
} else {
layoutResource = 17367130;
}} else if ((features & (36)) != 0) {
layoutResource = 17367126;
} else if ((features & (128)) != 0) {
if (this.mIsFloating) {
layoutResource = 17367073;
} else {
layoutResource = 17367125;
}} else if ((features & (2)) == 0) {
if (this.mIsFloating) {
layoutResource = 17367074;
} else {
layoutResource = 17367129;
}} else if ((features & (512)) != 0) {
if (this.mIsFloating) {
layoutResource = 17367127;
} else {
layoutResource = 17367128;
}} else {
layoutResource = 17367127;
}var $in = (android.content.Context.getSystemContext ().getSystemService ("layout_inflater")).inflate (layoutResource, null);
decor.addView ($in,  new android.view.ViewGroup.LayoutParams (-1, -1));
var contentParent = this.findViewById (16908290);
if (contentParent == null) {
throw  new RuntimeException ("Window couldn't find content container view");
}if (this.getContainer () == null) {
var drawable = this.mBackgroundDrawable;
if (this.mBackgroundResource != 0) {
drawable = this.getContext ().getResources ().getDrawable (this.mBackgroundResource);
}this.mDecor.setWindowBackground (drawable);
drawable = null;
if (this.mFrameResource != 0) {
drawable = this.getContext ().getResources ().getDrawable (this.mFrameResource);
}this.mDecor.setWindowFrame (drawable);
if (this.mTitleColor == 0) {
this.mTitleColor = this.mTextColor;
}if (this.mTitle != null) {
this.setTitle (this.mTitle);
}this.setTitleColor (this.mTitleColor);
}return contentParent;
}, "android.view.Window.DecorView");
Clazz.defineMethod (c$, "loadImageURI", 
($fz = function (uri) {
try {
return android.graphics.drawable.Drawable.createFromStream (this.getContext ().getContentResolver ().openInputStream (uri), null);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.w ("PhoneWindow", "Unable to open content: " + uri);
} else {
throw e;
}
}
return null;
}, $fz.isPrivate = true, $fz), "android.net.Uri");
Clazz.defineMethod (c$, "getDrawableState", 
($fz = function (featureId, required) {
if ((this.getFeatures () & (1 << featureId)) == 0) {
if (!required) {
return null;
}throw  new RuntimeException ("The feature has not been requested");
}var ar;
if ((ar = this.mDrawables) == null || ar.length <= featureId) {
var nar =  new Array (featureId + 1);
if (ar != null) {
System.arraycopy (ar, 0, nar, 0, ar.length);
}this.mDrawables = ar = nar;
}var st = ar[featureId];
if (st == null) {
ar[featureId] = st =  new android.view.Window.DrawableFeatureState (featureId);
}return st;
}, $fz.isPrivate = true, $fz), "~N,~B");
Clazz.defineMethod (c$, "saveHierarchyState", 
function () {
var outState =  new android.os.Bundle ();
if (this.mContentParent == null) {
return outState;
}var states =  new android.util.SparseArray ();
this.mContentParent.saveHierarchyState (states);
outState.putSparseParcelableArray ("android:views", states);
var focusedView = this.mContentParent.findFocus ();
if (focusedView != null) {
if (focusedView.getId () != -1) {
outState.putInt ("android:focusedViewId", focusedView.getId ());
} else {
if (true) {
android.util.Log.d ("PhoneWindow", "couldn't save which view has focus because the focused view " + focusedView + " has no id.");
}}}var panelStates =  new android.util.SparseArray ();
this.savePanelState (panelStates);
if (panelStates.size () > 0) {
outState.putSparseParcelableArray ("android:Panels", panelStates);
}return outState;
});
Clazz.defineMethod (c$, "restoreHierarchyState", 
function (savedInstanceState) {
if (this.mContentParent == null) {
return ;
}var savedStates = savedInstanceState.getSparseParcelableArray ("android:views");
if (savedStates != null) {
this.mContentParent.restoreHierarchyState (savedStates);
}var focusedViewId = savedInstanceState.getInt ("android:focusedViewId", -1);
if (focusedViewId != -1) {
var needsFocus = this.mContentParent.findViewById (focusedViewId);
if (needsFocus != null) {
needsFocus.requestFocus ();
} else {
android.util.Log.w ("PhoneWindow", "Previously focused view reported id " + focusedViewId + " during save, but can't be found during restore.");
}}var panelStates = savedInstanceState.getSparseParcelableArray ("android:Panels");
if (panelStates != null) {
this.restorePanelState (panelStates);
}}, "android.os.Bundle");
Clazz.defineMethod (c$, "savePanelState", 
($fz = function (icicles) {
var panels = this.mPanels;
if (panels == null) {
return ;
}for (var curFeatureId = panels.length - 1; curFeatureId >= 0; curFeatureId--) {
if (panels[curFeatureId] != null) {
icicles.put (curFeatureId, panels[curFeatureId].onSaveInstanceState ());
}}
}, $fz.isPrivate = true, $fz), "android.util.SparseArray");
Clazz.defineMethod (c$, "restorePanelState", 
($fz = function (icicles) {
var st;
for (var curFeatureId = icicles.size () - 1; curFeatureId >= 0; curFeatureId--) {
st = this.getPanelState (curFeatureId, false);
if (st == null) {
continue ;}st.onRestoreInstanceState (icicles.get (curFeatureId));
}
}, $fz.isPrivate = true, $fz), "android.util.SparseArray");
Clazz.defineMethod (c$, "onKeyDown", 
function (featureId, keyCode, event) {
var dispatcher = this.mDecor != null ? this.mDecor.getKeyDispatcherState () : null;
switch (keyCode) {
case 24:
case 25:
{
return true;
}case 85:
case 91:
case 79:
case 86:
case 87:
case 88:
case 89:
case 90:
{
var intent =  new android.content.Intent ("android.intent.action.MEDIA_BUTTON", null);
intent.putExtra ("android.intent.extra.KEY_EVENT", event);
this.getContext ().sendOrderedBroadcast (intent, null);
return true;
}case 27:
{
return true;
}case 118:
{
this.onKeyDownPanel ((featureId < 0) ? 0 : featureId, event);
return true;
}case 115:
{
if (event.getRepeatCount () > 0) break;
if (featureId < 0) break;
dispatcher.startTracking (event, this);
return true;
}case 5:
{
return true;
}case 84:
{
}}
return false;
}, "~N,~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyUp", 
function (featureId, keyCode, event) {
var dispatcher = this.mDecor != null ? this.mDecor.getKeyDispatcherState () : null;
if (dispatcher != null) {
dispatcher.handleUpEvent (event);
}switch (keyCode) {
case 24:
case 25:
{
return true;
}case 118:
{
this.onKeyUpPanel (featureId < 0 ? 0 : featureId, event);
return true;
}case 115:
{
if (featureId < 0) break;
if (event.isTracking () && !event.isCanceled ()) {
if (featureId == 0) {
var st = this.getPanelState (featureId, false);
if (st != null && st.isInExpandedMode) {
this.reopenMenu (true);
return true;
}}this.closePanel (featureId);
return true;
}break;
}case 79:
case 85:
case 86:
case 87:
case 88:
case 89:
case 90:
{
var intent =  new android.content.Intent ("android.intent.action.MEDIA_BUTTON", null);
intent.putExtra ("android.intent.extra.KEY_EVENT", event);
this.getContext ().sendOrderedBroadcast (intent, null);
return true;
}case 27:
{
if (event.isTracking () && !event.isCanceled ()) {
}return true;
}case 5:
{
return true;
}case 84:
{
return true;
}}
return false;
}, "~N,~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyUpPanel", 
($fz = function (featureId, event) {
if (event.isCanceled ()) {
return ;
}var st = this.getPanelState (featureId, true);
if (st.isOpen || st.isHandled) {
this.closePanel (st, true);
} else if (st.isPrepared) {
this.openPanel (st, event);
}}, $fz.isPrivate = true, $fz), "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "closePanel", 
function (featureId) {
if (featureId == 6) {
this.closeContextMenu ();
} else {
this.closePanel (this.getPanelState (featureId, true), true);
}}, "~N");
Clazz.defineMethod (c$, "closeContextMenu", 
($fz = function () {
if (this.mContextMenu != null) {
this.mContextMenu.close ();
this.dismissContextMenu ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "dismissContextMenu", 
($fz = function () {
this.mContextMenu = null;
if (this.mContextMenuHelper != null) {
this.mContextMenuHelper.dismiss ();
this.mContextMenuHelper = null;
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "reopenMenu", 
($fz = function (toggleMenuMode) {
var st = this.getPanelState (0, true);
var newExpandedMode = toggleMenuMode ? !st.isInExpandedMode : st.isInExpandedMode;
st.refreshDecorView = true;
this.closePanel (st, false);
st.isInExpandedMode = newExpandedMode;
this.openPanel (st, null);
}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "superDispatchKeyEvent", 
function (event) {
return this.mDecor.superDispatchKeyEvent (event);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "superDispatchTouchEvent", 
function (event) {
return this.mDecor.superDispatchTouchEvent (event);
}, "android.view.MotionEvent");
Clazz.makeConstructor (c$, 
function (context) {
this.mContext = context;
this.mLayoutInflater = android.view.LayoutInflater.from (context);
}, "android.content.Context");
Clazz.defineMethod (c$, "findViewByElementId", 
function (viewElementId) {
return this.getDecorView ().findViewByElementId (viewElementId);
}, "~N");
Clazz.defineMethod (c$, "togglePanel", 
function (featureId, event) {
var st = this.getPanelState (featureId, true);
if (st.isOpen) {
this.closePanel (st, true);
} else {
this.openPanel (st, event);
}}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "openPanel", 
function (featureId, event) {
this.openPanel (this.getPanelState (featureId, true), event);
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "openPanel", 
($fz = function (st, event) {
if (st.isOpen) {
return ;
}var cb = this.getCallback ();
if ((cb != null) && (!cb.onMenuOpened (st.featureId, st.menu))) {
this.closePanel (st, true);
return ;
}var wm = this.getWindowManager ();
if (wm == null) {
return ;
}if (!this.preparePanel (st, event)) {
return ;
}if (st.decorView == null || st.refreshDecorView) {
if (st.decorView == null) {
if (!this.initializePanelDecor (st) || (st.decorView == null)) return ;
} else if (st.refreshDecorView && (st.decorView.getChildCount () > 0)) {
st.decorView.removeAllViews ();
}if (!this.initializePanelContent (st) || (st.shownPanelView == null)) {
return ;
}var lp = st.shownPanelView.getLayoutParams ();
if (lp == null) {
lp =  new android.view.ViewGroup.LayoutParams (-2, -2);
}var backgroundResId;
if (lp.width == -1) {
backgroundResId = st.fullBackground;
} else {
backgroundResId = st.background;
}st.decorView.setWindowBackground (this.getContext ().getResources ().getDrawable (backgroundResId));
st.decorView.addView (st.shownPanelView, lp);
if (!st.shownPanelView.hasFocus ()) {
st.shownPanelView.requestFocus ();
}}st.isOpen = true;
st.isHandled = false;
var lp =  new android.view.WindowManager.LayoutParams (-2, -2, st.x, st.y, 1003, 135168, st.decorView.mDefaultOpacity);
lp.gravity = st.gravity;
lp.windowAnimations = st.windowAnimations;
wm.addView (st.decorView, lp);
}, $fz.isPrivate = true, $fz), "android.view.Window.PanelFeatureState,android.view.KeyEvent");
Clazz.defineMethod (c$, "initializePanelDecor", 
($fz = function (st) {
st.decorView = Clazz.innerTypeInstance (android.view.Window.DecorView, this, null, this.getContext (), st.featureId);
st.gravity = 81;
st.setStyle (this.getContext ());
this.mDecor.addView (st.decorView, true);
return true;
}, $fz.isPrivate = true, $fz), "android.view.Window.PanelFeatureState");
Clazz.defineMethod (c$, "closePanel", 
($fz = function (st, doCallback) {
var wm = this.getWindowManager ();
if ((wm != null) && st.isOpen) {
if (st.decorView != null) {
st.decorView.removeView (st.shownPanelView);
this.mDecor.removeView (st.decorView);
wm.removeView (st.decorView);
st.decorView = null;
}if (doCallback) {
this.callOnPanelClosed (st.featureId, st, null);
}}st.isOpen = false;
st.isPrepared = false;
st.isHandled = false;
st.shownPanelView = null;
if (st.isInExpandedMode) {
st.refreshDecorView = true;
st.isInExpandedMode = false;
}if (this.mPreparedPanel === st) {
this.mPreparedPanel = null;
}}, $fz.isPrivate = true, $fz), "android.view.Window.PanelFeatureState,~B");
Clazz.defineMethod (c$, "callOnPanelClosed", 
($fz = function (featureId, panel, menu) {
var cb = this.getCallback ();
if (cb == null) return ;
if (menu == null) {
if (panel == null) {
if ((featureId >= 0) && (featureId < this.mPanels.length)) {
panel = this.mPanels[featureId];
}}if (panel != null) {
menu = panel.menu;
}}if ((panel != null) && (!panel.isOpen)) return ;
cb.onPanelClosed (featureId, menu);
}, $fz.isPrivate = true, $fz), "~N,android.view.Window.PanelFeatureState,com.android.internal.view.menu.MenuBuilder");
Clazz.defineMethod (c$, "rSetViewGone", 
($fz = function (v) {
v.setVisibility (8);
if (Clazz.instanceOf (v, android.view.ViewGroup)) {
var vg = v;
var tmp = null;
for (var i = 0; i < vg.getChildCount (); ++i) {
tmp = vg.getChildAt (i);
this.rSetViewGone (tmp);
}
}}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "closeAllPanels", 
function () {
var wm = this.getWindowManager ();
if (wm == null) {
return ;
}var panels = this.mPanels;
var N = panels != null ? panels.length : 0;
for (var i = 0; i < N; i++) {
var panel = panels[i];
if (panel != null) {
this.closePanel (panel, true);
}}
});
Clazz.defineMethod (c$, "initializePanelContent", 
($fz = function (st) {
if (st.createdPanelView != null) {
st.shownPanelView = st.createdPanelView;
return true;
}var menu = st.menu;
if (menu == null) {
return false;
}st.shownPanelView = menu.getMenuView ((st.isInExpandedMode) ? 1 : 0, st.decorView);
if (st.shownPanelView != null) {
var defaultAnimations = (st.shownPanelView).getWindowAnimations ();
if (defaultAnimations != 0) {
st.windowAnimations = defaultAnimations;
}return true;
} else {
return false;
}}, $fz.isPrivate = true, $fz), "android.view.Window.PanelFeatureState");
Clazz.defineMethod (c$, "preparePanel", 
($fz = function (st, event) {
if (st.isPrepared) return true;
if ((this.mPreparedPanel != null) && (this.mPreparedPanel !== st)) {
this.closePanel (this.mPreparedPanel, false);
}var cb = this.getCallback ();
if (cb != null) {
st.createdPanelView = cb.onCreatePanelView (st.featureId);
}if (st.createdPanelView == null) {
if (st.menu == null) {
if (!this.initializePanelMenu (st) || (st.menu == null)) {
return false;
}if ((cb == null) || !cb.onCreatePanelMenu (st.featureId, st.menu)) {
st.menu = null;
return false;
}}if (!cb.onPreparePanel (st.featureId, st.createdPanelView, st.menu)) {
return false;
}}st.isPrepared = true;
st.isHandled = false;
this.mPreparedPanel = st;
return true;
}, $fz.isPrivate = true, $fz), "android.view.Window.PanelFeatureState,android.view.KeyEvent");
Clazz.defineMethod (c$, "requestFeature", 
function (featureId) {
var flag = 1 << featureId;
this.mFeatures |= flag;
this.mLocalFeatures |= this.mContainer != null ? (flag & ~this.mContainer.mFeatures) : flag;
return (this.mFeatures & flag) != 0;
}, "~N");
Clazz.defineMethod (c$, "initializePanelMenu", 
($fz = function (st) {
var menu =  new com.android.internal.view.menu.MenuBuilder (this.getContext ());
menu.setCallback (this);
st.setMenu (menu);
return true;
}, $fz.isPrivate = true, $fz), "android.view.Window.PanelFeatureState");
Clazz.defineMethod (c$, "setBackgroundDrawable", 
function (drawable) {
if (drawable !== this.mBackgroundDrawable || this.mBackgroundResource != 0) {
this.mBackgroundResource = 0;
this.mBackgroundDrawable = drawable;
if (this.mDecor != null) {
this.mDecor.setWindowBackground (drawable);
}}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setFeatureDrawableResource", 
function (featureId, resId) {
if (resId != 0) {
var st = this.getDrawableState (featureId, true);
if (st.resid != resId) {
st.resid = resId;
st.uri = null;
st.local = this.getContext ().getResources ().getDrawable (resId);
this.updateDrawable (featureId, st, false);
}} else {
this.setFeatureDrawable (featureId, null);
}}, "~N,~N");
Clazz.defineMethod (c$, "setFeatureDrawableUri", 
function (featureId, uri) {
if (uri != null) {
var st = this.getDrawableState (featureId, true);
if (st.uri == null || !st.uri.equals (uri)) {
st.resid = 0;
st.uri = uri;
st.local = this.loadImageURI (uri);
this.updateDrawable (featureId, st, false);
}} else {
this.setFeatureDrawable (featureId, null);
}}, "~N,android.net.Uri");
Clazz.defineMethod (c$, "setFeatureDrawable", 
function (featureId, drawable) {
var st = this.getDrawableState (featureId, true);
st.resid = 0;
st.uri = null;
if (st.local !== drawable) {
st.local = drawable;
this.updateDrawable (featureId, st, false);
}}, "~N,android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setFeatureDrawableAlpha", 
function (featureId, alpha) {
var st = this.getDrawableState (featureId, true);
if (st.alpha != alpha) {
st.alpha = alpha;
this.updateDrawable (featureId, st, false);
}}, "~N,~N");
Clazz.defineMethod (c$, "setFeatureDefaultDrawable", 
function (featureId, drawable) {
var st = this.getDrawableState (featureId, true);
if (st.def !== drawable) {
st.def = drawable;
this.updateDrawable (featureId, st, false);
}}, "~N,android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setFeatureInt", 
function (featureId, value) {
this.updateInt (featureId, value, false);
}, "~N,~N");
Clazz.defineMethod (c$, "setChildDrawable", 
function (featureId, drawable) {
var st = this.getDrawableState (featureId, true);
st.child = drawable;
this.updateDrawable (featureId, st, false);
}, "~N,android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setChildInt", 
function (featureId, value) {
this.updateInt (featureId, value, false);
}, "~N,~N");
Clazz.defineMethod (c$, "updateDrawable", 
function (featureId, fromActive) {
var st = this.getDrawableState (featureId, false);
if (st != null) {
this.updateDrawable (featureId, st, fromActive);
}}, "~N,~B");
Clazz.defineMethod (c$, "onDrawableChanged", 
function (featureId, drawable, alpha) {
var view;
if (featureId == 3) {
view = this.getLeftIconView ();
} else if (featureId == 4) {
view = this.getRightIconView ();
} else {
return ;
}if (drawable != null) {
drawable.setAlpha (alpha);
view.setImageDrawable (drawable);
view.setVisibility (0);
} else {
view.setVisibility (8);
}}, "~N,android.graphics.drawable.Drawable,~N");
Clazz.defineMethod (c$, "getPanelState", 
($fz = function (featureId, required) {
return this.getPanelState (featureId, required, null);
}, $fz.isPrivate = true, $fz), "~N,~B");
Clazz.defineMethod (c$, "getPanelState", 
($fz = function (featureId, required, convertPanelState) {
if ((this.getFeatures () & (1 << featureId)) == 0) {
if (!required) {
return null;
}throw  new RuntimeException ("The feature has not been requested");
}var ar;
if ((ar = this.mPanels) == null || ar.length <= featureId) {
var nar =  new Array (featureId + 1);
if (ar != null) {
System.arraycopy (ar, 0, nar, 0, ar.length);
}this.mPanels = ar = nar;
}var st = ar[featureId];
if (st == null) {
ar[featureId] = st = (convertPanelState != null) ? convertPanelState :  new android.view.Window.PanelFeatureState (featureId);
}return st;
}, $fz.isPrivate = true, $fz), "~N,~B,android.view.Window.PanelFeatureState");
Clazz.defineMethod (c$, "getFeatures", 
function () {
return this.mFeatures;
});
Clazz.defineMethod (c$, "getLocalFeatures", 
function () {
return this.mLocalFeatures;
});
Clazz.defineMethod (c$, "removeBackKeyInLocalFeature", 
function () {
var features = this.getLocalFeatures ();
if ((features & (512)) != 0) {
this.mLocalFeatures = features ^ (512);
}});
Clazz.defineMethod (c$, "updateDrawable", 
($fz = function (featureId, st, fromResume) {
if (this.mContentParent == null) {
return ;
}var featureMask = 1 << featureId;
if ((this.getFeatures () & featureMask) == 0 && !fromResume) {
return ;
}var drawable = null;
if (st != null) {
drawable = st.child;
if (drawable == null) drawable = st.local;
if (drawable == null) drawable = st.def;
}if ((this.getLocalFeatures () & featureMask) == 0) {
if (this.getContainer () != null) {
if (this.isActive () || fromResume) {
this.getContainer ().setChildDrawable (featureId, drawable);
}}} else if (st != null && (st.cur !== drawable || st.curAlpha != st.alpha)) {
st.cur = drawable;
st.curAlpha = st.alpha;
this.onDrawableChanged (featureId, drawable, st.alpha);
}}, $fz.isPrivate = true, $fz), "~N,android.view.Window.DrawableFeatureState,~B");
Clazz.defineMethod (c$, "getLeftIconView", 
($fz = function () {
if (this.mLeftIconView != null) {
return this.mLeftIconView;
}if (this.mContentParent == null) {
this.installDecor ();
}return (this.mLeftIconView = this.findViewById (16908661));
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getRightIconView", 
($fz = function () {
if (this.mRightIconView != null) {
return this.mRightIconView;
}if (this.mContentParent == null) {
this.installDecor ();
}return (this.mRightIconView = this.findViewById (16908663));
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "onMenuItemSelected", 
function (menu, item) {
var cb = this.getCallback ();
if (cb != null) {
var panel = this.findMenuPanel (menu.getRootMenu ());
if (panel != null) {
var retVal = cb.onMenuItemSelected (panel.featureId, item);
this.closePanel (this.getPanelState (panel.featureId, true), true);
return retVal;
}}return false;
}, "com.android.internal.view.menu.MenuBuilder,com.android.internal.view.menu.MenuItemImpl");
Clazz.defineMethod (c$, "findMenuPanel", 
function (menu) {
var panels = this.mPanels;
var N = panels != null ? panels.length : 0;
for (var i = 0; i < N; i++) {
var panel = panels[i];
if (panel != null && panel.menu === menu) {
return panel;
}}
return null;
}, "com.android.internal.view.menu.MenuBuilder");
Clazz.overrideMethod (c$, "onCloseMenu", 
function (menu, allMenusAreClosing) {
var panel = this.findMenuPanel (menu);
if (panel != null) {
this.closePanel (panel, allMenusAreClosing);
}}, "com.android.internal.view.menu.MenuBuilder,~B");
Clazz.defineMethod (c$, "updateInt", 
($fz = function (featureId, value, fromResume) {
if (this.mContentParent == null) {
return ;
}var featureMask = 1 << featureId;
}, $fz.isPrivate = true, $fz), "~N,~N,~B");
Clazz.defineMethod (c$, "setContainer", 
function (container) {
this.mContainer = container;
if (container != null) {
this.mFeatures |= 2;
this.mLocalFeatures |= 2;
container.mHasChildren = true;
}}, "android.view.Window");
Clazz.defineMethod (c$, "getContainer", 
function () {
return this.mContainer;
});
Clazz.defineMethod (c$, "getWindowManager", 
function () {
return this.mWindowManager;
});
Clazz.defineMethod (c$, "peekDecorView", 
function () {
return this.mDecor;
});
Clazz.defineMethod (c$, "setWindowManager", 
function (wm, appToken, appName) {
this.mAppToken = appToken;
this.mAppName = appName;
if (wm == null) {
wm = android.view.WindowManagerImpl.getDefault ();
}this.mWindowManager = Clazz.innerTypeInstance (android.view.Window.LocalWindowManager, this, null, wm);
}, "android.view.WindowManager,android.os.IBinder,~S");
Clazz.defineMethod (c$, "setLayout", 
function (width, height) {
var attrs = this.getAttributes ();
attrs.width = width;
attrs.height = height;
if (this.mCallback != null) {
this.mCallback.onWindowAttributesChanged (attrs);
}}, "~N,~N");
Clazz.defineMethod (c$, "setGravity", 
function (gravity) {
var attrs = this.getAttributes ();
attrs.gravity = gravity;
if (this.mCallback != null) {
this.mCallback.onWindowAttributesChanged (attrs);
}}, "~N");
Clazz.defineMethod (c$, "setFlags", 
function (flags, mask) {
var attrs = this.getAttributes ();
attrs.flags = (attrs.flags & ~mask) | (flags & mask);
this.mForcedWindowFlags |= mask;
if (this.mCallback != null) {
this.mCallback.onWindowAttributesChanged (attrs);
}}, "~N,~N");
Clazz.defineMethod (c$, "clearFlags", 
function (flags) {
this.setFlags (0, flags);
}, "~N");
Clazz.defineMethod (c$, "setAttributes", 
function (a) {
this.mWindowAttributes.copyFrom (a);
if (this.mCallback != null) {
this.mCallback.onWindowAttributesChanged (this.mWindowAttributes);
}}, "android.view.WindowManager.LayoutParams");
Clazz.defineMethod (c$, "getAttributes", 
function () {
return this.mWindowAttributes;
});
Clazz.defineMethod (c$, "onKeyDownPanel", 
function (featureId, event) {
var keyCode = event.getKeyCode ();
if (event.getRepeatCount () == 0) {
var st = this.getPanelState (featureId, true);
if (!st.isOpen) {
return this.preparePanel (st, event);
}} else if ((event.getFlags () & 128) != 0) {
}return false;
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onConfigurationChanged", 
function (newConfig) {
var st = this.getPanelState (0, false);
if ((st != null) && (st.menu != null)) {
var menuBuilder = st.menu;
if (st.isOpen) {
var state =  new android.os.Bundle ();
menuBuilder.saveHierarchyState (state);
android.view.Window.clearMenuViews (st);
this.reopenMenu (false);
menuBuilder.restoreHierarchyState (state);
} else {
android.view.Window.clearMenuViews (st);
}}}, "android.content.res.Configuration");
c$.clearMenuViews = Clazz.defineMethod (c$, "clearMenuViews", 
($fz = function (st) {
st.createdPanelView = null;
st.refreshDecorView = true;
(st.menu).clearMenuViews ();
}, $fz.isPrivate = true, $fz), "android.view.Window.PanelFeatureState");
Clazz.overrideMethod (c$, "onSubMenuSelected", 
function (subMenu) {
if (!subMenu.hasVisibleItems ()) {
return true;
} new com.android.internal.view.menu.MenuDialogHelper (subMenu).show (null);
return true;
}, "com.android.internal.view.menu.SubMenuBuilder");
Clazz.overrideMethod (c$, "onCloseSubMenu", 
function (subMenu) {
var parentMenu = subMenu.getRootMenu ();
var panel = this.findMenuPanel (parentMenu);
if (panel != null) {
this.callOnPanelClosed (panel.featureId, panel, parentMenu);
this.closePanel (panel, true);
}}, "com.android.internal.view.menu.SubMenuBuilder");
Clazz.overrideMethod (c$, "onMenuModeChange", 
function (menu) {
this.reopenMenu (true);
}, "com.android.internal.view.menu.MenuBuilder");
Clazz.defineMethod (c$, "superDispatchTrackballEvent", 
function (event) {
console.log("Missing method: superDispatchTrackballEvent");
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "takeInputQueue", 
function (callback) {
console.log("Missing method: takeInputQueue");
}, "android.view.InputQueue.Callback");
Clazz.defineMethod (c$, "makeActive", 
function () {
console.log("Missing method: makeActive");
});
Clazz.defineMethod (c$, "takeKeyEvents", 
function (get) {
console.log("Missing method: takeKeyEvents");
}, "~B");
Clazz.defineMethod (c$, "onActive", 
function () {
console.log("Missing method: onActive");
});
Clazz.defineMethod (c$, "setType", 
function (type) {
console.log("Missing method: setType");
}, "~N");
Clazz.defineMethod (c$, "setBackgroundDrawableResource", 
function (resid) {
console.log("Missing method: setBackgroundDrawableResource");
}, "~N");
Clazz.defineMethod (c$, "hasSoftInputMode", 
function () {
console.log("Missing method: hasSoftInputMode");
});
Clazz.defineMethod (c$, "setDefaultWindowFormat", 
function (format) {
console.log("Missing method: setDefaultWindowFormat");
}, "~N");
Clazz.defineMethod (c$, "isFloating", 
function () {
console.log("Missing method: isFloating");
});
Clazz.defineMethod (c$, "addFlags", 
function (flags) {
console.log("Missing method: addFlags");
}, "~N");
Clazz.defineMethod (c$, "setSoftInputMode", 
function (mode) {
console.log("Missing method: setSoftInputMode");
}, "~N");
Clazz.defineMethod (c$, "getVolumeControlStream", 
function () {
console.log("Missing method: getVolumeControlStream");
});
Clazz.defineMethod (c$, "setFormat", 
function (format) {
console.log("Missing method: setFormat");
}, "~N");
Clazz.defineMethod (c$, "setVolumeControlStream", 
function (streamType) {
console.log("Missing method: setVolumeControlStream");
}, "~N");
Clazz.defineMethod (c$, "setWindowAnimations", 
function (resId) {
console.log("Missing method: setWindowAnimations");
}, "~N");
Clazz.defineMethod (c$, "hasChildren", 
function () {
console.log("Missing method: hasChildren");
});
c$.$Window$DecorView$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mFeatureId = -1;
this.mDefaultOpacity = -1;
this.mBackgroundPadding = null;
this.mFramePadding = null;
this.mChanging = false;
Clazz.instantialize (this, arguments);
}, android.view.Window, "DecorView", android.widget.FrameLayout);
Clazz.prepareFields (c$, function () {
this.mBackgroundPadding =  new android.graphics.Rect ();
this.mFramePadding =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.view.Window.DecorView, [a]);
var thisView = document.getElementById(this.getUIElementID());
if (null == thisView) {
thisView = document.createElement("span");
thisView.style.position = "absolute";
thisView.id = this.getUIElementID();
thisView.style.display = "block";
}
document.body.appendChild(thisView);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.view.Window.DecorView, [a]);
this.mFeatureId = b;
}, "android.content.Context,~N");
Clazz.defineMethod (c$, "assignParent", 
function (a, b) {
if (Clazz.instanceOf (a, android.view.View)) {
Clazz.superCall (this, android.view.Window.DecorView, "assignParent", [a, b]);
if (android.util.DebugUtils.DEBUG_VIEW_IN_BROWSER) {
var thisView = document.getElementById(this.getUIElementID ());
if (this.mFeatureId == 0) {
// OptionsMenu
thisView.style.opacity = 0.8;
thisView.style.filter = "alpha(opacity=80)";
}
}} else {
if (this.mParent == null) {
this.mParent = a;
} else if (a == null) {
this.mParent = null;
return ;
} else {
throw  new RuntimeException ("view " + this + " being attached, but" + " it already has been attached to a ViewRoot");
}}}, "android.view.ViewParent,~B");
Clazz.overrideMethod (c$, "destroy", 
function () {
var thisView = document.getElementById(this.mUIElementID);
if (thisView != null && thisView.parentNode != null) {
thisView.parentNode.removeChild(thisView);
}
if (Clazz.instanceOf (this.mParent, android.view.ViewRoot)) {
(this.mParent).reset ();
}});
Clazz.defineMethod (c$, "superDispatchKeyEvent", 
function (a) {
return Clazz.superCall (this, android.view.Window.DecorView, "dispatchKeyEvent", [a]);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "superDispatchTouchEvent", 
function (a) {
return Clazz.superCall (this, android.view.Window.DecorView, "dispatchTouchEvent", [a]);
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "dispatchKeyEvent", 
function (a) {
var b = a.getKeyCode ();
var c = a.getAction () == 0;
var d = this.b$["android.view.Window"].getCallback ();
var e = (d != null && this.mFeatureId < 0 ? d.dispatchKeyEvent (a) : Clazz.superCall (this, android.view.Window.DecorView, "dispatchKeyEvent", [a]));
if (e) {
return true;
}return c ? this.b$["android.view.Window"].onKeyDown (this.mFeatureId, a.getKeyCode (), a) : this.b$["android.view.Window"].onKeyUp (this.mFeatureId, a.getKeyCode (), a);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "dispatchTouchEvent", 
function (a) {
var b = this.b$["android.view.Window"].getCallback ();
return (b != null && this.mFeatureId < 0 ? b.dispatchTouchEvent (a) : Clazz.superCall (this, android.view.Window.DecorView, "dispatchTouchEvent", [a]));
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "startChanging", 
function () {
this.mChanging = true;
});
Clazz.defineMethod (c$, "finishChanging", 
function () {
this.mChanging = false;
this.drawableChanged ();
});
Clazz.defineMethod (c$, "setWindowBackground", 
function (a) {
if (this.getBackground () !== a) {
this.setBackgroundDrawable (a);
if (a != null) {
a.getPadding (this.mBackgroundPadding);
} else {
this.mBackgroundPadding.setEmpty ();
}this.drawableChanged ();
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setWindowFrame", 
function (a) {
if (this.getForeground () !== a) {
this.setForeground (a);
if (a != null) {
a.getPadding (this.mFramePadding);
} else {
this.mFramePadding.setEmpty ();
}this.drawableChanged ();
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "drawableChanged", 
($fz = function () {
if (this.mChanging) {
return ;
}this.setPadding (this.mFramePadding.left + this.mBackgroundPadding.left, this.mFramePadding.top + this.mBackgroundPadding.top, this.mFramePadding.right + this.mBackgroundPadding.right, this.mFramePadding.bottom + this.mBackgroundPadding.bottom);
this.requestLayout ();
this.invalidate ();
}, $fz.isPrivate = true, $fz));
c$ = Clazz.p0p ();
};
c$.$Window$LocalWindowManager$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mWindowManager = null;
Clazz.instantialize (this, arguments);
}, android.view.Window, "LocalWindowManager", android.view.WindowManager);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.view.Window.LocalWindowManager, []);
this.mWindowManager = a;
}, "android.view.WindowManager");
Clazz.overrideMethod (c$, "addView", 
function (a, b) {
var c = b;
(this.mWindowManager).addView (a, b);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "updateViewLayout", 
function (a, b) {
this.mWindowManager.updateViewLayout (a, b);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "removeView", 
function (a) {
this.mWindowManager.removeView (a);
}, "android.view.View");
Clazz.defineMethod (c$, "getDefaultDisplay", 
function () {
return this.mWindowManager.getDefaultDisplay ();
});
Clazz.defineMethod (c$, "removeViewImmediate", 
function (a) {
this.mWindowManager.removeViewImmediate (a);
}, "android.view.View");
c$ = Clazz.p0p ();
};
c$.$Window$ContextMenuCallback$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mFeatureId = 0;
this.mSubMenuHelper = null;
Clazz.instantialize (this, arguments);
}, android.view.Window, "ContextMenuCallback", null, com.android.internal.view.menu.MenuBuilder.Callback);
Clazz.makeConstructor (c$, 
function (a) {
this.mFeatureId = a;
}, "~N");
Clazz.overrideMethod (c$, "onCloseMenu", 
function (a, b) {
if (b) {
var c = this.b$["android.view.Window"].getCallback ();
if (c != null) c.onPanelClosed (this.mFeatureId, a);
if (a === this.b$["android.view.Window"].mContextMenu) {
this.b$["android.view.Window"].dismissContextMenu ();
}if (this.mSubMenuHelper != null) {
this.mSubMenuHelper.dismiss ();
this.mSubMenuHelper = null;
}}}, "com.android.internal.view.menu.MenuBuilder,~B");
Clazz.overrideMethod (c$, "onCloseSubMenu", 
function (a) {
var b = this.b$["android.view.Window"].getCallback ();
if (b != null) b.onPanelClosed (this.mFeatureId, a.getRootMenu ());
}, "com.android.internal.view.menu.SubMenuBuilder");
Clazz.overrideMethod (c$, "onMenuItemSelected", 
function (a, b) {
var c = this.b$["android.view.Window"].getCallback ();
return (c != null) && c.onMenuItemSelected (this.mFeatureId, b);
}, "com.android.internal.view.menu.MenuBuilder,com.android.internal.view.menu.MenuItemImpl");
Clazz.overrideMethod (c$, "onMenuModeChange", 
function (a) {
}, "com.android.internal.view.menu.MenuBuilder");
Clazz.overrideMethod (c$, "onSubMenuSelected", 
function (a) {
a.setCallback (this);
this.mSubMenuHelper =  new com.android.internal.view.menu.MenuDialogHelper (a);
this.mSubMenuHelper.show (null);
return true;
}, "com.android.internal.view.menu.SubMenuBuilder");
c$ = Clazz.p0p ();
};
Clazz.declareInterface (android.view.Window, "Callback");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.featureId = 0;
this.resid = 0;
this.uri = null;
this.local = null;
this.child = null;
this.def = null;
this.cur = null;
this.alpha = 255;
this.curAlpha = 255;
Clazz.instantialize (this, arguments);
}, android.view.Window, "DrawableFeatureState");
Clazz.makeConstructor (c$, 
function (a) {
this.featureId = a;
}, "~N");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.featureId = 0;
this.background = 0;
this.fullBackground = 0;
this.gravity = 0;
this.x = 0;
this.y = 0;
this.windowAnimations = 0;
this.decorView = null;
this.createdPanelView = null;
this.shownPanelView = null;
this.menu = null;
this.isPrepared = false;
this.isHandled = false;
this.isOpen = false;
this.isInExpandedMode = false;
this.qwertyMode = false;
this.refreshDecorView = false;
this.wasLastOpen = false;
this.wasLastExpanded = false;
this.frozenMenuState = null;
Clazz.instantialize (this, arguments);
}, android.view.Window, "PanelFeatureState");
Clazz.makeConstructor (c$, 
function (a) {
this.featureId = a;
this.refreshDecorView = false;
}, "~N");
Clazz.defineMethod (c$, "setStyle", 
function (a) {
var b = a.obtainStyledAttributes (com.android.internal.R.styleable.Theme);
this.background = b.getResourceId (46, 0);
this.fullBackground = b.getResourceId (47, 0);
this.windowAnimations = b.getResourceId (93, 0);
b.recycle ();
}, "android.content.Context");
Clazz.defineMethod (c$, "setMenu", 
function (a) {
this.menu = a;
if (this.frozenMenuState != null) {
(a).restoreHierarchyState (this.frozenMenuState);
this.frozenMenuState = null;
}}, "com.android.internal.view.menu.MenuBuilder");
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
var a =  new android.view.Window.PanelFeatureState.SavedState ();
a.featureId = this.featureId;
a.isOpen = this.isOpen;
a.isInExpandedMode = this.isInExpandedMode;
if (this.menu != null) {
a.menuState =  new android.os.Bundle ();
(this.menu).saveHierarchyState (a.menuState);
}return a;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (a) {
var b = a;
this.featureId = b.featureId;
this.wasLastOpen = b.isOpen;
this.wasLastExpanded = b.isInExpandedMode;
this.frozenMenuState = b.menuState;
this.menu = null;
this.createdPanelView = null;
this.shownPanelView = null;
this.decorView = null;
}, "android.os.Parcelable");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.featureId = 0;
this.isOpen = false;
this.isInExpandedMode = false;
this.menuState = null;
Clazz.instantialize (this, arguments);
}, android.view.Window.PanelFeatureState, "SavedState", null, android.os.Parcelable);
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
a.writeInt (this.featureId);
a.writeInt (this.isOpen ? 1 : 0);
a.writeInt (this.isInExpandedMode ? 1 : 0);
if (this.isOpen) {
a.writeBundle (this.menuState);
}}, "android.os.Parcel,~N");
c$.readFromParcel = Clazz.defineMethod (c$, "readFromParcel", 
($fz = function (a) {
var b =  new android.view.Window.PanelFeatureState.SavedState ();
b.featureId = a.readInt ();
b.isOpen = a.readInt () == 1;
b.isInExpandedMode = a.readInt () == 1;
if (b.isOpen) {
b.menuState = a.readBundle ();
}return b;
}, $fz.isPrivate = true, $fz), "android.os.Parcel");
c$.$Window$PanelFeatureState$SavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view, "Window$PanelFeatureState$SavedState$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return android.view.Window.PanelFeatureState.SavedState.readFromParcel (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.view.Window$PanelFeatureState$SavedState$1") ? 0 : android.view.Window.PanelFeatureState.SavedState.$Window$PanelFeatureState$SavedState$1$ ()), Clazz.innerTypeInstance (android.view.Window$PanelFeatureState$SavedState$1, this, null));
c$ = Clazz.p0p ();
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "PhoneWindow",
"FEATURE_OPTIONS_PANEL", 0,
"FEATURE_NO_TITLE", 1,
"FEATURE_PROGRESS", 2,
"FEATURE_LEFT_ICON", 3,
"FEATURE_RIGHT_ICON", 4,
"FEATURE_INDETERMINATE_PROGRESS", 5,
"FEATURE_CONTEXT_MENU", 6,
"FEATURE_CUSTOM_TITLE", 7,
"FEATURE_OPENGL", 8,
"FEATURE_BACKKEY", 9,
"PROGRESS_VISIBILITY_ON", -1,
"PROGRESS_VISIBILITY_OFF", -2,
"PROGRESS_INDETERMINATE_ON", -3,
"PROGRESS_INDETERMINATE_OFF", -4,
"PROGRESS_START", 0,
"PROGRESS_END", 10000,
"PROGRESS_SECONDARY_START", 20000,
"PROGRESS_SECONDARY_END", 30000,
"DEFAULT_FEATURES", 577,
"ID_ANDROID_CONTENT", 16908290,
"ID_BACK_KEY", 16908660,
"ID_MENU_KEY", 16908659,
"RELAYOUT_FIRST_TIME", 0x2,
"FOCUSED_ID_TAG", "android:focusedViewId",
"VIEWS_TAG", "android:views",
"PANELS_TAG", "android:Panels");
});
