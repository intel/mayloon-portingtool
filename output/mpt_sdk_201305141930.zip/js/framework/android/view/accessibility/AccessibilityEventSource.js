﻿Clazz.declarePackage ("android.view.accessibility");
Clazz.declareInterface (android.view.accessibility, "AccessibilityEventSource");
