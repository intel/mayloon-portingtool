﻿Clazz.declarePackage ("android.view.accessibility");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator", "java.util.ArrayList"], "android.view.accessibility.AccessibilityEvent", ["java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mNext = null;
this.mEventType = 0;
this.mBooleanProperties = 0;
this.mCurrentItemIndex = 0;
this.mItemCount = 0;
this.mFromIndex = 0;
this.mAddedCount = 0;
this.mRemovedCount = 0;
this.mEventTime = 0;
this.mClassName = null;
this.mPackageName = null;
this.mContentDescription = null;
this.mBeforeText = null;
this.mParcelableData = null;
this.mText = null;
this.mIsInPool = false;
Clazz.instantialize (this, arguments);
}, android.view.accessibility, "AccessibilityEvent", null, android.os.Parcelable);
Clazz.prepareFields (c$, function () {
this.mText =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
($fz = function () {
this.mCurrentItemIndex = -1;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "isChecked", 
function () {
return this.getBooleanProperty (1);
});
Clazz.defineMethod (c$, "setChecked", 
function (isChecked) {
this.setBooleanProperty (1, isChecked);
}, "~B");
Clazz.defineMethod (c$, "isEnabled", 
function () {
return this.getBooleanProperty (2);
});
Clazz.defineMethod (c$, "setEnabled", 
function (isEnabled) {
this.setBooleanProperty (2, isEnabled);
}, "~B");
Clazz.defineMethod (c$, "isPassword", 
function () {
return this.getBooleanProperty (4);
});
Clazz.defineMethod (c$, "setPassword", 
function (isPassword) {
this.setBooleanProperty (4, isPassword);
}, "~B");
Clazz.defineMethod (c$, "setFullScreen", 
function (isFullScreen) {
this.setBooleanProperty (128, isFullScreen);
}, "~B");
Clazz.defineMethod (c$, "isFullScreen", 
function () {
return this.getBooleanProperty (128);
});
Clazz.defineMethod (c$, "getEventType", 
function () {
return this.mEventType;
});
Clazz.defineMethod (c$, "setEventType", 
function (eventType) {
this.mEventType = eventType;
}, "~N");
Clazz.defineMethod (c$, "getItemCount", 
function () {
return this.mItemCount;
});
Clazz.defineMethod (c$, "setItemCount", 
function (itemCount) {
this.mItemCount = itemCount;
}, "~N");
Clazz.defineMethod (c$, "getCurrentItemIndex", 
function () {
return this.mCurrentItemIndex;
});
Clazz.defineMethod (c$, "setCurrentItemIndex", 
function (currentItemIndex) {
this.mCurrentItemIndex = currentItemIndex;
}, "~N");
Clazz.defineMethod (c$, "getFromIndex", 
function () {
return this.mFromIndex;
});
Clazz.defineMethod (c$, "setFromIndex", 
function (fromIndex) {
this.mFromIndex = fromIndex;
}, "~N");
Clazz.defineMethod (c$, "getAddedCount", 
function () {
return this.mAddedCount;
});
Clazz.defineMethod (c$, "setAddedCount", 
function (addedCount) {
this.mAddedCount = addedCount;
}, "~N");
Clazz.defineMethod (c$, "getRemovedCount", 
function () {
return this.mRemovedCount;
});
Clazz.defineMethod (c$, "setRemovedCount", 
function (removedCount) {
this.mRemovedCount = removedCount;
}, "~N");
Clazz.defineMethod (c$, "getEventTime", 
function () {
return this.mEventTime;
});
Clazz.defineMethod (c$, "setEventTime", 
function (eventTime) {
this.mEventTime = eventTime;
}, "~N");
Clazz.defineMethod (c$, "getClassName", 
function () {
return this.mClassName;
});
Clazz.defineMethod (c$, "setClassName", 
function (className) {
this.mClassName = className;
}, "CharSequence");
Clazz.defineMethod (c$, "getPackageName", 
function () {
return this.mPackageName;
});
Clazz.defineMethod (c$, "setPackageName", 
function (packageName) {
this.mPackageName = packageName;
}, "CharSequence");
Clazz.defineMethod (c$, "getText", 
function () {
return this.mText;
});
Clazz.defineMethod (c$, "getBeforeText", 
function () {
return this.mBeforeText;
});
Clazz.defineMethod (c$, "setBeforeText", 
function (beforeText) {
this.mBeforeText = beforeText;
}, "CharSequence");
Clazz.defineMethod (c$, "getContentDescription", 
function () {
return this.mContentDescription;
});
Clazz.defineMethod (c$, "setContentDescription", 
function (contentDescription) {
this.mContentDescription = contentDescription;
}, "CharSequence");
Clazz.defineMethod (c$, "getParcelableData", 
function () {
return this.mParcelableData;
});
Clazz.defineMethod (c$, "setParcelableData", 
function (parcelableData) {
this.mParcelableData = parcelableData;
}, "android.os.Parcelable");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (eventType) {
var event = android.view.accessibility.AccessibilityEvent.obtain ();
event.setEventType (eventType);
return event;
}, "~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function () {
{
if (android.view.accessibility.AccessibilityEvent.sPool != null) {
var event = android.view.accessibility.AccessibilityEvent.sPool;
($t$ = android.view.accessibility.AccessibilityEvent.sPool = android.view.accessibility.AccessibilityEvent.sPool.mNext, android.view.accessibility.AccessibilityEvent.prototype.sPool = android.view.accessibility.AccessibilityEvent.sPool, $t$);
($t$ = android.view.accessibility.AccessibilityEvent.sPoolSize --, android.view.accessibility.AccessibilityEvent.prototype.sPoolSize = android.view.accessibility.AccessibilityEvent.sPoolSize, $t$);
event.mNext = null;
event.mIsInPool = false;
return event;
}return  new android.view.accessibility.AccessibilityEvent ();
}});
Clazz.defineMethod (c$, "recycle", 
function () {
if (this.mIsInPool) {
return ;
}this.clear ();
{
if (android.view.accessibility.AccessibilityEvent.sPoolSize <= 2) {
this.mNext = android.view.accessibility.AccessibilityEvent.sPool;
($t$ = android.view.accessibility.AccessibilityEvent.sPool = this, android.view.accessibility.AccessibilityEvent.prototype.sPool = android.view.accessibility.AccessibilityEvent.sPool, $t$);
this.mIsInPool = true;
($t$ = android.view.accessibility.AccessibilityEvent.sPoolSize ++, android.view.accessibility.AccessibilityEvent.prototype.sPoolSize = android.view.accessibility.AccessibilityEvent.sPoolSize, $t$);
}}});
Clazz.defineMethod (c$, "clear", 
($fz = function () {
this.mEventType = 0;
this.mBooleanProperties = 0;
this.mCurrentItemIndex = -1;
this.mItemCount = 0;
this.mFromIndex = 0;
this.mAddedCount = 0;
this.mRemovedCount = 0;
this.mEventTime = 0;
this.mClassName = null;
this.mPackageName = null;
this.mContentDescription = null;
this.mBeforeText = null;
this.mParcelableData = null;
this.mText.clear ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getBooleanProperty", 
($fz = function (property) {
return (this.mBooleanProperties & property) == property;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "setBooleanProperty", 
($fz = function (property, value) {
if (value) {
this.mBooleanProperties |= property;
} else {
this.mBooleanProperties &= ~property;
}}, $fz.isPrivate = true, $fz), "~N,~B");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "toString", 
function () {
var builder =  new StringBuilder ();
builder.append (Clazz.superCall (this, android.view.accessibility.AccessibilityEvent, "toString", []));
builder.append ("; EventType: " + this.mEventType);
builder.append ("; EventTime: " + this.mEventTime);
builder.append ("; ClassName: " + this.mClassName);
builder.append ("; PackageName: " + this.mPackageName);
builder.append ("; Text: " + this.mText);
builder.append ("; ContentDescription: " + this.mContentDescription);
builder.append ("; ItemCount: " + this.mItemCount);
builder.append ("; CurrentItemIndex: " + this.mCurrentItemIndex);
builder.append ("; IsEnabled: " + this.isEnabled ());
builder.append ("; IsPassword: " + this.isPassword ());
builder.append ("; IsChecked: " + this.isChecked ());
builder.append ("; IsFullScreen: " + this.isFullScreen ());
builder.append ("; BeforeText: " + this.mBeforeText);
builder.append ("; FromIndex: " + this.mFromIndex);
builder.append ("; AddedCount: " + this.mAddedCount);
builder.append ("; RemovedCount: " + this.mRemovedCount);
builder.append ("; ParcelableData: " + this.mParcelableData);
return builder.toString ();
});
Clazz.defineMethod (c$, "initFromParcel", 
function (parcel) {
console.log("Missing method: initFromParcel");
}, "android.os.Parcel");
c$.$AccessibilityEvent$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view.accessibility, "AccessibilityEvent$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (parcel) {
var event = android.view.accessibility.AccessibilityEvent.obtain ();
return event;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"INVALID_POSITION", -1,
"MAX_TEXT_LENGTH", 500,
"TYPE_VIEW_CLICKED", 0x00000001,
"TYPE_VIEW_LONG_CLICKED", 0x00000002,
"TYPE_VIEW_SELECTED", 0x00000004,
"TYPE_VIEW_FOCUSED", 0x00000008,
"TYPE_VIEW_TEXT_CHANGED", 0x00000010,
"TYPE_WINDOW_STATE_CHANGED", 0x00000020,
"TYPE_NOTIFICATION_STATE_CHANGED", 0x00000040,
"TYPES_ALL_MASK", 0xFFFFFFFF,
"MAX_POOL_SIZE", 2);
c$.mPoolLock = c$.prototype.mPoolLock =  new JavaObject ();
Clazz.defineStatics (c$,
"sPool", null,
"sPoolSize", 0,
"CHECKED", 0x00000001,
"ENABLED", 0x00000002,
"PASSWORD", 0x00000004,
"FULL_SCREEN", 0x00000080);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.view.accessibility.AccessibilityEvent$1") ? 0 : android.view.accessibility.AccessibilityEvent.$AccessibilityEvent$1$ ()), Clazz.innerTypeInstance (android.view.accessibility.AccessibilityEvent$1, this, null));
});
