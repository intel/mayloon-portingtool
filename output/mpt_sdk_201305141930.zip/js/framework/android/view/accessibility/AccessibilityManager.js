﻿Clazz.declarePackage ("android.view.accessibility");
Clazz.load (["android.os.Handler"], "android.view.accessibility.AccessibilityManager", ["android.os.SystemClock", "android.util.Log", "java.lang.IllegalStateException", "java.util.Collections"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mHandler = null;
this.mIsEnabled = false;
if (!Clazz.isClassDefined ("android.view.accessibility.AccessibilityManager.MyHandler")) {
android.view.accessibility.AccessibilityManager.$AccessibilityManager$MyHandler$ ();
}
Clazz.instantialize (this, arguments);
}, android.view.accessibility, "AccessibilityManager");
c$.getInstance = Clazz.defineMethod (c$, "getInstance", 
function (context) {
{
if (android.view.accessibility.AccessibilityManager.sInstance == null) {
($t$ = android.view.accessibility.AccessibilityManager.sInstance =  new android.view.accessibility.AccessibilityManager (context), android.view.accessibility.AccessibilityManager.prototype.sInstance = android.view.accessibility.AccessibilityManager.sInstance, $t$);
}}return android.view.accessibility.AccessibilityManager.sInstance;
}, "android.content.Context");
Clazz.makeConstructor (c$, 
($fz = function (context) {
this.mHandler = Clazz.innerTypeInstance (android.view.accessibility.AccessibilityManager.MyHandler, this, null, null);
}, $fz.isPrivate = true, $fz), "android.content.Context");
Clazz.defineMethod (c$, "isEnabled", 
function () {
{
return this.mIsEnabled;
}});
Clazz.defineMethod (c$, "sendAccessibilityEvent", 
function (event) {
if (!this.mIsEnabled) {
throw  new IllegalStateException ("Accessibility off. Did you forget to check that?");
}var doRecycle = false;
try {
event.setEventTime (android.os.SystemClock.uptimeMillis ());
if (false) {
android.util.Log.i ("AccessibilityManager", event + " sent");
}} catch (re) {
if (Clazz.instanceOf (re, Exception)) {
android.util.Log.e ("AccessibilityManager", "Error during sending " + event + " ", re);
} else {
throw re;
}
} finally {
if (doRecycle) {
event.recycle ();
}}
}, "android.view.accessibility.AccessibilityEvent");
Clazz.defineMethod (c$, "interrupt", 
function () {
if (!this.mIsEnabled) {
throw  new IllegalStateException ("Accessibility off. Did you forget to check that?");
}try {
if (false) {
android.util.Log.i ("AccessibilityManager", "Requested interrupt from all services");
}} catch (re) {
if (Clazz.instanceOf (re, Exception)) {
android.util.Log.e ("AccessibilityManager", "Error while requesting interrupt from all services. ", re);
} else {
throw re;
}
}
});
Clazz.defineMethod (c$, "getAccessibilityServiceList", 
function () {
var services = null;
try {
if (false) {
android.util.Log.i ("AccessibilityManager", "Installed AccessibilityServices " + services);
}} catch (re) {
if (Clazz.instanceOf (re, Exception)) {
android.util.Log.e ("AccessibilityManager", "Error while obtaining the installed AccessibilityServices. ", re);
} else {
throw re;
}
}
return java.util.Collections.unmodifiableList (services);
});
c$.$AccessibilityManager$MyHandler$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.view.accessibility.AccessibilityManager, "MyHandler", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
switch (a.what) {
case 10:
{
this.b$["android.view.accessibility.AccessibilityManager"].mIsEnabled = (a.arg1 == 1);
}return ;
default:
android.util.Log.w ("AccessibilityManager", "Unknown message type: " + a.what);
}
}, "android.os.Message");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"LOG_TAG", "AccessibilityManager");
c$.sInstanceSync = c$.prototype.sInstanceSync =  new JavaObject ();
Clazz.defineStatics (c$,
"sInstance", null,
"DO_SET_ENABLED", 10);
});
