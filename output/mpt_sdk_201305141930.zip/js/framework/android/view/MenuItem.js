﻿Clazz.declarePackage ("android.view");
Clazz.declareInterface (android.view, "MenuItem");
Clazz.declareInterface (android.view.MenuItem, "OnMenuItemClickListener");
