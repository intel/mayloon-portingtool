﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.content.ContextWrapper"], "android.view.ContextThemeWrapper", ["android.content.Context", "android.view.LayoutInflater"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$mBase = null;
this.$mThemeResource = 0;
this.$mTheme = null;
this.mInflater = null;
Clazz.instantialize (this, arguments);
}, android.view, "ContextThemeWrapper", android.content.ContextWrapper);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.view.ContextThemeWrapper, [null]);
});
Clazz.makeConstructor (c$, 
function (context, i) {
Clazz.superConstructor (this, android.view.ContextThemeWrapper, [context]);
this.$mBase = context;
this.$mThemeResource = i;
}, "android.content.Context,~N");
Clazz.defineMethod (c$, "attachBaseContext", 
function (newBase) {
Clazz.superCall (this, android.view.ContextThemeWrapper, "attachBaseContext", [newBase]);
this.$mBase = newBase;
}, "android.content.Context");
Clazz.overrideMethod (c$, "setTheme", 
function (resid) {
this.$mThemeResource = resid;
this.initializeTheme ();
}, "~N");
Clazz.overrideMethod (c$, "getTheme", 
function () {
if (this.$mTheme != null) {
return this.$mTheme;
}if (this.$mThemeResource == 0) {
this.$mThemeResource = 16973829;
}this.initializeTheme ();
return this.$mTheme;
});
Clazz.defineMethod (c$, "getSystemService", 
function (name) {
if ("layout_inflater".equals (name)) {
if (this.mInflater == null) {
this.mInflater = android.view.LayoutInflater.from (this.$mBase).cloneInContext (this);
}return this.mInflater;
}return this.$mBase.getSystemService (name);
}, "~S");
Clazz.defineMethod (c$, "onApplyThemeResource", 
function (theme, resid, first) {
theme.applyStyle (resid, true);
}, "android.content.res.Resources.Theme,~N,~B");
Clazz.defineMethod (c$, "initializeTheme", 
($fz = function () {
var first = this.$mTheme == null;
if (first) {
this.$mTheme = this.getResources ().newTheme ();
var theme = this.$mBase.getTheme ();
if (theme != null) {
this.$mTheme.setTo (theme);
}}this.onApplyThemeResource (this.$mTheme, this.$mThemeResource, first);
}, $fz.isPrivate = true, $fz));
});
