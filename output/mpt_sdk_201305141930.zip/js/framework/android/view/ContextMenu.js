﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.view.Menu"], "android.view.ContextMenu", null, function () {
Clazz.declareInterface (android.view, "ContextMenu", android.view.Menu);
Clazz.declareInterface (android.view.ContextMenu, "ContextMenuInfo");
});
