﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.view.ViewGroup", "$.ViewManager"], "android.view.WindowManager", ["android.util.Log", "android.view.Display", "java.lang.StringBuilder"], function () {
c$ = Clazz.declareType (android.view, "WindowManager", null, android.view.ViewManager);
Clazz.overrideMethod (c$, "addView", 
function (view, params) {
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.overrideMethod (c$, "updateViewLayout", 
function (view, params) {
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.overrideMethod (c$, "removeView", 
function (view) {
}, "android.view.View");
Clazz.defineMethod (c$, "getDefaultDisplay", 
function () {
return  new android.view.Display (0);
});
Clazz.defineMethod (c$, "removeViewImmediate", 
function (view) {
}, "android.view.View");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.x = 0;
this.y = 0;
this.horizontalWeight = 0;
this.verticalWeight = 0;
this.type = 0;
this.memoryType = 0;
this.flags = 0;
this.softInputMode = 0;
this.gravity = 0;
this.horizontalMargin = 0;
this.verticalMargin = 0;
this.format = 0;
this.windowAnimations = 0;
this.alpha = 1.0;
this.dimAmount = 1.0;
this.screenBrightness = -1.0;
this.buttonBrightness = -1.0;
this.packageName = null;
this.screenOrientation = -1;
this.mCompatibilityParamsBackup = null;
this.mTitle = "";
this.token = null;
Clazz.instantialize (this, arguments);
}, android.view.WindowManager, "LayoutParams", android.view.ViewGroup.LayoutParams);
c$.mayUseInputMethod = Clazz.defineMethod (c$, "mayUseInputMethod", 
function (a) {
switch (a & (131080)) {
case 0:
case 131080:
return true;
}
return false;
}, "~N");
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.view.WindowManager.LayoutParams, [-1, -1]);
this.type = 2;
this.format = -1;
});
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.view.WindowManager.LayoutParams, [-1, -1]);
this.type = a;
this.format = -1;
}, "~N");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.view.WindowManager.LayoutParams, [-1, -1]);
this.type = a;
this.flags = b;
this.format = -1;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.view.WindowManager.LayoutParams, [-1, -1]);
this.type = a;
this.flags = b;
this.format = c;
}, "~N,~N,~N");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e) {
Clazz.superConstructor (this, android.view.WindowManager.LayoutParams, [a, b]);
this.type = c;
this.flags = d;
this.format = e;
}, "~N,~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e, f, g) {
Clazz.superConstructor (this, android.view.WindowManager.LayoutParams, [a, b]);
this.x = c;
this.y = d;
this.type = e;
this.flags = f;
this.format = g;
}, "~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "setTitle", 
function (a) {
if (null == a) a = "";
this.mTitle = a;
}, "CharSequence");
Clazz.defineMethod (c$, "getTitle", 
function () {
return this.mTitle;
});
Clazz.defineMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "copyFrom", 
function (a) {
var b = 0;
if (this.width != a.width) {
this.width = a.width;
b |= 1;
}if (this.height != a.height) {
this.height = a.height;
b |= 1;
}if (this.x != a.x) {
this.x = a.x;
b |= 1;
}if (this.y != a.y) {
this.y = a.y;
b |= 1;
}if (this.horizontalWeight != a.horizontalWeight) {
this.horizontalWeight = a.horizontalWeight;
b |= 1;
}if (this.verticalWeight != a.verticalWeight) {
this.verticalWeight = a.verticalWeight;
b |= 1;
}if (this.horizontalMargin != a.horizontalMargin) {
this.horizontalMargin = a.horizontalMargin;
b |= 1;
}if (this.verticalMargin != a.verticalMargin) {
this.verticalMargin = a.verticalMargin;
b |= 1;
}if (this.type != a.type) {
this.type = a.type;
b |= 2;
}if (this.memoryType != a.memoryType) {
this.memoryType = a.memoryType;
b |= 256;
}if (this.flags != a.flags) {
this.flags = a.flags;
b |= 4;
}if (this.softInputMode != a.softInputMode) {
this.softInputMode = a.softInputMode;
b |= 512;
}if (this.gravity != a.gravity) {
this.gravity = a.gravity;
b |= 1;
}if (this.horizontalMargin != a.horizontalMargin) {
this.horizontalMargin = a.horizontalMargin;
b |= 1;
}if (this.verticalMargin != a.verticalMargin) {
this.verticalMargin = a.verticalMargin;
b |= 1;
}if (this.format != a.format) {
this.format = a.format;
b |= 8;
}if (this.windowAnimations != a.windowAnimations) {
this.windowAnimations = a.windowAnimations;
b |= 16;
}if (this.packageName == null) {
this.packageName = a.packageName;
}if (!this.mTitle.equals (a.mTitle)) {
this.mTitle = a.mTitle;
b |= 64;
}if (this.alpha != a.alpha) {
this.alpha = a.alpha;
b |= 128;
}if (this.dimAmount != a.dimAmount) {
this.dimAmount = a.dimAmount;
b |= 32;
}if (this.screenBrightness != a.screenBrightness) {
this.screenBrightness = a.screenBrightness;
b |= 2048;
}if (this.buttonBrightness != a.buttonBrightness) {
this.buttonBrightness = a.buttonBrightness;
b |= 4096;
}if (this.screenOrientation != a.screenOrientation) {
this.screenOrientation = a.screenOrientation;
b |= 1024;
}return b;
}, "android.view.WindowManager.LayoutParams");
Clazz.defineMethod (c$, "debug", 
function (a) {
a += "Contents of " + this + ":";
android.util.Log.d ("Debug", a);
a = Clazz.superCall (this, android.view.WindowManager.LayoutParams, "debug", [""]);
android.util.Log.d ("Debug", a);
android.util.Log.d ("Debug", "");
android.util.Log.d ("Debug", "Window.LayoutParams={title=" + this.mTitle + "}");
return "";
}, "~S");
Clazz.overrideMethod (c$, "toString", 
function () {
var a =  new StringBuilder (256);
a.append ("WM.LayoutParams{");
a.append ("(");
a.append (this.x);
a.append (',');
a.append (this.y);
a.append (")(");
a.append ((this.width == -1 ? "fill" : (this.width == -2 ? "wrap" : this.width)));
a.append ('x');
a.append ((this.height == -1 ? "fill" : (this.height == -2 ? "wrap" : this.height)));
a.append (")");
if (this.softInputMode != 0) {
a.append (" sim=#");
a.append (Integer.toHexString (this.softInputMode));
}if (this.gravity != 0) {
a.append (" gr=#");
a.append (Integer.toHexString (this.gravity));
}a.append (" ty=");
a.append (this.type);
a.append (" fl=#");
a.append (Integer.toHexString (this.flags));
a.append (" fmt=");
a.append (this.format);
if (this.windowAnimations != 0) {
a.append (" wanim=0x");
a.append (Integer.toHexString (this.windowAnimations));
}if (this.screenOrientation != -1) {
a.append (" or=");
a.append (this.screenOrientation);
}if ((this.flags & 536870912) != 0) {
a.append (" compatible=true");
}a.append ('}');
return a.toString ();
});
Clazz.defineMethod (c$, "scale", 
function (a) {
this.x = Math.round ((this.x * a + 0.5));
this.y = Math.round ((this.y * a + 0.5));
if (this.width > 0) {
this.width = Math.round ((this.width * a + 0.5));
}if (this.height > 0) {
this.height = Math.round ((this.height * a + 0.5));
}}, "~N");
Clazz.defineMethod (c$, "backup", 
function () {
var a = this.mCompatibilityParamsBackup;
if (a == null) {
a = this.mCompatibilityParamsBackup =  Clazz.newArray (4, 0);
}a[0] = this.x;
a[1] = this.y;
a[2] = this.width;
a[3] = this.height;
});
Clazz.defineMethod (c$, "restore", 
function () {
var a = this.mCompatibilityParamsBackup;
if (a != null) {
this.x = a[0];
this.y = a[1];
this.width = a[2];
this.height = a[3];
}});
Clazz.defineStatics (c$,
"FIRST_APPLICATION_WINDOW", 1,
"TYPE_BASE_APPLICATION", 1,
"TYPE_APPLICATION", 2,
"TYPE_APPLICATION_STARTING", 3,
"LAST_APPLICATION_WINDOW", 99,
"FIRST_SUB_WINDOW", 1000,
"TYPE_APPLICATION_PANEL", 1000,
"TYPE_APPLICATION_MEDIA", 1001,
"TYPE_APPLICATION_SUB_PANEL", 1002,
"TYPE_APPLICATION_ATTACHED_DIALOG", 1003,
"TYPE_APPLICATION_MEDIA_OVERLAY", 1004,
"LAST_SUB_WINDOW", 1999,
"FIRST_SYSTEM_WINDOW", 2000,
"TYPE_STATUS_BAR", 2000,
"TYPE_SEARCH_BAR", 2001,
"TYPE_PHONE", 2002,
"TYPE_SYSTEM_ALERT", 2003,
"TYPE_KEYGUARD", 2004,
"TYPE_TOAST", 2005,
"TYPE_SYSTEM_OVERLAY", 2006,
"TYPE_PRIORITY_PHONE", 2007,
"TYPE_SYSTEM_DIALOG", 2008,
"TYPE_KEYGUARD_DIALOG", 2009,
"TYPE_SYSTEM_ERROR", 2010,
"TYPE_INPUT_METHOD", 2011,
"TYPE_INPUT_METHOD_DIALOG", 2012,
"TYPE_WALLPAPER", 2013,
"TYPE_STATUS_BAR_PANEL", 2014,
"TYPE_SECURE_SYSTEM_OVERLAY", 2015,
"LAST_SYSTEM_WINDOW", 2999,
"MEMORY_TYPE_NORMAL", 0,
"MEMORY_TYPE_HARDWARE", 1,
"MEMORY_TYPE_GPU", 2,
"MEMORY_TYPE_PUSH_BUFFERS", 3,
"FLAG_ALLOW_LOCK_WHILE_SCREEN_ON", 0x00000001,
"FLAG_DIM_BEHIND", 0x00000002,
"FLAG_BLUR_BEHIND", 0x00000004,
"FLAG_NOT_FOCUSABLE", 0x00000008,
"FLAG_NOT_TOUCHABLE", 0x00000010,
"FLAG_NOT_TOUCH_MODAL", 0x00000020,
"FLAG_TOUCHABLE_WHEN_WAKING", 0x00000040,
"FLAG_KEEP_SCREEN_ON", 0x00000080,
"FLAG_LAYOUT_IN_SCREEN", 0x00000100,
"FLAG_LAYOUT_NO_LIMITS", 0x00000200,
"FLAG_FULLSCREEN", 0x00000400,
"FLAG_FORCE_NOT_FULLSCREEN", 0x00000800,
"FLAG_DITHER", 0x00001000,
"FLAG_SECURE", 0x00002000,
"FLAG_SCALED", 0x00004000,
"FLAG_IGNORE_CHEEK_PRESSES", 0x00008000,
"FLAG_LAYOUT_INSET_DECOR", 0x00010000,
"FLAG_ALT_FOCUSABLE_IM", 0x00020000,
"FLAG_WATCH_OUTSIDE_TOUCH", 0x00040000,
"FLAG_SHOW_WHEN_LOCKED", 0x00080000,
"FLAG_SHOW_WALLPAPER", 0x00100000,
"FLAG_TURN_SCREEN_ON", 0x00200000,
"FLAG_DISMISS_KEYGUARD", 0x00400000,
"FLAG_SPLIT_TOUCH", 0x00800000,
"FLAG_KEEP_SURFACE_WHILE_ANIMATING", 0x10000000,
"FLAG_COMPATIBLE_WINDOW", 0x20000000,
"FLAG_SYSTEM_ERROR", 0x40000000,
"SOFT_INPUT_MASK_STATE", 0x0f,
"SOFT_INPUT_STATE_UNSPECIFIED", 0,
"SOFT_INPUT_STATE_UNCHANGED", 1,
"SOFT_INPUT_STATE_HIDDEN", 2,
"SOFT_INPUT_STATE_ALWAYS_HIDDEN", 3,
"SOFT_INPUT_STATE_VISIBLE", 4,
"SOFT_INPUT_STATE_ALWAYS_VISIBLE", 5,
"SOFT_INPUT_MASK_ADJUST", 0xf0,
"SOFT_INPUT_ADJUST_UNSPECIFIED", 0x00,
"SOFT_INPUT_ADJUST_RESIZE", 0x10,
"SOFT_INPUT_ADJUST_PAN", 0x20,
"SOFT_INPUT_IS_FORWARD_NAVIGATION", 0x100,
"BRIGHTNESS_OVERRIDE_NONE", -1.0,
"BRIGHTNESS_OVERRIDE_OFF", 0.0,
"BRIGHTNESS_OVERRIDE_FULL", 1.0,
"LAYOUT_CHANGED", 1,
"TYPE_CHANGED", 2,
"FLAGS_CHANGED", 4,
"FORMAT_CHANGED", 8,
"ANIMATION_CHANGED", 16,
"DIM_AMOUNT_CHANGED", 32,
"TITLE_CHANGED", 64,
"ALPHA_CHANGED", 128,
"MEMORY_TYPE_CHANGED", 256,
"SOFT_INPUT_MODE_CHANGED", 512,
"SCREEN_ORIENTATION_CHANGED", 1024,
"SCREEN_BRIGHTNESS_CHANGED", 2048,
"BUTTON_BRIGHTNESS_CHANGED", 4096);
c$ = Clazz.p0p ();
});
