﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.util.SparseArray", "$.SparseIntArray"], "android.view.KeyCharacterMap", ["android.os.SystemClock", "android.view.KeyEvent", "java.lang.IndexOutOfBoundsException", "$.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPointer = 0;
this.mKeyboardDevice = 0;
Clazz.instantialize (this, arguments);
}, android.view, "KeyCharacterMap");
c$.load = Clazz.defineMethod (c$, "load", 
function (keyboard) {
{
var result;
var ref = android.view.KeyCharacterMap.sInstances.get (keyboard);
if (ref != null) {
result = ref;
if (result != null) {
return result;
}}result =  new android.view.KeyCharacterMap (keyboard);
android.view.KeyCharacterMap.sInstances.put (keyboard, result);
return result;
}}, "~N");
Clazz.makeConstructor (c$, 
($fz = function (keyboardDevice) {
this.mKeyboardDevice = keyboardDevice;
this.mPointer = android.view.KeyCharacterMap.ctor_native (keyboardDevice);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getNumber", 
function (keyCode) {
return android.view.KeyCharacterMap.getNumber_native (this.mPointer, keyCode);
}, "~N");
Clazz.defineMethod (c$, "getMatch", 
function (keyCode, chars) {
return this.getMatch (keyCode, chars, 0);
}, "~N,~A");
Clazz.defineMethod (c$, "getMatch", 
function (keyCode, chars, modifiers) {
if (chars == null) {
throw  new NullPointerException ();
}return android.view.KeyCharacterMap.getMatch_native (this.mPointer, keyCode, chars, modifiers);
}, "~N,~A,~N");
Clazz.defineMethod (c$, "getDisplayLabel", 
function (keyCode) {
return android.view.KeyCharacterMap.getDisplayLabel_native (this.mPointer, keyCode);
}, "~N");
c$.getDeadChar = Clazz.defineMethod (c$, "getDeadChar", 
function (accent, c) {
return android.view.KeyCharacterMap.DEAD.get ((accent << 16) | c);
}, "~N,~N");
Clazz.defineMethod (c$, "getKeyData", 
function (keyCode, results) {
if (results.meta.length >= 4) {
return android.view.KeyCharacterMap.getKeyData_native (this.mPointer, keyCode, results);
} else {
throw  new IndexOutOfBoundsException ("results.meta.length must be >= 4");
}}, "~N,android.view.KeyCharacterMap.KeyData");
Clazz.defineMethod (c$, "getEvents", 
function (chars) {
if (chars == null) {
throw  new NullPointerException ();
}var keys = android.view.KeyCharacterMap.getEvents_native (this.mPointer, chars);
if (keys == null) {
return null;
}var len = keys.length * 2;
var N = keys.length;
for (var i = 0; i < N; i++) {
var mods = (keys[i] >> 32);
if ((mods & 2) != 0) {
len += 2;
}if ((mods & 1) != 0) {
len += 2;
}if ((mods & 4) != 0) {
len += 2;
}}
var rv =  new Array (len);
var index = 0;
var now = android.os.SystemClock.uptimeMillis ();
var device = this.mKeyboardDevice;
for (var i = 0; i < N; i++) {
var mods = (keys[i] >> 32);
var meta = 0;
if ((mods & 2) != 0) {
meta |= 2;
rv[index] =  new android.view.KeyEvent (now, now, 0, 57, 0, meta, device, 0);
index++;
}if ((mods & 1) != 0) {
meta |= 1;
rv[index] =  new android.view.KeyEvent (now, now, 0, 59, 0, meta, device, 0);
index++;
}if ((mods & 4) != 0) {
meta |= 4;
rv[index] =  new android.view.KeyEvent (now, now, 0, 63, 0, meta, device, 0);
index++;
}var key = (keys[i]);
rv[index] =  new android.view.KeyEvent (now, now, 0, key, 0, meta, device, 0);
index++;
rv[index] =  new android.view.KeyEvent (now, now, 1, key, 0, meta, device, 0);
index++;
if ((mods & 2) != 0) {
meta &= -3;
rv[index] =  new android.view.KeyEvent (now, now, 1, 57, 0, meta, device, 0);
index++;
}if ((mods & 1) != 0) {
meta &= -2;
rv[index] =  new android.view.KeyEvent (now, now, 1, 59, 0, meta, device, 0);
index++;
}if ((mods & 4) != 0) {
meta &= -5;
rv[index] =  new android.view.KeyEvent (now, now, 1, 63, 0, meta, device, 0);
index++;
}}
return rv;
}, "~A");
Clazz.overrideMethod (c$, "finalize", 
function () {
android.view.KeyCharacterMap.dtor_native (this.mPointer);
});
Clazz.defineMethod (c$, "getKeyboardType", 
function () {
return android.view.KeyCharacterMap.getKeyboardType_native (this.mPointer);
});
c$.deviceHasKeys = Clazz.defineMethod (c$, "deviceHasKeys", 
function (keyCodes) {
console.log("Missing method: deviceHasKeys");
}, "~A");
Clazz.defineMethod (c$, "isPrintingKey", 
function (keyCode) {
console.log("Missing method: isPrintingKey");
}, "~N");
c$.deviceHasKey = Clazz.defineMethod (c$, "deviceHasKey", 
function (keyCode) {
console.log("Missing method: deviceHasKey");
}, "~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.displayLabel = 0;
this.number = 0;
this.meta = null;
Clazz.instantialize (this, arguments);
}, android.view.KeyCharacterMap, "KeyData");
Clazz.prepareFields (c$, function () {
this.meta =  Clazz.newArray (4, '\0');
});
Clazz.defineStatics (c$,
"META_LENGTH", 4);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"BUILT_IN_KEYBOARD", 0,
"NUMERIC", 1,
"PREDICTIVE", 2,
"ALPHA", 3,
"HEX_INPUT", '\uEF00',
"PICKER_DIALOG_INPUT", '\uEF01');
c$.sLock = c$.prototype.sLock =  new JavaObject ();
c$.sInstances = c$.prototype.sInstances =  new android.util.SparseArray ();
c$.COMBINING = c$.prototype.COMBINING =  new android.util.SparseIntArray ();
c$.DEAD = c$.prototype.DEAD =  new android.util.SparseIntArray ();
Clazz.defineStatics (c$,
"ACUTE", 11796480,
"GRAVE", 6291456,
"CIRCUMFLEX", 6160384,
"TILDE", 8257536,
"UMLAUT", 11010048,
"COMBINING_ACCENT", 0x80000000,
"COMBINING_ACCENT_MASK", 0x7FFFFFFF);
{
android.view.KeyCharacterMap.COMBINING.put ('\u0300'.charCodeAt (0), -2147483552);
android.view.KeyCharacterMap.COMBINING.put ('\u0301'.charCodeAt (0), -2147483468);
android.view.KeyCharacterMap.COMBINING.put ('\u0302'.charCodeAt (0), -2147483554);
android.view.KeyCharacterMap.COMBINING.put ('\u0303'.charCodeAt (0), -2147483522);
android.view.KeyCharacterMap.COMBINING.put ('\u0308'.charCodeAt (0), -2147483480);
android.view.KeyCharacterMap.DEAD.put (11796545, '\u00C1'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796547, '\u0106'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796549, '\u00C9'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796551, '\u01F4'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796553, '\u00CD'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796555, '\u1E30'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796556, '\u0139'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796557, '\u1E3E'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796558, '\u0143'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796559, '\u00D3'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796560, '\u1E54'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796562, '\u0154'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796563, '\u015A'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796565, '\u00DA'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796567, '\u1E82'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796569, '\u00DD'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796570, '\u0179'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796577, '\u00E1'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796579, '\u0107'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796581, '\u00E9'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796583, '\u01F5'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796585, '\u00ED'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796587, '\u1E31'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796588, '\u013A'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796589, '\u1E3F'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796590, '\u0144'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796591, '\u00F3'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796592, '\u1E55'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796594, '\u0155'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796595, '\u015B'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796597, '\u00FA'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796599, '\u1E83'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796601, '\u00FD'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11796602, '\u017A'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160449, '\u00C2'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160451, '\u0108'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160453, '\u00CA'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160455, '\u011C'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160456, '\u0124'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160457, '\u00CE'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160458, '\u0134'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160463, '\u00D4'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160467, '\u015C'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160469, '\u00DB'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160471, '\u0174'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160473, '\u0176'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160474, '\u1E90'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160481, '\u00E2'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160483, '\u0109'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160485, '\u00EA'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160487, '\u011D'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160488, '\u0125'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160489, '\u00EE'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160490, '\u0135'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160495, '\u00F4'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160499, '\u015D'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160501, '\u00FB'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160503, '\u0175'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160505, '\u0177'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6160506, '\u1E91'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291521, '\u00C0'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291525, '\u00C8'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291529, '\u00CC'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291534, '\u01F8'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291535, '\u00D2'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291541, '\u00D9'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291543, '\u1E80'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291545, '\u1EF2'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291553, '\u00E0'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291557, '\u00E8'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291561, '\u00EC'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291566, '\u01F9'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291567, '\u00F2'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291573, '\u00F9'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291575, '\u1E81'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (6291577, '\u1EF3'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257601, '\u00C3'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257605, '\u1EBC'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257609, '\u0128'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257614, '\u00D1'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257615, '\u00D5'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257621, '\u0168'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257622, '\u1E7C'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257625, '\u1EF8'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257633, '\u00E3'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257637, '\u1EBD'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257641, '\u0129'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257646, '\u00F1'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257647, '\u00F5'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257653, '\u0169'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257654, '\u1E7D'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (8257657, '\u1EF9'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010113, '\u00C4'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010117, '\u00CB'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010120, '\u1E26'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010121, '\u00CF'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010127, '\u00D6'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010133, '\u00DC'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010135, '\u1E84'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010136, '\u1E8C'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010137, '\u0178'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010145, '\u00E4'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010149, '\u00EB'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010152, '\u1E27'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010153, '\u00EF'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010159, '\u00F6'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010164, '\u1E97'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010165, '\u00FC'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010167, '\u1E85'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010168, '\u1E8D'.charCodeAt (0));
android.view.KeyCharacterMap.DEAD.put (11010169, '\u00FF'.charCodeAt (0));
}});
