﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.graphics.Canvas", "android.os.Parcelable", "java.lang.Exception"], "android.view.Surface", ["android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mSurfaceControl = 0;
this.mSaveCount = 0;
this.mCanvas = null;
this.mNativeSurface = 0;
this.mName = null;
this.mCompatibleDisplayMetrics = null;
this.mCompatibleMatrix = null;
this.mCreationStack = null;
if (!Clazz.isClassDefined ("android.view.Surface.CompatibleCanvas")) {
android.view.Surface.$Surface$CompatibleCanvas$ ();
}
Clazz.instantialize (this, arguments);
}, android.view, "Surface", null, android.os.Parcelable);
c$.nativeClassInit = Clazz.defineMethod (c$, "nativeClassInit", 
($fz = function () {
}, $fz.isPrivate = true, $fz));
Clazz.makeConstructor (c$, 
function (s, pid, display, w, h, format, flags) {
if (false) {
this.mCreationStack =  new Exception ();
}this.mCanvas = Clazz.innerTypeInstance (android.view.Surface.CompatibleCanvas, this, null);
this.init (s, pid, null, display, w, h, format, flags);
}, "android.view.SurfaceSession,~N,~N,~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (s, pid, name, display, w, h, format, flags) {
if (false) {
this.mCreationStack =  new Exception ();
}this.mCanvas = Clazz.innerTypeInstance (android.view.Surface.CompatibleCanvas, this, null);
this.init (s, pid, name, display, w, h, format, flags);
this.mName = name;
}, "android.view.SurfaceSession,~N,~S,~N,~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function () {
if (false) {
this.mCreationStack =  new Exception ();
}this.mCanvas = Clazz.innerTypeInstance (android.view.Surface.CompatibleCanvas, this, null);
});
Clazz.defineMethod (c$, "release", 
function () {
});
Clazz.defineMethod (c$, "lockCanvas", 
function (dirty) {
return this.lockCanvasNative (dirty);
}, "android.graphics.Rect");
c$.setOrientation = Clazz.defineMethod (c$, "setOrientation", 
function (display, orientation) {
android.view.Surface.setOrientation (display, orientation, 0);
}, "~N,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return "Surface(name=" + this.mName + ", identity=" + this.getIdentity () + ")";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.overrideMethod (c$, "finalize", 
function () {
if (this.mNativeSurface != 0 || this.mSurfaceControl != 0) {
if (false) {
android.util.Log.w ("Surface", "Surface.finalize() has work. You should have called release() (" + this.mNativeSurface + ", " + this.mSurfaceControl + ")", this.mCreationStack);
} else {
android.util.Log.w ("Surface", "Surface.finalize() has work. You should have called release() (" + this.mNativeSurface + ", " + this.mSurfaceControl + ")");
}}this.release ();
});
Clazz.defineMethod (c$, "getIdentity", 
($fz = function () {
return 0;
}, $fz.isPrivate = true, $fz));
c$.$Surface$CompatibleCanvas$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mOrigMatrix = null;
Clazz.instantialize (this, arguments);
}, android.view.Surface, "CompatibleCanvas", android.graphics.Canvas);
Clazz.defineMethod (c$, "getWidth", 
function () {
return this.b$["android.view.Surface"].mCompatibleDisplayMetrics == null ? Clazz.superCall (this, android.view.Surface.CompatibleCanvas, "getWidth", []) : this.b$["android.view.Surface"].mCompatibleDisplayMetrics.widthPixels;
});
Clazz.defineMethod (c$, "getHeight", 
function () {
return this.b$["android.view.Surface"].mCompatibleDisplayMetrics == null ? Clazz.superCall (this, android.view.Surface.CompatibleCanvas, "getHeight", []) : this.b$["android.view.Surface"].mCompatibleDisplayMetrics.heightPixels;
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.declareType (android.view.Surface, "OutOfResourcesException", Exception);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.view.Surface.OutOfResourcesException, []);
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"LOG_TAG", "Surface",
"DEBUG_RELEASE", false,
"HIDDEN", 0x00000004,
"HARDWARE", 0x00000010,
"GPU", 0x00000028,
"SECURE", 0x00000080,
"NON_PREMULTIPLIED", 0x00000100,
"PUSH_BUFFERS", 0x00000200,
"FX_SURFACE_NORMAL", 0x00000000,
"FX_SURFACE_BLUR", 0x00010000,
"FX_SURFACE_DIM", 0x00020000,
"FX_SURFACE_MASK", 0x000F0000,
"SURFACE_HIDDEN", 0x01,
"SURFACE_FROZEN", 0x02,
"SURACE_FROZEN", 0x02,
"SURFACE_DITHER", 0x04,
"SURFACE_BLUR_FREEZE", 0x10,
"ROTATION_0", 0,
"ROTATION_90", 1,
"ROTATION_180", 2,
"ROTATION_270", 3,
"FLAGS_ORIENTATION_ANIMATION_DISABLE", 0x000000001);
{
android.view.Surface.nativeClassInit ();
}});
