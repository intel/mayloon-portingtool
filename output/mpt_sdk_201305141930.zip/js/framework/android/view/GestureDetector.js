﻿Clazz.declarePackage ("android.view");
Clazz.load (null, "android.view.GestureDetector", ["android.view.MotionEvent"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mListener = null;
this.mContext = null;
this.mCurrentDownEvent = null;
this.mPreviousUpEvent = null;
Clazz.instantialize (this, arguments);
}, android.view, "GestureDetector");
Clazz.makeConstructor (c$, 
function (context, listener) {
}, "android.content.Context,android.view.GestureDetector.OnGestureListener");
Clazz.makeConstructor (c$, 
function (context, listener, handler) {
}, "android.content.Context,android.view.GestureDetector.OnGestureListener,android.os.Handler");
Clazz.makeConstructor (c$, 
function (context, listener) {
this.mContext = context;
this.mListener = listener;
}, "android.content.Context,android.view.GestureDetector.SimpleOnGestureListener");
Clazz.defineMethod (c$, "onTouchEvent", 
function (ev) {
var action = ev.getAction ();
var handled = false;
switch (action & 255) {
case 5:
break;
case 6:
break;
case 0:
this.mCurrentDownEvent = android.view.MotionEvent.obtain (ev);
handled = new Boolean (handled | this.mListener.onDown (ev)).valueOf ();
break;
case 2:
break;
case 1:
var currentUpEvent = android.view.MotionEvent.obtain (ev);
handled = this.mListener.onFling (this.mCurrentDownEvent, ev, ev.getX () - this.mCurrentDownEvent.getX (), ev.getY () - this.mCurrentDownEvent.getY ());
this.mPreviousUpEvent = currentUpEvent;
break;
case 3:
}
return handled;
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "setIsLongpressEnabled", 
function (isLongpressEnabled) {
console.log("Missing method: setIsLongpressEnabled");
}, "~B");
Clazz.defineMethod (c$, "isLongpressEnabled", 
function () {
console.log("Missing method: isLongpressEnabled");
});
Clazz.defineMethod (c$, "setOnDoubleTapListener", 
function (onDoubleTapListener) {
console.log("Missing method: setOnDoubleTapListener");
}, "~O");
Clazz.declareInterface (android.view.GestureDetector, "OnGestureListener");
Clazz.pu$h ();
c$ = Clazz.declareType (android.view.GestureDetector, "SimpleOnGestureListener");
Clazz.defineMethod (c$, "onFling", 
function (a, b, c, d) {
return false;
}, "android.view.MotionEvent,android.view.MotionEvent,~N,~N");
Clazz.defineMethod (c$, "onDown", 
function (a) {
return true;
}, "android.view.MotionEvent");
c$ = Clazz.p0p ();
});
