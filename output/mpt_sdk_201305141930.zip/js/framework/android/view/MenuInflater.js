﻿Clazz.declarePackage ("android.view");
Clazz.load (null, "android.view.MenuInflater", ["android.util.Xml", "android.view.InflateException", "com.android.internal.R", "java.lang.NullPointerException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mContext = null;
if (!Clazz.isClassDefined ("android.view.MenuInflater.MenuState")) {
android.view.MenuInflater.$MenuInflater$MenuState$ ();
}
Clazz.instantialize (this, arguments);
}, android.view, "MenuInflater");
Clazz.makeConstructor (c$, 
function (context) {
this.mContext = context;
}, "android.content.Context");
Clazz.defineMethod (c$, "inflate", 
function (menuRes, menu) {
var parser = null;
try {
parser = this.mContext.getResources ().getLayout (menuRes);
var attrs = android.util.Xml.asAttributeSet (parser);
this.parseMenu (parser, attrs, menu);
} catch (e$$) {
if (Clazz.instanceOf (e$$, org.xmlpull.v1.XmlPullParserException)) {
var e = e$$;
{
throw  new android.view.InflateException ("Error inflating menu XML", e);
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var e = e$$;
{
throw  new android.view.InflateException ("Error inflating menu XML", e);
}
} else {
throw e$$;
}
} finally {
if (parser != null) parser.close ();
}
}, "~N,android.view.Menu");
Clazz.defineMethod (c$, "parseMenu", 
($fz = function (parser, attrs, menu) {
var menuState = Clazz.innerTypeInstance (android.view.MenuInflater.MenuState, this, null, menu);
var eventType = parser.getEventType ();
var tagName;
var lookingForEndOfUnknownTag = false;
var unknownTagName = null;
do {
if (eventType == 2) {
tagName = parser.getName ();
if (tagName.equals ("menu")) {
eventType = parser.next ();
break;
}throw  new RuntimeException ("Expecting menu, got " + tagName);
}eventType = parser.next ();
} while (eventType != 1);
var reachedEndOfMenu = false;
while (!reachedEndOfMenu) {
switch (eventType) {
case 2:
if (lookingForEndOfUnknownTag) {
break;
}tagName = parser.getName ();
if (tagName.equals ("group")) {
menuState.readGroup (attrs);
} else if (tagName.equals ("item")) {
menuState.readItem (attrs);
} else if (tagName.equals ("menu")) {
var subMenu = menuState.addSubMenuItem ();
this.parseMenu (parser, attrs, subMenu);
} else {
lookingForEndOfUnknownTag = true;
unknownTagName = tagName;
}break;
case 3:
tagName = parser.getName ();
if (lookingForEndOfUnknownTag && tagName.equals (unknownTagName)) {
lookingForEndOfUnknownTag = false;
unknownTagName = null;
} else if (tagName.equals ("group")) {
menuState.resetGroup ();
} else if (tagName.equals ("item")) {
if (!menuState.hasAddedItem ()) {
menuState.addItem ();
}} else if (tagName.equals ("menu")) {
reachedEndOfMenu = true;
}break;
case 1:
throw  new RuntimeException ("Unexpected end of document");
}
eventType = parser.next ();
}
}, $fz.isPrivate = true, $fz), "org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,android.view.Menu");
c$.$MenuInflater$MenuState$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.menu = null;
this.groupId = 0;
this.groupCategory = 0;
this.groupOrder = 0;
this.groupCheckable = 0;
this.groupVisible = false;
this.groupEnabled = false;
this.itemAdded = false;
this.itemId = 0;
this.itemCategoryOrder = 0;
this.itemTitle = null;
this.itemTitleCondensed = null;
this.itemIconResId = 0;
this.itemCheckable = 0;
this.itemChecked = false;
this.itemVisible = false;
this.itemEnabled = false;
Clazz.instantialize (this, arguments);
}, android.view.MenuInflater, "MenuState");
Clazz.makeConstructor (c$, 
function (a) {
this.menu = a;
this.resetGroup ();
}, "android.view.Menu");
Clazz.defineMethod (c$, "resetGroup", 
function () {
this.groupId = 0;
this.groupCategory = 0;
this.groupOrder = 0;
this.groupCheckable = 0;
this.groupVisible = true;
this.groupEnabled = true;
});
Clazz.defineMethod (c$, "readGroup", 
function (a) {
var b = this.b$["android.view.MenuInflater"].mContext.obtainStyledAttributes (a, com.android.internal.R.styleable.MenuGroup);
this.groupId = b.getResourceId (1, 0);
this.groupCategory = b.getInt (3, 0);
this.groupOrder = b.getInt (4, 0);
this.groupCheckable = b.getInt (5, 0);
this.groupVisible = b.getBoolean (2, true);
this.groupEnabled = b.getBoolean (0, true);
b.recycle ();
}, "android.util.AttributeSet");
Clazz.defineMethod (c$, "readItem", 
function (a) {
var b = this.b$["android.view.MenuInflater"].mContext.obtainStyledAttributes (a, com.android.internal.R.styleable.MenuItem);
this.itemId = b.getResourceId (2, 0);
var c = b.getInt (5, this.groupCategory);
var d = b.getInt (6, this.groupOrder);
this.itemCategoryOrder = (c & -65536) | (d & 65535);
this.itemTitle = b.getString (7);
this.itemTitleCondensed = b.getString (8);
this.itemIconResId = b.getResourceId (0, 0);
if (b.hasValue (11)) {
this.itemCheckable = b.getBoolean (11, false) ? 1 : 0;
} else {
this.itemCheckable = this.groupCheckable;
}this.itemChecked = b.getBoolean (3, false);
this.itemVisible = b.getBoolean (4, this.groupVisible);
this.itemEnabled = b.getBoolean (1, this.groupEnabled);
b.recycle ();
this.itemAdded = false;
}, "android.util.AttributeSet");
Clazz.defineMethod (c$, "setItem", 
($fz = function (a) {
a.setChecked (this.itemChecked).setVisible (this.itemVisible).setEnabled (this.itemEnabled).setCheckable (this.itemCheckable >= 1).setTitleCondensed (this.itemTitleCondensed).setIcon (this.itemIconResId);
if (this.itemCheckable >= 2) {
(a).setExclusiveCheckable (true);
}}, $fz.isPrivate = true, $fz), "android.view.MenuItem");
Clazz.defineMethod (c$, "addItem", 
function () {
if (this.menu == null) {
throw  new NullPointerException ("MenuInflater.MenuState.menu is null");
}this.itemAdded = true;
this.setItem (this.menu.add (this.groupId, this.itemId, this.itemCategoryOrder, this.itemTitle));
});
Clazz.defineMethod (c$, "addSubMenuItem", 
function () {
if (this.menu == null) {
throw  new NullPointerException ("MenuInflater.MenuState.menu is null");
}this.itemAdded = true;
var a = this.menu.addSubMenu (this.groupId, this.itemId, this.itemCategoryOrder, this.itemTitle);
this.setItem (a.getItem ());
return a;
});
Clazz.defineMethod (c$, "hasAddedItem", 
function () {
return this.itemAdded;
});
Clazz.defineStatics (c$,
"defaultGroupId", 0,
"defaultItemId", 0,
"defaultItemCategory", 0,
"defaultItemOrder", 0,
"defaultItemCheckable", 0,
"defaultItemChecked", false,
"defaultItemVisible", true,
"defaultItemEnabled", true);
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"XML_MENU", "menu",
"XML_GROUP", "group",
"XML_ITEM", "item",
"NO_ID", 0);
});
