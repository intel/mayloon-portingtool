﻿Clazz.declarePackage ("android.view");
Clazz.declareInterface (android.view, "ViewManager");
