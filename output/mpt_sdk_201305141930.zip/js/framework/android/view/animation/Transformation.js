﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (null, "android.view.animation.Transformation", ["android.graphics.Matrix", "java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mMatrix = null;
this.mAlpha = 0;
this.mTransformationType = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "Transformation");
Clazz.makeConstructor (c$, 
function () {
this.clear ();
});
Clazz.defineMethod (c$, "clear", 
function () {
if (this.mMatrix == null) {
this.mMatrix =  new android.graphics.Matrix ();
} else {
this.mMatrix.reset ();
}this.mAlpha = 1.0;
this.mTransformationType = android.view.animation.Transformation.TYPE_BOTH;
});
Clazz.defineMethod (c$, "getTransformationType", 
function () {
return this.mTransformationType;
});
Clazz.defineMethod (c$, "setTransformationType", 
function (transformationType) {
this.mTransformationType = transformationType;
}, "~N");
Clazz.defineMethod (c$, "set", 
function (t) {
this.mAlpha = t.getAlpha ();
this.mMatrix.set (t.getMatrix ());
this.mTransformationType = t.getTransformationType ();
}, "android.view.animation.Transformation");
Clazz.defineMethod (c$, "compose", 
function (t) {
this.mAlpha *= t.getAlpha ();
this.mMatrix.preConcat (t.getMatrix ());
}, "android.view.animation.Transformation");
Clazz.defineMethod (c$, "getMatrix", 
function () {
return this.mMatrix;
});
Clazz.defineMethod (c$, "setAlpha", 
function (alpha) {
this.mAlpha = alpha;
}, "~N");
Clazz.defineMethod (c$, "getAlpha", 
function () {
return this.mAlpha;
});
Clazz.overrideMethod (c$, "toString", 
function () {
var sb =  new StringBuilder (64);
sb.append ("Transformation");
this.toShortString (sb);
return sb.toString ();
});
Clazz.defineMethod (c$, "toShortString", 
function () {
var sb =  new StringBuilder (64);
this.toShortString (sb);
return sb.toString ();
});
Clazz.defineMethod (c$, "toShortString", 
function (sb) {
sb.append ("{alpha=");
sb.append (this.mAlpha);
sb.append (" matrix=");
this.mMatrix.toShortString (sb);
sb.append ('}');
}, "StringBuilder");
Clazz.defineMethod (c$, "printShortString", 
function (pw) {
pw.print ("{alpha=");
pw.print (this.mAlpha);
pw.print (" matrix=");
this.mMatrix.printShortString (pw);
pw.print ('}');
}, "java.io.PrintWriter");
Clazz.defineStatics (c$,
"TYPE_IDENTITY", 0x0,
"TYPE_ALPHA", 0x1,
"TYPE_MATRIX", 0x2);
c$.TYPE_BOTH = c$.prototype.TYPE_BOTH = android.view.animation.Transformation.TYPE_ALPHA | android.view.animation.Transformation.TYPE_MATRIX;
});
