﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Interpolator"], "android.view.animation.LinearInterpolator", null, function () {
c$ = Clazz.declareType (android.view.animation, "LinearInterpolator", null, android.view.animation.Interpolator);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (context, attrs) {
}, "android.content.Context,android.util.AttributeSet");
Clazz.overrideMethod (c$, "getInterpolation", 
function (input) {
return input;
}, "~N");
});
