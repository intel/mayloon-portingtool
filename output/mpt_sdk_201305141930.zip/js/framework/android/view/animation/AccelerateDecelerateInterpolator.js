﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Interpolator"], "android.view.animation.AccelerateDecelerateInterpolator", null, function () {
c$ = Clazz.declareType (android.view.animation, "AccelerateDecelerateInterpolator", null, android.view.animation.Interpolator);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (context, attrs) {
}, "android.content.Context,android.util.AttributeSet");
Clazz.overrideMethod (c$, "getInterpolation", 
function (input) {
return (Math.cos ((input + 1) * 3.141592653589793) / 2.0) + 0.5;
}, "~N");
});
