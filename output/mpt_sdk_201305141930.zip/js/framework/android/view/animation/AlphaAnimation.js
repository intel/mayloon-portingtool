﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Animation"], "android.view.animation.AlphaAnimation", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFromAlpha = 0;
this.mToAlpha = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "AlphaAnimation", android.view.animation.Animation);
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.view.animation.AlphaAnimation, [context, attrs]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.AlphaAnimation);
this.mFromAlpha = a.getFloat (0, 1.0);
this.mToAlpha = a.getFloat (1, 1.0);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (fromAlpha, toAlpha) {
Clazz.superConstructor (this, android.view.animation.AlphaAnimation, []);
this.mFromAlpha = fromAlpha;
this.mToAlpha = toAlpha;
}, "~N,~N");
Clazz.overrideMethod (c$, "applyTransformation", 
function (interpolatedTime, t) {
var alpha = this.mFromAlpha;
t.setAlpha (alpha + ((this.mToAlpha - alpha) * interpolatedTime));
}, "~N,android.view.animation.Transformation");
Clazz.overrideMethod (c$, "willChangeTransformationMatrix", 
function () {
return false;
});
Clazz.overrideMethod (c$, "willChangeBounds", 
function () {
return false;
});
});
