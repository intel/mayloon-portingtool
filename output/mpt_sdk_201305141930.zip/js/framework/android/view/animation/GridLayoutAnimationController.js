﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.LayoutAnimationController"], "android.view.animation.GridLayoutAnimationController", ["android.view.animation.Animation", "$.LinearInterpolator", "com.android.internal.R", "java.util.Random"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mColumnDelay = 0;
this.mRowDelay = 0;
this.mDirection = 0;
this.mDirectionPriority = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "GridLayoutAnimationController", android.view.animation.LayoutAnimationController);
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.view.animation.GridLayoutAnimationController, [context, attrs]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.GridLayoutAnimation);
var d = android.view.animation.Animation.Description.parseValue (a.peekValue (0));
this.mColumnDelay = d.value;
d = android.view.animation.Animation.Description.parseValue (a.peekValue (1));
this.mRowDelay = d.value;
this.mDirection = a.getInt (2, 0);
this.mDirectionPriority = a.getInt (3, 0);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (animation) {
this.construct (animation, 0.5, 0.5);
}, "android.view.animation.Animation");
Clazz.makeConstructor (c$, 
function (animation, columnDelay, rowDelay) {
Clazz.superConstructor (this, android.view.animation.GridLayoutAnimationController, [animation]);
this.mColumnDelay = columnDelay;
this.mRowDelay = rowDelay;
}, "android.view.animation.Animation,~N,~N");
Clazz.defineMethod (c$, "getColumnDelay", 
function () {
return this.mColumnDelay;
});
Clazz.defineMethod (c$, "setColumnDelay", 
function (columnDelay) {
this.mColumnDelay = columnDelay;
}, "~N");
Clazz.defineMethod (c$, "getRowDelay", 
function () {
return this.mRowDelay;
});
Clazz.defineMethod (c$, "setRowDelay", 
function (rowDelay) {
this.mRowDelay = rowDelay;
}, "~N");
Clazz.defineMethod (c$, "getDirection", 
function () {
return this.mDirection;
});
Clazz.defineMethod (c$, "setDirection", 
function (direction) {
this.mDirection = direction;
}, "~N");
Clazz.defineMethod (c$, "getDirectionPriority", 
function () {
return this.mDirectionPriority;
});
Clazz.defineMethod (c$, "setDirectionPriority", 
function (directionPriority) {
this.mDirectionPriority = directionPriority;
}, "~N");
Clazz.overrideMethod (c$, "willOverlap", 
function () {
return this.mColumnDelay < 1.0 || this.mRowDelay < 1.0;
});
Clazz.overrideMethod (c$, "getDelayForView", 
function (view) {
var lp = view.getLayoutParams ();
var params = lp.layoutAnimationParameters;
if (params == null) {
return 0;
}var column = this.getTransformedColumnIndex (params);
var row = this.getTransformedRowIndex (params);
var rowsCount = params.rowsCount;
var columnsCount = params.columnsCount;
var duration = this.mAnimation.getDuration ();
var columnDelay = this.mColumnDelay * duration;
var rowDelay = this.mRowDelay * duration;
var totalDelay;
var viewDelay;
if (this.mInterpolator == null) {
this.mInterpolator =  new android.view.animation.LinearInterpolator ();
}switch (this.mDirectionPriority) {
case 1:
viewDelay = Math.round ((row * rowDelay + column * rowsCount * rowDelay));
totalDelay = rowsCount * rowDelay + columnsCount * rowsCount * rowDelay;
break;
case 2:
viewDelay = Math.round ((column * columnDelay + row * columnsCount * columnDelay));
totalDelay = columnsCount * columnDelay + rowsCount * columnsCount * columnDelay;
break;
case 0:
default:
viewDelay = Math.round ((column * columnDelay + row * rowDelay));
totalDelay = columnsCount * columnDelay + rowsCount * rowDelay;
break;
}
var normalizedDelay = viewDelay / totalDelay;
normalizedDelay = this.mInterpolator.getInterpolation (normalizedDelay);
return Math.round ((normalizedDelay * totalDelay));
}, "android.view.View");
Clazz.defineMethod (c$, "getTransformedColumnIndex", 
($fz = function (params) {
var index;
switch (this.getOrder ()) {
case 1:
index = params.columnsCount - 1 - params.column;
break;
case 2:
if (this.mRandomizer == null) {
this.mRandomizer =  new java.util.Random ();
}index = Math.round ((params.columnsCount * this.mRandomizer.nextFloat ()));
break;
case 0:
default:
index = params.column;
break;
}
var direction = this.mDirection & 1;
if (direction == 1) {
index = params.columnsCount - 1 - index;
}return index;
}, $fz.isPrivate = true, $fz), "android.view.animation.GridLayoutAnimationController.AnimationParameters");
Clazz.defineMethod (c$, "getTransformedRowIndex", 
($fz = function (params) {
var index;
switch (this.getOrder ()) {
case 1:
index = params.rowsCount - 1 - params.row;
break;
case 2:
if (this.mRandomizer == null) {
this.mRandomizer =  new java.util.Random ();
}index = Math.round ((params.rowsCount * this.mRandomizer.nextFloat ()));
break;
case 0:
default:
index = params.row;
break;
}
var direction = this.mDirection & 2;
if (direction == 2) {
index = params.rowsCount - 1 - index;
}return index;
}, $fz.isPrivate = true, $fz), "android.view.animation.GridLayoutAnimationController.AnimationParameters");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.column = 0;
this.row = 0;
this.columnsCount = 0;
this.rowsCount = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation.GridLayoutAnimationController, "AnimationParameters", android.view.animation.LayoutAnimationController.AnimationParameters);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DIRECTION_LEFT_TO_RIGHT", 0x0,
"DIRECTION_RIGHT_TO_LEFT", 0x1,
"DIRECTION_TOP_TO_BOTTOM", 0x0,
"DIRECTION_BOTTOM_TO_TOP", 0x2,
"DIRECTION_HORIZONTAL_MASK", 0x1,
"DIRECTION_VERTICAL_MASK", 0x2,
"PRIORITY_NONE", 0,
"PRIORITY_COLUMN", 1,
"PRIORITY_ROW", 2);
});
