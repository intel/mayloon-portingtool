﻿Clazz.declarePackage ("android.view.animation");
Clazz.declareInterface (android.view.animation, "Interpolator");
