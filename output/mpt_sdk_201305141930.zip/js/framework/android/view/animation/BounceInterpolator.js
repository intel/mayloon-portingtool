﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Interpolator"], "android.view.animation.BounceInterpolator", null, function () {
c$ = Clazz.declareType (android.view.animation, "BounceInterpolator", null, android.view.animation.Interpolator);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (context, attrs) {
}, "android.content.Context,android.util.AttributeSet");
c$.bounce = Clazz.defineMethod (c$, "bounce", 
($fz = function (t) {
return t * t * 8.0;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.overrideMethod (c$, "getInterpolation", 
function (t) {
t *= 1.1226;
if (t < 0.3535) return android.view.animation.BounceInterpolator.bounce (t);
 else if (t < 0.7408) return android.view.animation.BounceInterpolator.bounce (t - 0.54719) + 0.7;
 else if (t < 0.9644) return android.view.animation.BounceInterpolator.bounce (t - 0.8526) + 0.9;
 else return android.view.animation.BounceInterpolator.bounce (t - 1.0435) + 0.95;
}, "~N");
});
