﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.graphics.RectF", "android.view.animation.Transformation"], "android.view.animation.Animation", ["android.util.TypedValue", "android.view.animation.AccelerateDecelerateInterpolator", "$.AnimationUtils", "com.android.internal.R", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mEnded = false;
this.mStarted = false;
this.mCycleFlip = false;
this.mInitialized = false;
this.mFillBefore = true;
this.mFillAfter = false;
this.mFillEnabled = false;
this.mStartTime = -1;
this.mStartOffset = 0;
this.mDuration = 0;
this.mRepeatCount = 0;
this.mRepeated = 0;
this.mRepeatMode = 1;
this.mInterpolator = null;
this.mListener = null;
this.mZAdjustment = 0;
this.mDetachWallpaper = false;
this.mMore = true;
this.mOneMoreTime = true;
this.mPreviousRegion = null;
this.mRegion = null;
this.mTransformation = null;
this.mPreviousTransformation = null;
Clazz.instantialize (this, arguments);
}, android.view.animation, "Animation", null, Cloneable);
Clazz.prepareFields (c$, function () {
this.mPreviousRegion =  new android.graphics.RectF ();
this.mRegion =  new android.graphics.RectF ();
this.mTransformation =  new android.view.animation.Transformation ();
this.mPreviousTransformation =  new android.view.animation.Transformation ();
});
Clazz.makeConstructor (c$, 
function () {
this.ensureInterpolator ();
});
Clazz.makeConstructor (c$, 
function (context, attrs) {
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.Animation);
this.setDuration (a.getInt (1, 0));
this.setStartOffset (a.getInt (4, 0));
this.setFillEnabled (a.getBoolean (8, this.mFillEnabled));
this.setFillBefore (a.getBoolean (2, this.mFillBefore));
this.setFillAfter (a.getBoolean (3, this.mFillAfter));
var resID = a.getResourceId (0, 0);
if (resID > 0) {
this.setInterpolator (context, resID);
}this.setRepeatCount (a.getInt (5, this.mRepeatCount));
this.setRepeatMode (a.getInt (6, 1));
this.setZAdjustment (a.getInt (7, 0));
this.setDetachWallpaper (a.getBoolean (9, false));
this.ensureInterpolator ();
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "clone", 
function () {
var animation = Clazz.superCall (this, android.view.animation.Animation, "clone", []);
animation.mPreviousRegion =  new android.graphics.RectF ();
animation.mRegion =  new android.graphics.RectF ();
animation.mTransformation =  new android.view.animation.Transformation ();
animation.mPreviousTransformation =  new android.view.animation.Transformation ();
return animation;
});
Clazz.defineMethod (c$, "reset", 
function () {
this.mPreviousRegion.setEmpty ();
this.mPreviousTransformation.clear ();
this.mInitialized = false;
this.mCycleFlip = false;
this.mRepeated = 0;
this.mMore = true;
this.mOneMoreTime = true;
});
Clazz.defineMethod (c$, "cancel", 
function () {
if (this.mStarted && !this.mEnded) {
if (this.mListener != null) this.mListener.onAnimationEnd (this);
this.mEnded = true;
}this.mStartTime = -9223372036854775808;
this.mMore = this.mOneMoreTime = false;
});
Clazz.defineMethod (c$, "detach", 
function () {
if (this.mStarted && !this.mEnded) {
this.mEnded = true;
if (this.mListener != null) this.mListener.onAnimationEnd (this);
}});
Clazz.defineMethod (c$, "isInitialized", 
function () {
return this.mInitialized;
});
Clazz.defineMethod (c$, "initialize", 
function (width, height, parentWidth, parentHeight) {
this.reset ();
this.mInitialized = true;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setInterpolator", 
function (context, resID) {
this.setInterpolator (android.view.animation.AnimationUtils.loadInterpolator (context, resID));
}, "android.content.Context,~N");
Clazz.defineMethod (c$, "setInterpolator", 
function (i) {
this.mInterpolator = i;
}, "android.view.animation.Interpolator");
Clazz.defineMethod (c$, "setStartOffset", 
function (startOffset) {
this.mStartOffset = startOffset;
}, "~N");
Clazz.defineMethod (c$, "setDuration", 
function (durationMillis) {
if (durationMillis < 0) {
throw  new IllegalArgumentException ("Animation duration cannot be negative");
}this.mDuration = durationMillis;
}, "~N");
Clazz.defineMethod (c$, "restrictDuration", 
function (durationMillis) {
if (this.mStartOffset > durationMillis) {
this.mStartOffset = durationMillis;
this.mDuration = 0;
this.mRepeatCount = 0;
return ;
}var dur = this.mDuration + this.mStartOffset;
if (dur > durationMillis) {
this.mDuration = durationMillis - this.mStartOffset;
dur = durationMillis;
}if (this.mDuration <= 0) {
this.mDuration = 0;
this.mRepeatCount = 0;
return ;
}if (this.mRepeatCount < 0 || this.mRepeatCount > durationMillis || (dur * this.mRepeatCount) > durationMillis) {
this.mRepeatCount = (Math.floor (durationMillis / dur)) - 1;
if (this.mRepeatCount < 0) {
this.mRepeatCount = 0;
}}}, "~N");
Clazz.defineMethod (c$, "scaleCurrentDuration", 
function (scale) {
this.mDuration = Math.round ((this.mDuration * scale));
}, "~N");
Clazz.defineMethod (c$, "setStartTime", 
function (startTimeMillis) {
this.mStartTime = startTimeMillis;
this.mStarted = this.mEnded = false;
this.mCycleFlip = false;
this.mRepeated = 0;
this.mMore = true;
}, "~N");
Clazz.defineMethod (c$, "start", 
function () {
this.setStartTime (-1);
});
Clazz.defineMethod (c$, "startNow", 
function () {
this.setStartTime (android.view.animation.AnimationUtils.currentAnimationTimeMillis ());
});
Clazz.defineMethod (c$, "setRepeatMode", 
function (repeatMode) {
this.mRepeatMode = repeatMode;
}, "~N");
Clazz.defineMethod (c$, "setRepeatCount", 
function (repeatCount) {
if (repeatCount < 0) {
repeatCount = -1;
}this.mRepeatCount = repeatCount;
}, "~N");
Clazz.defineMethod (c$, "isFillEnabled", 
function () {
return this.mFillEnabled;
});
Clazz.defineMethod (c$, "setFillEnabled", 
function (fillEnabled) {
this.mFillEnabled = fillEnabled;
}, "~B");
Clazz.defineMethod (c$, "setFillBefore", 
function (fillBefore) {
this.mFillBefore = fillBefore;
}, "~B");
Clazz.defineMethod (c$, "setFillAfter", 
function (fillAfter) {
this.mFillAfter = fillAfter;
}, "~B");
Clazz.defineMethod (c$, "setZAdjustment", 
function (zAdjustment) {
this.mZAdjustment = zAdjustment;
}, "~N");
Clazz.defineMethod (c$, "setDetachWallpaper", 
function (detachWallpaper) {
this.mDetachWallpaper = detachWallpaper;
}, "~B");
Clazz.defineMethod (c$, "getInterpolator", 
function () {
return this.mInterpolator;
});
Clazz.defineMethod (c$, "getStartTime", 
function () {
return this.mStartTime;
});
Clazz.defineMethod (c$, "getDuration", 
function () {
return this.mDuration;
});
Clazz.defineMethod (c$, "getStartOffset", 
function () {
return this.mStartOffset;
});
Clazz.defineMethod (c$, "getRepeatMode", 
function () {
return this.mRepeatMode;
});
Clazz.defineMethod (c$, "getRepeatCount", 
function () {
return this.mRepeatCount;
});
Clazz.defineMethod (c$, "getFillBefore", 
function () {
return this.mFillBefore;
});
Clazz.defineMethod (c$, "getFillAfter", 
function () {
return this.mFillAfter;
});
Clazz.defineMethod (c$, "getZAdjustment", 
function () {
return this.mZAdjustment;
});
Clazz.defineMethod (c$, "getDetachWallpaper", 
function () {
return this.mDetachWallpaper;
});
Clazz.defineMethod (c$, "willChangeTransformationMatrix", 
function () {
return true;
});
Clazz.defineMethod (c$, "willChangeBounds", 
function () {
return true;
});
Clazz.defineMethod (c$, "setAnimationListener", 
function (listener) {
this.mListener = listener;
}, "android.view.animation.Animation.AnimationListener");
Clazz.defineMethod (c$, "ensureInterpolator", 
function () {
if (this.mInterpolator == null) {
this.mInterpolator =  new android.view.animation.AccelerateDecelerateInterpolator ();
}});
Clazz.defineMethod (c$, "computeDurationHint", 
function () {
return (this.getStartOffset () + this.getDuration ()) * (this.getRepeatCount () + 1);
});
Clazz.defineMethod (c$, "getTransformation", 
function (currentTime, outTransformation) {
if (this.mStartTime == -1) {
this.mStartTime = currentTime;
}var startOffset = this.getStartOffset ();
var duration = this.mDuration;
var normalizedTime;
if (duration != 0) {
normalizedTime = ((currentTime - (this.mStartTime + startOffset))) / duration;
} else {
normalizedTime = currentTime < this.mStartTime ? 0.0 : 1.0;
}var expired = normalizedTime >= 1.0;
this.mMore = !expired;
if (!this.mFillEnabled) normalizedTime = Math.max (Math.min (normalizedTime, 1.0), 0.0);
if ((normalizedTime >= 0.0 || this.mFillBefore) && (normalizedTime <= 1.0 || this.mFillAfter)) {
if (!this.mStarted) {
if (this.mListener != null) {
this.mListener.onAnimationStart (this);
}this.mStarted = true;
}if (this.mFillEnabled) normalizedTime = Math.max (Math.min (normalizedTime, 1.0), 0.0);
if (this.mCycleFlip) {
normalizedTime = 1.0 - normalizedTime;
}var interpolatedTime = this.mInterpolator.getInterpolation (normalizedTime);
this.applyTransformation (interpolatedTime, outTransformation);
}if (expired) {
if (this.mRepeatCount == this.mRepeated) {
if (!this.mEnded) {
this.mEnded = true;
if (this.mListener != null) {
this.mListener.onAnimationEnd (this);
}}} else {
if (this.mRepeatCount > 0) {
this.mRepeated++;
}if (this.mRepeatMode == 2) {
this.mCycleFlip = !this.mCycleFlip;
}this.mStartTime = -1;
this.mMore = true;
if (this.mListener != null) {
this.mListener.onAnimationRepeat (this);
}}}if (!this.mMore && this.mOneMoreTime) {
this.mOneMoreTime = false;
return true;
}return this.mMore;
}, "~N,android.view.animation.Transformation");
Clazz.defineMethod (c$, "hasStarted", 
function () {
return this.mStarted;
});
Clazz.defineMethod (c$, "hasEnded", 
function () {
return this.mEnded;
});
Clazz.defineMethod (c$, "applyTransformation", 
function (interpolatedTime, t) {
}, "~N,android.view.animation.Transformation");
Clazz.defineMethod (c$, "resolveSize", 
function (type, value, size, parentSize) {
switch (type) {
case 0:
return value;
case 1:
return size * value;
case 2:
return parentSize * value;
default:
return value;
}
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "getInvalidateRegion", 
function (left, top, right, bottom, invalidate, transformation) {
var tempRegion = this.mRegion;
var previousRegion = this.mPreviousRegion;
invalidate.set (left, top, right, bottom);
transformation.getMatrix ().mapRect (invalidate);
invalidate.inset (-1.0, -1.0);
tempRegion.set (invalidate);
invalidate.union (previousRegion);
previousRegion.set (tempRegion);
var tempTransformation = this.mTransformation;
var previousTransformation = this.mPreviousTransformation;
tempTransformation.set (transformation);
transformation.set (previousTransformation);
previousTransformation.set (tempTransformation);
}, "~N,~N,~N,~N,android.graphics.RectF,android.view.animation.Transformation");
Clazz.defineMethod (c$, "initializeInvalidateRegion", 
function (left, top, right, bottom) {
var region = this.mPreviousRegion;
region.set (left, top, right, bottom);
region.inset (-1.0, -1.0);
if (this.mFillBefore) {
var previousTransformation = this.mPreviousTransformation;
this.applyTransformation (this.mInterpolator.getInterpolation (0.0), previousTransformation);
}}, "~N,~N,~N,~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.type = 0;
this.value = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation.Animation, "Description");
c$.parseValue = Clazz.defineMethod (c$, "parseValue", 
function (a) {
var b =  new android.view.animation.Animation.Description ();
if (a == null) {
b.type = 0;
b.value = 0;
} else {
if (a.type == 6) {
b.type = (a.data & 15) == 1 ? 2 : 1;
b.value = android.util.TypedValue.complexToFloat (a.data);
return b;
} else if (a.type == 4) {
b.type = 0;
b.value = a.getFloat ();
return b;
} else if (a.type >= 16 && a.type <= 31) {
b.type = 0;
b.value = a.data;
return b;
}}b.type = 0;
b.value = 0.0;
return b;
}, "android.util.TypedValue");
c$ = Clazz.p0p ();
Clazz.declareInterface (android.view.animation.Animation, "AnimationListener");
Clazz.defineStatics (c$,
"INFINITE", -1,
"RESTART", 1,
"REVERSE", 2,
"START_ON_FIRST_FRAME", -1,
"ABSOLUTE", 0,
"RELATIVE_TO_SELF", 1,
"RELATIVE_TO_PARENT", 2,
"ZORDER_NORMAL", 0,
"ZORDER_TOP", 1,
"ZORDER_BOTTOM", -1);
});
