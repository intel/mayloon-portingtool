﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (null, "android.view.animation.LayoutAnimationController", ["android.view.animation.Animation", "$.AnimationUtils", "$.LinearInterpolator", "com.android.internal.R", "java.util.Random"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAnimation = null;
this.mRandomizer = null;
this.mInterpolator = null;
this.mDelay = 0;
this.mOrder = 0;
this.mDuration = 0;
this.mMaxDelay = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "LayoutAnimationController");
Clazz.makeConstructor (c$, 
function (context, attrs) {
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.LayoutAnimation);
var d = android.view.animation.Animation.Description.parseValue (a.peekValue (1));
this.mDelay = d.value;
this.mOrder = a.getInt (3, 0);
var resource = a.getResourceId (2, 0);
if (resource > 0) {
this.setAnimation (context, resource);
}resource = a.getResourceId (0, 0);
if (resource > 0) {
this.setInterpolator (context, resource);
}a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (animation) {
this.construct (animation, 0.5);
}, "android.view.animation.Animation");
Clazz.makeConstructor (c$, 
function (animation, delay) {
this.mDelay = delay;
this.setAnimation (animation);
}, "android.view.animation.Animation,~N");
Clazz.defineMethod (c$, "getOrder", 
function () {
return this.mOrder;
});
Clazz.defineMethod (c$, "setOrder", 
function (order) {
this.mOrder = order;
}, "~N");
Clazz.defineMethod (c$, "setAnimation", 
function (context, resourceID) {
this.setAnimation (android.view.animation.AnimationUtils.loadAnimation (context, resourceID));
}, "android.content.Context,~N");
Clazz.defineMethod (c$, "setAnimation", 
function (animation) {
this.mAnimation = animation;
this.mAnimation.setFillBefore (true);
}, "android.view.animation.Animation");
Clazz.defineMethod (c$, "getAnimation", 
function () {
return this.mAnimation;
});
Clazz.defineMethod (c$, "setInterpolator", 
function (context, resourceID) {
this.setInterpolator (android.view.animation.AnimationUtils.loadInterpolator (context, resourceID));
}, "android.content.Context,~N");
Clazz.defineMethod (c$, "setInterpolator", 
function (interpolator) {
this.mInterpolator = interpolator;
}, "android.view.animation.Interpolator");
Clazz.defineMethod (c$, "getInterpolator", 
function () {
return this.mInterpolator;
});
Clazz.defineMethod (c$, "getDelay", 
function () {
return this.mDelay;
});
Clazz.defineMethod (c$, "setDelay", 
function (delay) {
this.mDelay = delay;
}, "~N");
Clazz.defineMethod (c$, "willOverlap", 
function () {
return this.mDelay < 1.0;
});
Clazz.defineMethod (c$, "start", 
function () {
this.mDuration = this.mAnimation.getDuration ();
this.mMaxDelay = -9223372036854775808;
this.mAnimation.setStartTime (-1);
});
Clazz.defineMethod (c$, "getAnimationForView", 
function (view) {
var delay = this.getDelayForView (view) + this.mAnimation.getStartOffset ();
this.mMaxDelay = Math.max (this.mMaxDelay, delay);
try {
var animation = this.mAnimation.clone ();
animation.setStartOffset (delay);
return animation;
} catch (e) {
if (Clazz.instanceOf (e, CloneNotSupportedException)) {
return null;
} else {
throw e;
}
}
}, "android.view.View");
Clazz.defineMethod (c$, "isDone", 
function () {
return android.view.animation.AnimationUtils.currentAnimationTimeMillis () > this.mAnimation.getStartTime () + this.mMaxDelay + this.mDuration;
});
Clazz.defineMethod (c$, "getDelayForView", 
function (view) {
var lp = view.getLayoutParams ();
var params = lp.layoutAnimationParameters;
if (params == null) {
return 0;
}var delay = this.mDelay * this.mAnimation.getDuration ();
var viewDelay = Math.round ((this.getTransformedIndex (params) * delay));
var totalDelay = delay * params.count;
if (this.mInterpolator == null) {
this.mInterpolator =  new android.view.animation.LinearInterpolator ();
}var normalizedDelay = viewDelay / totalDelay;
normalizedDelay = this.mInterpolator.getInterpolation (normalizedDelay);
return Math.round ((normalizedDelay * totalDelay));
}, "android.view.View");
Clazz.defineMethod (c$, "getTransformedIndex", 
function (params) {
switch (this.getOrder ()) {
case 1:
return params.count - 1 - params.index;
case 2:
if (this.mRandomizer == null) {
this.mRandomizer =  new java.util.Random ();
}return Math.round ((params.count * this.mRandomizer.nextFloat ()));
case 0:
default:
return params.index;
}
}, "android.view.animation.LayoutAnimationController.AnimationParameters");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.count = 0;
this.index = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation.LayoutAnimationController, "AnimationParameters");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"ORDER_NORMAL", 0,
"ORDER_REVERSE", 1,
"ORDER_RANDOM", 2);
});
