﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Animation", "$.Transformation", "java.util.ArrayList"], "android.view.animation.AnimationSet", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFlags = 0;
this.mAnimations = null;
this.mTempTransformation = null;
this.mLastEnd = 0;
this.mStoredOffsets = null;
Clazz.instantialize (this, arguments);
}, android.view.animation, "AnimationSet", android.view.animation.Animation);
Clazz.prepareFields (c$, function () {
this.mAnimations =  new java.util.ArrayList ();
this.mTempTransformation =  new android.view.animation.Transformation ();
});
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.view.animation.AnimationSet, [context, attrs]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.AnimationSet);
this.setFlag (16, a.getBoolean (0, true));
this.init ();
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (shareInterpolator) {
Clazz.superConstructor (this, android.view.animation.AnimationSet, []);
this.setFlag (16, shareInterpolator);
this.init ();
}, "~B");
Clazz.defineMethod (c$, "clone", 
function () {
var animation = Clazz.superCall (this, android.view.animation.AnimationSet, "clone", []);
animation.mTempTransformation =  new android.view.animation.Transformation ();
animation.mAnimations =  new java.util.ArrayList ();
var count = this.mAnimations.size ();
var animations = this.mAnimations;
for (var i = 0; i < count; i++) {
animation.mAnimations.add (animations.get (i).clone ());
}
return animation;
});
Clazz.defineMethod (c$, "setFlag", 
($fz = function (mask, value) {
if (value) {
this.mFlags |= mask;
} else {
this.mFlags &= ~mask;
}}, $fz.isPrivate = true, $fz), "~N,~B");
Clazz.defineMethod (c$, "init", 
($fz = function () {
this.mStartTime = 0;
this.mDuration = 0;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setFillAfter", 
function (fillAfter) {
this.mFlags |= 1;
Clazz.superCall (this, android.view.animation.AnimationSet, "setFillAfter", [fillAfter]);
}, "~B");
Clazz.defineMethod (c$, "setFillBefore", 
function (fillBefore) {
this.mFlags |= 2;
Clazz.superCall (this, android.view.animation.AnimationSet, "setFillBefore", [fillBefore]);
}, "~B");
Clazz.defineMethod (c$, "setRepeatMode", 
function (repeatMode) {
this.mFlags |= 4;
Clazz.superCall (this, android.view.animation.AnimationSet, "setRepeatMode", [repeatMode]);
}, "~N");
Clazz.defineMethod (c$, "setStartOffset", 
function (startOffset) {
this.mFlags |= 8;
Clazz.superCall (this, android.view.animation.AnimationSet, "setStartOffset", [startOffset]);
}, "~N");
Clazz.defineMethod (c$, "setDuration", 
function (durationMillis) {
this.mFlags |= 32;
Clazz.superCall (this, android.view.animation.AnimationSet, "setDuration", [durationMillis]);
}, "~N");
Clazz.defineMethod (c$, "addAnimation", 
function (a) {
this.mAnimations.add (a);
var noMatrix = (this.mFlags & 64) == 0;
if (noMatrix && a.willChangeTransformationMatrix ()) {
this.mFlags |= 64;
}var changeBounds = (this.mFlags & 128) == 0;
if (changeBounds && a.willChangeTransformationMatrix ()) {
this.mFlags |= 128;
}if (this.mAnimations.size () == 1) {
this.mDuration = a.getStartOffset () + a.getDuration ();
this.mLastEnd = this.mStartOffset + this.mDuration;
} else {
this.mLastEnd = Math.max (this.mLastEnd, a.getStartOffset () + a.getDuration ());
this.mDuration = this.mLastEnd - this.mStartOffset;
}}, "android.view.animation.Animation");
Clazz.defineMethod (c$, "setStartTime", 
function (startTimeMillis) {
Clazz.superCall (this, android.view.animation.AnimationSet, "setStartTime", [startTimeMillis]);
var count = this.mAnimations.size ();
var animations = this.mAnimations;
for (var i = 0; i < count; i++) {
var a = animations.get (i);
a.setStartTime (startTimeMillis);
}
}, "~N");
Clazz.defineMethod (c$, "getStartTime", 
function () {
var startTime = 9223372036854775807;
var count = this.mAnimations.size ();
var animations = this.mAnimations;
for (var i = 0; i < count; i++) {
var a = animations.get (i);
startTime = Math.min (startTime, a.getStartTime ());
}
return startTime;
});
Clazz.defineMethod (c$, "restrictDuration", 
function (durationMillis) {
Clazz.superCall (this, android.view.animation.AnimationSet, "restrictDuration", [durationMillis]);
var animations = this.mAnimations;
var count = animations.size ();
for (var i = 0; i < count; i++) {
animations.get (i).restrictDuration (durationMillis);
}
}, "~N");
Clazz.defineMethod (c$, "getDuration", 
function () {
var animations = this.mAnimations;
var count = animations.size ();
var duration = 0;
var durationSet = (this.mFlags & 32) == 32;
if (durationSet) {
duration = this.mDuration;
} else {
for (var i = 0; i < count; i++) {
duration = Math.max (duration, animations.get (i).getDuration ());
}
}return duration;
});
Clazz.defineMethod (c$, "computeDurationHint", 
function () {
var duration = 0;
var count = this.mAnimations.size ();
var animations = this.mAnimations;
for (var i = count - 1; i >= 0; --i) {
var d = animations.get (i).computeDurationHint ();
if (d > duration) duration = d;
}
return duration;
});
Clazz.overrideMethod (c$, "initializeInvalidateRegion", 
function (left, top, right, bottom) {
var region = this.mPreviousRegion;
region.set (left, top, right, bottom);
region.inset (-1.0, -1.0);
if (this.mFillBefore) {
var count = this.mAnimations.size ();
var animations = this.mAnimations;
var temp = this.mTempTransformation;
var previousTransformation = this.mPreviousTransformation;
for (var i = count - 1; i >= 0; --i) {
var a = animations.get (i);
temp.clear ();
var interpolator = a.mInterpolator;
a.applyTransformation (interpolator != null ? interpolator.getInterpolation (0.0) : 0.0, temp);
previousTransformation.compose (temp);
}
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "getTransformation", 
function (currentTime, t) {
var count = this.mAnimations.size ();
var animations = this.mAnimations;
var temp = this.mTempTransformation;
var more = false;
var started = false;
var ended = true;
t.clear ();
for (var i = count - 1; i >= 0; --i) {
var a = animations.get (i);
temp.clear ();
more = a.getTransformation (currentTime, temp) || more;
t.compose (temp);
started = started || a.hasStarted ();
ended = a.hasEnded () && ended;
}
if (started && !this.mStarted) {
if (this.mListener != null) {
this.mListener.onAnimationStart (this);
}this.mStarted = true;
}if (ended != this.mEnded) {
if (this.mListener != null) {
this.mListener.onAnimationEnd (this);
}this.mEnded = ended;
}return more;
}, "~N,android.view.animation.Transformation");
Clazz.defineMethod (c$, "scaleCurrentDuration", 
function (scale) {
var animations = this.mAnimations;
var count = animations.size ();
for (var i = 0; i < count; i++) {
animations.get (i).scaleCurrentDuration (scale);
}
}, "~N");
Clazz.defineMethod (c$, "initialize", 
function (width, height, parentWidth, parentHeight) {
Clazz.superCall (this, android.view.animation.AnimationSet, "initialize", [width, height, parentWidth, parentHeight]);
var durationSet = (this.mFlags & 32) == 32;
var fillAfterSet = (this.mFlags & 1) == 1;
var fillBeforeSet = (this.mFlags & 2) == 2;
var repeatModeSet = (this.mFlags & 4) == 4;
var shareInterpolator = (this.mFlags & 16) == 16;
var startOffsetSet = (this.mFlags & 8) == 8;
if (shareInterpolator) {
this.ensureInterpolator ();
}var children = this.mAnimations;
var count = children.size ();
var duration = this.mDuration;
var fillAfter = this.mFillAfter;
var fillBefore = this.mFillBefore;
var repeatMode = this.mRepeatMode;
var interpolator = this.mInterpolator;
var startOffset = this.mStartOffset;
var storedOffsets = this.mStoredOffsets;
if (startOffsetSet) {
if (storedOffsets == null || storedOffsets.length != count) {
storedOffsets = this.mStoredOffsets =  Clazz.newArray (count, 0);
}} else if (storedOffsets != null) {
storedOffsets = this.mStoredOffsets = null;
}for (var i = 0; i < count; i++) {
var a = children.get (i);
if (durationSet) {
a.setDuration (duration);
}if (fillAfterSet) {
a.setFillAfter (fillAfter);
}if (fillBeforeSet) {
a.setFillBefore (fillBefore);
}if (repeatModeSet) {
a.setRepeatMode (repeatMode);
}if (shareInterpolator) {
a.setInterpolator (interpolator);
}if (startOffsetSet) {
var offset = a.getStartOffset ();
a.setStartOffset (offset + startOffset);
storedOffsets[i] = offset;
}a.initialize (width, height, parentWidth, parentHeight);
}
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "reset", 
function () {
Clazz.superCall (this, android.view.animation.AnimationSet, "reset", []);
this.restoreChildrenStartOffset ();
});
Clazz.defineMethod (c$, "restoreChildrenStartOffset", 
function () {
var offsets = this.mStoredOffsets;
if (offsets == null) return ;
var children = this.mAnimations;
var count = children.size ();
for (var i = 0; i < count; i++) {
children.get (i).setStartOffset (offsets[i]);
}
});
Clazz.defineMethod (c$, "getAnimations", 
function () {
return this.mAnimations;
});
Clazz.defineMethod (c$, "willChangeTransformationMatrix", 
function () {
return (this.mFlags & 64) == 64;
});
Clazz.overrideMethod (c$, "willChangeBounds", 
function () {
return (this.mFlags & 128) == 128;
});
Clazz.defineStatics (c$,
"PROPERTY_FILL_AFTER_MASK", 0x1,
"PROPERTY_FILL_BEFORE_MASK", 0x2,
"PROPERTY_REPEAT_MODE_MASK", 0x4,
"PROPERTY_START_OFFSET_MASK", 0x8,
"PROPERTY_SHARE_INTERPOLATOR_MASK", 0x10,
"PROPERTY_DURATION_MASK", 0x20,
"PROPERTY_MORPH_MATRIX_MASK", 0x40,
"PROPERTY_CHANGE_BOUNDS_MASK", 0x80);
});
