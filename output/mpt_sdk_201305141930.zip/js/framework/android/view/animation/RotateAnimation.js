﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Animation"], "android.view.animation.RotateAnimation", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFromDegrees = 0;
this.mToDegrees = 0;
this.mPivotXType = 0;
this.mPivotYType = 0;
this.mPivotXValue = 0.0;
this.mPivotYValue = 0.0;
this.mPivotX = 0;
this.mPivotY = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "RotateAnimation", android.view.animation.Animation);
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.view.animation.RotateAnimation, [context, attrs]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.RotateAnimation);
this.mFromDegrees = a.getFloat (0, 0.0);
this.mToDegrees = a.getFloat (1, 0.0);
var d = android.view.animation.Animation.Description.parseValue (a.peekValue (2));
this.mPivotXType = d.type;
this.mPivotXValue = d.value;
d = android.view.animation.Animation.Description.parseValue (a.peekValue (3));
this.mPivotYType = d.type;
this.mPivotYValue = d.value;
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (fromDegrees, toDegrees) {
Clazz.superConstructor (this, android.view.animation.RotateAnimation, []);
this.mFromDegrees = fromDegrees;
this.mToDegrees = toDegrees;
this.mPivotX = 0.0;
this.mPivotY = 0.0;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (fromDegrees, toDegrees, pivotX, pivotY) {
Clazz.superConstructor (this, android.view.animation.RotateAnimation, []);
this.mFromDegrees = fromDegrees;
this.mToDegrees = toDegrees;
this.mPivotXType = 0;
this.mPivotYType = 0;
this.mPivotXValue = pivotX;
this.mPivotYValue = pivotY;
}, "~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (fromDegrees, toDegrees, pivotXType, pivotXValue, pivotYType, pivotYValue) {
Clazz.superConstructor (this, android.view.animation.RotateAnimation, []);
this.mFromDegrees = fromDegrees;
this.mToDegrees = toDegrees;
this.mPivotXValue = pivotXValue;
this.mPivotXType = pivotXType;
this.mPivotYValue = pivotYValue;
this.mPivotYType = pivotYType;
}, "~N,~N,~N,~N,~N,~N");
Clazz.overrideMethod (c$, "applyTransformation", 
function (interpolatedTime, t) {
var degrees = this.mFromDegrees + ((this.mToDegrees - this.mFromDegrees) * interpolatedTime);
if (this.mPivotX == 0.0 && this.mPivotY == 0.0) {
t.getMatrix ().setRotate (degrees);
} else {
t.getMatrix ().setRotate (degrees, this.mPivotX, this.mPivotY);
}}, "~N,android.view.animation.Transformation");
Clazz.defineMethod (c$, "initialize", 
function (width, height, parentWidth, parentHeight) {
Clazz.superCall (this, android.view.animation.RotateAnimation, "initialize", [width, height, parentWidth, parentHeight]);
this.mPivotX = this.resolveSize (this.mPivotXType, this.mPivotXValue, width, parentWidth);
this.mPivotY = this.resolveSize (this.mPivotYType, this.mPivotYValue, height, parentHeight);
}, "~N,~N,~N,~N");
});
