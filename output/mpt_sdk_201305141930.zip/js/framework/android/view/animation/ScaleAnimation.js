﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Animation"], "android.view.animation.ScaleAnimation", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFromX = 0;
this.mToX = 0;
this.mFromY = 0;
this.mToY = 0;
this.mPivotXType = 0;
this.mPivotYType = 0;
this.mPivotXValue = 0.0;
this.mPivotYValue = 0.0;
this.mPivotX = 0;
this.mPivotY = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "ScaleAnimation", android.view.animation.Animation);
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.view.animation.ScaleAnimation, [context, attrs]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.ScaleAnimation);
this.mFromX = a.getFloat (2, 0.0);
this.mToX = a.getFloat (3, 0.0);
this.mFromY = a.getFloat (4, 0.0);
this.mToY = a.getFloat (5, 0.0);
var d = android.view.animation.Animation.Description.parseValue (a.peekValue (0));
this.mPivotXType = d.type;
this.mPivotXValue = d.value;
d = android.view.animation.Animation.Description.parseValue (a.peekValue (1));
this.mPivotYType = d.type;
this.mPivotYValue = d.value;
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (fromX, toX, fromY, toY) {
Clazz.superConstructor (this, android.view.animation.ScaleAnimation, []);
this.mFromX = fromX;
this.mToX = toX;
this.mFromY = fromY;
this.mToY = toY;
this.mPivotX = 0;
this.mPivotY = 0;
}, "~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (fromX, toX, fromY, toY, pivotX, pivotY) {
Clazz.superConstructor (this, android.view.animation.ScaleAnimation, []);
this.mFromX = fromX;
this.mToX = toX;
this.mFromY = fromY;
this.mToY = toY;
this.mPivotXType = 0;
this.mPivotYType = 0;
this.mPivotXValue = pivotX;
this.mPivotYValue = pivotY;
}, "~N,~N,~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (fromX, toX, fromY, toY, pivotXType, pivotXValue, pivotYType, pivotYValue) {
Clazz.superConstructor (this, android.view.animation.ScaleAnimation, []);
this.mFromX = fromX;
this.mToX = toX;
this.mFromY = fromY;
this.mToY = toY;
this.mPivotXValue = pivotXValue;
this.mPivotXType = pivotXType;
this.mPivotYValue = pivotYValue;
this.mPivotYType = pivotYType;
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.overrideMethod (c$, "applyTransformation", 
function (interpolatedTime, t) {
var sx = 1.0;
var sy = 1.0;
if (this.mFromX != 1.0 || this.mToX != 1.0) {
sx = this.mFromX + ((this.mToX - this.mFromX) * interpolatedTime);
}if (this.mFromY != 1.0 || this.mToY != 1.0) {
sy = this.mFromY + ((this.mToY - this.mFromY) * interpolatedTime);
}if (this.mPivotX == 0 && this.mPivotY == 0) {
t.getMatrix ().setScale (sx, sy);
} else {
t.getMatrix ().setScale (sx, sy, this.mPivotX, this.mPivotY);
}}, "~N,android.view.animation.Transformation");
Clazz.defineMethod (c$, "initialize", 
function (width, height, parentWidth, parentHeight) {
Clazz.superCall (this, android.view.animation.ScaleAnimation, "initialize", [width, height, parentWidth, parentHeight]);
this.mPivotX = this.resolveSize (this.mPivotXType, this.mPivotXValue, width, parentWidth);
this.mPivotY = this.resolveSize (this.mPivotYType, this.mPivotYValue, height, parentHeight);
}, "~N,~N,~N,~N");
});
