﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Interpolator"], "android.view.animation.OvershootInterpolator", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mTension = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "OvershootInterpolator", null, android.view.animation.Interpolator);
Clazz.makeConstructor (c$, 
function () {
this.mTension = 2.0;
});
Clazz.makeConstructor (c$, 
function (tension) {
this.mTension = tension;
}, "~N");
Clazz.makeConstructor (c$, 
function (context, attrs) {
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.OvershootInterpolator);
this.mTension = a.getFloat (0, 2.0);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.overrideMethod (c$, "getInterpolation", 
function (t) {
t -= 1.0;
return t * t * ((this.mTension + 1) * t + this.mTension) + 1.0;
}, "~N");
});
