﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Interpolator"], "android.view.animation.AccelerateInterpolator", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFactor = 0;
this.mDoubleFactor = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "AccelerateInterpolator", null, android.view.animation.Interpolator);
Clazz.makeConstructor (c$, 
function () {
this.mFactor = 1.0;
this.mDoubleFactor = 2.0;
});
Clazz.makeConstructor (c$, 
function (factor) {
this.mFactor = factor;
this.mDoubleFactor = 2 * this.mFactor;
}, "~N");
Clazz.makeConstructor (c$, 
function (context, attrs) {
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.AccelerateInterpolator);
this.mFactor = a.getFloat (0, 1.0);
this.mDoubleFactor = 2 * this.mFactor;
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.overrideMethod (c$, "getInterpolation", 
function (input) {
if (this.mFactor == 1.0) {
return input * input;
} else {
return Math.pow (input, this.mDoubleFactor);
}}, "~N");
});
