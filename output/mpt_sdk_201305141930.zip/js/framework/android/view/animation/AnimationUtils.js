﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (null, "android.view.animation.AnimationUtils", ["android.content.res.Resources", "android.os.SystemClock", "android.util.Xml", "android.view.animation.AccelerateDecelerateInterpolator", "$.AccelerateInterpolator", "$.AlphaAnimation", "$.AnimationSet", "$.AnticipateInterpolator", "$.AnticipateOvershootInterpolator", "$.BounceInterpolator", "$.CycleInterpolator", "$.DecelerateInterpolator", "$.GridLayoutAnimationController", "$.LayoutAnimationController", "$.LinearInterpolator", "$.OvershootInterpolator", "$.RotateAnimation", "$.ScaleAnimation", "$.TranslateAnimation", "java.lang.RuntimeException"], function () {
c$ = Clazz.declareType (android.view.animation, "AnimationUtils");
c$.currentAnimationTimeMillis = Clazz.defineMethod (c$, "currentAnimationTimeMillis", 
function () {
return android.os.SystemClock.uptimeMillis ();
});
c$.loadAnimation = Clazz.defineMethod (c$, "loadAnimation", 
function (context, id) {
var parser = null;
try {
parser = context.getResources ().getAnimation (id);
return android.view.animation.AnimationUtils.createAnimationFromXml (context, parser);
} catch (e$$) {
if (Clazz.instanceOf (e$$, org.xmlpull.v1.XmlPullParserException)) {
var ex = e$$;
{
var rnf =  new android.content.res.Resources.NotFoundException ("Can't load animation resource ID #0x" + Integer.toHexString (id));
rnf.initCause (ex);
throw rnf;
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
var rnf =  new android.content.res.Resources.NotFoundException ("Can't load animation resource ID #0x" + Integer.toHexString (id));
rnf.initCause (ex);
throw rnf;
}
} else {
throw e$$;
}
} finally {
if (parser != null) parser.close ();
}
}, "android.content.Context,~N");
c$.createAnimationFromXml = Clazz.defineMethod (c$, "createAnimationFromXml", 
($fz = function (c, parser) {
return android.view.animation.AnimationUtils.createAnimationFromXml (c, parser, null, android.util.Xml.asAttributeSet (parser));
}, $fz.isPrivate = true, $fz), "android.content.Context,org.xmlpull.v1.XmlPullParser");
c$.createAnimationFromXml = Clazz.defineMethod (c$, "createAnimationFromXml", 
($fz = function (c, parser, parent, attrs) {
var anim = null;
var type;
var depth = parser.getDepth ();
while (((type = parser.next ()) != 3 || parser.getDepth () > depth) && type != 1) {
if (type != 2) {
continue ;}var name = parser.getName ();
if (name.equals ("set")) {
anim =  new android.view.animation.AnimationSet (c, attrs);
android.view.animation.AnimationUtils.createAnimationFromXml (c, parser, anim, attrs);
} else if (name.equals ("alpha")) {
anim =  new android.view.animation.AlphaAnimation (c, attrs);
} else if (name.equals ("scale")) {
anim =  new android.view.animation.ScaleAnimation (c, attrs);
} else if (name.equals ("rotate")) {
anim =  new android.view.animation.RotateAnimation (c, attrs);
} else if (name.equals ("translate")) {
anim =  new android.view.animation.TranslateAnimation (c, attrs);
} else {
throw  new RuntimeException ("Unknown animation name: " + parser.getName ());
}if (parent != null) {
parent.addAnimation (anim);
}}
return anim;
}, $fz.isPrivate = true, $fz), "android.content.Context,org.xmlpull.v1.XmlPullParser,android.view.animation.AnimationSet,android.util.AttributeSet");
c$.loadLayoutAnimation = Clazz.defineMethod (c$, "loadLayoutAnimation", 
function (context, id) {
var parser = null;
try {
parser = context.getResources ().getAnimation (id);
return android.view.animation.AnimationUtils.createLayoutAnimationFromXml (context, parser);
} catch (e$$) {
if (Clazz.instanceOf (e$$, org.xmlpull.v1.XmlPullParserException)) {
var ex = e$$;
{
var rnf =  new android.content.res.Resources.NotFoundException ("Can't load animation resource ID #0x" + Integer.toHexString (id));
rnf.initCause (ex);
throw rnf;
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
var rnf =  new android.content.res.Resources.NotFoundException ("Can't load animation resource ID #0x" + Integer.toHexString (id));
rnf.initCause (ex);
throw rnf;
}
} else {
throw e$$;
}
} finally {
if (parser != null) parser.close ();
}
}, "android.content.Context,~N");
c$.createLayoutAnimationFromXml = Clazz.defineMethod (c$, "createLayoutAnimationFromXml", 
($fz = function (c, parser) {
return android.view.animation.AnimationUtils.createLayoutAnimationFromXml (c, parser, android.util.Xml.asAttributeSet (parser));
}, $fz.isPrivate = true, $fz), "android.content.Context,org.xmlpull.v1.XmlPullParser");
c$.createLayoutAnimationFromXml = Clazz.defineMethod (c$, "createLayoutAnimationFromXml", 
($fz = function (c, parser, attrs) {
var controller = null;
var type;
var depth = parser.getDepth ();
while (((type = parser.next ()) != 3 || parser.getDepth () > depth) && type != 1) {
if (type != 2) {
continue ;}var name = parser.getName ();
if ("layoutAnimation".equals (name)) {
controller =  new android.view.animation.LayoutAnimationController (c, attrs);
} else if ("gridLayoutAnimation".equals (name)) {
controller =  new android.view.animation.GridLayoutAnimationController (c, attrs);
} else {
throw  new RuntimeException ("Unknown layout animation name: " + name);
}}
return controller;
}, $fz.isPrivate = true, $fz), "android.content.Context,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
c$.makeInAnimation = Clazz.defineMethod (c$, "makeInAnimation", 
function (c, fromLeft) {
var a;
if (fromLeft) {
a = android.view.animation.AnimationUtils.loadAnimation (c, 17432578);
} else {
a = android.view.animation.AnimationUtils.loadAnimation (c, 17432624);
}a.setInterpolator ( new android.view.animation.DecelerateInterpolator ());
a.setStartTime (android.view.animation.AnimationUtils.currentAnimationTimeMillis ());
return a;
}, "android.content.Context,~B");
c$.makeOutAnimation = Clazz.defineMethod (c$, "makeOutAnimation", 
function (c, toRight) {
var a;
if (toRight) {
a = android.view.animation.AnimationUtils.loadAnimation (c, 17432579);
} else {
a = android.view.animation.AnimationUtils.loadAnimation (c, 17432627);
}a.setInterpolator ( new android.view.animation.AccelerateInterpolator ());
a.setStartTime (android.view.animation.AnimationUtils.currentAnimationTimeMillis ());
return a;
}, "android.content.Context,~B");
c$.makeInChildBottomAnimation = Clazz.defineMethod (c$, "makeInChildBottomAnimation", 
function (c) {
var a;
a = android.view.animation.AnimationUtils.loadAnimation (c, 17432623);
a.setInterpolator ( new android.view.animation.AccelerateInterpolator ());
a.setStartTime (android.view.animation.AnimationUtils.currentAnimationTimeMillis ());
return a;
}, "android.content.Context");
c$.loadInterpolator = Clazz.defineMethod (c$, "loadInterpolator", 
function (context, id) {
var parser = null;
try {
parser = context.getResources ().getAnimation (id);
return android.view.animation.AnimationUtils.createInterpolatorFromXml (context, parser);
} catch (e$$) {
if (Clazz.instanceOf (e$$, org.xmlpull.v1.XmlPullParserException)) {
var ex = e$$;
{
var rnf =  new android.content.res.Resources.NotFoundException ("Can't load animation resource ID #0x" + Integer.toHexString (id));
rnf.initCause (ex);
throw rnf;
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var ex = e$$;
{
var rnf =  new android.content.res.Resources.NotFoundException ("Can't load animation resource ID #0x" + Integer.toHexString (id));
rnf.initCause (ex);
throw rnf;
}
} else {
throw e$$;
}
} finally {
if (parser != null) parser.close ();
}
}, "android.content.Context,~N");
c$.createInterpolatorFromXml = Clazz.defineMethod (c$, "createInterpolatorFromXml", 
($fz = function (c, parser) {
var interpolator = null;
var type;
var depth = parser.getDepth ();
while (((type = parser.next ()) != 3 || parser.getDepth () > depth) && type != 1) {
if (type != 2) {
continue ;}var attrs = android.util.Xml.asAttributeSet (parser);
var name = parser.getName ();
if (name.equals ("linearInterpolator")) {
interpolator =  new android.view.animation.LinearInterpolator (c, attrs);
} else if (name.equals ("accelerateInterpolator")) {
interpolator =  new android.view.animation.AccelerateInterpolator (c, attrs);
} else if (name.equals ("decelerateInterpolator")) {
interpolator =  new android.view.animation.DecelerateInterpolator (c, attrs);
} else if (name.equals ("accelerateDecelerateInterpolator")) {
interpolator =  new android.view.animation.AccelerateDecelerateInterpolator (c, attrs);
} else if (name.equals ("cycleInterpolator")) {
interpolator =  new android.view.animation.CycleInterpolator (c, attrs);
} else if (name.equals ("anticipateInterpolator")) {
interpolator =  new android.view.animation.AnticipateInterpolator (c, attrs);
} else if (name.equals ("overshootInterpolator")) {
interpolator =  new android.view.animation.OvershootInterpolator (c, attrs);
} else if (name.equals ("anticipateOvershootInterpolator")) {
interpolator =  new android.view.animation.AnticipateOvershootInterpolator (c, attrs);
} else if (name.equals ("bounceInterpolator")) {
interpolator =  new android.view.animation.BounceInterpolator (c, attrs);
} else {
throw  new RuntimeException ("Unknown interpolator name: " + parser.getName ());
}}
return interpolator;
}, $fz.isPrivate = true, $fz), "android.content.Context,org.xmlpull.v1.XmlPullParser");
});
