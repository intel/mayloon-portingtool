﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Animation"], "android.view.animation.TranslateAnimation", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFromXType = 0;
this.mToXType = 0;
this.mFromYType = 0;
this.mToYType = 0;
this.mFromXValue = 0.0;
this.mToXValue = 0.0;
this.mFromYValue = 0.0;
this.mToYValue = 0.0;
this.mFromXDelta = 0;
this.mToXDelta = 0;
this.mFromYDelta = 0;
this.mToYDelta = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "TranslateAnimation", android.view.animation.Animation);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.view.animation.TranslateAnimation, []);
});
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.view.animation.TranslateAnimation, [context, attrs]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.TranslateAnimation);
var d = android.view.animation.Animation.Description.parseValue (a.peekValue (0));
this.mFromXType = d.type;
this.mFromXValue = d.value;
d = android.view.animation.Animation.Description.parseValue (a.peekValue (1));
this.mToXType = d.type;
this.mToXValue = d.value;
d = android.view.animation.Animation.Description.parseValue (a.peekValue (2));
this.mFromYType = d.type;
this.mFromYValue = d.value;
d = android.view.animation.Animation.Description.parseValue (a.peekValue (3));
this.mToYType = d.type;
this.mToYValue = d.value;
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (fromXDelta, toXDelta, fromYDelta, toYDelta) {
Clazz.superConstructor (this, android.view.animation.TranslateAnimation, []);
this.mFromXValue = fromXDelta;
this.mToXValue = toXDelta;
this.mFromYValue = fromYDelta;
this.mToYValue = toYDelta;
this.mFromXType = 0;
this.mToXType = 0;
this.mFromYType = 0;
this.mToYType = 0;
}, "~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (fromXType, fromXValue, toXType, toXValue, fromYType, fromYValue, toYType, toYValue) {
Clazz.superConstructor (this, android.view.animation.TranslateAnimation, []);
this.mFromXValue = fromXValue;
this.mToXValue = toXValue;
this.mFromYValue = fromYValue;
this.mToYValue = toYValue;
this.mFromXType = fromXType;
this.mToXType = toXType;
this.mFromYType = fromYType;
this.mToYType = toYType;
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.overrideMethod (c$, "applyTransformation", 
function (interpolatedTime, t) {
var dx = this.mFromXDelta;
var dy = this.mFromYDelta;
if (this.mFromXDelta != this.mToXDelta) {
dx = this.mFromXDelta + ((this.mToXDelta - this.mFromXDelta) * interpolatedTime);
}if (this.mFromYDelta != this.mToYDelta) {
dy = this.mFromYDelta + ((this.mToYDelta - this.mFromYDelta) * interpolatedTime);
}t.getMatrix ().setTranslate (dx, dy);
}, "~N,android.view.animation.Transformation");
Clazz.defineMethod (c$, "initialize", 
function (width, height, parentWidth, parentHeight) {
Clazz.superCall (this, android.view.animation.TranslateAnimation, "initialize", [width, height, parentWidth, parentHeight]);
this.mFromXDelta = this.resolveSize (this.mFromXType, this.mFromXValue, width, parentWidth);
this.mToXDelta = this.resolveSize (this.mToXType, this.mToXValue, width, parentWidth);
this.mFromYDelta = this.resolveSize (this.mFromYType, this.mFromYValue, height, parentHeight);
this.mToYDelta = this.resolveSize (this.mToYType, this.mToYValue, height, parentHeight);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setValues", 
function (fromXType, fromXValue, toXType, toXValue, fromYType, fromYValue, toYType, toYValue) {
this.mFromXValue = fromXValue;
this.mToXValue = toXValue;
this.mFromYValue = fromYValue;
this.mToYValue = toYValue;
this.mFromXType = fromXType;
this.mToXType = toXType;
this.mFromYType = fromYType;
this.mToYType = toYType;
}, "~N,~N,~N,~N,~N,~N,~N,~N");
});
