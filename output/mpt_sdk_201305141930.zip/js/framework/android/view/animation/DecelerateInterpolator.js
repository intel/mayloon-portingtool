﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Interpolator"], "android.view.animation.DecelerateInterpolator", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFactor = 1.0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "DecelerateInterpolator", null, android.view.animation.Interpolator);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (factor) {
this.mFactor = factor;
}, "~N");
Clazz.makeConstructor (c$, 
function (context, attrs) {
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.DecelerateInterpolator);
this.mFactor = a.getFloat (0, 1.0);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.overrideMethod (c$, "getInterpolation", 
function (input) {
if (this.mFactor == 1.0) {
return (1.0 - (1.0 - input) * (1.0 - input));
} else {
return (1.0 - Math.pow ((1.0 - input), 2 * this.mFactor));
}}, "~N");
});
