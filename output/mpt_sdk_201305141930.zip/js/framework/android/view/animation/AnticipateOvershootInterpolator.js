﻿Clazz.declarePackage ("android.view.animation");
Clazz.load (["android.view.animation.Interpolator"], "android.view.animation.AnticipateOvershootInterpolator", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mTension = 0;
Clazz.instantialize (this, arguments);
}, android.view.animation, "AnticipateOvershootInterpolator", null, android.view.animation.Interpolator);
Clazz.makeConstructor (c$, 
function () {
this.mTension = 3.0;
});
Clazz.makeConstructor (c$, 
function (tension) {
this.mTension = tension * 1.5;
}, "~N");
Clazz.makeConstructor (c$, 
function (tension, extraTension) {
this.mTension = tension * extraTension;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (context, attrs) {
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.AnticipateOvershootInterpolator);
this.mTension = a.getFloat (0, 2.0) * a.getFloat (1, 1.5);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
c$.a = Clazz.defineMethod (c$, "a", 
($fz = function (t, s) {
return t * t * ((s + 1) * t - s);
}, $fz.isPrivate = true, $fz), "~N,~N");
c$.o = Clazz.defineMethod (c$, "o", 
($fz = function (t, s) {
return t * t * ((s + 1) * t + s);
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.overrideMethod (c$, "getInterpolation", 
function (t) {
if (t < 0.5) return 0.5 * android.view.animation.AnticipateOvershootInterpolator.a (t * 2.0, this.mTension);
 else return 0.5 * (android.view.animation.AnticipateOvershootInterpolator.o (t * 2.0 - 2.0, this.mTension) + 2.0);
}, "~N");
});
