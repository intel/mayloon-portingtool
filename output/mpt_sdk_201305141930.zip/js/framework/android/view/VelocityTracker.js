﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.util.Poolable", "$.PoolableManager", "$.Pools"], "android.view.VelocityTracker", ["android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPointerListHead = null;
this.mLastTouchIndex = 0;
this.mGeneration = 0;
this.mNext = null;
Clazz.instantialize (this, arguments);
}, android.view, "VelocityTracker", null, android.util.Poolable);
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function () {
return android.view.VelocityTracker.sPool.acquire ();
});
Clazz.defineMethod (c$, "recycle", 
function () {
android.view.VelocityTracker.sPool.release (this);
});
Clazz.overrideMethod (c$, "setNextPoolable", 
function (element) {
this.mNext = element;
}, "android.view.VelocityTracker");
Clazz.overrideMethod (c$, "getNextPoolable", 
function () {
return this.mNext;
});
Clazz.makeConstructor (c$, 
($fz = function () {
this.clear ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "clear", 
function () {
android.view.VelocityTracker.releasePointerList (this.mPointerListHead);
this.mPointerListHead = null;
this.mLastTouchIndex = 0;
});
Clazz.defineMethod (c$, "addMovement", 
function (ev) {
var historySize = ev.getHistorySize ();
var pointerCount = ev.getPointerCount ();
var lastTouchIndex = this.mLastTouchIndex;
var nextTouchIndex = (lastTouchIndex + 1) % 10;
var finalTouchIndex = (nextTouchIndex + historySize) % 10;
var generation = this.mGeneration++;
this.mLastTouchIndex = finalTouchIndex;
var previousPointer = null;
for (var i = 0; i < pointerCount; i++) {
var pointerId = ev.getPointerId (i);
var nextPointer;
if (previousPointer == null || pointerId < previousPointer.id) {
previousPointer = null;
nextPointer = this.mPointerListHead;
} else {
nextPointer = previousPointer.next;
}var pointer;
for (; ; ) {
if (nextPointer != null) {
var nextPointerId = nextPointer.id;
if (nextPointerId == pointerId) {
pointer = nextPointer;
break;
}if (nextPointerId < pointerId) {
nextPointer = nextPointer.next;
continue ;}}pointer = android.view.VelocityTracker.obtainPointer ();
pointer.id = pointerId;
pointer.pastTime[lastTouchIndex] = -9223372036854775808;
pointer.next = nextPointer;
if (previousPointer == null) {
this.mPointerListHead = pointer;
} else {
previousPointer.next = pointer;
}break;
}
pointer.generation = generation;
previousPointer = pointer;
var pastX = pointer.pastX;
var pastY = pointer.pastY;
var pastTime = pointer.pastTime;
for (var j = 0; j < historySize; j++) {
var touchIndex = (nextTouchIndex + j) % 10;
pastX[touchIndex] = ev.getHistoricalX (i, j);
pastY[touchIndex] = ev.getHistoricalY (i, j);
pastTime[touchIndex] = ev.getHistoricalEventTime (j);
}
pastX[finalTouchIndex] = ev.getX (i);
pastY[finalTouchIndex] = ev.getY (i);
pastTime[finalTouchIndex] = ev.getEventTime ();
}
previousPointer = null;
for (var pointer = this.mPointerListHead; pointer != null; ) {
var nextPointer = pointer.next;
if (pointer.generation != generation) {
if (previousPointer == null) {
this.mPointerListHead = nextPointer;
} else {
previousPointer.next = nextPointer;
}android.view.VelocityTracker.releasePointer (pointer);
} else {
previousPointer = pointer;
}pointer = nextPointer;
}
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "computeCurrentVelocity", 
function (units) {
this.computeCurrentVelocity (units, 3.4028235E38);
}, "~N");
Clazz.defineMethod (c$, "computeCurrentVelocity", 
function (units, maxVelocity) {
var lastTouchIndex = this.mLastTouchIndex;
for (var pointer = this.mPointerListHead; pointer != null; pointer = pointer.next) {
var pastTime = pointer.pastTime;
var oldestTouchIndex = lastTouchIndex;
var numTouches = 1;
var minTime = pastTime[lastTouchIndex] - 200;
while (numTouches < 10) {
var nextOldestTouchIndex = (oldestTouchIndex + 10 - 1) % 10;
var nextOldestTime = pastTime[nextOldestTouchIndex];
if (nextOldestTime < minTime) {
break;
}oldestTouchIndex = nextOldestTouchIndex;
numTouches += 1;
}
if (numTouches > 3) {
numTouches -= 1;
}var pastX = pointer.pastX;
var pastY = pointer.pastY;
var oldestX = pastX[oldestTouchIndex];
var oldestY = pastY[oldestTouchIndex];
var oldestTime = pastTime[oldestTouchIndex];
var accumX = 0;
var accumY = 0;
for (var i = 1; i < numTouches; i++) {
var touchIndex = (oldestTouchIndex + i) % 10;
var duration = (pastTime[touchIndex] - oldestTime);
if (duration == 0) continue ;var delta = pastX[touchIndex] - oldestX;
var velocity = (delta / duration) * units;
accumX = (accumX == 0) ? velocity : (accumX + velocity) * .5;
delta = pastY[touchIndex] - oldestY;
velocity = (delta / duration) * units;
accumY = (accumY == 0) ? velocity : (accumY + velocity) * .5;
}
if (accumX < -maxVelocity) {
accumX = -maxVelocity;
} else if (accumX > maxVelocity) {
accumX = maxVelocity;
}if (accumY < -maxVelocity) {
accumY = -maxVelocity;
} else if (accumY > maxVelocity) {
accumY = maxVelocity;
}pointer.xVelocity = accumX;
pointer.yVelocity = accumY;
if (false) {
android.util.Log.v ("VelocityTracker", "Pointer " + pointer.id + ": Y velocity=" + accumX + " X velocity=" + accumY + " N=" + numTouches);
}}
}, "~N,~N");
Clazz.defineMethod (c$, "getXVelocity", 
function () {
var pointer = this.getPointer (0);
return pointer != null ? pointer.xVelocity : 0;
});
Clazz.defineMethod (c$, "getYVelocity", 
function () {
var pointer = this.getPointer (0);
return pointer != null ? pointer.yVelocity : 0;
});
Clazz.defineMethod (c$, "getXVelocity", 
function (id) {
var pointer = this.getPointer (id);
return pointer != null ? pointer.xVelocity : 0;
}, "~N");
Clazz.defineMethod (c$, "getYVelocity", 
function (id) {
var pointer = this.getPointer (id);
return pointer != null ? pointer.yVelocity : 0;
}, "~N");
Clazz.defineMethod (c$, "getPointer", 
($fz = function (id) {
for (var pointer = this.mPointerListHead; pointer != null; pointer = pointer.next) {
if (pointer.id == id) {
return pointer;
}}
return null;
}, $fz.isPrivate = true, $fz), "~N");
c$.obtainPointer = Clazz.defineMethod (c$, "obtainPointer", 
($fz = function () {
{
if (android.view.VelocityTracker.sRecycledPointerCount != 0) {
var element = android.view.VelocityTracker.sRecycledPointerListHead;
($t$ = android.view.VelocityTracker.sRecycledPointerCount -= 1, android.view.VelocityTracker.prototype.sRecycledPointerCount = android.view.VelocityTracker.sRecycledPointerCount, $t$);
($t$ = android.view.VelocityTracker.sRecycledPointerListHead = element.next, android.view.VelocityTracker.prototype.sRecycledPointerListHead = android.view.VelocityTracker.sRecycledPointerListHead, $t$);
element.next = null;
return element;
}}return  new android.view.VelocityTracker.Pointer ();
}, $fz.isPrivate = true, $fz));
c$.releasePointer = Clazz.defineMethod (c$, "releasePointer", 
($fz = function (pointer) {
{
if (android.view.VelocityTracker.sRecycledPointerCount < 20) {
pointer.next = android.view.VelocityTracker.sRecycledPointerListHead;
($t$ = android.view.VelocityTracker.sRecycledPointerCount += 1, android.view.VelocityTracker.prototype.sRecycledPointerCount = android.view.VelocityTracker.sRecycledPointerCount, $t$);
($t$ = android.view.VelocityTracker.sRecycledPointerListHead = pointer, android.view.VelocityTracker.prototype.sRecycledPointerListHead = android.view.VelocityTracker.sRecycledPointerListHead, $t$);
}}}, $fz.isPrivate = true, $fz), "android.view.VelocityTracker.Pointer");
c$.releasePointerList = Clazz.defineMethod (c$, "releasePointerList", 
($fz = function (pointer) {
if (pointer != null) {
{
var count = android.view.VelocityTracker.sRecycledPointerCount;
if (count >= 20) {
return ;
}var tail = pointer;
for (; ; ) {
count += 1;
if (count >= 20) {
break;
}var next = tail.next;
if (next == null) {
break;
}tail = next;
}
tail.next = android.view.VelocityTracker.sRecycledPointerListHead;
($t$ = android.view.VelocityTracker.sRecycledPointerCount = count, android.view.VelocityTracker.prototype.sRecycledPointerCount = android.view.VelocityTracker.sRecycledPointerCount, $t$);
($t$ = android.view.VelocityTracker.sRecycledPointerListHead = pointer, android.view.VelocityTracker.prototype.sRecycledPointerListHead = android.view.VelocityTracker.sRecycledPointerListHead, $t$);
}}}, $fz.isPrivate = true, $fz), "android.view.VelocityTracker.Pointer");
c$.$VelocityTracker$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view, "VelocityTracker$1", null, android.util.PoolableManager);
Clazz.overrideMethod (c$, "newInstance", 
function () {
return  new android.view.VelocityTracker ();
});
Clazz.overrideMethod (c$, "onAcquired", 
function (element) {
}, "android.view.VelocityTracker");
Clazz.overrideMethod (c$, "onReleased", 
function (element) {
element.clear ();
}, "android.view.VelocityTracker");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.next = null;
this.id = 0;
this.xVelocity = 0;
this.yVelocity = 0;
this.pastX = null;
this.pastY = null;
this.pastTime = null;
this.generation = 0;
Clazz.instantialize (this, arguments);
}, android.view.VelocityTracker, "Pointer");
Clazz.prepareFields (c$, function () {
this.pastX =  Clazz.newArray (10, 0);
this.pastY =  Clazz.newArray (10, 0);
this.pastTime =  Clazz.newArray (10, 0);
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "VelocityTracker",
"DEBUG", false,
"localLOGV", false,
"NUM_PAST", 10,
"MAX_AGE_MILLISECONDS", 200,
"POINTER_POOL_CAPACITY", 20);
c$.sPool = c$.prototype.sPool = android.util.Pools.finitePool (((Clazz.isClassDefined ("android.view.VelocityTracker$1") ? 0 : android.view.VelocityTracker.$VelocityTracker$1$ ()), Clazz.innerTypeInstance (android.view.VelocityTracker$1, this, null)), 2);
Clazz.defineStatics (c$,
"sRecycledPointerListHead", null,
"sRecycledPointerCount", 0);
});
