﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.graphics.Rect"], "android.view.FocusFinder", ["android.view.ViewConfiguration", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFocusedRect = null;
this.mOtherRect = null;
this.mBestCandidateRect = null;
Clazz.instantialize (this, arguments);
}, android.view, "FocusFinder");
Clazz.prepareFields (c$, function () {
this.mFocusedRect =  new android.graphics.Rect ();
this.mOtherRect =  new android.graphics.Rect ();
this.mBestCandidateRect =  new android.graphics.Rect ();
});
c$.getInstance = Clazz.defineMethod (c$, "getInstance", 
function () {
return android.view.FocusFinder.tlFocusFinder;
});
Clazz.makeConstructor (c$, 
($fz = function () {
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "findNextFocus", 
function (root, focused, direction) {
if (focused != null) {
var userSetNextFocus = focused.findUserSetNextFocus (root, direction);
if (userSetNextFocus != null && userSetNextFocus.isFocusable () && (!userSetNextFocus.isInTouchMode () || userSetNextFocus.isFocusableInTouchMode ())) {
return userSetNextFocus;
}focused.getFocusedRect (this.mFocusedRect);
root.offsetDescendantRectToMyCoords (focused, this.mFocusedRect);
} else {
switch (direction) {
case 66:
case 130:
var rootTop = root.getScrollY ();
var rootLeft = root.getScrollX ();
this.mFocusedRect.set (rootLeft, rootTop, rootLeft, rootTop);
break;
case 17:
case 33:
var rootBottom = root.getScrollY () + root.getHeight ();
var rootRight = root.getScrollX () + root.getWidth ();
this.mFocusedRect.set (rootRight, rootBottom, rootRight, rootBottom);
break;
}
}return this.findNextFocus (root, focused, this.mFocusedRect, direction);
}, "android.view.ViewGroup,android.view.View,~N");
Clazz.defineMethod (c$, "findNextFocusFromRect", 
function (root, focusedRect, direction) {
return this.findNextFocus (root, null, focusedRect, direction);
}, "android.view.ViewGroup,android.graphics.Rect,~N");
Clazz.defineMethod (c$, "findNextFocus", 
($fz = function (root, focused, focusedRect, direction) {
var focusables = root.getFocusables (direction);
this.mBestCandidateRect.set (focusedRect);
switch (direction) {
case 17:
this.mBestCandidateRect.offset (focusedRect.width () + 1, 0);
break;
case 66:
this.mBestCandidateRect.offset (-(focusedRect.width () + 1), 0);
break;
case 33:
this.mBestCandidateRect.offset (0, focusedRect.height () + 1);
break;
case 130:
this.mBestCandidateRect.offset (0, -(focusedRect.height () + 1));
}
var closest = null;
var numFocusables = focusables.size ();
for (var i = 0; i < numFocusables; i++) {
var focusable = focusables.get (i);
if (focusable === focused || focusable === root) continue ;focusable.getDrawingRect (this.mOtherRect);
root.offsetDescendantRectToMyCoords (focusable, this.mOtherRect);
if (this.isBetterCandidate (direction, focusedRect, this.mOtherRect, this.mBestCandidateRect)) {
this.mBestCandidateRect.set (this.mOtherRect);
closest = focusable;
}}
return closest;
}, $fz.isPrivate = true, $fz), "android.view.ViewGroup,android.view.View,android.graphics.Rect,~N");
Clazz.defineMethod (c$, "isBetterCandidate", 
function (direction, source, rect1, rect2) {
if (!this.isCandidate (source, rect1, direction)) {
return false;
}if (!this.isCandidate (source, rect2, direction)) {
return true;
}if (this.beamBeats (direction, source, rect1, rect2)) {
return true;
}if (this.beamBeats (direction, source, rect2, rect1)) {
return false;
}return (this.getWeightedDistanceFor (android.view.FocusFinder.majorAxisDistance (direction, source, rect1), android.view.FocusFinder.minorAxisDistance (direction, source, rect1)) < this.getWeightedDistanceFor (android.view.FocusFinder.majorAxisDistance (direction, source, rect2), android.view.FocusFinder.minorAxisDistance (direction, source, rect2)));
}, "~N,android.graphics.Rect,android.graphics.Rect,android.graphics.Rect");
Clazz.defineMethod (c$, "beamBeats", 
function (direction, source, rect1, rect2) {
var rect1InSrcBeam = this.beamsOverlap (direction, source, rect1);
var rect2InSrcBeam = this.beamsOverlap (direction, source, rect2);
if (rect2InSrcBeam || !rect1InSrcBeam) {
return false;
}if (!this.isToDirectionOf (direction, source, rect2)) {
return true;
}if ((direction == 17 || direction == 66)) {
return true;
}return (android.view.FocusFinder.majorAxisDistance (direction, source, rect1) < android.view.FocusFinder.majorAxisDistanceToFarEdge (direction, source, rect2));
}, "~N,android.graphics.Rect,android.graphics.Rect,android.graphics.Rect");
Clazz.defineMethod (c$, "getWeightedDistanceFor", 
function (majorAxisDistance, minorAxisDistance) {
return 13 * majorAxisDistance * majorAxisDistance + minorAxisDistance * minorAxisDistance;
}, "~N,~N");
Clazz.defineMethod (c$, "isCandidate", 
function (srcRect, destRect, direction) {
switch (direction) {
case 17:
return (srcRect.right > destRect.right || srcRect.left >= destRect.right) && srcRect.left > destRect.left;
case 66:
return (srcRect.left < destRect.left || srcRect.right <= destRect.left) && srcRect.right < destRect.right;
case 33:
return (srcRect.bottom > destRect.bottom || srcRect.top >= destRect.bottom) && srcRect.top > destRect.top;
case 130:
return (srcRect.top < destRect.top || srcRect.bottom <= destRect.top) && srcRect.bottom < destRect.bottom;
}
throw  new IllegalArgumentException ("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
}, "android.graphics.Rect,android.graphics.Rect,~N");
Clazz.defineMethod (c$, "beamsOverlap", 
function (direction, rect1, rect2) {
switch (direction) {
case 17:
case 66:
return (rect2.bottom >= rect1.top) && (rect2.top <= rect1.bottom);
case 33:
case 130:
return (rect2.right >= rect1.left) && (rect2.left <= rect1.right);
}
throw  new IllegalArgumentException ("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
}, "~N,android.graphics.Rect,android.graphics.Rect");
Clazz.defineMethod (c$, "isToDirectionOf", 
function (direction, src, dest) {
switch (direction) {
case 17:
return src.left >= dest.right;
case 66:
return src.right <= dest.left;
case 33:
return src.top >= dest.bottom;
case 130:
return src.bottom <= dest.top;
}
throw  new IllegalArgumentException ("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
}, "~N,android.graphics.Rect,android.graphics.Rect");
c$.majorAxisDistance = Clazz.defineMethod (c$, "majorAxisDistance", 
function (direction, source, dest) {
return Math.max (0, android.view.FocusFinder.majorAxisDistanceRaw (direction, source, dest));
}, "~N,android.graphics.Rect,android.graphics.Rect");
c$.majorAxisDistanceRaw = Clazz.defineMethod (c$, "majorAxisDistanceRaw", 
function (direction, source, dest) {
switch (direction) {
case 17:
return source.left - dest.right;
case 66:
return dest.left - source.right;
case 33:
return source.top - dest.bottom;
case 130:
return dest.top - source.bottom;
}
throw  new IllegalArgumentException ("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
}, "~N,android.graphics.Rect,android.graphics.Rect");
c$.majorAxisDistanceToFarEdge = Clazz.defineMethod (c$, "majorAxisDistanceToFarEdge", 
function (direction, source, dest) {
return Math.max (1, android.view.FocusFinder.majorAxisDistanceToFarEdgeRaw (direction, source, dest));
}, "~N,android.graphics.Rect,android.graphics.Rect");
c$.majorAxisDistanceToFarEdgeRaw = Clazz.defineMethod (c$, "majorAxisDistanceToFarEdgeRaw", 
function (direction, source, dest) {
switch (direction) {
case 17:
return source.left - dest.left;
case 66:
return dest.right - source.right;
case 33:
return source.top - dest.top;
case 130:
return dest.bottom - source.bottom;
}
throw  new IllegalArgumentException ("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
}, "~N,android.graphics.Rect,android.graphics.Rect");
c$.minorAxisDistance = Clazz.defineMethod (c$, "minorAxisDistance", 
function (direction, source, dest) {
switch (direction) {
case 17:
case 66:
return Math.abs (((source.top + Math.floor (source.height () / 2)) - ((dest.top + Math.floor (dest.height () / 2)))));
case 33:
case 130:
return Math.abs (((source.left + Math.floor (source.width () / 2)) - ((dest.left + Math.floor (dest.width () / 2)))));
}
throw  new IllegalArgumentException ("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
}, "~N,android.graphics.Rect,android.graphics.Rect");
Clazz.defineMethod (c$, "findNearestTouchable", 
function (root, x, y, direction, deltas) {
var touchables = root.getTouchables ();
var minDistance = 2147483647;
var closest = null;
var numTouchables = touchables.size ();
var edgeSlop = android.view.ViewConfiguration.get (root.mContext).getScaledEdgeSlop ();
var closestBounds =  new android.graphics.Rect ();
var touchableBounds = this.mOtherRect;
for (var i = 0; i < numTouchables; i++) {
var touchable = touchables.get (i);
touchable.getDrawingRect (touchableBounds);
root.offsetRectBetweenParentAndChild (touchable, touchableBounds, true, true);
if (!this.isTouchCandidate (x, y, touchableBounds, direction)) {
continue ;}var distance = 2147483647;
switch (direction) {
case 17:
distance = x - touchableBounds.right + 1;
break;
case 66:
distance = touchableBounds.left;
break;
case 33:
distance = y - touchableBounds.bottom + 1;
break;
case 130:
distance = touchableBounds.top;
break;
}
if (distance < edgeSlop) {
if (closest == null || closestBounds.contains (touchableBounds) || (!touchableBounds.contains (closestBounds) && distance < minDistance)) {
minDistance = distance;
closest = touchable;
closestBounds.set (touchableBounds);
switch (direction) {
case 17:
deltas[0] = -distance;
break;
case 66:
deltas[0] = distance;
break;
case 33:
deltas[1] = -distance;
break;
case 130:
deltas[1] = distance;
break;
}
}}}
return closest;
}, "android.view.ViewGroup,~N,~N,~N,~A");
Clazz.defineMethod (c$, "isTouchCandidate", 
($fz = function (x, y, destRect, direction) {
switch (direction) {
case 17:
return destRect.left <= x && destRect.top <= y && y <= destRect.bottom;
case 66:
return destRect.left >= x && destRect.top <= y && y <= destRect.bottom;
case 33:
return destRect.top <= y && destRect.left <= x && x <= destRect.right;
case 130:
return destRect.top >= y && destRect.left <= x && x <= destRect.right;
}
throw  new IllegalArgumentException ("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
}, $fz.isPrivate = true, $fz), "~N,~N,android.graphics.Rect,~N");
c$.tlFocusFinder = c$.prototype.tlFocusFinder =  new android.view.FocusFinder ();
});
