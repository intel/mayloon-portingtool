﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.view.InputChannel", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPtr = 0;
this.mDisposeAfterWriteToParcel = false;
Clazz.instantialize (this, arguments);
}, android.view, "InputChannel", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "finalize", 
function () {
try {
this.nativeDispose (true);
} finally {
Clazz.superCall (this, android.view.InputChannel, "finalize", []);
}
});
c$.openInputChannelPair = Clazz.defineMethod (c$, "openInputChannelPair", 
function (name) {
if (name == null) {
throw  new IllegalArgumentException ("name must not be null");
}return android.view.InputChannel.nativeOpenInputChannelPair (name);
}, "~S");
Clazz.defineMethod (c$, "getName", 
function () {
var name = this.nativeGetName ();
return name != null ? name : "uninitialized";
});
Clazz.defineMethod (c$, "dispose", 
function () {
this.nativeDispose (false);
});
Clazz.defineMethod (c$, "transferToBinderOutParameter", 
function (outParameter) {
if (outParameter == null) {
throw  new IllegalArgumentException ("outParameter must not be null");
}this.nativeTransferTo (outParameter);
outParameter.mDisposeAfterWriteToParcel = true;
}, "android.view.InputChannel");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 1;
});
Clazz.defineMethod (c$, "readFromParcel", 
function ($in) {
if ($in == null) {
throw  new IllegalArgumentException ("in must not be null");
}this.nativeReadFromParcel ($in);
}, "android.os.Parcel");
Clazz.defineMethod (c$, "writeToParcel", 
function (out, flags) {
if (out == null) {
throw  new IllegalArgumentException ("out must not be null");
}this.nativeWriteToParcel (out);
if (this.mDisposeAfterWriteToParcel) {
this.dispose ();
}}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return this.getName ();
});
c$.$InputChannel$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.view, "InputChannel$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (source) {
var result =  new android.view.InputChannel ();
result.readFromParcel (source);
return result;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"TAG", "InputChannel",
"DEBUG", false);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.view.InputChannel$1") ? 0 : android.view.InputChannel.$InputChannel$1$ ()), Clazz.innerTypeInstance (android.view.InputChannel$1, this, null));
});
