﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.view.View", "$.ViewManager", "$.ViewParent", "android.graphics.Rect"], "android.view.ViewGroup", ["android.graphics.RectF", "android.util.Log", "android.view.animation.LayoutAnimationController", "$.Transformation", "com.android.internal.R", "java.lang.IllegalArgumentException", "$.IllegalStateException", "$.IndexOutOfBoundsException", "$.NullPointerException", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDisappearingChildren = null;
this.mOnHierarchyChangeListener = null;
this.mFocused = null;
this.mChildTransformation = null;
this.mInvalidateRegion = null;
this.mMotionTarget = null;
this.mTempRect = null;
this.mLayoutAnimationController = null;
this.mAnimationListener = null;
this.mGroupFlags = 0;
this.mChildren = null;
this.mChildrenCount = 0;
this.mPendingChildren = null;
Clazz.instantialize (this, arguments);
}, android.view, "ViewGroup", android.view.View, [android.view.ViewParent, android.view.ViewManager]);
Clazz.prepareFields (c$, function () {
this.mTempRect =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function (context) {
Clazz.superConstructor (this, android.view.ViewGroup, [context]);
this.initViewGroup ();
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.view.ViewGroup, [context, attrs]);
this.initViewGroup ();
this.initFromAttributes (context, attrs);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.view.ViewGroup, [context, attrs, defStyle]);
this.initViewGroup ();
this.initFromAttributes (context, attrs);
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "initViewGroup", 
($fz = function () {
this.setFlags (128, 128);
this.mGroupFlags |= 1;
this.mGroupFlags |= 2;
this.mGroupFlags |= 16;
this.mGroupFlags |= 64;
this.mGroupFlags |= 16384;
this.setDescendantFocusability (131072);
this.mChildren =  new Array (12);
this.mChildrenCount = 0;
this.mPendingChildren =  new java.util.ArrayList ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "initFromAttributes", 
($fz = function (context, attrs) {
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.ViewGroup);
var N = a.getIndexCount ();
for (var i = 0; i < N; i++) {
var attr = a.getIndex (i);
switch (attr) {
case 0:
this.setClipChildren (a.getBoolean (attr, true));
break;
case 1:
this.setClipToPadding (a.getBoolean (attr, true));
break;
case 6:
this.setAddStatesFromChildren (a.getBoolean (attr, false));
break;
case 2:
var id = a.getResourceId (attr, -1);
if (id > 0) {
}break;
case 7:
this.setDescendantFocusability (android.view.ViewGroup.DESCENDANT_FOCUSABILITY_FLAGS[a.getInt (attr, 0)]);
break;
}
}
a.recycle ();
}, $fz.isPrivate = true, $fz), "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "getDescendantFocusability", 
function () {
return this.mGroupFlags & 393216;
});
Clazz.defineMethod (c$, "setDescendantFocusability", 
function (focusability) {
switch (focusability) {
case 131072:
case 262144:
case 393216:
break;
default:
throw  new IllegalArgumentException ("must be one of FOCUS_BEFORE_DESCENDANTS, FOCUS_AFTER_DESCENDANTS, FOCUS_BLOCK_DESCENDANTS");
}
this.mGroupFlags &= -393217;
this.mGroupFlags |= (focusability & 393216);
}, "~N");
Clazz.defineMethod (c$, "handleFocusGainInternal", 
function (direction, previouslyFocusedRect) {
if (this.mFocused != null) {
this.mFocused.unFocus ();
this.mFocused = null;
}Clazz.superCall (this, android.view.ViewGroup, "handleFocusGainInternal", [direction, previouslyFocusedRect]);
}, "~N,android.graphics.Rect");
Clazz.defineMethod (c$, "requestChildFocus", 
function (child, focused) {
if (false) {
System.out.println (this + " requestChildFocus()");
}if (this.getDescendantFocusability () == 393216) {
return ;
}Clazz.superCall (this, android.view.ViewGroup, "unFocus", []);
if (this.mFocused !== child) {
if (this.mFocused != null) {
this.mFocused.unFocus ();
}this.mFocused = child;
}if (this.mParent != null) {
this.mParent.requestChildFocus (this, focused);
}}, "android.view.View,android.view.View");
Clazz.defineMethod (c$, "focusableViewAvailable", 
function (v) {
if (this.mParent != null && (this.getDescendantFocusability () != 393216) && !(this.isFocused () && this.getDescendantFocusability () != 262144)) {
this.mParent.focusableViewAvailable (v);
}}, "android.view.View");
Clazz.defineMethod (c$, "showContextMenuForChild", 
function (originalView) {
return this.mParent != null && this.mParent.showContextMenuForChild (originalView);
}, "android.view.View");
Clazz.overrideMethod (c$, "requestChildRectangleOnScreen", 
function (child, rectangle, immediate) {
return false;
}, "android.view.View,android.graphics.Rect,~B");
Clazz.defineMethod (c$, "dispatchUnhandledMove", 
function (focused, direction) {
return this.mFocused != null && this.mFocused.dispatchUnhandledMove (focused, direction);
}, "android.view.View,~N");
Clazz.defineMethod (c$, "clearChildFocus", 
function (child) {
if (false) {
System.out.println (this + " clearChildFocus()");
}this.mFocused = null;
if (this.mParent != null) {
this.mParent.clearChildFocus (this);
}}, "android.view.View");
Clazz.defineMethod (c$, "clearFocus", 
function () {
Clazz.superCall (this, android.view.ViewGroup, "clearFocus", []);
if (this.mFocused != null) {
this.mFocused.clearFocus ();
}});
Clazz.defineMethod (c$, "unFocus", 
function () {
if (false) {
System.out.println (this + " unFocus()");
}Clazz.superCall (this, android.view.ViewGroup, "unFocus", []);
if (this.mFocused != null) {
this.mFocused.unFocus ();
}this.mFocused = null;
});
Clazz.defineMethod (c$, "getFocusedChild", 
function () {
return this.mFocused;
});
Clazz.defineMethod (c$, "hasFocus", 
function () {
return (this.mPrivateFlags & 2) != 0 || this.mFocused != null;
});
Clazz.defineMethod (c$, "findFocus", 
function () {
if (false) {
System.out.println ("Find focus in " + this + ": flags=" + this.isFocused () + ", child=" + this.mFocused);
}if (this.isFocused ()) {
return this;
}if (this.mFocused != null) {
return this.mFocused.findFocus ();
}return null;
});
Clazz.defineMethod (c$, "hasFocusable", 
function () {
if ((this.mViewFlags & 12) != 0) {
return false;
}if (this.isFocusable ()) {
return true;
}var descendantFocusability = this.getDescendantFocusability ();
if (descendantFocusability != 393216) {
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
var child = children[i];
if (child.hasFocusable ()) {
return true;
}}
}return false;
});
Clazz.defineMethod (c$, "addFocusables", 
function (views, direction) {
this.addFocusables (views, direction, 1);
}, "java.util.ArrayList,~N");
Clazz.defineMethod (c$, "addFocusables", 
function (views, direction, focusableMode) {
var focusableCount = views.size ();
var descendantFocusability = this.getDescendantFocusability ();
if (descendantFocusability != 393216) {
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
var child = children[i];
if ((child.mViewFlags & 12) == 0) {
child.addFocusables (views, direction, focusableMode);
}}
}if (descendantFocusability != 262144 || (focusableCount == views.size ())) {
Clazz.superCall (this, android.view.ViewGroup, "addFocusables", [views, direction, focusableMode]);
}}, "java.util.ArrayList,~N,~N");
Clazz.defineMethod (c$, "dispatchWindowFocusChanged", 
function (hasFocus) {
Clazz.superCall (this, android.view.ViewGroup, "dispatchWindowFocusChanged", [hasFocus]);
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
children[i].dispatchWindowFocusChanged (hasFocus);
}
}, "~B");
Clazz.defineMethod (c$, "dispatchWindowVisibilityChanged", 
function (visibility) {
Clazz.superCall (this, android.view.ViewGroup, "dispatchWindowVisibilityChanged", [visibility]);
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
children[i].dispatchWindowVisibilityChanged (visibility);
}
}, "~N");
Clazz.defineMethod (c$, "addTouchables", 
function (views) {
Clazz.superCall (this, android.view.ViewGroup, "addTouchables", [views]);
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
var child = children[i];
if ((child.mViewFlags & 12) == 0) {
child.addTouchables (views);
}}
}, "java.util.ArrayList");
Clazz.defineMethod (c$, "dispatchDisplayHint", 
function (hint) {
Clazz.superCall (this, android.view.ViewGroup, "dispatchDisplayHint", [hint]);
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
children[i].dispatchDisplayHint (hint);
}
}, "~N");
Clazz.defineMethod (c$, "recomputeViewAttributes", 
function (child) {
var parent = this.mParent;
if (parent != null) parent.recomputeViewAttributes (this);
}, "android.view.View");
Clazz.defineMethod (c$, "dispatchCollectViewAttributes", 
function (visibility) {
visibility |= this.mViewFlags & 12;
Clazz.superCall (this, android.view.ViewGroup, "dispatchCollectViewAttributes", [visibility]);
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
children[i].dispatchCollectViewAttributes (visibility);
}
}, "~N");
Clazz.overrideMethod (c$, "bringChildToFront", 
function (child) {
var index = this.indexOfChild (child);
if (index >= 0) {
this.removeFromArray (index);
this.addInArray (child, this.mChildrenCount);
child.mParent = this;
}}, "android.view.View");
Clazz.defineMethod (c$, "dispatchKeyEventPreIme", 
function (event) {
if ((this.mPrivateFlags & (18)) == (18)) {
return Clazz.superCall (this, android.view.ViewGroup, "dispatchKeyEventPreIme", [event]);
} else if (this.mFocused != null && (this.mFocused.mPrivateFlags & 16) == 16) {
return this.mFocused.dispatchKeyEventPreIme (event);
}return false;
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "dispatchKeyEvent", 
function (event) {
if ((this.mPrivateFlags & (18)) == (18)) {
return Clazz.superCall (this, android.view.ViewGroup, "dispatchKeyEvent", [event]);
} else if (this.mFocused != null && (this.mFocused.mPrivateFlags & 16) == 16) {
return this.mFocused.dispatchKeyEvent (event);
}return false;
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "dispatchTouchEvent", 
function (ev) {
var action = ev.getAction ();
var xf = ev.getX ();
var yf = ev.getY ();
var scrolledXFloat = xf + this.mScrollX;
var scrolledYFloat = yf + this.mScrollY;
var frame = this.mTempRect;
var disallowIntercept = (this.mGroupFlags & 524288) != 0;
if (action == 0) {
if (disallowIntercept || !this.onInterceptTouchEvent (ev)) {
this.mMotionTarget = null;
ev.setAction (0);
var scrolledXInt = Math.round (scrolledXFloat);
var scrolledYInt = Math.round (scrolledYFloat);
var children = this.mChildren;
var count = this.mChildrenCount;
for (var i = count - 1; i >= 0; i--) {
var child = children[i];
if ((child.mViewFlags & 12) == 0 || child.getAnimation () != null) {
child.getHitRect (frame);
if (frame.contains (scrolledXInt, scrolledYInt)) {
var xc = scrolledXFloat - child.mLeft;
var yc = scrolledYFloat - child.mTop;
ev.setLocation (xc, yc);
child.mPrivateFlags &= -67108865;
if (child.dispatchTouchEvent (ev)) {
this.mMotionTarget = child;
return true;
}}}}
}}var isUpOrCancel = (action == 1) || (action == 3);
if (isUpOrCancel) {
this.mGroupFlags &= -524289;
}var target = this.mMotionTarget;
if (target == null) {
ev.setLocation (xf, yf);
if ((this.mPrivateFlags & 67108864) != 0) {
ev.setAction (3);
this.mPrivateFlags &= -67108865;
}return Clazz.superCall (this, android.view.ViewGroup, "dispatchTouchEvent", [ev]);
}if (!disallowIntercept && this.onInterceptTouchEvent (ev)) {
var xc = scrolledXFloat - target.mLeft;
var yc = scrolledYFloat - target.mTop;
this.mPrivateFlags &= -67108865;
ev.setAction (3);
ev.setLocation (xc, yc);
if (!target.dispatchTouchEvent (ev)) {
}this.mMotionTarget = null;
return true;
}if (isUpOrCancel) {
this.mMotionTarget = null;
}var xc = scrolledXFloat - target.mLeft;
var yc = scrolledYFloat - target.mTop;
ev.setLocation (xc, yc);
if ((target.mPrivateFlags & 67108864) != 0) {
ev.setAction (3);
target.mPrivateFlags &= -67108865;
this.mMotionTarget = null;
}return target.dispatchTouchEvent (ev);
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "dispatchKeyShortcutEvent", 
function (event) {
if ((this.mPrivateFlags & (18)) == (18)) {
return Clazz.superCall (this, android.view.ViewGroup, "dispatchKeyShortcutEvent", [event]);
} else if (this.mFocused != null && (this.mFocused.mPrivateFlags & 16) == 16) {
return this.mFocused.dispatchKeyShortcutEvent (event);
}return false;
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "requestDisallowInterceptTouchEvent", 
function (disallowIntercept) {
if (disallowIntercept == ((this.mGroupFlags & 524288) != 0)) {
return ;
}if (disallowIntercept) {
this.mGroupFlags |= 524288;
} else {
this.mGroupFlags &= -524289;
}if (this.mParent != null) {
this.mParent.requestDisallowInterceptTouchEvent (disallowIntercept);
}}, "~B");
Clazz.defineMethod (c$, "dispatchAttachedToWindow", 
function (info, visibility) {
Clazz.superCall (this, android.view.ViewGroup, "dispatchAttachedToWindow", [info, visibility]);
visibility |= this.mViewFlags & 12;
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
children[i].dispatchAttachedToWindow (info, visibility);
}
}, "android.view.View.AttachInfo,~N");
Clazz.defineMethod (c$, "dispatchDetachedFromWindow", 
function () {
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
children[i].dispatchDetachedFromWindow ();
}
Clazz.superCall (this, android.view.ViewGroup, "dispatchDetachedFromWindow", []);
});
Clazz.defineMethod (c$, "setPadding", 
function (left, top, right, bottom) {
Clazz.superCall (this, android.view.ViewGroup, "setPadding", [left, top, right, bottom]);
if ((this.mPaddingLeft | this.mPaddingTop | this.mPaddingRight | this.mPaddingRight) != 0) {
this.mGroupFlags |= 32;
} else {
this.mGroupFlags &= -33;
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "dispatchDraw", 
function (canvas) {
var count = this.mChildrenCount;
var children = this.mChildren;
var flags = this.mGroupFlags;
if ((flags & 8) != 0 && this.canAnimate ()) {
var cache = (this.mGroupFlags & 64) == 64;
for (var i = 0; i < count; i++) {
var child = children[i];
if ((child.mViewFlags & 12) == 0) {
var params = child.getLayoutParams ();
this.attachLayoutAnimationParameters (child, params, i, count);
this.bindLayoutAnimation (child);
}}
var controller = this.mLayoutAnimationController;
if (controller.willOverlap ()) {
this.mGroupFlags |= 128;
}controller.start ();
this.mGroupFlags &= -9;
this.mGroupFlags &= -17;
if (cache) {
this.mGroupFlags |= 32768;
}if (this.mAnimationListener != null) {
this.mAnimationListener.onAnimationStart (controller.getAnimation ());
}}var saveCount = 0;
var clipToPadding = (flags & 34) == 34;
if (clipToPadding) {
saveCount = canvas.save ();
canvas.clipRect (this.mScrollX + this.mPaddingLeft, this.mScrollY + this.mPaddingTop, this.mScrollX + this.mRight - this.mLeft - this.mPaddingRight, this.mScrollY + this.mBottom - this.mTop - this.mPaddingBottom);
}this.mPrivateFlags &= -65;
this.mGroupFlags &= -5;
var more = false;
var drawingTime = this.getDrawingTime ();
if ((flags & 1024) == 0) {
for (var i = 0; i < count; i++) {
var child = children[i];
if ((child.mViewFlags & 12) == 0 || child.getAnimation () != null) {
more = new Boolean (more | this.drawChild (canvas, child, drawingTime)).valueOf ();
}}
} else {
for (var i = 0; i < count; i++) {
var child = children[this.getChildDrawingOrder (count, i)];
if ((child.mViewFlags & 12) == 0 || child.getAnimation () != null) {
more = new Boolean (more | this.drawChild (canvas, child, drawingTime)).valueOf ();
}}
}if (clipToPadding) {
canvas.restoreToCount (saveCount);
}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "drawChild", 
function (canvas, child, drawingTime) {
var more = false;
var cl = child.mLeft;
var ct = child.mTop;
var cr = child.mRight;
var cb = child.mBottom;
var flags = this.mGroupFlags;
if ((flags & 256) == 256) {
if (this.mChildTransformation != null) {
this.mChildTransformation.clear ();
}this.mGroupFlags &= -257;
}var transformToApply = null;
var a = child.getAnimation ();
var concatMatrix = false;
if (a != null) {
if (this.mInvalidateRegion == null) {
this.mInvalidateRegion =  new android.graphics.RectF ();
}var region = this.mInvalidateRegion;
var initialized = a.isInitialized ();
if (!initialized) {
a.initialize (cr - cl, cb - ct, this.getWidth (), this.getHeight ());
a.initializeInvalidateRegion (0, 0, cr - cl, cb - ct);
child.onAnimationStart ();
}if (this.mChildTransformation == null) {
this.mChildTransformation =  new android.view.animation.Transformation ();
}more = a.getTransformation (drawingTime, this.mChildTransformation);
transformToApply = this.mChildTransformation;
concatMatrix = a.willChangeTransformationMatrix ();
if (more) {
if (!a.willChangeBounds ()) {
if ((flags & (144)) == 128) {
this.mGroupFlags |= 4;
} else if ((flags & 4) == 0) {
this.mPrivateFlags |= 64;
this.postInvalidateDelayed (17, cl, ct, cr, cb);
}} else {
a.getInvalidateRegion (0, 0, cr - cl, cb - ct, region, transformToApply);
this.mPrivateFlags |= 64;
var left = cl + Math.round (region.left);
var top = ct + Math.round (region.top);
this.postInvalidateDelayed (17, left, top, left + Math.round (region.width ()), top + Math.round (region.height ()));
}}} else if ((flags & 2048) == 2048) {
if (this.mChildTransformation == null) {
this.mChildTransformation =  new android.view.animation.Transformation ();
}var hasTransform = this.getChildStaticTransformation (child, this.mChildTransformation);
if (hasTransform) {
var transformType = this.mChildTransformation.getTransformationType ();
transformToApply = transformType != android.view.animation.Transformation.TYPE_IDENTITY ? this.mChildTransformation : null;
concatMatrix = (transformType & android.view.animation.Transformation.TYPE_MATRIX) != 0;
}}child.mPrivateFlags |= 32;
child.computeScroll ();
var sx = child.mScrollX;
var sy = child.mScrollY;
var scalingRequired = false;
var hasNoCache = true;
var restoreTo = canvas.save ();
if (true) {
canvas.translate (cl - sx, ct - sy);
} else {
canvas.translate (cl, ct);
if (scalingRequired) {
var scale = 1.0 / this.mAttachInfo.mApplicationScale;
canvas.scale (scale, scale);
}}var alpha = 1.0;
if (transformToApply != null) {
if (concatMatrix) {
var transX = 0;
var transY = 0;
if (true) {
transX = -sx;
transY = -sy;
}canvas.translate (-transX, -transY);
canvas.concat (transformToApply.getMatrix ());
canvas.translate (transX, transY);
this.mGroupFlags |= 256;
}alpha = transformToApply.getAlpha ();
if (alpha < 1.0) {
this.mGroupFlags |= 256;
}if (alpha < 1.0 && true) {
var multipliedAlpha = Math.round ((255 * alpha));
if (!child.onSetAlpha (multipliedAlpha)) {
android.util.Log.e ("ViewGroup", "saveLayerAlhpa is not implemented yet!");
} else {
child.mPrivateFlags |= 262144;
}}} else if ((child.mPrivateFlags & 262144) == 262144) {
child.onSetAlpha (255);
}if ((flags & 1) == 1) {
if (true) {
canvas.clipRect (sx, sy, sx + (cr - cl), sy + (cb - ct));
} else {
}}if (true) {
if ((child.mPrivateFlags & 128) == 128) {
child.mPrivateFlags &= -6291457;
child.dispatchDraw (canvas);
} else {
child.draw (canvas);
}}canvas.restoreToCount (restoreTo);
if (a != null && !more) {
child.onSetAlpha (255);
this.finishAnimatingView (child, a);
}return more;
}, "android.graphics.Canvas,android.view.View,~N");
Clazz.defineMethod (c$, "getChildDrawingOrder", 
function (childCount, i) {
return i;
}, "~N,~N");
Clazz.defineMethod (c$, "setClipChildren", 
function (clipChildren) {
this.setBooleanFlag (1, clipChildren);
}, "~B");
Clazz.defineMethod (c$, "setClipToPadding", 
function (clipToPadding) {
this.setBooleanFlag (2, clipToPadding);
}, "~B");
Clazz.overrideMethod (c$, "dispatchSetSelected", 
function (selected) {
var children = this.mChildren;
var count = this.mChildrenCount;
for (var i = 0; i < count; i++) {
children[i].setSelected (selected);
}
}, "~B");
Clazz.overrideMethod (c$, "dispatchSetPressed", 
function (pressed) {
var children = this.mChildren;
var count = this.mChildrenCount;
for (var i = 0; i < count; i++) {
children[i].setPressed (pressed);
}
}, "~B");
Clazz.defineMethod (c$, "setStaticTransformationsEnabled", 
function (enabled) {
this.setBooleanFlag (2048, enabled);
}, "~B");
Clazz.defineMethod (c$, "setVisibilityRec", 
function (visible) {
var children = this.mChildren;
var count = this.mChildrenCount;
for (var i = count - 1; i >= 0; i--) {
var view = children[i];
if (Clazz.instanceOf (view, android.view.ViewGroup)) (view).setVisibilityRec (visible);
var thisView = document.getElementById(view.mUIElementID);
if (thisView != null) thisView.style.visibility = visible;
}
}, "~S");
Clazz.defineMethod (c$, "getChildStaticTransformation", 
function (child, t) {
return false;
}, "android.view.View,android.view.animation.Transformation");
Clazz.overrideMethod (c$, "findViewTraversal", 
function (id) {
if (id == this.mID) {
return this;
}var where = this.mChildren;
var len = this.mChildrenCount;
for (var i = 0; i < len; i++) {
var v = where[i];
if ((v.mPrivateFlags & 8) == 0) {
v = v.findViewById (id);
if (v != null) {
return v;
}}}
return null;
}, "~N");
Clazz.overrideMethod (c$, "findViewWithTagTraversal", 
function (tag) {
if (tag != null && tag.equals (this.mTag)) {
return this;
}var where = this.mChildren;
var len = this.mChildrenCount;
for (var i = 0; i < len; i++) {
var v = where[i];
if ((v.mPrivateFlags & 8) == 0) {
v = v.findViewWithTag (tag);
if (v != null) {
return v;
}}}
return null;
}, "~O");
Clazz.defineMethod (c$, "addView", 
function (child) {
this.addView (child, -1);
}, "android.view.View");
Clazz.defineMethod (c$, "addView", 
function (child, index) {
if (child == null) throw  new NullPointerException ();
var params = child.getLayoutParams ();
if (params == null) {
params = this.generateDefaultLayoutParams ();
if (params == null) {
throw  new IllegalArgumentException ("generateDefaultLayoutParams() cannot return null");
}}this.addView (child, index, params, true);
}, "android.view.View,~N");
Clazz.defineMethod (c$, "addView", 
function (child, modifyDom) {
this.addView (child, -1, modifyDom);
}, "android.view.View,~B");
Clazz.defineMethod (c$, "addView", 
function (child, index, modifyDom) {
var params = child.getLayoutParams ();
if (params == null) {
params = this.generateDefaultLayoutParams ();
if (params == null) {
throw  new IllegalArgumentException ("generateDefaultLayoutParams() cannot return null");
}}this.addView (child, index, params, modifyDom);
}, "android.view.View,~N,~B");
Clazz.defineMethod (c$, "addView", 
function (child, width, height, modifyDom) {
var params = this.generateDefaultLayoutParams ();
params.width = width;
params.height = height;
this.addView (child, -1, params, modifyDom);
}, "android.view.View,~N,~N,~B");
Clazz.defineMethod (c$, "addView", 
function (child, params, modifyDom) {
this.addView (child, -1, params, modifyDom);
}, "android.view.View,android.view.ViewGroup.LayoutParams,~B");
Clazz.defineMethod (c$, "addView", 
function (child, index, params, modifyDom) {
this.addViewInner (child, index, params, false, modifyDom);
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams,~B");
Clazz.overrideMethod (c$, "updateViewLayout", 
function (view, params) {
if (!this.checkLayoutParams (params)) {
throw  new IllegalArgumentException ("Invalid LayoutParams supplied to ID: " + this.getUIElementID ());
}if (view.mParent !== this) {
throw  new IllegalArgumentException ("Given view not a child of ID: " + this.getUIElementID ());
}view.setLayoutParams (params);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "checkLayoutParams", 
function (p) {
return p != null;
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "setOnHierarchyChangeListener", 
function (listener) {
this.mOnHierarchyChangeListener = listener;
}, "android.view.ViewGroup.OnHierarchyChangeListener");
Clazz.defineMethod (c$, "addViewInLayout", 
function (child, index, params) {
return this.addViewInLayout (child, index, params, false);
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addViewInLayout", 
function (child, index, params, modifyDom) {
return this.addViewInLayout (child, index, params, false, modifyDom);
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams,~B");
Clazz.defineMethod (c$, "addViewInLayout", 
function (child, index, params, preventRequestLayout, modifyDom) {
child.mParent = null;
this.addViewInner (child, index, params, preventRequestLayout, modifyDom);
child.mPrivateFlags = (child.mPrivateFlags & -6291457) | 32;
return true;
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams,~B,~B");
Clazz.defineMethod (c$, "cleanupLayoutState", 
function (child) {
child.mPrivateFlags &= -4097;
}, "android.view.View");
Clazz.defineMethod (c$, "addViewInner", 
($fz = function (child, index, params, preventRequestLayout, modifyDom) {
if (child == null) throw  new NullPointerException ();
if (child.getParent () != null) {
throw  new IllegalStateException ("The specified child already has a parent. You must call removeView() on the child\'s parent first.");
}if (!this.checkLayoutParams (params)) {
if (params == null) throw  new NullPointerException ();
params = this.generateLayoutParams (params);
}child.mLayoutParams = params;
if (index < 0) {
index = this.mChildrenCount;
}if (modifyDom == true) {
this.addInArray (child, index);
}child.assignParent (this, modifyDom);
if (child.hasFocus ()) {
this.requestChildFocus (child, child.findFocus ());
}var ai = this.mAttachInfo;
if (ai != null) {
var lastKeepOn = ai.mKeepScreenOn;
ai.mKeepScreenOn = false;
child.dispatchAttachedToWindow (this.mAttachInfo, (this.mViewFlags & 12));
if (ai.mKeepScreenOn) {
this.needGlobalAttributesUpdate (true);
}ai.mKeepScreenOn = lastKeepOn;
}if (this.mOnHierarchyChangeListener != null) {
this.mOnHierarchyChangeListener.onChildViewAdded (this, child);
}if ((child.mViewFlags & 4194304) == 4194304) {
this.mGroupFlags |= 65536;
}}, $fz.isPrivate = true, $fz), "android.view.View,~N,android.view.ViewGroup.LayoutParams,~B,~B");
Clazz.defineMethod (c$, "addInArray", 
($fz = function (child, index) {
var children = this.mChildren;
var count = this.mChildrenCount;
var size = children.length;
if (index == count) {
if (size == count) {
this.mChildren =  new Array (size + 12);
System.arraycopy (children, 0, this.mChildren, 0, size);
children = this.mChildren;
}children[this.mChildrenCount++] = child;
} else if (index < count) {
if (size == count) {
this.mChildren =  new Array (size + 12);
System.arraycopy (children, 0, this.mChildren, 0, index);
System.arraycopy (children, index, this.mChildren, index + 1, count - index);
children = this.mChildren;
} else {
System.arraycopy (children, index, children, index + 1, count - index);
}children[index] = child;
this.mChildrenCount++;
} else {
throw  new IndexOutOfBoundsException ("index=" + index + " count=" + count);
}}, $fz.isPrivate = true, $fz), "android.view.View,~N");
Clazz.defineMethod (c$, "removeFromArray", 
($fz = function (index) {
var children = this.mChildren;
var count = this.mChildrenCount;
if (index < 0 || index >= count) {
throw  new IndexOutOfBoundsException ();
}var view = children[index];
view.mParent = null;
var child = document.getElementById(view.mUIElementID);
if (child != null) {
child.parentNode.removeChild(child);
}
if (index < count - 1) {
System.arraycopy (children, index + 1, children, index, this.mChildrenCount - 1 - index);
}children[--this.mChildrenCount] = null;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "removeFromArray", 
($fz = function (start, count) {
var children = this.mChildren;
var childrenCount = this.mChildrenCount;
start = Math.max (0, start);
var end = Math.min (childrenCount, start + count);
if (start == end) {
return ;
}if (end == childrenCount) {
for (var i = start; i < end; i++) {
children[i].mParent = null;
children[i] = null;
}
} else {
for (var i = start; i < end; i++) {
children[i].mParent = null;
}
System.arraycopy (children, end, children, start, childrenCount - end);
for (var i = childrenCount - (end - start); i < childrenCount; i++) {
children[i] = null;
}
}this.mChildrenCount -= (end - start);
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "bindLayoutAnimation", 
($fz = function (child) {
var a = this.mLayoutAnimationController.getAnimationForView (child);
child.setAnimation (a);
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "attachLayoutAnimationParameters", 
function (child, params, index, count) {
var animationParams = params.layoutAnimationParameters;
if (animationParams == null) {
animationParams =  new android.view.animation.LayoutAnimationController.AnimationParameters ();
params.layoutAnimationParameters = animationParams;
}animationParams.count = count;
animationParams.index = index;
}, "android.view.View,android.view.ViewGroup.LayoutParams,~N,~N");
Clazz.overrideMethod (c$, "removeView", 
function (view) {
this.removeViewInternal (view);
this.requestLayout ();
this.invalidate ();
}, "android.view.View");
Clazz.defineMethod (c$, "removeViewInLayout", 
function (view) {
this.removeViewInternal (view);
}, "android.view.View");
Clazz.defineMethod (c$, "removeViewsInLayout", 
function (start, count) {
this.removeViewsInternal (start, count);
}, "~N,~N");
Clazz.defineMethod (c$, "removeViewAt", 
function (index) {
this.removeViewInternal (index, this.getChildAt (index));
this.requestLayout ();
this.invalidate ();
}, "~N");
Clazz.defineMethod (c$, "removeViews", 
function (start, count) {
this.removeViewsInternal (start, count);
this.requestLayout ();
this.invalidate ();
}, "~N,~N");
Clazz.defineMethod (c$, "removeViewInternal", 
($fz = function (view) {
var index = this.indexOfChild (view);
if (index >= 0) {
this.removeViewInternal (index, view);
}}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "removeViewInternal", 
($fz = function (index, view) {
var clearChildFocus = false;
if (view === this.mFocused) {
view.clearFocusForRemoval ();
clearChildFocus = true;
}if (view.mAttachInfo != null) {
view.dispatchDetachedFromWindow ();
}if (this.mOnHierarchyChangeListener != null) {
this.mOnHierarchyChangeListener.onChildViewRemoved (this, view);
}this.needGlobalAttributesUpdate (false);
this.removeFromArray (index);
if (clearChildFocus) {
this.clearChildFocus (view);
}}, $fz.isPrivate = true, $fz), "~N,android.view.View");
Clazz.defineMethod (c$, "removeViewsInternal", 
($fz = function (start, count) {
var onHierarchyChangeListener = this.mOnHierarchyChangeListener;
var notifyListener = onHierarchyChangeListener != null;
var focused = this.mFocused;
var detach = this.mAttachInfo != null;
var clearChildFocus = null;
var children = this.mChildren;
var end = start + count;
for (var i = start; i < end; i++) {
var view = children[i];
if (view === focused) {
view.clearFocusForRemoval ();
clearChildFocus = view;
}if (detach) {
view.dispatchDetachedFromWindow ();
}this.needGlobalAttributesUpdate (false);
if (notifyListener) {
onHierarchyChangeListener.onChildViewRemoved (this, view);
}}
this.removeFromArray (start, count);
if (clearChildFocus != null) {
this.clearChildFocus (clearChildFocus);
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "removeAllViews", 
function () {
this.removeAllViewsInLayout ();
this.requestLayout ();
this.invalidate ();
});
Clazz.defineMethod (c$, "removeAllViewsInLayout", 
function () {
var count = this.mChildrenCount;
if (count <= 0) {
return ;
}var children = this.mChildren;
this.mChildrenCount = 0;
var listener = this.mOnHierarchyChangeListener;
var notify = listener != null;
var focused = this.mFocused;
var detach = this.mAttachInfo != null;
var clearChildFocus = null;
this.needGlobalAttributesUpdate (false);
for (var i = count - 1; i >= 0; i--) {
var view = children[i];
if (view === focused) {
view.clearFocusForRemoval ();
clearChildFocus = view;
}if (detach) {
view.dispatchDetachedFromWindow ();
}if (notify) {
listener.onChildViewRemoved (this, view);
}view.mParent = null;
children[i] = null;
if (Clazz.instanceOf (view, android.view.ViewGroup)) {
(view).removeAllViewsInLayout ();
}var child = document.getElementById(view.mUIElementID);
if (child != null) {
child.parentNode.removeChild(child);
}
}
if (clearChildFocus != null) {
this.clearChildFocus (clearChildFocus);
}});
Clazz.defineMethod (c$, "removeDetachedView", 
function (child, animate) {
if (child === this.mFocused) {
child.clearFocus ();
}if (child.mAttachInfo != null) {
child.dispatchDetachedFromWindow ();
}if (this.mOnHierarchyChangeListener != null) {
this.mOnHierarchyChangeListener.onChildViewRemoved (this, child);
}}, "android.view.View,~B");
Clazz.defineMethod (c$, "attachViewToParent", 
function (child, index, params) {
child.mLayoutParams = params;
if (index < 0) {
index = this.mChildrenCount;
}this.addInArray (child, index);
child.mParent = this;
child.mPrivateFlags = (child.mPrivateFlags & -6291457 & -32769) | 32;
if (child.hasFocus ()) {
this.requestChildFocus (child, child.findFocus ());
}}, "android.view.View,~N,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "detachViewFromParent", 
function (child) {
this.removeFromArray (this.indexOfChild (child));
}, "android.view.View");
Clazz.defineMethod (c$, "detachViewFromParent", 
function (index) {
this.removeFromArray (index);
}, "~N");
Clazz.defineMethod (c$, "detachViewsFromParent", 
function (start, count) {
this.removeFromArray (start, count);
}, "~N,~N");
Clazz.defineMethod (c$, "detachAllViewsFromParent", 
function () {
android.util.Log.d ("ViewGroup", "in detachAllViewsFromParent, can really detach?");
var count = this.mChildrenCount;
if (count <= 0) {
return ;
}var children = this.mChildren;
this.mChildrenCount = 0;
for (var i = count - 1; i >= 0; i--) {
children[i].mParent = null;
children[i] = null;
}
});
Clazz.overrideMethod (c$, "invalidateChild", 
function (child, dirty) {
var parent = this;
var attachInfo = this.mAttachInfo;
if (attachInfo != null) {
var location = attachInfo.mInvalidateChildLocation;
location[0] = child.mLeft;
location[1] = child.mTop;
var drawAnimation = (child.mPrivateFlags & 64) == 64;
var isOpaque = child.isOpaque () && !drawAnimation && child.getAnimation () != null;
var opaqueFlag = isOpaque ? 4194304 : 2097152;
do {
var view = null;
if (Clazz.instanceOf (parent, android.view.View)) {
view = parent;
}if (drawAnimation) {
if (view != null) {
view.mPrivateFlags |= 64;
} else if (Clazz.instanceOf (parent, android.view.ViewRoot)) {
(parent).mIsAnimating = true;
}}if (view != null && (view.mPrivateFlags & 6291456) != 2097152) {
view.mPrivateFlags = (view.mPrivateFlags & -6291457) | opaqueFlag;
}parent = parent.invalidateChildInParent (location, dirty);
} while (parent != null);
}}, "android.view.View,android.graphics.Rect");
Clazz.defineMethod (c$, "invalidateChildInParent", 
function (location, dirty) {
if ((this.mPrivateFlags & 32) == 32) {
if ((this.mGroupFlags & (144)) != 128) {
dirty.offset (location[0] - this.mScrollX, location[1] - this.mScrollY);
var left = this.mLeft;
var top = this.mTop;
if (dirty.intersect (0, 0, this.mRight - left, this.mBottom - top) || (this.mPrivateFlags & 64) == 64) {
this.mPrivateFlags &= -32769;
location[0] = left;
location[1] = top;
return this.mParent;
}} else {
this.mPrivateFlags &= -32801;
location[0] = this.mLeft;
location[1] = this.mTop;
dirty.set (0, 0, this.mRight - location[0], this.mBottom - location[1]);
return this.mParent;
}}return null;
}, "~A,android.graphics.Rect");
Clazz.defineMethod (c$, "offsetDescendantRectToMyCoords", 
function (descendant, rect) {
this.offsetRectBetweenParentAndChild (descendant, rect, true, false);
}, "android.view.View,android.graphics.Rect");
Clazz.defineMethod (c$, "offsetRectIntoDescendantCoords", 
function (descendant, rect) {
this.offsetRectBetweenParentAndChild (descendant, rect, false, false);
}, "android.view.View,android.graphics.Rect");
Clazz.defineMethod (c$, "offsetRectBetweenParentAndChild", 
function (descendant, rect, offsetFromChildToParent, clipToBounds) {
if (descendant === this) {
return ;
}var theParent = descendant.mParent;
while ((theParent != null) && (Clazz.instanceOf (theParent, android.view.View)) && (theParent !== this)) {
if (offsetFromChildToParent) {
rect.offset (descendant.mLeft - descendant.mScrollX, descendant.mTop - descendant.mScrollY);
if (clipToBounds) {
var p = theParent;
rect.intersect (0, 0, p.mRight - p.mLeft, p.mBottom - p.mTop);
}} else {
if (clipToBounds) {
var p = theParent;
rect.intersect (0, 0, p.mRight - p.mLeft, p.mBottom - p.mTop);
}rect.offset (descendant.mScrollX - descendant.mLeft, descendant.mScrollY - descendant.mTop);
}descendant = theParent;
theParent = descendant.mParent;
}
if (theParent === this) {
if (offsetFromChildToParent) {
rect.offset (descendant.mLeft - descendant.mScrollX, descendant.mTop - descendant.mScrollY);
} else {
rect.offset (descendant.mScrollX - descendant.mLeft, descendant.mScrollY - descendant.mTop);
}} else {
throw  new IllegalArgumentException ("parameter must be a descendant of this view");
}}, "android.view.View,android.graphics.Rect,~B,~B");
Clazz.defineMethod (c$, "offsetChildrenTopAndBottom", 
function (offset) {
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
var v = children[i];
v.mTop += offset;
v.mBottom += offset;
}
}, "~N");
Clazz.defineMethod (c$, "getChildVisibleRect", 
function (child, r, offset) {
var dx = child.mLeft - this.mScrollX;
var dy = child.mTop - this.mScrollY;
if (offset != null) {
offset.x += dx;
offset.y += dy;
}r.offset (dx, dy);
return r.intersect (0, 0, this.mRight - this.mLeft, this.mBottom - this.mTop) && (this.mParent == null || this.mParent.getChildVisibleRect (this, r, offset));
}, "android.view.View,android.graphics.Rect,android.graphics.Point");
Clazz.defineMethod (c$, "canAnimate", 
function () {
return this.mLayoutAnimationController != null;
});
Clazz.defineMethod (c$, "scheduleLayoutAnimation", 
function () {
this.mGroupFlags |= 8;
});
Clazz.defineMethod (c$, "setLayoutAnimation", 
function (controller) {
this.mLayoutAnimationController = controller;
if (this.mLayoutAnimationController != null) {
this.mGroupFlags |= 8;
}}, "android.view.animation.LayoutAnimationController");
Clazz.defineMethod (c$, "isChildrenDrawingOrderEnabled", 
function () {
return (this.mGroupFlags & 1024) == 1024;
});
Clazz.defineMethod (c$, "setChildrenDrawingOrderEnabled", 
function (enabled) {
this.setBooleanFlag (1024, enabled);
}, "~B");
Clazz.defineMethod (c$, "setBooleanFlag", 
($fz = function (flag, value) {
if (value) {
this.mGroupFlags |= flag;
} else {
this.mGroupFlags &= ~flag;
}}, $fz.isPrivate = true, $fz), "~N,~B");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (attrs) {
return  new android.view.ViewGroup.LayoutParams (this.getContext (), attrs);
}, "android.util.AttributeSet");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (p) {
return p;
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "generateDefaultLayoutParams", 
function () {
return  new android.view.ViewGroup.LayoutParams (-2, -2);
});
Clazz.defineMethod (c$, "indexOfChild", 
function (child) {
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
if (children[i] === child) {
return i;
}}
return -1;
}, "android.view.View");
Clazz.defineMethod (c$, "getChildCount", 
function () {
return this.mChildrenCount;
});
Clazz.defineMethod (c$, "getChildAt", 
function (index) {
try {
return this.mChildren[index];
} catch (ex) {
if (Clazz.instanceOf (ex, IndexOutOfBoundsException)) {
return null;
} else {
throw ex;
}
}
}, "~N");
Clazz.defineMethod (c$, "measureChildren", 
function (widthMeasureSpec, heightMeasureSpec) {
var size = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < size; ++i) {
var child = children[i];
if ((child.mViewFlags & 12) != 8) {
this.measureChild (child, widthMeasureSpec, heightMeasureSpec);
}}
}, "~N,~N");
Clazz.defineMethod (c$, "measureChild", 
function (child, parentWidthMeasureSpec, parentHeightMeasureSpec) {
var lp = child.getLayoutParams ();
var childWidthMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (parentWidthMeasureSpec, this.mPaddingLeft + this.mPaddingRight, lp.width);
var childHeightMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (parentHeightMeasureSpec, this.mPaddingTop + this.mPaddingBottom, lp.height);
child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}, "android.view.View,~N,~N");
Clazz.defineMethod (c$, "measureChildWithMargins", 
function (child, parentWidthMeasureSpec, widthUsed, parentHeightMeasureSpec, heightUsed) {
var lp = child.getLayoutParams ();
var childWidthMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (parentWidthMeasureSpec, this.mPaddingLeft + this.mPaddingRight + lp.leftMargin + lp.rightMargin + widthUsed, lp.width);
var childHeightMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (parentHeightMeasureSpec, this.mPaddingTop + this.mPaddingBottom + lp.topMargin + lp.bottomMargin + heightUsed, lp.height);
child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}, "android.view.View,~N,~N,~N,~N");
c$.getChildMeasureSpec = Clazz.defineMethod (c$, "getChildMeasureSpec", 
function (spec, padding, childDimension) {
var specMode = android.view.View.MeasureSpec.getMode (spec);
var specSize = android.view.View.MeasureSpec.getSize (spec);
if (isNaN(padding) == true) {
padding = 0;
}
var size = Math.max (0, specSize - padding);
var resultSize = 0;
var resultMode = 0;
switch (specMode) {
case 1073741824:
if (childDimension >= 0) {
resultSize = childDimension;
resultMode = 1073741824;
} else if (childDimension == -1) {
resultSize = size;
resultMode = 1073741824;
} else if (childDimension == -2) {
resultSize = size;
resultMode = -2147483648;
}break;
case -2147483648:
if (childDimension >= 0) {
resultSize = childDimension;
resultMode = 1073741824;
} else if (childDimension == -1) {
resultSize = size;
resultMode = -2147483648;
} else if (childDimension == -2) {
resultSize = size;
resultMode = -2147483648;
}break;
case 0:
if (childDimension >= 0) {
resultSize = childDimension;
resultMode = 1073741824;
} else if (childDimension == -1) {
resultSize = 0;
resultMode = 0;
} else if (childDimension == -2) {
resultSize = 0;
resultMode = 0;
}break;
}
return android.view.View.MeasureSpec.makeMeasureSpec (resultSize, resultMode);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "clearDisappearingChildren", 
function () {
if (this.mDisappearingChildren != null) {
this.mDisappearingChildren.clear ();
}});
Clazz.defineMethod (c$, "finishAnimatingView", 
($fz = function (view, animation) {
var disappearingChildren = this.mDisappearingChildren;
if (disappearingChildren != null) {
if (disappearingChildren.contains (view)) {
disappearingChildren.remove (view);
if (view.mAttachInfo != null) {
view.dispatchDetachedFromWindow ();
}view.clearAnimation ();
this.mGroupFlags |= 4;
}}if (animation != null && !animation.getFillAfter ()) {
view.clearAnimation ();
}if ((view.mPrivateFlags & 65536) == 65536) {
view.onAnimationEnd ();
view.mPrivateFlags &= -65537;
this.mGroupFlags |= 4;
}}, $fz.isPrivate = true, $fz), "android.view.View,android.view.animation.Animation");
Clazz.defineMethod (c$, "requestTransparentRegion", 
function (child) {
if (child != null) {
child.mPrivateFlags |= 512;
if (this.mParent != null) {
this.mParent.requestTransparentRegion (this);
}}}, "android.view.View");
Clazz.defineMethod (c$, "fitSystemWindows", 
function (insets) {
var done = Clazz.superCall (this, android.view.ViewGroup, "fitSystemWindows", [insets]);
if (!done) {
var count = this.mChildrenCount;
var children = this.mChildren;
for (var i = 0; i < count; i++) {
done = children[i].fitSystemWindows (insets);
if (done) {
break;
}}
}return done;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "onCreateDrawableState", 
function (extraSpace) {
if ((this.mGroupFlags & 8192) == 0) {
return Clazz.superCall (this, android.view.ViewGroup, "onCreateDrawableState", [extraSpace]);
}var need = 0;
var n = this.getChildCount ();
for (var i = 0; i < n; i++) {
var childState = this.getChildAt (i).getDrawableState ();
if (childState != null) {
need += childState.length;
}}
var state = Clazz.superCall (this, android.view.ViewGroup, "onCreateDrawableState", [extraSpace + need]);
for (var i = 0; i < n; i++) {
var childState = this.getChildAt (i).getDrawableState ();
if (childState != null) {
state = android.view.View.mergeDrawableStates (state, childState);
}}
return state;
}, "~N");
Clazz.defineMethod (c$, "setAddStatesFromChildren", 
function (addsStates) {
if (addsStates) {
this.mGroupFlags |= 8192;
} else {
this.mGroupFlags &= -8193;
}}, "~B");
Clazz.defineMethod (c$, "addStatesFromChildren", 
function () {
return (this.mGroupFlags & 8192) != 0;
});
Clazz.overrideMethod (c$, "verifyDrawable", 
function (who) {
return false;
}, "android.graphics.drawable.Drawable");
Clazz.overrideMethod (c$, "drawableStateChanged", 
function () {
});
Clazz.overrideMethod (c$, "findElementViewTraversal", 
function (viewElementId) {
if (viewElementId == this.getUIElementID ()) {
return this;
}var where = this.mChildren;
var len = this.mChildrenCount;
for (var i = 0; i < len; i++) {
var v = where[i];
v = v.findViewByElementId (viewElementId);
if (v != null) {
return v;
}}
return null;
}, "~N");
Clazz.defineMethod (c$, "onInterceptTouchEvent", 
function (event) {
return false;
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "addView", 
function (child, params) {
this.addView (child, -1, params);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addView", 
function (child, index, params) {
this.requestLayout ();
this.invalidate ();
this.addViewInner (child, index, params, false);
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addViewInner", 
($fz = function (child, index, params, preventRequestLayout) {
if (child.getParent () != null) {
throw  new IllegalStateException ("The specified child already has a parent. You must call removeView() on the child\'s parent first.");
}if (!this.checkLayoutParams (params)) {
if (params == null) throw  new NullPointerException ();
params = this.generateLayoutParams (params);
}if (preventRequestLayout) {
child.mLayoutParams = params;
} else {
child.setLayoutParams (params);
}if (index < 0) {
index = this.mChildrenCount;
}this.addInArray (child, index);
if (preventRequestLayout) {
child.assignParent (this, true);
} else {
child.mParent = this;
}if (child.hasFocus ()) {
this.requestChildFocus (child, child.findFocus ());
}var ai = this.mAttachInfo;
if (ai != null) {
var lastKeepOn = ai.mKeepScreenOn;
ai.mKeepScreenOn = false;
child.dispatchAttachedToWindow (this.mAttachInfo, (this.mViewFlags & 12));
if (ai.mKeepScreenOn) {
this.needGlobalAttributesUpdate (true);
}ai.mKeepScreenOn = lastKeepOn;
}if (this.mOnHierarchyChangeListener != null) {
this.mOnHierarchyChangeListener.onChildViewAdded (this, child);
}if ((child.mViewFlags & 4194304) == 4194304) {
this.mGroupFlags |= 65536;
}}, $fz.isPrivate = true, $fz), "android.view.View,~N,android.view.ViewGroup.LayoutParams,~B");
Clazz.defineMethod (c$, "focusSearch", 
function (v, direction) {
return null;
}, "android.view.View,~N");
Clazz.overrideMethod (c$, "childDrawableStateChanged", 
function (child) {
if ((this.mGroupFlags & 8192) != 0) {
this.refreshDrawableState ();
}}, "android.view.View");
Clazz.defineMethod (c$, "onRequestFocusInDescendants", 
function (direction, previouslyFocusedRect) {
var index;
var increment;
var end;
var count = this.mChildrenCount;
if ((direction & 2) != 0) {
index = 0;
increment = 1;
end = count;
} else {
index = count - 1;
increment = -1;
end = -1;
}var children = this.mChildren;
for (var i = index; i != end; i += increment) {
var child = children[i];
if ((child.mViewFlags & 12) == 0) {
if (child.requestFocus (direction, previouslyFocusedRect)) {
return true;
}}}
return false;
}, "~N,android.graphics.Rect");
Clazz.defineMethod (c$, "addPendingChild", 
function (pendingChild) {
android.util.Log.d ("ViewGroup", "Adding View " + pendingChild.getUIElementID () + " as pending child for View " + this.getUIElementID ());
this.mPendingChildren.add (pendingChild);
}, "android.view.View");
Clazz.defineMethod (c$, "fixPendingChildren", 
function () {
for (var child, $child = this.mPendingChildren.iterator (); $child.hasNext () && ((child = $child.next ()) || true);) {
child.fixParent (this, true);
}
this.mPendingChildren.clear ();
});
Clazz.defineMethod (c$, "setLayoutAnimationListener", 
function (animationListener) {
console.log("Missing method: setLayoutAnimationListener");
}, "android.view.animation.Animation.AnimationListener");
Clazz.defineMethod (c$, "setAnimationCacheEnabled", 
function (enabled) {
console.log("Missing method: setAnimationCacheEnabled");
}, "~B");
Clazz.defineMethod (c$, "setChildrenDrawnWithCacheEnabled", 
function (enabled) {
console.log("Missing method: setChildrenDrawnWithCacheEnabled");
}, "~B");
Clazz.defineMethod (c$, "getPersistentDrawingCache", 
function () {
console.log("Missing method: getPersistentDrawingCache");
});
Clazz.defineMethod (c$, "debug", 
function (depth) {
console.log("Missing method: debug");
}, "~N");
Clazz.defineMethod (c$, "setPersistentDrawingCache", 
function (drawingCacheToKeep) {
console.log("Missing method: setPersistentDrawingCache");
}, "~N");
Clazz.defineMethod (c$, "startLayoutAnimation", 
function () {
console.log("Missing method: startLayoutAnimation");
});
Clazz.defineMethod (c$, "isChildrenDrawnWithCacheEnabled", 
function () {
console.log("Missing method: isChildrenDrawnWithCacheEnabled");
});
Clazz.defineMethod (c$, "isAnimationCacheEnabled", 
function () {
console.log("Missing method: isAnimationCacheEnabled");
});
Clazz.defineMethod (c$, "isAlwaysDrawnWithCacheEnabled", 
function () {
console.log("Missing method: isAlwaysDrawnWithCacheEnabled");
});
Clazz.defineMethod (c$, "setChildrenDrawingCacheEnabled", 
function (enabled) {
console.log("Missing method: setChildrenDrawingCacheEnabled");
}, "~B");
Clazz.defineMethod (c$, "setAlwaysDrawnWithCacheEnabled", 
function (always) {
console.log("Missing method: setAlwaysDrawnWithCacheEnabled");
}, "~B");
Clazz.defineMethod (c$, "debug", 
function (output) {
console.log("Missing method: debug");
}, "~S");
Clazz.declareInterface (android.view.ViewGroup, "OnHierarchyChangeListener");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.width = 0;
this.height = 0;
this.layoutAnimationParameters = null;
Clazz.instantialize (this, arguments);
}, android.view.ViewGroup, "LayoutParams");
Clazz.makeConstructor (c$, 
function (a, b) {
var c = a.obtainStyledAttributes (b, com.android.internal.R.styleable.ViewGroup_Layout);
this.setBaseAttributes (c, 0, 1);
c.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (a, b) {
this.width = a;
this.height = b;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
if (a == null) {
throw  new NullPointerException ("ViewGroup.LayoutParams->source is null");
}this.width = a.width;
this.height = a.height;
}, "android.view.ViewGroup.LayoutParams");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "setBaseAttributes", 
function (a, b, c) {
if (a == null) {
throw  new NullPointerException ("ViewGroup.setBaseAttributes parame a is null");
}this.width = a.getLayoutDimension (b, "layout_width");
this.height = a.getLayoutDimension (c, "layout_height");
}, "android.content.res.TypedArray,~N,~N");
Clazz.defineMethod (c$, "debug", 
function (a) {
return a + "ViewGroup.LayoutParams={ width=" + android.view.ViewGroup.LayoutParams.sizeToString (this.width) + ", height=" + android.view.ViewGroup.LayoutParams.sizeToString (this.height) + " }";
}, "~S");
c$.sizeToString = Clazz.defineMethod (c$, "sizeToString", 
function (a) {
if (a == -2) {
return "wrap-content";
}if (a == -1) {
return "match-parent";
}return String.valueOf (a);
}, "~N");
Clazz.defineStatics (c$,
"FILL_PARENT", -1,
"MATCH_PARENT", -1,
"WRAP_CONTENT", -2);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.leftMargin = 0;
this.topMargin = 0;
this.rightMargin = 0;
this.bottomMargin = 0;
Clazz.instantialize (this, arguments);
}, android.view.ViewGroup, "MarginLayoutParams", android.view.ViewGroup.LayoutParams);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.view.ViewGroup.MarginLayoutParams);
if (a == null) {
throw  new NullPointerException ("ViewGroup.MarginLayoutParams c is null");
}var c = a.obtainStyledAttributes (b, com.android.internal.R.styleable.ViewGroup_MarginLayout);
this.setBaseAttributes (c, 0, 1);
var d = c.getDimensionPixelSize (2, -1);
if (d >= 0) {
this.leftMargin = d;
this.topMargin = d;
this.rightMargin = d;
this.bottomMargin = d;
} else {
this.leftMargin = c.getDimensionPixelSize (3, 0);
this.topMargin = c.getDimensionPixelSize (4, 0);
this.rightMargin = c.getDimensionPixelSize (5, 0);
this.bottomMargin = c.getDimensionPixelSize (6, 0);
}c.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.view.ViewGroup.MarginLayoutParams, []);
if (a == null) {
throw  new NullPointerException ("ViewGroup.MarginLayoutParams->source is null");
}this.width = a.width;
this.height = a.height;
this.leftMargin = a.leftMargin;
this.topMargin = a.topMargin;
this.rightMargin = a.rightMargin;
this.bottomMargin = a.bottomMargin;
}, "android.view.ViewGroup.MarginLayoutParams");
Clazz.defineMethod (c$, "setMargins", 
function (a, b, c, d) {
this.leftMargin = a;
this.topMargin = b;
this.rightMargin = c;
this.bottomMargin = d;
}, "~N,~N,~N,~N");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"$DBG", false,
"TAG", "ViewGroup",
"FLAG_CLIP_CHILDREN", 0x1,
"FLAG_CLIP_TO_PADDING", 0x2,
"FLAG_INVALIDATE_REQUIRED", 0x4,
"FLAG_RUN_ANIMATION", 0x8,
"FLAG_ANIMATION_DONE", 0x10,
"FLAG_PADDING_NOT_NULL", 0x20,
"FLAG_ANIMATION_CACHE", 0x40,
"FLAG_OPTIMIZE_INVALIDATE", 0x80,
"FLAG_CLEAR_TRANSFORMATION", 0x100,
"FLAG_NOTIFY_ANIMATION_LISTENER", 0x200,
"FLAG_USE_CHILD_DRAWING_ORDER", 0x400,
"FLAG_SUPPORT_STATIC_TRANSFORMATIONS", 0x800,
"FLAG_ALPHA_LOWER_THAN_ONE", 0x1000,
"FLAG_ADD_STATES_FROM_CHILDREN", 0x2000,
"FLAG_ALWAYS_DRAWN_WITH_CACHE", 0x4000,
"FLAG_CHILDREN_DRAWN_WITH_CACHE", 0x8000,
"FLAG_NOTIFY_CHILDREN_ON_DRAWABLE_STATE_CHANGE", 0x10000,
"FLAG_MASK_FOCUSABILITY", 0x60000,
"FOCUS_BEFORE_DESCENDANTS", 0x20000,
"FOCUS_AFTER_DESCENDANTS", 0x40000,
"FOCUS_BLOCK_DESCENDANTS", 0x60000,
"DESCENDANT_FOCUSABILITY_FLAGS", [131072, 262144, 393216],
"FLAG_DISALLOW_INTERCEPT", 0x80000,
"PERSISTENT_NO_CACHE", 0x0,
"PERSISTENT_ANIMATION_CACHE", 0x1,
"PERSISTENT_SCROLLING_CACHE", 0x2,
"PERSISTENT_ALL_CACHES", 0x3,
"CLIP_TO_PADDING_MASK", 34,
"CHILD_LEFT_INDEX", 0,
"CHILD_TOP_INDEX", 1,
"ARRAY_INITIAL_CAPACITY", 12,
"ARRAY_CAPACITY_INCREMENT", 12);
});
