﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.os.Parcelable"], "android.view.InputDevice", ["android.view.KeyCharacterMap", "java.lang.IllegalArgumentException", "$.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mId = 0;
this.mName = null;
this.mSources = 0;
this.mKeyboardType = 0;
this.mMotionRanges = null;
Clazz.instantialize (this, arguments);
}, android.view, "InputDevice", null, android.os.Parcelable);
c$.getDevice = Clazz.defineMethod (c$, "getDevice", 
function (id) {
return null;
}, "~N");
Clazz.defineMethod (c$, "getId", 
function () {
return this.mId;
});
Clazz.defineMethod (c$, "getName", 
function () {
return this.mName;
});
Clazz.defineMethod (c$, "getSources", 
function () {
return this.mSources;
});
Clazz.defineMethod (c$, "getKeyboardType", 
function () {
return this.mKeyboardType;
});
Clazz.defineMethod (c$, "getKeyCharacterMap", 
function () {
return android.view.KeyCharacterMap.load (this.mId);
});
Clazz.defineMethod (c$, "getMotionRange", 
function (rangeType) {
if (rangeType < 0 || rangeType > 8) {
throw  new IllegalArgumentException ("Requested range is out of bounds.");
}return this.mMotionRanges[rangeType];
}, "~N");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.overrideMethod (c$, "toString", 
function () {
var description =  new StringBuilder ();
description.append ("Input Device ").append (this.mId).append (": ").append (this.mName).append ("\n");
description.append ("  Keyboard Type: ");
switch (this.mKeyboardType) {
case 0:
description.append ("none");
break;
case 1:
description.append ("non-alphabetic");
break;
case 2:
description.append ("alphabetic");
break;
}
description.append ("\n");
description.append ("  Sources:");
this.appendSourceDescriptionIfApplicable (description, 257, "keyboard");
this.appendSourceDescriptionIfApplicable (description, 513, "dpad");
this.appendSourceDescriptionIfApplicable (description, 4098, "touchscreen");
this.appendSourceDescriptionIfApplicable (description, 8194, "mouse");
this.appendSourceDescriptionIfApplicable (description, 65540, "trackball");
this.appendSourceDescriptionIfApplicable (description, 1048584, "touchpad");
description.append ("\n");
this.appendRangeDescriptionIfApplicable (description, 0, "x");
this.appendRangeDescriptionIfApplicable (description, 1, "y");
this.appendRangeDescriptionIfApplicable (description, 2, "pressure");
this.appendRangeDescriptionIfApplicable (description, 3, "size");
this.appendRangeDescriptionIfApplicable (description, 4, "touchMajor");
this.appendRangeDescriptionIfApplicable (description, 5, "touchMinor");
this.appendRangeDescriptionIfApplicable (description, 6, "toolMajor");
this.appendRangeDescriptionIfApplicable (description, 7, "toolMinor");
this.appendRangeDescriptionIfApplicable (description, 8, "orientation");
return description.toString ();
});
Clazz.defineMethod (c$, "appendSourceDescriptionIfApplicable", 
($fz = function (description, source, sourceName) {
if ((this.mSources & source) == source) {
description.append (" ");
description.append (sourceName);
}}, $fz.isPrivate = true, $fz), "StringBuilder,~N,~S");
Clazz.defineMethod (c$, "appendRangeDescriptionIfApplicable", 
($fz = function (description, rangeType, rangeName) {
var range = this.mMotionRanges[rangeType];
if (range != null) {
description.append ("  Range[").append (rangeName);
description.append ("]: min=").append (range.mMin);
description.append (" max=").append (range.mMax);
description.append (" flat=").append (range.mFlat);
description.append (" fuzz=").append (range.mFuzz);
description.append ("\n");
}}, $fz.isPrivate = true, $fz), "StringBuilder,~N,~S");
c$.getDeviceIds = Clazz.defineMethod (c$, "getDeviceIds", 
function () {
console.log("Missing method: getDeviceIds");
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mMin = 0;
this.mMax = 0;
this.mFlat = 0;
this.mFuzz = 0;
Clazz.instantialize (this, arguments);
}, android.view.InputDevice, "MotionRange");
Clazz.makeConstructor (c$, 
($fz = function (a, b, c, d) {
this.mMin = a;
this.mMax = b;
this.mFlat = c;
this.mFuzz = d;
}, $fz.isPrivate = true, $fz), "~N,~N,~N,~N");
Clazz.defineMethod (c$, "getMin", 
function () {
return this.mMin;
});
Clazz.defineMethod (c$, "getMax", 
function () {
return this.mMax;
});
Clazz.defineMethod (c$, "getRange", 
function () {
return this.mMax - this.mMin;
});
Clazz.defineMethod (c$, "getFlat", 
function () {
return this.mFlat;
});
Clazz.defineMethod (c$, "getFuzz", 
function () {
return this.mFuzz;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"SOURCE_CLASS_MASK", 0x000000ff,
"SOURCE_CLASS_BUTTON", 0x00000001,
"SOURCE_CLASS_POINTER", 0x00000002,
"SOURCE_CLASS_TRACKBALL", 0x00000004,
"SOURCE_CLASS_POSITION", 0x00000008,
"SOURCE_UNKNOWN", 0x00000000,
"SOURCE_KEYBOARD", 257,
"SOURCE_DPAD", 513,
"SOURCE_TOUCHSCREEN", 4098,
"SOURCE_MOUSE", 8194,
"SOURCE_TRACKBALL", 65540,
"SOURCE_TOUCHPAD", 1048584,
"SOURCE_ANY", 0xffffff00,
"MOTION_RANGE_X", 0,
"MOTION_RANGE_Y", 1,
"MOTION_RANGE_PRESSURE", 2,
"MOTION_RANGE_SIZE", 3,
"MOTION_RANGE_TOUCH_MAJOR", 4,
"MOTION_RANGE_TOUCH_MINOR", 5,
"MOTION_RANGE_TOOL_MAJOR", 6,
"MOTION_RANGE_TOOL_MINOR", 7,
"MOTION_RANGE_ORIENTATION", 8,
"MOTION_RANGE_LAST", 8,
"KEYBOARD_TYPE_NONE", 0,
"KEYBOARD_TYPE_NON_ALPHABETIC", 1,
"KEYBOARD_TYPE_ALPHABETIC", 2);
});
