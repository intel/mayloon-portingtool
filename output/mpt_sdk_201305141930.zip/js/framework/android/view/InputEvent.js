﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.os.Parcelable"], "android.view.InputEvent", ["android.view.InputDevice"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDeviceId = 0;
this.mSource = 0;
Clazz.instantialize (this, arguments);
}, android.view, "InputEvent", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "getDeviceId", 
function () {
return this.mDeviceId;
});
Clazz.defineMethod (c$, "getDevice", 
function () {
return android.view.InputDevice.getDevice (this.mDeviceId);
});
Clazz.defineMethod (c$, "getSource", 
function () {
return this.mSource;
});
Clazz.defineMethod (c$, "setSource", 
function (source) {
this.mSource = source;
}, "~N");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineStatics (c$,
"PARCEL_TOKEN_MOTION_EVENT", 1,
"PARCEL_TOKEN_KEY_EVENT", 2);
});
