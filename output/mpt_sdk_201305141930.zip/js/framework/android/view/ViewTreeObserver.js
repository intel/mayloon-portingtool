﻿Clazz.declarePackage ("android.view");
Clazz.load (["android.graphics.Rect"], "android.view.ViewTreeObserver", ["java.lang.IllegalStateException", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mOnGlobalFocusListeners = null;
this.mOnGlobalLayoutListeners = null;
this.mOnPreDrawListeners = null;
this.mOnTouchModeChangeListeners = null;
this.mOnComputeInternalInsetsListeners = null;
this.mOnScrollChangedListeners = null;
this.mAlive = true;
Clazz.instantialize (this, arguments);
}, android.view, "ViewTreeObserver");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "merge", 
function (observer) {
if (observer.mOnGlobalFocusListeners != null) {
if (this.mOnGlobalFocusListeners != null) {
this.mOnGlobalFocusListeners.addAll (observer.mOnGlobalFocusListeners);
} else {
this.mOnGlobalFocusListeners = observer.mOnGlobalFocusListeners;
}}if (observer.mOnGlobalLayoutListeners != null) {
if (this.mOnGlobalLayoutListeners != null) {
this.mOnGlobalLayoutListeners.addAll (observer.mOnGlobalLayoutListeners);
} else {
this.mOnGlobalLayoutListeners = observer.mOnGlobalLayoutListeners;
}}if (observer.mOnPreDrawListeners != null) {
if (this.mOnPreDrawListeners != null) {
this.mOnPreDrawListeners.addAll (observer.mOnPreDrawListeners);
} else {
this.mOnPreDrawListeners = observer.mOnPreDrawListeners;
}}if (observer.mOnTouchModeChangeListeners != null) {
if (this.mOnTouchModeChangeListeners != null) {
this.mOnTouchModeChangeListeners.addAll (observer.mOnTouchModeChangeListeners);
} else {
this.mOnTouchModeChangeListeners = observer.mOnTouchModeChangeListeners;
}}if (observer.mOnComputeInternalInsetsListeners != null) {
if (this.mOnComputeInternalInsetsListeners != null) {
this.mOnComputeInternalInsetsListeners.addAll (observer.mOnComputeInternalInsetsListeners);
} else {
this.mOnComputeInternalInsetsListeners = observer.mOnComputeInternalInsetsListeners;
}}observer.kill ();
}, "android.view.ViewTreeObserver");
Clazz.defineMethod (c$, "addOnGlobalFocusChangeListener", 
function (listener) {
this.checkIsAlive ();
if (this.mOnGlobalFocusListeners == null) {
this.mOnGlobalFocusListeners =  new java.util.ArrayList ();
}this.mOnGlobalFocusListeners.add (listener);
}, "android.view.ViewTreeObserver.OnGlobalFocusChangeListener");
Clazz.defineMethod (c$, "removeOnGlobalFocusChangeListener", 
function (victim) {
this.checkIsAlive ();
if (this.mOnGlobalFocusListeners == null) {
return ;
}this.mOnGlobalFocusListeners.remove (victim);
}, "android.view.ViewTreeObserver.OnGlobalFocusChangeListener");
Clazz.defineMethod (c$, "addOnGlobalLayoutListener", 
function (listener) {
this.checkIsAlive ();
if (this.mOnGlobalLayoutListeners == null) {
this.mOnGlobalLayoutListeners =  new java.util.ArrayList ();
}this.mOnGlobalLayoutListeners.add (listener);
}, "android.view.ViewTreeObserver.OnGlobalLayoutListener");
Clazz.defineMethod (c$, "removeGlobalOnLayoutListener", 
function (victim) {
this.checkIsAlive ();
if (this.mOnGlobalLayoutListeners == null) {
return ;
}this.mOnGlobalLayoutListeners.remove (victim);
}, "android.view.ViewTreeObserver.OnGlobalLayoutListener");
Clazz.defineMethod (c$, "addOnPreDrawListener", 
function (listener) {
this.checkIsAlive ();
if (this.mOnPreDrawListeners == null) {
this.mOnPreDrawListeners =  new java.util.ArrayList ();
}this.mOnPreDrawListeners.add (listener);
}, "android.view.ViewTreeObserver.OnPreDrawListener");
Clazz.defineMethod (c$, "removeOnPreDrawListener", 
function (victim) {
this.checkIsAlive ();
if (this.mOnPreDrawListeners == null) {
return ;
}this.mOnPreDrawListeners.remove (victim);
}, "android.view.ViewTreeObserver.OnPreDrawListener");
Clazz.defineMethod (c$, "addOnScrollChangedListener", 
function (listener) {
this.checkIsAlive ();
if (this.mOnScrollChangedListeners == null) {
this.mOnScrollChangedListeners =  new java.util.ArrayList ();
}this.mOnScrollChangedListeners.add (listener);
}, "android.view.ViewTreeObserver.OnScrollChangedListener");
Clazz.defineMethod (c$, "removeOnScrollChangedListener", 
function (victim) {
this.checkIsAlive ();
if (this.mOnScrollChangedListeners == null) {
return ;
}this.mOnScrollChangedListeners.remove (victim);
}, "android.view.ViewTreeObserver.OnScrollChangedListener");
Clazz.defineMethod (c$, "addOnTouchModeChangeListener", 
function (listener) {
this.checkIsAlive ();
if (this.mOnTouchModeChangeListeners == null) {
this.mOnTouchModeChangeListeners =  new java.util.ArrayList ();
}this.mOnTouchModeChangeListeners.add (listener);
}, "android.view.ViewTreeObserver.OnTouchModeChangeListener");
Clazz.defineMethod (c$, "removeOnTouchModeChangeListener", 
function (victim) {
this.checkIsAlive ();
if (this.mOnTouchModeChangeListeners == null) {
return ;
}this.mOnTouchModeChangeListeners.remove (victim);
}, "android.view.ViewTreeObserver.OnTouchModeChangeListener");
Clazz.defineMethod (c$, "addOnComputeInternalInsetsListener", 
function (listener) {
this.checkIsAlive ();
if (this.mOnComputeInternalInsetsListeners == null) {
this.mOnComputeInternalInsetsListeners =  new java.util.ArrayList ();
}this.mOnComputeInternalInsetsListeners.add (listener);
}, "android.view.ViewTreeObserver.OnComputeInternalInsetsListener");
Clazz.defineMethod (c$, "removeOnComputeInternalInsetsListener", 
function (victim) {
this.checkIsAlive ();
if (this.mOnComputeInternalInsetsListeners == null) {
return ;
}this.mOnComputeInternalInsetsListeners.remove (victim);
}, "android.view.ViewTreeObserver.OnComputeInternalInsetsListener");
Clazz.defineMethod (c$, "checkIsAlive", 
($fz = function () {
if (!this.mAlive) {
throw  new IllegalStateException ("This ViewTreeObserver is not alive, call getViewTreeObserver() again");
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "isAlive", 
function () {
return this.mAlive;
});
Clazz.defineMethod (c$, "kill", 
($fz = function () {
this.mAlive = false;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "dispatchOnGlobalFocusChange", 
function (oldFocus, newFocus) {
var listeners = this.mOnGlobalFocusListeners;
if (listeners != null) {
for (var listener, $listener = listeners.iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
listener.onGlobalFocusChanged (oldFocus, newFocus);
}
}}, "android.view.View,android.view.View");
Clazz.defineMethod (c$, "dispatchOnGlobalLayout", 
function () {
var listeners = this.mOnGlobalLayoutListeners;
if (listeners != null) {
for (var listener, $listener = listeners.iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
listener.onGlobalLayout ();
}
}});
Clazz.defineMethod (c$, "dispatchOnPreDraw", 
function () {
var cancelDraw = false;
var listeners = this.mOnPreDrawListeners;
if (listeners != null) {
for (var listener, $listener = listeners.iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
cancelDraw = new Boolean (cancelDraw | !listener.onPreDraw ()).valueOf ();
}
}return cancelDraw;
});
Clazz.defineMethod (c$, "dispatchOnTouchModeChanged", 
function (inTouchMode) {
var listeners = this.mOnTouchModeChangeListeners;
if (listeners != null) {
for (var listener, $listener = listeners.iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
listener.onTouchModeChanged (inTouchMode);
}
}}, "~B");
Clazz.defineMethod (c$, "dispatchOnScrollChanged", 
function () {
var listeners = this.mOnScrollChangedListeners;
if (listeners != null) {
for (var listener, $listener = listeners.iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
listener.onScrollChanged ();
}
}});
Clazz.defineMethod (c$, "hasComputeInternalInsetsListeners", 
function () {
var listeners = this.mOnComputeInternalInsetsListeners;
return (listeners != null && listeners.size () > 0);
});
Clazz.defineMethod (c$, "dispatchOnComputeInternalInsets", 
function (inoutInfo) {
var listeners = this.mOnComputeInternalInsetsListeners;
if (listeners != null) {
for (var listener, $listener = listeners.iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
listener.onComputeInternalInsets (inoutInfo);
}
}}, "android.view.ViewTreeObserver.InternalInsetsInfo");
Clazz.declareInterface (android.view.ViewTreeObserver, "OnGlobalFocusChangeListener");
Clazz.declareInterface (android.view.ViewTreeObserver, "OnGlobalLayoutListener");
Clazz.declareInterface (android.view.ViewTreeObserver, "OnPreDrawListener");
Clazz.declareInterface (android.view.ViewTreeObserver, "OnTouchModeChangeListener");
Clazz.declareInterface (android.view.ViewTreeObserver, "OnScrollChangedListener");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.contentInsets = null;
this.visibleInsets = null;
this.mTouchableInsets = 0;
Clazz.instantialize (this, arguments);
}, android.view.ViewTreeObserver, "InternalInsetsInfo");
Clazz.prepareFields (c$, function () {
this.contentInsets =  new android.graphics.Rect ();
this.visibleInsets =  new android.graphics.Rect ();
});
Clazz.defineMethod (c$, "setTouchableInsets", 
function (a) {
this.mTouchableInsets = a;
}, "~N");
Clazz.defineMethod (c$, "getTouchableInsets", 
function () {
return this.mTouchableInsets;
});
Clazz.defineMethod (c$, "reset", 
function () {
var a = this.contentInsets;
var b = this.visibleInsets;
a.left = a.top = a.right = a.bottom = b.left = b.top = b.right = b.bottom = 0;
this.mTouchableInsets = 0;
});
Clazz.overrideMethod (c$, "equals", 
function (a) {
try {
if (a == null) {
return false;
}var b = a;
if (!this.contentInsets.equals (b.contentInsets)) {
return false;
}if (!this.visibleInsets.equals (b.visibleInsets)) {
return false;
}return this.mTouchableInsets == b.mTouchableInsets;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
return false;
} else {
throw e;
}
}
}, "~O");
Clazz.defineMethod (c$, "set", 
function (a) {
this.contentInsets.set (a.contentInsets);
this.visibleInsets.set (a.visibleInsets);
this.mTouchableInsets = a.mTouchableInsets;
}, "android.view.ViewTreeObserver.InternalInsetsInfo");
Clazz.defineStatics (c$,
"TOUCHABLE_INSETS_FRAME", 0,
"TOUCHABLE_INSETS_CONTENT", 1,
"TOUCHABLE_INSETS_VISIBLE", 2);
c$ = Clazz.p0p ();
Clazz.declareInterface (android.view.ViewTreeObserver, "OnComputeInternalInsetsListener");
});
