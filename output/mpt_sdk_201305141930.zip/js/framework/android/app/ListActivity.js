﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.app.Activity", "android.os.Handler", "android.widget.AdapterView.OnItemClickListener"], "android.app.ListActivity", ["java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAdapter = null;
this.mList = null;
this.mHandler = null;
this.mFinishedStart = false;
this.mRequestFocus = null;
this.mOnClickListener = null;
Clazz.instantialize (this, arguments);
}, android.app, "ListActivity", android.app.Activity);
Clazz.prepareFields (c$, function () {
this.mHandler =  new android.os.Handler ();
this.mRequestFocus = ((Clazz.isClassDefined ("android.app.ListActivity$1") ? 0 : android.app.ListActivity.$ListActivity$1$ ()), Clazz.innerTypeInstance (android.app.ListActivity$1, this, null));
this.mOnClickListener = ((Clazz.isClassDefined ("android.app.ListActivity$2") ? 0 : android.app.ListActivity.$ListActivity$2$ ()), Clazz.innerTypeInstance (android.app.ListActivity$2, this, null));
});
Clazz.defineMethod (c$, "onListItemClick", 
function (l, v, position, id) {
System.out.println ("ListActivity:onListItemClick");
}, "android.widget.ListView,android.view.View,~N,~N");
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
this.ensureList ();
Clazz.superCall (this, android.app.ListActivity, "onRestoreInstanceState", [state]);
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onDestroy", 
function () {
this.mHandler.removeCallbacks (this.mRequestFocus);
Clazz.superCall (this, android.app.ListActivity, "onDestroy", []);
});
Clazz.defineMethod (c$, "onContentChanged", 
function () {
Clazz.superCall (this, android.app.ListActivity, "onContentChanged", []);
var emptyView = this.findViewById (16908292);
this.mList = this.findViewById (16908298);
if (this.mList == null) {
throw  new RuntimeException ("Your content must have a ListView whose id attribute is \'android.R.id.list\'");
}if (emptyView != null) {
this.mList.setEmptyView (emptyView);
}this.mList.setOnItemClickListener (this.mOnClickListener);
if (this.mFinishedStart) {
this.setListAdapter (this.mAdapter);
}this.mHandler.post (this.mRequestFocus);
this.mFinishedStart = true;
});
Clazz.defineMethod (c$, "setListAdapter", 
function (adapter) {
{
this.ensureList ();
this.mAdapter = adapter;
this.mList.setAdapter (adapter);
}}, "android.widget.ListAdapter");
Clazz.defineMethod (c$, "setSelection", 
function (position) {
this.mList.setSelection (position);
}, "~N");
Clazz.defineMethod (c$, "getSelectedItemPosition", 
function () {
return this.mList.getSelectedItemPosition ();
});
Clazz.defineMethod (c$, "getSelectedItemId", 
function () {
return this.mList.getSelectedItemId ();
});
Clazz.defineMethod (c$, "getListView", 
function () {
this.ensureList ();
return this.mList;
});
Clazz.defineMethod (c$, "getListAdapter", 
function () {
return this.mAdapter;
});
Clazz.defineMethod (c$, "ensureList", 
($fz = function () {
if (this.mList != null) {
return ;
}this.setContentView (17367099);
}, $fz.isPrivate = true, $fz));
c$.$ListActivity$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.app, "ListActivity$1", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["android.app.ListActivity"].mList.focusableViewAvailable (this.b$["android.app.ListActivity"].mList);
});
c$ = Clazz.p0p ();
};
c$.$ListActivity$2$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.app, "ListActivity$2", null, android.widget.AdapterView.OnItemClickListener);
Clazz.overrideMethod (c$, "onItemClick", 
function (parent, v, position, id) {
this.b$["android.app.ListActivity"].onListItemClick (parent, v, position, id);
}, "android.widget.AdapterView,android.view.View,~N,~N");
c$ = Clazz.p0p ();
};
});
