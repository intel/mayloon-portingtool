﻿Clazz.declarePackage ("android.app");
c$ = Clazz.declareType (android.app, "IServiceConnection");
