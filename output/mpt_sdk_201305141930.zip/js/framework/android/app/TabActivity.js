﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.app.ActivityGroup"], "android.app.TabActivity", ["java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mTabHost = null;
this.mDefaultTab = null;
this.mDefaultTabIndex = -1;
Clazz.instantialize (this, arguments);
}, android.app, "TabActivity", android.app.ActivityGroup);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.app.TabActivity, []);
});
Clazz.defineMethod (c$, "setDefaultTab", 
function (tag) {
this.mDefaultTab = tag;
this.mDefaultTabIndex = -1;
}, "~S");
Clazz.defineMethod (c$, "setDefaultTab", 
function (index) {
this.mDefaultTab = null;
this.mDefaultTabIndex = index;
}, "~N");
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
Clazz.superCall (this, android.app.TabActivity, "onRestoreInstanceState", [state]);
this.ensureTabHost ();
var cur = state.getString ("currentTab");
if (cur != null) {
this.mTabHost.setCurrentTabByTag (cur);
}if (this.mTabHost.getCurrentTab () < 0) {
if (this.mDefaultTab != null) {
this.mTabHost.setCurrentTabByTag (this.mDefaultTab);
} else if (this.mDefaultTabIndex >= 0) {
this.mTabHost.setCurrentTab (this.mDefaultTabIndex);
}}}, "android.os.Bundle");
Clazz.defineMethod (c$, "onPostCreate", 
function (icicle) {
Clazz.superCall (this, android.app.TabActivity, "onPostCreate", [icicle]);
this.ensureTabHost ();
if (this.mTabHost.getCurrentTab () == -1) {
this.mTabHost.setCurrentTab (0);
}}, "android.os.Bundle");
Clazz.defineMethod (c$, "onSaveInstanceState", 
function (outState) {
Clazz.superCall (this, android.app.TabActivity, "onSaveInstanceState", [outState]);
var currentTabTag = this.mTabHost.getCurrentTabTag ();
if (currentTabTag != null) {
outState.putString ("currentTab", currentTabTag);
}}, "android.os.Bundle");
Clazz.defineMethod (c$, "onContentChanged", 
function () {
Clazz.superCall (this, android.app.TabActivity, "onContentChanged", []);
this.mTabHost = this.findViewById (16908306);
if (this.mTabHost == null) {
throw  new RuntimeException ("Your content must have a TabHost whose id attribute is \'android.R.id.tabhost\'");
}this.mTabHost.setup (this.getLocalActivityManager ());
});
Clazz.defineMethod (c$, "ensureTabHost", 
($fz = function () {
if (this.mTabHost == null) {
this.setContentView (17367139);
}}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "onChildTitleChanged", 
function (childActivity, title) {
if (this.getLocalActivityManager ().getCurrentActivity () === childActivity) {
var tabView = this.mTabHost.getCurrentTabView ();
if (tabView != null && Clazz.instanceOf (tabView, android.widget.TextView)) {
(tabView).setText (title);
}}}, "android.app.Activity,CharSequence");
Clazz.defineMethod (c$, "getTabHost", 
function () {
this.ensureTabHost ();
return this.mTabHost;
});
Clazz.defineMethod (c$, "getTabWidget", 
function () {
return this.mTabHost.getTabWidget ();
});
});
