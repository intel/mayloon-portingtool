﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.Parcelable", "android.content.pm.IntentResolver", "android.os.Parcelable.Creator", "java.util.ArrayList", "$.HashMap"], "android.app.ActivityManager", ["android.app.ActivityStack", "$.ConnectionRecord", "$.ProcessRecord", "$.ServiceRecord", "android.content.BroadcastFilter", "$.BroadcastRecord", "$.ComponentName", "$.ContentProviderRecord", "$.ContentService", "$.Context", "$.Intent", "$.ReceiverList", "android.content.pm.ConfigurationInfo", "$.ResolveInfo", "android.net.Uri", "android.os.Looper", "$.SystemClock", "android.util.Log", "$.Slog", "java.lang.IllegalArgumentException", "$.SecurityException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mContext = null;
this.mCurActivity = null;
this.mPersistentStartingProcesses = null;
this.mCurTask = 0;
this.mMainStack = null;
this.mStartRunning = false;
this.mTopAction = null;
this.mTopData = null;
this.mSystemReady = false;
this.mTopComponent = null;
if (!Clazz.isClassDefined ("android.app.ActivityManager.ConnectionInfo")) {
android.app.ActivityManager.$ActivityManager$ConnectionInfo$ ();
}
this.mActiveConnections = null;
if (!Clazz.isClassDefined ("android.app.ActivityManager.ServiceLookupResult")) {
android.app.ActivityManager.$ActivityManager$ServiceLookupResult$ ();
}
if (!Clazz.isClassDefined ("android.app.ActivityManager.RunConnection")) {
android.app.ActivityManager.$ActivityManager$RunConnection$ ();
}
if (!Clazz.isClassDefined ("android.app.ActivityManager.ServiceRestarter")) {
android.app.ActivityManager.$ActivityManager$ServiceRestarter$ ();
}
this.mProcessNames = null;
this.mRecentTasks = null;
this.mFocusedActivity = null;
this.mReceiverResolver = null;
this.mRegisteredReceivers = null;
this.mParallelBroadcasts = null;
this.mOrderedBroadcasts = null;
this.mServices = null;
this.mServicesByIntent = null;
this.mPendingServices = null;
this.mRestartingServices = null;
this.mStoppingServices = null;
this.mProvidersByName = null;
this.mProvidersByClass = null;
Clazz.instantialize (this, arguments);
}, android.app, "ActivityManager");
Clazz.prepareFields (c$, function () {
this.mPersistentStartingProcesses =  new java.util.ArrayList ();
this.mActiveConnections =  new java.util.HashMap ();
this.mProcessNames =  new java.util.HashMap ();
this.mRecentTasks =  new java.util.ArrayList ();
this.mReceiverResolver = ((Clazz.isClassDefined ("android.app.ActivityManager$1") ? 0 : android.app.ActivityManager.$ActivityManager$1$ ()), Clazz.innerTypeInstance (android.app.ActivityManager$1, this, null));
this.mRegisteredReceivers =  new java.util.HashMap ();
this.mParallelBroadcasts =  new java.util.ArrayList ();
this.mOrderedBroadcasts =  new java.util.ArrayList ();
this.mServices =  new java.util.HashMap ();
this.mServicesByIntent =  new java.util.HashMap ();
this.mPendingServices =  new java.util.ArrayList ();
this.mRestartingServices =  new java.util.ArrayList ();
this.mStoppingServices =  new java.util.ArrayList ();
this.mProvidersByName =  new java.util.HashMap ();
this.mProvidersByClass =  new java.util.HashMap ();
});
Clazz.makeConstructor (c$, 
function (context) {
this.mContext = context;
}, "android.content.Context");
Clazz.defineMethod (c$, "main", 
function () {
android.os.Looper.prepare ();
this.mMainStack =  new android.app.ActivityStack (this, this.mContext, true);
this.startRunning (null, null, null, null);
});
Clazz.defineMethod (c$, "startActivity", 
function (caller, intent, resolvedType, grantedUriPermissions, grantedMode, resultTo, resultWho, requestCode, onlyIfNeeded, debug) {
return this.mMainStack.startActivityMayWait (caller, intent, resolvedType, grantedUriPermissions, grantedMode, resultTo, resultWho, requestCode, onlyIfNeeded, debug);
}, "android.app.IApplicationThread,android.content.Intent,~S,~A,~N,android.os.IBinder,~S,~N,~B,~B");
Clazz.defineMethod (c$, "startService", 
function (caller, service, resolvedType) {
if (service != null && service.hasFileDescriptors () == true) {
throw  new IllegalArgumentException ("File descriptors passed in Intent");
}{
var res = this.startServiceLocked (caller, service, resolvedType);
return res;
}}, "android.app.IApplicationThread,android.content.Intent,~S");
Clazz.defineMethod (c$, "bindService", 
function (caller, service, resolvedType, connection, flags) {
if (service != null && service.hasFileDescriptors () == true) {
throw  new IllegalArgumentException ("File descriptors passed in Intent");
}var callerApp = this.getRecordForAppLocked (caller);
android.util.Log.i ("ActivityManager>>>", "bindService:");
var clientLabel = service.getIntExtra ("android.intent.extra.client_label", 0);
var res = this.retrieveServiceLocked (service, resolvedType);
if (res == null) {
return 0;
}if (res.record == null) {
return -1;
}var s = res.record;
var b = s.retrieveAppBindingLocked (service, callerApp);
var c =  new android.app.ConnectionRecord (b, connection, flags, clientLabel);
var clist = android.app.ActivityManager.mServiceConnection.get (s);
if (clist == null) {
clist =  new java.util.ArrayList ();
android.app.ActivityManager.mServiceConnection.put (s, clist);
}clist.add (c);
if ((flags & 1) != 0) {
s.lastActivity = android.os.SystemClock.uptimeMillis ();
if (!this.bringUpServiceLocked (s, service.getFlags (), false)) {
return 0;
}}return 1;
}, "android.app.IApplicationThread,android.content.Intent,~S,android.content.ServiceConnection,~N");
Clazz.defineMethod (c$, "startServiceLocked", 
($fz = function (caller, service, resolvedType) {
{
var res = this.retrieveServiceLocked (service, resolvedType);
if (res == null) {
return null;
}if (res.record == null) {
return  new android.content.ComponentName ("!", res.permission != null ? res.permission : "private to package");
}var r = res.record;
r.startRequested = true;
r.callStart = false;
r.pendingStarts.add ( new android.app.ServiceRecord.StartItem (r, 1, service, -1));
r.lastActivity = android.os.SystemClock.uptimeMillis ();
if (!this.bringUpServiceLocked (r, service.getFlags (), false)) {
return  new android.content.ComponentName ("!", "Service process is bad");
}return r.name;
}}, $fz.isPrivate = true, $fz), "android.app.IApplicationThread,android.content.Intent,~S");
Clazz.defineMethod (c$, "bringUpServiceLocked", 
($fz = function (r, intentFlags, whileRestarting) {
android.util.Log.i ("ActivityManager>>>", "bringUpServiceLocked:");
if (r.app != null && r.app.thread != null) {
return true;
}var appName = r.processName;
var app = this.newProcessRecordLocked (null, r.appInfo, appName);
if (app != null) {
try {
app.addPackage (r.appInfo.packageName);
this.realStartServiceLocked (r, app);
return true;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
}if (!this.mPendingServices.contains (r)) {
this.mPendingServices.add (r);
}return true;
}, $fz.isPrivate = true, $fz), "android.app.ServiceRecord,~N,~B");
Clazz.defineMethod (c$, "realStartServiceLocked", 
($fz = function (r, app) {
android.util.Log.i ("ActivityManager>>>", "realStartServiceLocked:");
r.app = app;
r.restartTime = r.lastActivity = android.os.SystemClock.uptimeMillis ();
app.services.add (r);
this.mContext.getActivityThread ().getApplicationThread ().scheduleCreateService (r, r.serviceInfo);
this.requestServiceBindingsLocked (r);
if (r.startRequested && r.callStart && r.pendingStarts.size () == 0) {
r.pendingStarts.add ( new android.app.ServiceRecord.StartItem (r, 1, null, -1));
}this.sendServiceArgsLocked (r, true);
}, $fz.isPrivate = true, $fz), "android.app.ServiceRecord,android.app.ProcessRecord");
Clazz.defineMethod (c$, "sendServiceArgsLocked", 
($fz = function (r, b) {
var N = r.pendingStarts.size ();
if (N == 0) {
return ;
}while (r.pendingStarts.size () > 0) {
var si = r.pendingStarts.remove (0);
if (si.intent == null && N > 1) {
continue ;}si.deliveredTime = android.os.SystemClock.uptimeMillis ();
r.deliveredStarts.add (si);
si.deliveryCount++;
var flags = 0;
if (si.deliveryCount > 0) {
flags |= 2;
}if (si.doneExecutingCount > 0) {
flags |= 1;
}this.mContext.getActivityThread ().getApplicationThread ().scheduleServiceArgs (r, si.id, flags, si.intent);
}
}, $fz.isPrivate = true, $fz), "android.app.ServiceRecord,~B");
Clazz.defineMethod (c$, "requestServiceBindingsLocked", 
($fz = function (r) {
android.util.Log.i ("ActivityManager>>>", "requestServiceBindingsLocked:");
var bindings = r.bindings.values ().iterator ();
while (bindings.hasNext ()) {
var i = bindings.next ();
if (!this.requestServiceBindingLocked (r, i, false)) {
break;
}}
}, $fz.isPrivate = true, $fz), "android.app.ServiceRecord");
Clazz.defineMethod (c$, "requestServiceBindingLocked", 
($fz = function (r, i, rebind) {
android.util.Log.i ("ActivityManager>>>", "requestServiceBindingsLocked2:");
if (r.app == null) {
return false;
}if ((!i.requested || rebind) && i.apps.size () > 0) {
this.mContext.getActivityThread ().getApplicationThread ().scheduleBindService (r, i.intent.getIntent (), rebind);
if (!rebind) {
i.requested = true;
}i.hasBound = true;
i.doRebind = false;
}return true;
}, $fz.isPrivate = true, $fz), "android.app.ServiceRecord,android.app.IntentBindRecord,~B");
Clazz.defineMethod (c$, "retrieveServiceLocked", 
($fz = function (service, resolvedType) {
var r = null;
if (service.getComponent () != null) {
r = this.mServices.get (service.getComponent ());
}var filter =  new android.content.Intent.FilterComparison (service);
r = this.mServicesByIntent.get (filter);
if (r == null) {
var rInfo = android.content.Context.getSystemContext ().getPackageManager ().resolveService (service, resolvedType, 1024);
var sInfo = rInfo != null ? rInfo.serviceInfo : null;
var name = service.getComponent ();
r = this.mServices.get (name);
if (r == null) {
filter =  new android.content.Intent.FilterComparison (service.cloneFilter ());
var res = Clazz.innerTypeInstance (android.app.ActivityManager.ServiceRestarter, this, null);
r =  new android.app.ServiceRecord (this, name, filter, sInfo, res);
res.setService (r);
this.mServices.put (name, r);
this.mServicesByIntent.put (filter, r);
var N = this.mPendingServices.size ();
for (var i = 0; i < N; i++) {
var pr = this.mPendingServices.get (i);
if (pr.name.equals (name)) {
this.mPendingServices.remove (i);
i--;
N--;
}}
}}if (r != null) {
return Clazz.innerTypeInstance (android.app.ActivityManager.ServiceLookupResult, this, null, r, null);
}return null;
}, $fz.isPrivate = true, $fz), "android.content.Intent,~S");
Clazz.defineMethod (c$, "publishService", 
function (token, intent, service) {
if (intent != null && intent.hasFileDescriptors () == true) {
throw  new IllegalArgumentException ("File descriptors passed in Intent");
}android.util.Log.i ("ActivityManager>>>", "publishService:");
if (!(Clazz.instanceOf (token, android.app.ServiceRecord))) {
throw  new IllegalArgumentException ("Invalid service token");
}var r = token;
if (r != null) {
var filter =  new android.content.Intent.FilterComparison (intent);
var b = r.bindings.get (filter);
if (android.app.ActivityManager.mServiceConnection.get (r) == null) android.util.Log.i ("ActivityManager>>>", "service connection  = null:");
if (android.app.ActivityManager.mServiceConnection.get (r) != null) {
var it = android.app.ActivityManager.mServiceConnection.values ().iterator ();
while (it.hasNext ()) {
var clist = it.next ();
for (var i = 0; i < clist.size (); i++) {
var c = clist.get (i);
android.util.Log.i ("ActivityManager>>>", "c.conn:");
this.mContext.getActivityThread ().getApplicationThread ().getHandler ().post (Clazz.innerTypeInstance (android.app.ActivityManager.RunConnection, this, null, r.name, service, 0, c.conn));
}
}
}}}, "android.os.IBinder,android.content.Intent,android.os.IBinder");
Clazz.defineMethod (c$, "startRunning", 
function (pkg, cls, action, data) {
if (this.mStartRunning) {
return ;
}this.mStartRunning = true;
this.mTopComponent = pkg != null && cls != null ?  new android.content.ComponentName (pkg, cls) : null;
this.mTopAction = action != null ? action : "android.intent.action.MAIN";
this.mTopData = data;
this.systemReady ();
}, "~S,~S,~S,~S");
Clazz.defineMethod (c$, "startHomeActivityLocked", 
function () {
var intent =  new android.content.Intent (this.mTopAction, this.mTopData != null ? android.net.Uri.parse (this.mTopData) : null);
intent.addCategory ("android.intent.category.HOME");
var aInfo = intent.resolveActivityInfo (this.mContext.getPackageManager (), 1024);
if (aInfo == null) {
var manager = this.mContext.getPackageManager ();
var mainIntent =  new android.content.Intent ("android.intent.action.MAIN", null);
mainIntent.addCategory ("android.intent.category.LAUNCHER");
var apps = manager.queryIntentActivities (mainIntent, 0);
aInfo = apps.get (0).activityInfo;
}if (aInfo == null) {
android.util.Log.i ("ActivityManager>>>", "Cannot find intent " + intent);
} else {
intent.setComponent ( new android.content.ComponentName (aInfo.applicationInfo.packageName, aInfo.name));
var app = this.getProcessRecordLocked (aInfo.processName);
if (app == null || app.instrumentationClass == null) {
intent.setFlags (intent.getFlags () | 268435456);
this.mMainStack.startActivityLocked (null, intent, null, null, 0, aInfo, null, null, 0, 0, 0, false, false);
}}try {
// Removing startup screen
if (document.getElementById('mayloonstartup')) {
document.getElementById('mayloonstartup').style.display = 'none';
}
} catch ( e ) {
// Just ignore any exception occurred
}
return true;
});
Clazz.defineMethod (c$, "getProcessRecordLocked", 
function (processName) {
var proc = this.mProcessNames.get (processName);
return proc;
}, "~S");
Clazz.defineMethod (c$, "systemReady", 
function () {
android.content.ContentService.main (this.mContext);
this.mMainStack.resumeTopActivityLocked (null);
});
Clazz.defineMethod (c$, "addRecentTaskLocked", 
function (task) {
var N = this.mRecentTasks.size ();
for (var i = 0; i < N; i++) {
var tr = this.mRecentTasks.get (i);
if ((task.affinity != null && task.affinity.equals (tr.affinity)) || (task.intent != null && task.intent.filterEquals (tr.intent))) {
this.mRecentTasks.remove (i);
i--;
N--;
if (task.intent == null) {
task = tr;
}}}
if (N >= 20) {
this.mRecentTasks.remove (N - 1);
}this.mRecentTasks.add (0, task);
}, "android.app.TaskRecord");
Clazz.defineMethod (c$, "registerReceiver", 
function (caller, receiver, filter, permission) {
{
var callerApp = null;
if (caller != null) {
callerApp = this.getRecordForAppLocked (caller);
}var allSticky = null;
var actions = filter.actionsIterator ();
if (true) android.util.Log.i ("ActivityManager>>>", "this is register in activitymanager");
if (actions != null) {
while (actions.hasNext ()) {
var action = actions.next ();
if (true) android.util.Log.i ("ActivityManager>>>", "action:" + action);
}
} else {
}var sticky = allSticky != null ? allSticky.get (0) : null;
if (receiver == null) {
return sticky;
}var rl = this.mRegisteredReceivers.get (receiver);
if (rl == null) {
rl =  new android.content.ReceiverList (this, callerApp, 0, 0, receiver);
this.mRegisteredReceivers.put (receiver, rl);
}var bf =  new android.content.BroadcastFilter (filter, rl, permission);
rl.add (bf);
this.mReceiverResolver.addFilter (bf);
if (!bf.debugCheck ()) {
android.util.Slog.w ("ActivityManager>>>", "==> For Dynamic broadast");
}if (allSticky != null) {
}return null;
}}, "android.app.IApplicationThread,android.content.IIntentReceiver,android.content.IntentFilter,~S");
Clazz.defineMethod (c$, "unregisterReceiver", 
function (receiver) {
var rl = this.mRegisteredReceivers.get (receiver);
if (rl != null) {
this.removeReceiverLocked (rl);
}}, "android.content.IIntentReceiver");
Clazz.defineMethod (c$, "removeReceiverLocked", 
function (rl) {
this.mRegisteredReceivers.remove (rl.receiver);
var N = rl.size ();
for (var i = 0; i < N; i++) {
this.mReceiverResolver.removeFilter (rl.get (i));
}
}, "android.content.ReceiverList");
Clazz.defineMethod (c$, "deliverToRegisteredReceiverLocked", 
($fz = function (r, filter, ordered) {
var context = filter.receiverList.receiver.mOuterContext;
var intent = r.intent;
filter.receiverList.receiver.receiver.onReceive (context, intent);
}, $fz.isPrivate = true, $fz), "android.content.BroadcastRecord,android.content.BroadcastFilter,~B");
Clazz.defineMethod (c$, "processNextBroadcast", 
($fz = function (intent) {
if (this.mParallelBroadcasts.size () > 0) {
var r = this.mParallelBroadcasts.remove (0);
r.dispatchTime = android.os.SystemClock.uptimeMillis ();
var N = r.receivers.size ();
for (var i = 0; i < N; i++) {
var target = r.receivers.get (i);
if (true) android.util.Log.i ("ActivityManager>>>", "receivers size:" + N);
this.deliverToRegisteredReceiverLocked (r, target, false);
}
}if (this.mOrderedBroadcasts.size () > 0) {
var r = this.mOrderedBroadcasts.remove (0);
r.dispatchTime = android.os.SystemClock.uptimeMillis ();
var N = r.receivers.size ();
for (var i = 0; i < N; i++) {
var target = r.receivers.get (i);
if (true) android.util.Log.i ("ActivityManager>>>", "package receivers size:" + N);
var receiver = null;
try {
receiver = Class.forName (target.activityInfo.name).newInstance ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.i ("ActivityManager>>>", "Create broadrecerver error");
} else {
throw e;
}
}
receiver.onReceive (android.content.Context.mOuterContext, intent);
}
}}, $fz.isPrivate = true, $fz), "android.content.Intent");
Clazz.defineMethod (c$, "scheduleBroadcastsLocked", 
($fz = function (intent) {
this.processNextBroadcast (intent);
}, $fz.isPrivate = true, $fz), "android.content.Intent");
Clazz.defineMethod (c$, "broadcastIntent", 
function (caller, intent, resolvedType, resultTo, resultCode, resultData, map, requiredPermission, ordered, sticky) {
var callerApp = this.getRecordForAppLocked (caller);
if (false) android.util.Slog.v ("ActivityManager>>>", (sticky ? "Broadcast sticky: " : "Broadcast: ") + intent + " ordered=" + ordered);
if ((resultTo != null) && !ordered) {
android.util.Slog.w ("ActivityManager>>>", "Broadcast " + intent + " not ordered but result callback requested!");
}var receivers = null;
var registeredReceivers = null;
registeredReceivers = this.mReceiverResolver.queryIntent (intent, resolvedType, false);
var replacePending = (intent.getFlags () & 536870912) != 0;
android.util.Log.i ("ActivityManager>>>", "ComponentNamename:" + intent.getComponent ());
if (intent.getComponent () != null) {
var ai = android.content.Context.getSystemContext ().getPackageManager ().getReceiverInfo (intent.getComponent (), 1024);
if (ai != null) {
receivers =  new java.util.ArrayList ();
var ri =  new android.content.pm.ResolveInfo ();
ri.activityInfo = ai;
receivers.add (ri);
}} else {
android.util.Log.i ("ActivityManager>>>", "if:" + String.valueOf (intent.getFlags () & 1073741824));
if ((intent.getFlags () & 1073741824) == 0) {
receivers = android.content.Context.getSystemContext ().getPackageManager ().queryIntentReceivers (intent, resolvedType, 1024);
}}android.util.Log.i ("ActivityManager>>>", "package receiver size is:" + String.valueOf (receivers.size ()));
var NR = registeredReceivers != null ? registeredReceivers.size () : 0;
if (!ordered && NR > 0) {
var r =  new android.content.BroadcastRecord (intent, callerApp, null, 0, 0, requiredPermission, registeredReceivers, resultCode, resultData, map, ordered, sticky, false);
this.mParallelBroadcasts.add (r);
registeredReceivers = null;
NR = 0;
}var s =  new android.content.BroadcastRecord (intent, callerApp, null, 0, 0, requiredPermission, receivers, resultCode, resultData, map, ordered, sticky, false);
this.mOrderedBroadcasts.add (s);
this.scheduleBroadcastsLocked (intent);
return 0;
}, "android.app.IApplicationThread,android.content.Intent,~S,android.content.IIntentReceiver,~N,~S,android.os.Bundle,~S,~B,~B");
Clazz.defineMethod (c$, "startProcessLocked", 
function (processName, info, knownToBeDead, intentFlags, hostingType, hostingName, allowWhileBooting) {
var app = this.getProcessRecordLocked (processName);
if (app != null && app.pid > 0) {
android.util.Log.i ("ActivityManager>>>", "impossible here");
if (!knownToBeDead || app.thread == null) {
return app;
} else {
}}var hostingNameStr = hostingName != null ? hostingName.flattenToShortString () : null;
if ((intentFlags & 4) != 0) {
android.util.Log.i ("ActivityManager>>>", "impossible here");
} else {
}if (app == null) {
app = this.newProcessRecordLocked (null, info, processName);
this.mProcessNames.put (processName, app);
} else {
app.addPackage (info.packageName);
}this.startProcessLocked (app, hostingType, hostingNameStr);
return (app.pid != 0) ? app : null;
}, "~S,android.content.pm.ApplicationInfo,~B,~N,~S,android.content.ComponentName,~B");
Clazz.defineMethod (c$, "newProcessRecordLocked", 
function (thread, info, customProcess) {
var proc = customProcess != null ? customProcess : info.processName;
return  new android.app.ProcessRecord (thread, info, proc);
}, "android.app.IApplicationThread,android.content.pm.ApplicationInfo,~S");
Clazz.defineMethod (c$, "startProcessLocked", 
($fz = function (app, hostingType, hostingNameStr) {
try {
var acT = Class.forName ("android.app.ActivityThread").newInstance ();
acT.main (app.processName);
} catch (e$$) {
if (Clazz.instanceOf (e$$, InstantiationException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, IllegalAccessException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, ClassNotFoundException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else {
throw e$$;
}
}
}, $fz.isPrivate = true, $fz), "android.app.ProcessRecord,~S,~S");
Clazz.defineMethod (c$, "attachApplication", 
function (thread, processName) {
var app = null;
app = this.mProcessNames.get (processName);
if (app == null) {
android.util.Log.e ("ActivityManager>>>", "process get fail");
return ;
}app.thread = thread;
app.curAdj = app.setAdj = -100;
app.forcingToForeground = null;
app.foregroundServices = false;
app.debugging = false;
var normalMode = true;
thread.bindApplication (processName, app.instrumentationInfo != null ? app.instrumentationInfo : app.info, app.instrumentationClass, app.instrumentationProfileFile, app.instrumentationArguments, 0, false || !normalMode);
var hr = this.mMainStack.topRunningActivityLocked (null);
if (hr != null && normalMode) {
if (hr.app == null && processName.equals (hr.processName)) {
try {
this.mMainStack.realStartActivityLocked (hr, app, true, true);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.i ("ActivityManager>>>", e.getMessage ());
android.util.Log.i ("ActivityManager>>>", "Exception in new application when starting activity " + hr.intent.getComponent ().flattenToShortString ());
} else {
throw e;
}
}
} else {
android.util.Log.i ("ActivityManager>>>", "impossible here lalala");
}}}, "android.app.IApplicationThread,~S");
Clazz.defineMethod (c$, "finishActivity", 
function (token, resultCode, resultData) {
var res = this.mMainStack.requestFinishActivityLocked (token, resultCode, resultData, "app-request");
return res;
}, "android.os.IBinder,~N,android.content.Intent");
Clazz.defineMethod (c$, "getRecordForAppLocked", 
function (thread) {
if (thread == null) {
return null;
}var entrySetIterator = this.mProcessNames.entrySet ().iterator ();
while (entrySetIterator.hasNext ()) {
var entry = entrySetIterator.next ();
if (entry.getValue ().thread === thread) {
return entry.getValue ();
}}
return null;
}, "android.app.IApplicationThread");
Clazz.defineMethod (c$, "setFocusedActivityLocked", 
function (r) {
if (this.mFocusedActivity !== r) {
this.mFocusedActivity = r;
}}, "android.app.ActivityRecord");
Clazz.defineMethod (c$, "activityPaused", 
function (token, icicle) {
this.mMainStack.activityPaused (token, icicle, false);
}, "android.os.IBinder,android.os.Bundle");
Clazz.defineMethod (c$, "activityDestroyed", 
function (token) {
this.mMainStack.activityDestroyed (token);
}, "android.os.IBinder");
Clazz.defineMethod (c$, "findServiceLocked", 
($fz = function (name, token) {
var r = this.mServices.get (name);
return r === token ? r : null;
}, $fz.isPrivate = true, $fz), "android.content.ComponentName,android.os.IBinder");
Clazz.defineMethod (c$, "stopServiceToken", 
function (className, token, startId) {
{
if (true) android.util.Log.i ("ActivityManager>>>", "stopServiceToken: " + className + " " + token + " startId=" + startId);
var r = this.findServiceLocked (className, token);
if (r != null) {
if (startId >= 0) {
var si = r.findDeliveredStart (startId, false);
if (si != null) {
while (r.deliveredStarts.size () > 0) {
var cur = r.deliveredStarts.remove (0);
if (cur === si) {
break;
}}
}if (r.lastStartId != startId) {
return false;
}if (r.deliveredStarts.size () > 0) {
android.util.Log.i ("ActivityManager>>>", "stopServiceToken startId " + startId + " is last, but have " + r.deliveredStarts.size () + " remaining args");
}}r.startRequested = false;
r.callStart = false;
this.bringDownServiceLocked (r, false);
return true;
}}return false;
}, "android.content.ComponentName,android.os.IBinder,~N");
Clazz.defineMethod (c$, "serviceDoneExecutingLocked", 
function (r, inStopping) {
if (true) android.util.Log.i ("ActivityManager>>>", "<<< DONE EXECUTING " + r + ": nesting=" + r.executeNesting + ", inStopping=" + inStopping + ", app=" + r.app);
 else if (true) System.out.println ("ActivityManager>>>" + "<<< DONE EXECUTING " + r.shortName);
r.executeNesting--;
if (r.executeNesting <= 0 && r.app != null) {
if (true) android.util.Log.i ("ActivityManager>>>", "Nesting at 0 of " + r.shortName);
r.app.executingServices.remove (r);
if (r.app.executingServices.size () == 0) {
if (true) android.util.Log.i ("ActivityManager>>>", "No more executingServices of " + r.shortName);
}if (inStopping) {
if (true) android.util.Log.i ("ActivityManager>>>", "doneExecuting remove stopping " + r);
this.mStoppingServices.remove (r);
}}}, "android.app.ServiceRecord,~B");
Clazz.defineMethod (c$, "unscheduleServiceRestartLocked", 
($fz = function (r) {
if (r.restartDelay == 0) {
return false;
}r.resetRestartCounter ();
this.mRestartingServices.remove (r);
return true;
}, $fz.isPrivate = true, $fz), "android.app.ServiceRecord");
Clazz.defineMethod (c$, "bringDownServiceLocked", 
($fz = function (r, force) {
if (!force && r.startRequested) {
return ;
}if (r.connections.size () > 0) {
if (!force) {
var it = r.connections.values ().iterator ();
while (it.hasNext ()) {
var cr = it.next ();
for (var i = 0; i < cr.size (); i++) {
if ((cr.get (i).flags & 1) != 0) {
return ;
}}
}
}var it = r.connections.values ().iterator ();
while (it.hasNext ()) {
var c = it.next ();
for (var i = 0; i < c.size (); i++) {
try {
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.i ("ActivityManager>>>", "Failure disconnecting service " + r.name + " to connection " + " (in " + c.get (i).binding.client.processName + ")");
} else {
throw e;
}
}
}
}
}if (r.bindings.size () > 0 && r.app != null && r.app.thread != null) {
var it = r.bindings.values ().iterator ();
while (it.hasNext ()) {
var ibr = it.next ();
if (true) android.util.Log.i ("ActivityManager>>>", "Bringing down binding " + ibr + ": hasBound=" + ibr.hasBound);
if (r.app != null && r.app.thread != null && ibr.hasBound) {
try {
this.bumpServiceExecutingLocked (r, "bring down unbind");
ibr.hasBound = false;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.i ("ActivityManager>>>", "Exception when unbinding service " + r.shortName);
this.serviceDoneExecutingLocked (r, true);
} else {
throw e;
}
}
}}
}if (true) android.util.Log.i ("ActivityManager>>>", "Bringing down " + r + " " + r.intent);
this.mServices.remove (r.name);
this.mServicesByIntent.remove (r.intent);
r.totalRestartCount = 0;
this.unscheduleServiceRestartLocked (r);
var N = this.mPendingServices.size ();
for (var i = 0; i < N; i++) {
if (this.mPendingServices.get (i) === r) {
this.mPendingServices.remove (i);
if (true) android.util.Log.i ("ActivityManager>>>", "Removed pending: " + r);
i--;
N--;
}}
r.cancelNotification ();
r.isForeground = false;
r.foregroundId = 0;
r.clearDeliveredStartsLocked ();
r.pendingStarts.clear ();
if (r.app != null) {
r.app.services.remove (r);
if (r.app.thread != null) {
try {
this.bumpServiceExecutingLocked (r, "stop");
this.mStoppingServices.add (r);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.i ("ActivityManager>>>", "Exception when stopping service " + r.shortName);
this.serviceDoneExecutingLocked (r, true);
} else {
throw e;
}
}
} else {
if (true) android.util.Log.i ("ActivityManager>>>", "Removed service that has no process: " + r);
}} else {
if (true) android.util.Log.i ("ActivityManager>>>", "Removed service that is not running: " + r);
}}, $fz.isPrivate = true, $fz), "android.app.ServiceRecord,~B");
Clazz.defineMethod (c$, "bumpServiceExecutingLocked", 
($fz = function (r, why) {
if (true) android.util.Log.i ("ActivityManager>>>", ">>> EXECUTING " + why + " of " + r + " in app " + r.app);
 else if (true) android.util.Log.i ("ActivityManager>>>", ">>> EXECUTING " + why + " of " + r.shortName);
var now = android.os.SystemClock.uptimeMillis ();
if (r.executeNesting == 0 && r.app != null) {
if (r.app.executingServices.size () == 0) {
}r.app.executingServices.add (r);
}r.executeNesting++;
r.executingStart = now;
}, $fz.isPrivate = true, $fz), "android.app.ServiceRecord,~S");
Clazz.defineMethod (c$, "setServiceForeground", 
function (className, token, id, removeNotification) {
try {
{
var r = this.findServiceLocked (className, token);
if (r != null) {
if (id != 0) {
if (r.foregroundId != id) {
r.cancelNotification ();
r.foregroundId = id;
}r.isForeground = true;
r.postNotification ();
} else {
if (r.isForeground) {
r.isForeground = false;
}if (removeNotification) {
r.cancelNotification ();
r.foregroundId = 0;
}}}}} finally {
}
}, "android.content.ComponentName,android.os.IBinder,~N,~B");
Clazz.defineMethod (c$, "getContentProvider", 
function (caller, name) {
if (caller == null) {
var msg = "null IApplicationThread when getting content provider " + name;
android.util.Log.w ("ActivityManager>>>", msg);
}return this.getContentProviderImpl (caller, name);
}, "android.app.IApplicationThread,~S");
Clazz.defineMethod (c$, "getContentProviderExternal", 
($fz = function (name) {
return this.getContentProviderImpl (null, name);
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "getProviderMimeType", 
function (uri) {
var name = uri.getAuthority ();
var holder = null;
try {
holder = this.getContentProviderExternal (name);
if (android.app.ActivityManager.DEBUG_PROVIDER) android.util.Log.i ("ActivityManager>>>", "getProviderMimeType:" + holder);
if (holder != null) {
return holder.provider.getType (uri);
}} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.w ("ActivityManager>>>", "Content provider dead retrieving " + uri, e);
return null;
} else {
throw e;
}
} finally {
if (holder != null) {
this.removeContentProviderExternal (name);
}}
return null;
}, "android.net.Uri");
Clazz.defineMethod (c$, "removeContentProviderExternal", 
($fz = function (name) {
var cpr = this.mProvidersByName.get (name);
if (cpr == null) {
if (android.app.ActivityManager.DEBUG_PROVIDER) android.util.Slog.v ("ActivityManager>>>", name + " content provider not found in providers list");
return ;
}var localCpr = this.mProvidersByClass.get (cpr.info.name);
localCpr.externals--;
if (localCpr.externals < 0) {
android.util.Slog.e ("ActivityManager>>>", "Externals < 0 for content provider " + localCpr);
}}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "getContentProviderImpl", 
($fz = function (caller, name) {
var cpr;
var cpi = null;
if (android.app.ActivityManager.DEBUG_PROVIDER) android.util.Log.i ("ActivityManager>>>", "ActivityManager:getContentProviderImpl");
var r = null;
if (caller != null) {
r = this.getRecordForAppLocked (caller);
if (r == null) {
throw  new SecurityException ("Unable to find app for caller " + caller + ") when getting content provider " + name);
}}if (android.app.ActivityManager.DEBUG_PROVIDER) android.util.Log.i ("ActivityManager>>>", "ActivityManager:getContentProviderImpl");
cpr = this.mProvidersByName.get (name);
if (cpr != null) {
cpi = cpr.info;
if (r != null && cpr.canRunHere (r)) {
if (cpr.provider != null) {
cpr =  new android.content.ContentProviderRecord (cpr);
}return cpr;
}} else {
if (android.app.ActivityManager.DEBUG_PROVIDER) android.util.Log.i ("ActivityManager>>>", "ActivityManager:getContentProviderImpl:AppGlobals.getPackageManager().resolveContentProvider");
cpi = android.content.Context.getSystemContext ().getPackageManager ().resolveContentProvider (name, 3072);
if (cpi == null) {
android.util.Log.d ("ActivityManager>>>", "cpi(ProviderInfo is null.)");
return null;
}if (android.app.ActivityManager.DEBUG_PROVIDER) android.util.Log.i ("ActivityManager>>>", "ActivityManager:ProviderInfo is got!");
cpr = this.mProvidersByClass.get (cpi.name);
var firstClass = cpr == null;
if (firstClass) {
try {
var ai = android.content.Context.getSystemContext ().getPackageManager ().getApplicationInfo (cpi.applicationInfo.packageName, 1024);
if (ai == null) {
android.util.Log.w ("ActivityManager>>>", "No package info for content provider " + cpi.name);
return null;
}cpr =  new android.content.ContentProviderRecord (cpi, ai);
this.mProvidersByClass.put (cpi.name, cpr);
this.mProvidersByName.put (name, cpr);
} catch (ex) {
if (Clazz.instanceOf (ex, Exception)) {
} else {
throw ex;
}
}
}if (cpr.canRunHere (r)) {
return cpr;
}}while (cpr.provider == null) {
if (cpr.launchingApp == null) {
android.util.Log.w ("ActivityManager>>>", "Unable to launch app " + cpi.applicationInfo.packageName + "/" + cpi.applicationInfo.uid + " for provider " + name + ": launching app became null");
return null;
}try {
cpr.wait ();
} catch (ex) {
if (Clazz.instanceOf (ex, InterruptedException)) {
} else {
throw ex;
}
}
}
return cpr;
}, $fz.isPrivate = true, $fz), "android.app.IApplicationThread,~S");
Clazz.defineMethod (c$, "unbindService", 
function (conn) {
}, "android.content.ServiceConnection");
Clazz.defineMethod (c$, "getDeviceConfigurationInfo", 
function () {
var info =  new android.content.pm.ConfigurationInfo ();
info.reqGlEsVersion = 0x00020000;
return info;
});
Clazz.defineMethod (c$, "getProcessesInErrorState", 
function () {
return null;
});
Clazz.defineMethod (c$, "finishInstrumentationLocked", 
function (app, resultCode, results) {
var pretty = null;
if (results != null) {
pretty = results.getString ("stream");
}if (pretty != null) {
android.util.Log.i ("ActivityManager>>>", pretty);
} else {
if (results != null) {
for (var key, $key = results.keySet ().iterator (); $key.hasNext () && ((key = $key.next ()) || true);) {
android.util.Log.i ("ActivityManager>>>", "Instrumentation_RESULT: " + key + "=" + results.getByte (key));
}
}android.util.Log.i ("ActivityManager>>>", "Instrumentation_code: " + resultCode);
}app.instrumentationClass = null;
app.instrumentationInfo = null;
app.instrumentationProfileFile = null;
app.instrumentationArguments = null;
}, "android.app.ProcessRecord,~N,android.os.Bundle");
Clazz.defineMethod (c$, "finishInstrumentation", 
function (target, resultCode, results) {
if (results != null && results.hasFileDescriptors ()) {
throw  new IllegalArgumentException ("File descriptors passed in Intent");
}{
var app = this.getRecordForAppLocked (target);
if (app == null) {
android.util.Slog.w ("ActivityManager>>>", "finishInstrumentation: no app for " + target);
return ;
}this.finishInstrumentationLocked (app, resultCode, results);
}}, "android.app.IApplicationThread,~N,android.os.Bundle");
Clazz.defineMethod (c$, "getProcessRecordLocked", 
function (processName, uid) {
var proc = this.mProcessNames.get (processName);
return proc;
}, "~S,~N");
Clazz.defineMethod (c$, "addAppLocked", 
function (info) {
var app = this.getProcessRecordLocked (info.processName, info.uid);
if (app == null) {
app = this.newProcessRecordLocked (null, info, null);
this.mProcessNames.put (info.processName, app);
}if ((info.flags & (9)) == (9)) {
app.persistent = true;
app.maxAdj = -12;
}return app;
}, "android.content.pm.ApplicationInfo");
Clazz.defineMethod (c$, "startInstrumentation", 
function (className, profileFile, flags, $arguments, watcher) {
android.util.Log.i ("ActivityManager>>>", "start instrumentation");
if ($arguments != null && $arguments.hasFileDescriptors ()) {
throw  new IllegalArgumentException ("File descriptors passed in Bundle");
}var ii = null;
var ai = null;
try {
ii = android.content.Context.getSystemContext ().getPackageManager ().getInstrumentationInfo (className, 1024);
ai = android.content.Context.getSystemContext ().getPackageManager ().getApplicationInfo (ii.targetPackage, 1024);
} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
} else {
throw e;
}
}
if (ii == null) {
android.util.Log.e ("ActivityManager>>>", "Unable to find instrumentation info for: " + className);
return false;
}if (ai == null) {
android.util.Log.e ("ActivityManager>>>", "Unable to find instrumentation target package: " + ii.targetPackage);
return false;
}var app = this.addAppLocked (ai);
app.instrumentationClass = className;
app.instrumentationInfo = ai;
app.instrumentationProfileFile = profileFile;
app.instrumentationArguments = $arguments;
app.instrumentationResultClass = className;
this.mPersistentStartingProcesses.add (app);
this.startProcessLocked (app, "added application", app.processName);
android.util.Log.i ("ActivityManager>>>", "start process locked");
return true;
}, "android.content.ComponentName,~S,~N,android.os.Bundle,android.app.IInstrumentationWatcher");
Clazz.defineMethod (c$, "getProcessMemoryInfo", 
function (pids) {
console.log("Missing method: getProcessMemoryInfo");
}, "~A");
Clazz.defineMethod (c$, "killBackgroundProcesses", 
function (packageName) {
console.log("Missing method: killBackgroundProcesses");
}, "~S");
Clazz.defineMethod (c$, "getMemoryInfo", 
function (outInfo) {
console.log("Missing method: getMemoryInfo");
}, "~O");
Clazz.defineMethod (c$, "getRunningServices", 
function (maxNum) {
console.log("Missing method: getRunningServices");
}, "~N");
Clazz.defineMethod (c$, "getRunningAppProcesses", 
function () {
console.log("Missing method: getRunningAppProcesses");
});
Clazz.defineMethod (c$, "getMemoryClass", 
function () {
console.log("Missing method: getMemoryClass");
});
Clazz.defineMethod (c$, "restartPackage", 
function (packageName) {
console.log("Missing method: restartPackage");
}, "~S");
c$.isUserAMonkey = Clazz.defineMethod (c$, "isUserAMonkey", 
function () {
console.log("Missing method: isUserAMonkey");
});
Clazz.defineMethod (c$, "getRunningTasks", 
function (maxNum) {
console.log("Missing method: getRunningTasks");
}, "~N");
Clazz.defineMethod (c$, "MemoryInfo", 
function () {
console.log("Missing method: MemoryInfo");
});
c$.$ActivityManager$ConnectionInfo$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.binder = null;
Clazz.instantialize (this, arguments);
}, android.app.ActivityManager, "ConnectionInfo");
c$ = Clazz.p0p ();
};
c$.$ActivityManager$ServiceLookupResult$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.record = null;
this.permission = null;
Clazz.instantialize (this, arguments);
}, android.app.ActivityManager, "ServiceLookupResult");
Clazz.makeConstructor (c$, 
function (a, b) {
this.record = a;
this.permission = b;
}, "android.app.ServiceRecord,~S");
c$ = Clazz.p0p ();
};
c$.$ActivityManager$RunConnection$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mName = null;
this.mService = null;
this.mCommand = 0;
this.mConnection = null;
Clazz.instantialize (this, arguments);
}, android.app.ActivityManager, "RunConnection", null, Runnable);
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
android.util.Log.i ("ActivityManager>>>", "new RunConnection:");
this.mName = a;
this.mService = b;
this.mCommand = c;
this.mConnection = d;
}, "android.content.ComponentName,android.os.IBinder,~N,android.content.ServiceConnection");
Clazz.overrideMethod (c$, "run", 
function () {
android.util.Log.i ("ActivityManager>>>", "RunConnection.run:");
if (this.mCommand == 0) {
var a;
var b;
a = this.b$["android.app.ActivityManager"].mActiveConnections.get (this.mName);
if (a != null && a.binder === this.mService) {
return ;
}if (this.mService != null) {
b = Clazz.innerTypeInstance (android.app.ActivityManager.ConnectionInfo, this, null);
b.binder = this.mService;
this.b$["android.app.ActivityManager"].mActiveConnections.put (this.mName, b);
} else {
this.b$["android.app.ActivityManager"].mActiveConnections.remove (this.mName);
}if (a != null) {
this.mConnection.onServiceDisconnected (this.mName);
}if (this.mService != null) {
android.util.Log.i ("ActivityManager>>>", "RunConnection:");
this.mConnection.onServiceConnected (this.mName, this.mService);
}} else if (this.mCommand == 1) {
this.mConnection.onServiceDisconnected (this.mName);
}});
c$ = Clazz.p0p ();
};
c$.$ActivityManager$ServiceRestarter$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mService = null;
Clazz.instantialize (this, arguments);
}, android.app.ActivityManager, "ServiceRestarter", null, Runnable);
Clazz.defineMethod (c$, "setService", 
function (a) {
this.mService = a;
}, "android.app.ServiceRecord");
Clazz.overrideMethod (c$, "run", 
function () {
});
c$ = Clazz.p0p ();
};
c$.$ActivityManager$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.app, "ActivityManager$1", android.content.pm.IntentResolver);
Clazz.overrideMethod (c$, "allowFilterResult", 
function (filter, dest) {
var target = filter.receiverList.receiver;
for (var i = dest.size () - 1; i >= 0; i--) {
if (dest.get (i).receiverList.receiver === target) {
return false;
}}
return true;
}, "android.content.BroadcastFilter,java.util.List");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.info = null;
this.provider = null;
this.noReleaseNeeded = false;
Clazz.instantialize (this, arguments);
}, android.app.ActivityManager, "ContentProviderHolder", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function (a) {
this.info = a;
}, "android.content.pm.ProviderInfo");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
this.info.writeToParcel (a, 0);
if (this.provider != null) {
a.writeStrongBinder (null);
} else {
a.writeStrongBinder (null);
}a.writeInt (this.noReleaseNeeded ? 1 : 0);
}, "android.os.Parcel,~N");
Clazz.makeConstructor (c$, 
($fz = function (a) {
this.info = null;
}, $fz.isPrivate = true, $fz), "android.os.Parcel");
c$.$ActivityManager$ContentProviderHolder$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.app, "ActivityManager$ContentProviderHolder$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.app.ActivityManager.ContentProviderHolder (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.app.ActivityManager$ContentProviderHolder$1") ? 0 : android.app.ActivityManager.ContentProviderHolder.$ActivityManager$ContentProviderHolder$1$ ()), Clazz.innerTypeInstance (android.app.ActivityManager$ContentProviderHolder$1, this, null));
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.condition = 0;
this.processName = null;
this.pid = 0;
this.uid = 0;
this.tag = null;
this.shortMsg = null;
this.longMsg = null;
this.stackTrace = null;
this.crashData = null;
Clazz.instantialize (this, arguments);
}, android.app.ActivityManager, "ProcessErrorStateInfo", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
a.writeInt (this.condition);
a.writeString (this.processName);
a.writeInt (this.pid);
a.writeInt (this.uid);
a.writeString (this.tag);
a.writeString (this.shortMsg);
a.writeString (this.longMsg);
a.writeString (this.stackTrace);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "readFromParcel", 
function (a) {
this.condition = a.readInt ();
this.processName = a.readString ();
this.pid = a.readInt ();
this.uid = a.readInt ();
this.tag = a.readString ();
this.shortMsg = a.readString ();
this.longMsg = a.readString ();
this.stackTrace = a.readString ();
}, "android.os.Parcel");
Clazz.makeConstructor (c$, 
($fz = function (a) {
this.readFromParcel (a);
}, $fz.isPrivate = true, $fz), "android.os.Parcel");
c$.$ActivityManager$ProcessErrorStateInfo$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.app, "ActivityManager$ProcessErrorStateInfo$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.app.ActivityManager.ProcessErrorStateInfo (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"NO_ERROR", 0,
"CRASHED", 1,
"NOT_RESPONDING", 2);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.app.ActivityManager$ProcessErrorStateInfo$1") ? 0 : android.app.ActivityManager.ProcessErrorStateInfo.$ActivityManager$ProcessErrorStateInfo$1$ ()), Clazz.innerTypeInstance (android.app.ActivityManager$ProcessErrorStateInfo$1, this, null));
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"LAUNCHER", "com.intel.jsdroid.sudoku",
"DEBUG_PROVIDER", true,
"START_SWITCHES_CANCELED", 4,
"START_DELIVERED_TO_TOP", 3,
"START_TASK_TO_FRONT", 2,
"START_RETURN_INTENT_TO_CALLER", 1,
"START_SUCCESS", 0,
"START_INTENT_NOT_RESOLVED", -1,
"START_CLASS_NOT_FOUND", -2,
"START_FORWARD_AND_REQUEST_CONFLICT", -3,
"START_PERMISSION_DENIED", -4,
"START_NOT_ACTIVITY", -5,
"START_CANCELED", -6,
"CORE_SERVER_ADJ", -12,
"TAG", "ActivityManager>>>",
"SERVICE_TIMEOUT", 20000,
"DEBUG_SERVICE", true);
c$.mServiceConnection = c$.prototype.mServiceConnection =  new java.util.HashMap ();
Clazz.defineStatics (c$,
"STOCK_PM_FLAGS", 1024,
"MAX_RECENT_TASKS", 20,
"DEBUG_BROADCAST", true,
"DEBUG_BROADCAST_LIGHT", false,
"BROADCAST_SUCCESS", 0,
"SHOW_ERROR_MSG", 1,
"SHOW_NOT_RESPONDING_MSG", 2,
"SHOW_FACTORY_ERROR_MSG", 3,
"UPDATE_CONFIGURATION_MSG", 4,
"GC_BACKGROUND_PROCESSES_MSG", 5,
"WAIT_FOR_DEBUGGER_MSG", 6,
"BROADCAST_INTENT_MSG", 7,
"BROADCAST_TIMEOUT_MSG", 8,
"SERVICE_TIMEOUT_MSG", 12,
"UPDATE_TIME_ZONE", 13,
"SHOW_UID_ERROR_MSG", 14,
"IM_FEELING_LUCKY_MSG", 15,
"PROC_START_TIMEOUT_MSG", 20,
"DO_PENDING_ACTIVITY_LAUNCHES_MSG", 21,
"KILL_APPLICATION_MSG", 22,
"FINALIZE_PENDING_INTENT_MSG", 23,
"POST_HEAVY_NOTIFICATION_MSG", 24,
"CANCEL_HEAVY_NOTIFICATION_MSG", 25,
"SHOW_STRICT_MODE_VIOLATION_MSG", 26,
"CHECK_EXCESSIVE_WAKE_LOCKS_MSG", 27);
});
