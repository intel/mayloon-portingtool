﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.MessageQueue", "java.lang.Thread"], "android.app.Instrumentation", ["android.content.ComponentName", "$.Context", "$.Intent", "android.content.res.Configuration", "android.util.ActivityNotFoundException", "$.AndroidRuntimeException", "android.view.KeyEvent", "java.lang.IllegalArgumentException", "$.RuntimeException", "$.SecurityException", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAppContext = null;
this.mRunner = null;
this.mMessageQueue = null;
this.mThread = null;
this.mInstrContext = null;
this.mWatcher = null;
if (!Clazz.isClassDefined ("android.app.Instrumentation.InstrumentationThread")) {
android.app.Instrumentation.$Instrumentation$InstrumentationThread$ ();
}
Clazz.instantialize (this, arguments);
}, android.app, "Instrumentation");
Clazz.defineMethod (c$, "init", 
function (thread, instrContext, appContext, component, watcher) {
this.mThread = thread;
this.mInstrContext = instrContext;
this.mAppContext = appContext;
this.mWatcher = watcher;
}, "android.app.ActivityThread,android.content.Context,android.content.Context,android.content.ComponentName,android.app.IInstrumentationWatcher");
Clazz.defineMethod (c$, "onCreate", 
function ($arguments) {
}, "android.os.Bundle");
Clazz.defineMethod (c$, "start", 
function () {
if (this.mRunner != null) {
throw  new RuntimeException ("Instrumentation already started");
}this.mRunner = Clazz.innerTypeInstance (android.app.Instrumentation.InstrumentationThread, this, null, "Instr: " + this.getClass ().getName ());
this.mRunner.start ();
});
Clazz.defineMethod (c$, "onStart", 
function () {
});
Clazz.defineMethod (c$, "finish", 
function (resultCode, results) {
this.mThread.finishInstrumentation (resultCode, results);
}, "~N,android.os.Bundle");
Clazz.defineMethod (c$, "callActivityOnSaveInstanceState", 
function (activity, outState) {
activity.performSaveInstanceState (outState);
}, "android.app.Activity,android.os.Bundle");
Clazz.defineMethod (c$, "callActivityOnPause", 
function (activity) {
activity.performPause ();
}, "android.app.Activity");
Clazz.defineMethod (c$, "callActivityOnResume", 
function (activity) {
activity.onResume ();
}, "android.app.Activity");
Clazz.defineMethod (c$, "execStartActivity", 
function (who, contextThread, token, target, intent, requestCode) {
System.out.println ("in execStartActivity");
var whoThread = contextThread;
try {
var result = (android.content.Context.getSystemContext ().getSystemService ("activity")).startActivity (whoThread, intent, intent.resolveTypeIfNeeded (who.getContentResolver ()), null, 0, token, target != null ? target.mEmbeddedID : null, requestCode, false, false);
android.app.Instrumentation.checkStartActivityResult (result, intent);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
return null;
}, "android.content.Context,android.os.IBinder,android.os.IBinder,android.app.Activity,android.content.Intent,~N");
Clazz.defineMethod (c$, "newApplication", 
function (className, context) {
var app = Class.forName (className).newInstance ();
app.attach (context);
return app;
}, "~S,android.content.Context");
Clazz.defineMethod (c$, "callApplicationOnCreate", 
function (app) {
app.onCreate ();
}, "android.app.Application");
c$.checkStartActivityResult = Clazz.defineMethod (c$, "checkStartActivityResult", 
function (res, intent) {
if (res >= 0) {
return ;
}switch (res) {
case -1:
case -2:
if (Clazz.instanceOf (intent, android.content.Intent) && (intent).getComponent () != null) throw  new android.util.ActivityNotFoundException ("Unable to find explicit activity class " + (intent).getComponent ().toShortString () + "; have you declared this activity in your AndroidManifest.xml?");
throw  new android.util.ActivityNotFoundException ("No Activity found to handle " + intent);
case -4:
throw  new SecurityException ("Not allowed to start activity " + intent);
case -3:
throw  new android.util.AndroidRuntimeException ("FORWARD_RESULT_FLAG used while also requesting a result");
case -5:
throw  new IllegalArgumentException ("PendingIntent is not an activity");
default:
throw  new android.util.AndroidRuntimeException ("Unknown error code " + res + " when starting " + intent);
}
}, "~N,~O");
Clazz.defineMethod (c$, "newActivity", 
function (className, intent) {
return Class.forName (className).newInstance ();
}, "~S,android.content.Intent");
Clazz.defineMethod (c$, "callActivityOnCreate", 
function (activity, icicle) {
if (android.app.Instrumentation.mWaitingActivities == null) {
($t$ = android.app.Instrumentation.mWaitingActivities =  new java.util.ArrayList (), android.app.Instrumentation.prototype.mWaitingActivities = android.app.Instrumentation.mWaitingActivities, $t$);
}var N = android.app.Instrumentation.mWaitingActivities.size ();
for (var i = 0; i < N; i++) {
var aw = android.app.Instrumentation.mWaitingActivities.get (i);
var intent = aw.intent;
if (intent.filterEquals (activity.getIntent ())) {
aw.activity = activity;
}}
activity.onCreate (icicle);
}, "android.app.Activity,android.os.Bundle");
Clazz.defineMethod (c$, "callActivityOnStop", 
function (activity) {
activity.onStop ();
}, "android.app.Activity");
Clazz.defineMethod (c$, "callActivityOnRestoreInstanceState", 
function (activity, savedInstanceState) {
activity.performRestoreInstanceState (savedInstanceState);
}, "android.app.Activity,android.os.Bundle");
Clazz.defineMethod (c$, "callActivityOnPostCreate", 
function (activity, icicle) {
activity.onPostCreate (icicle);
}, "android.app.Activity,android.os.Bundle");
Clazz.defineMethod (c$, "callActivityOnStart", 
function (activity) {
activity.onStart ();
}, "android.app.Activity");
Clazz.defineMethod (c$, "onException", 
function (obj, e) {
return false;
}, "~O,Throwable");
Clazz.defineMethod (c$, "getTargetContext", 
function () {
return this.mAppContext;
});
Clazz.defineMethod (c$, "startActivitySync", 
function (intent) {
intent =  new android.content.Intent (intent);
var ai = intent.resolveActivityInfo (this.getTargetContext ().getPackageManager (), 0);
if (ai == null) {
throw  new RuntimeException ("Unable to resolve activity for: " + intent);
}intent.setComponent ( new android.content.ComponentName (ai.applicationInfo.packageName, ai.name));
var aw =  new android.app.Instrumentation.ActivityWaiter (intent);
if (android.app.Instrumentation.mWaitingActivities == null) {
($t$ = android.app.Instrumentation.mWaitingActivities =  new java.util.ArrayList (), android.app.Instrumentation.prototype.mWaitingActivities = android.app.Instrumentation.mWaitingActivities, $t$);
}android.app.Instrumentation.mWaitingActivities.add (aw);
this.getTargetContext ().startActivity (intent);
return aw.activity;
}, "android.content.Intent");
Clazz.defineMethod (c$, "waitForIdle", 
function (recipient) {
this.mMessageQueue.addIdleHandler ( new android.app.Instrumentation.Idler (recipient));
this.mThread.getHandler ().post ( new android.app.Instrumentation.EmptyRunnable ());
}, "Runnable");
Clazz.defineMethod (c$, "waitForIdleSync", 
function () {
var idler =  new android.app.Instrumentation.Idler (null);
this.mMessageQueue.addIdleHandler (idler);
this.mThread.getHandler ().post ( new android.app.Instrumentation.EmptyRunnable ());
idler.waitForIdle ();
});
Clazz.defineMethod (c$, "runOnMainSync", 
function (runner) {
var sr =  new android.app.Instrumentation.SyncRunnable (runner);
this.mThread.getHandler ().post (sr);
sr.waitForComplete ();
}, "Runnable");
Clazz.defineMethod (c$, "sendKeySync", 
function (event, ID) {
var action = event.getAction ();
var code = event.getKeyCode ();
var evt;
var eventType;
var element = document.getElementById(ID);
if(action == 0)
eventType = "keydown";
else
eventType = "keyup";
if (window.KeyEvent) {
evt = document.createEvent('KeyEvents');
evt.initKeyEvent(eventType, false, true, window, false, false, false, false, code, code);
}
else if(window.KeyboardEvent)
{
evt = document.createEvent('KeyboardEvents');
Object.defineProperty(evt,'keyCode', {
get : function(){
return this.keyCodeVal;
}
})
evt.initKeyboardEvent(eventType, false, true, window, code, code, false, false, false, false);
evt.keyCodeVal = Number(code);
}
else {
evt = document.createEvent('UIEvent');
evt.shiftKey = false;
evt.metaKey = false;
evt.altKey = false;
evt.ctrlKey = false;
evt.initUIEvent(eventType, false, true, window, 1);
evt.charCode = code;
evt.keyCode = code;
evt.which = code;
}
element.dispatchEvent(evt);
}, "android.view.KeyEvent,~N");
Clazz.defineMethod (c$, "sendEvent", 
function (eventType, ID, canBubble) {
var element = document.getElementById(ID);
var evt = document.createEvent("HTMLEvents");
evt.initEvent(eventType,canBubble,true);
element.dispatchEvent(evt);
}, "~S,~N,~B");
Clazz.defineMethod (c$, "sendCharacterSync", 
function (keyCode, ID) {
this.sendKeySync ( new android.view.KeyEvent (0, keyCode), ID);
this.sendKeySync ( new android.view.KeyEvent (1, keyCode), ID);
}, "~N,~N");
Clazz.defineMethod (c$, "sendKeyDownUpSync", 
function (key, ID) {
this.sendKeySync ( new android.view.KeyEvent (0, key), ID);
this.sendKeySync ( new android.view.KeyEvent (1, key), ID);
}, "~N,~N");
Clazz.defineMethod (c$, "newActivity", 
function (clazz, context, token, application, intent, info, title, parent, id, lastNonConfigurationInstance) {
var activity = clazz.newInstance ();
var aThread = null;
activity.attach (context, aThread, this, token, application, intent, info, title, parent, id, lastNonConfigurationInstance,  new android.content.res.Configuration ());
return activity;
}, "Class,android.content.Context,android.os.IBinder,android.app.Application,android.content.Intent,android.content.pm.ActivityInfo,CharSequence,android.app.Activity,~S,~O");
c$.newApplication = Clazz.defineMethod (c$, "newApplication", 
function (clazz, context) {
var app = clazz.newInstance ();
app.attach (context);
return app;
}, "Class,android.content.Context");
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mInstrContext;
});
Clazz.defineMethod (c$, "sendStatus", 
function (resultCode, results) {
}, "~N,android.os.Bundle");
Clazz.defineMethod (c$, "sendPointerSync", 
function (event) {
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "getBinderCounts", 
function () {
console.log("Missing method: getBinderCounts");
});
Clazz.defineMethod (c$, "callActivityOnRestart", 
function (activity) {
console.log("Missing method: callActivityOnRestart");
}, "android.app.Activity");
Clazz.defineMethod (c$, "endPerformanceSnapshot", 
function () {
console.log("Missing method: endPerformanceSnapshot");
});
Clazz.defineMethod (c$, "stopAllocCounting", 
function () {
console.log("Missing method: stopAllocCounting");
});
Clazz.defineMethod (c$, "onDestroy", 
function () {
console.log("Missing method: onDestroy");
});
Clazz.defineMethod (c$, "startAllocCounting", 
function () {
console.log("Missing method: startAllocCounting");
});
Clazz.defineMethod (c$, "isProfiling", 
function () {
console.log("Missing method: isProfiling");
});
Clazz.defineMethod (c$, "addMonitor", 
function (cls, result, block) {
console.log("Missing method: addMonitor");
}, "~S,android.app.Instrumentation.ActivityResult,~B");
Clazz.defineMethod (c$, "stopProfiling", 
function () {
console.log("Missing method: stopProfiling");
});
Clazz.defineMethod (c$, "callActivityOnUserLeaving", 
function (activity) {
console.log("Missing method: callActivityOnUserLeaving");
}, "android.app.Activity");
Clazz.defineMethod (c$, "sendKeyDownUpSync", 
function (key) {
console.log("Missing method: sendKeyDownUpSync");
}, "~N");
Clazz.defineMethod (c$, "callActivityOnDestroy", 
function (activity) {
console.log("Missing method: callActivityOnDestroy");
}, "android.app.Activity");
Clazz.defineMethod (c$, "removeMonitor", 
function (monitor) {
console.log("Missing method: removeMonitor");
}, "~O");
Clazz.defineMethod (c$, "setAutomaticPerformanceSnapshots", 
function () {
console.log("Missing method: setAutomaticPerformanceSnapshots");
});
Clazz.defineMethod (c$, "startProfiling", 
function () {
console.log("Missing method: startProfiling");
});
Clazz.defineMethod (c$, "setInTouchMode", 
function (inTouch) {
console.log("Missing method: setInTouchMode");
}, "~B");
Clazz.defineMethod (c$, "waitForMonitor", 
function (monitor) {
console.log("Missing method: waitForMonitor");
}, "~O");
Clazz.defineMethod (c$, "startPerformanceSnapshot", 
function () {
console.log("Missing method: startPerformanceSnapshot");
});
Clazz.defineMethod (c$, "addMonitor", 
function (monitor) {
console.log("Missing method: addMonitor");
}, "~O");
Clazz.defineMethod (c$, "sendStringSync", 
function (text) {
console.log("Missing method: sendStringSync");
}, "~S");
Clazz.defineMethod (c$, "sendCharacterSync", 
function (keyCode) {
console.log("Missing method: sendCharacterSync");
}, "~N");
c$.$Instrumentation$InstrumentationThread$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.app.Instrumentation, "InstrumentationThread", Thread);
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["android.app.Instrumentation"].onStart ();
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mResultCode = 0;
this.mResultData = null;
Clazz.instantialize (this, arguments);
}, android.app.Instrumentation, "ActivityResult");
Clazz.makeConstructor (c$, 
function (a, b) {
this.mResultCode = a;
this.mResultData = b;
}, "~N,android.content.Intent");
Clazz.defineMethod (c$, "getResultCode", 
function () {
return this.mResultCode;
});
Clazz.defineMethod (c$, "getResultData", 
function () {
return this.mResultData;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.intent = null;
this.activity = null;
Clazz.instantialize (this, arguments);
}, android.app.Instrumentation, "ActivityWaiter");
Clazz.makeConstructor (c$, 
function (a) {
this.intent = a;
}, "android.content.Intent");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mCallback = null;
this.mIdle = false;
Clazz.instantialize (this, arguments);
}, android.app.Instrumentation, "Idler", null, android.os.MessageQueue.IdleHandler);
Clazz.makeConstructor (c$, 
function (a) {
this.mCallback = a;
this.mIdle = false;
}, "Runnable");
Clazz.overrideMethod (c$, "queueIdle", 
function () {
if (this.mCallback != null) {
this.mCallback.run ();
}{
this.mIdle = true;
this.notifyAll ();
}return false;
});
Clazz.defineMethod (c$, "waitForIdle", 
function () {
{
while (!this.mIdle) {
try {
this.wait ();
} catch (e) {
if (Clazz.instanceOf (e, InterruptedException)) {
} else {
throw e;
}
}
}
}});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.app.Instrumentation, "EmptyRunnable", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mTarget = null;
this.mComplete = false;
Clazz.instantialize (this, arguments);
}, android.app.Instrumentation, "SyncRunnable", null, Runnable);
Clazz.makeConstructor (c$, 
function (a) {
this.mTarget = a;
}, "Runnable");
Clazz.defineMethod (c$, "run", 
function () {
this.mTarget.run ();
{
this.mComplete = true;
this.notifyAll ();
}});
Clazz.defineMethod (c$, "waitForComplete", 
function () {
{
while (!this.mComplete) {
try {
this.wait ();
} catch (e) {
if (Clazz.instanceOf (e, InterruptedException)) {
} else {
throw e;
}
}
}
}});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"REPORT_KEY_IDENTIFIER", "id",
"TAG", "Instrumentation",
"REPORT_KEY_STREAMRESULT", "stream",
"mWaitingActivities", null);
});
