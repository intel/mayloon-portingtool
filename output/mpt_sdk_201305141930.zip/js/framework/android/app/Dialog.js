﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.content.DialogInterface", "android.os.Handler", "android.view.KeyEvent", "$.View", "$.Window"], "android.app.Dialog", ["android.os.Bundle", "$.Message", "android.util.Log", "android.view.ContextThemeWrapper", "$.ViewConfiguration", "$.WindowManager", "$.WindowManagerImpl", "java.lang.Thread", "java.lang.ref.WeakReference"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mOwnerActivity = null;
this.mContext = null;
this.mWindowManager = null;
this.mWindow = null;
this.mDecor = null;
this.mCancelable = true;
this.mCancelMessage = null;
this.mDismissMessage = null;
this.mShowMessage = null;
this.mCanceledOnTouchOutside = false;
this.mOnKeyListener = null;
this.mCreated = false;
this.mShowing = false;
this.mUiThread = null;
this.mHandler = null;
this.mListenersHandler = null;
this.mDismissAction = null;
Clazz.instantialize (this, arguments);
}, android.app, "Dialog", null, [android.content.DialogInterface, android.view.Window.Callback, android.view.KeyEvent.Callback, android.view.View.OnCreateContextMenuListener]);
Clazz.prepareFields (c$, function () {
this.mHandler =  new android.os.Handler ();
this.mDismissAction = ((Clazz.isClassDefined ("android.app.Dialog$1") ? 0 : android.app.Dialog.$Dialog$1$ ()), Clazz.innerTypeInstance (android.app.Dialog$1, this, null));
});
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, 0);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, theme) {
this.mContext =  new android.view.ContextThemeWrapper (context, theme == 0 ? 16973835 : theme);
this.mWindowManager = android.view.WindowManagerImpl.getDefault ();
var w =  new android.view.Window (this.mContext);
this.mWindow = w;
w.setCallback (this);
w.setWindowManager (this.mWindowManager, null, null);
w.setGravity (17);
this.mUiThread = Thread.currentThread ();
this.mListenersHandler =  new android.app.Dialog.ListenersHandler (this);
}, "android.content.Context,~N");
Clazz.makeConstructor (c$, 
function (context, cancelable, cancelCallback) {
this.construct (context);
this.mCancelable = cancelable;
this.mCancelMessage = cancelCallback;
}, "android.content.Context,~B,android.os.Message");
Clazz.makeConstructor (c$, 
function (context, cancelable, cancelListener) {
this.construct (context);
this.mCancelable = cancelable;
this.setOnCancelListener (cancelListener);
}, "android.content.Context,~B,android.content.DialogInterface.OnCancelListener");
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.defineMethod (c$, "setOwnerActivity", 
function (activity) {
this.mOwnerActivity = activity;
}, "android.app.Activity");
Clazz.defineMethod (c$, "getOwnerActivity", 
function () {
return this.mOwnerActivity;
});
Clazz.defineMethod (c$, "isShowing", 
function () {
return this.mShowing;
});
Clazz.defineMethod (c$, "show", 
function () {
if (this.mShowing) {
if (this.mDecor != null) {
this.mDecor.setVisibility (0);
}return ;
}if (!this.mCreated) {
this.dispatchOnCreate (null);
}this.onStart ();
this.mDecor = this.mWindow.getDecorView ();
this.mDecor.zIndex = this.mContext.getActivityManager ().mCurActivity.mZIndex + 1;
var l = this.mWindow.getAttributes ();
if ((l.softInputMode & 256) == 0) {
var nl =  new android.view.WindowManager.LayoutParams ();
nl.copyFrom (l);
nl.softInputMode |= 256;
l = nl;
}try {
this.mWindowManager.addView (this.mDecor, l);
this.mShowing = true;
this.sendShowMessage ();
} finally {
}
});
Clazz.defineMethod (c$, "hide", 
function () {
if (this.mDecor != null) {
this.mDecor.setVisibility (8);
}});
Clazz.overrideMethod (c$, "dismiss", 
function () {
if (Thread.currentThread () !== this.mUiThread) {
this.mHandler.post (this.mDismissAction);
} else {
this.mDismissAction.run ();
}});
Clazz.defineMethod (c$, "dismissDialog", 
($fz = function () {
if (this.mDecor == null || !this.mShowing) {
return ;
}try {
this.mWindowManager.removeView (this.mDecor);
} finally {
this.mDecor = null;
this.mWindow.closeAllPanels ();
this.onStop ();
this.mShowing = false;
this.sendDismissMessage ();
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "sendDismissMessage", 
($fz = function () {
if (this.mDismissMessage != null) {
android.os.Message.obtain (this.mDismissMessage).sendToTarget ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "sendShowMessage", 
($fz = function () {
if (this.mShowMessage != null) {
android.os.Message.obtain (this.mShowMessage).sendToTarget ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "dispatchOnCreate", 
function (savedInstanceState) {
if (!this.mCreated) {
this.onCreate (savedInstanceState);
this.mCreated = true;
}}, "android.os.Bundle");
Clazz.defineMethod (c$, "onCreate", 
function (savedInstanceState) {
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onStart", 
function () {
});
Clazz.defineMethod (c$, "onStop", 
function () {
});
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
var bundle =  new android.os.Bundle ();
bundle.putBoolean ("android:dialogShowing", this.mShowing);
if (this.mCreated) {
bundle.putBundle ("android:dialogHierarchy", this.mWindow.saveHierarchyState ());
}return bundle;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (savedInstanceState) {
var dialogHierarchyState = savedInstanceState.getBundle ("android:dialogHierarchy");
if (dialogHierarchyState == null) {
return ;
}this.dispatchOnCreate (savedInstanceState);
this.mWindow.restoreHierarchyState (dialogHierarchyState);
if (savedInstanceState.getBoolean ("android:dialogShowing")) {
this.show ();
}}, "android.os.Bundle");
Clazz.defineMethod (c$, "getWindow", 
function () {
return this.mWindow;
});
Clazz.defineMethod (c$, "getCurrentFocus", 
function () {
return this.mWindow != null ? this.mWindow.getCurrentFocus () : null;
});
Clazz.defineMethod (c$, "findViewById", 
function (id) {
return this.mWindow.findViewById (id);
}, "~N");
Clazz.defineMethod (c$, "setContentView", 
function (layoutResID) {
this.mWindow.setContentView (layoutResID);
}, "~N");
Clazz.defineMethod (c$, "setContentView", 
function (view) {
this.mWindow.setContentView (view);
}, "android.view.View");
Clazz.defineMethod (c$, "setContentView", 
function (view, params) {
this.mWindow.setContentView (view, params);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addContentView", 
function (view, params) {
this.mWindow.addContentView (view, params);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "setTitle", 
function (title) {
this.mWindow.setTitle (title);
this.mWindow.getAttributes ().setTitle (title);
}, "CharSequence");
Clazz.defineMethod (c$, "setTitle", 
function (titleId) {
this.setTitle (this.mContext.getText (titleId));
}, "~N");
Clazz.overrideMethod (c$, "onKeyDown", 
function (keyCode, event) {
if (keyCode == 115) {
event.startTracking ();
return true;
}return false;
}, "~N,android.view.KeyEvent");
Clazz.overrideMethod (c$, "onKeyLongPress", 
function (keyCode, event) {
return false;
}, "~N,android.view.KeyEvent");
Clazz.overrideMethod (c$, "onKeyUp", 
function (keyCode, event) {
if (keyCode == 115 && event.isTracking () && !event.isCanceled ()) {
this.onBackPressed ();
return true;
}return false;
}, "~N,android.view.KeyEvent");
Clazz.overrideMethod (c$, "onKeyMultiple", 
function (keyCode, repeatCount, event) {
return false;
}, "~N,~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onBackPressed", 
function () {
if (this.mCancelable) {
this.cancel ();
}});
Clazz.defineMethod (c$, "onTouchEvent", 
function (event) {
if (this.mCancelable && this.mCanceledOnTouchOutside && event.getAction () == 0 && this.isOutOfBounds (event)) {
this.cancel ();
return true;
}return false;
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "isOutOfBounds", 
($fz = function (event) {
var x = Math.round (event.getX ());
var y = Math.round (event.getY ());
var slop = android.view.ViewConfiguration.get (this.mContext).getScaledWindowTouchSlop ();
var decorView = this.getWindow ().getDecorView ();
return (x < -slop) || (y < -slop) || (x > (decorView.getWidth () + slop)) || (y > (decorView.getHeight () + slop));
}, $fz.isPrivate = true, $fz), "android.view.MotionEvent");
Clazz.defineMethod (c$, "onTrackballEvent", 
function (event) {
return false;
}, "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onWindowAttributesChanged", 
function (params) {
if (this.mDecor != null) {
this.mWindowManager.updateViewLayout (this.mDecor, params);
}}, "android.view.WindowManager.LayoutParams");
Clazz.overrideMethod (c$, "onContentChanged", 
function () {
});
Clazz.defineMethod (c$, "onWindowFocusChanged", 
function (hasFocus) {
}, "~B");
Clazz.defineMethod (c$, "onAttachedToWindow", 
function () {
});
Clazz.defineMethod (c$, "onDetachedFromWindow", 
function () {
});
Clazz.overrideMethod (c$, "dispatchKeyEvent", 
function (event) {
if ((this.mOnKeyListener != null) && (this.mOnKeyListener.onKey (this, event.getKeyCode (), event))) {
return true;
}if (this.mWindow.superDispatchKeyEvent (event)) {
return true;
}return event.dispatch (this, this.mDecor != null ? this.mDecor.getKeyDispatcherState () : null, this);
}, "android.view.KeyEvent");
Clazz.overrideMethod (c$, "dispatchTouchEvent", 
function (ev) {
if (this.mWindow.superDispatchTouchEvent (ev)) {
return true;
}return this.onTouchEvent (ev);
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "dispatchTrackballEvent", 
function (ev) {
return this.onTrackballEvent (ev);
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "dispatchPopulateAccessibilityEvent", 
function (event) {
event.setClassName (this.getClass ().getName ());
event.setPackageName (this.mContext.getPackageName ());
var params = this.getWindow ().getAttributes ();
var isFullScreen = (params.width == -1) && (params.height == -1);
event.setFullScreen (isFullScreen);
return false;
}, "android.view.accessibility.AccessibilityEvent");
Clazz.overrideMethod (c$, "onCreatePanelView", 
function (featureId) {
return null;
}, "~N");
Clazz.overrideMethod (c$, "onCreatePanelMenu", 
function (featureId, menu) {
if (featureId == 0) {
return this.onCreateOptionsMenu (menu);
}return false;
}, "~N,android.view.Menu");
Clazz.overrideMethod (c$, "onPreparePanel", 
function (featureId, view, menu) {
if (featureId == 0 && menu != null) {
var goforit = this.onPrepareOptionsMenu (menu);
return goforit && menu.hasVisibleItems ();
}return true;
}, "~N,android.view.View,android.view.Menu");
Clazz.overrideMethod (c$, "onMenuOpened", 
function (featureId, menu) {
return true;
}, "~N,android.view.Menu");
Clazz.overrideMethod (c$, "onMenuItemSelected", 
function (featureId, item) {
return false;
}, "~N,android.view.MenuItem");
Clazz.overrideMethod (c$, "onPanelClosed", 
function (featureId, menu) {
}, "~N,android.view.Menu");
Clazz.defineMethod (c$, "onCreateOptionsMenu", 
function (menu) {
return true;
}, "android.view.Menu");
Clazz.defineMethod (c$, "onPrepareOptionsMenu", 
function (menu) {
return true;
}, "android.view.Menu");
Clazz.defineMethod (c$, "onOptionsItemSelected", 
function (item) {
return false;
}, "android.view.MenuItem");
Clazz.defineMethod (c$, "onOptionsMenuClosed", 
function (menu) {
}, "android.view.Menu");
Clazz.defineMethod (c$, "openOptionsMenu", 
function () {
this.mWindow.openPanel (0, null);
});
Clazz.defineMethod (c$, "closeOptionsMenu", 
function () {
this.mWindow.closePanel (0);
});
Clazz.overrideMethod (c$, "onCreateContextMenu", 
function (menu, v, menuInfo) {
}, "android.view.ContextMenu,android.view.View,android.view.ContextMenu.ContextMenuInfo");
Clazz.defineMethod (c$, "registerForContextMenu", 
function (view) {
view.setOnCreateContextMenuListener (this);
}, "android.view.View");
Clazz.defineMethod (c$, "unregisterForContextMenu", 
function (view) {
view.setOnCreateContextMenuListener (null);
}, "android.view.View");
Clazz.defineMethod (c$, "openContextMenu", 
function (view) {
view.showContextMenu ();
}, "android.view.View");
Clazz.defineMethod (c$, "onContextItemSelected", 
function (item) {
return false;
}, "android.view.MenuItem");
Clazz.defineMethod (c$, "onContextMenuClosed", 
function (menu) {
}, "android.view.Menu");
Clazz.defineMethod (c$, "onSearchRequested", 
function () {
android.util.Log.e ("Dialog", "onSearchRequested is not implemented!");
return false;
});
Clazz.defineMethod (c$, "takeKeyEvents", 
function (get) {
android.util.Log.e ("Dialog", "takeKeyEvents is not implemented!");
}, "~B");
Clazz.defineMethod (c$, "requestWindowFeature", 
function (featureId) {
return this.getWindow ().requestFeature (featureId);
}, "~N");
Clazz.defineMethod (c$, "setFeatureDrawableResource", 
function (featureId, resId) {
this.getWindow ().setFeatureDrawableResource (featureId, resId);
}, "~N,~N");
Clazz.defineMethod (c$, "setFeatureDrawableUri", 
function (featureId, uri) {
this.getWindow ().setFeatureDrawableUri (featureId, uri);
}, "~N,android.net.Uri");
Clazz.defineMethod (c$, "setFeatureDrawable", 
function (featureId, drawable) {
this.getWindow ().setFeatureDrawable (featureId, drawable);
}, "~N,android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setFeatureDrawableAlpha", 
function (featureId, alpha) {
this.getWindow ().setFeatureDrawableAlpha (featureId, alpha);
}, "~N,~N");
Clazz.defineMethod (c$, "getLayoutInflater", 
function () {
return this.getWindow ().getLayoutInflater ();
});
Clazz.defineMethod (c$, "setCancelable", 
function (flag) {
this.mCancelable = flag;
}, "~B");
Clazz.defineMethod (c$, "setCanceledOnTouchOutside", 
function (cancel) {
if (cancel && !this.mCancelable) {
this.mCancelable = true;
}this.mCanceledOnTouchOutside = cancel;
}, "~B");
Clazz.overrideMethod (c$, "cancel", 
function () {
if (this.mCancelMessage != null) {
android.os.Message.obtain (this.mCancelMessage).sendToTarget ();
}this.dismiss ();
});
Clazz.defineMethod (c$, "setOnCancelListener", 
function (listener) {
if (listener != null) {
this.mCancelMessage = this.mListenersHandler.obtainMessage (68, listener);
} else {
this.mCancelMessage = null;
}}, "android.content.DialogInterface.OnCancelListener");
Clazz.defineMethod (c$, "setCancelMessage", 
function (msg) {
this.mCancelMessage = msg;
}, "android.os.Message");
Clazz.defineMethod (c$, "setOnDismissListener", 
function (listener) {
if (listener != null) {
this.mDismissMessage = this.mListenersHandler.obtainMessage (67, listener);
} else {
this.mDismissMessage = null;
}}, "android.content.DialogInterface.OnDismissListener");
Clazz.defineMethod (c$, "setOnShowListener", 
function (listener) {
if (listener != null) {
this.mShowMessage = this.mListenersHandler.obtainMessage (69, listener);
} else {
this.mShowMessage = null;
}}, "android.content.DialogInterface.OnShowListener");
Clazz.defineMethod (c$, "setDismissMessage", 
function (msg) {
this.mDismissMessage = msg;
}, "android.os.Message");
Clazz.defineMethod (c$, "setVolumeControlStream", 
function (streamType) {
android.util.Log.e ("Dialog", "setVolumeControlStream is not implemented!");
}, "~N");
Clazz.defineMethod (c$, "getVolumeControlStream", 
function () {
android.util.Log.e ("Dialog", "getVolumeControlStream is not implemented!");
return 0;
});
Clazz.defineMethod (c$, "setOnKeyListener", 
function (onKeyListener) {
this.mOnKeyListener = onKeyListener;
}, "android.content.DialogInterface.OnKeyListener");
c$.$Dialog$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.app, "Dialog$1", null, Runnable);
Clazz.defineMethod (c$, "run", 
function () {
this.b$["android.app.Dialog"].dismissDialog ();
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mDialog = null;
Clazz.instantialize (this, arguments);
}, android.app.Dialog, "ListenersHandler", android.os.Handler);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.app.Dialog.ListenersHandler, []);
this.mDialog =  new java.lang.ref.WeakReference (a);
}, "android.app.Dialog");
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
switch (a.what) {
case 67:
(a.obj).onDismiss (this.mDialog.get ());
break;
case 68:
(a.obj).onCancel (this.mDialog.get ());
break;
case 69:
(a.obj).onShow (this.mDialog.get ());
break;
}
}, "android.os.Message");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DISMISS", 0x43,
"CANCEL", 0x44,
"SHOW", 0x45,
"DIALOG_SHOWING_TAG", "android:dialogShowing",
"DIALOG_HIERARCHY_TAG", "android:dialogHierarchy");
});
