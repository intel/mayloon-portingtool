﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.content.Context", "android.content.pm.PackageManager"], "android.app.ContextImpl", ["android.app.ReceiverRestrictedContext", "android.content.res.Resources", "android.hardware.SensorManager", "android.media.AudioManager", "android.os.FileUtils", "android.util.AndroidRuntimeException", "$.Log", "java.io.File", "$.FileInputStream", "$.FileOutputStream", "java.lang.IllegalArgumentException", "$.RuntimeException", "$.SecurityException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAudioManager = null;
this.$mPackageInfo = null;
this.$mResources = null;
this.mMainThread = null;
this.$mOuterContext = null;
this.$mActivityToken = null;
this.$mContentResolver = null;
this.$mThemeResource = 0;
this.$mTheme = null;
this.$mPackageManager = null;
this.$mNotificationManager = null;
this.$mActivityManager = null;
this.mReceiverRestrictedContext = null;
this.mSensorManager = null;
this.$mLayoutInflater = null;
this.mRestricted = false;
this.mSync = null;
this.mDatabasesDir = null;
this.$mPreferencesDir = null;
this.$mFilesDir = null;
this.$mCacheDir = null;
this.$mExternalFilesDir = null;
this.$mExternalCacheDir = null;
Clazz.instantialize (this, arguments);
}, android.app, "ContextImpl", android.content.Context);
Clazz.prepareFields (c$, function () {
this.mSync =  new JavaObject ();
});
c$.getInstanceCount = Clazz.defineMethod (c$, "getInstanceCount", 
function () {
return android.app.ContextImpl.sInstanceCount;
});
Clazz.overrideMethod (c$, "getResources", 
function () {
return this.$mResources;
});
Clazz.overrideMethod (c$, "getContentResolver", 
function () {
return this.$mContentResolver;
});
Clazz.overrideMethod (c$, "getApplicationContext", 
function () {
return (this.$mPackageInfo != null) ? this.$mPackageInfo.getApplication () : this.mMainThread.getApplication ();
});
Clazz.overrideMethod (c$, "setTheme", 
function (resid) {
this.$mThemeResource = resid;
}, "~N");
Clazz.overrideMethod (c$, "getTheme", 
function () {
if (this.$mTheme == null) {
if (this.$mThemeResource == 0) {
this.$mThemeResource = 16973829;
}this.$mTheme = this.$mResources.newTheme ();
this.$mTheme.applyStyle (this.$mThemeResource, true);
}return this.$mTheme;
});
Clazz.overrideMethod (c$, "openFileInput", 
function (name) {
var f = this.makeFilename (this.getFilesDir (), name);
return  new java.io.FileInputStream (f);
}, "~S");
Clazz.overrideMethod (c$, "openFileOutput", 
function (name, mode) {
var append = (mode & 32768) != 0;
var f = this.makeFilename (this.getFilesDir (), name);
try {
var fos =  new java.io.FileOutputStream (f, append);
android.app.ContextImpl.setFilePermissionsFromMode (f.getPath (), mode, 0);
return fos;
} catch (e) {
if (Clazz.instanceOf (e, java.io.FileNotFoundException)) {
} else {
throw e;
}
}
var parent = f.getParentFile ();
parent.mkdir ();
android.os.FileUtils.setPermissions (parent.getPath (), 505, -1, -1);
var fos =  new java.io.FileOutputStream (f, append);
android.app.ContextImpl.setFilePermissionsFromMode (f.getPath (), mode, 0);
return fos;
}, "~S,~N");
Clazz.defineMethod (c$, "registerReceiver", 
function (receiver, filter) {
return this.registerReceiver (receiver, filter, null, null);
}, "android.content.BroadcastReceiver,android.content.IntentFilter");
Clazz.overrideMethod (c$, "unregisterReceiver", 
function (receiver) {
}, "android.content.BroadcastReceiver");
Clazz.defineMethod (c$, "uriModeFlagToString", 
($fz = function (uriModeFlags) {
switch (uriModeFlags) {
case 3:
return "read and write";
case 1:
return "read";
case 2:
return "write";
}
throw  new IllegalArgumentException ("Unknown permission mode flags: " + uriModeFlags);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "createPackageContext", 
function (packageName, flags) {
if (packageName.equals ("system") || packageName.equals ("android")) {
return  new android.app.ContextImpl (this.mMainThread.getSystemContext ());
}var pi = this.mMainThread.getPackageInfo (packageName, flags);
if (pi != null) {
var c =  new android.app.ContextImpl ();
c.mRestricted = (flags & 4) == 4;
c.init (pi, null, this.mMainThread, this.$mResources);
if (c.$mResources != null) {
return c;
}}throw  new android.content.pm.PackageManager.NameNotFoundException ("Application package " + packageName + " not found");
}, "~S,~N");
Clazz.overrideMethod (c$, "isRestricted", 
function () {
return this.mRestricted;
});
c$.createSystemContext = Clazz.defineMethod (c$, "createSystemContext", 
function (mainThread) {
var $private = Clazz.checkPrivateMethod (arguments);
if ($private != null) {
return $private.apply (this, arguments);
}
var context =  new android.app.ContextImpl ();
context.init (android.content.res.Resources.getSystem (), mainThread);
return context;
}, "android.app.ActivityThread");
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.app.ContextImpl, []);
this.$mOuterContext = this;
});
Clazz.makeConstructor (c$, 
function (context) {
Clazz.superConstructor (this, android.app.ContextImpl, []);
($t$ = ++ android.app.ContextImpl.sInstanceCount, android.app.ContextImpl.prototype.sInstanceCount = android.app.ContextImpl.sInstanceCount, $t$);
this.$mPackageInfo = context.$mPackageInfo;
this.$mResources = context.$mResources;
this.mMainThread = context.mMainThread;
this.$mContentResolver = context.$mContentResolver;
this.$mOuterContext = this;
}, "android.app.ContextImpl");
Clazz.defineMethod (c$, "init", 
function (packageInfo, activityToken, mainThread) {
this.init (packageInfo, activityToken, mainThread, null);
}, "android.app.LoadedApk,android.os.IBinder,android.app.ActivityThread");
Clazz.defineMethod (c$, "init", 
function (packageInfo, activityToken, mainThread, container) {
this.$mPackageInfo = packageInfo;
this.$mResources = (android.content.Context.getSystemContext ().getSystemService ("package")).getPackageResources (this.$mPackageInfo.getPackageName ());
this.mMainThread = mainThread;
this.$mContentResolver = Clazz.innerTypeInstance (android.content.Context.ApplicationContentResolver, this, null, this, mainThread);
this.setActivityToken (activityToken);
}, "android.app.LoadedApk,android.os.IBinder,android.app.ActivityThread,android.content.res.Resources");
Clazz.defineMethod (c$, "init", 
function (resources, mainThread) {
this.$mPackageInfo = null;
this.$mResources = resources;
this.mMainThread = mainThread;
this.$mContentResolver = Clazz.innerTypeInstance (android.content.Context.ApplicationContentResolver, this, null, this, mainThread);
}, "android.content.res.Resources,android.app.ActivityThread");
Clazz.defineMethod (c$, "getReceiverRestrictedContext", 
function () {
if (this.mReceiverRestrictedContext != null) {
return this.mReceiverRestrictedContext;
}return this.mReceiverRestrictedContext =  new android.app.ReceiverRestrictedContext (this.getOuterContext ());
});
Clazz.overrideMethod (c$, "setActivityToken", 
function (token) {
this.$mActivityToken = token;
}, "android.os.IBinder");
c$.setFilePermissionsFromMode = Clazz.defineMethod (c$, "setFilePermissionsFromMode", 
($fz = function (name, mode, extraPermissions) {
var perms = 256 | 128 | 32 | 16 | extraPermissions;
if ((mode & 1) != 0) {
perms |= 4;
}if ((mode & 2) != 0) {
perms |= 2;
}if (false) {
android.util.Log.i ("ApplicationContext", "File " + name + ": mode=0x" + Integer.toHexString (mode) + ", perms=0x" + Integer.toHexString (perms));
}android.os.FileUtils.setPermissions (name, perms, -1, -1);
}, $fz.isPrivate = true, $fz), "~S,~N,~N");
Clazz.defineMethod (c$, "makeFilename", 
($fz = function (base, name) {
var $private = Clazz.checkPrivateMethod (arguments);
if ($private != null) {
return $private.apply (this, arguments);
}
if (name.indexOf (java.io.File.separatorChar) < 0) {
return  new java.io.File (base, name);
}throw  new IllegalArgumentException ("File " + name + " contains a path separator");
}, $fz.isPrivate = true, $fz), "java.io.File,~S");
Clazz.overrideMethod (c$, "getPackageName", 
function () {
if (this.$mPackageInfo != null) {
return this.$mPackageInfo.getPackageName ();
}throw  new RuntimeException ("Not supported in system context");
});
Clazz.overrideMethod (c$, "startActivity", 
function (intent) {
if ((intent.getFlags () & 268435456) == 0) {
throw  new android.util.AndroidRuntimeException ("Calling startActivity() from outside of an Activity  context requires the FLAG_ACTIVITY_NEW_TASK flag. Is this really what you want?");
}this.mMainThread.getInstrumentation ().execStartActivity (this.getOuterContext (), this.mMainThread.getApplicationThread (), null, null, intent, -1);
}, "android.content.Intent");
Clazz.pu$h ();
c$ = Clazz.declareType (android.app.ContextImpl, "ApplicationPackageManager", android.content.pm.PackageManager);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"$TAG", "ApplicationContext",
"$DEBUG", false,
"DEBUG_ICONS", false);
c$.sSync = c$.prototype.sSync =  new JavaObject ();
Clazz.defineStatics (c$,
"sAlarmManager", null,
"sPowerManager", null,
"sLocationManager", null,
"sInstanceCount", 0,
"EMPTY_FILE_LIST", []);
});
