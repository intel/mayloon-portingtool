﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.app.Notification", ["java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.when = 0;
this.icon = 0;
this.number = 0;
this.contentIntent = null;
this.deleteIntent = null;
this.fullScreenIntent = null;
this.tickerText = null;
this.iconLevel = 0;
this.sound = null;
this.audioStreamType = -1;
this.vibrate = null;
this.ledARGB = 0;
this.ledOnMS = 0;
this.ledOffMS = 0;
this.defaults = 0;
this.flags = 0;
Clazz.instantialize (this, arguments);
}, android.app, "Notification", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
this.when = System.currentTimeMillis ();
});
Clazz.makeConstructor (c$, 
function (context, icon, tickerText, when, contentTitle, contentText, contentIntent) {
this.when = when;
this.icon = icon;
this.tickerText = tickerText;
}, "android.content.Context,~N,CharSequence,~N,CharSequence,CharSequence,android.content.Intent");
Clazz.makeConstructor (c$, 
function (icon, tickerText, when) {
this.icon = icon;
this.tickerText = tickerText;
this.when = when;
}, "~N,CharSequence,~N");
Clazz.makeConstructor (c$, 
function (parcel) {
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "clone", 
function () {
return null;
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (parcel, flags) {
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "setLatestEventInfo", 
function (context, contentTitle, contentText, contentIntent) {
}, "android.content.Context,CharSequence,CharSequence,android.app.PendingIntent");
Clazz.overrideMethod (c$, "toString", 
function () {
var sb =  new StringBuilder ();
sb.append ("Notification(vibrate=");
if (this.vibrate != null) {
var N = this.vibrate.length - 1;
sb.append ("[");
for (var i = 0; i < N; i++) {
sb.append (this.vibrate[i]);
sb.append (',');
}
if (N != -1) {
sb.append (this.vibrate[N]);
}sb.append ("]");
} else if ((this.defaults & 2) != 0) {
sb.append ("default");
} else {
sb.append ("null");
}sb.append (",sound=");
if (this.sound != null) {
sb.append (this.sound.toString ());
} else if ((this.defaults & 1) != 0) {
sb.append ("default");
} else {
sb.append ("null");
}sb.append (",defaults=0x");
sb.append (Integer.toHexString (this.defaults));
sb.append (",flags=0x");
sb.append (Integer.toHexString (this.flags));
sb.append (")");
return sb.toString ();
});
c$.$Notification$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.app, "Notification$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (parcel) {
return  new android.app.Notification (parcel);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"DEFAULT_ALL", -1,
"DEFAULT_SOUND", 1,
"DEFAULT_VIBRATE", 2,
"DEFAULT_LIGHTS", 4,
"STREAM_DEFAULT", -1,
"FLAG_SHOW_LIGHTS", 0x00000001,
"FLAG_ONGOING_EVENT", 0x00000002,
"FLAG_INSISTENT", 0x00000004,
"FLAG_ONLY_ALERT_ONCE", 0x00000008,
"FLAG_AUTO_CANCEL", 0x00000010,
"FLAG_NO_CLEAR", 0x00000020,
"FLAG_FOREGROUND_SERVICE", 0x00000040);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.app.Notification$1") ? 0 : android.app.Notification.$Notification$1$ ()), Clazz.innerTypeInstance (android.app.Notification$1, this, null));
});
