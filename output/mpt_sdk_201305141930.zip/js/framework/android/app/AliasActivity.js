﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.app.Activity"], "android.app.AliasActivity", ["android.content.Intent", "com.android.internal.util.XmlUtils", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.ALIAS_META_DATA = "android.app.alias";
Clazz.instantialize (this, arguments);
}, android.app, "AliasActivity", android.app.Activity);
Clazz.defineMethod (c$, "onCreate", 
function (savedInstanceState) {
Clazz.superCall (this, android.app.AliasActivity, "onCreate", [savedInstanceState]);
var parser = null;
try {
var ai = this.getPackageManager ().getActivityInfo (this.getComponentName (), 128);
parser = ai.loadXmlMetaData (this.getPackageManager (), "android.app.alias");
if (parser == null) {
throw  new RuntimeException ("Alias requires a meta-data field android.app.alias");
}var intent = this.parseAlias (parser);
if (intent == null) {
throw  new RuntimeException ("No <intent> tag found in alias description");
}this.startActivity (intent);
this.finish ();
} catch (e$$) {
if (Clazz.instanceOf (e$$, android.content.pm.PackageManager.NameNotFoundException)) {
var e = e$$;
{
throw  new RuntimeException ("Error parsing alias", e);
}
} else if (Clazz.instanceOf (e$$, org.xmlpull.v1.XmlPullParserException)) {
var e = e$$;
{
throw  new RuntimeException ("Error parsing alias", e);
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var e = e$$;
{
throw  new RuntimeException ("Error parsing alias", e);
}
} else {
throw e$$;
}
} finally {
if (parser != null) parser.close ();
}
}, "android.os.Bundle");
Clazz.defineMethod (c$, "parseAlias", 
($fz = function (parser) {
var attrs = parser;
var intent = null;
var type;
while ((type = parser.next ()) != 1 && type != 2) {
}
var nodeName = parser.getName ();
if (!"alias".equals (nodeName)) {
throw  new RuntimeException ("Alias meta-data must start with <alias> tag; found" + nodeName + " at " + parser.getPositionDescription ());
}var outerDepth = parser.getDepth ();
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type == 3 || type == 4) {
continue ;}nodeName = parser.getName ();
if ("intent".equals (nodeName)) {
var gotIntent = android.content.Intent.parseIntent (this.getResources (), parser, attrs);
if (intent == null) intent = gotIntent;
} else {
com.android.internal.util.XmlUtils.skipCurrentTag (parser);
}}
return intent;
}, $fz.isPrivate = true, $fz), "org.xmlpull.v1.XmlPullParser");
});
