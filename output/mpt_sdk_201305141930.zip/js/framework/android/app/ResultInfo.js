﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.app.ResultInfo", ["android.content.Intent"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mResultWho = null;
this.mRequestCode = 0;
this.mResultCode = 0;
this.mData = null;
Clazz.instantialize (this, arguments);
}, android.app, "ResultInfo", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function (resultWho, requestCode, resultCode, data) {
this.mResultWho = resultWho;
this.mRequestCode = requestCode;
this.mResultCode = resultCode;
this.mData = data;
}, "~S,~N,~N,android.content.Intent");
Clazz.overrideMethod (c$, "toString", 
function () {
return "ResultInfo{who=" + this.mResultWho + ", request=" + this.mRequestCode + ", result=" + this.mResultCode + ", data=" + this.mData + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (out, flags) {
out.writeString (this.mResultWho);
out.writeInt (this.mRequestCode);
out.writeInt (this.mResultCode);
if (this.mData != null) {
out.writeInt (1);
this.mData.writeToParcel (out, 0);
} else {
out.writeInt (0);
}}, "android.os.Parcel,~N");
Clazz.makeConstructor (c$, 
function ($in) {
this.mResultWho = $in.readString ();
this.mRequestCode = $in.readInt ();
this.mResultCode = $in.readInt ();
if ($in.readInt () != 0) {
this.mData = android.content.Intent.CREATOR.createFromParcel ($in);
} else {
this.mData = null;
}}, "android.os.Parcel");
c$.$ResultInfo$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.app, "ResultInfo$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
return  new android.app.ResultInfo ($in);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.app.ResultInfo$1") ? 0 : android.app.ResultInfo.$ResultInfo$1$ ()), Clazz.innerTypeInstance (android.app.ResultInfo$1, this, null));
});
