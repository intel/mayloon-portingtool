﻿Clazz.declarePackage ("android.app");
c$ = Clazz.decorateAsClass (function () {
this.alarm_timer = 0;
Clazz.instantialize (this, arguments);
}, android.app, "AlarmManager");
Clazz.defineMethod (c$, "set", 
function (type, triggerAtTime, operation) {
System.out.println ("triggerAtTime:" + triggerAtTime);
var delayMillis = triggerAtTime - System.currentTimeMillis ();
System.out.println ("delayMillis:" + delayMillis);
alarm_timer=window.setTimeout((function(operation) {
return function() {
window.log("timeout: alarm");
operation.send();
};
})(operation), delayMillis);
}, "~N,~N,android.app.PendingIntent");
Clazz.defineMethod (c$, "cancel", 
function (operation) {
clearTimeout(alarm_timer);
}, "android.app.PendingIntent");
Clazz.defineMethod (c$, "setTime", 
function (millis) {
console.log("Missing method: setTime");
}, "~N");
Clazz.defineMethod (c$, "setTimeZone", 
function (timeZone) {
console.log("Missing method: setTimeZone");
}, "~S");
Clazz.defineStatics (c$,
"RTC_WAKEUP", 0);
