﻿Clazz.declarePackage ("android.app");
Clazz.load (null, "android.app.ConnectionRecord", ["java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.binding = null;
this.conn = null;
this.flags = 0;
this.clientLabel = 0;
this.stringName = null;
Clazz.instantialize (this, arguments);
}, android.app, "ConnectionRecord");
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
pw.println (prefix + "binding=" + this.binding);
pw.println (prefix + "conn=" + " flags=0x" + Integer.toHexString (this.flags));
}, "java.io.PrintWriter,~S");
Clazz.makeConstructor (c$, 
function (_binding, _conn, _flags, _clientLabel) {
this.binding = _binding;
this.conn = _conn;
this.flags = _flags;
this.clientLabel = _clientLabel;
}, "android.app.AppBindRecord,android.content.ServiceConnection,~N,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.stringName != null) {
return this.stringName;
}var sb =  new StringBuilder (128);
sb.append ("ConnectionRecord{");
sb.append (' ');
sb.append (this.binding.service.shortName);
sb.append (":@");
sb.append ('}');
return this.stringName = sb.toString ();
});
});
