﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.app.ResultInfo"], "android.app.ActivityResult", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mFrom = null;
Clazz.instantialize (this, arguments);
}, android.app, "ActivityResult", android.app.ResultInfo);
Clazz.makeConstructor (c$, 
function (from, resultWho, requestCode, resultCode, data) {
Clazz.superConstructor (this, android.app.ActivityResult, [resultWho, requestCode, resultCode, data]);
this.mFrom = from;
}, "android.app.ActivityRecord,~S,~N,~N,android.content.Intent");
});
