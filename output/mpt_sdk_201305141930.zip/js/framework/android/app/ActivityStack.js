﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.Handler", "java.util.ArrayList"], "android.app.ActivityStack", ["android.app.ActivityRecord", "$.TaskRecord", "android.content.ComponentName", "$.Context", "$.Intent", "android.util.Log", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mService = null;
this.mMainStack = false;
this.mContext = null;
this.mHistory = null;
this.mLRUActivities = null;
this.mWaitingVisibleActivities = null;
this.mStoppingActivities = null;
this.mNoAnimActivities = null;
this.mFinishingActivities = null;
this.mPausingActivity = null;
this.mLastPausedActivity = null;
this.mResumedActivity = null;
this.mLastStartedActivity = null;
this.mConfigWillChange = false;
this.mUserLeaving = false;
this.mInitialStartTime = 0;
this.mHandler = null;
Clazz.instantialize (this, arguments);
}, android.app, "ActivityStack");
Clazz.prepareFields (c$, function () {
this.mHistory =  new java.util.ArrayList ();
this.mLRUActivities =  new java.util.ArrayList ();
this.mWaitingVisibleActivities =  new java.util.ArrayList ();
this.mStoppingActivities =  new java.util.ArrayList ();
this.mNoAnimActivities =  new java.util.ArrayList ();
this.mFinishingActivities =  new java.util.ArrayList ();
this.mHandler = ((Clazz.isClassDefined ("android.app.ActivityStack$1") ? 0 : android.app.ActivityStack.$ActivityStack$1$ ()), Clazz.innerTypeInstance (android.app.ActivityStack$1, this, null));
});
Clazz.makeConstructor (c$, 
function (service, context, mainStack) {
this.mService = service;
this.mContext = context;
this.mMainStack = mainStack;
}, "android.app.ActivityManager,android.content.Context,~B");
Clazz.defineMethod (c$, "topRunningActivityLocked", 
function (notTop) {
var i = this.mHistory.size () - 1;
while (i >= 0) {
var r = this.mHistory.get (i);
if (!r.finishing && r !== notTop) {
return r;
}i--;
}
return null;
}, "android.app.ActivityRecord");
Clazz.defineMethod (c$, "topRunningNonDelayedActivityLocked", 
function (notTop) {
var i = this.mHistory.size () - 1;
while (i >= 0) {
var r = this.mHistory.get (i);
if (!r.finishing && !r.delayedResume && r !== notTop) {
return r;
}i--;
}
return null;
}, "android.app.ActivityRecord");
Clazz.defineMethod (c$, "topRunningActivityLocked", 
function (token, taskId) {
var i = this.mHistory.size () - 1;
while (i >= 0) {
var r = this.mHistory.get (i);
if (!r.finishing && (token !== r) && (taskId != r.task.taskId)) {
return r;
}i--;
}
return null;
}, "android.os.IBinder,~N");
Clazz.defineMethod (c$, "indexOfTokenLocked", 
function (token) {
var count = this.mHistory.size ();
var index = -1;
for (var i = count - 1; i >= 0; i--) {
var o = this.mHistory.get (i);
if (o === token) {
index = i;
break;
}}
return index;
}, "android.os.IBinder");
Clazz.defineMethod (c$, "findTaskLocked", 
($fz = function (intent, info) {
var cls = intent.getComponent ();
if (info.targetActivity != null) {
cls =  new android.content.ComponentName (info.packageName, info.targetActivity);
}var cp = null;
var N = this.mHistory.size ();
for (var i = (N - 1); i >= 0; i--) {
var r = this.mHistory.get (i);
if (!r.finishing && r.task !== cp && r.launchMode != 3) {
cp = r.task;
if (r.task.affinity != null) {
if (r.task.affinity.equals (info.taskAffinity)) {
return r;
}} else if (r.task.intent != null && r.task.intent.getComponent ().equals (cls)) {
return r;
} else if (r.task.affinityIntent != null && r.task.affinityIntent.getComponent ().equals (cls)) {
return r;
}}}
return null;
}, $fz.isPrivate = true, $fz), "android.content.Intent,android.content.pm.ActivityInfo");
Clazz.defineMethod (c$, "findActivityLocked", 
($fz = function (intent, info) {
var cls = intent.getComponent ();
if (info.targetActivity != null) {
cls =  new android.content.ComponentName (info.packageName, info.targetActivity);
}var N = this.mHistory.size ();
for (var i = (N - 1); i >= 0; i--) {
var r = this.mHistory.get (i);
if (!r.finishing) {
if (r.intent.getComponent ().equals (cls)) {
return r;
}}}
return null;
}, $fz.isPrivate = true, $fz), "android.content.Intent,android.content.pm.ActivityInfo");
Clazz.defineMethod (c$, "realStartActivityLocked", 
function (r, app, andResume, checkConfig) {
r.app = app;
var idx = app.activities.indexOf (r);
if (idx < 0) {
app.activities.add (r);
}if (app.thread == null) {
return false;
}var results = null;
var newIntents = null;
if (andResume) {
results = r.results;
newIntents = r.newIntents;
}app.thread.scheduleLaunchActivity ( new android.content.Intent (r.intent), r, 0, r.info, r.icicle, results, newIntents, !andResume, false);
if (andResume) {
r.state = 1;
r.icicle = null;
r.haveState = false;
r.stopped = false;
this.mResumedActivity = r;
this.completeResumeLocked (r);
} else {
r.state = 5;
r.stopped = true;
}return true;
}, "android.app.ActivityRecord,android.app.ProcessRecord,~B,~B");
Clazz.defineMethod (c$, "startSpecificActivityLocked", 
($fz = function (r, andResume, checkConfig) {
var app = this.mService.getProcessRecordLocked (r.processName);
if (app != null && app.thread != null) {
this.realStartActivityLocked (r, app, andResume, checkConfig);
return ;
}this.mService.startProcessLocked (r.processName, r.info.applicationInfo, true, 0, "activity", r.intent.getComponent (), false);
}, $fz.isPrivate = true, $fz), "android.app.ActivityRecord,~B,~B");
Clazz.defineMethod (c$, "startPausingLocked", 
($fz = function (userLeaving, uiSleeping) {
if (this.mPausingActivity != null) {
}var prev = this.mResumedActivity;
if (prev == null) {
this.resumeTopActivityLocked (null);
return ;
}this.mResumedActivity = null;
this.mPausingActivity = prev;
this.mLastPausedActivity = prev;
prev.state = 2;
if (prev.app != null && prev.app.thread != null) {
prev.app.thread.schedulePauseActivity (prev, prev.finishing, userLeaving, prev.configChangeFlags);
} else {
this.mPausingActivity = null;
this.mLastPausedActivity = null;
}if (this.mPausingActivity != null) {
if (uiSleeping == false) {
prev.pauseKeyDispatchingLocked ();
}} else {
this.resumeTopActivityLocked (null);
}}, $fz.isPrivate = true, $fz), "~B,~B");
Clazz.defineMethod (c$, "activityPaused", 
function (token, icicle, timeout) {
var r = null;
var index = this.indexOfTokenLocked (token);
if (index >= 0) {
r = this.mHistory.get (index);
if (!timeout) {
r.icicle = icicle;
r.haveState = true;
}if (this.mPausingActivity === r) {
r.state = 3;
this.completePauseLocked ();
} else {
android.util.Log.i ("ActivityStack>>>", "impossible here! mPausingActivity != r");
}}}, "android.os.IBinder,android.os.Bundle,~B");
Clazz.defineMethod (c$, "finishCurrentActivityLocked", 
($fz = function (r, mode) {
var index = this.indexOfTokenLocked (r);
if (index < 0) {
return null;
}return this.finishCurrentActivityLocked (r, index, mode);
}, $fz.isPrivate = true, $fz), "android.app.ActivityRecord,~N");
Clazz.defineMethod (c$, "completePauseLocked", 
($fz = function () {
var prev = this.mPausingActivity;
if (prev != null) {
if (prev.finishing) {
android.util.Log.i ("ActivityStack>>>", "prev.finishing is true...");
prev = this.finishCurrentActivityLocked (prev, 2);
} else if (prev.app != null) {
if (prev.waitingVisible) {
prev.waitingVisible = false;
this.mWaitingVisibleActivities.remove (prev);
}if (prev.configDestroy) {
android.util.Log.i ("ActivityStack>>>", "impossible here! prev.configDestroy is true");
} else {
this.mStoppingActivities.add (prev);
if (this.mStoppingActivities.size () > 3) {
android.util.Log.i ("ActivityStack>>>", "ActivityStack>>>To many pending stops, forcing idle");
}}} else {
android.util.Log.i ("ActivityStack>>>", "can come here?");
prev = null;
}this.mPausingActivity = null;
}this.resumeTopActivityLocked (prev);
if (prev != null) {
prev.resumeKeyDispatchingLocked ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "completeResumeLocked", 
($fz = function (next) {
next.idle = false;
next.results = null;
next.newIntents = null;
if (this.mMainStack) {
this.mService.setFocusedActivityLocked (next);
}next.resumeKeyDispatchingLocked ();
this.mNoAnimActivities.clear ();
}, $fz.isPrivate = true, $fz), "android.app.ActivityRecord");
Clazz.defineMethod (c$, "resumeTopActivityLocked", 
function (prev) {
var next = this.topRunningActivityLocked (null);
var userLeaving = this.mUserLeaving;
this.mUserLeaving = false;
if (next == null) {
if (this.mMainStack) {
return this.mService.startHomeActivityLocked ();
}} else {
}next.delayedResume = false;
if (this.mResumedActivity === next && next.state == 1) {
this.mNoAnimActivities.clear ();
return false;
}this.mStoppingActivities.remove (next);
this.mWaitingVisibleActivities.remove (next);
if (this.mPausingActivity != null) {
return false;
}if (this.mResumedActivity != null) {
this.startPausingLocked (userLeaving, false);
return true;
}if (prev != null && prev !== next) {
if (!prev.waitingVisible && next != null && !next.nowVisible) {
prev.waitingVisible = true;
this.mWaitingVisibleActivities.add (prev);
} else {
if (prev.finishing) {
} else {
}}}if (prev != null) {
if (prev.finishing) {
if (this.mNoAnimActivities.contains (prev)) {
} else {
}} else {
if (this.mNoAnimActivities.contains (next)) {
} else {
}}} else if (this.mHistory.size () > 1) {
if (this.mNoAnimActivities.contains (next)) {
} else {
}}if (next.app != null && next.app.thread != null) {
next.state = 1;
this.mResumedActivity = next;
var a = next.results;
if (a != null) {
var N = a.size ();
if (!next.finishing && N > 0) {
next.app.thread.scheduleSendResult (next, a);
}}if (next.newIntents != null) {
}next.app.thread.scheduleResumeActivity (next, false);
next.visible = true;
this.completeResumeLocked (next);
next.icicle = null;
next.haveState = false;
next.stopped = false;
} else {
if (!next.hasBeenLaunched) {
next.hasBeenLaunched = true;
} else {
}this.startSpecificActivityLocked (next, true, true);
}return true;
}, "android.app.ActivityRecord");
Clazz.defineMethod (c$, "startActivityLocked", 
($fz = function (r, newTask, doResume) {
var NH = this.mHistory.size ();
var addPos = -1;
if (!newTask) {
var startIt = true;
for (var i = NH - 1; i >= 0; i--) {
var p = this.mHistory.get (i);
if (p.finishing) {
continue ;}if (p.task === r.task) {
addPos = i + 1;
if (!startIt) {
this.mHistory.add (addPos, r);
r.info.zIndex = 3 * (this.mHistory.size () - 1);
r.inHistory = true;
r.task.numActivities++;
return ;
}break;
}if (p.fullscreen) {
startIt = false;
}}
}if (addPos < 0) {
addPos = NH;
}if (addPos < NH) {
this.mUserLeaving = false;
}this.mHistory.add (addPos, r);
r.info.zIndex = 3 * (this.mHistory.size () - 1);
r.inHistory = true;
r.frontOfTask = newTask;
r.task.numActivities++;
if (NH > 0) {
android.util.Log.i ("ActivityStack>>>", "NH > 0, NH: " + NH);
} else {
}if (doResume) {
this.resumeTopActivityLocked (null);
}}, $fz.isPrivate = true, $fz), "android.app.ActivityRecord,~B,~B");
Clazz.defineMethod (c$, "startActivityLocked", 
function (caller, intent, resolvedType, grantedUriPermissions, grantedMode, aInfo, resultTo, resultWho, requestCode, callingPid, callingUid, onlyIfNeeded, componentSpecified) {
var err = 0;
var callerApp = null;
if (caller != null) {
callerApp = this.mService.getRecordForAppLocked (caller);
if (callerApp != null) {
} else {
err = -4;
}}var sourceRecord = null;
var resultRecord = null;
if (resultTo != null) {
var index = this.indexOfTokenLocked (resultTo);
android.util.Log.i ("ActivityStack>>>", "ActivityStack>>>" + "Sending result to " + (resultTo).info.name + " (index " + index + ")");
if (index >= 0) {
sourceRecord = this.mHistory.get (index);
if (requestCode >= 0 && !sourceRecord.finishing) {
resultRecord = sourceRecord;
}}}var launchFlags = intent.getFlags ();
if ((launchFlags & 33554432) != 0 && sourceRecord != null) {
android.util.Log.i ("ActivityStack>>>", "impossible here! Intent.FLAG_ACTIVITY_FORWARD_RESULT can't be set");
if (requestCode >= 0) {
return -3;
}resultRecord = sourceRecord.resultTo;
resultWho = sourceRecord.resultWho;
requestCode = sourceRecord.requestCode;
sourceRecord.resultTo = null;
if (resultRecord != null) {
resultRecord.removeResultsLocked (sourceRecord, resultWho, requestCode);
}}if (err == 0 && intent.getComponent () == null) {
err = -1;
}if (err == 0 && aInfo == null) {
err = -2;
}if (err != 0) {
return err;
}var r =  new android.app.ActivityRecord (this.mService, this, callerApp, callingUid, intent, resolvedType, aInfo, null, resultRecord, resultWho, requestCode, componentSpecified);
return this.startActivityUncheckedLocked (r, sourceRecord, grantedUriPermissions, grantedMode, onlyIfNeeded, true);
}, "android.app.IApplicationThread,android.content.Intent,~S,~A,~N,android.content.pm.ActivityInfo,android.os.IBinder,~S,~N,~N,~N,~B,~B");
Clazz.defineMethod (c$, "startActivityUncheckedLocked", 
function (r, sourceRecord, grantedUriPermissions, grantedMode, onlyIfNeeded, doResume) {
var intent = r.intent;
var launchFlags = intent.getFlags ();
this.mUserLeaving = (launchFlags & 262144) == 0;
if (!doResume) {
r.delayedResume = true;
}var notTop = (launchFlags & 16777216) != 0 ? r : null;
if (onlyIfNeeded) {
var checkedCaller = sourceRecord;
if (checkedCaller == null) {
checkedCaller = this.topRunningNonDelayedActivityLocked (notTop);
}if (!checkedCaller.realActivity.equals (r.realActivity)) {
onlyIfNeeded = false;
}}if (sourceRecord == null) {
if ((launchFlags & 268435456) == 0) {
launchFlags |= 268435456;
}} else if (sourceRecord.launchMode == 3) {
launchFlags |= 268435456;
} else if (r.launchMode == 3 || r.launchMode == 2) {
launchFlags |= 268435456;
}if (r.resultTo != null && (launchFlags & 268435456) != 0) {
r.resultTo = null;
}var addingToTask = false;
if (((launchFlags & 268435456) != 0 && (launchFlags & 134217728) == 0) || r.launchMode == 2 || r.launchMode == 3) {
if (r.resultTo == null) {
var taskTop = r.launchMode != 3 ? this.findTaskLocked (intent, r.info) : this.findActivityLocked (intent, r.info);
if (taskTop != null) {
if (taskTop.task.intent == null) {
taskTop.task.setIntent (intent, r.info);
}var curTop = this.topRunningNonDelayedActivityLocked (notTop);
if (curTop.task !== taskTop.task) {
r.intent.addFlags (4194304);
var callerAtFront = sourceRecord == null || curTop.task === sourceRecord.task;
if (callerAtFront) {
this.moveTaskToFrontLocked (taskTop.task, r);
}}if ((launchFlags & 2097152) != 0) {
taskTop = this.resetTaskIfNeededLocked (taskTop, r);
}if (onlyIfNeeded) {
if (doResume) {
this.resumeTopActivityLocked (null);
}return 1;
}if ((launchFlags & 67108864) != 0 || r.launchMode == 2 || r.launchMode == 3) {
var top = this.performClearTaskLocked (taskTop.task.taskId, r, launchFlags, true);
if (top != null) {
if (top.frontOfTask) {
top.task.setIntent (r.intent, r.info);
}} else {
addingToTask = true;
sourceRecord = taskTop;
}} else if (r.realActivity.equals (taskTop.task.realActivity)) {
if ((launchFlags & 536870912) != 0 && taskTop.realActivity.equals (r.realActivity)) {
if (taskTop.frontOfTask) {
taskTop.task.setIntent (r.intent, r.info);
}} else if (!r.intent.filterEquals (taskTop.task.intent)) {
addingToTask = true;
sourceRecord = taskTop;
}} else if ((launchFlags & 2097152) == 0) {
addingToTask = true;
sourceRecord = taskTop;
} else if (!taskTop.task.rootWasReset) {
taskTop.task.setIntent (r.intent, r.info);
}if (!addingToTask) {
if (doResume) {
this.resumeTopActivityLocked (null);
}return 2;
}}}}if (r.packageName != null) {
var top = this.topRunningNonDelayedActivityLocked (notTop);
if (top != null && r.resultTo == null) {
if (top.realActivity.equals (r.realActivity)) {
}}} else {
return -2;
}var newTask = false;
if (r.resultTo == null && addingToTask == false && (launchFlags & 268435456) != 0) {
this.mService.mCurTask++;
if (this.mService.mCurTask <= 0) {
this.mService.mCurTask = 1;
}r.task =  new android.app.TaskRecord (this.mService.mCurTask, r.info, intent, (r.info.flags & 4) != 0);
newTask = true;
if (this.mMainStack) {
this.mService.addRecentTaskLocked (r.task);
}} else if (sourceRecord != null) {
if (!addingToTask && (launchFlags & 67108864) != 0) {
var top = this.performClearTaskLocked (sourceRecord.task.taskId, r, launchFlags, true);
if (top != null) {
if (doResume) {
this.resumeTopActivityLocked (null);
}return 3;
}} else if (!addingToTask && (launchFlags & 131072) != 0) {
var where = this.findActivityInHistoryLocked (r, sourceRecord.task.taskId);
if (where >= 0) {
var top = this.moveActivityToFrontLocked (where);
if (doResume) {
this.resumeTopActivityLocked (null);
}return 3;
}}r.task = sourceRecord.task;
} else {
var N = this.mHistory.size ();
var prev = N > 0 ? this.mHistory.get (N - 1) : null;
r.task = prev != null ? prev.task :  new android.app.TaskRecord (this.mService.mCurTask, r.info, intent, (r.info.flags & 4) != 0);
}this.startActivityLocked (r, newTask, doResume);
return 0;
}, "android.app.ActivityRecord,android.app.ActivityRecord,~A,~N,~B,~B");
Clazz.defineMethod (c$, "moveActivityToFrontLocked", 
($fz = function (where) {
var newTop = this.mHistory.remove (where);
var top = this.mHistory.size ();
var oldTop = this.mHistory.get (top - 1);
this.mHistory.add (top, newTop);
oldTop.frontOfTask = false;
newTop.frontOfTask = true;
return newTop;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "findActivityInHistoryLocked", 
($fz = function (r, task) {
var i = this.mHistory.size ();
while (i > 0) {
i--;
var candidate = this.mHistory.get (i);
if (candidate.task.taskId != task) {
break;
}if (candidate.realActivity.equals (r.realActivity)) {
return i;
}}
return -1;
}, $fz.isPrivate = true, $fz), "android.app.ActivityRecord,~N");
Clazz.defineMethod (c$, "performClearTaskLocked", 
($fz = function (taskId, newR, launchFlags, doClear) {
var i = this.mHistory.size ();
while (i > 0) {
i--;
var r = this.mHistory.get (i);
if (r.task.taskId == taskId) {
i++;
break;
}}
while (i > 0) {
i--;
var r = this.mHistory.get (i);
if (r.finishing) {
continue ;}if (r.task.taskId != taskId) {
return null;
}if (r.realActivity.equals (newR.realActivity)) {
var ret = r;
if (doClear) {
while (i < (this.mHistory.size () - 1)) {
i++;
r = this.mHistory.get (i);
if (r.finishing) {
continue ;}if (this.finishActivityLocked (r, i, 0, null, "clear")) {
i--;
}}
}if (ret.launchMode == 0 && (launchFlags & 536870912) == 0) {
if (!ret.finishing) {
var index = this.indexOfTokenLocked (ret);
if (index >= 0) {
this.finishActivityLocked (ret, index, 0, null, "clear");
}return null;
}}return ret;
}}
return null;
}, $fz.isPrivate = true, $fz), "~N,android.app.ActivityRecord,~N,~B");
Clazz.defineMethod (c$, "resetTaskIfNeededLocked", 
($fz = function (taskTop, newActivity) {
var forceReset = (newActivity.info.flags & 4) != 0;
if (taskTop.task.getInactiveDuration () > 1800000) {
if ((newActivity.info.flags & 8) == 0) {
forceReset = true;
}}var task = taskTop.task;
var target = null;
var targetI = 0;
var taskTopI = -1;
var replyChainEnd = -1;
var lastReparentPos = -1;
for (var i = this.mHistory.size () - 1; i >= -1; i--) {
var below = i >= 0 ? this.mHistory.get (i) : null;
if (below != null && below.finishing) {
continue ;}if (target == null) {
target = below;
targetI = i;
replyChainEnd = -1;
continue ;}var flags = target.info.flags;
var finishOnTaskLaunch = (flags & 2) != 0;
var allowTaskReparenting = (flags & 64) != 0;
if (target.task === task) {
if (taskTopI < 0) {
taskTopI = targetI;
}if (below != null && below.task === task) {
var clearWhenTaskReset = (target.intent.getFlags () & 524288) != 0;
if (!finishOnTaskLaunch && !clearWhenTaskReset && target.resultTo != null) {
if (replyChainEnd < 0) {
replyChainEnd = targetI;
}} else if (!finishOnTaskLaunch && !clearWhenTaskReset && allowTaskReparenting && target.taskAffinity != null && !target.taskAffinity.equals (task.affinity)) {
var p = this.mHistory.get (0);
if (target.taskAffinity != null && target.taskAffinity.equals (p.task.affinity)) {
target.task = p.task;
} else {
this.mService.mCurTask++;
if (this.mService.mCurTask <= 0) {
this.mService.mCurTask = 1;
}target.task =  new android.app.TaskRecord (this.mService.mCurTask, target.info, null, (target.info.flags & 4) != 0);
target.task.affinityIntent = target.intent;
}if (replyChainEnd < 0) {
replyChainEnd = targetI;
}var dstPos = 0;
for (var srcPos = targetI; srcPos <= replyChainEnd; srcPos++) {
p = this.mHistory.get (srcPos);
if (p.finishing) {
continue ;}task.numActivities--;
p.task = target.task;
target.task.numActivities++;
this.mHistory.remove (srcPos);
this.mHistory.add (dstPos, p);
dstPos++;
i++;
}
if (taskTop === p) {
taskTop = below;
}if (taskTopI == replyChainEnd) {
taskTopI = -1;
}replyChainEnd = -1;
if (this.mMainStack) {
this.mService.addRecentTaskLocked (target.task);
}} else if (forceReset || finishOnTaskLaunch || clearWhenTaskReset) {
if (clearWhenTaskReset) {
replyChainEnd = targetI + 1;
while (replyChainEnd < this.mHistory.size () && (this.mHistory.get (replyChainEnd)).task === task) {
replyChainEnd++;
}
replyChainEnd--;
} else if (replyChainEnd < 0) {
replyChainEnd = targetI;
}var p = null;
for (var srcPos = targetI; srcPos <= replyChainEnd; srcPos++) {
p = this.mHistory.get (srcPos);
if (p.finishing) {
continue ;}if (this.finishActivityLocked (p, srcPos, 0, null, "reset")) {
replyChainEnd--;
srcPos--;
}}
if (taskTop === p) {
taskTop = below;
}if (taskTopI == replyChainEnd) {
taskTopI = -1;
}replyChainEnd = -1;
} else {
replyChainEnd = -1;
}} else {
replyChainEnd = -1;
}} else if (target.resultTo != null) {
if (replyChainEnd < 0) {
replyChainEnd = targetI;
}} else if (taskTopI >= 0 && allowTaskReparenting && task.affinity != null && task.affinity.equals (target.taskAffinity)) {
if (forceReset || finishOnTaskLaunch) {
if (replyChainEnd < 0) {
replyChainEnd = targetI;
}var p = null;
for (var srcPos = targetI; srcPos <= replyChainEnd; srcPos++) {
p = this.mHistory.get (srcPos);
if (p.finishing) {
continue ;}if (this.finishActivityLocked (p, srcPos, 0, null, "reset")) {
taskTopI--;
lastReparentPos--;
replyChainEnd--;
srcPos--;
}}
replyChainEnd = -1;
} else {
if (replyChainEnd < 0) {
replyChainEnd = targetI;
}for (var srcPos = replyChainEnd; srcPos >= targetI; srcPos--) {
var p = this.mHistory.get (srcPos);
if (p.finishing) {
continue ;}if (lastReparentPos < 0) {
lastReparentPos = taskTopI;
taskTop = p;
} else {
lastReparentPos--;
}this.mHistory.remove (srcPos);
p.task.numActivities--;
p.task = task;
this.mHistory.add (lastReparentPos, p);
task.numActivities++;
}
replyChainEnd = -1;
if (target.info.launchMode == 1) {
for (var j = lastReparentPos - 1; j >= 0; j--) {
var p = this.mHistory.get (j);
if (p.finishing) {
continue ;}if (p.intent.getComponent ().equals (target.intent.getComponent ())) {
if (this.finishActivityLocked (p, j, 0, null, "replace")) {
taskTopI--;
lastReparentPos--;
}}}
}}}target = below;
targetI = i;
}
return taskTop;
}, $fz.isPrivate = true, $fz), "android.app.ActivityRecord,android.app.ActivityRecord");
Clazz.defineMethod (c$, "moveTaskToFrontLocked", 
function (tr, reason) {
var task = tr.taskId;
var top = this.mHistory.size () - 1;
if (top < 0 || (this.mHistory.get (top)).task.taskId == task) {
return ;
}var moved =  new java.util.ArrayList ();
top = this.mHistory.size () - 1;
var pos = top;
while (pos >= 0) {
var r = this.mHistory.get (pos);
var first = true;
if (r.task.taskId == task) {
this.mHistory.remove (pos);
this.mHistory.add (top, r);
moved.add (0, r);
top--;
if (first && this.mMainStack) {
this.mService.addRecentTaskLocked (r.task);
first = false;
}}pos--;
}
if (reason != null && (reason.intent.getFlags () & 65536) != 0) {
var r = this.topRunningActivityLocked (null);
if (r != null) {
this.mNoAnimActivities.add (r);
}} else {
}this.finishTaskMoveLocked (task);
}, "android.app.TaskRecord,android.app.ActivityRecord");
Clazz.defineMethod (c$, "finishTaskMoveLocked", 
($fz = function (task) {
this.resumeTopActivityLocked (null);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "startActivityMayWait", 
function (caller, intent, resolvedType, grantedUriPermissions, grantedMode, resultTo, resultWho, requestCode, onlyIfNeeded, debug) {
if (intent != null && intent.hasFileDescriptors ()) {
throw  new IllegalArgumentException ("File descriptors passed in Intent");
}android.util.Log.i ("ActivityStack>>>", " startActivityMayWait");
var componentSpecified = intent.getComponent () != null;
intent =  new android.content.Intent (intent);
var aInfo;
var rInfo = android.content.Context.getSystemContext ().getPackageManager ().resolveIntent (intent, resolvedType, 66560);
aInfo = rInfo != null ? rInfo.activityInfo : null;
android.util.Log.i ("ActivityStack>>>", " startActivityMayWait2");
if (aInfo != null) {
intent.setComponent ( new android.content.ComponentName (aInfo.applicationInfo.packageName, aInfo.name));
android.util.Log.i ("ActivityStack>>>", "aInfo.applicationInfo.packageName: " + aInfo.applicationInfo.packageName + ", aInfo.name: " + aInfo.name);
android.util.Log.i ("ActivityStack>>>", "intent.getComponent: " + intent.getComponent ().flattenToString ());
}var res = this.startActivityLocked (caller, intent, resolvedType, grantedUriPermissions, grantedMode, aInfo, resultTo, resultWho, requestCode, 0, 0, onlyIfNeeded, componentSpecified);
return res;
}, "android.app.IApplicationThread,android.content.Intent,~S,~A,~N,android.os.IBinder,~S,~N,~B,~B");
Clazz.defineMethod (c$, "requestFinishActivityLocked", 
function (token, resultCode, resultData, reason) {
var index = this.indexOfTokenLocked (token);
if (index < 0) {
return false;
}var r = this.mHistory.get (index);
var lastActivity = true;
for (var i = this.mHistory.size () - 1; i >= 0; i--) {
var p = this.mHistory.get (i);
if (!p.finishing && p !== r) {
lastActivity = false;
break;
}}
if (lastActivity) {
if (r.intent.hasCategory ("android.intent.category.HOME")) {
return false;
}}this.finishActivityLocked (r, index, resultCode, resultData, reason);
return true;
}, "android.os.IBinder,~N,android.content.Intent,~S");
Clazz.defineMethod (c$, "finishActivityLocked", 
function (r, index, resultCode, resultData, reason) {
if (r.finishing) {
return false;
}r.finishing = true;
r.task.numActivities--;
if (index < (this.mHistory.size () - 1)) {
var next = this.mHistory.get (index + 1);
if (next.task === r.task) {
if (r.frontOfTask) {
next.frontOfTask = true;
}if ((r.intent.getFlags () & 524288) != 0) {
next.intent.addFlags (524288);
}}}r.pauseKeyDispatchingLocked ();
if (this.mMainStack) {
if (this.mService.mFocusedActivity === r) {
this.mService.setFocusedActivityLocked (this.topRunningActivityLocked (null));
}}var resultTo = r.resultTo;
if (resultTo != null) {
resultTo.addResultLocked (r, r.resultWho, r.requestCode, resultCode, resultData);
r.resultTo = null;
}r.results = null;
r.newIntents = null;
r.icicle = null;
if (this.mResumedActivity === r) {
if (this.mPausingActivity == null) {
android.util.Log.i ("ActivityStack>>>", "Finish needs to pause: " + r.info.name);
this.startPausingLocked (false, false);
android.util.Log.i ("ActivityStack>>>", "Finish not pausing: " + r.info.name);
return this.finishCurrentActivityLocked (r, index, 0) == null;
}} else if (r.state != 2) {
android.util.Log.i ("ActivityStack>>>", "impossible here");
android.util.Log.i ("ActivityStack>>>", "Finish not pausing: " + r.info.name);
if (r.state == 3) {
return this.finishCurrentActivityLocked (r, index, 0) == null;
}return this.finishCurrentActivityLocked (r, index, 1) == null;
} else {
android.util.Log.i ("ActivityStack>>>", "Finish waiting for pause of: " + r.info.name);
}android.util.Log.i ("ActivityStack>>>", "finishActivityLocked Over");
return false;
}, "android.app.ActivityRecord,~N,~N,android.content.Intent,~S");
Clazz.defineMethod (c$, "finishCurrentActivityLocked", 
($fz = function (r, index, mode) {
if (mode == 2 && r.nowVisible) {
if (!this.mStoppingActivities.contains (r)) {
this.mStoppingActivities.add (r);
if (this.mStoppingActivities.size () > 3) {
}}r.state = 4;
return r;
}this.mStoppingActivities.remove (r);
this.mWaitingVisibleActivities.remove (r);
if (this.mResumedActivity === r) {
this.mResumedActivity = null;
}var prevState = r.state;
r.state = 6;
if (mode == 0 || prevState == 5 || prevState == 0) {
return this.destroyActivityLocked (r, true) ? null : r;
} else {
android.util.Log.i ("ActivityStack>>>", "state:" + prevState);
android.util.Log.i ("ActivityStack>>>", "Enqueueing pending finish: " + r.info.name);
this.mFinishingActivities.add (r);
this.resumeTopActivityLocked (null);
}return r;
}, $fz.isPrivate = true, $fz), "android.app.ActivityRecord,~N,~N");
Clazz.defineMethod (c$, "cleanUpActivityLocked", 
function (r, cleanServices) {
if (this.mResumedActivity === r) {
this.mResumedActivity = null;
}if (this.mService.mFocusedActivity === r) {
this.mService.mFocusedActivity = null;
}r.configDestroy = false;
r.frozenBeforeDestroy = false;
this.mFinishingActivities.remove (r);
this.mWaitingVisibleActivities.remove (r);
}, "android.app.ActivityRecord,~B");
Clazz.defineMethod (c$, "removeActivityFromHistoryLocked", 
($fz = function (r) {
if (r.state != 8) {
this.mHistory.remove (r);
r.inHistory = false;
r.state = 8;
}}, $fz.isPrivate = true, $fz), "android.app.ActivityRecord");
Clazz.defineMethod (c$, "destroyActivityLocked", 
function (r, removeFromApp) {
var removedFromHistory = false;
this.cleanUpActivityLocked (r, false);
var hadApp = r.app != null;
if (hadApp) {
if (removeFromApp) {
var idx = r.app.activities.indexOf (r);
if (idx >= 0) {
r.app.activities.remove (idx);
}}var skipDestroy = false;
r.app.thread.scheduleDestroyActivity (r, r.finishing, r.configChangeFlags);
r.app = null;
r.nowVisible = false;
if (r.finishing && !skipDestroy) {
r.state = 7;
} else {
r.state = 8;
}} else {
if (r.finishing) {
this.removeActivityFromHistoryLocked (r);
removedFromHistory = true;
} else {
r.state = 8;
}}r.configChangeFlags = 0;
if (!this.mLRUActivities.remove (r) && hadApp) {
android.util.Log.i ("ActivityStack>>>", "Activity " + r.info.name + " being finished, but not in LRU list");
}return removedFromHistory;
}, "android.app.ActivityRecord,~B");
Clazz.defineMethod (c$, "activityDestroyed", 
function (token) {
var index = this.indexOfTokenLocked (token);
if (index >= 0) {
var r = this.mHistory.get (index);
if (r.state == 7) {
this.removeActivityFromHistoryLocked (r);
}}}, "android.os.IBinder");
c$.$ActivityStack$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.app, "ActivityStack$1", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (msg) {
switch (msg.what) {
case 9:
{
}break;
case 10:
{
}break;
case 17:
{
}break;
case 11:
{
}break;
case 16:
{
}break;
case 19:
{
this.b$["android.app.ActivityStack"].resumeTopActivityLocked (null);
}break;
}
}, "android.os.Message");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.declareType (android.app.ActivityStack, "ActivityState");
Clazz.defineStatics (c$,
"INITIALIZING", 0,
"RESUMED", 1,
"PAUSING", 2,
"PAUSED", 3,
"STOPPING", 4,
"STOPPED", 5,
"FINISHING", 6,
"DESTROYING", 7,
"DESTROYED", 8);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "ActivityStack>>>",
"IDLE_TIMEOUT", 10000,
"PAUSE_TIMEOUT", 500,
"DESTROY_TIMEOUT", 10000,
"ACTIVITY_INACTIVE_RESET_TIME", 1800000,
"START_WARN_TIME", 5000,
"SHOW_APP_STARTING_PREVIEW", true,
"PAUSE_TIMEOUT_MSG", 9,
"IDLE_TIMEOUT_MSG", 10,
"IDLE_NOW_MSG", 11,
"LAUNCH_TIMEOUT_MSG", 16,
"DESTROY_TIMEOUT_MSG", 17,
"RESUME_TOP_ACTIVITY_MSG", 19,
"FINISH_IMMEDIATELY", 0,
"FINISH_AFTER_PAUSE", 1,
"FINISH_AFTER_VISIBLE", 2);
});
