﻿Clazz.declarePackage ("android.app");
Clazz.load (["java.util.HashMap"], "android.app.IntentBindRecord", ["java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.service = null;
this.intent = null;
this.apps = null;
this.binder = null;
this.requested = false;
this.received = false;
this.hasBound = false;
this.doRebind = false;
this.stringName = null;
Clazz.instantialize (this, arguments);
}, android.app, "IntentBindRecord");
Clazz.prepareFields (c$, function () {
this.apps =  new java.util.HashMap ();
});
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
pw.print (prefix);
pw.print ("service=");
pw.println (this.service);
this.dumpInService (pw, prefix);
}, "java.io.PrintWriter,~S");
Clazz.defineMethod (c$, "dumpInService", 
function (pw, prefix) {
pw.print (prefix);
pw.print ("intent={");
pw.print (this.intent.getIntent ().toShortString (true, false));
pw.println ('}');
pw.print (prefix);
pw.print ("binder=");
pw.println (this.binder);
pw.print (prefix);
pw.print ("requested=");
pw.print (this.requested);
pw.print (" received=");
pw.print (this.received);
pw.print (" hasBound=");
pw.print (this.hasBound);
pw.print (" doRebind=");
pw.println (this.doRebind);
if (this.apps.size () > 0) {
var it = this.apps.values ().iterator ();
while (it.hasNext ()) {
var a = it.next ();
pw.print (prefix);
pw.print ("* Client AppBindRecord{");
pw.print (Integer.toHexString (System.identityHashCode (a)));
pw.print (' ');
pw.print (a.client);
pw.println ('}');
a.dumpInIntentBind (pw, prefix + "  ");
}
}}, "java.io.PrintWriter,~S");
Clazz.makeConstructor (c$, 
function (_service, _intent) {
this.service = _service;
this.intent = _intent;
}, "android.app.ServiceRecord,android.content.Intent.FilterComparison");
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.stringName != null) {
return this.stringName;
}var sb =  new StringBuilder (128);
sb.append ("IntentBindRecord{");
sb.append (Integer.toHexString (System.identityHashCode (this)));
sb.append (' ');
sb.append (this.service.shortName);
sb.append (':');
if (this.intent != null) {
this.intent.getIntent ().toShortString (sb, false, false);
}sb.append ('}');
return this.stringName = sb.toString ();
});
});
