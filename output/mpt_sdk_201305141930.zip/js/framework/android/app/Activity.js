﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.view.ContextThemeWrapper", "$.KeyEvent", "$.View", "$.Window", "java.util.ArrayList"], "android.app.Activity", ["android.content.Context", "$.Intent", "android.text.Selection", "$.SpannableStringBuilder", "android.util.Log", "$.SparseArray", "android.view.MenuInflater", "$.WindowManager", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mWindow = null;
this.mDecor = null;
this.mParent = null;
this.mCalled = false;
this.mFinished = false;
this.mStartedActivity = false;
this.mIntent = null;
this.mWindowAdded = false;
this.mVisibleFromServer = false;
this.mVisibleFromClient = true;
this.mComponent = null;
this.mInstrumentation = null;
this.mResumed = false;
this.mStopped = false;
this.mMainThread = null;
this.mApplication = null;
this.mTitle = null;
this.mTitleColor = 0;
this.mTitleReady = false;
this.mDefaultKeyMode = 0;
this.mDefaultKeySsb = null;
this.mManagedDialogs = null;
this.mManagedCursors = null;
this.mToken = null;
this.mEmbeddedID = null;
this.$mWindowManager = null;
this.mZIndex = 0;
this.mResultCode = 0;
this.mResultData = null;
Clazz.instantialize (this, arguments);
}, android.app, "Activity", android.view.ContextThemeWrapper, [android.view.Window.Callback, android.view.KeyEvent.Callback, android.view.View.OnCreateContextMenuListener]);
Clazz.prepareFields (c$, function () {
this.mManagedCursors =  new java.util.ArrayList ();
});
c$.getInstanceCount = Clazz.defineMethod (c$, "getInstanceCount", 
function () {
return android.app.Activity.sInstanceCount;
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.app.Activity, []);
});
Clazz.defineMethod (c$, "isChild", 
function () {
return this.mParent != null;
});
Clazz.defineMethod (c$, "getParent", 
function () {
return this.mParent;
});
Clazz.defineMethod (c$, "getIntent", 
function () {
if (this.mIntent == null) {
this.mIntent =  new android.content.Intent ();
}return this.mIntent;
});
Clazz.defineMethod (c$, "setIntent", 
function (newIntent) {
this.mIntent = newIntent;
}, "android.content.Intent");
Clazz.defineMethod (c$, "onCreate", 
function (state) {
this.print ("onCreate");
this.mCalled = true;
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onCreateOptionsMenu", 
function (menu) {
if (this.mParent != null) {
return this.mParent.onCreateOptionsMenu (menu);
}return true;
}, "android.view.Menu");
Clazz.defineMethod (c$, "managedQuery", 
function (uri, projection, selection, sortOrder) {
var c = this.getContentResolver ().query (uri, projection, selection, null, sortOrder);
if (c != null) {
this.startManagingCursor (c);
}return c;
}, "android.net.Uri,~A,~S,~S");
Clazz.defineMethod (c$, "managedQuery", 
function (uri, projection, selection, selectionArgs, sortOrder) {
var c = this.getContentResolver ().query (uri, projection, selection, selectionArgs, sortOrder);
if (c != null) {
this.startManagingCursor (c);
}return c;
}, "android.net.Uri,~A,~S,~A,~S");
Clazz.defineMethod (c$, "startManagingCursor", 
function (c) {
this.mManagedCursors.add ( new android.app.Activity.ManagedCursor (c));
}, "android.database.Cursor");
Clazz.defineMethod (c$, "onSaveInstanceState", 
function (state) {
}, "android.os.Bundle");
Clazz.defineMethod (c$, "findViewById", 
function (id) {
return this.mWindow.findViewById (id);
}, "~N");
Clazz.defineMethod (c$, "setContentView", 
function (layoutResID) {
this.mWindow.setContentView (layoutResID);
this.mDecor = this.mWindow.getDecorView ();
}, "~N");
Clazz.defineMethod (c$, "setContentView", 
function (view) {
this.mWindow.setContentView (view);
this.mDecor = this.mWindow.getDecorView ();
}, "android.view.View");
Clazz.defineMethod (c$, "onPause", 
function () {
this.print ("onPause");
this.mCalled = true;
});
Clazz.defineMethod (c$, "print", 
($fz = function (functionName) {
var klass = this.getClass ();
android.util.Log.d ("Activity", "Activity's CanonicalName: " + klass.getName () + ", " + functionName);
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "onResume", 
function () {
this.print ("onResume");
this.mCalled = true;
});
Clazz.defineMethod (c$, "setDefaultKeyMode", 
function (mode) {
this.mDefaultKeyMode = mode;
switch (mode) {
case 0:
case 2:
this.mDefaultKeySsb = null;
break;
case 1:
case 3:
case 4:
this.mDefaultKeySsb =  new android.text.SpannableStringBuilder ();
android.text.Selection.setSelection (this.mDefaultKeySsb, 0);
break;
default:
throw  new IllegalArgumentException ();
}
}, "~N");
Clazz.overrideMethod (c$, "onKeyDown", 
function (keyCode, keyEvent) {
if (keyCode == 115) {
this.onBackPressed ();
return true;
}if (this.mDefaultKeyMode == 0) {
return false;
} else if (this.mDefaultKeyMode == 2) {
return false;
} else {
var clearSpannable = false;
var handled = false;
if (keyEvent.getRepeatCount () != 0) {
clearSpannable = true;
handled = false;
}if (clearSpannable) {
this.mDefaultKeySsb.clear ();
this.mDefaultKeySsb.clearSpans ();
android.text.Selection.setSelection (this.mDefaultKeySsb, 0);
}return handled;
}}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onPrepareOptionsMenu", 
function (menu) {
if (this.mParent != null) {
return this.mParent.onPrepareOptionsMenu (menu);
}return true;
}, "android.view.Menu");
Clazz.defineMethod (c$, "onOptionsItemSelected", 
function (item) {
if (this.mParent != null) {
return this.mParent.onOptionsItemSelected (item);
}return false;
}, "android.view.MenuItem");
Clazz.defineMethod (c$, "setParent", 
function (parent) {
this.mParent = parent;
}, "android.app.Activity");
Clazz.defineMethod (c$, "attach", 
function (context, instr, title, aThread, token, intent, app) {
this.attachBaseContext (context);
this.mActivityThread = aThread;
this.mMainThread = aThread;
this.mWindow =  new android.view.Window (this);
this.mWindow.setCallback (this);
this.mInstrumentation = instr;
this.mToken = token;
this.mIntent = intent;
this.mComponent = intent.getComponent ();
this.mTitle = title;
this.mIntent = intent;
this.mComponent = intent.getComponent ();
this.mApplication = app;
this.mWindow.setWindowManager (null, this.mToken, null);
if (this.mParent != null) {
this.mWindow.setContainer (this.mParent.getWindow ());
}this.$mWindowManager = this.mWindow.getWindowManager ();
}, "android.content.Context,android.app.Instrumentation,CharSequence,android.app.ActivityThread,android.os.IBinder,android.content.Intent,android.app.Application");
Clazz.defineMethod (c$, "getToken", 
function () {
return this.mToken;
});
Clazz.defineMethod (c$, "getApplication", 
function () {
return this.mApplication;
});
Clazz.defineMethod (c$, "performStart", 
function () {
this.mCalled = false;
this.mInstrumentation.callActivityOnStart (this);
if (!this.mCalled) {
android.util.Log.d ("Activity", "Activity " + this.mComponent.toShortString () + " did not call through to super.onStart()");
}});
Clazz.defineMethod (c$, "makeVisible", 
function () {
if (!this.mWindowAdded) {
var wm = this.getWindowManager ();
this.mDecor.zIndex = this.mZIndex;
wm.addView (this.mDecor,  new android.view.WindowManager.LayoutParams (2, 0, -1));
this.mWindowAdded = true;
}this.mDecor.setVisibility (0);
});
Clazz.defineMethod (c$, "setVisible", 
function (visible) {
if (visible) this.makeVisible ();
 else this.mDecor.setVisibility (4);
}, "~B");
Clazz.defineMethod (c$, "getWindow", 
function () {
return this.mWindow;
});
Clazz.defineMethod (c$, "onOptionsMenuClosed", 
function (menu) {
if (this.mParent != null) {
this.mParent.onOptionsMenuClosed (menu);
}}, "android.view.Menu");
Clazz.defineMethod (c$, "openOptionsMenu", 
function () {
this.mWindow.togglePanel (0, null);
});
Clazz.defineMethod (c$, "closeOptionsMenu", 
function () {
this.mWindow.closePanel (0);
});
Clazz.overrideMethod (c$, "onCreateContextMenu", 
function (menu, v, menuInfo) {
}, "android.view.ContextMenu,android.view.View,android.view.ContextMenu.ContextMenuInfo");
Clazz.defineMethod (c$, "registerForContextMenu", 
function (view) {
view.setOnCreateContextMenuListener (this);
}, "android.view.View");
Clazz.defineMethod (c$, "unregisterForContextMenu", 
function (view) {
view.setOnCreateContextMenuListener (null);
}, "android.view.View");
Clazz.defineMethod (c$, "openContextMenu", 
function (view) {
view.showContextMenu ();
}, "android.view.View");
Clazz.defineMethod (c$, "closeContextMenu", 
function () {
this.mWindow.closePanel (6);
});
Clazz.defineMethod (c$, "getLayoutInflater", 
function () {
return this.getWindow ().getLayoutInflater ();
});
Clazz.defineMethod (c$, "requestWindowFeature", 
function (featureId) {
return this.getWindow ().requestFeature (featureId);
}, "~N");
Clazz.defineMethod (c$, "onUserInteraction", 
function () {
});
Clazz.overrideMethod (c$, "dispatchKeyEvent", 
function (event) {
this.onUserInteraction ();
if (this.getWindow ().superDispatchKeyEvent (event)) {
return true;
}var decor = this.mDecor;
if (decor == null) {
decor = this.getWindow ().getDecorView ();
}return event.dispatch (this, decor != null ? decor.getKeyDispatcherState () : null, this);
}, "android.view.KeyEvent");
Clazz.overrideMethod (c$, "dispatchTouchEvent", 
function (ev) {
if (ev.getAction () == 0) {
this.onUserInteraction ();
}if (this.getWindow ().superDispatchTouchEvent (ev)) {
return true;
}return this.onTouchEvent (ev);
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "onBackPressed", 
function () {
this.finish ();
});
Clazz.defineMethod (c$, "onTouchEvent", 
function (event) {
return false;
}, "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onWindowAttributesChanged", 
function (params) {
if (this.mParent == null) {
var decor = this.mDecor;
if (decor != null && decor.getParent () != null) {
this.getWindowManager ().updateViewLayout (decor, params);
}}}, "android.view.WindowManager.LayoutParams");
Clazz.overrideMethod (c$, "onContentChanged", 
function () {
});
Clazz.overrideMethod (c$, "onCreatePanelView", 
function (featureId) {
return null;
}, "~N");
Clazz.overrideMethod (c$, "onCreatePanelMenu", 
function (featureId, menu) {
if (featureId == 0) {
return this.onCreateOptionsMenu (menu);
}return false;
}, "~N,android.view.Menu");
Clazz.overrideMethod (c$, "onPreparePanel", 
function (featureId, view, menu) {
if (featureId == 0 && menu != null) {
var goforit = this.onPrepareOptionsMenu (menu);
return goforit && menu.hasVisibleItems ();
}return true;
}, "~N,android.view.View,android.view.Menu");
Clazz.overrideMethod (c$, "onMenuOpened", 
function (featureId, menu) {
return true;
}, "~N,android.view.Menu");
Clazz.overrideMethod (c$, "onMenuItemSelected", 
function (featureId, item) {
switch (featureId) {
case 0:
return this.onOptionsItemSelected (item);
case 6:
return this.onContextItemSelected (item);
default:
return false;
}
}, "~N,android.view.MenuItem");
Clazz.overrideMethod (c$, "onPanelClosed", 
function (featureId, menu) {
switch (featureId) {
case 0:
this.onOptionsMenuClosed (menu);
break;
case 6:
this.onContextMenuClosed (menu);
break;
}
}, "~N,android.view.Menu");
Clazz.defineMethod (c$, "onContextMenuClosed", 
function (menu) {
if (this.mParent != null) {
this.mParent.onContextMenuClosed (menu);
}}, "android.view.Menu");
Clazz.defineMethod (c$, "onContextItemSelected", 
function (item) {
if (this.mParent != null) {
return this.mParent.onContextItemSelected (item);
}return false;
}, "android.view.MenuItem");
Clazz.defineMethod (c$, "getWindowManager", 
function () {
return this.$mWindowManager;
});
Clazz.defineMethod (c$, "performSaveInstanceState", 
function (outState) {
this.onSaveInstanceState (outState);
}, "android.os.Bundle");
Clazz.defineMethod (c$, "performPause", 
function () {
this.mCalled = false;
this.onPause ();
if (!this.mCalled) {
android.util.Log.d ("Activity", "Activity " + this.mComponent.toShortString () + " did not call through to super.onPause()");
}});
Clazz.defineMethod (c$, "onPostResume", 
function () {
this.mCalled = true;
});
Clazz.defineMethod (c$, "performResume", 
function () {
this.mCalled = false;
this.mInstrumentation.callActivityOnResume (this);
if (!this.mCalled) {
android.util.Log.d ("Activity", "Activity " + this.mComponent.toShortString () + " did not call through to super.onResume()");
}this.mResumed = true;
this.mCalled = false;
this.onPostResume ();
if (!this.mCalled) {
android.util.Log.d ("Activity", "Activity " + this.mComponent.toShortString () + " did not call through to super.onPostResume()");
}});
Clazz.defineMethod (c$, "getComponentName", 
function () {
return this.mComponent;
});
Clazz.overrideMethod (c$, "startActivity", 
function (intent) {
this.startActivityForResult (intent, -1);
}, "android.content.Intent");
Clazz.defineMethod (c$, "startActivityForResult", 
function (intent, requestCode) {
if (this.mParent == null) {
android.util.Log.d ("Activity", "in startActivityForResult");
var ar = this.mInstrumentation.execStartActivity (this, this.mMainThread.getApplicationThread (), this.mToken, this, intent, requestCode);
if (ar != null) {
android.util.Log.d ("Activity", "impossible here! ar will be set to null by default");
this.mMainThread.sendActivityResult (this.mToken, this.mEmbeddedID, requestCode, ar.getResultCode (), ar.getResultData ());
}if (requestCode >= 0) {
this.mStartedActivity = true;
}}}, "android.content.Intent,~N");
Clazz.defineMethod (c$, "setResult", 
function (resultCode) {
this.mResultCode = resultCode;
this.mResultData = null;
}, "~N");
Clazz.defineMethod (c$, "setResult", 
function (resultCode, data) {
this.mResultCode = resultCode;
this.mResultData = data;
}, "~N,android.content.Intent");
Clazz.defineMethod (c$, "finish", 
function () {
var resultCode;
var resultData;
resultCode = this.mResultCode;
resultData = this.mResultData;
android.util.Log.d ("Activity", "Finishing self: token=" + (this.mToken).info.name);
if (android.content.Context.getSystemContext ().getActivityManager ().finishActivity (this.mToken, resultCode, resultData)) {
this.mFinished = true;
}});
Clazz.defineMethod (c$, "onActivityResult", 
function (requestCode, resultCode, data) {
}, "~N,~N,android.content.Intent");
Clazz.defineMethod (c$, "performRestoreInstanceState", 
function (savedInstanceState) {
this.onRestoreInstanceState (savedInstanceState);
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onPostCreate", 
function (savedInstanceState) {
if (!this.isChild ()) {
this.mTitleReady = true;
this.onTitleChanged (this.getTitle (), this.getTitleColor ());
}this.mCalled = true;
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onStart", 
function () {
this.print ("onStart");
this.mCalled = true;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (savedInstanceState) {
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onDestroy", 
function () {
this.print ("onDestroy");
this.mCalled = true;
});
Clazz.defineMethod (c$, "onStop", 
function () {
this.print ("onStop");
this.mCalled = true;
});
Clazz.defineMethod (c$, "performStop", 
function () {
android.util.Log.d ("Activity", "in performStop");
if (!this.mStopped) {
if (this.mWindow != null) {
this.mWindow.closeAllPanels ();
}this.mCalled = false;
this.mInstrumentation.callActivityOnStop (this);
if (!this.mCalled) {
System.out.println ("Activity did not call through to super.onStop()");
}this.mStopped = true;
}this.mResumed = false;
});
Clazz.defineMethod (c$, "dispatchActivityResult", 
function (who, requestCode, resultCode, data) {
if (who == null) {
this.onActivityResult (requestCode, resultCode, data);
}}, "~S,~N,~N,android.content.Intent");
Clazz.overrideMethod (c$, "onKeyLongPress", 
function (keyCode, event) {
return false;
}, "~N,android.view.KeyEvent");
Clazz.overrideMethod (c$, "onKeyUp", 
function (keyCode, event) {
return false;
}, "~N,android.view.KeyEvent");
Clazz.overrideMethod (c$, "onKeyMultiple", 
function (keyCode, count, event) {
return false;
}, "~N,~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "createDialog", 
($fz = function (dialogId, state, args) {
var dialog = this.onCreateDialog ((dialogId).intValue (), args);
if (dialog == null) {
return null;
}dialog.dispatchOnCreate (state);
return dialog;
}, $fz.isPrivate = true, $fz), "Integer,android.os.Bundle,android.os.Bundle");
Clazz.defineMethod (c$, "onCreateDialog", 
function (id, args) {
return this.onCreateDialog (id);
}, "~N,android.os.Bundle");
Clazz.defineMethod (c$, "onCreateDialog", 
function (id) {
return null;
}, "~N");
Clazz.defineMethod (c$, "onPrepareDialog", 
function (id, dialog) {
dialog.setOwnerActivity (this);
}, "~N,android.app.Dialog");
Clazz.defineMethod (c$, "onPrepareDialog", 
function (id, dialog, args) {
this.onPrepareDialog (id, dialog);
}, "~N,android.app.Dialog,android.os.Bundle");
Clazz.defineMethod (c$, "showDialog", 
function (id) {
this.showDialog (id, null);
}, "~N");
Clazz.defineMethod (c$, "showDialog", 
function (id, args) {
if (this.mManagedDialogs == null) {
this.mManagedDialogs =  new android.util.SparseArray ();
}var md = this.mManagedDialogs.get (id);
if (md == null) {
md =  new android.app.Activity.ManagedDialog ();
md.mDialog = this.createDialog (new Integer (id), null, args);
if (md.mDialog == null) {
return false;
}this.mManagedDialogs.put (id, md);
}md.mArgs = args;
this.onPrepareDialog (id, md.mDialog, args);
md.mDialog.show ();
return true;
}, "~N,android.os.Bundle");
Clazz.defineMethod (c$, "setTitle", 
function (title) {
this.mTitle = title;
this.onTitleChanged (title, this.mTitleColor);
if (this.mParent != null) {
this.mParent.onChildTitleChanged (this, title);
}}, "CharSequence");
Clazz.defineMethod (c$, "setTitle", 
function (titleId) {
this.setTitle (this.getText (titleId));
}, "~N");
Clazz.defineMethod (c$, "setTitleColor", 
function (textColor) {
this.mTitleColor = textColor;
this.onTitleChanged (this.mTitle, textColor);
}, "~N");
Clazz.defineMethod (c$, "getTitle", 
function () {
return this.mTitle;
});
Clazz.defineMethod (c$, "getTitleColor", 
function () {
return this.mTitleColor;
});
Clazz.defineMethod (c$, "onTitleChanged", 
function (title, color) {
if (this.mTitleReady) {
var win = this.getWindow ();
if (win != null) {
win.setTitle (title);
if (color != 0) {
win.setTitleColor (color);
}}}}, "CharSequence,~N");
Clazz.defineMethod (c$, "onChildTitleChanged", 
function (childActivity, title) {
}, "android.app.Activity,CharSequence");
Clazz.defineMethod (c$, "setProgressBarVisibility", 
function (visible) {
this.getWindow ().setFeatureInt (2, visible ? -1 : -2);
}, "~B");
Clazz.defineMethod (c$, "setProgressBarIndeterminateVisibility", 
function (visible) {
this.getWindow ().setFeatureInt (5, visible ? -1 : -2);
}, "~B");
Clazz.defineMethod (c$, "setProgressBarIndeterminate", 
function (indeterminate) {
this.getWindow ().setFeatureInt (2, indeterminate ? -3 : -4);
}, "~B");
Clazz.defineMethod (c$, "setProgress", 
function (progress) {
this.getWindow ().setFeatureInt (2, progress + 0);
}, "~N");
Clazz.defineMethod (c$, "setSecondaryProgress", 
function (secondaryProgress) {
this.getWindow ().setFeatureInt (2, secondaryProgress + 20000);
}, "~N");
Clazz.defineMethod (c$, "isFinishing", 
function () {
return this.mFinished;
});
Clazz.defineMethod (c$, "onNewIntent", 
function (intent) {
}, "android.content.Intent");
Clazz.defineMethod (c$, "onRestart", 
function () {
this.mCalled = true;
});
Clazz.defineMethod (c$, "attach", 
function (context, aThread, instr, token, application, intent, info, title, parent, id, lastNonConfigurationInstance, config) {
this.attach (context, aThread, instr, token, 0, application, intent, info, title, parent, id, lastNonConfigurationInstance, null, config);
}, "android.content.Context,android.app.ActivityThread,android.app.Instrumentation,android.os.IBinder,android.app.Application,android.content.Intent,android.content.pm.ActivityInfo,CharSequence,android.app.Activity,~S,~O,android.content.res.Configuration");
Clazz.defineMethod (c$, "attach", 
function (context, aThread, instr, token, ident, application, intent, info, title, parent, id, lastNonConfigurationInstance, lastNonConfigurationChildInstances, config) {
this.attachBaseContext (context);
}, "android.content.Context,android.app.ActivityThread,android.app.Instrumentation,android.os.IBinder,~N,android.app.Application,android.content.Intent,android.content.pm.ActivityInfo,CharSequence,android.app.Activity,~S,~O,java.util.HashMap,android.content.res.Configuration");
Clazz.defineMethod (c$, "getMenuInflater", 
function () {
return  new android.view.MenuInflater (this);
});
Clazz.defineMethod (c$, "getPreferences", 
function (mode) {
console.log("Missing method: getPreferences");
}, "~N");
Clazz.defineMethod (c$, "setRequestedOrientation", 
function (requestedOrientation) {
console.log("Missing method: setRequestedOrientation");
}, "~N");
Clazz.defineMethod (c$, "getTaskId", 
function () {
console.log("Missing method: getTaskId");
});
Clazz.defineMethod (c$, "onRetainNonConfigurationInstance", 
function () {
console.log("Missing method: onRetainNonConfigurationInstance");
});
Clazz.defineMethod (c$, "takeKeyEvents", 
function (get) {
console.log("Missing method: takeKeyEvents");
}, "~B");
Clazz.defineMethod (c$, "getCallingPackage", 
function () {
console.log("Missing method: getCallingPackage");
});
Clazz.defineMethod (c$, "setPersistent", 
function (isPersistent) {
console.log("Missing method: setPersistent");
}, "~B");
Clazz.defineMethod (c$, "dismissDialog", 
function (id) {
console.log("Missing method: dismissDialog");
}, "~N");
Clazz.defineMethod (c$, "setVolumeControlStream", 
function (streamType) {
console.log("Missing method: setVolumeControlStream");
}, "~N");
Clazz.defineMethod (c$, "hasWindowFocus", 
function () {
console.log("Missing method: hasWindowFocus");
});
Clazz.defineMethod (c$, "getLastNonConfigurationInstance", 
function () {
console.log("Missing method: getLastNonConfigurationInstance");
});
Clazz.defineMethod (c$, "getLocalClassName", 
function () {
console.log("Missing method: getLocalClassName");
});
Clazz.defineMethod (c$, "isTaskRoot", 
function () {
console.log("Missing method: isTaskRoot");
});
Clazz.defineMethod (c$, "onUserLeaveHint", 
function () {
console.log("Missing method: onUserLeaveHint");
});
Clazz.defineMethod (c$, "onAttachedToWindow", 
function () {
console.log("Missing method: onAttachedToWindow");
});
Clazz.defineMethod (c$, "onWindowFocusChanged", 
function (hasFocus) {
console.log("Missing method: onWindowFocusChanged");
}, "~B");
Clazz.defineMethod (c$, "onLowMemory", 
function () {
console.log("Missing method: onLowMemory");
});
Clazz.defineMethod (c$, "runOnUiThread", 
function (action) {
console.log("Missing method: runOnUiThread");
}, "Runnable");
Clazz.defineMethod (c$, "finishActivity", 
function (requestCode) {
console.log("Missing method: finishActivity");
}, "~N");
Clazz.defineMethod (c$, "onDetachedFromWindow", 
function () {
console.log("Missing method: onDetachedFromWindow");
});
Clazz.defineMethod (c$, "getChangingConfigurations", 
function () {
console.log("Missing method: getChangingConfigurations");
});
Clazz.defineMethod (c$, "getVolumeControlStream", 
function () {
console.log("Missing method: getVolumeControlStream");
});
Clazz.defineMethod (c$, "removeDialog", 
function (id) {
console.log("Missing method: removeDialog");
}, "~N");
Clazz.defineMethod (c$, "onCreateDescription", 
function () {
console.log("Missing method: onCreateDescription");
});
Clazz.defineMethod (c$, "moveTaskToBack", 
function (nonRoot) {
console.log("Missing method: moveTaskToBack");
}, "~B");
Clazz.defineMethod (c$, "onSearchRequested", 
function () {
console.log("Missing method: onSearchRequested");
});
Clazz.defineMethod (c$, "finishFromChild", 
function (child) {
console.log("Missing method: finishFromChild");
}, "android.app.Activity");
Clazz.defineMethod (c$, "getRequestedOrientation", 
function () {
console.log("Missing method: getRequestedOrientation");
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mDialog = null;
this.mArgs = null;
Clazz.instantialize (this, arguments);
}, android.app.Activity, "ManagedDialog");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mCursor = null;
this.mReleased = false;
this.mUpdated = false;
Clazz.instantialize (this, arguments);
}, android.app.Activity, "ManagedCursor");
Clazz.makeConstructor (c$, 
function (a) {
this.mCursor = a;
this.mReleased = false;
this.mUpdated = false;
}, "android.database.Cursor");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"$TAG", "Activity",
"RESULT_CANCELED", 0,
"RESULT_OK", -1,
"RESULT_FIRST_USER", 1,
"sInstanceCount", 0,
"DEFAULT_KEYS_DISABLE", 0,
"DEFAULT_KEYS_DIALER", 1,
"DEFAULT_KEYS_SHORTCUT", 2,
"DEFAULT_KEYS_SEARCH_LOCAL", 3,
"DEFAULT_KEYS_SEARCH_GLOBAL", 4);
});
