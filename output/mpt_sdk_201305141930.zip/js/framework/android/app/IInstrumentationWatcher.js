﻿Clazz.declarePackage ("android.app");
c$ = Clazz.decorateAsClass (function () {
this.mFinished = false;
this.mRawMode = false;
Clazz.instantialize (this, arguments);
}, android.app, "IInstrumentationWatcher");
Clazz.defineMethod (c$, "setRawOutput", 
function (rawMode) {
this.mRawMode = rawMode;
}, "~B");
Clazz.defineMethod (c$, "instrumentationStatus", 
function (name, resultCode, results) {
{
var pretty = null;
if (!this.mRawMode && results != null) {
pretty = results.getString ("stream");
}if (pretty != null) {
System.out.print (pretty);
} else {
if (results != null) {
for (var key, $key = results.keySet ().iterator (); $key.hasNext () && ((key = $key.next ()) || true);) {
System.out.println ("INSTRUMENTATION_STATUS: " + key + "=" + results.get (key));
}
}System.out.println ("INSTRUMENTATION_STATUS_CODE: " + resultCode);
}this.notifyAll ();
}}, "android.content.ComponentName,~N,android.os.Bundle");
Clazz.defineMethod (c$, "instrumentationFinished", 
function (name, resultCode, results) {
{
var pretty = null;
if (!this.mRawMode && results != null) {
pretty = results.getString ("stream");
}if (pretty != null) {
System.out.println (pretty);
} else {
if (results != null) {
for (var key, $key = results.keySet ().iterator (); $key.hasNext () && ((key = $key.next ()) || true);) {
System.out.println ("INSTRUMENTATION_RESULT: " + key + "=" + results.get (key));
}
}System.out.println ("INSTRUMENTATION_CODE: " + resultCode);
}this.mFinished = true;
this.notifyAll ();
}}, "android.content.ComponentName,~N,android.os.Bundle");
