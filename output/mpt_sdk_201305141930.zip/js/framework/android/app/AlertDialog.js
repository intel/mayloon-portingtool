﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.app.Dialog", "android.content.DialogInterface"], "android.app.AlertDialog", ["com.android.internal.app.AlertController"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAlert = null;
Clazz.instantialize (this, arguments);
}, android.app, "AlertDialog", android.app.Dialog, android.content.DialogInterface);
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, 16973987);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, theme) {
Clazz.superConstructor (this, android.app.AlertDialog, [context, theme]);
this.mAlert =  new com.android.internal.app.AlertController (context, this, this.getWindow ());
}, "android.content.Context,~N");
Clazz.makeConstructor (c$, 
function (context, cancelable, cancelListener) {
Clazz.superConstructor (this, android.app.AlertDialog, [context, 16973987]);
this.setCancelable (cancelable);
this.setOnCancelListener (cancelListener);
this.mAlert =  new com.android.internal.app.AlertController (context, this, this.getWindow ());
}, "android.content.Context,~B,android.content.DialogInterface.OnCancelListener");
Clazz.defineMethod (c$, "getButton", 
function (whichButton) {
return this.mAlert.getButton (whichButton);
}, "~N");
Clazz.defineMethod (c$, "getListView", 
function () {
return this.mAlert.getListView ();
});
Clazz.defineMethod (c$, "setTitle", 
function (title) {
Clazz.superCall (this, android.app.AlertDialog, "setTitle", [title]);
this.mAlert.setTitle (title);
}, "CharSequence");
Clazz.defineMethod (c$, "setCustomTitle", 
function (customTitleView) {
this.mAlert.setCustomTitle (customTitleView);
}, "android.view.View");
Clazz.defineMethod (c$, "setMessage", 
function (message) {
this.mAlert.setMessage (message);
}, "CharSequence");
Clazz.defineMethod (c$, "setView", 
function (view) {
this.mAlert.setView (view);
}, "android.view.View");
Clazz.defineMethod (c$, "setView", 
function (view, viewSpacingLeft, viewSpacingTop, viewSpacingRight, viewSpacingBottom) {
this.mAlert.setView (view, viewSpacingLeft, viewSpacingTop, viewSpacingRight, viewSpacingBottom);
}, "android.view.View,~N,~N,~N,~N");
Clazz.defineMethod (c$, "setButton", 
function (whichButton, text, msg) {
this.mAlert.setButton (whichButton, text, null, msg);
}, "~N,CharSequence,android.os.Message");
Clazz.defineMethod (c$, "setButton", 
function (whichButton, text, listener) {
this.mAlert.setButton (whichButton, text, listener, null);
}, "~N,CharSequence,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setButton", 
function (text, msg) {
this.setButton (-1, text, msg);
}, "CharSequence,android.os.Message");
Clazz.defineMethod (c$, "setButton2", 
function (text, msg) {
this.setButton (-2, text, msg);
}, "CharSequence,android.os.Message");
Clazz.defineMethod (c$, "setButton3", 
function (text, msg) {
this.setButton (-3, text, msg);
}, "CharSequence,android.os.Message");
Clazz.defineMethod (c$, "setButton", 
function (text, listener) {
this.setButton (-1, text, listener);
}, "CharSequence,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setButton2", 
function (text, listener) {
this.setButton (-2, text, listener);
}, "CharSequence,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setButton3", 
function (text, listener) {
this.setButton (-3, text, listener);
}, "CharSequence,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setIcon", 
function (resId) {
this.mAlert.setIcon (resId);
}, "~N");
Clazz.defineMethod (c$, "setIcon", 
function (icon) {
this.mAlert.setIcon (icon);
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setInverseBackgroundForced", 
function (forceInverseBackground) {
this.mAlert.setInverseBackgroundForced (forceInverseBackground);
}, "~B");
Clazz.defineMethod (c$, "onCreate", 
function (savedInstanceState) {
Clazz.superCall (this, android.app.AlertDialog, "onCreate", [savedInstanceState]);
this.mAlert.installContent ();
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onKeyDown", 
function (keyCode, event) {
if (this.mAlert.onKeyDown (keyCode, event)) return true;
return Clazz.superCall (this, android.app.AlertDialog, "onKeyDown", [keyCode, event]);
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyUp", 
function (keyCode, event) {
if (this.mAlert.onKeyUp (keyCode, event)) return true;
return Clazz.superCall (this, android.app.AlertDialog, "onKeyUp", [keyCode, event]);
}, "~N,android.view.KeyEvent");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.P = null;
this.mTheme = 0;
Clazz.instantialize (this, arguments);
}, android.app.AlertDialog, "Builder");
Clazz.makeConstructor (c$, 
function (a) {
this.construct (a, 16973987);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (a, b) {
this.P =  new com.android.internal.app.AlertController.AlertParams (a);
this.mTheme = b;
}, "android.content.Context,~N");
Clazz.defineMethod (c$, "setTitle", 
function (a) {
this.P.mTitle = this.P.mContext.getText (a);
return this;
}, "~N");
Clazz.defineMethod (c$, "setTitle", 
function (a) {
this.P.mTitle = a;
return this;
}, "CharSequence");
Clazz.defineMethod (c$, "setCustomTitle", 
function (a) {
this.P.mCustomTitleView = a;
return this;
}, "android.view.View");
Clazz.defineMethod (c$, "setMessage", 
function (a) {
this.P.mMessage = this.P.mContext.getText (a);
return this;
}, "~N");
Clazz.defineMethod (c$, "setMessage", 
function (a) {
this.P.mMessage = a;
return this;
}, "CharSequence");
Clazz.defineMethod (c$, "setIcon", 
function (a) {
this.P.mIconId = a;
return this;
}, "~N");
Clazz.defineMethod (c$, "setIcon", 
function (a) {
this.P.mIcon = a;
return this;
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setPositiveButton", 
function (a, b) {
this.P.mPositiveButtonText = this.P.mContext.getText (a);
this.P.mPositiveButtonListener = b;
return this;
}, "~N,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setPositiveButton", 
function (a, b) {
this.P.mPositiveButtonText = a;
this.P.mPositiveButtonListener = b;
return this;
}, "CharSequence,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setNegativeButton", 
function (a, b) {
this.P.mNegativeButtonText = this.P.mContext.getText (a);
this.P.mNegativeButtonListener = b;
return this;
}, "~N,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setNegativeButton", 
function (a, b) {
this.P.mNegativeButtonText = a;
this.P.mNegativeButtonListener = b;
return this;
}, "CharSequence,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setNeutralButton", 
function (a, b) {
this.P.mNeutralButtonText = this.P.mContext.getText (a);
this.P.mNeutralButtonListener = b;
return this;
}, "~N,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setNeutralButton", 
function (a, b) {
this.P.mNeutralButtonText = a;
this.P.mNeutralButtonListener = b;
return this;
}, "CharSequence,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setCancelable", 
function (a) {
this.P.mCancelable = a;
return this;
}, "~B");
Clazz.defineMethod (c$, "setOnCancelListener", 
function (a) {
this.P.mOnCancelListener = a;
return this;
}, "android.content.DialogInterface.OnCancelListener");
Clazz.defineMethod (c$, "setOnKeyListener", 
function (a) {
this.P.mOnKeyListener = a;
return this;
}, "android.content.DialogInterface.OnKeyListener");
Clazz.defineMethod (c$, "setItems", 
function (a, b) {
this.P.mItems = this.P.mContext.getResources ().getTextArray (a);
this.P.mOnClickListener = b;
return this;
}, "~N,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setItems", 
function (a, b) {
this.P.mItems = a;
this.P.mOnClickListener = b;
return this;
}, "~A,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setAdapter", 
function (a, b) {
this.P.mAdapter = a;
this.P.mOnClickListener = b;
return this;
}, "android.widget.ListAdapter,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setCursor", 
function (a, b, c) {
this.P.mCursor = a;
this.P.mLabelColumn = c;
this.P.mOnClickListener = b;
return this;
}, "android.database.Cursor,android.content.DialogInterface.OnClickListener,~S");
Clazz.defineMethod (c$, "setMultiChoiceItems", 
function (a, b, c) {
this.P.mItems = this.P.mContext.getResources ().getTextArray (a);
this.P.mOnCheckboxClickListener = c;
this.P.mCheckedItems = b;
this.P.mIsMultiChoice = true;
return this;
}, "~N,~A,android.content.DialogInterface.OnMultiChoiceClickListener");
Clazz.defineMethod (c$, "setMultiChoiceItems", 
function (a, b, c) {
this.P.mItems = a;
this.P.mOnCheckboxClickListener = c;
this.P.mCheckedItems = b;
this.P.mIsMultiChoice = true;
return this;
}, "~A,~A,android.content.DialogInterface.OnMultiChoiceClickListener");
Clazz.defineMethod (c$, "setMultiChoiceItems", 
function (a, b, c, d) {
this.P.mCursor = a;
this.P.mOnCheckboxClickListener = d;
this.P.mIsCheckedColumn = b;
this.P.mLabelColumn = c;
this.P.mIsMultiChoice = true;
return this;
}, "android.database.Cursor,~S,~S,android.content.DialogInterface.OnMultiChoiceClickListener");
Clazz.defineMethod (c$, "setSingleChoiceItems", 
function (a, b, c) {
this.P.mItems = this.P.mContext.getResources ().getTextArray (a);
this.P.mOnClickListener = c;
this.P.mCheckedItem = b;
this.P.mIsSingleChoice = true;
return this;
}, "~N,~N,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setSingleChoiceItems", 
function (a, b, c, d) {
this.P.mCursor = a;
this.P.mOnClickListener = d;
this.P.mCheckedItem = b;
this.P.mLabelColumn = c;
this.P.mIsSingleChoice = true;
return this;
}, "android.database.Cursor,~N,~S,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setSingleChoiceItems", 
function (a, b, c) {
this.P.mItems = a;
this.P.mOnClickListener = c;
this.P.mCheckedItem = b;
this.P.mIsSingleChoice = true;
return this;
}, "~A,~N,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setSingleChoiceItems", 
function (a, b, c) {
this.P.mAdapter = a;
this.P.mOnClickListener = c;
this.P.mCheckedItem = b;
this.P.mIsSingleChoice = true;
return this;
}, "android.widget.ListAdapter,~N,android.content.DialogInterface.OnClickListener");
Clazz.defineMethod (c$, "setOnItemSelectedListener", 
function (a) {
this.P.mOnItemSelectedListener = a;
return this;
}, "android.widget.AdapterView.OnItemSelectedListener");
Clazz.defineMethod (c$, "setView", 
function (a) {
this.P.mView = a;
this.P.mViewSpacingSpecified = false;
return this;
}, "android.view.View");
Clazz.defineMethod (c$, "setView", 
function (a, b, c, d, e) {
this.P.mView = a;
this.P.mViewSpacingSpecified = true;
this.P.mViewSpacingLeft = b;
this.P.mViewSpacingTop = c;
this.P.mViewSpacingRight = d;
this.P.mViewSpacingBottom = e;
return this;
}, "android.view.View,~N,~N,~N,~N");
Clazz.defineMethod (c$, "setInverseBackgroundForced", 
function (a) {
this.P.mForceInverseBackground = a;
return this;
}, "~B");
Clazz.defineMethod (c$, "setRecycleOnMeasureEnabled", 
function (a) {
this.P.mRecycleOnMeasure = a;
return this;
}, "~B");
Clazz.defineMethod (c$, "create", 
function () {
var a =  new android.app.AlertDialog (this.P.mContext, this.mTheme);
this.P.apply (a.mAlert);
a.setCancelable (this.P.mCancelable);
a.setOnCancelListener (this.P.mOnCancelListener);
if (this.P.mOnKeyListener != null) {
a.setOnKeyListener (this.P.mOnKeyListener);
}return a;
});
Clazz.defineMethod (c$, "show", 
function () {
var a = this.create ();
a.show ();
return a;
});
c$ = Clazz.p0p ();
});
