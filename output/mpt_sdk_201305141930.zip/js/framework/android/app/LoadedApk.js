﻿Clazz.declarePackage ("android.app");
Clazz.load (["java.util.HashMap"], "android.app.LoadedApk", ["android.content.Context", "$.IIntentReceiver", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mReceivers = null;
this.mUnregisteredReceivers = null;
this.mActivityThread = null;
this.mClassLoader = null;
this.mBaseClassLoader = null;
this.mApplicationInfo = null;
this.mPackageName = null;
this.mResources = null;
this.mApplication = null;
this.mAppDir = null;
this.mSharedLibraries = null;
this.mIncludeCode = false;
Clazz.instantialize (this, arguments);
}, android.app, "LoadedApk");
Clazz.prepareFields (c$, function () {
this.mReceivers =  new java.util.HashMap ();
this.mUnregisteredReceivers =  new java.util.HashMap ();
});
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (activityThread, aInfo) {
this.mActivityThread = activityThread;
this.mApplicationInfo = aInfo;
this.mPackageName = aInfo.packageName;
}, "android.app.ActivityThread,android.content.pm.ApplicationInfo");
Clazz.defineMethod (c$, "getPackageName", 
function () {
return this.mPackageName;
});
Clazz.defineMethod (c$, "getApplication", 
function () {
return this.mApplication;
});
Clazz.defineMethod (c$, "makeApplication", 
function (forceDefaultAppClass, instrumentation) {
if (this.mApplication != null) {
return this.mApplication;
}var app = null;
var appClass = this.mApplicationInfo.className;
if (forceDefaultAppClass || (appClass == null)) {
appClass = "android.app.Application";
}try {
var context = android.content.Context.getSystemContext ().createPackageContext (this.mApplicationInfo.packageName, this.mActivityThread);
app = this.mActivityThread.mInstrumentation.newApplication (appClass, context);
context.setOuterContext (app);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
if (!this.mActivityThread.mInstrumentation.onException (app, e)) {
throw  new RuntimeException ("Unable to instantiate application " + appClass + ": " + e.toString (), e);
}} else {
throw e;
}
}
this.mActivityThread.mAllApplications.add (app);
this.mApplication = app;
if (instrumentation != null) {
try {
instrumentation.callApplicationOnCreate (app);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
if (!instrumentation.onException (app, e)) {
throw  new RuntimeException ("Unable to create application " + app.getClass ().getName () + ": " + e.toString (), e);
}} else {
throw e;
}
}
}return app;
}, "~B,android.app.Instrumentation");
Clazz.defineMethod (c$, "getReceiverDispatcher", 
function (r, context, handler, registered) {
{
var rd = null;
var map = null;
if (registered) {
map = this.mReceivers.get (context);
if (map != null) {
rd = map.get (r);
}}if (rd == null) {
rd =  new android.content.IIntentReceiver (r, context, handler, registered);
if (registered) {
if (map == null) {
map =  new java.util.HashMap ();
this.mReceivers.put (context, map);
}map.put (r, rd);
}}return rd;
}}, "android.content.BroadcastReceiver,android.content.Context,android.os.Handler,~B");
});
