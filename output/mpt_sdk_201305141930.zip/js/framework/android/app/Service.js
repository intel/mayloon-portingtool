﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.content.ContextWrapper"], "android.app.Service", ["android.content.ComponentName", "android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mThread = null;
this.mClassName = null;
this.mToken = null;
this.$mActivityManager = null;
this.mStartCompatibility = false;
Clazz.instantialize (this, arguments);
}, android.app, "Service", android.content.ContextWrapper);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.app.Service, [null]);
});
Clazz.defineMethod (c$, "onCreate", 
function () {
});
Clazz.defineMethod (c$, "onStart", 
function (intent, startId) {
}, "android.content.Intent,~N");
Clazz.defineMethod (c$, "onStartCommand", 
function (intent, flags, startId) {
this.onStart (intent, startId);
return this.mStartCompatibility ? 0 : 1;
}, "android.content.Intent,~N,~N");
Clazz.defineMethod (c$, "onDestroy", 
function () {
});
Clazz.defineMethod (c$, "onConfigurationChanged", 
function (newConfig) {
}, "android.content.res.Configuration");
Clazz.defineMethod (c$, "onLowMemory", 
function () {
});
Clazz.defineMethod (c$, "onUnbind", 
function (intent) {
return false;
}, "android.content.Intent");
Clazz.defineMethod (c$, "onRebind", 
function (intent) {
}, "android.content.Intent");
Clazz.defineMethod (c$, "stopSelf", 
function () {
this.stopSelf (-1);
});
Clazz.defineMethod (c$, "stopSelf", 
function (startId) {
if (this.$mActivityManager == null) {
return ;
}try {
this.$mActivityManager.stopServiceToken ( new android.content.ComponentName (this, this.mClassName), this.mToken, startId);
} catch (ex) {
if (Clazz.instanceOf (ex, Exception)) {
} else {
throw ex;
}
}
}, "~N");
Clazz.defineMethod (c$, "stopSelfResult", 
function (startId) {
if (this.$mActivityManager == null) {
return false;
}try {
return this.$mActivityManager.stopServiceToken ( new android.content.ComponentName (this, this.mClassName), this.mToken, startId);
} catch (ex) {
if (Clazz.instanceOf (ex, Exception)) {
} else {
throw ex;
}
}
return false;
}, "~N");
Clazz.defineMethod (c$, "setForeground", 
function (isForeground) {
android.util.Log.w ("Service", "setForeground: ignoring old API call on " + this.getClass ().getName ());
}, "~B");
Clazz.defineMethod (c$, "startForeground", 
function (id) {
try {
this.$mActivityManager.setServiceForeground ( new android.content.ComponentName (this, this.mClassName), this.mToken, id, true);
} catch (ex) {
if (Clazz.instanceOf (ex, Exception)) {
} else {
throw ex;
}
}
}, "~N");
Clazz.defineMethod (c$, "stopForeground", 
function (removeNotification) {
try {
this.$mActivityManager.setServiceForeground ( new android.content.ComponentName (this, this.mClassName), this.mToken, 0, removeNotification);
} catch (ex) {
if (Clazz.instanceOf (ex, Exception)) {
} else {
throw ex;
}
}
}, "~B");
Clazz.defineMethod (c$, "dump", 
function (fd, writer, args) {
writer.println ("nothing to dump");
}, "java.io.FileDescriptor,java.io.PrintWriter,~A");
Clazz.defineMethod (c$, "attach", 
function (context, thread, className, token, activityManager) {
this.attachBaseContext (context);
this.mThread = thread;
this.mClassName = className;
this.mToken = token;
this.$mActivityManager = activityManager;
this.mStartCompatibility = true;
}, "android.content.Context,android.app.ActivityThread,~S,android.os.IBinder,~O");
Clazz.defineMethod (c$, "getClassName", 
function () {
return this.mClassName;
});
Clazz.defineMethod (c$, "getApplication", 
function () {
console.log("Missing method: getApplication");
});
Clazz.defineStatics (c$,
"$TAG", "Service",
"START_CONTINUATION_MASK", 0xf,
"START_STICKY_COMPATIBILITY", 0,
"START_STICKY", 1,
"START_NOT_STICKY", 2,
"START_REDELIVER_INTENT", 3,
"START_FLAG_REDELIVERY", 0x0001,
"START_FLAG_RETRY", 0x0002);
});
