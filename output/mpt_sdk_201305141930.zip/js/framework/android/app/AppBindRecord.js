﻿Clazz.declarePackage ("android.app");
Clazz.load (["java.util.HashSet"], "android.app.AppBindRecord", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.service = null;
this.intent = null;
this.client = null;
this.connections = null;
Clazz.instantialize (this, arguments);
}, android.app, "AppBindRecord");
Clazz.prepareFields (c$, function () {
this.connections =  new java.util.HashSet ();
});
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
pw.println (prefix + "service=" + this.service);
pw.println (prefix + "client=" + this.client);
this.dumpInIntentBind (pw, prefix);
}, "java.io.PrintWriter,~S");
Clazz.defineMethod (c$, "dumpInIntentBind", 
function (pw, prefix) {
if (this.connections.size () > 0) {
pw.println (prefix + "Per-process Connections:");
var it = this.connections.iterator ();
while (it.hasNext ()) {
var c = it.next ();
pw.println (prefix + "  " + c);
}
}}, "java.io.PrintWriter,~S");
Clazz.makeConstructor (c$, 
function (_service, _intent, _client) {
this.service = _service;
this.intent = _intent;
this.client = _client;
}, "android.app.ServiceRecord,android.app.IntentBindRecord,android.app.ProcessRecord");
Clazz.overrideMethod (c$, "toString", 
function () {
return "AppBindRecord{ " + this.service.shortName + ":" + this.client.processName + "}";
});
});
