﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.Binder"], "android.app.ActivityRecord", ["android.app.ActivityResult", "android.content.ComponentName", "android.os.Message", "$.SystemClock", "java.lang.StringBuilder", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.service = null;
this.stack = null;
this.info = null;
this.launchedFromUid = 0;
this.intent = null;
this.realActivity = null;
this.shortComponentName = null;
this.resolvedType = null;
this.packageName = null;
this.processName = null;
this.taskAffinity = null;
this.stateNotNeeded = false;
this.fullscreen = false;
this.componentSpecified = false;
this.isHomeActivity = false;
this.baseDir = null;
this.resDir = null;
this.dataDir = null;
this.nonLocalizedLabel = null;
this.labelRes = 0;
this.icon = 0;
this.theme = 0;
this.task = null;
this.launchTime = 0;
this.startTime = 0;
this.cpuTimeAtResume = 0;
this.configuration = null;
this.resultTo = null;
this.resultWho = null;
this.requestCode = 0;
this.results = null;
this.newIntents = null;
this.app = null;
this.description = null;
this.state = 0;
this.icicle = null;
this.frontOfTask = false;
this.launchFailed = false;
this.haveState = false;
this.stopped = false;
this.delayedResume = false;
this.finishing = false;
this.configDestroy = false;
this.configChangeFlags = 0;
this.keysPaused = false;
this.inHistory = false;
this.launchMode = 0;
this.visible = false;
this.waitingVisible = false;
this.nowVisible = false;
this.thumbnailNeeded = false;
this.idle = false;
this.hasBeenLaunched = false;
this.frozenBeforeDestroy = false;
this.stringName = null;
Clazz.instantialize (this, arguments);
}, android.app, "ActivityRecord", android.os.Binder);
Clazz.makeConstructor (c$, 
function (_service, _stack, _caller, _launchedFromUid, _intent, _resolvedType, aInfo, _configuration, _resultTo, _resultWho, _reqCode, _componentSpecified) {
Clazz.superConstructor (this, android.app.ActivityRecord, []);
this.service = _service;
this.stack = _stack;
this.info = aInfo;
this.launchedFromUid = _launchedFromUid;
this.intent = _intent;
this.shortComponentName = _intent.getComponent ().flattenToShortString ();
this.resolvedType = _resolvedType;
this.componentSpecified = _componentSpecified;
this.configuration = _configuration;
this.resultTo = _resultTo;
this.resultWho = _resultWho;
this.requestCode = _reqCode;
this.state = 0;
this.frontOfTask = false;
this.launchFailed = false;
this.haveState = false;
this.stopped = false;
this.delayedResume = false;
this.finishing = false;
this.configDestroy = false;
this.keysPaused = false;
this.inHistory = false;
this.visible = true;
this.waitingVisible = false;
this.nowVisible = false;
this.thumbnailNeeded = false;
this.idle = false;
this.hasBeenLaunched = false;
if (aInfo != null) {
if (aInfo.targetActivity == null || aInfo.launchMode == 0 || aInfo.launchMode == 1) {
this.realActivity = _intent.getComponent ();
} else {
this.realActivity =  new android.content.ComponentName (aInfo.packageName, aInfo.targetActivity);
}this.taskAffinity = aInfo.taskAffinity;
this.stateNotNeeded = (aInfo.flags & 16) != 0;
this.baseDir = aInfo.applicationInfo.sourceDir;
this.resDir = aInfo.applicationInfo.publicSourceDir;
this.dataDir = aInfo.applicationInfo.dataDir;
this.nonLocalizedLabel = aInfo.nonLocalizedLabel;
this.labelRes = aInfo.labelRes;
if (this.nonLocalizedLabel == null && this.labelRes == 0) {
var app = aInfo.applicationInfo;
this.nonLocalizedLabel = app.nonLocalizedLabel;
this.labelRes = app.labelRes;
}this.icon = aInfo.getIconResource ();
this.theme = aInfo.getThemeResource ();
if ((aInfo.flags & 1) != 0 && _caller != null && aInfo.applicationInfo.uid == _caller.info.uid) {
this.processName = _caller.processName;
} else {
if (aInfo.processName == null) this.processName = aInfo.processName = aInfo.packageName;
 else this.processName = aInfo.processName;
}if (this.intent != null && (aInfo.flags & 32) != 0) {
this.intent.addFlags (8388608);
}this.packageName = aInfo.applicationInfo.packageName;
this.launchMode = aInfo.launchMode;
this.fullscreen = true;
if (!_componentSpecified || _launchedFromUid == 0) {
if ("android.intent.action.MAIN".equals (_intent.getAction ()) && _intent.hasCategory ("android.intent.category.HOME") && _intent.getCategories ().size () == 1 && _intent.getData () == null && _intent.getType () == null && (this.intent.getFlags () & 268435456) != 0 && !"android".equals (this.realActivity.getClassName ())) {
this.isHomeActivity = true;
} else {
this.isHomeActivity = false;
}} else {
this.isHomeActivity = false;
}} else {
this.realActivity = null;
this.taskAffinity = null;
this.stateNotNeeded = false;
this.baseDir = null;
this.resDir = null;
this.dataDir = null;
this.processName = null;
this.packageName = null;
this.fullscreen = true;
this.isHomeActivity = false;
}}, "android.app.ActivityManager,android.app.ActivityStack,android.app.ProcessRecord,~N,android.content.Intent,~S,android.content.pm.ActivityInfo,android.content.res.Configuration,android.app.ActivityRecord,~S,~N,~B");
Clazz.defineMethod (c$, "addResultLocked", 
function (from, resultWho, requestCode, resultCode, resultData) {
var r =  new android.app.ActivityResult (from, resultWho, requestCode, resultCode, resultData);
if (this.results == null) {
this.results =  new java.util.ArrayList ();
}this.results.add (r);
}, "android.app.ActivityRecord,~S,~N,~N,android.content.Intent");
Clazz.defineMethod (c$, "removeResultsLocked", 
function (from, resultWho, requestCode) {
if (this.results != null) {
for (var i = this.results.size () - 1; i >= 0; i--) {
var r = this.results.get (i);
if (r.mFrom !== from) continue ;if (r.mResultWho == null) {
if (resultWho != null) continue ;} else {
if (!r.mResultWho.equals (resultWho)) continue ;}if (r.mRequestCode != requestCode) continue ;this.results.remove (i);
}
}}, "android.app.ActivityRecord,~S,~N");
Clazz.defineMethod (c$, "addNewIntentLocked", 
function (intent) {
if (this.newIntents == null) {
this.newIntents =  new java.util.ArrayList ();
}this.newIntents.add (intent);
}, "android.content.Intent");
Clazz.defineMethod (c$, "pauseKeyDispatchingLocked", 
function () {
if (!this.keysPaused) {
this.keysPaused = true;
}});
Clazz.defineMethod (c$, "resumeKeyDispatchingLocked", 
function () {
if (this.keysPaused) {
this.keysPaused = false;
}});
Clazz.defineMethod (c$, "windowsVisible", 
function () {
{
if (this.launchTime != 0) {
var curTime = android.os.SystemClock.uptimeMillis ();
var thisTime = curTime - this.launchTime;
var totalTime = this.stack.mInitialStartTime != 0 ? (curTime - this.stack.mInitialStartTime) : thisTime;
if (totalTime > 0) {
}this.launchTime = 0;
this.stack.mInitialStartTime = 0;
}this.startTime = 0;
if (!this.nowVisible) {
this.nowVisible = true;
if (!this.idle) {
} else {
var N = this.stack.mWaitingVisibleActivities.size ();
if (N > 0) {
for (var i = 0; i < N; i++) {
var r = this.stack.mWaitingVisibleActivities.get (i);
r.waitingVisible = false;
}
this.stack.mWaitingVisibleActivities.clear ();
var msg = android.os.Message.obtain ();
msg.what = 11;
this.stack.mHandler.sendMessage (msg);
}}}}});
Clazz.defineMethod (c$, "windowsGone", 
function () {
this.nowVisible = false;
});
Clazz.defineMethod (c$, "isInterestingToUserLocked", 
function () {
return this.visible || this.nowVisible || this.state == 2 || this.state == 1;
});
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.stringName != null) {
return this.stringName;
}var sb =  new StringBuilder (128);
sb.append ("HistoryRecord{");
sb.append (this.packageName);
sb.append (' ');
sb.append (this.intent.getComponent ().flattenToShortString ());
sb.append ('}');
return this.stringName = sb.toString ();
});
});
