﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.Binder", "java.util.ArrayList", "$.HashMap"], "android.app.ServiceRecord", ["android.app.AppBindRecord", "$.IntentBindRecord", "android.content.Intent", "android.os.SystemClock", "java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.ams = null;
this.name = null;
this.shortName = null;
this.intent = null;
this.serviceInfo = null;
this.appInfo = null;
this.packageName = null;
this.processName = null;
this.permission = null;
this.baseDir = null;
this.resDir = null;
this.dataDir = null;
this.exported = false;
this.restarter = null;
this.createTime = 0;
this.bindings = null;
this.connections = null;
this.app = null;
this.isForeground = false;
this.foregroundId = 0;
this.lastActivity = 0;
this.startRequested = false;
this.stopIfKilled = false;
this.callStart = false;
this.lastStartId = 0;
this.executeNesting = 0;
this.executingStart = 0;
this.crashCount = 0;
this.totalRestartCount = 0;
this.restartCount = 0;
this.restartDelay = 0;
this.restartTime = 0;
this.nextRestartTime = 0;
this.stringName = null;
this.deliveredStarts = null;
this.pendingStarts = null;
Clazz.instantialize (this, arguments);
}, android.app, "ServiceRecord", android.os.Binder);
Clazz.prepareFields (c$, function () {
this.bindings =  new java.util.HashMap ();
this.connections =  new java.util.HashMap ();
this.deliveredStarts =  new java.util.ArrayList ();
this.pendingStarts =  new java.util.ArrayList ();
});
Clazz.defineMethod (c$, "dumpStartList", 
function (pw, prefix, list, now) {
}, "java.io.PrintWriter,~S,java.util.List,~N");
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
}, "java.io.PrintWriter,~S");
Clazz.makeConstructor (c$, 
function (ams, name, intent, sInfo, restarter) {
Clazz.superConstructor (this, android.app.ServiceRecord, []);
this.ams = ams;
this.name = name;
this.shortName = name.flattenToShortString ();
this.intent = intent;
this.serviceInfo = sInfo;
this.appInfo = sInfo.applicationInfo;
this.packageName = sInfo.applicationInfo.packageName;
this.processName = sInfo.processName;
this.permission = sInfo.permission;
this.baseDir = (sInfo.applicationInfo != null) ? sInfo.applicationInfo.sourceDir : null;
this.resDir = (sInfo.applicationInfo != null) ? sInfo.applicationInfo.publicSourceDir : null;
this.dataDir = (sInfo.applicationInfo != null) ? sInfo.applicationInfo.dataDir : null;
this.exported = sInfo.exported;
this.restarter = restarter;
this.createTime = android.os.SystemClock.elapsedRealtime ();
this.lastActivity = android.os.SystemClock.uptimeMillis ();
}, "android.app.ActivityManager,android.content.ComponentName,android.content.Intent.FilterComparison,android.content.pm.ServiceInfo,Runnable");
Clazz.defineMethod (c$, "retrieveAppBindingLocked", 
function (intent, app) {
var filter =  new android.content.Intent.FilterComparison (intent);
var i = this.bindings.get (filter);
if (i == null) {
i =  new android.app.IntentBindRecord (this, filter);
this.bindings.put (filter, i);
}var a = i.apps.get (app);
if (a != null) {
return a;
}a =  new android.app.AppBindRecord (this, i, app);
i.apps.put (app, a);
return a;
}, "android.content.Intent,android.app.ProcessRecord");
Clazz.defineMethod (c$, "resetRestartCounter", 
function () {
this.restartCount = 0;
this.restartDelay = 0;
this.restartTime = 0;
});
Clazz.defineMethod (c$, "findDeliveredStart", 
function (id, remove) {
var N = this.deliveredStarts.size ();
for (var i = 0; i < N; i++) {
var si = this.deliveredStarts.get (i);
if (si.id == id) {
if (remove) this.deliveredStarts.remove (i);
return si;
}}
return null;
}, "~N,~B");
Clazz.defineMethod (c$, "postNotification", 
function () {
});
Clazz.defineMethod (c$, "cancelNotification", 
function () {
});
Clazz.defineMethod (c$, "clearDeliveredStartsLocked", 
function () {
this.deliveredStarts.clear ();
});
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.stringName != null) {
return this.stringName;
}var sb =  new StringBuilder (128);
sb.append ("ServiceRecord{").append (' ').append (this.shortName).append ('}');
return this.stringName = sb.toString ();
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.sr = null;
this.id = 0;
this.intent = null;
this.targetPermissionUid = 0;
this.deliveredTime = 0;
this.deliveryCount = 0;
this.doneExecutingCount = 0;
this.stringName = null;
Clazz.instantialize (this, arguments);
}, android.app.ServiceRecord, "StartItem");
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
this.sr = a;
this.id = b;
this.intent = c;
this.targetPermissionUid = d;
}, "android.app.ServiceRecord,~N,android.content.Intent,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.stringName != null) {
return this.stringName;
}var a =  new StringBuilder (128);
a.append ("ServiceRecord{").append (' ').append (this.sr.shortName).append (" StartItem ").append (" id=").append (this.id).append ('}');
return this.stringName = a.toString ();
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"MAX_DELIVERY_COUNT", 3,
"MAX_DONE_EXECUTING_COUNT", 6);
});
