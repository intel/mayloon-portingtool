﻿Clazz.declarePackage ("android.app");
c$ = Clazz.declareType (android.app, "NotificationManager");
Clazz.defineMethod (c$, "notify", 
function (id, notification) {
this.notify (null, id, notification);
}, "~N,android.app.Notification");
Clazz.defineMethod (c$, "notify", 
function (tag, id, notification) {
var idOut =  Clazz.newArray (1, 0);
}, "~S,~N,android.app.Notification");
Clazz.defineMethod (c$, "cancel", 
function (id) {
this.cancel (null, id);
}, "~N");
Clazz.defineMethod (c$, "cancel", 
function (tag, id) {
}, "~S,~N");
Clazz.defineMethod (c$, "cancelAll", 
function () {
});
