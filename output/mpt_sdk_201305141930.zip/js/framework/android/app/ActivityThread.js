﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.app.IApplicationThread", "android.os.Binder", "$.Handler", "java.util.ArrayList", "$.HashMap", "java.util.regex.Pattern"], "android.app.ActivityThread", ["android.app.ContextImpl", "$.Instrumentation", "$.LoadedApk", "$.RemoteServiceException", "$.ResultInfo", "android.content.ComponentName", "$.Context", "android.content.pm.ApplicationInfo", "android.graphics.Bitmap", "android.os.Bundle", "$.Looper", "$.Message", "android.util.DisplayMetrics", "$.Log", "$.Slog", "android.view.WindowManagerImpl", "java.io.File", "java.lang.RuntimeException", "$.SecurityException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAppThread = null;
this.mH = null;
this.mActivities = null;
this.mInstrumentation = null;
this.mNumVisibleActivities = 0;
this.mNewActivities = null;
this.mProcessName = null;
this.mBoundApplication = null;
this.mInitialApplication = null;
this.mProviderRefCountMap = null;
this.mProviderMap = null;
this.mAllApplications = null;
this.mInstrumentationAppDir = null;
this.mInstrumentationAppPackage = null;
this.mInstrumentedAppDir = null;
this.mDisplay = null;
this.mDisplayMetrics = null;
this.mServices = null;
this.mPackages = null;
this.mResourcePackages = null;
if (!Clazz.isClassDefined ("android.app.ActivityThread.ProviderRefCount")) {
android.app.ActivityThread.$ActivityThread$ProviderRefCount$ ();
}
if (!Clazz.isClassDefined ("android.app.ActivityThread.ApplicationThread")) {
android.app.ActivityThread.$ActivityThread$ApplicationThread$ ();
}
if (!Clazz.isClassDefined ("android.app.ActivityThread.H")) {
android.app.ActivityThread.$ActivityThread$H$ ();
}
Clazz.instantialize (this, arguments);
}, android.app, "ActivityThread");
Clazz.prepareFields (c$, function () {
this.mAppThread = Clazz.innerTypeInstance (android.app.ActivityThread.ApplicationThread, this, null);
this.mH = Clazz.innerTypeInstance (android.app.ActivityThread.H, this, null);
this.mActivities =  new java.util.HashMap ();
this.mProviderRefCountMap =  new java.util.HashMap ();
this.mProviderMap =  new java.util.HashMap ();
this.mAllApplications =  new java.util.ArrayList ();
this.mServices =  new java.util.HashMap ();
this.mPackages =  new java.util.HashMap ();
this.mResourcePackages =  new java.util.HashMap ();
});
Clazz.defineMethod (c$, "getApplicationThread", 
function () {
return this.mAppThread;
});
c$.currentActivityThread = Clazz.defineMethod (c$, "currentActivityThread", 
function () {
return android.app.ActivityThread.sThreadLocal;
});
c$.currentApplication = Clazz.defineMethod (c$, "currentApplication", 
function () {
var am = android.app.ActivityThread.currentActivityThread ();
return am != null ? am.mInitialApplication : null;
});
c$.getPackageManager = Clazz.defineMethod (c$, "getPackageManager", 
function () {
return android.app.ActivityThread.sPackageManager;
});
Clazz.defineMethod (c$, "currentPackageName", 
function () {
return this.mProcessName;
});
Clazz.defineMethod (c$, "main", 
function (processName) {
this.mProcessName = processName;
android.os.Looper.prepareMainLooper ();
this.attach (false);
}, "~S");
Clazz.defineMethod (c$, "acquireProvider", 
function (c, name) {
if (android.app.ActivityThread.DEBUG_PROVIDER) System.out.println ("ActivityThread:acquireProvider(Context c, String name)");
var provider = this.getProvider (c, name);
if (provider == null) return null;
var jBinder = provider.asBinder ();
var prc = this.mProviderRefCountMap.get (jBinder);
if (prc == null) {
this.mProviderRefCountMap.put (jBinder, Clazz.innerTypeInstance (android.app.ActivityThread.ProviderRefCount, this, null, 1));
} else {
prc.count++;
}return provider;
}, "android.content.Context,~S");
Clazz.defineMethod (c$, "getProvider", 
($fz = function (context, name) {
var existing = this.getExistingProvider (context, name);
if (existing != null) {
return existing;
}var holder = null;
if (android.app.ActivityThread.DEBUG_PROVIDER) System.out.println ("ActivityThread:getContentProvider from ActivityManager");
holder = (android.content.Context.getSystemContext ().getSystemService ("activity")).getContentProvider (this.getApplicationThread (), name);
if (holder == null) {
System.out.println ("ActivityThread" + "Failed to find provider info for " + name);
return null;
}var prov = this.installProvider (context, holder.provider, holder.info, true);
if (prov == null) {
if (android.app.ActivityThread.DEBUG_PROVIDER) System.out.println ("ActivityThread provider installation falled...");
return null;
}if (holder.noReleaseNeeded || holder.provider == null) {
this.mProviderRefCountMap.put (prov.asBinder (), Clazz.innerTypeInstance (android.app.ActivityThread.ProviderRefCount, this, null, 10000));
}return prov;
}, $fz.isPrivate = true, $fz), "android.content.Context,~S");
Clazz.defineMethod (c$, "releaseProvider", 
function (provider) {
if (provider == null) {
return false;
}var jBinder = provider.asBinder ();
var prc = this.mProviderRefCountMap.get (jBinder);
if (prc == null) {
if (android.app.ActivityThread.DEBUG) android.util.Log.v ("ActivityThread", "releaseProvider::Weird shouldn't be here");
return false;
} else {
prc.count--;
if (prc.count == 0) {
}}return true;
}, "android.content.ContentProvider");
Clazz.defineMethod (c$, "installProvider", 
($fz = function (context, provider, info, noisy) {
var localProvider = null;
if (android.app.ActivityThread.DEBUG_PROVIDER) System.out.println ("ActivityThread installProvider...");
if (provider == null) {
if (noisy) {
android.util.Log.d ("ActivityThread", "Loading provider " + info.authority + ": " + info.name);
}var c = null;
var ai = info.applicationInfo;
if (context.getPackageName ().equals (ai.packageName)) {
c = context;
System.out.println ("this app");
} else if (this.mInitialApplication != null && this.mInitialApplication.getPackageName ().equals (ai.packageName)) {
c = this.mInitialApplication;
System.out.println ("init app");
} else {
System.out.println ("app:" + ai.packageName);
try {
c = context.createPackageContext (ai.packageName, this);
} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
} else {
throw e;
}
}
}if (c == null) {
android.util.Log.w ("ActivityThread", "Unable to get context for package " + ai.packageName + " while loading content provider " + info.name);
return null;
}try {
System.out.println ("Provider:" + info.name);
localProvider = (Class.forName (info.name).newInstance ());
if (android.app.ActivityThread.DEBUG_PROVIDER) System.out.println ("ActivityThread Provider is attached...");
provider = localProvider;
if (provider == null) {
android.util.Log.e ("ActivityThread", "Failed to instantiate class " + info.name + " from sourceDir " + info.applicationInfo.sourceDir);
return null;
}if (android.app.ActivityThread.DEBUG_PROVIDER) android.util.Log.v ("ActivityThread", "Instantiating local provider " + info.name);
localProvider.attachInfo (c, info);
if (android.app.ActivityThread.DEBUG_PROVIDER) System.out.println ("ActivityThread Provider is attached...");
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.d ("ActivityThread", "Exception occured...");
return null;
} else {
throw e;
}
}
} else if (android.app.ActivityThread.DEBUG) {
android.util.Log.v ("ActivityThread", "Installing external provider " + info.authority + ": " + info.name);
}if (android.app.ActivityThread.DEBUG_PROVIDER) System.out.println ("ActivityThread Provider ...");
var names = info.authority.$plit (";");
if (android.app.ActivityThread.DEBUG_PROVIDER) System.out.println ("ActivityThread Provider test...");
for (var i = 0; i < names.length; i++) {
this.mProviderMap.put (names[i], provider);
}
if (android.app.ActivityThread.DEBUG_PROVIDER) System.out.println ("ActivityThread Provider is installed...");
return provider;
}, $fz.isPrivate = true, $fz), "android.content.Context,android.content.ContentProvider,android.content.pm.ProviderInfo,~B");
Clazz.defineMethod (c$, "acquireExistingProvider", 
function (c, name) {
var provider = this.getExistingProvider (c, name);
if (provider == null) return null;
var jBinder = provider.asBinder ();
var prc = this.mProviderRefCountMap.get (jBinder);
if (prc == null) {
this.mProviderRefCountMap.put (jBinder, Clazz.innerTypeInstance (android.app.ActivityThread.ProviderRefCount, this, null, 1));
} else {
prc.count++;
}return provider;
}, "android.content.Context,~S");
Clazz.defineMethod (c$, "getExistingProvider", 
($fz = function (context, name) {
System.out.println ("Getting existing provider...");
var pr = this.mProviderMap.get (name);
if (pr != null) {
return pr;
}return null;
}, $fz.isPrivate = true, $fz), "android.content.Context,~S");
Clazz.defineMethod (c$, "attach", 
($fz = function (system) {
($t$ = android.app.ActivityThread.sThreadLocal = this, android.app.ActivityThread.prototype.sThreadLocal = android.app.ActivityThread.sThreadLocal, $t$);
if (system == false) {
var mgr = android.content.Context.getSystemContext ().getSystemService ("activity");
mgr.attachApplication (this.mAppThread, this.mProcessName);
}}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "queueOrSendMessage", 
($fz = function (what, obj, arg1, arg2) {
var msg = android.os.Message.obtain ();
msg.what = what;
msg.obj = obj;
msg.arg1 = arg1;
msg.arg2 = arg2;
this.mH.sendMessage (msg);
}, $fz.isPrivate = true, $fz), "~N,~O,~N,~N");
Clazz.defineMethod (c$, "getHandler", 
function () {
return this.mH;
});
Clazz.defineMethod (c$, "queueOrSendMessage", 
($fz = function (what, obj) {
this.queueOrSendMessage (what, obj, 0, 0);
}, $fz.isPrivate = true, $fz), "~N,~O");
Clazz.defineMethod (c$, "queueOrSendMessage", 
($fz = function (what, obj, arg1) {
this.queueOrSendMessage (what, obj, arg1, 0);
}, $fz.isPrivate = true, $fz), "~N,~O,~N");
Clazz.defineMethod (c$, "getPackageInfoNoCheck", 
function (ai) {
return this.getPackageInfo (ai, null, false, true);
}, "android.content.pm.ApplicationInfo");
Clazz.defineMethod (c$, "handleBindApplication", 
($fz = function (data) {
this.mBoundApplication = data;
data.info = this.getPackageInfoNoCheck (data.appInfo);
if ((data.appInfo.flags & (129)) != 0) {
}if ((data.appInfo.flags & 8192) == 0) {
android.graphics.Bitmap.setDefaultDensity (160);
}if (data.instrumentationName != null) {
var appContext =  new android.app.ContextImpl ();
appContext.init (data.info, null, this);
var ii = null;
ii = appContext.getPackageManager ().getInstrumentationInfo (data.instrumentationName, 0);
if (ii == null) {
throw  new RuntimeException ("Unable to find instrumentation info for: " + data.instrumentationName);
}this.mInstrumentationAppDir = ii.sourceDir;
this.mInstrumentationAppPackage = ii.packageName;
var instrApp =  new android.content.pm.ApplicationInfo ();
instrApp.packageName = ii.packageName;
instrApp.sourceDir = ii.sourceDir;
instrApp.publicSourceDir = ii.publicSourceDir;
instrApp.dataDir = ii.dataDir;
instrApp.nativeLibraryDir = ii.nativeLibraryDir;
var pi = this.getPackageInfo (instrApp, appContext.getClassLoader (), false, true);
var instrContext =  new android.app.ContextImpl ();
instrContext.init (pi, null, this);
try {
this.mInstrumentation = Class.forName (data.instrumentationName.getClassName ()).newInstance ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
throw  new RuntimeException ("Unable to instantiate instrumentation " + data.instrumentationName + ": " + e.toString (), e);
} else {
throw e;
}
}
this.mInstrumentation.init (this, instrContext, appContext,  new android.content.ComponentName (ii.packageName, ii.name), data.instrumentationWatcher);
if (data.profileFile != null && !ii.handleProfiling) {
data.handlingProfiling = true;
var file =  new java.io.File (data.profileFile);
file.getParentFile ().mkdirs ();
}try {
this.mInstrumentation.onCreate (data.instrumentationArgs);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
throw  new RuntimeException ("Exception thrown in onCreate() of " + data.instrumentationName + ": " + e.toString (), e);
} else {
throw e;
}
}
} else {
this.mInstrumentation =  new android.app.Instrumentation ();
}var app = data.info.makeApplication (data.restrictedBackupMode, null);
this.mInitialApplication = app;
var providers = data.providers;
if (providers != null) {
this.mH.sendEmptyMessageDelayed (132, 10000);
}try {
this.mInstrumentation.callApplicationOnCreate (app);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
if (!this.mInstrumentation.onException (app, e)) {
throw  new RuntimeException ("Unable to create application " + app.getClass ().getName () + ": " + e.toString (), e);
}} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.AppBindData");
Clazz.defineMethod (c$, "handleLaunchActivity", 
($fz = function (r, customIntent) {
var a = this.performLaunchActivity (r, customIntent);
if (a != null) {
var oldState = r.state;
this.handleResumeActivity (r.token, false, r.isForward);
if (!r.activity.mFinished && r.startsNotResumed) {
System.out.println ("if catched");
r.activity.mCalled = false;
this.mInstrumentation.callActivityOnPause (r.activity);
r.state = oldState;
if (!r.activity.mCalled) {
System.out.println ("Activity " + r.intent.getComponent ().toShortString () + " did not call through to super.onPause()");
}r.paused = true;
}} else {
(android.content.Context.getSystemContext ().getSystemService ("activity")).finishActivity (r.token, 0, null);
}}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.ActivityClientRecord,android.content.Intent");
Clazz.defineMethod (c$, "deliverNewIntents", 
($fz = function (r, intents) {
var N = intents.size ();
for (var i = 0; i < N; i++) {
var intent = intents.get (i);
intent.setExtrasClassLoader (r.activity.getClassLoader ());
}
}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.ActivityClientRecord,java.util.List");
Clazz.defineMethod (c$, "performNewIntents", 
function (token, intents) {
var r = this.mActivities.get (token);
if (r != null) {
var resumed = !r.paused;
if (resumed) {
this.mInstrumentation.callActivityOnPause (r.activity);
}this.deliverNewIntents (r, intents);
if (resumed) {
this.mInstrumentation.callActivityOnResume (r.activity);
}}}, "android.os.IBinder,java.util.List");
Clazz.defineMethod (c$, "getDisplayMetricsLocked", 
function (forceUpdate) {
if (this.mDisplayMetrics != null && !forceUpdate) {
return this.mDisplayMetrics;
}if (this.mDisplay == null) {
var wm = android.view.WindowManagerImpl.getDefault ();
this.mDisplay = wm.getDefaultDisplay ();
}var metrics = this.mDisplayMetrics =  new android.util.DisplayMetrics ();
this.mDisplay.getMetrics (metrics);
return metrics;
}, "~B");
Clazz.defineMethod (c$, "getPackageInfo", 
function (ai) {
return this.getPackageInfo (ai, null, false, false);
}, "android.content.pm.ApplicationInfo");
Clazz.defineMethod (c$, "getPackageInfo", 
function (packageName, flags) {
var packageInfo = null;
if ((flags & 1) != 0) {
packageInfo = this.mPackages.get (packageName);
} else {
packageInfo = this.mResourcePackages.get (packageName);
}if (packageInfo != null && (packageInfo.mResources == null || packageInfo.mResources.getAssets ().isUpToDate ())) {
return packageInfo;
}var ai = null;
if (ai != null) {
return this.getPackageInfo (ai, flags);
}return null;
}, "~S,~N");
Clazz.defineMethod (c$, "getPackageInfo", 
function (ai, flags) {
var includeCode = (flags & 1) != 0;
var securityViolation = false;
if ((flags & (3)) == 1) {
if (securityViolation) {
var msg = "Requesting code from " + ai.packageName + " (with uid " + ai.uid + ")";
if (this.mBoundApplication != null) {
msg = msg + " to be run in process " + this.mBoundApplication.processName + " (with uid " + this.mBoundApplication.appInfo.uid + ")";
}throw  new SecurityException (msg);
}}return this.getPackageInfo (ai, null, securityViolation, includeCode);
}, "android.content.pm.ApplicationInfo,~N");
Clazz.defineMethod (c$, "getPackageInfo", 
($fz = function (aInfo, baseLoader, securityViolation, includeCode) {
var packageInfo = this.mResourcePackages.get (aInfo.packageName);
if (packageInfo == null) {
packageInfo =  new android.app.LoadedApk (this, aInfo);
this.mResourcePackages.put (aInfo.packageName, packageInfo);
}return packageInfo;
}, $fz.isPrivate = true, $fz), "android.content.pm.ApplicationInfo,ClassLoader,~B,~B");
Clazz.defineMethod (c$, "getSystemContext", 
function () {
if (android.app.ActivityThread.mSystemContext == null) {
var context = android.app.ContextImpl.createSystemContext (this);
var info =  new android.app.LoadedApk (this, null);
context.init (info, null, this);
($t$ = android.app.ActivityThread.mSystemContext = context, android.app.ActivityThread.prototype.mSystemContext = android.app.ActivityThread.mSystemContext, $t$);
}return android.app.ActivityThread.mSystemContext;
});
Clazz.defineMethod (c$, "performLaunchActivity", 
($fz = function (r, customIntent) {
var aInfo = r.activityInfo;
if (r.packageInfo == null) {
r.packageInfo = this.getPackageInfo (aInfo.applicationInfo);
}var component = r.intent.getComponent ();
if (component == null) {
System.out.println ("component is null");
}if (r.activityInfo.targetActivity != null) {
component =  new android.content.ComponentName (r.activityInfo.packageName, r.activityInfo.targetActivity);
}var activity = null;
try {
activity = this.mInstrumentation.newActivity (component.getClassName (), r.intent);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
System.out.println (e.getMessage ());
} else {
throw e;
}
}
var app = r.packageInfo.makeApplication (false, this.mInstrumentation);
if (activity != null) {
activity.mZIndex = r.activityInfo.zIndex;
var appContext = null;
try {
appContext = android.content.Context.getSystemContext ().createPackageContext (r.activityInfo.packageName, this);
appContext.setLoadedApk (r.packageInfo);
appContext.setOuterContext (activity);
android.util.Log.i ("ActivityThread", "appContext is created:" + appContext.icount);
if (appContext.mActivityThread == null) {
System.out.println ("appContext's mActivityThread is null");
}} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
e.printStackTrace ();
} else {
throw e;
}
}
var dm = this.getDisplayMetricsLocked (true);
appContext.getResources ().updateConfiguration (null, dm);
var title = r.activityInfo.loadLabel (appContext.getPackageManager ());
activity.attach (appContext, this.mInstrumentation, title, this, r.token, r.intent, app);
android.content.Context.setOuterContext (activity);
System.out.println ("activity context in AT is:" + activity.icount);
if (activity.mActivityThread == null) {
System.out.println ("activity thread in AT is null");
}if (customIntent != null) {
activity.mIntent = customIntent;
}r.lastNonConfigurationInstance = null;
r.lastNonConfigurationChildInstances = null;
activity.mStartedActivity = false;
var theme = r.activityInfo.getThemeResource ();
if (theme != 0) {
activity.setTheme (theme);
}android.content.Context.getSystemContext ().getActivityManager ().mCurActivity = activity;
activity.mCalled = false;
this.mInstrumentation.callActivityOnCreate (activity, r.state);
if (!activity.mCalled) {
System.out.println ("Activity " + r.intent.getComponent ().toShortString () + " did not call through to super.onCreate()");
}r.activity = activity;
r.stopped = true;
if (!r.activity.mFinished) {
activity.performStart ();
r.stopped = false;
}if (!r.activity.mFinished) {
if (r.state != null) {
this.mInstrumentation.callActivityOnRestoreInstanceState (activity, r.state);
}}if (!r.activity.mFinished) {
activity.mCalled = false;
this.mInstrumentation.callActivityOnPostCreate (activity, r.state);
if (!activity.mCalled) {
System.out.println ("Activity " + r.intent.getComponent ().toShortString () + " did not call through to super.onPostCreate()");
}}}r.paused = true;
this.mActivities.put (r.token, r);
return activity;
}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.ActivityClientRecord,android.content.Intent");
Clazz.defineMethod (c$, "handlePauseActivity", 
($fz = function (token, finished, userLeaving, configChanges) {
var r = this.mActivities.get (token);
if (r != null) {
var state = this.performPauseActivity (token, finished, true);
android.content.Context.getSystemContext ().getActivityManager ().activityPaused (token, state);
}}, $fz.isPrivate = true, $fz), "android.os.IBinder,~B,~B,~N");
Clazz.defineMethod (c$, "performPauseActivity", 
function (token, finished, saveState) {
var r = this.mActivities.get (token);
return r != null ? this.performPauseActivity (r, finished, saveState) : null;
}, "android.os.IBinder,~B,~B");
Clazz.defineMethod (c$, "performPauseActivity", 
function (r, finished, saveState) {
if (r.paused) {
if (r.activity.mFinished) {
return null;
}var e =  new RuntimeException ("Performing pause of activity that is not resumed: " + r.intent.getComponent ().toShortString ());
System.out.println ("ActivityThread" + e.getMessage ());
}var state = null;
if (finished) {
r.activity.mFinished = true;
}if (!r.activity.mFinished && saveState) {
state =  new android.os.Bundle ();
this.mInstrumentation.callActivityOnSaveInstanceState (r.activity, state);
r.state = state;
}r.activity.mCalled = false;
this.mInstrumentation.callActivityOnPause (r.activity);
r.paused = true;
return state;
}, "android.app.ActivityThread.ActivityClientRecord,~B,~B");
Clazz.defineMethod (c$, "performStopActivity", 
function (token) {
var r = this.mActivities.get (token);
this.performStopActivityInner (r, false);
}, "android.os.IBinder");
Clazz.defineMethod (c$, "performStopActivityInner", 
($fz = function (r, keepShown) {
if (r != null) {
if (!keepShown && r.stopped) {
if (r.activity.mFinished) {
return ;
}var e =  new RuntimeException ("Performing stop of activity that is not resumed: " + r.intent.getComponent ().toShortString ());
android.util.Slog.e ("ActivityThread", e.getMessage (), e);
}if (!keepShown) {
try {
r.activity.performStop ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
if (!this.mInstrumentation.onException (r.activity, e)) {
throw  new RuntimeException ("Unable to stop activity " + r.intent.getComponent ().toShortString () + ": " + e.toString (), e);
}} else {
throw e;
}
}
r.stopped = true;
}r.paused = true;
}}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.ActivityClientRecord,~B");
Clazz.defineMethod (c$, "handleResumeActivity", 
function (token, clearHide, isForward) {
var r = this.performResumeActivity (token, clearHide);
if (r != null) {
android.content.Context.getSystemContext ().getActivityManager ().mCurActivity = r.activity;
var a = r.activity;
var forwardBit = isForward ? 256 : 0;
var willBeVisible = !a.mStartedActivity;
if (!willBeVisible) {
}if (r.window == null && !a.mFinished && willBeVisible) {
r.window = r.activity.getWindow ();
var decor = r.window.getDecorView ();
decor.zIndex = r.activity.mZIndex;
decor.setVisibility (4);
var wm = a.getWindowManager ();
var l = r.window.getAttributes ();
a.mDecor = decor;
l.type = 1;
l.softInputMode |= forwardBit;
if (a.mVisibleFromClient) {
a.mWindowAdded = true;
wm.addView (decor, l);
}} else if (!willBeVisible) {
r.hideForNow = true;
}if (!r.activity.mFinished && willBeVisible && r.activity.mDecor != null && !r.hideForNow) {
var l = r.window.getAttributes ();
if ((l.softInputMode & 256) != forwardBit) {
l.softInputMode = (l.softInputMode & (-257)) | forwardBit;
if (r.activity.mVisibleFromClient) {
var wm = a.getWindowManager ();
var decor = r.window.getDecorView ();
wm.updateViewLayout (decor, l);
}}r.activity.mVisibleFromServer = true;
this.mNumVisibleActivities++;
if (r.activity.mVisibleFromClient) {
r.activity.makeVisible ();
}}r.nextIdle = this.mNewActivities;
this.mNewActivities = r;
} else {
(android.content.Context.getSystemContext ().getSystemService ("activity")).finishActivity (token, 0, null);
}}, "android.os.IBinder,~B,~B");
Clazz.defineMethod (c$, "handleCreateService", 
($fz = function (data) {
var service = null;
try {
service = Class.forName (data.info.name).newInstance ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
System.out.println (e.getMessage ());
} else {
throw e;
}
}
try {
var context = android.content.Context.getSystemContext ().createPackageContext (data.info.packageName, this);
service.attach (context, this, data.info.name, data.token, android.content.Context.getSystemContext ().getActivityManager ());
android.content.Context.setOuterContext (service);
System.out.println ("service context in AT is:" + service.icount);
service.onCreate ();
this.mServices.put (data.token, service);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
System.out.println (e.getMessage ());
} else {
throw e;
}
}
}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.CreateServiceData");
Clazz.defineMethod (c$, "handleServiceArgs", 
($fz = function (data) {
var s = this.mServices.get (data.token);
if (s != null) {
if (data.args != null) {
data.args.setExtrasClassLoader (s.getClassLoader ());
}var res;
res = s.onStartCommand (data.args, data.flags, data.startId);
}}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.ServiceArgsData");
Clazz.defineMethod (c$, "handleBindService", 
($fz = function (data) {
var s = this.mServices.get (data.token);
if (s != null) {
data.intent.setExtrasClassLoader (s.getClassLoader ());
if (!data.rebind) {
var binder = s.onBind (data.intent);
android.content.Context.getSystemContext ().getActivityManager ().publishService (data.token, data.intent, binder);
} else {
s.onRebind (data.intent);
}}}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.BindServiceData");
Clazz.defineMethod (c$, "resolveActivityInfo", 
function (intent) {
var aInfo = intent.resolveActivityInfo (this.mInitialApplication.getPackageManager (), 1024);
if (aInfo == null) {
android.app.Instrumentation.checkStartActivityResult (-2, intent);
}return aInfo;
}, "android.content.Intent");
Clazz.defineMethod (c$, "startActivityNow", 
function (parent, id, intent, activityInfo, token, state, lastNonConfigurationInstance) {
var r =  new android.app.ActivityThread.ActivityClientRecord ();
r.token = token;
r.ident = 0;
r.intent = intent;
r.state = state;
r.parent = parent;
r.embeddedID = id;
r.activityInfo = activityInfo;
r.lastNonConfigurationInstance = lastNonConfigurationInstance;
return this.performLaunchActivity (r, null);
}, "android.app.Activity,~S,android.content.Intent,android.content.pm.ActivityInfo,android.os.IBinder,android.os.Bundle,~O");
Clazz.defineMethod (c$, "performResumeActivity", 
function (token, clearHide) {
var r = this.mActivities.get (token);
if (r != null && !r.activity.mFinished) {
if (clearHide) {
r.hideForNow = false;
r.activity.mStartedActivity = false;
}r.activity.performResume ();
r.paused = false;
r.stopped = false;
r.state = null;
}return r;
}, "android.os.IBinder,~B");
Clazz.defineMethod (c$, "sendActivityResult", 
function (token, id, requestCode, resultCode, data) {
System.out.println ("ActivityThread" + "sendActivityResult: id=" + id + " req=" + requestCode + " res=" + resultCode + " data=");
var list =  new java.util.ArrayList ();
list.add ( new android.app.ResultInfo (id, requestCode, resultCode, data));
this.mAppThread.scheduleSendResult (token, list);
}, "android.os.IBinder,~S,~N,~N,android.content.Intent");
Clazz.defineMethod (c$, "handleDestroyActivity", 
($fz = function (token, finishing, configChanges, getNonConfigInstance) {
var r = this.performDestroyActivity (token, finishing, configChanges, getNonConfigInstance);
if (r != null) {
var wm = r.activity.getWindowManager ();
var v = r.activity.mDecor;
if (v != null) {
if (r.activity.mVisibleFromServer) {
this.mNumVisibleActivities--;
}if (r.activity.mWindowAdded) {
wm.removeViewImmediate (v);
}r.activity.mDecor = null;
}}if (finishing) {
android.content.Context.getSystemContext ().getActivityManager ().activityDestroyed (token);
}}, $fz.isPrivate = true, $fz), "android.os.IBinder,~B,~N,~B");
Clazz.defineMethod (c$, "performDestroyActivity", 
function (token, finishing) {
return this.performDestroyActivity (token, finishing, 0, false);
}, "android.os.IBinder,~B");
Clazz.defineMethod (c$, "performDestroyActivity", 
($fz = function (token, finishing, configChanges, getNonConfigInstance) {
var r = this.mActivities.get (token);
if (r != null) {
android.util.Log.i ("ActivityThread", "Performing finish of " + r.activityInfo.name);
if (finishing) {
r.activity.mFinished = true;
}if (!r.paused) {
r.activity.mCalled = false;
this.mInstrumentation.callActivityOnPause (r.activity);
if (!r.activity.mCalled) {
System.out.println ("Activity did not call through to super.onPause()");
}r.paused = true;
}if (!r.stopped) {
r.activity.performStop ();
r.stopped = true;
}r.activity.mCalled = false;
r.activity.onDestroy ();
if (!r.activity.mCalled) {
System.out.println ("Activity did not call through to super.onDestroy()");
}if (r.window != null) {
r.window.closeAllPanels ();
r.window.getDecorView ().destroy ();
}}this.mActivities.remove (token);
return r;
}, $fz.isPrivate = true, $fz), "android.os.IBinder,~B,~N,~B");
Clazz.defineMethod (c$, "handleSendResult", 
($fz = function (res) {
var r = this.mActivities.get (res.token);
System.out.println ("ActivityThread" + "Handling send result to " + r.activityInfo.name);
if (r != null) {
var resumed = !r.paused;
if (!r.activity.mFinished && r.activity.mDecor != null && r.hideForNow && resumed) {
this.updateVisibility (r, true);
}if (resumed) {
r.activity.mCalled = false;
this.mInstrumentation.callActivityOnPause (r.activity);
if (!r.activity.mCalled) {
System.out.println ("Activity did not call through to super.onPause()");
}}this.deliverResults (r, res.results);
if (resumed) {
this.mInstrumentation.callActivityOnResume (r.activity);
}}}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.ResultData");
Clazz.defineMethod (c$, "updateVisibility", 
($fz = function (r, show) {
var v = r.activity.mDecor;
if (v != null) {
if (show) {
if (!r.activity.mVisibleFromServer) {
r.activity.mVisibleFromServer = true;
this.mNumVisibleActivities++;
if (r.activity.mVisibleFromClient) {
r.activity.makeVisible ();
}}} else {
if (r.activity.mVisibleFromServer) {
r.activity.mVisibleFromServer = false;
this.mNumVisibleActivities--;
v.setVisibility (4);
}}}}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.ActivityClientRecord,~B");
Clazz.defineMethod (c$, "performRestartActivity", 
function (token) {
var r = this.mActivities.get (token);
if (r.stopped) {
r.stopped = false;
}}, "android.os.IBinder");
Clazz.defineMethod (c$, "deliverResults", 
($fz = function (r, results) {
var N = results.size ();
for (var i = 0; i < N; i++) {
var ri = results.get (i);
if (ri.mData != null) {
ri.mData.setExtrasClassLoader (r.activity.getClassLoader ());
System.out.println ("ActivityThread" + "Delivering result to activity " + r.activityInfo.name + " : " + ri.mData.getAction ());
}r.activity.dispatchActivityResult (ri.mResultWho, ri.mRequestCode, ri.mResultCode, ri.mData);
}
}, $fz.isPrivate = true, $fz), "android.app.ActivityThread.ActivityClientRecord,java.util.List");
Clazz.defineMethod (c$, "getApplication", 
function () {
return this.mInitialApplication;
});
Clazz.defineMethod (c$, "finishInstrumentation", 
function (resultCode, results) {
android.content.Context.getSystemContext ().getActivityManager ().finishInstrumentation (this.mAppThread, resultCode, results);
}, "~N,android.os.Bundle");
Clazz.defineMethod (c$, "getInstrumentation", 
function () {
return this.mInstrumentation;
});
c$.$ActivityThread$ProviderRefCount$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.count = 0;
Clazz.instantialize (this, arguments);
}, android.app.ActivityThread, "ProviderRefCount");
Clazz.makeConstructor (c$, 
function (a) {
this.count = a;
}, "~N");
c$ = Clazz.p0p ();
};
c$.$ActivityThread$ApplicationThread$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.SCHEDULE_PAUSE_ACTIVITY_TRANSACTION = 1;
this.SCHEDULE_STOP_ACTIVITY_TRANSACTION = 3;
this.SCHEDULE_WINDOW_VISIBILITY_TRANSACTION = 4;
this.SCHEDULE_RESUME_ACTIVITY_TRANSACTION = 5;
this.SCHEDULE_SEND_RESULT_TRANSACTION = 6;
this.SCHEDULE_LAUNCH_ACTIVITY_TRANSACTION = 7;
this.SCHEDULE_FINISH_ACTIVITY_TRANSACTION = 9;
Clazz.instantialize (this, arguments);
}, android.app.ActivityThread, "ApplicationThread", android.os.Binder, android.app.IApplicationThread);
Clazz.overrideMethod (c$, "onTransact", 
function (a, b, c, d) {
switch (a) {
case 1:
{
b.enforceInterface ("android.app.ApplicationThread");
var e = b.readStrongBinder ();
var f = false;
var g = false;
var h = 0;
this.schedulePauseActivity (e, f, g, h);
return true;
}case 5:
{
b.enforceInterface ("android.app.ApplicationThread");
var e = b.readStrongBinder ();
var f = false;
this.scheduleResumeActivity (e, f);
return true;
}}
return false;
}, "~N,android.os.Parcel,android.os.Parcel,~N");
Clazz.overrideMethod (c$, "schedulePauseActivity", 
function (a, b, c, d) {
this.b$["android.app.ActivityThread"].queueOrSendMessage (b ? 102 : 101, a, (c ? 1 : 0), d);
}, "android.os.IBinder,~B,~B,~N");
Clazz.overrideMethod (c$, "scheduleStopActivity", 
function (a, b, c) {
this.b$["android.app.ActivityThread"].queueOrSendMessage (b ? 103 : 104, a, 0, c);
}, "android.os.IBinder,~B,~N");
Clazz.overrideMethod (c$, "scheduleWindowVisibility", 
function (a, b) {
this.b$["android.app.ActivityThread"].queueOrSendMessage (b ? 105 : 106, a);
}, "android.os.IBinder,~B");
Clazz.overrideMethod (c$, "scheduleResumeActivity", 
function (a, b) {
this.b$["android.app.ActivityThread"].queueOrSendMessage (107, a, b ? 1 : 0);
}, "android.os.IBinder,~B");
Clazz.overrideMethod (c$, "scheduleSendResult", 
function (a, b) {
var c =  new android.app.ActivityThread.ResultData ();
c.token = a;
c.results = b;
this.b$["android.app.ActivityThread"].queueOrSendMessage (108, c);
}, "android.os.IBinder,java.util.List");
Clazz.overrideMethod (c$, "scheduleLaunchActivity", 
function (a, b, c, d, e, f, g, h, i) {
var j =  new android.app.ActivityThread.ActivityClientRecord ();
j.token = b;
j.ident = c;
j.intent = a;
j.activityInfo = d;
j.state = e;
j.pendingResults = f;
j.pendingIntents = g;
j.startsNotResumed = h;
j.isForward = i;
this.b$["android.app.ActivityThread"].queueOrSendMessage (100, j);
}, "android.content.Intent,android.os.IBinder,~N,android.content.pm.ActivityInfo,android.os.Bundle,java.util.List,java.util.List,~B,~B");
Clazz.overrideMethod (c$, "scheduleDestroyActivity", 
function (a, b, c) {
this.b$["android.app.ActivityThread"].queueOrSendMessage (109, a, b ? 1 : 0, c);
}, "android.os.IBinder,~B,~N");
Clazz.defineMethod (c$, "scheduleCreateService", 
function (a, b) {
var c =  new android.app.ActivityThread.CreateServiceData ();
c.token = a;
c.info = b;
this.b$["android.app.ActivityThread"].queueOrSendMessage (114, c);
}, "android.os.IBinder,android.content.pm.ServiceInfo");
Clazz.defineMethod (c$, "scheduleBindService", 
function (a, b, c) {
var d =  new android.app.ActivityThread.BindServiceData ();
d.token = a;
d.intent = b;
d.rebind = c;
this.b$["android.app.ActivityThread"].queueOrSendMessage (121, d);
}, "android.os.IBinder,android.content.Intent,~B");
Clazz.defineMethod (c$, "scheduleServiceArgs", 
function (a, b, c, d) {
var e =  new android.app.ActivityThread.ServiceArgsData ();
e.token = a;
e.startId = b;
e.flags = c;
e.args = d;
this.b$["android.app.ActivityThread"].queueOrSendMessage (115, e);
}, "android.app.ServiceRecord,~N,~N,android.content.Intent");
Clazz.overrideMethod (c$, "bindApplication", 
function (a, b, c, d, e, f, g) {
var h =  new android.app.ActivityThread.AppBindData ();
h.processName = a;
h.appInfo = b;
h.instrumentationName = c;
h.profileFile = d;
h.instrumentationArgs = e;
h.debugMode = f;
h.restrictedBackupMode = g;
this.b$["android.app.ActivityThread"].queueOrSendMessage (110, h);
}, "~S,android.content.pm.ApplicationInfo,android.content.ComponentName,~S,android.os.Bundle,~N,~B");
Clazz.overrideMethod (c$, "asBinder", 
function () {
return this;
});
Clazz.defineMethod (c$, "getHandler", 
function () {
return this.b$["android.app.ActivityThread"].mH;
});
Clazz.defineStatics (c$,
"descriptor", "android.app.ApplicationThread");
c$ = Clazz.p0p ();
};
c$.$ActivityThread$H$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.app.ActivityThread, "H", android.os.Handler);
Clazz.defineMethod (c$, "codeToString", 
function (a) {
if (false) {
switch (a) {
case 101:
return "PAUSE_ACTIVITY";
case 102:
return "PAUSE_ACTIVITY_FINISHING";
case 107:
return "RESUME_ACTIVITY";
}
}return "(unknown)";
}, "~N");
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
if (false) android.util.Slog.v ("ActivityThread", ">>> handling: " + a.what);
switch (a.what) {
case 100:
{
var b = a.obj;
b.packageInfo = this.b$["android.app.ActivityThread"].getPackageInfoNoCheck (b.activityInfo.applicationInfo);
this.b$["android.app.ActivityThread"].handleLaunchActivity (b, null);
}break;
case 126:
{
var b = a.obj;
android.util.Log.e ("ActivityThread", "RelaunchActivity is not handled now!");
}break;
case 101:
this.b$["android.app.ActivityThread"].handlePauseActivity (a.obj, false, a.arg1 != 0, a.arg2);
break;
case 102:
this.b$["android.app.ActivityThread"].handlePauseActivity (a.obj, true, a.arg1 != 0, a.arg2);
break;
case 103:
android.util.Log.e ("ActivityThread", "StopActivityShow is not handled now!");
break;
case 104:
android.util.Log.e ("ActivityThread", "StopActivityHide is not handled now!");
break;
case 105:
android.util.Log.e ("ActivityThread", "WindowVisibilityShow is not handled now!");
break;
case 106:
android.util.Log.e ("ActivityThread", "WindowVisibilityHide is not handled now!");
break;
case 107:
this.b$["android.app.ActivityThread"].handleResumeActivity (a.obj, true, a.arg1 != 0);
break;
case 108:
this.b$["android.app.ActivityThread"].handleSendResult (a.obj);
break;
case 109:
this.b$["android.app.ActivityThread"].handleDestroyActivity (a.obj, a.arg1 != 0, a.arg2, false);
break;
case 110:
var b = a.obj;
this.b$["android.app.ActivityThread"].handleBindApplication (b);
break;
case 111:
if (this.b$["android.app.ActivityThread"].mInitialApplication != null) {
this.b$["android.app.ActivityThread"].mInitialApplication.onTerminate ();
}android.os.Looper.myLooper ().quit ();
break;
case 112:
android.util.Log.e ("ActivityThread", "NewIntent is not handled now!");
break;
case 113:
android.util.Log.e ("ActivityThread", "Receiver is not handled now!");
break;
case 114:
this.b$["android.app.ActivityThread"].handleCreateService (a.obj);
break;
case 121:
this.b$["android.app.ActivityThread"].handleBindService (a.obj);
break;
case 122:
android.util.Log.e ("ActivityThread", "UnbindService is not handled now!");
break;
case 115:
this.b$["android.app.ActivityThread"].handleServiceArgs (a.obj);
break;
case 116:
android.util.Log.e ("ActivityThread", "StopService is not handled now!");
break;
case 117:
android.util.Log.e ("ActivityThread", "RequestThumbnail is not handled now!");
break;
case 118:
android.util.Log.e ("ActivityThread", "ConfigurationChanged is not handled now!");
break;
case 119:
android.util.Log.e ("ActivityThread", "CLEAN_UP_CONTEXT is not handled now!");
break;
case 120:
android.util.Log.e ("ActivityThread", "GC_WHEN_IDLE is not handled now!");
break;
case 123:
android.util.Log.e ("ActivityThread", "DumpService is not handled now!");
break;
case 124:
android.util.Log.e ("ActivityThread", "LowMemory is not handled now!");
break;
case 125:
android.util.Log.e ("ActivityThread", "ActivityConfigurationChanged is not handled now!");
break;
case 127:
android.util.Log.e ("ActivityThread", "ProfilerControl is not handled now!");
break;
case 128:
android.util.Log.e ("ActivityThread", "CreateBackupAgent is not handled now!");
break;
case 129:
android.util.Log.e ("ActivityThread", "DestroyBackupAgent is not handled now!");
break;
case 130:
android.util.Log.e ("ActivityThread", "SUICIDE is not handled now!");
break;
case 131:
android.util.Log.e ("ActivityThread", "RemoveProvider is not handled now!");
break;
case 132:
android.util.Log.e ("ActivityThread", "ENABLE_JIT is not handled now!");
break;
case 133:
android.util.Log.e ("ActivityThread", "DispatchPackageBroadcast is not handled now!");
break;
case 134:
throw  new android.app.RemoteServiceException (a.obj);
}
if (false) android.util.Slog.v ("ActivityThread", "<<< done: " + a.what);
}, "android.os.Message");
Clazz.defineStatics (c$,
"LAUNCH_ACTIVITY", 100,
"PAUSE_ACTIVITY", 101,
"PAUSE_ACTIVITY_FINISHING", 102,
"STOP_ACTIVITY_SHOW", 103,
"STOP_ACTIVITY_HIDE", 104,
"SHOW_WINDOW", 105,
"HIDE_WINDOW", 106,
"RESUME_ACTIVITY", 107,
"SEND_RESULT", 108,
"DESTROY_ACTIVITY", 109,
"BIND_APPLICATION", 110,
"EXIT_APPLICATION", 111,
"NEW_INTENT", 112,
"RECEIVER", 113,
"CREATE_SERVICE", 114,
"SERVICE_ARGS", 115,
"STOP_SERVICE", 116,
"REQUEST_THUMBNAIL", 117,
"CONFIGURATION_CHANGED", 118,
"CLEAN_UP_CONTEXT", 119,
"GC_WHEN_IDLE", 120,
"BIND_SERVICE", 121,
"UNBIND_SERVICE", 122,
"DUMP_SERVICE", 123,
"LOW_MEMORY", 124,
"ACTIVITY_CONFIGURATION_CHANGED", 125,
"RELAUNCH_ACTIVITY", 126,
"PROFILER_CONTROL", 127,
"CREATE_BACKUP_AGENT", 128,
"DESTROY_BACKUP_AGENT", 129,
"SUICIDE", 130,
"REMOVE_PROVIDER", 131,
"ENABLE_JIT", 132,
"DISPATCH_PACKAGE_BROADCAST", 133,
"SCHEDULE_CRASH", 134);
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.info = null;
this.processName = null;
this.appInfo = null;
this.providers = null;
this.instrumentationName = null;
this.profileFile = null;
this.instrumentationArgs = null;
this.instrumentationWatcher = null;
this.debugMode = 0;
this.restrictedBackupMode = false;
this.config = null;
this.handlingProfiling = false;
Clazz.instantialize (this, arguments);
}, android.app.ActivityThread, "AppBindData");
Clazz.overrideMethod (c$, "toString", 
function () {
return "AppBindData{appInfo=" + this.appInfo + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.pendingResults = null;
this.token = null;
this.ident = 0;
this.intent = null;
this.state = null;
this.activity = null;
this.window = null;
this.parent = null;
this.embeddedID = null;
this.lastNonConfigurationInstance = null;
this.lastNonConfigurationChildInstances = null;
this.paused = false;
this.stopped = false;
this.hideForNow = false;
this.newConfig = null;
this.createdConfig = null;
this.nextIdle = null;
this.activityInfo = null;
this.packageInfo = null;
this.pendingIntents = null;
this.startsNotResumed = false;
this.isForward = false;
Clazz.instantialize (this, arguments);
}, android.app.ActivityThread, "ActivityClientRecord");
Clazz.makeConstructor (c$, 
function () {
this.parent = null;
this.embeddedID = null;
this.paused = false;
this.stopped = false;
this.hideForNow = false;
this.nextIdle = null;
});
Clazz.overrideMethod (c$, "toString", 
function () {
var a = this.intent.getComponent ();
return "ActivityRecord{ token=" + this.token + " " + (a == null ? "no component name" : a.toShortString ()) + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.token = null;
this.results = null;
Clazz.instantialize (this, arguments);
}, android.app.ActivityThread, "ResultData");
Clazz.overrideMethod (c$, "toString", 
function () {
System.out.println ("ResultData.toString()");
return "ResultData{token=" + this.token + " results" + this.results + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.token = null;
this.info = null;
this.intent = null;
Clazz.instantialize (this, arguments);
}, android.app.ActivityThread, "CreateServiceData");
Clazz.overrideMethod (c$, "toString", 
function () {
return "CreateServiceData{token=" + this.token + " className=" + this.info.name + " packageName=" + this.info.packageName + " intent=" + this.intent + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.token = null;
this.intent = null;
this.rebind = false;
Clazz.instantialize (this, arguments);
}, android.app.ActivityThread, "BindServiceData");
Clazz.overrideMethod (c$, "toString", 
function () {
return "BindServiceData{token=" + this.token + " intent=" + this.intent + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.token = null;
this.startId = 0;
this.flags = 0;
this.args = null;
Clazz.instantialize (this, arguments);
}, android.app.ActivityThread, "ServiceArgsData");
Clazz.overrideMethod (c$, "toString", 
function () {
return "ServiceArgsData{token=" + this.token + " startId=" + this.startId + " args=" + this.args + "}";
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "ActivityThread",
"DEBUG_PROVIDER", true,
"DEBUG_MESSAGES", false,
"DEBUG", true,
"mSystemContext", null,
"sPackageManager", null);
c$.sThreadLocal = c$.prototype.sThreadLocal =  new android.app.ActivityThread ();
c$.PATTERN_SEMICOLON = c$.prototype.PATTERN_SEMICOLON = java.util.regex.Pattern.compile (";");
Clazz.defineStatics (c$,
"DEBUG_BROADCAST", false);
});
