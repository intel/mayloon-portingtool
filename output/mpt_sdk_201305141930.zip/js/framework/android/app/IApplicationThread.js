﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.IInterface"], "android.app.IApplicationThread", null, function () {
c$ = Clazz.declareInterface (android.app, "IApplicationThread", android.os.IInterface);
Clazz.defineStatics (c$,
"DEBUG_OFF", 0,
"DEBUG_ON", 1,
"DEBUG_WAIT", 2);
});
