﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.content.ContextWrapper"], "android.app.ReceiverRestrictedContext", ["android.content.ReceiverCallNotAllowedException"], function () {
c$ = Clazz.declareType (android.app, "ReceiverRestrictedContext", android.content.ContextWrapper);
Clazz.defineMethod (c$, "registerReceiver", 
function (receiver, filter) {
return this.registerReceiver (receiver, filter, null, null);
}, "android.content.BroadcastReceiver,android.content.IntentFilter");
Clazz.defineMethod (c$, "registerReceiver", 
function (receiver, filter, broadcastPermission, scheduler) {
throw  new android.content.ReceiverCallNotAllowedException ("IntentReceiver components are not allowed to register to receive intents");
}, "android.content.BroadcastReceiver,android.content.IntentFilter,~S,android.os.Handler");
Clazz.overrideMethod (c$, "bindService", 
function (service, conn, flags) {
throw  new android.content.ReceiverCallNotAllowedException ("IntentReceiver components are not allowed to bind to services");
}, "android.content.Intent,android.content.ServiceConnection,~N");
});
