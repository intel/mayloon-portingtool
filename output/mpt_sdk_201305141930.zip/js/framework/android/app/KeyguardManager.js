﻿Clazz.declarePackage ("android.app");
c$ = Clazz.decorateAsClass (function () {
if (!Clazz.isClassDefined ("android.app.KeyguardManager.KeyguardLock")) {
android.app.KeyguardManager.$KeyguardManager$KeyguardLock$ ();
}
Clazz.instantialize (this, arguments);
}, android.app, "KeyguardManager");
Clazz.defineMethod (c$, "inKeyguardRestrictedInputMode", 
function () {
return false;
});
Clazz.defineMethod (c$, "newKeyguardLock", 
function (tag) {
return Clazz.innerTypeInstance (android.app.KeyguardManager.KeyguardLock, this, null, tag);
}, "~S");
Clazz.defineMethod (c$, "exitKeyguardSecurely", 
function (callback) {
console.log("Missing method: exitKeyguardSecurely");
}, "~O");
c$.$KeyguardManager$KeyguardLock$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mTag = null;
Clazz.instantialize (this, arguments);
}, android.app.KeyguardManager, "KeyguardLock");
Clazz.makeConstructor (c$, 
function (a) {
this.mTag = a;
}, "~S");
Clazz.defineMethod (c$, "disableKeyguard", 
function () {
});
Clazz.defineMethod (c$, "reenableKeyguard", 
function () {
});
c$ = Clazz.p0p ();
};
