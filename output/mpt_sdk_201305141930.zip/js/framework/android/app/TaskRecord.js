﻿Clazz.declarePackage ("android.app");
Clazz.load (null, "android.app.TaskRecord", ["android.content.ComponentName", "$.Intent", "android.os.SystemClock", "java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.taskId = 0;
this.affinity = null;
this.clearOnBackground = false;
this.intent = null;
this.affinityIntent = null;
this.origActivity = null;
this.realActivity = null;
this.numActivities = 0;
this.lastActiveTime = 0;
this.rootWasReset = false;
this.stringName = null;
Clazz.instantialize (this, arguments);
}, android.app, "TaskRecord");
Clazz.makeConstructor (c$, 
function (_taskId, info, _intent, _clearOnBackground) {
this.taskId = _taskId;
this.affinity = info.taskAffinity;
this.clearOnBackground = _clearOnBackground;
this.setIntent (_intent, info);
}, "~N,android.content.pm.ActivityInfo,android.content.Intent,~B");
Clazz.defineMethod (c$, "touchActiveTime", 
function () {
this.lastActiveTime = android.os.SystemClock.elapsedRealtime ();
});
Clazz.defineMethod (c$, "getInactiveDuration", 
function () {
return android.os.SystemClock.elapsedRealtime () - this.lastActiveTime;
});
Clazz.defineMethod (c$, "setIntent", 
function (_intent, info) {
this.stringName = null;
if (info.targetActivity == null) {
this.intent = _intent;
this.realActivity = _intent != null ? _intent.getComponent () : null;
this.origActivity = null;
} else {
var targetComponent =  new android.content.ComponentName (info.packageName, info.targetActivity);
if (_intent != null) {
var targetIntent =  new android.content.Intent (_intent);
targetIntent.setComponent (targetComponent);
this.intent = targetIntent;
this.realActivity = targetComponent;
this.origActivity = _intent.getComponent ();
} else {
this.intent = null;
this.realActivity = targetComponent;
this.origActivity =  new android.content.ComponentName (info.packageName, info.name);
}}if (this.intent != null && (this.intent.getFlags () & 2097152) != 0) {
this.rootWasReset = true;
}}, "android.content.Intent,android.content.pm.ActivityInfo");
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
if (this.clearOnBackground || this.numActivities != 0 || this.rootWasReset) {
pw.print (prefix);
pw.print ("clearOnBackground=");
pw.print (this.clearOnBackground);
pw.print (" numActivities=");
pw.print (this.numActivities);
pw.print (" rootWasReset=");
pw.println (this.rootWasReset);
}if (this.affinity != null) {
pw.print (prefix);
pw.print ("affinity=");
pw.println (this.affinity);
}if (this.intent != null) {
var sb =  new StringBuilder (128);
sb.append (prefix);
sb.append ("intent={");
this.intent.toShortString (sb, true, false);
sb.append ('}');
pw.println (sb.toString ());
}if (this.affinityIntent != null) {
var sb =  new StringBuilder (128);
sb.append (prefix);
sb.append ("affinityIntent={");
this.affinityIntent.toShortString (sb, true, false);
sb.append ('}');
pw.println (sb.toString ());
}if (this.origActivity != null) {
pw.print (prefix);
pw.print ("origActivity=");
pw.println (this.origActivity.flattenToShortString ());
}if (this.realActivity != null) {
pw.print (prefix);
pw.print ("realActivity=");
pw.println (this.realActivity.flattenToShortString ());
}pw.print (prefix);
pw.print ("lastActiveTime=");
pw.print (this.lastActiveTime);
pw.print (" (inactive for ");
pw.print ((Math.floor (this.getInactiveDuration () / 1000)));
pw.println ("s)");
}, "java.io.PrintWriter,~S");
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.stringName != null) {
return this.stringName;
}var sb =  new StringBuilder (128);
sb.append ("TaskRecord{");
sb.append (" #");
sb.append (this.taskId);
if (this.affinity != null) {
sb.append (" A ");
sb.append (this.affinity);
} else if (this.intent != null) {
sb.append (" I ");
sb.append (this.intent.getComponent ().flattenToShortString ());
} else if (this.affinityIntent != null) {
sb.append (" aI ");
sb.append (this.affinityIntent.getComponent ().flattenToShortString ());
} else {
sb.append (" ??");
}sb.append ('}');
return this.stringName = sb.toString ();
});
});
