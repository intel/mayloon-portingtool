﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.content.ComponentCallbacks", "$.ContextWrapper"], "android.app.Application", null, function () {
c$ = Clazz.declareType (android.app, "Application", android.content.ContextWrapper, android.content.ComponentCallbacks);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.app.Application, [null]);
});
Clazz.defineMethod (c$, "onCreate", 
function () {
});
Clazz.defineMethod (c$, "onTerminate", 
function () {
});
Clazz.overrideMethod (c$, "onConfigurationChanged", 
function (newConfig) {
}, "android.content.res.Configuration");
Clazz.overrideMethod (c$, "onLowMemory", 
function () {
});
Clazz.defineMethod (c$, "attach", 
function (context) {
this.attachBaseContext (context);
}, "android.content.Context");
});
