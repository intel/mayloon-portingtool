﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.util.AndroidRuntimeException"], "android.app.RemoteServiceException", null, function () {
c$ = Clazz.declareType (android.app, "RemoteServiceException", android.util.AndroidRuntimeException);
});
