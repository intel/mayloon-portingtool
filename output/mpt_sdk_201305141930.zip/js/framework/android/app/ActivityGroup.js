﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.app.Activity"], "android.app.ActivityGroup", ["android.app.LocalActivityManager"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mLocalActivityManager = null;
Clazz.instantialize (this, arguments);
}, android.app, "ActivityGroup", android.app.Activity);
Clazz.makeConstructor (c$, 
function () {
this.construct (true);
});
Clazz.makeConstructor (c$, 
function (singleActivityMode) {
Clazz.superConstructor (this, android.app.ActivityGroup, []);
this.mLocalActivityManager =  new android.app.LocalActivityManager (this, singleActivityMode);
}, "~B");
Clazz.defineMethod (c$, "onCreate", 
function (savedInstanceState) {
Clazz.superCall (this, android.app.ActivityGroup, "onCreate", [savedInstanceState]);
var states = savedInstanceState != null ? savedInstanceState.getBundle ("android:states") : null;
this.mLocalActivityManager.dispatchCreate (states);
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onResume", 
function () {
Clazz.superCall (this, android.app.ActivityGroup, "onResume", []);
this.mLocalActivityManager.dispatchResume ();
});
Clazz.defineMethod (c$, "onSaveInstanceState", 
function (outState) {
Clazz.superCall (this, android.app.ActivityGroup, "onSaveInstanceState", [outState]);
var state = this.mLocalActivityManager.saveInstanceState ();
if (state != null) {
outState.putBundle ("android:states", state);
}}, "android.os.Bundle");
Clazz.defineMethod (c$, "onPause", 
function () {
Clazz.superCall (this, android.app.ActivityGroup, "onPause", []);
this.mLocalActivityManager.dispatchPause (this.isFinishing ());
});
Clazz.defineMethod (c$, "onStop", 
function () {
Clazz.superCall (this, android.app.ActivityGroup, "onStop", []);
this.mLocalActivityManager.dispatchStop ();
});
Clazz.defineMethod (c$, "getCurrentActivity", 
function () {
return this.mLocalActivityManager.getCurrentActivity ();
});
Clazz.defineMethod (c$, "getLocalActivityManager", 
function () {
return this.mLocalActivityManager;
});
Clazz.defineMethod (c$, "dispatchActivityResult", 
function (who, requestCode, resultCode, data) {
if (who != null) {
var act = this.mLocalActivityManager.getActivity (who);
if (act != null) {
act.onActivityResult (requestCode, resultCode, data);
return ;
}}Clazz.superCall (this, android.app.ActivityGroup, "dispatchActivityResult", [who, requestCode, resultCode, data]);
}, "~S,~N,~N,android.content.Intent");
Clazz.defineStatics (c$,
"$$TAG", "ActivityGroup",
"STATES_KEY", "android:states",
"PARENT_NON_CONFIG_INSTANCE_KEY", "android:parent_non_config_instance");
});
