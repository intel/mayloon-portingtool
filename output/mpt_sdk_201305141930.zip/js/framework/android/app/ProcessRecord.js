﻿Clazz.declarePackage ("android.app");
Clazz.load (["java.util.ArrayList", "$.HashMap", "$.HashSet"], "android.app.ProcessRecord", ["java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.info = null;
this.processName = null;
this.pkgList = null;
this.thread = null;
this.pid = 0;
this.starting = false;
this.lastActivityTime = 0;
this.lruWeight = 0;
this.maxAdj = 0;
this.hiddenAdj = 0;
this.curRawAdj = 0;
this.setRawAdj = 0;
this.curAdj = 0;
this.setAdj = 0;
this.curSchedGroup = 0;
this.setSchedGroup = 0;
this.keeping = false;
this.setIsForeground = false;
this.foregroundServices = false;
this.bad = false;
this.killedBackground = false;
this.forcingToForeground = null;
this.adjSeq = 0;
this.lruSeq = 0;
this.instrumentationClass = null;
this.instrumentationInfo = null;
this.instrumentationProfileFile = null;
this.instrumentationArguments = null;
this.instrumentationResultClass = null;
this.lastWakeTime = 0;
this.lastCpuTime = 0;
this.curCpuTime = 0;
this.lastRequestedGc = 0;
this.lastLowMemory = 0;
this.reportLowMemory = false;
this.empty = false;
this.hidden = false;
this.lastPss = 0;
this.adjType = null;
this.adjTypeCode = 0;
this.adjSource = null;
this.adjTarget = null;
this.activities = null;
this.services = null;
this.executingServices = null;
this.receivers = null;
this.pubProviders = null;
this.conProviders = null;
this.persistent = false;
this.crashing = false;
this.crashDialog = null;
this.notResponding = false;
this.anrDialog = null;
this.removed = false;
this.debugging = false;
this.waitedForDebugger = false;
this.waitDialog = null;
this.shortStringName = null;
this.stringName = null;
this.errorReportReceiver = null;
Clazz.instantialize (this, arguments);
}, android.app, "ProcessRecord");
Clazz.prepareFields (c$, function () {
this.pkgList =  new java.util.HashSet ();
this.activities =  new java.util.ArrayList ();
this.services =  new java.util.HashSet ();
this.executingServices =  new java.util.HashSet ();
this.receivers =  new java.util.HashSet ();
this.pubProviders =  new java.util.HashMap ();
this.conProviders =  new java.util.HashMap ();
});
Clazz.makeConstructor (c$, 
function (_thread, _info, _processName) {
this.info = _info;
this.processName = _processName;
this.pkgList.add (_info.packageName);
this.thread = _thread;
this.curRawAdj = this.setRawAdj = -100;
this.curAdj = this.setAdj = -100;
this.persistent = false;
this.removed = false;
}, "android.app.IApplicationThread,android.content.pm.ApplicationInfo,~S");
Clazz.defineMethod (c$, "setPid", 
function (_pid) {
this.pid = _pid;
this.shortStringName = null;
this.stringName = null;
}, "~N");
Clazz.defineMethod (c$, "isInterestingToUserLocked", 
function () {
var size = this.activities.size ();
for (var i = 0; i < size; i++) {
var r = this.activities.get (i);
if (r.isInterestingToUserLocked ()) {
return true;
}}
return false;
});
Clazz.defineMethod (c$, "toShortString", 
function () {
if (this.shortStringName != null) {
return this.shortStringName;
}var sb =  new StringBuilder (128);
this.toShortString (sb);
return this.shortStringName = sb.toString ();
});
Clazz.defineMethod (c$, "toShortString", 
function (sb) {
sb.append (' ');
sb.append (this.pid);
sb.append (':');
sb.append (this.processName);
sb.append ('/');
sb.append (this.info.uid);
}, "StringBuilder");
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.stringName != null) {
return this.stringName;
}var sb =  new StringBuilder (128);
sb.append ("ProcessRecord{");
this.toShortString (sb);
sb.append ('}');
return this.stringName = sb.toString ();
});
Clazz.defineMethod (c$, "addPackage", 
function (pkg) {
if (!this.pkgList.contains (pkg)) {
this.pkgList.add (pkg);
return true;
}return false;
}, "~S");
Clazz.defineMethod (c$, "resetPackageList", 
function () {
this.pkgList.clear ();
this.pkgList.add (this.info.packageName);
});
Clazz.defineMethod (c$, "getPackageList", 
function () {
var size = this.pkgList.size ();
if (size == 0) {
return null;
}var list =  new Array (size);
this.pkgList.toArray (list);
return list;
});
});
