﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.Parcelable"], "android.app.PendingIntent", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mContext = null;
this.mIntent = null;
this.BROADCAST = false;
Clazz.instantialize (this, arguments);
}, android.app, "PendingIntent", null, android.os.Parcelable);
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
c$.getBroadcast = Clazz.defineMethod (c$, "getBroadcast", 
function (context, requestCode, intent, flags) {
var pIntent =  new android.app.PendingIntent ();
pIntent.mContext = context;
pIntent.mIntent = intent;
pIntent.BROADCAST = true;
return pIntent;
}, "android.content.Context,~N,android.content.Intent,~N");
Clazz.defineMethod (c$, "send", 
function () {
if (this.BROADCAST == true) this.mContext.sendBroadcast (this.mIntent);
});
Clazz.defineMethod (c$, "getTarget", 
function () {
console.log("Missing method: getTarget");
});
Clazz.defineMethod (c$, "send", 
function (code) {
console.log("Missing method: send");
}, "~N");
Clazz.defineMethod (c$, "getTargetPackage", 
function () {
console.log("Missing method: getTargetPackage");
});
Clazz.defineMethod (c$, "cancel", 
function () {
console.log("Missing method: cancel");
});
Clazz.declareInterface (android.app.PendingIntent, "OnFinished");
});
