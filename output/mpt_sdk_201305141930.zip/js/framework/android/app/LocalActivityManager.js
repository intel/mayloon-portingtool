﻿Clazz.declarePackage ("android.app");
Clazz.load (["android.os.Binder", "java.util.ArrayList", "$.HashMap"], "android.app.LocalActivityManager", ["android.app.ActivityThread", "android.os.Bundle", "android.util.Log", "java.lang.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mActivityThread = null;
this.mParent = null;
this.mResumed = null;
this.mActivities = null;
this.mActivityArray = null;
this.mSingleMode = false;
this.mFinishing = false;
this.mCurState = 1;
Clazz.instantialize (this, arguments);
}, android.app, "LocalActivityManager");
Clazz.prepareFields (c$, function () {
this.mActivities =  new java.util.HashMap ();
this.mActivityArray =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
function (parent, singleMode) {
this.mActivityThread = android.app.ActivityThread.currentActivityThread ();
this.mParent = parent;
this.mSingleMode = singleMode;
}, "android.app.Activity,~B");
Clazz.defineMethod (c$, "moveToState", 
($fz = function (r, desiredState) {
if (r.curState == 0 || r.curState == 5) {
return ;
}if (r.curState == 1) {
var instance = null;
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": starting " + r.intent);
if (r.activityInfo == null) {
r.activityInfo = this.mActivityThread.resolveActivityInfo (r.intent);
}r.activity = this.mActivityThread.startActivityNow (this.mParent, r.id, r.intent, r.activityInfo, r, r.instanceState, instance);
if (r.activity == null) {
return ;
}r.window = r.activity.getWindow ();
r.instanceState = null;
r.curState = 3;
if (desiredState == 4) {
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": resuming");
this.mActivityThread.performResumeActivity (r, true);
r.curState = 4;
}return ;
}switch (r.curState) {
case 2:
if (desiredState == 3) {
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": restarting");
this.mActivityThread.performRestartActivity (r);
r.curState = 3;
}if (desiredState == 4) {
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": restarting and resuming");
this.mActivityThread.performRestartActivity (r);
this.mActivityThread.performResumeActivity (r, true);
r.curState = 4;
}return ;
case 3:
if (desiredState == 4) {
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": resuming");
this.mActivityThread.performResumeActivity (r, true);
r.instanceState = null;
r.curState = 4;
}if (desiredState == 2) {
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": stopping");
this.mActivityThread.performStopActivity (r);
r.curState = 2;
}return ;
case 4:
if (desiredState == 3) {
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": pausing");
this.performPause (r, this.mFinishing);
r.curState = 3;
}if (desiredState == 2) {
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": pausing");
this.performPause (r, this.mFinishing);
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": stopping");
this.mActivityThread.performStopActivity (r);
r.curState = 2;
}return ;
}
}, $fz.isPrivate = true, $fz), "android.app.LocalActivityManager.LocalActivityRecord,~N");
Clazz.defineMethod (c$, "performPause", 
($fz = function (r, finishing) {
var needState = r.instanceState == null;
var instanceState = this.mActivityThread.performPauseActivity (r, finishing, needState);
if (needState) {
r.instanceState = instanceState;
}}, $fz.isPrivate = true, $fz), "android.app.LocalActivityManager.LocalActivityRecord,~B");
Clazz.defineMethod (c$, "startActivity", 
function (id, intent) {
if (this.mCurState == 1) {
throw  new IllegalStateException ("Activities can't be added until the containing group has been created.");
}var adding = false;
var sameIntent = false;
var aInfo = null;
var r = this.mActivities.get (id);
if (r == null) {
r =  new android.app.LocalActivityManager.LocalActivityRecord (id, intent);
adding = true;
} else if (r.intent != null) {
sameIntent = r.intent.filterEquals (intent);
if (sameIntent) {
aInfo = r.activityInfo;
}}if (aInfo == null) {
aInfo = this.mActivityThread.resolveActivityInfo (intent);
}if (this.mSingleMode) {
var old = this.mResumed;
if (old != null && old !== r && this.mCurState == 4) {
this.moveToState (old, 3);
}}if (adding) {
this.mActivities.put (id, r);
this.mActivityArray.add (r);
} else if (r.activityInfo != null) {
if (aInfo === r.activityInfo || (aInfo.name.equals (r.activityInfo.name) && aInfo.packageName.equals (r.activityInfo.packageName))) {
if (aInfo.launchMode != 0 || (intent.getFlags () & 536870912) != 0) {
var intents =  new java.util.ArrayList (1);
intents.add (intent);
if (false) android.util.Log.v ("LocalActivityManager", r.id + ": new intent");
this.mActivityThread.performNewIntents (r, intents);
r.intent = intent;
this.moveToState (r, this.mCurState);
if (this.mSingleMode) {
this.mResumed = r;
}return r.window;
}if (sameIntent && (intent.getFlags () & 67108864) == 0) {
r.intent = intent;
this.moveToState (r, this.mCurState);
if (this.mSingleMode) {
this.mResumed = r;
}return r.window;
}}this.performDestroy (r, true);
}r.intent = intent;
r.curState = 1;
r.activityInfo = aInfo;
this.moveToState (r, this.mCurState);
if (this.mSingleMode) {
this.mResumed = r;
}return r.window;
}, "~S,android.content.Intent");
Clazz.defineMethod (c$, "performDestroy", 
($fz = function (r, finish) {
var win = null;
win = r.window;
if (r.curState == 4 && !finish) {
this.performPause (r, finish);
}if (false) android.util.Log.v ("LocalActivityManager", r.id + ": destroying");
this.mActivityThread.performDestroyActivity (r, finish);
r.activity = null;
r.window = null;
if (finish) {
r.instanceState = null;
}r.curState = 5;
return win;
}, $fz.isPrivate = true, $fz), "android.app.LocalActivityManager.LocalActivityRecord,~B");
Clazz.defineMethod (c$, "destroyActivity", 
function (id, finish) {
var r = this.mActivities.get (id);
var win = null;
if (r != null) {
win = this.performDestroy (r, finish);
if (finish) {
this.mActivities.remove (id);
}}return win;
}, "~S,~B");
Clazz.defineMethod (c$, "getCurrentActivity", 
function () {
return this.mResumed != null ? this.mResumed.activity : null;
});
Clazz.defineMethod (c$, "getCurrentId", 
function () {
return this.mResumed != null ? this.mResumed.id : null;
});
Clazz.defineMethod (c$, "getActivity", 
function (id) {
var r = this.mActivities.get (id);
return r != null ? r.activity : null;
}, "~S");
Clazz.defineMethod (c$, "dispatchCreate", 
function (state) {
if (state != null) {
var i = state.keySet ().iterator ();
while (i.hasNext ()) {
try {
var id = i.next ();
var astate = state.getBundle (id);
var r = this.mActivities.get (id);
if (r != null) {
r.instanceState = astate;
} else {
r =  new android.app.LocalActivityManager.LocalActivityRecord (id, null);
r.instanceState = astate;
this.mActivities.put (id, r);
this.mActivityArray.add (r);
}} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.e ("LocalActivityManager", "Exception thrown when restoring LocalActivityManager state", e);
} else {
throw e;
}
}
}
}this.mCurState = 2;
}, "android.os.Bundle");
Clazz.defineMethod (c$, "saveInstanceState", 
function () {
var state = null;
var N = this.mActivityArray.size ();
for (var i = 0; i < N; i++) {
var r = this.mActivityArray.get (i);
if (state == null) {
state =  new android.os.Bundle ();
}if ((r.instanceState != null || r.curState == 4) && r.activity != null) {
var childState =  new android.os.Bundle ();
r.activity.onSaveInstanceState (childState);
r.instanceState = childState;
}if (r.instanceState != null) {
state.putBundle (r.id, r.instanceState);
}}
return state;
});
Clazz.defineMethod (c$, "dispatchResume", 
function () {
this.mCurState = 4;
if (this.mSingleMode) {
if (this.mResumed != null) {
this.moveToState (this.mResumed, 4);
}} else {
var N = this.mActivityArray.size ();
for (var i = 0; i < N; i++) {
this.moveToState (this.mActivityArray.get (i), 4);
}
}});
Clazz.defineMethod (c$, "dispatchPause", 
function (finishing) {
if (finishing) {
this.mFinishing = true;
}this.mCurState = 3;
if (this.mSingleMode) {
if (this.mResumed != null) {
this.moveToState (this.mResumed, 3);
}} else {
var N = this.mActivityArray.size ();
for (var i = 0; i < N; i++) {
var r = this.mActivityArray.get (i);
if (r.curState == 4) {
this.moveToState (r, 3);
}}
}}, "~B");
Clazz.defineMethod (c$, "dispatchStop", 
function () {
this.mCurState = 2;
var N = this.mActivityArray.size ();
for (var i = 0; i < N; i++) {
var r = this.mActivityArray.get (i);
this.moveToState (r, 2);
}
});
Clazz.defineMethod (c$, "removeAllActivities", 
function () {
console.log("Missing method: removeAllActivities");
});
Clazz.defineMethod (c$, "dispatchDestroy", 
function (finishing) {
console.log("Missing method: dispatchDestroy");
}, "~B");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.id = null;
this.intent = null;
this.activityInfo = null;
this.activity = null;
this.window = null;
this.instanceState = null;
this.curState = 0;
Clazz.instantialize (this, arguments);
}, android.app.LocalActivityManager, "LocalActivityRecord", android.os.Binder);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.app.LocalActivityManager.LocalActivityRecord, []);
this.id = a;
this.intent = b;
}, "~S,android.content.Intent");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "LocalActivityManager",
"localLOGV", false,
"RESTORED", 0,
"INITIALIZING", 1,
"CREATED", 2,
"STARTED", 3,
"RESUMED", 4,
"DESTROYED", 5);
});
