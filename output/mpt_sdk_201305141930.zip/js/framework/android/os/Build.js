﻿Clazz.declarePackage ("android.os");
Clazz.load (["android.os.SystemProperties"], "android.os.Build", ["java.lang.Long"], function () {
c$ = Clazz.declareType (android.os, "Build");
c$.getString = Clazz.defineMethod (c$, "getString", 
($fz = function (property) {
return android.os.SystemProperties.get (property, "unknown");
}, $fz.isPrivate = true, $fz), "~S");
Clazz.pu$h ();
c$ = Clazz.declareType (android.os.Build, "VERSION");
c$.INCREMENTAL = c$.prototype.INCREMENTAL = android.os.Build.getString ("ro.build.version.incremental");
c$.RELEASE = c$.prototype.RELEASE = android.os.Build.getString ("ro.build.version.release");
c$.SDK = c$.prototype.SDK = android.os.Build.getString ("ro.build.version.sdk");
c$.SDK_INT = c$.prototype.SDK_INT = android.os.SystemProperties.getInt ("ro.build.version.sdk", 0);
c$.CODENAME = c$.prototype.CODENAME = android.os.Build.getString ("ro.build.version.codename");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.os.Build, "VERSION_CODES");
Clazz.defineStatics (c$,
"CUR_DEVELOPMENT", 10000,
"BASE", 1,
"BASE_1_1", 2,
"CUPCAKE", 3,
"DONUT", 4,
"ECLAIR", 5,
"ECLAIR_0_1", 6,
"ECLAIR_MR1", 7,
"FROYO", 8,
"GINGERBREAD", 9,
"GINGERBREAD_MR1", 10);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"UNKNOWN", "unknown");
c$.ID = c$.prototype.ID = android.os.Build.getString ("ro.build.id");
c$.DISPLAY = c$.prototype.DISPLAY = android.os.Build.getString ("ro.build.display.id");
c$.PRODUCT = c$.prototype.PRODUCT = android.os.Build.getString ("ro.product.name");
c$.DEVICE = c$.prototype.DEVICE = android.os.Build.getString ("ro.product.device");
c$.BOARD = c$.prototype.BOARD = android.os.Build.getString ("ro.product.board");
c$.CPU_ABI = c$.prototype.CPU_ABI = android.os.Build.getString ("ro.product.cpu.abi");
c$.CPU_ABI2 = c$.prototype.CPU_ABI2 = android.os.Build.getString ("ro.product.cpu.abi2");
c$.MANUFACTURER = c$.prototype.MANUFACTURER = android.os.Build.getString ("ro.product.manufacturer");
c$.BRAND = c$.prototype.BRAND = android.os.Build.getString ("ro.product.brand");
c$.MODEL = c$.prototype.MODEL = android.os.Build.getString ("ro.product.model");
c$.BOOTLOADER = c$.prototype.BOOTLOADER = android.os.Build.getString ("ro.bootloader");
c$.RADIO = c$.prototype.RADIO = android.os.Build.getString ("gsm.version.baseband");
c$.HARDWARE = c$.prototype.HARDWARE = android.os.Build.getString ("ro.hardware");
c$.SERIAL = c$.prototype.SERIAL = android.os.Build.getString ("ro.serialno");
c$.TYPE = c$.prototype.TYPE = android.os.Build.getString ("ro.build.type");
c$.TAGS = c$.prototype.TAGS = android.os.Build.getString ("ro.build.tags");
c$.FINGERPRINT = c$.prototype.FINGERPRINT = android.os.Build.getString ("ro.build.fingerprint");
});
