﻿Clazz.declarePackage ("android.os");
Clazz.load (null, "android.os.Handler", ["android.os.Looper", "$.Message", "$.MessageQueue", "$.SystemClock", "android.util.Log", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mQueue = null;
this.mLooper = null;
this.mCallback = null;
Clazz.instantialize (this, arguments);
}, android.os, "Handler");
Clazz.defineMethod (c$, "handleMessage", 
function (msg) {
}, "android.os.Message");
Clazz.defineMethod (c$, "dispatchMessage", 
function (msg) {
if (msg.callback != null) {
this.handleCallback (msg);
} else {
if (this.mCallback != null) {
if (this.mCallback.handleMessage (msg)) {
return ;
}}this.handleMessage (msg);
}}, "android.os.Message");
Clazz.makeConstructor (c$, 
function () {
this.mLooper = android.os.Looper.myLooper ();
if (this.mLooper == null) {
android.os.Looper.prepare ();
this.mLooper = android.os.Looper.myLooper ();
if (this.mLooper.mQueue == null) {
this.mLooper.mQueue =  new android.os.MessageQueue ();
}}this.mQueue = this.mLooper.mQueue;
this.mCallback = null;
});
Clazz.makeConstructor (c$, 
function (callback) {
if (false) {
var klass = this.getClass ();
if ((klass.isAnonymousClass () || klass.isMemberClass () || klass.isLocalClass ()) && (klass.getModifiers () & 8) == 0) {
android.util.Log.w ("Handler", "The following Handler class should be static or leaks might occur: " + klass.getCanonicalName ());
}}this.mLooper = android.os.Looper.myLooper ();
if (this.mLooper == null) {
throw  new RuntimeException ("Can't create handler inside thread that has not called Looper.prepare()");
}this.mQueue = this.mLooper.mQueue;
this.mCallback = callback;
}, "android.os.Handler.Callback");
Clazz.makeConstructor (c$, 
function (looper) {
this.mLooper = looper;
this.mQueue = looper.mQueue;
this.mCallback = null;
}, "android.os.Looper");
Clazz.makeConstructor (c$, 
function (looper, callback) {
this.mLooper = looper;
this.mQueue = looper.mQueue;
this.mCallback = callback;
}, "android.os.Looper,android.os.Handler.Callback");
Clazz.defineMethod (c$, "obtainMessage", 
function () {
return android.os.Message.obtain (this);
});
Clazz.defineMethod (c$, "obtainMessage", 
function (what) {
return android.os.Message.obtain (this, what);
}, "~N");
Clazz.defineMethod (c$, "obtainMessage", 
function (what, obj) {
return android.os.Message.obtain (this, what, obj);
}, "~N,~O");
Clazz.defineMethod (c$, "obtainMessage", 
function (what, arg1, arg2) {
return android.os.Message.obtain (this, what, arg1, arg2);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "obtainMessage", 
function (what, arg1, arg2, obj) {
return android.os.Message.obtain (this, what, arg1, arg2, obj);
}, "~N,~N,~N,~O");
Clazz.defineMethod (c$, "post", 
function (r) {
return this.sendMessageDelayed (this.getPostMessage (r), 0);
}, "Runnable");
Clazz.defineMethod (c$, "postAtTime", 
function (r, uptimeMillis) {
return this.sendMessageDelayed (this.getPostMessage (r), uptimeMillis - android.os.SystemClock.uptimeMillis ());
}, "Runnable,~N");
Clazz.defineMethod (c$, "postAtTime", 
function (r, token, uptimeMillis) {
return this.sendMessageDelayed (this.getPostMessage (r, token), uptimeMillis - android.os.SystemClock.uptimeMillis ());
}, "Runnable,~O,~N");
Clazz.defineMethod (c$, "postDelayed", 
function (r, delayMillis) {
return this.sendMessageDelayed (this.getPostMessage (r), delayMillis);
}, "Runnable,~N");
Clazz.defineMethod (c$, "postAtFrontOfQueue", 
function (r) {
return this.sendMessageAtFrontOfQueue (this.getPostMessage (r));
}, "Runnable");
Clazz.defineMethod (c$, "removeCallbacks", 
function (r) {
this.mQueue.removeMessages (this, r, null);
}, "Runnable");
Clazz.defineMethod (c$, "removeCallbacks", 
function (r, token) {
this.mQueue.removeMessages (this, r, token);
}, "Runnable,~O");
Clazz.defineMethod (c$, "sendMessage", 
function (msg) {
return this.sendMessageDelayed (msg, 0);
}, "android.os.Message");
Clazz.defineMethod (c$, "sendEmptyMessage", 
function (what) {
return this.sendEmptyMessageDelayed (what, 0);
}, "~N");
Clazz.defineMethod (c$, "sendEmptyMessageDelayed", 
function (what, delayMillis) {
var msg = android.os.Message.obtain ();
msg.what = what;
return this.sendMessageDelayed (msg, delayMillis);
}, "~N,~N");
Clazz.defineMethod (c$, "sendEmptyMessageAtTime", 
function (what, uptimeMillis) {
var msg = android.os.Message.obtain ();
msg.what = what;
return this.sendMessageAtTime (msg, uptimeMillis);
}, "~N,~N");
Clazz.defineMethod (c$, "sendMessageDelayed", 
function (msg, delayMillis) {
if (delayMillis < 0) {
delayMillis = 0;
}var result = true;
if (delayMillis > 0) {
window.setTimeout((function(handler, m) {
return function() {
//window.log("timeout: sendMessage");
handler.sendMessageAtTime(m, android.os.SystemClock.uptimeMillis());
};
})(this,msg), delayMillis);
} else result = this.sendMessageAtTime (msg, android.os.SystemClock.uptimeMillis ());
return result;
}, "android.os.Message,~N");
Clazz.defineMethod (c$, "sendMessageAtTime", 
function (msg, uptimeMillis) {
var sent = false;
var queue = this.mQueue;
if (queue != null) {
msg.target = this;
sent = queue.enqueueMessage (msg, uptimeMillis);
} else {
var e =  new RuntimeException (this + " sendMessageAtTime() called with no mQueue");
android.util.Log.w ("Looper", e.getMessage (), e);
}return sent;
}, "android.os.Message,~N");
Clazz.defineMethod (c$, "sendMessageAtFrontOfQueue", 
function (msg) {
var sent = false;
var queue = this.mQueue;
if (queue != null) {
msg.target = this;
sent = queue.enqueueMessage (msg, 0);
} else {
var e =  new RuntimeException (this + " sendMessageAtTime() called with no mQueue");
android.util.Log.w ("Looper", e.getMessage (), e);
}return sent;
}, "android.os.Message");
Clazz.defineMethod (c$, "removeMessages", 
function (what) {
this.mQueue.removeMessages (this, what, null, true);
}, "~N");
Clazz.defineMethod (c$, "removeMessages", 
function (what, object) {
this.mQueue.removeMessages (this, what, object, true);
}, "~N,~O");
Clazz.defineMethod (c$, "removeCallbacksAndMessages", 
function (token) {
this.mQueue.removeCallbacksAndMessages (this, token);
}, "~O");
Clazz.defineMethod (c$, "hasMessages", 
function (what) {
return this.mQueue.removeMessages (this, what, null, false);
}, "~N");
Clazz.defineMethod (c$, "hasMessages", 
function (what, object) {
return this.mQueue.removeMessages (this, what, object, false);
}, "~N,~O");
Clazz.defineMethod (c$, "getLooper", 
function () {
return this.mLooper;
});
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
}, "android.util.Printer,~S");
Clazz.overrideMethod (c$, "toString", 
function () {
return "Handler{" + Integer.toHexString (System.identityHashCode (this)) + "}";
});
Clazz.defineMethod (c$, "getPostMessage", 
($fz = function (r) {
var m = android.os.Message.obtain ();
m.callback = r;
return m;
}, $fz.isPrivate = true, $fz), "Runnable");
Clazz.defineMethod (c$, "getPostMessage", 
($fz = function (r, token) {
var m = android.os.Message.obtain ();
m.obj = token;
m.callback = r;
return m;
}, $fz.isPrivate = true, $fz), "Runnable,~O");
Clazz.defineMethod (c$, "handleCallback", 
($fz = function (message) {
message.callback.run ();
}, $fz.isPrivate = true, $fz), "android.os.Message");
Clazz.declareInterface (android.os.Handler, "Callback");
Clazz.defineStatics (c$,
"FIND_POTENTIAL_LEAKS", false,
"TAG", "Handler");
});
