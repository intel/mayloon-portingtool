﻿Clazz.declarePackage ("android.os");
Clazz.load (["android.util.AndroidException"], "android.os.RemoteException", null, function () {
c$ = Clazz.declareType (android.os, "RemoteException", android.util.AndroidException);
});
