﻿Clazz.declarePackage ("android.os");
Clazz.load (["android.os.Parcelable.Creator"], "android.os.Parcel", ["java.lang.RuntimeException", "java.util.ArrayList", "$.HashMap"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mObject = 0;
this.mOwnObject = 0;
this.mStack = null;
Clazz.instantialize (this, arguments);
}, android.os, "Parcel");
c$.openFileDescriptor = Clazz.defineMethod (c$, "openFileDescriptor", 
function (file, mode) {
return null;
}, "~S,~N");
c$.closeFileDescriptor = Clazz.defineMethod (c$, "closeFileDescriptor", 
function (desc) {
}, "java.io.FileDescriptor");
Clazz.defineMethod (c$, "enforceInterface", 
function (descriptor) {
}, "~S");
Clazz.defineMethod (c$, "readStrongBinder", 
function () {
return null;
});
Clazz.defineMethod (c$, "writeString", 
function (interfaceDescriptor) {
}, "~S");
Clazz.defineMethod (c$, "setDataPosition", 
function (i) {
}, "~N");
Clazz.defineMethod (c$, "writeInt", 
function (mRequestCode) {
}, "~N");
Clazz.defineMethod (c$, "readString", 
function () {
return null;
});
Clazz.defineMethod (c$, "writeNoException", 
function () {
});
Clazz.defineMethod (c$, "readException", 
function () {
});
Clazz.defineMethod (c$, "readInt", 
function () {
return 0;
});
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function () {
return null;
});
Clazz.defineMethod (c$, "writeInterfaceToken", 
function (descriptor) {
}, "~S");
Clazz.defineMethod (c$, "writeStringArray", 
function (packages) {
}, "~A");
Clazz.defineMethod (c$, "recycle", 
function () {
});
Clazz.defineMethod (c$, "writeStrongBinder", 
function (token) {
}, "android.os.IBinder");
Clazz.defineMethod (c$, "writeTypedList", 
function (intents) {
}, "java.util.List");
Clazz.defineMethod (c$, "writeBundle", 
function (state) {
}, "android.os.Bundle");
Clazz.defineMethod (c$, "writeMap", 
function (val) {
this.writeMapInternal (val);
}, "java.util.Map");
Clazz.defineMethod (c$, "writeMapInternal", 
function (val) {
if (val == null) {
this.writeInt (-1);
return ;
}var entries = val.entrySet ();
this.writeInt (entries.size ());
for (var e, $e = entries.iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
this.writeValue (e.getKey ());
this.writeValue (e.getValue ());
}
}, "java.util.Map");
Clazz.defineMethod (c$, "readValue", 
function (loader) {
var type = this.readInt ();
switch (type) {
case -1:
return null;
case 0:
return this.readString ();
case 1:
return this.readInt ();
case 2:
return this.readHashMap (loader);
case 5:
return this.readInt ();
case 9:
return this.readInt () == 1;
case 14:
case 24:
case 15:
return this.readStrongBinder ();
case 17:
case 18:
case 19:
case 20:
case 21:
case 16:
case 12:
case 22:
case 3:
default:
var off = this.dataPosition () - 4;
throw  new RuntimeException ("Parcel " + this + ": Unmarshalling unknown type code " + type + " at offset " + off);
}
}, "ClassLoader");
Clazz.defineMethod (c$, "writeValue", 
function (v) {
if (v == null) {
this.writeInt (-1);
} else if (Clazz.instanceOf (v, String)) {
this.writeInt (0);
this.writeString (v);
} else if (Clazz.instanceOf (v, Integer)) {
this.writeInt (1);
this.writeInt ((v).intValue ());
} else if (Clazz.instanceOf (v, java.util.Map)) {
this.writeInt (2);
this.writeMap (v);
} else if (Clazz.instanceOf (v, android.os.Bundle)) {
this.writeInt (3);
this.writeBundle (v);
} else {
throw  new RuntimeException ("Parcel: unable to marshal value " + v);
}}, "~O");
Clazz.defineMethod (c$, "readBundle", 
function () {
return null;
});
Clazz.defineMethod (c$, "readHashMap", 
function (loader) {
var N = this.readInt ();
if (N < 0) {
return null;
}var m =  new java.util.HashMap (N);
this.readMapInternal (m, N, loader);
return m;
}, "ClassLoader");
Clazz.defineMethod (c$, "readMapInternal", 
function (outVal, N, loader) {
while (N > 0) {
var key = this.readValue (loader);
var value = this.readValue (loader);
outVal.put (key, value);
N--;
}
}, "java.util.Map,~N,ClassLoader");
Clazz.defineMethod (c$, "writeParcelable", 
function (p, parcelableFlags) {
}, "android.os.Parcelable,~N");
Clazz.defineMethod (c$, "readParcelable", 
function (loader) {
return null;
}, "ClassLoader");
Clazz.defineMethod (c$, "createTypedArrayList", 
function (c) {
var N = this.readInt ();
if (N < 0) {
return null;
}var l =  new java.util.ArrayList (N);
while (N > 0) {
if (this.readInt () != 0) {
l.add (c.createFromParcel (this));
} else {
l.add (null);
}N--;
}
return l;
}, "android.os.Parcelable.Creator");
Clazz.defineMethod (c$, "writeLong", 
function (mStartOffset) {
}, "~N");
Clazz.defineMethod (c$, "readLong", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeDouble", 
function (mStartOffset) {
}, "~N");
Clazz.defineMethod (c$, "readDouble", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeFloat", 
function (mStartOffset) {
}, "~N");
Clazz.defineMethod (c$, "readFloat", 
function () {
return 0;
});
Clazz.defineMethod (c$, "readStringArray", 
function () {
return null;
});
Clazz.defineMethod (c$, "writeTypedArray", 
function (uriPermissionPatterns, parcelableFlags) {
}, "~A,~N");
Clazz.defineMethod (c$, "createTypedArray", 
function (creator) {
return null;
}, "android.os.Parcelable.Creator");
Clazz.defineMethod (c$, "readParcelableArray", 
function (loader) {
console.log("Missing method: readParcelableArray");
}, "ClassLoader");
Clazz.defineMethod (c$, "writeFloatArray", 
function (val) {
console.log("Missing method: writeFloatArray");
}, "~A");
Clazz.defineMethod (c$, "writeFloat", 
function (val) {
console.log("Missing method: writeFloat");
}, "~N");
Clazz.defineMethod (c$, "readSerializable", 
function () {
console.log("Missing method: readSerializable");
});
Clazz.defineMethod (c$, "createFloatArray", 
function () {
console.log("Missing method: createFloatArray");
});
Clazz.defineMethod (c$, "writeCharArray", 
function (val) {
console.log("Missing method: writeCharArray");
}, "~A");
Clazz.defineMethod (c$, "readException", 
function (code, msg) {
console.log("Missing method: readException");
}, "~N,~S");
Clazz.defineMethod (c$, "writeByteArray", 
function (b, offset, len) {
console.log("Missing method: writeByteArray");
}, "~A,~N,~N");
Clazz.defineMethod (c$, "readByteArray", 
function (val) {
console.log("Missing method: readByteArray");
}, "~A");
Clazz.defineMethod (c$, "readByte", 
function () {
console.log("Missing method: readByte");
});
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (obj) {
console.log("Missing method: obtain");
}, "~N");
Clazz.defineMethod (c$, "dataAvail", 
function () {
console.log("Missing method: dataAvail");
});
Clazz.defineMethod (c$, "readBinderList", 
function (list) {
console.log("Missing method: readBinderList");
}, "java.util.List");
Clazz.defineMethod (c$, "marshall", 
function () {
console.log("Missing method: marshall");
});
Clazz.defineMethod (c$, "writeBooleanArray", 
function (val) {
console.log("Missing method: writeBooleanArray");
}, "~A");
Clazz.defineMethod (c$, "writeByte", 
function (val) {
console.log("Missing method: writeByte");
}, "~N");
Clazz.defineMethod (c$, "createBinderArray", 
function () {
console.log("Missing method: createBinderArray");
});
Clazz.defineMethod (c$, "writeDoubleArray", 
function (val) {
console.log("Missing method: writeDoubleArray");
}, "~A");
Clazz.defineMethod (c$, "writeArray", 
function (val) {
console.log("Missing method: writeArray");
}, "~A");
Clazz.defineMethod (c$, "dataCapacity", 
function () {
console.log("Missing method: dataCapacity");
});
Clazz.defineMethod (c$, "readLongArray", 
function (val) {
console.log("Missing method: readLongArray");
}, "~A");
Clazz.defineMethod (c$, "createCharArray", 
function () {
console.log("Missing method: createCharArray");
});
Clazz.defineMethod (c$, "readArray", 
function (loader) {
console.log("Missing method: readArray");
}, "ClassLoader");
Clazz.defineMethod (c$, "readCharArray", 
function (val) {
console.log("Missing method: readCharArray");
}, "~A");
Clazz.defineMethod (c$, "readBundle", 
function (loader) {
console.log("Missing method: readBundle");
}, "ClassLoader");
Clazz.defineMethod (c$, "createByteArray", 
function () {
console.log("Missing method: createByteArray");
});
Clazz.defineMethod (c$, "createStringArrayList", 
function () {
console.log("Missing method: createStringArrayList");
});
Clazz.defineMethod (c$, "readBinderArray", 
function (val) {
console.log("Missing method: readBinderArray");
}, "~A");
Clazz.defineMethod (c$, "writeList", 
function (val) {
console.log("Missing method: writeList");
}, "java.util.List");
Clazz.defineMethod (c$, "readStringArray", 
function (val) {
console.log("Missing method: readStringArray");
}, "~A");
Clazz.defineMethod (c$, "writeException", 
function (e) {
console.log("Missing method: writeException");
}, "Exception");
Clazz.defineMethod (c$, "readDoubleArray", 
function (val) {
console.log("Missing method: readDoubleArray");
}, "~A");
Clazz.defineMethod (c$, "createIntArray", 
function () {
console.log("Missing method: createIntArray");
});
Clazz.defineMethod (c$, "createStringArray", 
function () {
console.log("Missing method: createStringArray");
});
Clazz.defineMethod (c$, "createBinderArrayList", 
function () {
console.log("Missing method: createBinderArrayList");
});
Clazz.defineMethod (c$, "createBooleanArray", 
function () {
console.log("Missing method: createBooleanArray");
});
Clazz.defineMethod (c$, "readFloatArray", 
function (val) {
console.log("Missing method: readFloatArray");
}, "~A");
Clazz.defineMethod (c$, "readBooleanArray", 
function (val) {
console.log("Missing method: readBooleanArray");
}, "~A");
Clazz.defineMethod (c$, "writeStringList", 
function (val) {
console.log("Missing method: writeStringList");
}, "java.util.List");
Clazz.defineMethod (c$, "readArrayList", 
function (loader) {
console.log("Missing method: readArrayList");
}, "ClassLoader");
Clazz.defineMethod (c$, "setDataSize", 
function (size) {
console.log("Missing method: setDataSize");
}, "~N");
Clazz.defineMethod (c$, "writeByteArray", 
function (b) {
console.log("Missing method: writeByteArray");
}, "~A");
Clazz.overrideMethod (c$, "finalize", 
function () {
console.log("Missing method: finalize");
});
Clazz.defineMethod (c$, "writeBinderList", 
function (val) {
console.log("Missing method: writeBinderList");
}, "java.util.List");
Clazz.defineMethod (c$, "writeSerializable", 
function (s) {
console.log("Missing method: writeSerializable");
}, "java.io.Serializable");
Clazz.defineMethod (c$, "setDataCapacity", 
function (size) {
console.log("Missing method: setDataCapacity");
}, "~N");
Clazz.defineMethod (c$, "createLongArray", 
function () {
console.log("Missing method: createLongArray");
});
Clazz.defineMethod (c$, "readIntArray", 
function (val) {
console.log("Missing method: readIntArray");
}, "~A");
Clazz.defineMethod (c$, "writeLongArray", 
function (val) {
console.log("Missing method: writeLongArray");
}, "~A");
Clazz.defineMethod (c$, "writeIntArray", 
function (val) {
console.log("Missing method: writeIntArray");
}, "~A");
Clazz.defineMethod (c$, "createDoubleArray", 
function () {
console.log("Missing method: createDoubleArray");
});
Clazz.defineMethod (c$, "writeBinderArray", 
function (val) {
console.log("Missing method: writeBinderArray");
}, "~A");
Clazz.defineMethod (c$, "writeFileDescriptor", 
function (val) {
console.log("Missing method: writeFileDescriptor");
}, "java.io.FileDescriptor");
Clazz.defineMethod (c$, "dataSize", 
function () {
console.log("Missing method: dataSize");
});
Clazz.defineMethod (c$, "hasFileDescriptors", 
function () {
console.log("Missing method: hasFileDescriptors");
});
Clazz.defineMethod (c$, "readStringList", 
function (list) {
console.log("Missing method: readStringList");
}, "java.util.List");
c$.$Parcel$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.os, "Parcel$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
Clazz.overrideMethod (c$, "createFromParcel", 
function (source) {
return null;
}, "android.os.Parcel");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"DEBUG_RECYCLE", false,
"TAG", "Parcel",
"POOL_SIZE", 6);
c$.sOwnedPool = c$.prototype.sOwnedPool =  new Array (6);
c$.sHolderPool = c$.prototype.sHolderPool =  new Array (6);
Clazz.defineStatics (c$,
"VAL_NULL", -1,
"VAL_STRING", 0,
"VAL_INTEGER", 1,
"VAL_MAP", 2,
"VAL_BUNDLE", 3,
"VAL_PARCELABLE", 4,
"VAL_SHORT", 5,
"VAL_LONG", 6,
"VAL_FLOAT", 7,
"VAL_DOUBLE", 8,
"VAL_BOOLEAN", 9,
"VAL_CHARSEQUENCE", 10,
"VAL_LIST", 11,
"VAL_SPARSEARRAY", 12,
"VAL_BYTEARRAY", 13,
"VAL_STRINGARRAY", 14,
"VAL_IBINDER", 15,
"VAL_PARCELABLEARRAY", 16,
"VAL_OBJECTARRAY", 17,
"VAL_INTARRAY", 18,
"VAL_LONGARRAY", 19,
"VAL_BYTE", 20,
"VAL_SERIALIZABLE", 21,
"VAL_SPARSEBOOLEANARRAY", 22,
"VAL_BOOLEANARRAY", 23,
"VAL_CHARSEQUENCEARRAY", 24,
"EX_SECURITY", -1,
"EX_BAD_PARCELABLE", -2,
"EX_ILLEGAL_ARGUMENT", -3,
"EX_NULL_POINTER", -4,
"EX_ILLEGAL_STATE", -5,
"EX_HAS_REPLY_HEADER", -128);
c$.STRING_CREATOR = c$.prototype.STRING_CREATOR = ((Clazz.isClassDefined ("android.os.Parcel$1") ? 0 : android.os.Parcel.$Parcel$1$ ()), Clazz.innerTypeInstance (android.os.Parcel$1, this, null));
});
