﻿Clazz.declarePackage ("android.os");
Clazz.load (["android.os.Handler", "java.lang.Enum"], "android.os.AsyncTask", ["java.lang.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mStatus = null;
this.mLocalParams = null;
this.mResult = null;
Clazz.instantialize (this, arguments);
}, android.os, "AsyncTask");
Clazz.prepareFields (c$, function () {
this.mStatus = android.os.AsyncTask.Status.PENDING;
{
var mBgThread = null;
var mRunnable = null;
}});
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "getStatus", 
function () {
return this.mStatus;
});
Clazz.defineMethod (c$, "onPreExecute", 
function () {
});
Clazz.defineMethod (c$, "onPostExecute", 
function (result) {
}, "~O");
Clazz.defineMethod (c$, "onProgressUpdate", 
function (values) {
}, "~A");
Clazz.defineMethod (c$, "onCancelled", 
function () {
});
Clazz.defineMethod (c$, "isCancelled", 
function () {
return false;
});
Clazz.defineMethod (c$, "cancel", 
function (mayInterruptIfRunning) {
try{
mBgThread.kill();
}catch(e){
return false;
}
var message = android.os.AsyncTask.sHandler.obtainMessage (3,  new android.os.AsyncTask.AsyncTaskResult (this, Clazz.castNullAs ("Array")));
message.sendToTarget ();
return false;
}, "~B");
Clazz.defineMethod (c$, "get", 
function () {
try{
var res = mBgThread.join();
return this.mResult;
}catch(e){
return null;
}
return null;
});
Clazz.defineMethod (c$, "get", 
function (timeout, unit) {
return this.get ();
}, "~N,~O");
Clazz.defineMethod (c$, "execute", 
function (params) {
if (this.mStatus !== android.os.AsyncTask.Status.PENDING) {
switch (this.mStatus) {
case android.os.AsyncTask.Status.RUNNING:
throw  new IllegalStateException ("Cannot execute task: the task is already running.");
case android.os.AsyncTask.Status.FINISHED:
throw  new IllegalStateException ("Cannot execute task: the task has already been executed (a task can be executed only once)");
}
}this.mStatus = android.os.AsyncTask.Status.RUNNING;
this.mLocalParams = params;
this.onPreExecute ();
var obj_this = this;
var _callback = function(){
return {
run:function() {
mRunnable.bgRun(mRunnable.mLocalParams);
}
}
};
var _caller = _callback();
mRunnable = obj_this;
mBgThread = Concurrent.Thread.create(_caller.run);
//console.log('bye');
return this;
}, "~A");
Clazz.defineMethod (c$, "bgRun", 
function (params) {
this.mResult = this.doInBackground (params);
System.out.println ("doInBackround finished");
var message;
message = android.os.AsyncTask.sHandler.obtainMessage (1,  new android.os.AsyncTask.AsyncTaskResult (this, this.mResult));
message.sendToTarget ();
}, "~A");
Clazz.defineMethod (c$, "publishProgress", 
function (values) {
System.out.println ("Publish progress");
android.os.AsyncTask.sHandler.obtainMessage (2,  new android.os.AsyncTask.AsyncTaskResult (this, values)).sendToTarget ();
}, "~A");
Clazz.defineMethod (c$, "finish", 
function (result) {
if (this.isCancelled ()) result = null;
this.onPostExecute (result);
this.mStatus = android.os.AsyncTask.Status.FINISHED;
}, "~O");
Clazz.pu$h ();
c$ = Clazz.declareType (android.os.AsyncTask, "Status", Enum);
Clazz.defineEnumConstant (c$, "PENDING", 0, []);
Clazz.defineEnumConstant (c$, "RUNNING", 1, []);
Clazz.defineEnumConstant (c$, "FINISHED", 2, []);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.os.AsyncTask, "InternalHandler", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
var b = a.obj;
switch (a.what) {
case 1:
if (b.mData == null) {
b.mTask.finish (null);
} else {
b.mTask.finish (b.mData[0]);
}break;
case 2:
b.mTask.onProgressUpdate (b.mData);
break;
case 3:
b.mTask.onCancelled ();
break;
}
}, "android.os.Message");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mTask = null;
this.mData = null;
Clazz.instantialize (this, arguments);
}, android.os.AsyncTask, "AsyncTaskResult");
Clazz.makeConstructor (c$, 
function (a, b) {
this.mTask = a;
this.mData = b;
}, "android.os.AsyncTask,~A");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"LOG_TAG", "AsyncTask",
"CORE_POOL_SIZE", 5,
"MAXIMUM_POOL_SIZE", 128,
"KEEP_ALIVE", 1,
"MESSAGE_POST_RESULT", 0x1,
"MESSAGE_POST_PROGRESS", 0x2,
"MESSAGE_POST_CANCEL", 0x3);
c$.sHandler = c$.prototype.sHandler =  new android.os.AsyncTask.InternalHandler ();
});
