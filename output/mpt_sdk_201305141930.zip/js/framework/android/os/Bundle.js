﻿Clazz.declarePackage ("android.os");
Clazz.load (["android.os.Parcelable"], "android.os.Bundle", ["android.util.Log", "java.lang.StringBuilder", "java.util.HashMap"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAllowFds = true;
this.mMap = null;
this.mParcelledData = null;
this.mHasFds = false;
this.mFdsKnown = true;
this.mClassLoader = null;
Clazz.instantialize (this, arguments);
}, android.os, "Bundle", null, [android.os.Parcelable, Cloneable]);
Clazz.makeConstructor (c$, 
function () {
this.mMap =  new java.util.HashMap ();
this.mClassLoader = this.getClass ().getClassLoader ();
});
Clazz.makeConstructor (c$, 
function (parcelledData) {
}, "android.os.Parcel");
Clazz.makeConstructor (c$, 
function (parcelledData, length) {
}, "android.os.Parcel,~N");
Clazz.makeConstructor (c$, 
function (loader) {
this.mMap =  new java.util.HashMap ();
this.mClassLoader = loader;
}, "ClassLoader");
Clazz.makeConstructor (c$, 
function (capacity) {
this.mMap =  new java.util.HashMap (capacity);
this.mClassLoader = this.getClass ().getClassLoader ();
}, "~N");
Clazz.makeConstructor (c$, 
function (b) {
if (b.mMap != null) {
this.mMap =  new java.util.HashMap (b.mMap.size ());
for (var it = b.mMap.entrySet ().iterator (); it.hasNext (); ) {
var entry = it.next ();
this.mMap.put (entry.getKey (), entry.getValue ());
}
} else {
this.mMap = null;
}this.mHasFds = b.mHasFds;
this.mFdsKnown = b.mFdsKnown;
this.mClassLoader = b.mClassLoader;
}, "android.os.Bundle");
c$.forPair = Clazz.defineMethod (c$, "forPair", 
function (key, value) {
var b =  new android.os.Bundle (1);
b.putString (key, value);
return b;
}, "~S,~S");
Clazz.defineMethod (c$, "getPairValue", 
function () {
this.unparcel ();
var size = this.mMap.size ();
if (size > 1) {
android.util.Log.w ("Bundle", "getPairValue() used on Bundle with multiple pairs.");
}if (size == 0) {
return null;
}var o = this.mMap.values ().iterator ().next ();
try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning ("getPairValue()", o, "String", e);
return null;
} else {
throw e;
}
}
});
Clazz.defineMethod (c$, "setClassLoader", 
function (loader) {
this.mClassLoader = loader;
}, "ClassLoader");
Clazz.overrideMethod (c$, "clone", 
function () {
return  new android.os.Bundle (this);
});
Clazz.defineMethod (c$, "unparcel", 
function () {
if (this.mParcelledData == null) {
return ;
}this.mParcelledData = null;
});
Clazz.defineMethod (c$, "size", 
function () {
this.unparcel ();
return this.mMap.size ();
});
Clazz.defineMethod (c$, "isEmpty", 
function () {
this.unparcel ();
return this.mMap.isEmpty ();
});
Clazz.defineMethod (c$, "clear", 
function () {
this.unparcel ();
this.mMap.clear ();
this.mHasFds = false;
this.mFdsKnown = true;
});
Clazz.defineMethod (c$, "containsKey", 
function (key) {
this.unparcel ();
return this.mMap.containsKey (key);
}, "~S");
Clazz.defineMethod (c$, "get", 
function (key) {
this.unparcel ();
return this.mMap.get (key);
}, "~S");
Clazz.defineMethod (c$, "remove", 
function (key) {
this.unparcel ();
this.mMap.remove (key);
}, "~S");
Clazz.defineMethod (c$, "putAll", 
function (map) {
this.unparcel ();
map.unparcel ();
this.mMap.putAll (map.mMap);
this.mHasFds = new Boolean (this.mHasFds | map.mHasFds).valueOf ();
this.mFdsKnown = this.mFdsKnown && map.mFdsKnown;
}, "android.os.Bundle");
Clazz.defineMethod (c$, "keySet", 
function () {
this.unparcel ();
return this.mMap.keySet ();
});
Clazz.defineMethod (c$, "hasFileDescriptors", 
function () {
if (!this.mFdsKnown) {
var fdFound = false;
if (this.mParcelledData != null) {
} else {
var iter = this.mMap.entrySet ().iterator ();
while (!fdFound && iter.hasNext ()) {
var obj = iter.next ().getValue ();
if (Clazz.instanceOf (obj, android.os.Parcelable)) {
if (((obj).describeContents () & 1) != 0) {
fdFound = true;
break;
}} else if (Clazz.instanceOf (obj, Array)) {
var array = obj;
for (var n = array.length - 1; n >= 0; n--) {
if ((array[n].describeContents () & 1) != 0) {
fdFound = true;
break;
}}
} else if (Clazz.instanceOf (obj, java.util.ArrayList)) {
var array = obj;
if ((array.size () > 0) && (Clazz.instanceOf (array.get (0), android.os.Parcelable))) {
for (var n = array.size () - 1; n >= 0; n--) {
var p = array.get (n);
if (p != null && ((p.describeContents () & 1) != 0)) {
fdFound = true;
break;
}}
}}}
}this.mHasFds = fdFound;
this.mFdsKnown = true;
}return this.mHasFds;
});
Clazz.defineMethod (c$, "setAllowFds", 
function (allowFds) {
var orig = this.mAllowFds;
this.mAllowFds = allowFds;
return orig;
}, "~B");
Clazz.defineMethod (c$, "putBoolean", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, new Boolean (value));
}, "~S,~B");
Clazz.defineMethod (c$, "putByte", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, new Byte (value));
}, "~S,~N");
Clazz.defineMethod (c$, "putChar", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, new Character (value));
}, "~S,~N");
Clazz.defineMethod (c$, "putShort", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, new Short (value));
}, "~S,~N");
Clazz.defineMethod (c$, "putInt", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, new Integer (value));
}, "~S,~N");
Clazz.defineMethod (c$, "putLong", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, new Long (value));
}, "~S,~N");
Clazz.defineMethod (c$, "putFloat", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, new Float (value));
}, "~S,~N");
Clazz.defineMethod (c$, "putDouble", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, new Double (value));
}, "~S,~N");
Clazz.defineMethod (c$, "putString", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~S");
Clazz.defineMethod (c$, "putCharSequence", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,CharSequence");
Clazz.defineMethod (c$, "putParcelable", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
this.mFdsKnown = false;
}, "~S,android.os.Parcelable");
Clazz.defineMethod (c$, "putParcelableArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
this.mFdsKnown = false;
}, "~S,~A");
Clazz.defineMethod (c$, "putParcelableArrayList", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
this.mFdsKnown = false;
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "putIntegerArrayList", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "putStringArrayList", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "putCharSequenceArrayList", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "putSerializable", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,java.io.Serializable");
Clazz.defineMethod (c$, "putBooleanArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putByteArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putShortArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putCharArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putIntArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putLongArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putFloatArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putDoubleArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putStringArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putCharSequenceArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putBundle", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,android.os.Bundle");
Clazz.defineMethod (c$, "getBoolean", 
function (key) {
this.unparcel ();
return this.getBoolean (key, false);
}, "~S");
Clazz.defineMethod (c$, "typeWarning", 
($fz = function (key, value, className, defaultValue, e) {
var sb =  new StringBuilder ();
sb.append ("Key ");
sb.append (key);
sb.append (" expected ");
sb.append (className);
sb.append (" but value was a ");
sb.append (value.getClass ().getName ());
sb.append (".  The default value ");
sb.append (defaultValue);
sb.append (" was returned.");
android.util.Log.w ("Bundle", sb.toString ());
android.util.Log.w ("Bundle", "Attempt to cast generated internal exception:", e);
}, $fz.isPrivate = true, $fz), "~S,~O,~S,~O,ClassCastException");
Clazz.defineMethod (c$, "typeWarning", 
($fz = function (key, value, className, e) {
this.typeWarning (key, value, className, "<null>", e);
}, $fz.isPrivate = true, $fz), "~S,~O,~S,ClassCastException");
Clazz.defineMethod (c$, "getBoolean", 
function (key, defaultValue) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return defaultValue;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Boolean", new Boolean (defaultValue), e);
return defaultValue;
} else {
throw e;
}
}
}, "~S,~B");
Clazz.defineMethod (c$, "getByte", 
function (key) {
this.unparcel ();
return this.getByte (key, 0);
}, "~S");
Clazz.defineMethod (c$, "getByte", 
function (key, defaultValue) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return defaultValue;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Byte", new Byte (defaultValue), e);
return defaultValue;
} else {
throw e;
}
}
}, "~S,~N");
Clazz.defineMethod (c$, "getChar", 
function (key) {
this.unparcel ();
return this.getChar (key, String.fromCharCode (0));
}, "~S");
Clazz.defineMethod (c$, "getChar", 
function (key, defaultValue) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return defaultValue;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Character", new Character (defaultValue), e);
return defaultValue;
} else {
throw e;
}
}
}, "~S,~N");
Clazz.defineMethod (c$, "getShort", 
function (key) {
this.unparcel ();
return this.getShort (key, 0);
}, "~S");
Clazz.defineMethod (c$, "getShort", 
function (key, defaultValue) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return defaultValue;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Short", new Short (defaultValue), e);
return defaultValue;
} else {
throw e;
}
}
}, "~S,~N");
Clazz.defineMethod (c$, "getInt", 
function (key) {
this.unparcel ();
return this.getInt (key, 0);
}, "~S");
Clazz.defineMethod (c$, "getInt", 
function (key, defaultValue) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return defaultValue;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Integer", new Integer (defaultValue), e);
return defaultValue;
} else {
throw e;
}
}
}, "~S,~N");
Clazz.defineMethod (c$, "getLong", 
function (key) {
this.unparcel ();
return this.getLong (key, 0);
}, "~S");
Clazz.defineMethod (c$, "getLong", 
function (key, defaultValue) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return defaultValue;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Long", new Long (defaultValue), e);
return defaultValue;
} else {
throw e;
}
}
}, "~S,~N");
Clazz.defineMethod (c$, "getFloat", 
function (key) {
this.unparcel ();
return this.getFloat (key, 0.0);
}, "~S");
Clazz.defineMethod (c$, "getFloat", 
function (key, defaultValue) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return defaultValue;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Float", new Float (defaultValue), e);
return defaultValue;
} else {
throw e;
}
}
}, "~S,~N");
Clazz.defineMethod (c$, "getDouble", 
function (key) {
this.unparcel ();
return this.getDouble (key, 0.0);
}, "~S");
Clazz.defineMethod (c$, "getDouble", 
function (key, defaultValue) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return defaultValue;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Double", new Double (defaultValue), e);
return defaultValue;
} else {
throw e;
}
}
}, "~S,~N");
Clazz.defineMethod (c$, "getString", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "String", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getCharSequence", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "CharSequence", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getBundle", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Bundle", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getParcelable", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Parcelable", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getParcelableArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Parcelable[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getParcelableArrayList", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "ArrayList", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getSerializable", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "Serializable", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getIntegerArrayList", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "ArrayList<Integer>", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getStringArrayList", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "ArrayList<String>", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getCharSequenceArrayList", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "ArrayList<CharSequence>", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getBooleanArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "byte[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getByteArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "byte[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getShortArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "short[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getCharArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "char[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getIntArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "int[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getLongArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "long[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getFloatArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "float[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getDoubleArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "double[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getStringArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "String[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getCharSequenceArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "CharSequence[]", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "getIBinder", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "IBinder", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "putIBinder", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
}, "~S,android.os.IBinder");
Clazz.defineMethod (c$, "putSparseParcelableArray", 
function (key, value) {
this.unparcel ();
this.mMap.put (key, value);
this.mFdsKnown = false;
}, "~S,android.util.SparseArray");
Clazz.defineMethod (c$, "getSparseParcelableArray", 
function (key) {
this.unparcel ();
var o = this.mMap.get (key);
if (o == null) {
return null;
}try {
return o;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
this.typeWarning (key, o, "SparseArray", e);
return null;
} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "readFromParcel", 
function (parcel) {
console.log("Missing method: readFromParcel");
}, "android.os.Parcel");
Clazz.defineStatics (c$,
"LOG_TAG", "Bundle");
c$.EMPTY = c$.prototype.EMPTY =  new android.os.Bundle ();
});
