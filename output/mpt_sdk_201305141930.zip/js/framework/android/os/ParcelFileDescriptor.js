﻿Clazz.declarePackage ("android.os");
Clazz.load (["android.os.Parcelable", "java.io.FileInputStream", "$.FileOutputStream", "android.os.Parcelable.Creator"], "android.os.ParcelFileDescriptor", ["android.os.Parcel", "java.lang.IllegalArgumentException", "$.IllegalStateException", "$.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFileDescriptor = null;
this.mClosed = false;
this.mParcelDescriptor = null;
Clazz.instantialize (this, arguments);
}, android.os, "ParcelFileDescriptor", null, android.os.Parcelable);
c$.open = Clazz.defineMethod (c$, "open", 
function (file, mode) {
var path = file.getPath ();
var security = System.getSecurityManager ();
if (security != null) {
security.checkRead (path);
if ((mode & 536870912) != 0) {
security.checkWrite (path);
}}if ((mode & 805306368) == 0) {
throw  new IllegalArgumentException ("Must specify MODE_READ_ONLY, MODE_WRITE_ONLY, or MODE_READ_WRITE");
}var fd = android.os.Parcel.openFileDescriptor (path, mode);
return fd != null ?  new android.os.ParcelFileDescriptor (fd) : null;
}, "java.io.File,~N");
c$.dup = Clazz.defineMethod (c$, "dup", 
function (orig) {
return null;
}, "java.io.FileDescriptor");
Clazz.defineMethod (c$, "dup", 
function () {
return android.os.ParcelFileDescriptor.dup (this.getFileDescriptor ());
});
c$.fromFd = Clazz.defineMethod (c$, "fromFd", 
function (fd) {
var fdesc = android.os.ParcelFileDescriptor.getFileDescriptorFromFd (fd);
return  new android.os.ParcelFileDescriptor (fdesc);
}, "~N");
c$.adoptFd = Clazz.defineMethod (c$, "adoptFd", 
function (fd) {
var fdesc = android.os.ParcelFileDescriptor.getFileDescriptorFromFdNoDup (fd);
return  new android.os.ParcelFileDescriptor (fdesc);
}, "~N");
c$.fromSocket = Clazz.defineMethod (c$, "fromSocket", 
function (socket) {
return null;
}, "java.net.Socket");
c$.fromDatagramSocket = Clazz.defineMethod (c$, "fromDatagramSocket", 
function (datagramSocket) {
return null;
}, "java.net.DatagramSocket");
c$.createPipe = Clazz.defineMethod (c$, "createPipe", 
function () {
var fds =  new Array (2);
android.os.ParcelFileDescriptor.createPipeNative (fds);
var pfds =  new Array (2);
pfds[0] =  new android.os.ParcelFileDescriptor (fds[0]);
pfds[1] =  new android.os.ParcelFileDescriptor (fds[1]);
return pfds;
});
c$.fromData = Clazz.defineMethod (c$, "fromData", 
function (data, name) {
return null;
}, "~A,~S");
Clazz.defineMethod (c$, "getFileDescriptor", 
function () {
return this.mFileDescriptor;
});
Clazz.defineMethod (c$, "getFd", 
function () {
if (this.mClosed) {
throw  new IllegalStateException ("Already closed");
}return this.getFdNative ();
});
Clazz.defineMethod (c$, "detachFd", 
function () {
return 0;
});
Clazz.defineMethod (c$, "close", 
function () {
{
if (this.mClosed) return ;
this.mClosed = true;
}if (this.mParcelDescriptor != null) {
this.mParcelDescriptor.close ();
} else {
android.os.Parcel.closeFileDescriptor (this.mFileDescriptor);
}});
Clazz.overrideMethod (c$, "toString", 
function () {
return "{ParcelFileDescriptor: " + this.mFileDescriptor + "}";
});
Clazz.defineMethod (c$, "finalize", 
function () {
try {
if (!this.mClosed) {
this.close ();
}} finally {
Clazz.superCall (this, android.os.ParcelFileDescriptor, "finalize", []);
}
});
Clazz.makeConstructor (c$, 
function (descriptor) {
this.mParcelDescriptor = descriptor;
this.mFileDescriptor = this.mParcelDescriptor.mFileDescriptor;
}, "android.os.ParcelFileDescriptor");
Clazz.makeConstructor (c$, 
function (descriptor) {
if (descriptor == null) {
throw  new NullPointerException ("descriptor must not be null");
}this.mFileDescriptor = descriptor;
this.mParcelDescriptor = null;
}, "java.io.FileDescriptor");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 1;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (out, flags) {
}, "android.os.Parcel,~N");
c$.$ParcelFileDescriptor$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.os, "ParcelFileDescriptor$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
return null;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mFd = null;
Clazz.instantialize (this, arguments);
}, android.os.ParcelFileDescriptor, "AutoCloseInputStream", java.io.FileInputStream);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.os.ParcelFileDescriptor.AutoCloseInputStream, [a.getFileDescriptor ()]);
this.mFd = a;
}, "android.os.ParcelFileDescriptor");
Clazz.defineMethod (c$, "close", 
function () {
try {
this.mFd.close ();
} finally {
Clazz.superCall (this, android.os.ParcelFileDescriptor.AutoCloseInputStream, "close", []);
}
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mFd = null;
Clazz.instantialize (this, arguments);
}, android.os.ParcelFileDescriptor, "AutoCloseOutputStream", java.io.FileOutputStream);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.os.ParcelFileDescriptor.AutoCloseOutputStream, [a.getFileDescriptor ()]);
this.mFd = a;
}, "android.os.ParcelFileDescriptor");
Clazz.defineMethod (c$, "close", 
function () {
try {
this.mFd.close ();
} finally {
Clazz.superCall (this, android.os.ParcelFileDescriptor.AutoCloseOutputStream, "close", []);
}
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"MODE_WORLD_READABLE", 0x00000001,
"MODE_WORLD_WRITEABLE", 0x00000002,
"MODE_READ_ONLY", 0x10000000,
"MODE_WRITE_ONLY", 0x20000000,
"MODE_READ_WRITE", 0x30000000,
"MODE_CREATE", 0x08000000,
"MODE_TRUNCATE", 0x04000000,
"MODE_APPEND", 0x02000000);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.os.ParcelFileDescriptor$1") ? 0 : android.os.ParcelFileDescriptor.$ParcelFileDescriptor$1$ ()), Clazz.innerTypeInstance (android.os.ParcelFileDescriptor$1, this, null));
});
