﻿Clazz.declarePackage ("android.os");
Clazz.load (["java.io.File"], "android.os.Environment", ["android.content.res.Resources", "android.os.SystemProperties"], function () {
c$ = Clazz.declareType (android.os, "Environment");
c$.getRootDirectory = Clazz.defineMethod (c$, "getRootDirectory", 
function () {
return android.os.Environment.ROOT_DIRECTORY;
});
c$.getSystemSecureDirectory = Clazz.defineMethod (c$, "getSystemSecureDirectory", 
function () {
if (android.os.Environment.isEncryptedFilesystemEnabled ()) {
return  new java.io.File (android.os.Environment.SECURE_DATA_DIRECTORY, "system");
} else {
return  new java.io.File (android.os.Environment.DATA_DIRECTORY, "system");
}});
c$.getSecureDataDirectory = Clazz.defineMethod (c$, "getSecureDataDirectory", 
function () {
if (android.os.Environment.isEncryptedFilesystemEnabled ()) {
return android.os.Environment.SECURE_DATA_DIRECTORY;
} else {
return android.os.Environment.DATA_DIRECTORY;
}});
c$.isEncryptedFilesystemEnabled = Clazz.defineMethod (c$, "isEncryptedFilesystemEnabled", 
function () {
return android.os.SystemProperties.getBoolean ("persist.security.efs.enabled", false);
});
c$.getHostExternalStorageDirectory = Clazz.defineMethod (c$, "getHostExternalStorageDirectory", 
function () {
return android.os.Environment.MEEGO_EXTERNAL_STORAGE_DIRECTORY;
});
c$.getDataDirectory = Clazz.defineMethod (c$, "getDataDirectory", 
function () {
return android.os.Environment.DATA_DIRECTORY;
});
c$.getExternalStorageDirectory = Clazz.defineMethod (c$, "getExternalStorageDirectory", 
function () {
return android.os.Environment.EXTERNAL_STORAGE_DIRECTORY;
});
c$.getExternalStoragePublicDirectory = Clazz.defineMethod (c$, "getExternalStoragePublicDirectory", 
function (type) {
return  new java.io.File (android.os.Environment.getExternalStorageDirectory (), type);
}, "~S");
c$.getExternalStorageAndroidDataDir = Clazz.defineMethod (c$, "getExternalStorageAndroidDataDir", 
function () {
return android.os.Environment.EXTERNAL_STORAGE_ANDROID_DATA_DIRECTORY;
});
c$.getExternalStorageAppDataDirectory = Clazz.defineMethod (c$, "getExternalStorageAppDataDirectory", 
function (packageName) {
return  new java.io.File (android.os.Environment.EXTERNAL_STORAGE_ANDROID_DATA_DIRECTORY, packageName);
}, "~S");
c$.getExternalStorageAppMediaDirectory = Clazz.defineMethod (c$, "getExternalStorageAppMediaDirectory", 
function (packageName) {
return  new java.io.File (android.os.Environment.EXTERNAL_STORAGE_ANDROID_MEDIA_DIRECTORY, packageName);
}, "~S");
c$.getExternalStorageAppFilesDirectory = Clazz.defineMethod (c$, "getExternalStorageAppFilesDirectory", 
function (packageName) {
return  new java.io.File ( new java.io.File (android.os.Environment.EXTERNAL_STORAGE_ANDROID_DATA_DIRECTORY, packageName), "files");
}, "~S");
c$.getExternalStorageAppCacheDirectory = Clazz.defineMethod (c$, "getExternalStorageAppCacheDirectory", 
function (packageName) {
return  new java.io.File ( new java.io.File (android.os.Environment.EXTERNAL_STORAGE_ANDROID_DATA_DIRECTORY, packageName), "cache");
}, "~S");
c$.getDownloadCacheDirectory = Clazz.defineMethod (c$, "getDownloadCacheDirectory", 
function () {
return android.os.Environment.DOWNLOAD_CACHE_DIRECTORY;
});
c$.getExternalStorageState = Clazz.defineMethod (c$, "getExternalStorageState", 
function () {
return "mounted";
});
c$.isExternalStorageRemovable = Clazz.defineMethod (c$, "isExternalStorageRemovable", 
function () {
return android.content.res.Resources.getSystem ().getBoolean (17629186);
});
c$.getDirectory = Clazz.defineMethod (c$, "getDirectory", 
function (variableName, defaultPath) {
return  new java.io.File (defaultPath);
}, "~S,~S");
c$.ROOT_DIRECTORY = c$.prototype.ROOT_DIRECTORY = android.os.Environment.getDirectory ("ANDROID_ROOT", "/system");
Clazz.defineStatics (c$,
"SYSTEM_PROPERTY_EFS_ENABLED", "persist.security.efs.enabled");
c$.DATA_DIRECTORY = c$.prototype.DATA_DIRECTORY = android.os.Environment.getDirectory ("ANDROID_DATA", "/data");
c$.SECURE_DATA_DIRECTORY = c$.prototype.SECURE_DATA_DIRECTORY = android.os.Environment.getDirectory ("ANDROID_SECURE_DATA", "/data/secure");
c$.EXTERNAL_STORAGE_DIRECTORY = c$.prototype.EXTERNAL_STORAGE_DIRECTORY = android.os.Environment.getDirectory ("EXTERNAL_STORAGE", "/sdcard");
c$.MEEGO_EXTERNAL_STORAGE_DIRECTORY = c$.prototype.MEEGO_EXTERNAL_STORAGE_DIRECTORY = android.os.Environment.getDirectory ("MEEGO_EXTERNAL_STORAGE", "/media");
c$.EXTERNAL_STORAGE_ANDROID_DATA_DIRECTORY = c$.prototype.EXTERNAL_STORAGE_ANDROID_DATA_DIRECTORY =  new java.io.File ( new java.io.File (android.os.Environment.getDirectory ("EXTERNAL_STORAGE", "/sdcard"), "Android"), "data");
c$.EXTERNAL_STORAGE_ANDROID_MEDIA_DIRECTORY = c$.prototype.EXTERNAL_STORAGE_ANDROID_MEDIA_DIRECTORY =  new java.io.File ( new java.io.File (android.os.Environment.getDirectory ("EXTERNAL_STORAGE", "/sdcard"), "Android"), "media");
c$.DOWNLOAD_CACHE_DIRECTORY = c$.prototype.DOWNLOAD_CACHE_DIRECTORY = android.os.Environment.getDirectory ("DOWNLOAD_CACHE", "/cache");
Clazz.defineStatics (c$,
"DIRECTORY_MUSIC", "Music",
"DIRECTORY_PODCASTS", "Podcasts",
"DIRECTORY_RINGTONES", "Ringtones",
"DIRECTORY_ALARMS", "Alarms",
"DIRECTORY_NOTIFICATIONS", "Notifications",
"DIRECTORY_PICTURES", "Pictures",
"DIRECTORY_MOVIES", "Movies",
"DIRECTORY_DOWNLOADS", "Download",
"DIRECTORY_DCIM", "DCIM",
"MEDIA_REMOVED", "removed",
"MEDIA_UNMOUNTED", "unmounted",
"MEDIA_CHECKING", "checking",
"MEDIA_NOFS", "nofs",
"MEDIA_MOUNTED", "mounted",
"MEDIA_MOUNTED_READ_ONLY", "mounted_ro",
"MEDIA_SHARED", "shared",
"MEDIA_BAD_REMOVAL", "bad_removal",
"MEDIA_UNMOUNTABLE", "unmountable");
});
