﻿Clazz.declarePackage ("android.os");
c$ = Clazz.declareType (android.os, "SystemClock");
c$.sleep = Clazz.defineMethod (c$, "sleep", 
function (ms) {
}, "~N");
c$.setCurrentTimeMillis = Clazz.defineMethod (c$, "setCurrentTimeMillis", 
function (millis) {
return false;
}, "~N");
c$.uptimeMillis = Clazz.defineMethod (c$, "uptimeMillis", 
function () {
var now = 0;
var d = new Date();
now = d.getTime();
return now;
});
c$.elapsedRealtime = Clazz.defineMethod (c$, "elapsedRealtime", 
function () {
return 0;
});
c$.currentThreadTimeMillis = Clazz.defineMethod (c$, "currentThreadTimeMillis", 
function () {
return 0;
});
