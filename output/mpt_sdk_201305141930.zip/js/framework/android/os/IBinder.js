﻿Clazz.declarePackage ("android.os");
c$ = Clazz.declareInterface (android.os, "IBinder");
Clazz.declareInterface (android.os.IBinder, "DeathRecipient");
Clazz.defineStatics (c$,
"FIRST_CALL_TRANSACTION", 0x00000001,
"LAST_CALL_TRANSACTION", 0x00ffffff,
"PING_TRANSACTION", 1599098439,
"DUMP_TRANSACTION", 1598311760,
"INTERFACE_TRANSACTION", 1598968902,
"FLAG_ONEWAY", 0x00000001);
