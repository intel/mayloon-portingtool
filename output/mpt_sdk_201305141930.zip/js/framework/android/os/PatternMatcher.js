﻿Clazz.declarePackage ("android.os");
Clazz.load (["android.os.Parcelable"], "android.os.PatternMatcher", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mPattern = null;
this.mType = 0;
Clazz.instantialize (this, arguments);
}, android.os, "PatternMatcher", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function (pattern, type) {
this.mPattern = pattern;
this.mType = type;
}, "~S,~N");
Clazz.defineMethod (c$, "getPath", 
function () {
return this.mPattern;
});
Clazz.defineMethod (c$, "getType", 
function () {
return this.mType;
});
Clazz.defineMethod (c$, "match", 
function (str) {
return android.os.PatternMatcher.matchPattern (this.mPattern, str, this.mType);
}, "~S");
Clazz.overrideMethod (c$, "toString", 
function () {
var type = "? ";
switch (this.mType) {
case 0:
type = "LITERAL: ";
break;
case 1:
type = "PREFIX: ";
break;
case 2:
type = "GLOB: ";
break;
}
return "PatternMatcher{" + type + this.mPattern + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
c$.matchPattern = Clazz.defineMethod (c$, "matchPattern", 
function (pattern, match, type) {
if (match == null) return false;
if (type == 0) {
return pattern.equals (match);
}if (type == 1) {
return match.startsWith (pattern);
} else if (type != 2) {
return false;
}var NP = pattern.length;
if (NP <= 0) {
return match.length <= 0;
}var NM = match.length;
var ip = 0;
var im = 0;
var nextChar = pattern.charAt (0);
while ((ip < NP) && (im < NM)) {
var c = nextChar;
ip++;
nextChar = String.fromCharCode (  (ip < NP ? pattern.charAt (ip) : 0).charCodeAt (0));
var escaped = ((c).charCodeAt (0) == ('\\').charCodeAt (0));
if (escaped) {
c = nextChar;
ip++;
nextChar = String.fromCharCode (  (ip < NP ? pattern.charAt (ip) : 0).charCodeAt (0));
}if ((nextChar).charCodeAt (0) == ('*').charCodeAt (0)) {
if (!escaped && (c).charCodeAt (0) == ('.').charCodeAt (0)) {
if (ip >= (NP - 1)) {
return true;
}ip++;
nextChar = pattern.charAt (ip);
if ((nextChar).charCodeAt (0) == ('\\').charCodeAt (0)) {
ip++;
nextChar = String.fromCharCode (  (ip < NP ? pattern.charAt (ip) : 0).charCodeAt (0));
}do {
if ((match.charAt (im)).charCodeAt (0) == (nextChar).charCodeAt (0)) {
break;
}im++;
} while (im < NM);
if (im == NM) {
return false;
}ip++;
nextChar = String.fromCharCode (  (ip < NP ? pattern.charAt (ip) : 0).charCodeAt (0));
im++;
} else {
do {
if ((match.charAt (im)).charCodeAt (0) != (c).charCodeAt (0)) {
break;
}im++;
} while (im < NM);
ip++;
nextChar = String.fromCharCode (  (ip < NP ? pattern.charAt (ip) : 0).charCodeAt (0));
}} else {
if ((c).charCodeAt (0) != ('.').charCodeAt (0) && (match.charAt (im)).charCodeAt (0) != (c).charCodeAt (0)) return false;
im++;
}}
if (ip >= NP && im >= NM) {
return true;
}if (ip == NP - 2 && (pattern.charAt (ip)).charCodeAt (0) == ('.').charCodeAt (0) && (pattern.charAt (ip + 1)).charCodeAt (0) == ('*').charCodeAt (0)) {
return true;
}return false;
}, "~S,~S,~N");
Clazz.defineStatics (c$,
"PATTERN_LITERAL", 0,
"PATTERN_PREFIX", 1,
"PATTERN_SIMPLE_GLOB", 2);
});
