﻿Clazz.declarePackage ("android.os");
Clazz.load (null, "android.os.SystemProperties", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.declareType (android.os, "SystemProperties");
c$.native_get = Clazz.defineMethod (c$, "native_get", 
($fz = function (key) {
return "";
}, $fz.isPrivate = true, $fz), "~S");
c$.native_get = Clazz.defineMethod (c$, "native_get", 
($fz = function (key, def) {
return def;
}, $fz.isPrivate = true, $fz), "~S,~S");
c$.native_get_int = Clazz.defineMethod (c$, "native_get_int", 
($fz = function (key, def) {
return def;
}, $fz.isPrivate = true, $fz), "~S,~N");
c$.native_get_long = Clazz.defineMethod (c$, "native_get_long", 
($fz = function (key, def) {
return def;
}, $fz.isPrivate = true, $fz), "~S,~N");
c$.native_get_boolean = Clazz.defineMethod (c$, "native_get_boolean", 
($fz = function (key, def) {
return def;
}, $fz.isPrivate = true, $fz), "~S,~B");
c$.native_set = Clazz.defineMethod (c$, "native_set", 
($fz = function (key, def) {
}, $fz.isPrivate = true, $fz), "~S,~S");
c$.get = Clazz.defineMethod (c$, "get", 
function (key) {
if (key.length > 31) {
throw  new IllegalArgumentException ("key.length > 31");
}return android.os.SystemProperties.native_get (key);
}, "~S");
c$.get = Clazz.defineMethod (c$, "get", 
function (key, def) {
if (key.length > 31) {
throw  new IllegalArgumentException ("key.length > 31");
}return android.os.SystemProperties.native_get (key, def);
}, "~S,~S");
c$.getInt = Clazz.defineMethod (c$, "getInt", 
function (key, def) {
if (key.length > 31) {
throw  new IllegalArgumentException ("key.length > 31");
}return android.os.SystemProperties.native_get_int (key, def);
}, "~S,~N");
c$.getLong = Clazz.defineMethod (c$, "getLong", 
function (key, def) {
if (key.length > 31) {
throw  new IllegalArgumentException ("key.length > 31");
}return android.os.SystemProperties.native_get_long (key, def);
}, "~S,~N");
c$.getBoolean = Clazz.defineMethod (c$, "getBoolean", 
function (key, def) {
if (key.length > 31) {
throw  new IllegalArgumentException ("key.length > 31");
}return android.os.SystemProperties.native_get_boolean (key, def);
}, "~S,~B");
c$.set = Clazz.defineMethod (c$, "set", 
function (key, val) {
if (key.length > 31) {
throw  new IllegalArgumentException ("key.length > 31");
}if (val != null && val.length > 91) {
throw  new IllegalArgumentException ("val.length > 91");
}android.os.SystemProperties.native_set (key, val);
}, "~S,~S");
Clazz.defineStatics (c$,
"PROP_NAME_MAX", 31,
"PROP_VALUE_MAX", 91);
});
