﻿Clazz.declarePackage ("android.os");
c$ = Clazz.declareInterface (android.os, "Parcelable");
Clazz.declareInterface (android.os.Parcelable, "Creator");
Clazz.defineStatics (c$,
"PARCELABLE_WRITE_RETURN_VALUE", 0x0001,
"CONTENTS_FILE_DESCRIPTOR", 0x0001);
