﻿Clazz.declarePackage ("android.os");
Clazz.load (["android.os.IBinder"], "android.os.Binder", ["android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mOwner = null;
this.mDescriptor = null;
Clazz.instantialize (this, arguments);
}, android.os, "Binder", null, android.os.IBinder);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "attachInterface", 
function (owner, descriptor) {
this.mOwner = owner;
this.mDescriptor = descriptor;
}, "android.os.IInterface,~S");
Clazz.defineMethod (c$, "getInterfaceDescriptor", 
function () {
return this.mDescriptor;
});
Clazz.defineMethod (c$, "pingBinder", 
function () {
return true;
});
Clazz.defineMethod (c$, "isBinderAlive", 
function () {
return true;
});
Clazz.overrideMethod (c$, "queryLocalInterface", 
function (descriptor) {
if (this.mDescriptor.equals (descriptor)) {
return this.mOwner;
}return null;
}, "~S");
Clazz.defineMethod (c$, "onTransact", 
function (code, data, reply, flags) {
if (code == 1598968902) {
reply.writeString (this.getInterfaceDescriptor ());
return true;
} else if (code == 1598311760) {
return true;
}return false;
}, "~N,android.os.Parcel,android.os.Parcel,~N");
Clazz.overrideMethod (c$, "transact", 
function (code, data, reply, flags) {
android.util.Log.v ("Binder", "Transact: " + code + " to " + this);
if (data != null) {
data.setDataPosition (0);
}var r = this.onTransact (code, data, reply, flags);
if (reply != null) {
reply.setDataPosition (0);
}return r;
}, "~N,android.os.Parcel,android.os.Parcel,~N");
Clazz.overrideMethod (c$, "finalize", 
function () {
});
c$.flushPendingCommands = Clazz.defineMethod (c$, "flushPendingCommands", 
function () {
console.log("Missing method: flushPendingCommands");
});
c$.clearCallingIdentity = Clazz.defineMethod (c$, "clearCallingIdentity", 
function () {
console.log("Missing method: clearCallingIdentity");
});
c$.restoreCallingIdentity = Clazz.defineMethod (c$, "restoreCallingIdentity", 
function (token) {
console.log("Missing method: restoreCallingIdentity");
}, "~N");
c$.getCallingPid = Clazz.defineMethod (c$, "getCallingPid", 
function () {
console.log("Missing method: getCallingPid");
});
c$.getCallingUid = Clazz.defineMethod (c$, "getCallingUid", 
function () {
console.log("Missing method: getCallingUid");
});
c$.joinThreadPool = Clazz.defineMethod (c$, "joinThreadPool", 
function () {
console.log("Missing method: joinThreadPool");
});
Clazz.defineStatics (c$,
"TAG", "Binder>>>");
});
