﻿Clazz.declarePackage ("android.os");
Clazz.load (["java.lang.Exception"], "android.os.Looper", ["android.os.Message", "$.MessageQueue"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mQueue = null;
this.mRun = false;
this.mLogging = null;
Clazz.instantialize (this, arguments);
}, android.os, "Looper");
c$.prepare = Clazz.defineMethod (c$, "prepare", 
function () {
($t$ = android.os.Looper.lp =  new android.os.Looper (), android.os.Looper.prototype.lp = android.os.Looper.lp, $t$);
});
c$.prepareMainLooper = Clazz.defineMethod (c$, "prepareMainLooper", 
function () {
android.os.Looper.prepare ();
android.os.Looper.setMainLooper (android.os.Looper.myLooper ());
});
c$.setMainLooper = Clazz.defineMethod (c$, "setMainLooper", 
($fz = function (looper) {
}, $fz.isPrivate = true, $fz), "android.os.Looper");
c$.getMainLooper = Clazz.defineMethod (c$, "getMainLooper", 
function () {
return null;
});
c$.loop = Clazz.defineMethod (c$, "loop", 
function () {
var me = android.os.Looper.myLooper ();
var queue = me.mQueue;
while (true) {
var msg = queue.next ();
if (msg != null) {
if (msg.target == null) {
return ;
}if (me.mLogging != null) me.mLogging.println (">>>>> Dispatching to " + msg.target.getClass ().getName () + " " + (msg.callback == null ? "null" : msg.callback.getClass ().getName ()) + ": " + msg.what);
msg.target.dispatchMessage (msg);
if (me.mLogging != null) me.mLogging.println ("<<<<< Finished to    " + msg.target.getClass ().getName () + " " + (msg.callback == null ? "null" : msg.callback.getClass ().getName ()));
msg.recycle ();
}}
});
c$.myLooper = Clazz.defineMethod (c$, "myLooper", 
function () {
return android.os.Looper.lp;
});
Clazz.defineMethod (c$, "setMessageLogging", 
function (printer) {
this.mLogging = printer;
}, "android.util.Printer");
c$.myQueue = Clazz.defineMethod (c$, "myQueue", 
function () {
return android.os.Looper.myLooper ().mQueue;
});
Clazz.makeConstructor (c$, 
($fz = function () {
this.mQueue =  new android.os.MessageQueue ();
this.mRun = true;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "quit", 
function () {
var msg = android.os.Message.obtain ();
this.mQueue.enqueueMessage (msg, 0);
});
Clazz.defineMethod (c$, "getQueue", 
function () {
return this.mQueue;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return "Looper{" + Integer.toHexString (System.identityHashCode (this)) + "}";
});
Clazz.defineMethod (c$, "getThread", 
function () {
console.log("Missing method: getThread");
});
Clazz.pu$h ();
c$ = Clazz.declareType (android.os.Looper, "HandlerException", Exception);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.os.Looper.HandlerException, [android.os.Looper.HandlerException.createMessage (b), b]);
}, "android.os.Message,Throwable");
c$.createMessage = Clazz.defineMethod (c$, "createMessage", 
function (a) {
var b = a.getMessage ();
if (b == null) {
b = a.toString ();
}return b;
}, "Throwable");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"lp", null,
"mMainLooper", null);
});
