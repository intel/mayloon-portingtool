﻿Clazz.declarePackage ("android.os");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.os.Message", ["android.os.Bundle", "$.SystemClock", "android.util.TimeUtils", "java.lang.RuntimeException", "$.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.what = 0;
this.arg1 = 0;
this.arg2 = 0;
this.obj = null;
this.replyTo = null;
this.when = 0;
this.data = null;
this.target = null;
this.callback = null;
this.next = null;
Clazz.instantialize (this, arguments);
}, android.os, "Message", null, android.os.Parcelable);
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function () {
{
if (android.os.Message.mPool != null) {
var m = android.os.Message.mPool;
($t$ = android.os.Message.mPool = m.next, android.os.Message.prototype.mPool = android.os.Message.mPool, $t$);
m.next = null;
return m;
}}return  new android.os.Message ();
});
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (orig) {
var m = android.os.Message.obtain ();
m.what = orig.what;
m.arg1 = orig.arg1;
m.arg2 = orig.arg2;
m.obj = orig.obj;
m.replyTo = orig.replyTo;
if (orig.data != null) {
m.data =  new android.os.Bundle (orig.data);
}m.target = orig.target;
m.callback = orig.callback;
return m;
}, "android.os.Message");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (h) {
var m = android.os.Message.obtain ();
m.target = h;
return m;
}, "android.os.Handler");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (h, callback) {
var m = android.os.Message.obtain ();
m.target = h;
m.callback = callback;
return m;
}, "android.os.Handler,Runnable");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (h, what) {
var m = android.os.Message.obtain ();
m.target = h;
m.what = what;
return m;
}, "android.os.Handler,~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (h, what, obj) {
var m = android.os.Message.obtain ();
m.target = h;
m.what = what;
m.obj = obj;
return m;
}, "android.os.Handler,~N,~O");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (h, what, arg1, arg2) {
var m = android.os.Message.obtain ();
m.target = h;
m.what = what;
m.arg1 = arg1;
m.arg2 = arg2;
return m;
}, "android.os.Handler,~N,~N,~N");
c$.obtain = Clazz.defineMethod (c$, "obtain", 
function (h, what, arg1, arg2, obj) {
var m = android.os.Message.obtain ();
m.target = h;
m.what = what;
m.arg1 = arg1;
m.arg2 = arg2;
m.obj = obj;
return m;
}, "android.os.Handler,~N,~N,~N,~O");
Clazz.defineMethod (c$, "recycle", 
function () {
{
if (android.os.Message.mPoolSize < 10) {
this.clearForRecycle ();
this.next = android.os.Message.mPool;
($t$ = android.os.Message.mPool = this, android.os.Message.prototype.mPool = android.os.Message.mPool, $t$);
}}});
Clazz.defineMethod (c$, "copyFrom", 
function (o) {
this.what = o.what;
this.arg1 = o.arg1;
this.arg2 = o.arg2;
this.obj = o.obj;
this.replyTo = o.replyTo;
if (o.data != null) {
this.data = o.data.clone ();
} else {
this.data = null;
}}, "android.os.Message");
Clazz.defineMethod (c$, "getWhen", 
function () {
return this.when;
});
Clazz.defineMethod (c$, "setTarget", 
function (target) {
this.target = target;
}, "android.os.Handler");
Clazz.defineMethod (c$, "getTarget", 
function () {
return this.target;
});
Clazz.defineMethod (c$, "getCallback", 
function () {
return this.callback;
});
Clazz.defineMethod (c$, "getData", 
function () {
if (this.data == null) {
this.data =  new android.os.Bundle ();
}return this.data;
});
Clazz.defineMethod (c$, "peekData", 
function () {
return this.data;
});
Clazz.defineMethod (c$, "setData", 
function (data) {
this.data = data;
}, "android.os.Bundle");
Clazz.defineMethod (c$, "sendToTarget", 
function () {
this.target.sendMessage (this);
});
Clazz.defineMethod (c$, "clearForRecycle", 
function () {
this.what = 0;
this.arg1 = 0;
this.arg2 = 0;
this.obj = null;
this.replyTo = null;
this.when = 0;
this.target = null;
this.callback = null;
this.data = null;
});
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "toString", 
function () {
return this.toString (android.os.SystemClock.uptimeMillis ());
});
Clazz.defineMethod (c$, "toString", 
function (now) {
var b =  new StringBuilder ();
b.append ("{ what=");
b.append (this.what);
b.append (" when=");
android.util.TimeUtils.formatDuration (this.when - now, b);
if (this.arg1 != 0) {
b.append (" arg1=");
b.append (this.arg1);
}if (this.arg2 != 0) {
b.append (" arg2=");
b.append (this.arg2);
}if (this.obj != null) {
b.append (" obj=");
b.append (this.obj);
}b.append (" }");
return b.toString ();
}, "~N");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
if (this.callback != null) {
throw  new RuntimeException ("Can't marshal callbacks across processes.");
}}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "readFromParcel", 
($fz = function (source) {
}, $fz.isPrivate = true, $fz), "android.os.Parcel");
c$.$Message$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.os, "Message$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (source) {
var msg = android.os.Message.obtain ();
msg.readFromParcel (source);
return msg;
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
c$.mPoolSync = c$.prototype.mPoolSync =  new JavaObject ();
Clazz.defineStatics (c$,
"mPool", null,
"mPoolSize", 0,
"MAX_POOL_SIZE", 10);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.os.Message$1") ? 0 : android.os.Message.$Message$1$ ()), Clazz.innerTypeInstance (android.os.Message$1, this, null));
});
