﻿Clazz.declarePackage ("android.os");
Clazz.load (null, "android.os.PerformanceCollector", ["android.os.Bundle", "$.SystemClock", "java.lang.Runtime", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPerfWriter = null;
this.mPerfSnapshot = null;
this.mPerfMeasurement = null;
this.mSnapshotCpuTime = 0;
this.mSnapshotExecTime = 0;
this.mCpuTime = 0;
this.mExecTime = 0;
Clazz.instantialize (this, arguments);
}, android.os, "PerformanceCollector");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (writer) {
this.setPerformanceResultsWriter (writer);
}, "android.os.PerformanceCollector.PerformanceResultsWriter");
Clazz.defineMethod (c$, "setPerformanceResultsWriter", 
function (writer) {
this.mPerfWriter = writer;
}, "android.os.PerformanceCollector.PerformanceResultsWriter");
Clazz.defineMethod (c$, "beginSnapshot", 
function (label) {
if (this.mPerfWriter != null) this.mPerfWriter.writeBeginSnapshot (label);
this.startPerformanceSnapshot ();
}, "~S");
Clazz.defineMethod (c$, "endSnapshot", 
function () {
this.endPerformanceSnapshot ();
if (this.mPerfWriter != null) this.mPerfWriter.writeEndSnapshot (this.mPerfSnapshot);
return this.mPerfSnapshot;
});
Clazz.defineMethod (c$, "startTiming", 
function (label) {
if (this.mPerfWriter != null) this.mPerfWriter.writeStartTiming (label);
this.mPerfMeasurement =  new android.os.Bundle ();
this.mPerfMeasurement.putParcelableArrayList ("iterations",  new java.util.ArrayList ());
this.mExecTime = android.os.SystemClock.uptimeMillis ();
}, "~S");
Clazz.defineMethod (c$, "addIteration", 
function (label) {
this.mExecTime = android.os.SystemClock.uptimeMillis () - this.mExecTime;
var iteration =  new android.os.Bundle ();
iteration.putString ("label", label);
iteration.putLong ("execution_time", this.mExecTime);
iteration.putLong ("cpu_time", this.mCpuTime);
this.mPerfMeasurement.getParcelableArrayList ("iterations").add (iteration);
this.mExecTime = android.os.SystemClock.uptimeMillis ();
return iteration;
}, "~S");
Clazz.defineMethod (c$, "stopTiming", 
function (label) {
this.addIteration (label);
if (this.mPerfWriter != null) this.mPerfWriter.writeStopTiming (this.mPerfMeasurement);
return this.mPerfMeasurement;
}, "~S");
Clazz.defineMethod (c$, "addMeasurement", 
function (label, value) {
if (this.mPerfWriter != null) this.mPerfWriter.writeMeasurement (label, value);
}, "~S,~N");
Clazz.defineMethod (c$, "addMeasurement", 
function (label, value) {
if (this.mPerfWriter != null) this.mPerfWriter.writeMeasurement (label, value);
}, "~S,~N");
Clazz.defineMethod (c$, "addMeasurement", 
function (label, value) {
if (this.mPerfWriter != null) this.mPerfWriter.writeMeasurement (label, value);
}, "~S,~S");
Clazz.defineMethod (c$, "startPerformanceSnapshot", 
($fz = function () {
this.mPerfSnapshot =  new android.os.Bundle ();
var binderCounts = android.os.PerformanceCollector.getBinderCounts ();
for (var key, $key = binderCounts.keySet ().iterator (); $key.hasNext () && ((key = $key.next ()) || true);) {
this.mPerfSnapshot.putLong ("pre_" + key, binderCounts.getLong (key));
}
android.os.PerformanceCollector.startAllocCounting ();
this.mSnapshotExecTime = android.os.SystemClock.uptimeMillis ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "endPerformanceSnapshot", 
($fz = function () {
this.mSnapshotExecTime = android.os.SystemClock.uptimeMillis () - this.mSnapshotExecTime;
android.os.PerformanceCollector.stopAllocCounting ();
var runtime = Runtime.getRuntime ();
var dalvikMax = Math.floor (runtime.totalMemory () / 1024);
var dalvikFree = Math.floor (runtime.freeMemory () / 1024);
var dalvikAllocated = dalvikMax - dalvikFree;
var binderCounts = android.os.PerformanceCollector.getBinderCounts ();
for (var key, $key = binderCounts.keySet ().iterator (); $key.hasNext () && ((key = $key.next ()) || true);) {
this.mPerfSnapshot.putLong (key, binderCounts.getLong (key));
}
var allocCounts = android.os.PerformanceCollector.getAllocCounts ();
for (var key, $key = allocCounts.keySet ().iterator (); $key.hasNext () && ((key = $key.next ()) || true);) {
this.mPerfSnapshot.putLong (key, allocCounts.getLong (key));
}
this.mPerfSnapshot.putLong ("execution_time", this.mSnapshotExecTime);
this.mPerfSnapshot.putLong ("cpu_time", this.mSnapshotCpuTime);
this.mPerfSnapshot.putLong ("java_size", dalvikMax);
this.mPerfSnapshot.putLong ("java_allocated", dalvikAllocated);
this.mPerfSnapshot.putLong ("java_free", dalvikFree);
}, $fz.isPrivate = true, $fz));
c$.startAllocCounting = Clazz.defineMethod (c$, "startAllocCounting", 
($fz = function () {
Runtime.getRuntime ().gc ();
Runtime.getRuntime ().runFinalization ();
Runtime.getRuntime ().gc ();
}, $fz.isPrivate = true, $fz));
c$.stopAllocCounting = Clazz.defineMethod (c$, "stopAllocCounting", 
($fz = function () {
Runtime.getRuntime ().gc ();
Runtime.getRuntime ().runFinalization ();
Runtime.getRuntime ().gc ();
}, $fz.isPrivate = true, $fz));
c$.getAllocCounts = Clazz.defineMethod (c$, "getAllocCounts", 
($fz = function () {
var results =  new android.os.Bundle ();
return results;
}, $fz.isPrivate = true, $fz));
c$.getBinderCounts = Clazz.defineMethod (c$, "getBinderCounts", 
($fz = function () {
var results =  new android.os.Bundle ();
return results;
}, $fz.isPrivate = true, $fz));
Clazz.declareInterface (android.os.PerformanceCollector, "PerformanceResultsWriter");
Clazz.defineStatics (c$,
"METRIC_KEY_ITERATIONS", "iterations",
"METRIC_KEY_LABEL", "label",
"METRIC_KEY_CPU_TIME", "cpu_time",
"METRIC_KEY_EXECUTION_TIME", "execution_time",
"METRIC_KEY_PRE_RECEIVED_TRANSACTIONS", "pre_received_transactions",
"METRIC_KEY_PRE_SENT_TRANSACTIONS", "pre_sent_transactions",
"METRIC_KEY_RECEIVED_TRANSACTIONS", "received_transactions",
"METRIC_KEY_SENT_TRANSACTIONS", "sent_transactions",
"METRIC_KEY_GC_INVOCATION_COUNT", "gc_invocation_count",
"METRIC_KEY_JAVA_ALLOCATED", "java_allocated",
"METRIC_KEY_JAVA_FREE", "java_free",
"METRIC_KEY_JAVA_PRIVATE_DIRTY", "java_private_dirty",
"METRIC_KEY_JAVA_PSS", "java_pss",
"METRIC_KEY_JAVA_SHARED_DIRTY", "java_shared_dirty",
"METRIC_KEY_JAVA_SIZE", "java_size",
"METRIC_KEY_NATIVE_ALLOCATED", "native_allocated",
"METRIC_KEY_NATIVE_FREE", "native_free",
"METRIC_KEY_NATIVE_PRIVATE_DIRTY", "native_private_dirty",
"METRIC_KEY_NATIVE_PSS", "native_pss",
"METRIC_KEY_NATIVE_SHARED_DIRTY", "native_shared_dirty",
"METRIC_KEY_NATIVE_SIZE", "native_size",
"METRIC_KEY_GLOBAL_ALLOC_COUNT", "global_alloc_count",
"METRIC_KEY_GLOBAL_ALLOC_SIZE", "global_alloc_size",
"METRIC_KEY_GLOBAL_FREED_COUNT", "global_freed_count",
"METRIC_KEY_GLOBAL_FREED_SIZE", "global_freed_size",
"METRIC_KEY_OTHER_PRIVATE_DIRTY", "other_private_dirty",
"METRIC_KEY_OTHER_PSS", "other_pss",
"METRIC_KEY_OTHER_SHARED_DIRTY", "other_shared_dirty");
});
