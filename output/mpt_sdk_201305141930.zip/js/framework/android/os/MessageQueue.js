﻿Clazz.declarePackage ("android.os");
Clazz.load (["java.util.ArrayList"], "android.os.MessageQueue", ["android.os.SystemClock", "android.util.AndroidRuntimeException", "$.Log", "java.lang.NullPointerException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mMessages = null;
this.mIdleHandlers = null;
this.mPendingIdleHandlers = null;
this.mQuiting = false;
this.mQuitAllowed = true;
this.mBlocked = false;
this.mPtr = 0;
Clazz.instantialize (this, arguments);
}, android.os, "MessageQueue");
Clazz.prepareFields (c$, function () {
this.mIdleHandlers =  new java.util.ArrayList ();
});
Clazz.defineMethod (c$, "nativeInit", 
($fz = function () {
this.mPtr = ($t$ = android.os.MessageQueue.mId ++, android.os.MessageQueue.prototype.mId = android.os.MessageQueue.mId, $t$);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "nativeDestroy", 
($fz = function () {
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "nativePollOnce", 
($fz = function (ptr, timeoutMillis) {
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "nativeWake", 
($fz = function (ptr) {
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "addIdleHandler", 
function (handler) {
if (handler == null) {
throw  new NullPointerException ("Can't add a null IdleHandler");
}{
this.mIdleHandlers.add (handler);
}}, "android.os.MessageQueue.IdleHandler");
Clazz.defineMethod (c$, "removeIdleHandler", 
function (handler) {
{
this.mIdleHandlers.remove (handler);
}}, "android.os.MessageQueue.IdleHandler");
Clazz.makeConstructor (c$, 
function () {
this.nativeInit ();
});
Clazz.defineMethod (c$, "finalize", 
function () {
try {
this.nativeDestroy ();
} finally {
Clazz.superCall (this, android.os.MessageQueue, "finalize", []);
}
});
Clazz.defineMethod (c$, "next", 
function () {
var pendingIdleHandlerCount = -1;
var nextPollTimeoutMillis = 0;
for (; ; ) {
if (nextPollTimeoutMillis != 0) {
}this.nativePollOnce (this.mPtr, nextPollTimeoutMillis);
{
var now = android.os.SystemClock.uptimeMillis ();
var msg = this.mMessages;
if (msg != null) {
var when = msg.when;
if (now >= when) {
this.mBlocked = false;
this.mMessages = msg.next;
msg.next = null;
if (false) android.util.Log.v ("MessageQueue", "Returning message: " + msg);
return msg;
} else {
nextPollTimeoutMillis = Math.min (when - now, 2147483647);
}} else {
nextPollTimeoutMillis = -1;
return null;
}}pendingIdleHandlerCount = 0;
nextPollTimeoutMillis = 0;
}
});
Clazz.defineMethod (c$, "enqueueMessage", 
function (msg, when) {
if (msg.when != 0) {
throw  new android.util.AndroidRuntimeException (msg + " This message is already in use.");
}if (msg.target == null && !this.mQuitAllowed) {
throw  new RuntimeException ("Main thread not allowed to quit");
}var needWake;
{
if (this.mQuiting) {
var e =  new RuntimeException (msg.target + " sending message to a Handler on a dead thread");
android.util.Log.w ("MessageQueue", e.getMessage (), e);
return false;
} else if (msg.target == null) {
this.mQuiting = true;
}msg.when = when;
var p = this.mMessages;
if (p == null || when == 0 || when < p.when) {
msg.next = p;
this.mMessages = msg;
needWake = this.mBlocked;
if (p == null) {
this.processQueue ();
}} else {
var prev = null;
while (p != null && p.when <= when) {
prev = p;
p = p.next;
}
msg.next = prev.next;
prev.next = msg;
needWake = false;
}}if (needWake) {
this.nativeWake (this.mPtr);
}return true;
}, "android.os.Message,~N");
Clazz.defineMethod (c$, "processQueue", 
($fz = function () {
while (true) {
var msg = this.mMessages;
if (msg != null) {
if (msg.target == null) {
continue ;}if (false) android.util.Log.e ("MessageQueue", ">>>>> Dispatching to " + msg.target.getClass ().getName () + " " + (msg.callback == null ? "null" : msg.callback.getClass ().getName ()) + ": " + msg.what);
msg.target.dispatchMessage (msg);
if (false) android.util.Log.e ("MessageQueue", "<<<<< Finished to    " + msg.target.getClass ().getName () + " " + (msg.callback == null ? "null" : msg.callback.getClass ().getName ()));
msg = this.next ();
} else {
return ;
}}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "removeMessages", 
function (h, what, object, doRemove) {
{
var p = this.mMessages;
var found = false;
while (p != null && p.target === h && p.what == what && (object == null || p.obj === object)) {
if (!doRemove) return true;
found = true;
var n = p.next;
this.mMessages = n;
p.recycle ();
p = n;
}
while (p != null) {
var n = p.next;
if (n != null) {
if (n.target === h && n.what == what && (object == null || n.obj === object)) {
if (!doRemove) return true;
found = true;
var nn = n.next;
n.recycle ();
p.next = nn;
continue ;}}p = n;
}
return found;
}}, "android.os.Handler,~N,~O,~B");
Clazz.defineMethod (c$, "removeMessages", 
function (h, r, object) {
if (r == null) {
return ;
}{
var p = this.mMessages;
while (p != null && p.target === h && p.callback === r && (object == null || p.obj === object)) {
var n = p.next;
this.mMessages = n;
p.recycle ();
p = n;
}
while (p != null) {
var n = p.next;
if (n != null) {
if (n.target === h && n.callback === r && (object == null || n.obj === object)) {
var nn = n.next;
n.recycle ();
p.next = nn;
continue ;}}p = n;
}
}}, "android.os.Handler,Runnable,~O");
Clazz.defineMethod (c$, "removeCallbacksAndMessages", 
function (h, object) {
{
var p = this.mMessages;
while (p != null && p.target === h && (object == null || p.obj === object)) {
var n = p.next;
this.mMessages = n;
p.recycle ();
p = n;
}
while (p != null) {
var n = p.next;
if (n != null) {
if (n.target === h && (object == null || n.obj === object)) {
var nn = n.next;
n.recycle ();
p.next = nn;
continue ;}}p = n;
}
}}, "android.os.Handler,~O");
Clazz.declareInterface (android.os.MessageQueue, "IdleHandler");
Clazz.defineStatics (c$,
"mId", -1);
});
