﻿Clazz.declarePackage ("android.os");
Clazz.load (["java.util.regex.Pattern"], "android.os.FileUtils", ["java.io.ByteArrayOutputStream", "$.FileInputStream", "$.FileOutputStream"], function () {
c$ = Clazz.declareType (android.os, "FileUtils");
c$.sync = Clazz.defineMethod (c$, "sync", 
function (stream) {
try {
if (stream != null) {
stream.getFD ().sync ();
}return true;
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
return false;
}, "java.io.FileOutputStream");
c$.copyFile = Clazz.defineMethod (c$, "copyFile", 
function (srcFile, destFile) {
var result = false;
try {
var $in =  new java.io.FileInputStream (srcFile);
try {
result = android.os.FileUtils.copyToFile ($in, destFile);
} finally {
$in.close ();
}
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
result = false;
} else {
throw e;
}
}
return result;
}, "java.io.File,java.io.File");
c$.copyToFile = Clazz.defineMethod (c$, "copyToFile", 
function (inputStream, destFile) {
try {
if (destFile.exists ()) {
destFile.$delete ();
}var out =  new java.io.FileOutputStream (destFile);
try {
var buffer =  Clazz.newArray (4096, 0);
var bytesRead;
while ((bytesRead = inputStream.read (buffer)) >= 0) {
out.write (buffer, 0, bytesRead);
}
} finally {
out.flush ();
try {
out.getFD ().sync ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
out.close ();
}
return true;
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
return false;
} else {
throw e;
}
}
}, "java.io.InputStream,java.io.File");
c$.isFilenameSafe = Clazz.defineMethod (c$, "isFilenameSafe", 
function (file) {
return android.os.FileUtils.SAFE_FILENAME_PATTERN.matcher (file.getPath ()).matches ();
}, "java.io.File");
c$.readTextFile = Clazz.defineMethod (c$, "readTextFile", 
function (file, max, ellipsis) {
var input =  new java.io.FileInputStream (file);
try {
var size = file.length ();
if (max > 0 || (size > 0 && max == 0)) {
if (size > 0 && (max == 0 || size < max)) max = size;
var data =  Clazz.newArray (max + 1, 0);
var length = input.read (data);
if (length <= 0) return "";
if (length <= max) return  String.instantialize (data, 0, length);
if (ellipsis == null) return  String.instantialize (data, 0, max);
return  String.instantialize (data, 0, max) + ellipsis;
} else if (max < 0) {
var len;
var rolled = false;
var last = null;
var data = null;
do {
if (last != null) rolled = true;
var tmp = last;
last = data;
data = tmp;
if (data == null) data =  Clazz.newArray (-max, 0);
len = input.read (data);
} while (len == data.length);
if (last == null && len <= 0) return "";
if (last == null) return  String.instantialize (data, 0, len);
if (len > 0) {
rolled = true;
System.arraycopy (last, len, last, 0, last.length - len);
System.arraycopy (data, 0, last, last.length - len, len);
}if (ellipsis == null || !rolled) return  String.instantialize (last);
return ellipsis +  String.instantialize (last);
} else {
var contents =  new java.io.ByteArrayOutputStream ();
var len;
var data =  Clazz.newArray (1024, 0);
do {
len = input.read (data);
if (len > 0) contents.write (data, 0, len);
} while (len == data.length);
return contents.toString ();
}} finally {
input.close ();
}
}, "java.io.File,~N,~S");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.dev = 0;
this.ino = 0;
this.mode = 0;
this.nlink = 0;
this.uid = 0;
this.gid = 0;
this.rdev = 0;
this.size = 0;
this.blksize = 0;
this.blocks = 0;
this.atime = 0;
this.mtime = 0;
this.ctime = 0;
Clazz.instantialize (this, arguments);
}, android.os.FileUtils, "FileStatus");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"S_IRWXU", 00700,
"S_IRUSR", 00400,
"S_IWUSR", 00200,
"S_IXUSR", 00100,
"S_IRWXG", 00070,
"S_IRGRP", 00040,
"S_IWGRP", 00020,
"S_IXGRP", 00010,
"S_IRWXO", 00007,
"S_IROTH", 00004,
"S_IWOTH", 00002,
"S_IXOTH", 00001);
c$.SAFE_FILENAME_PATTERN = c$.prototype.SAFE_FILENAME_PATTERN = java.util.regex.Pattern.compile ("[\\w%+,./=_-]+");
});
