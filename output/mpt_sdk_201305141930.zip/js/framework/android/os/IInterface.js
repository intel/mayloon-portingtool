﻿Clazz.declarePackage ("android.os");
Clazz.declareInterface (android.os, "IInterface");
