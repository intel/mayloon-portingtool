﻿Clazz.declarePackage ("android.os");
Clazz.load (null, "android.os.PowerManager", ["java.lang.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
if (!Clazz.isClassDefined ("android.os.PowerManager.WakeLock")) {
android.os.PowerManager.$PowerManager$WakeLock$ ();
}
Clazz.instantialize (this, arguments);
}, android.os, "PowerManager");
Clazz.defineMethod (c$, "newWakeLock", 
function (flags, tag) {
if (tag == null) {
throw  new NullPointerException ("tag is null in PowerManager.newWakeLock");
}return Clazz.innerTypeInstance (android.os.PowerManager.WakeLock, this, null, flags, tag);
}, "~N,~S");
Clazz.defineMethod (c$, "goToSleep", 
function (time) {
console.log("Missing method: goToSleep");
}, "~N");
Clazz.defineMethod (c$, "reboot", 
function (reason) {
console.log("Missing method: reboot");
}, "~S");
Clazz.defineMethod (c$, "isScreenOn", 
function () {
console.log("Missing method: isScreenOn");
});
c$.$PowerManager$WakeLock$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mReleaser = null;
this.mFlags = 0;
this.mTag = null;
this.mToken = null;
this.mCount = 0;
this.mRefCounted = true;
this.mHeld = false;
Clazz.instantialize (this, arguments);
}, android.os.PowerManager, "WakeLock");
Clazz.prepareFields (c$, function () {
this.mReleaser = ((Clazz.isClassDefined ("android.os.PowerManager$WakeLock$1") ? 0 : android.os.PowerManager.WakeLock.$PowerManager$WakeLock$1$ ()), Clazz.innerTypeInstance (android.os.PowerManager$WakeLock$1, this, null));
});
Clazz.makeConstructor (c$, 
function (a, b) {
}, "~N,~S");
Clazz.defineMethod (c$, "setReferenceCounted", 
function (a) {
this.mRefCounted = a;
}, "~B");
Clazz.defineMethod (c$, "acquire", 
function () {
});
Clazz.defineMethod (c$, "acquire", 
function (a) {
this.acquire ();
}, "~N");
Clazz.defineMethod (c$, "release", 
function () {
this.release (0);
});
Clazz.defineMethod (c$, "release", 
function (a) {
}, "~N");
Clazz.defineMethod (c$, "isHeld", 
function () {
{
return this.mHeld;
}});
Clazz.overrideMethod (c$, "toString", 
function () {
{
return "WakeLock{" + Integer.toHexString (System.identityHashCode (this)) + " held=" + this.mHeld + ", refCount=" + this.mCount + "}";
}});
Clazz.overrideMethod (c$, "finalize", 
function () {
});
c$.$PowerManager$WakeLock$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.os, "PowerManager$WakeLock$1", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["android.os.PowerManager.WakeLock"].release ();
});
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"RELEASE_WAKE_LOCK", 1);
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"TAG", "PowerManager",
"WAKE_BIT_CPU_STRONG", 1,
"WAKE_BIT_CPU_WEAK", 2,
"WAKE_BIT_SCREEN_DIM", 4,
"WAKE_BIT_SCREEN_BRIGHT", 8,
"WAKE_BIT_KEYBOARD_BRIGHT", 16,
"WAKE_BIT_PROXIMITY_SCREEN_OFF", 32,
"LOCK_MASK", 63,
"PARTIAL_WAKE_LOCK", 1,
"FULL_WAKE_LOCK", 26,
"SCREEN_BRIGHT_WAKE_LOCK", 10,
"SCREEN_DIM_WAKE_LOCK", 6,
"PROXIMITY_SCREEN_OFF_WAKE_LOCK", 32,
"WAIT_FOR_PROXIMITY_NEGATIVE", 1,
"ACQUIRE_CAUSES_WAKEUP", 0x10000000,
"ON_AFTER_RELEASE", 0x20000000);
});
