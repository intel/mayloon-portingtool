﻿Clazz.declarePackage ("android.emoji");
Clazz.load (["java.util.LinkedHashMap"], "android.emoji.EmojiFactory", ["java.lang.ref.WeakReference"], function () {
c$ = Clazz.decorateAsClass (function () {
this.sCacheSize = 100;
if (!Clazz.isClassDefined ("android.emoji.EmojiFactory.CustomLinkedHashMap")) {
android.emoji.EmojiFactory.$EmojiFactory$CustomLinkedHashMap$ ();
}
this.mNativeEmojiFactory = 0;
this.mName = null;
this.mCache = null;
Clazz.instantialize (this, arguments);
}, android.emoji, "EmojiFactory");
Clazz.defineMethod (c$, "finalize", 
function () {
try {
this.nativeDestructor (this.mNativeEmojiFactory);
} finally {
Clazz.superCall (this, android.emoji.EmojiFactory, "finalize", []);
}
});
Clazz.defineMethod (c$, "name", 
function () {
return this.mName;
});
Clazz.defineMethod (c$, "getBitmapFromAndroidPua", 
function (pua) {
var cache = this.mCache.get (new Integer (pua));
if (cache == null) {
var ret = this.nativeGetBitmapFromAndroidPua (this.mNativeEmojiFactory, pua);
if (ret != null) {
this.mCache.put (new Integer (pua),  new java.lang.ref.WeakReference (ret));
}return ret;
} else {
var tmp = cache.get ();
if (tmp == null) {
var ret = this.nativeGetBitmapFromAndroidPua (this.mNativeEmojiFactory, pua);
this.mCache.put (new Integer (pua),  new java.lang.ref.WeakReference (ret));
return ret;
} else {
return tmp;
}}}, "~N");
Clazz.defineMethod (c$, "getBitmapFromVendorSpecificSjis", 
function (sjis) {
return this.getBitmapFromAndroidPua (this.getAndroidPuaFromVendorSpecificSjis (sjis));
}, "~N");
Clazz.defineMethod (c$, "getBitmapFromVendorSpecificPua", 
function (vsp) {
return this.getBitmapFromAndroidPua (this.getAndroidPuaFromVendorSpecificPua (vsp));
}, "~N");
Clazz.defineMethod (c$, "getAndroidPuaFromVendorSpecificSjis", 
function (sjis) {
return this.nativeGetAndroidPuaFromVendorSpecificSjis (this.mNativeEmojiFactory, sjis);
}, "~N");
Clazz.defineMethod (c$, "getVendorSpecificSjisFromAndroidPua", 
function (pua) {
return this.nativeGetVendorSpecificSjisFromAndroidPua (this.mNativeEmojiFactory, pua);
}, "~N");
Clazz.defineMethod (c$, "getAndroidPuaFromVendorSpecificPua", 
function (vsp) {
return this.nativeGetAndroidPuaFromVendorSpecificPua (this.mNativeEmojiFactory, vsp);
}, "~N");
Clazz.defineMethod (c$, "getAndroidPuaFromVendorSpecificPua", 
function (vspString) {
if (vspString == null) {
return null;
}var minVsp = this.nativeGetMinimumVendorSpecificPua (this.mNativeEmojiFactory);
var maxVsp = this.nativeGetMaximumVendorSpecificPua (this.mNativeEmojiFactory);
var len = vspString.length;
var codePoints =  Clazz.newArray (vspString.codePointCount (0, len), 0);
var new_len = 0;
for (var i = 0; i < len; i = vspString.offsetByCodePoints (i, 1), new_len++) {
var codePoint = vspString.codePointAt (i);
if (minVsp <= codePoint && codePoint <= maxVsp) {
var newCodePoint = this.getAndroidPuaFromVendorSpecificPua (codePoint);
if (newCodePoint > 0) {
codePoints[new_len] = newCodePoint;
continue ;}}codePoints[new_len] = codePoint;
}
return  String.instantialize (codePoints, 0, new_len);
}, "~S");
Clazz.defineMethod (c$, "getVendorSpecificPuaFromAndroidPua", 
function (pua) {
return this.nativeGetVendorSpecificPuaFromAndroidPua (this.mNativeEmojiFactory, pua);
}, "~N");
Clazz.defineMethod (c$, "getVendorSpecificPuaFromAndroidPua", 
function (puaString) {
if (puaString == null) {
return null;
}var minVsp = this.nativeGetMinimumAndroidPua (this.mNativeEmojiFactory);
var maxVsp = this.nativeGetMaximumAndroidPua (this.mNativeEmojiFactory);
var len = puaString.length;
var codePoints =  Clazz.newArray (puaString.codePointCount (0, len), 0);
var new_len = 0;
for (var i = 0; i < len; i = puaString.offsetByCodePoints (i, 1), new_len++) {
var codePoint = puaString.codePointAt (i);
if (minVsp <= codePoint && codePoint <= maxVsp) {
var newCodePoint = this.getVendorSpecificPuaFromAndroidPua (codePoint);
if (newCodePoint > 0) {
codePoints[new_len] = newCodePoint;
continue ;}}codePoints[new_len] = codePoint;
}
return  String.instantialize (codePoints, 0, new_len);
}, "~S");
Clazz.defineMethod (c$, "getMinimumAndroidPua", 
function () {
return this.nativeGetMinimumAndroidPua (this.mNativeEmojiFactory);
});
Clazz.defineMethod (c$, "getMaximumAndroidPua", 
function () {
return this.nativeGetMaximumAndroidPua (this.mNativeEmojiFactory);
});
c$.$EmojiFactory$CustomLinkedHashMap$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.emoji.EmojiFactory, "CustomLinkedHashMap", java.util.LinkedHashMap);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.emoji.EmojiFactory.CustomLinkedHashMap, [16, 0.75, true]);
});
Clazz.overrideMethod (c$, "removeEldestEntry", 
function (a) {
return this.size () > this.b$["android.emoji.EmojiFactory"].sCacheSize;
}, "java.util.Map.Entry");
c$ = Clazz.p0p ();
};
});
