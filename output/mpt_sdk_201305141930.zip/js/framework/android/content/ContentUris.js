﻿Clazz.declarePackage ("android.content");
Clazz.load (null, "android.content.ContentUris", ["java.lang.Long"], function () {
c$ = Clazz.declareType (android.content, "ContentUris");
c$.parseId = Clazz.defineMethod (c$, "parseId", 
function (contentUri) {
var last = contentUri.getLastPathSegment ();
return last == null ? -1 : Long.parseLong (last);
}, "android.net.Uri");
c$.appendId = Clazz.defineMethod (c$, "appendId", 
function (builder, id) {
return builder.appendEncodedPath (String.valueOf (id));
}, "android.net.Uri.Builder,~N");
c$.withAppendedId = Clazz.defineMethod (c$, "withAppendedId", 
function (contentUri, id) {
return android.content.ContentUris.appendId (contentUri.buildUpon (), id).build ();
}, "android.net.Uri,~N");
});
