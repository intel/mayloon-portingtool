﻿Clazz.declarePackage ("android.content");
c$ = Clazz.decorateAsClass (function () {
this.receiver = null;
this.mOuterContext = null;
this.mHander = null;
this.registered = false;
Clazz.instantialize (this, arguments);
}, android.content, "IIntentReceiver");
Clazz.makeConstructor (c$, 
function () {
this.receiver = null;
this.mOuterContext = null;
this.mHander = null;
this.registered = true;
});
Clazz.makeConstructor (c$, 
function (_receiver, _c, _h, _registered) {
this.receiver = _receiver;
this.mOuterContext = _c;
this.mHander = _h;
this.registered = _registered;
}, "android.content.BroadcastReceiver,android.content.Context,android.os.Handler,~B");
