﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.content.ContentResolver", "$.SharedPreferences", "android.app.LoadedApk", "android.os.Looper", "java.util.ArrayList", "$.HashMap", "$.HashSet"], "android.content.Context", ["android.app.ActivityManager", "$.ActivityThread", "$.AlarmManager", "$.KeyguardManager", "$.NotificationManager", "android.content.pm.PackageManager", "android.content.res.Resources", "android.database.sqlite.SQLiteDatabase", "android.location.LocationManager", "android.os.FileUtils", "$.PowerManager", "android.util.Log", "android.view.LayoutInflater", "$.ViewRoot", "$.WindowManagerImpl", "java.io.File", "$.FileInputStream", "$.FileOutputStream", "java.lang.IllegalArgumentException", "$.RuntimeException", "$.SecurityException", "java.util.WeakHashMap"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mThemeResource = 0;
this.mTheme = null;
this.mActivityToken = null;
this.mResources = null;
this.mPackageInfo = null;
this.icount = 0;
this.mActivityThread = null;
this.mReceiverInfo = null;
this.mLoadedApk = null;
this.mPreferencesDir = null;
this.mFilesDir = null;
this.mCacheDir = null;
this.mExternalFilesDir = null;
this.mExternalCacheDir = null;
this.mContentResolver = null;
this.mLayoutInflater = null;
this.mPackageManager = null;
if (!Clazz.isClassDefined ("android.content.Context.ApplicationContentResolver")) {
android.content.Context.$Context$ApplicationContentResolver$ ();
}
Clazz.instantialize (this, arguments);
}, android.content, "Context");
Clazz.prepareFields (c$, function () {
this.mReceiverInfo =  new android.app.LoadedApk ();
});
Clazz.defineMethod (c$, "getOuterContext", 
function () {
return android.content.Context.mOuterContext;
});
Clazz.makeConstructor (c$, 
function () {
($t$ = android.content.Context.mOuterContext = this, android.content.Context.prototype.mOuterContext = android.content.Context.mOuterContext, $t$);
($t$ = android.content.Context.count ++, android.content.Context.prototype.count = android.content.Context.count, $t$);
this.icount = android.content.Context.count;
android.util.Log.d ("Context", "Context is:" + this.icount);
});
c$.createSystemContext = Clazz.defineMethod (c$, "createSystemContext", 
($fz = function () {
var c =  new android.content.Context ();
c.init (null, android.content.res.Resources.getSystem (), null);
return c;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setLoadedApk", 
function (loadedApk) {
this.mLoadedApk = loadedApk;
}, "android.app.LoadedApk");
Clazz.defineMethod (c$, "getApplicationContext", 
function () {
return (this.mLoadedApk != null) ? this.mLoadedApk.getApplication () : this.mActivityThread.getApplication ();
});
c$.getSystemContext = Clazz.defineMethod (c$, "getSystemContext", 
function () {
if (android.content.Context.mSystemContext == null) {
($t$ = android.content.Context.mSystemContext = android.content.Context.createSystemContext (), android.content.Context.prototype.mSystemContext = android.content.Context.mSystemContext, $t$);
if (android.content.Context.DEBUG_PROVIDER) android.util.Log.i ("Context", "System context is:" + android.content.Context.mSystemContext.icount);
}return android.content.Context.mSystemContext;
});
Clazz.defineMethod (c$, "onKeyClick", 
function (v) {
if (v.getId () == 16908660) {
android.view.ViewRoot.simulateBack ();
}if (v.getId () == 16908659) {
android.view.ViewRoot.simulateMenu ();
}}, "android.view.View");
c$.setOuterContext = Clazz.defineMethod (c$, "setOuterContext", 
function (context) {
($t$ = android.content.Context.mOuterContext = context, android.content.Context.prototype.mOuterContext = android.content.Context.mOuterContext, $t$);
}, "android.content.Context");
Clazz.defineMethod (c$, "createPackageContext", 
function (packageName, thread) {
var pi = (android.content.Context.getSystemContext ().getSystemService ("package")).getPackageInfo (packageName, 0);
if (pi != null) {
var c =  new android.content.Context ();
c.init (pi, (android.content.Context.getSystemContext ().getSystemService ("package")).getPackageResources (packageName), thread);
if (c.mResources != null) return c;
}throw  new android.content.pm.PackageManager.NameNotFoundException ("Application package " + packageName + " not found");
}, "~S,android.app.ActivityThread");
Clazz.defineMethod (c$, "createPackageContext", 
function (packageName, flags) {
return this.createPackageContext (packageName, this.mActivityThread);
}, "~S,~N");
Clazz.defineMethod (c$, "init", 
function (pi, res, thread) {
this.mPackageInfo = pi;
this.mResources = res;
this.mActivityThread = thread;
this.mContentResolver = Clazz.innerTypeInstance (android.content.Context.ApplicationContentResolver, this, null, this, thread);
if (android.content.Context.DEBUG_PROVIDER) {
if (this.mContentResolver == null) {
android.util.Log.e ("Context", "!ApplicationContentResolver!NULL");
} else {
android.util.Log.d ("Context", "!ApplicationContentResolver!NOT NULL");
}}}, "android.content.pm.PackageInfo,android.content.res.Resources,android.app.ActivityThread");
Clazz.defineMethod (c$, "init", 
function (packageInfo, activityToken, mainThread, container) {
this.mPackageInfo = packageInfo;
this.mResources = container;
this.mActivityThread = mainThread;
this.mContentResolver = Clazz.innerTypeInstance (android.content.Context.ApplicationContentResolver, this, null, this, mainThread);
}, "android.content.pm.PackageInfo,android.os.IBinder,android.app.ActivityThread,android.content.res.Resources");
Clazz.defineMethod (c$, "isRestricted", 
function () {
return false;
});
Clazz.defineMethod (c$, "setTheme", 
function (resid) {
this.mThemeResource = resid;
}, "~N");
Clazz.defineMethod (c$, "registerReceiver", 
function (receiver, filter) {
return this.registerReceiver (receiver, filter, null, null);
}, "android.content.BroadcastReceiver,android.content.IntentFilter");
Clazz.defineMethod (c$, "registerReceiver", 
function (receiver, filter, broadcastPermission, scheduler) {
return this.registerReceiverInternal (receiver, filter, broadcastPermission, scheduler, this);
}, "android.content.BroadcastReceiver,android.content.IntentFilter,~S,android.os.Handler");
Clazz.defineMethod (c$, "registerReceiverInternal", 
($fz = function (receiver, filter, broadcastPermission, scheduler, context) {
if (receiver != null) {
if (context != null) {
if (scheduler == null) {
scheduler = this.mActivityThread.getHandler ();
}}}var rd = this.mReceiverInfo.getReceiverDispatcher (receiver, context, scheduler, true);
return android.content.Context.mActivityManager.registerReceiver (this.mActivityThread.getApplicationThread (), rd, filter, broadcastPermission);
}, $fz.isPrivate = true, $fz), "android.content.BroadcastReceiver,android.content.IntentFilter,~S,android.os.Handler,android.content.Context");
Clazz.defineMethod (c$, "unregisterReceiver", 
function (receiver) {
var rd = this.mReceiverInfo.getReceiverDispatcher (receiver, this, this.mActivityThread.getHandler (), true);
android.content.Context.mActivityManager.unregisterReceiver (rd);
}, "android.content.BroadcastReceiver");
Clazz.defineMethod (c$, "sendBroadcast", 
function (intent) {
android.content.Context.mActivityManager.broadcastIntent (this.mActivityThread.getApplicationThread (), intent, null, null, -1, null, null, null, false, false);
}, "android.content.Intent");
Clazz.defineMethod (c$, "sendBroadcast", 
function (intent, receiverPermission) {
android.content.Context.mActivityManager.broadcastIntent (this.mActivityThread.getApplicationThread (), intent, null, null, -1, null, null, receiverPermission, false, false);
}, "android.content.Intent,~S");
Clazz.defineMethod (c$, "sendOrderedBroadcast", 
function (intent, receiverPermission) {
if (this.mActivityThread == null) {
this.mActivityThread = android.app.ActivityThread.currentActivityThread ();
}android.content.Context.mActivityManager.broadcastIntent (this.mActivityThread.getApplicationThread (), intent, null, null, -1, null, null, receiverPermission, true, false);
}, "android.content.Intent,~S");
Clazz.defineMethod (c$, "sendOrderedBroadcast", 
function (intent, receiverPermission, resultReceiver, scheduler, initialCode, initialData, initialExtras) {
if (this.mActivityThread == null) {
this.mActivityThread = android.app.ActivityThread.currentActivityThread ();
}android.content.Context.mActivityManager.broadcastIntent (this.mActivityThread.getApplicationThread (), intent, null, null, -1, null, null, receiverPermission, true, false);
}, "android.content.Intent,~S,android.content.BroadcastReceiver,android.os.Handler,~N,~S,android.os.Bundle");
Clazz.defineMethod (c$, "sendStickyBroadcast", 
function (intent) {
android.content.Context.mActivityManager.broadcastIntent (this.mActivityThread.getApplicationThread (), intent, null, null, -1, null, null, null, false, true);
}, "android.content.Intent");
Clazz.defineMethod (c$, "sendStickyOrderedBroadcast", 
function (intent, resultReceiver, scheduler, initialCode, initialData, initialExtras) {
android.content.Context.mActivityManager.broadcastIntent (this.mActivityThread.getApplicationThread (), intent, null, null, -1, null, null, null, true, true);
}, "android.content.Intent,android.content.BroadcastReceiver,android.os.Handler,~N,~S,android.os.Bundle");
Clazz.defineMethod (c$, "removeStickyBroadcast", 
function (intent) {
}, "android.content.Intent");
Clazz.defineMethod (c$, "getTheme", 
function () {
if (this.mTheme == null) {
if (this.mThemeResource == 0) {
this.mThemeResource = 16973829;
}this.mTheme = this.mResources.newTheme ();
this.mTheme.applyStyle (this.mThemeResource, true);
}return this.mTheme;
});
Clazz.defineMethod (c$, "obtainStyledAttributes", 
function (attrs) {
return this.getTheme ().obtainStyledAttributes (attrs);
}, "~A");
Clazz.defineMethod (c$, "obtainStyledAttributes", 
function (resid, attrs) {
return this.getTheme ().obtainStyledAttributes (resid, attrs);
}, "~N,~A");
Clazz.defineMethod (c$, "obtainStyledAttributes", 
function (set, attrs) {
return this.getTheme ().obtainStyledAttributes (set, attrs, 0, 0);
}, "android.util.AttributeSet,~A");
Clazz.defineMethod (c$, "obtainStyledAttributes", 
function (set, attrs, defStyleAttr, defStyleRes) {
return this.getTheme ().obtainStyledAttributes (set, attrs, defStyleAttr, defStyleRes);
}, "android.util.AttributeSet,~A,~N,~N");
Clazz.defineMethod (c$, "getResources", 
function () {
return this.mResources;
});
Clazz.defineMethod (c$, "getPackageManager", 
function () {
if (this.mPackageManager == null) {
this.mPackageManager = android.content.Context.getSystemContext ().getSystemService ("package");
}return this.mPackageManager;
});
Clazz.defineMethod (c$, "getActivityManager", 
function () {
if (android.content.Context.mActivityManager != null) {
return android.content.Context.mActivityManager;
}return (($t$ = android.content.Context.mActivityManager =  new android.app.ActivityManager (this), android.content.Context.prototype.mActivityManager = android.content.Context.mActivityManager, $t$));
});
Clazz.defineMethod (c$, "getActivityThread", 
function () {
if (this.mActivityThread != null) {
return this.mActivityThread;
}return (this.mActivityThread =  new android.app.ActivityThread ());
});
Clazz.defineMethod (c$, "getText", 
function (resId) {
return this.getResources ().getText (resId);
}, "~N");
Clazz.defineMethod (c$, "getString", 
function (resId) {
return this.getResources ().getString (resId);
}, "~N");
Clazz.defineMethod (c$, "getClassLoader", 
function () {
return null;
});
Clazz.defineMethod (c$, "getSystemService", 
function (name) {
if ("layout_inflater".equals (name)) {
var inflater = this.mLayoutInflater;
if (inflater != null) {
return inflater;
}this.mLayoutInflater = inflater =  new android.view.LayoutInflater (this);
return inflater;
} else if ("activity".equals (name)) {
var am = android.content.Context.mActivityManager;
if (am != null) {
return am;
}($t$ = android.content.Context.mActivityManager = am =  new android.app.ActivityManager (this), android.content.Context.prototype.mActivityManager = android.content.Context.mActivityManager, $t$);
return am;
} else if ("package".equals (name)) {
var pm = this.mPackageManager;
if (pm != null) return pm;
this.mPackageManager = pm =  new android.content.pm.PackageManager ();
return pm;
} else if ("alarm".equals (name)) {
var am = android.content.Context.mAlarmManager;
if (am != null) {
return am;
}($t$ = android.content.Context.mAlarmManager = am =  new android.app.AlarmManager (), android.content.Context.prototype.mAlarmManager = android.content.Context.mAlarmManager, $t$);
return am;
} else if ("keyguard".equals (name)) {
var km = android.content.Context.mKeyguardManager;
if (km != null) {
return km;
}($t$ = android.content.Context.mKeyguardManager = km =  new android.app.KeyguardManager (), android.content.Context.prototype.mKeyguardManager = android.content.Context.mKeyguardManager, $t$);
return km;
} else if ("notification".equals (name)) {
var nm = android.content.Context.mNotificationManager;
if (nm != null) {
return nm;
}($t$ = android.content.Context.mNotificationManager = nm =  new android.app.NotificationManager (), android.content.Context.prototype.mNotificationManager = android.content.Context.mNotificationManager, $t$);
return nm;
} else if ("package".equals (name)) {
var pm = android.content.Context.mPowerManager;
if (pm != null) {
return pm;
}($t$ = android.content.Context.mPowerManager = pm =  new android.os.PowerManager (), android.content.Context.prototype.mPowerManager = android.content.Context.mPowerManager, $t$);
return pm;
} else if ("window".equals (name)) {
var wm = android.content.Context.mWindowManager;
if (wm != null) {
return wm;
}($t$ = android.content.Context.mWindowManager = wm =  new android.view.WindowManagerImpl (), android.content.Context.prototype.mWindowManager = android.content.Context.mWindowManager, $t$);
return wm;
} else if ("location".equals (name)) {
var lm = android.content.Context.mLocationManager;
if (lm != null) {
return lm;
}($t$ = android.content.Context.mLocationManager = lm =  new android.location.LocationManager (), android.content.Context.prototype.mLocationManager = android.content.Context.mLocationManager, $t$);
return lm;
}return null;
}, "~S");
Clazz.defineMethod (c$, "getPackageName", 
function () {
if (this.mPackageInfo != null) {
return this.mPackageInfo.packageName;
}throw  new RuntimeException ("Not supported in system context");
});
Clazz.defineMethod (c$, "startActivity", 
function (intent) {
return ;
}, "android.content.Intent");
Clazz.defineMethod (c$, "startService", 
function (service) {
service.setAllowFds (false);
var cn = this.getActivityManager ().startService (this.mActivityThread.getApplicationThread (), service, "");
if (cn != null && cn.getPackageName ().equals ("!")) {
throw  new SecurityException ("Not allowed to start service " + service + " without permission " + cn.getClassName ());
}return cn;
}, "android.content.Intent");
Clazz.defineMethod (c$, "stopService", 
function (service) {
return true;
}, "android.content.Intent");
Clazz.defineMethod (c$, "bindService", 
function (service, conn, flags) {
service.setAllowFds (false);
var res = this.getActivityManager ().bindService (this.mActivityThread.getApplicationThread (), service, "", conn, flags);
if (res < 0) {
throw  new SecurityException ("Not allowed to bind to service " + service);
}return res != 0;
}, "android.content.Intent,android.content.ServiceConnection,~N");
Clazz.defineMethod (c$, "unbindService", 
function (conn) {
if (this.mPackageInfo != null) {
this.getActivityManager ().unbindService (conn);
} else {
throw  new RuntimeException ("Not supported in system context");
}}, "android.content.ServiceConnection");
Clazz.defineMethod (c$, "setActivityToken", 
function (token) {
this.mActivityToken = token;
}, "android.os.IBinder");
Clazz.defineMethod (c$, "getActivityToken", 
function () {
return this.mActivityToken;
});
Clazz.defineMethod (c$, "openFileInput", 
function (name) {
var f = this.makeFilename (this.getFilesDir (), name);
return  new java.io.FileInputStream (f);
}, "~S");
Clazz.defineMethod (c$, "makeFilename", 
($fz = function (base, name) {
if (name.indexOf (java.io.File.separatorChar) < 0) {
return  new java.io.File (base, name);
}throw  new IllegalArgumentException ("File " + name + " contains a path separator");
}, $fz.isPrivate = true, $fz), "java.io.File,~S");
Clazz.defineMethod (c$, "openFileOutput", 
function (name, mode) {
var append = (mode & 32768) != 0;
var f = this.makeFilename (this.getFilesDir (), name);
try {
var fos =  new java.io.FileOutputStream (f, append);
return fos;
} catch (e) {
if (Clazz.instanceOf (e, java.io.FileNotFoundException)) {
} else {
throw e;
}
}
var parent = f.getParentFile ();
parent.mkdir ();
var fos =  new java.io.FileOutputStream (f, append);
return fos;
}, "~S,~N");
Clazz.defineMethod (c$, "getContentResolver", 
function () {
if (this.mContentResolver == null) {
this.mContentResolver = Clazz.innerTypeInstance (android.content.Context.ApplicationContentResolver, this, null, this, this.mActivityThread);
}return this.mContentResolver;
});
Clazz.defineMethod (c$, "openOrCreateDatabase", 
function (name, mode, factory) {
var Pname = this.getPackageName ();
var path = "/data/data/" + Pname + "/data/" + name;
var sqlitedatabase = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase (path, factory);
return sqlitedatabase;
}, "~S,~N,android.database.sqlite.SQLiteDatabase.CursorFactory");
Clazz.defineMethod (c$, "deleteDatabase", 
function (name) {
return false;
}, "~S");
Clazz.defineMethod (c$, "getDataDirFile", 
($fz = function () {
if (this.mActivityThread != null) {
return  new java.io.File (this.mActivityThread.currentPackageName ());
}throw  new RuntimeException ("Not supported in system context");
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getFilesDir", 
function () {
if (this.mFilesDir == null) {
this.mFilesDir =  new java.io.File (this.getDataDirFile (), "files");
}if (!this.mFilesDir.exists ()) {
if (!this.mFilesDir.mkdirs ()) {
return null;
}}return this.mFilesDir;
});
Clazz.defineMethod (c$, "getCacheDir", 
function () {
if (this.mCacheDir == null) {
this.mCacheDir =  new java.io.File (this.getDataDirFile (), "cache");
}if (!this.mCacheDir.exists ()) {
if (!this.mCacheDir.mkdirs ()) {
android.util.Log.w ("Context", "Unable to create cache directory");
return null;
}android.os.FileUtils.setPermissions (this.mCacheDir.getPath (), 505, -1, -1);
}return this.mCacheDir;
});
Clazz.defineMethod (c$, "getSharedPreferences", 
function (name, mode) {
var sp;
var needInitialLoad = false;
{
name = this.getPackageName () + name;
sp = android.content.Context.sSharedPrefs.get (name);
if (sp != null && !sp.hasFileChangedUnexpectedly ()) {
return sp;
}if (sp == null) {
sp =  new android.content.Context.SharedPreferencesJ2SImpl (name, mode, null);
android.content.Context.sSharedPrefs.put (name, sp);
needInitialLoad = true;
}}{
if (needInitialLoad && sp.isLoaded ()) {
return sp;
}}return sp;
}, "~S,~N");
Clazz.defineMethod (c$, "clearWallpaper", 
function () {
console.log("Missing method: clearWallpaper");
});
Clazz.defineMethod (c$, "databaseList", 
function () {
console.log("Missing method: databaseList");
});
Clazz.defineMethod (c$, "getExternalFilesDir", 
function (type) {
console.log("Missing method: getExternalFilesDir");
}, "~S");
Clazz.defineMethod (c$, "getPackageCodePath", 
function () {
console.log("Missing method: getPackageCodePath");
});
Clazz.defineMethod (c$, "fileList", 
function () {
console.log("Missing method: fileList");
});
Clazz.defineMethod (c$, "setWallpaper", 
function (data) {
console.log("Missing method: setWallpaper");
}, "java.io.InputStream");
Clazz.defineMethod (c$, "getFileStreamPath", 
function (name) {
console.log("Missing method: getFileStreamPath");
}, "~S");
Clazz.defineMethod (c$, "getPackageResourcePath", 
function () {
console.log("Missing method: getPackageResourcePath");
});
Clazz.defineMethod (c$, "getWallpaperDesiredMinimumHeight", 
function () {
console.log("Missing method: getWallpaperDesiredMinimumHeight");
});
Clazz.defineMethod (c$, "getDatabasePath", 
function (name) {
console.log("Missing method: getDatabasePath");
}, "~S");
Clazz.defineMethod (c$, "checkCallingPermission", 
function (permission) {
console.log("Missing method: checkCallingPermission");
}, "~S");
Clazz.defineMethod (c$, "getWallpaperDesiredMinimumWidth", 
function () {
console.log("Missing method: getWallpaperDesiredMinimumWidth");
});
Clazz.defineMethod (c$, "checkCallingOrSelfPermission", 
function (permission) {
console.log("Missing method: checkCallingOrSelfPermission");
}, "~S");
Clazz.defineMethod (c$, "getExternalCacheDir", 
function () {
console.log("Missing method: getExternalCacheDir");
});
Clazz.defineMethod (c$, "deleteFile", 
function (name) {
try {
var f = this.makeFilename (this.getFilesDir (), name);
if (f == null) {
return true;
}return f.$delete ();
} catch (e) {
if (Clazz.instanceOf (e, RuntimeException)) {
return false;
} else {
throw e;
}
}
}, "~S");
c$.$Context$ApplicationContentResolver$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.data = 0;
this.mMainThread = null;
Clazz.instantialize (this, arguments);
}, android.content.Context, "ApplicationContentResolver", android.content.ContentResolver);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.content.Context.ApplicationContentResolver, [a]);
if (android.content.Context.DEBUG_PROVIDER) android.util.Log.d ("Context", "ApplicationContentResolver created 0..." + a.icount);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.content.Context.ApplicationContentResolver, [a]);
this.mMainThread = b;
if (android.content.Context.DEBUG_PROVIDER) {
if (a == null) {
System.out.println ("context is null");
}if (this.mMainThread == null) {
android.util.Log.d ("Context", "mMainThread is null");
}}if (android.content.Context.DEBUG_PROVIDER) android.util.Log.d ("Context", "ApplicationContentResolver create 1..." + a.icount);
}, "android.content.Context,android.app.ActivityThread");
Clazz.defineMethod (c$, "acquireProvider", 
function (a, b) {
if (android.content.Context.DEBUG_PROVIDER) System.out.println ("Context: Calling acquireProvider(Context context, String name)");
return this.mMainThread.acquireProvider (a, b);
}, "android.content.Context,~S");
Clazz.defineMethod (c$, "acquireExistingProvider", 
function (a, b) {
return this.mMainThread.acquireExistingProvider (a, b);
}, "android.content.Context,~S");
Clazz.overrideMethod (c$, "releaseProvider", 
function (a) {
return this.mMainThread.releaseProvider (a);
}, "android.content.ContentProvider");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.appName = null;
this.mMode = 0;
this.mMap = null;
this.mLoaded = false;
this.mListeners = null;
this.returnVal = "";
if (!Clazz.isClassDefined ("android.content.Context.SharedPreferencesJ2SImpl.EditorImpl")) {
android.content.Context.SharedPreferencesJ2SImpl.$Context$SharedPreferencesJ2SImpl$EditorImpl$ ();
}
Clazz.instantialize (this, arguments);
}, android.content.Context, "SharedPreferencesJ2SImpl", null, android.content.SharedPreferences);
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.appName = a + "@";
this.mMode = b;
this.mLoaded = c != null;
this.mMap = c != null ? c :  new java.util.HashMap ();
this.mListeners =  new java.util.WeakHashMap ();
this.loadData ();
}, "~S,~N,java.util.Map");
Clazz.defineMethod (c$, "loadData", 
($fz = function () {
var size = localStorage.length;
for (var i = 0; i < size; i++) {
var key = localStorage.key(i);
if (key.indexOf(this.appName) == 0) {
var val = localStorage.getItem(key);
key = key.substr(this.appName.length);
this.mMap.put(key, val);
}
}
this.mLoaded = true;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getString", 
function (a, b) {
{
var c = this.mMap.get (a);
return c != null ? c : b;
}}, "~S,~S");
Clazz.overrideMethod (c$, "getInt", 
function (a, b) {
{
var c = this.mMap.get (a);
if (c != null) {
this.returnVal = c;
return Number(this.returnVal);
}return c != null ? c : b;
}}, "~S,~N");
Clazz.overrideMethod (c$, "getLong", 
function (a, b) {
{
var c = this.mMap.get (a);
if (c != null) {
this.returnVal = c;
return Number(this.returnVal);
}return c != null ? c : b;
}}, "~S,~N");
Clazz.overrideMethod (c$, "getFloat", 
function (a, b) {
{
var c = this.mMap.get (a);
if (c != null) {
this.returnVal = c;
return Number(this.returnVal);
}return c != null ? c : b;
}}, "~S,~N");
Clazz.overrideMethod (c$, "getBoolean", 
function (a, b) {
{
var c = this.mMap.get (a);
if (c != null) {
var d = c.toString ();
if ("true".equals (d)) {
return true;
}if ("false".equals (d)) {
return false;
}}return b;
}}, "~S,~B");
Clazz.overrideMethod (c$, "contains", 
function (a) {
{
return this.mMap.containsKey (a);
}}, "~S");
Clazz.overrideMethod (c$, "edit", 
function () {
return Clazz.innerTypeInstance (android.content.Context.SharedPreferencesJ2SImpl.EditorImpl, this, null);
});
Clazz.defineMethod (c$, "isLoaded", 
function () {
{
return this.mLoaded;
}});
Clazz.defineMethod (c$, "hasFileChangedUnexpectedly", 
function () {
return false;
});
Clazz.defineMethod (c$, "replace", 
function (a) {
{
this.mLoaded = true;
if (a != null) {
this.mMap = a;
}}}, "java.util.Map");
Clazz.overrideMethod (c$, "registerOnSharedPreferenceChangeListener", 
function (a) {
{
this.mListeners.put (a, android.content.Context.SharedPreferencesJ2SImpl.mContent);
}}, "android.content.SharedPreferences.OnSharedPreferenceChangeListener");
Clazz.overrideMethod (c$, "unregisterOnSharedPreferenceChangeListener", 
function (a) {
{
this.mListeners.remove (a);
}}, "android.content.SharedPreferences.OnSharedPreferenceChangeListener");
Clazz.overrideMethod (c$, "getAll", 
function () {
{
return  new java.util.HashMap (this.mMap);
}});
c$.$Context$SharedPreferencesJ2SImpl$EditorImpl$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mModified = null;
this.mClear = false;
this.argKey = "";
this.argVal = "";
Clazz.instantialize (this, arguments);
}, android.content.Context.SharedPreferencesJ2SImpl, "EditorImpl", null, android.content.SharedPreferences.Editor);
Clazz.prepareFields (c$, function () {
this.mModified =  new java.util.HashMap ();
});
Clazz.overrideMethod (c$, "putString", 
function (a, b) {
{
this.mModified.put (a, b);
return this;
}}, "~S,~S");
Clazz.overrideMethod (c$, "putInt", 
function (a, b) {
{
this.mModified.put (a, new Integer (b));
return this;
}}, "~S,~N");
Clazz.overrideMethod (c$, "putLong", 
function (a, b) {
{
this.mModified.put (a, new Long (b));
return this;
}}, "~S,~N");
Clazz.overrideMethod (c$, "putFloat", 
function (a, b) {
{
this.mModified.put (a, new Float (b));
return this;
}}, "~S,~N");
Clazz.overrideMethod (c$, "putBoolean", 
function (a, b) {
{
this.mModified.put (a, new Boolean (b));
return this;
}}, "~S,~B");
Clazz.overrideMethod (c$, "remove", 
function (a) {
{
this.mModified.put (a, this);
return this;
}}, "~S");
Clazz.overrideMethod (c$, "clear", 
function () {
{
this.mClear = true;
return this;
}});
Clazz.overrideMethod (c$, "apply", 
function () {
var a = this.commitToMemory ();
this.notifyListeners (a);
});
Clazz.overrideMethod (c$, "commit", 
function () {
var a = this.commitToMemory ();
this.notifyListeners (a);
return a.writeToDiskResult;
});
Clazz.defineMethod (c$, "commitToMemory", 
($fz = function () {
var a =  new android.content.Context.SharedPreferencesJ2SImpl.MemoryCommitResult ();
var b = this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mListeners.size () > 0;
if (b) {
a.keysModified =  new java.util.ArrayList ();
a.listeners =  new java.util.HashSet (this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mListeners.keySet ());
}{
if (this.mClear) {
if (!this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mMap.isEmpty ()) {
var c = this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mMap.keySet ().iterator ();
while (c.hasNext ()) {
this.argKey = this.b$["android.content.Context.SharedPreferencesJ2SImpl"].appName + c.next ();
localStorage.removeItem(this.argKey);
}
a.changesMade = true;
this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mMap.clear ();
}}this.mClear = false;
}for (var e, $e = this.mModified.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
var c = e.getKey ();
var d = e.getValue ();
this.argKey = this.b$["android.content.Context.SharedPreferencesJ2SImpl"].appName + c;
this.argVal = d.toString ();
if (d === this) {
if (!this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mMap.containsKey (c)) {
continue ;}localStorage.removeItem(this.argKey);
this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mMap.remove (c);
} else {
if (this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mMap.containsKey (c)) {
var e = this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mMap.get (c);
if (e != null && e.toString ().equals (d.toString ())) {
continue ;}}localStorage.setItem(this.argKey, this.argVal);
this.b$["android.content.Context.SharedPreferencesJ2SImpl"].mMap.put (c, d);
}a.changesMade = true;
if (b) {
a.keysModified.add (c);
}}
this.mModified.clear ();
return a;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "notifyListeners", 
($fz = function (a) {
if (a.listeners == null || a.keysModified == null || a.keysModified.size () == 0) {
return ;
}for (var b = a.keysModified.size () - 1; b >= 0; b--) {
var c = a.keysModified.get (b);
for (var listener, $listener = a.listeners.iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
if (listener != null) {
listener.onSharedPreferenceChanged (this.b$["android.content.Context.SharedPreferencesJ2SImpl"], c);
}}
}
}, $fz.isPrivate = true, $fz), "android.content.Context.SharedPreferencesJ2SImpl.MemoryCommitResult");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.keysModified = null;
this.listeners = null;
this.writeToDiskResult = true;
this.changesMade = false;
Clazz.instantialize (this, arguments);
}, android.content.Context.SharedPreferencesJ2SImpl, "MemoryCommitResult");
c$ = Clazz.p0p ();
c$.mContent = c$.prototype.mContent =  new JavaObject ();
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mFile = null;
this.mMode = 0;
this.mMap = null;
this.mDiskWritesInFlight = 0;
this.mLoaded = false;
this.mStatTimestamp = 0;
this.mStatSize = 0;
this.mWritingToDiskLock = null;
this.mListeners = null;
if (!Clazz.isClassDefined ("android.content.Context.SharedPreferencesImpl.EditorImpl")) {
android.content.Context.SharedPreferencesImpl.$Context$SharedPreferencesImpl$EditorImpl$ ();
}
Clazz.instantialize (this, arguments);
}, android.content.Context, "SharedPreferencesImpl", null, android.content.SharedPreferences);
Clazz.prepareFields (c$, function () {
this.mWritingToDiskLock =  new JavaObject ();
});
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.mFile = a;
this.mMode = b;
this.mLoaded = c != null;
this.mMap = c != null ? c :  new java.util.HashMap ();
this.mListeners =  new java.util.WeakHashMap ();
}, "java.io.File,~N,java.util.Map");
Clazz.defineMethod (c$, "isLoaded", 
function () {
{
return this.mLoaded;
}});
Clazz.defineMethod (c$, "hasFileChangedUnexpectedly", 
function () {
{
if (this.mDiskWritesInFlight > 0) {
if (false) android.util.Log.d ("Context", "disk write in flight, not unexpected.");
return false;
}}return false;
});
Clazz.defineMethod (c$, "replace", 
function (a) {
{
this.mLoaded = true;
if (a != null) {
this.mMap = a;
}}}, "java.util.Map");
Clazz.overrideMethod (c$, "registerOnSharedPreferenceChangeListener", 
function (a) {
{
this.mListeners.put (a, android.content.Context.SharedPreferencesImpl.mContent);
}}, "android.content.SharedPreferences.OnSharedPreferenceChangeListener");
Clazz.overrideMethod (c$, "unregisterOnSharedPreferenceChangeListener", 
function (a) {
{
this.mListeners.remove (a);
}}, "android.content.SharedPreferences.OnSharedPreferenceChangeListener");
Clazz.overrideMethod (c$, "getAll", 
function () {
{
return  new java.util.HashMap (this.mMap);
}});
Clazz.overrideMethod (c$, "getString", 
function (a, b) {
{
var c = this.mMap.get (a);
return c != null ? c : b;
}}, "~S,~S");
Clazz.overrideMethod (c$, "getInt", 
function (a, b) {
{
var c = this.mMap.get (a);
return c != null ? c : b;
}}, "~S,~N");
Clazz.overrideMethod (c$, "getLong", 
function (a, b) {
{
var c = this.mMap.get (a);
return c != null ? c : b;
}}, "~S,~N");
Clazz.overrideMethod (c$, "getFloat", 
function (a, b) {
{
var c = this.mMap.get (a);
return c != null ? c : b;
}}, "~S,~N");
Clazz.overrideMethod (c$, "getBoolean", 
function (a, b) {
{
var c = this.mMap.get (a);
return c != null ? c : b;
}}, "~S,~B");
Clazz.overrideMethod (c$, "contains", 
function (a) {
{
return this.mMap.containsKey (a);
}}, "~S");
Clazz.overrideMethod (c$, "edit", 
function () {
return Clazz.innerTypeInstance (android.content.Context.SharedPreferencesImpl.EditorImpl, this, null);
});
Clazz.defineMethod (c$, "enqueueDiskWrite", 
($fz = function (a, b) {
var c = ((Clazz.isClassDefined ("android.content.Context$SharedPreferencesImpl$1") ? 0 : android.content.Context.SharedPreferencesImpl.$Context$SharedPreferencesImpl$1$ ()), Clazz.innerTypeInstance (android.content.Context$SharedPreferencesImpl$1, this, Clazz.cloneFinals ("a", a, "b", b)));
var d = (b == null);
if (d) {
var e = false;
{
e = this.mDiskWritesInFlight == 1;
}if (e) {
c.run ();
return ;
}}}, $fz.isPrivate = true, $fz), "android.content.Context.SharedPreferencesImpl.MemoryCommitResult,Runnable");
c$.createFileOutputStream = Clazz.defineMethod (c$, "createFileOutputStream", 
($fz = function (a) {
var b = null;
try {
b =  new java.io.FileOutputStream (a);
} catch (e) {
if (Clazz.instanceOf (e, java.io.FileNotFoundException)) {
var c = a.getParentFile ();
if (!c.mkdir ()) {
android.util.Log.e ("Context", "Couldn't create directory for SharedPreferences file " + a);
return null;
}try {
b =  new java.io.FileOutputStream (a);
} catch (e2) {
if (Clazz.instanceOf (e2, java.io.FileNotFoundException)) {
android.util.Log.e ("Context", "Couldn't create SharedPreferences file " + a, e2);
} else {
throw e2;
}
}
} else {
throw e;
}
}
return b;
}, $fz.isPrivate = true, $fz), "java.io.File");
Clazz.defineMethod (c$, "writeToFile", 
($fz = function (a) {
if (this.mFile.exists ()) {
if (!a.changesMade) {
a.setDiskWriteResult (true);
return ;
}}var b = android.content.Context.SharedPreferencesImpl.createFileOutputStream (this.mFile);
if (b == null) {
a.setDiskWriteResult (false);
return ;
}a.setDiskWriteResult (true);
return ;
}, $fz.isPrivate = true, $fz), "android.content.Context.SharedPreferencesImpl.MemoryCommitResult");
c$.$Context$SharedPreferencesImpl$EditorImpl$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mModified = null;
this.mClear = false;
Clazz.instantialize (this, arguments);
}, android.content.Context.SharedPreferencesImpl, "EditorImpl", null, android.content.SharedPreferences.Editor);
Clazz.prepareFields (c$, function () {
this.mModified =  new java.util.HashMap ();
});
Clazz.overrideMethod (c$, "putString", 
function (a, b) {
{
this.mModified.put (a, b);
return this;
}}, "~S,~S");
Clazz.overrideMethod (c$, "putInt", 
function (a, b) {
{
this.mModified.put (a, new Integer (b));
return this;
}}, "~S,~N");
Clazz.overrideMethod (c$, "putLong", 
function (a, b) {
{
this.mModified.put (a, new Long (b));
return this;
}}, "~S,~N");
Clazz.overrideMethod (c$, "putFloat", 
function (a, b) {
{
this.mModified.put (a, new Float (b));
return this;
}}, "~S,~N");
Clazz.overrideMethod (c$, "putBoolean", 
function (a, b) {
{
this.mModified.put (a, new Boolean (b));
return this;
}}, "~S,~B");
Clazz.overrideMethod (c$, "remove", 
function (a) {
{
this.mModified.put (a, this);
return this;
}}, "~S");
Clazz.overrideMethod (c$, "clear", 
function () {
{
this.mClear = true;
return this;
}});
Clazz.overrideMethod (c$, "apply", 
function () {
var a = this.commitToMemory ();
this.notifyListeners (a);
});
Clazz.defineMethod (c$, "commitToMemory", 
($fz = function () {
var a =  new android.content.Context.SharedPreferencesImpl.MemoryCommitResult ();
{
if (this.b$["android.content.Context.SharedPreferencesImpl"].mDiskWritesInFlight > 0) {
this.b$["android.content.Context.SharedPreferencesImpl"].mMap =  new java.util.HashMap (this.b$["android.content.Context.SharedPreferencesImpl"].mMap);
}a.mapToWriteToDisk = this.b$["android.content.Context.SharedPreferencesImpl"].mMap;
this.b$["android.content.Context.SharedPreferencesImpl"].mDiskWritesInFlight++;
var b = this.b$["android.content.Context.SharedPreferencesImpl"].mListeners.size () > 0;
if (b) {
a.keysModified =  new java.util.ArrayList ();
a.listeners =  new java.util.HashSet (this.b$["android.content.Context.SharedPreferencesImpl"].mListeners.keySet ());
}{
if (this.mClear) {
if (!this.b$["android.content.Context.SharedPreferencesImpl"].mMap.isEmpty ()) {
a.changesMade = true;
this.b$["android.content.Context.SharedPreferencesImpl"].mMap.clear ();
}this.mClear = false;
}for (var e, $e = this.mModified.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
var c = e.getKey ();
var d = e.getValue ();
if (d === this) {
if (!this.b$["android.content.Context.SharedPreferencesImpl"].mMap.containsKey (c)) {
continue ;}this.b$["android.content.Context.SharedPreferencesImpl"].mMap.remove (c);
} else {
var e = false;
if (this.b$["android.content.Context.SharedPreferencesImpl"].mMap.containsKey (c)) {
var f = this.b$["android.content.Context.SharedPreferencesImpl"].mMap.get (c);
if (f != null && f.equals (d)) {
continue ;}}this.b$["android.content.Context.SharedPreferencesImpl"].mMap.put (c, d);
}a.changesMade = true;
if (b) {
a.keysModified.add (c);
}}
this.mModified.clear ();
}}return a;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "commit", 
function () {
var a = this.commitToMemory ();
this.b$["android.content.Context.SharedPreferencesImpl"].enqueueDiskWrite (a, null);
this.notifyListeners (a);
return a.writeToDiskResult;
});
Clazz.defineMethod (c$, "notifyListeners", 
($fz = function (a) {
if (a.listeners == null || a.keysModified == null || a.keysModified.size () == 0) {
return ;
}if (android.os.Looper.myLooper () === android.os.Looper.getMainLooper ()) {
for (var b = a.keysModified.size () - 1; b >= 0; b--) {
var c = a.keysModified.get (b);
for (var listener, $listener = a.listeners.iterator (); $listener.hasNext () && ((listener = $listener.next ()) || true);) {
if (listener != null) {
listener.onSharedPreferenceChanged (this.b$["android.content.Context.SharedPreferencesImpl"], c);
}}
}
} else {
}}, $fz.isPrivate = true, $fz), "android.content.Context.SharedPreferencesImpl.MemoryCommitResult");
c$ = Clazz.p0p ();
};
c$.$Context$SharedPreferencesImpl$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content, "Context$SharedPreferencesImpl$1", null, Runnable);
Clazz.defineMethod (c$, "run", 
function () {
{
this.b$["android.content.Context.SharedPreferencesImpl"].writeToFile (this.f$.a);
}{
this.b$["android.content.Context.SharedPreferencesImpl"].mDiskWritesInFlight--;
}if (this.f$.b != null) {
this.f$.b.run ();
}});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.changesMade = false;
this.keysModified = null;
this.listeners = null;
this.mapToWriteToDisk = null;
this.writeToDiskResult = false;
Clazz.instantialize (this, arguments);
}, android.content.Context.SharedPreferencesImpl, "MemoryCommitResult");
Clazz.defineMethod (c$, "setDiskWriteResult", 
function (a) {
this.writeToDiskResult = a;
}, "~B");
c$ = Clazz.p0p ();
c$.mContent = c$.prototype.mContent =  new JavaObject ();
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "Context",
"DEBUG", false,
"mOuterContext", null,
"count", 0,
"DEBUG_PROVIDER", true,
"CONTEXT_INCLUDE_CODE", 0x00000001,
"CONTEXT_IGNORE_SECURITY", 0x00000002,
"CONTEXT_RESTRICTED", 0x00000004,
"BIND_AUTO_CREATE", 0x0001,
"BIND_DEBUG_UNBIND", 0x0002,
"BIND_NOT_FOREGROUND", 0x0004,
"mSystemContext", null,
"LAYOUT_INFLATER_SERVICE", "layout_inflater",
"ACTIVITY_SERVICE", "activity",
"PACKAGE_SERVICE", "package",
"ALARM_SERVICE", "alarm",
"KEYGUARD_SERVICE", "keyguard",
"NOTIFICATION_SERVICE", "notification",
"POWER_SERVICE", "power",
"WINDOW_SERVICE", "window",
"LOCATION_SERVICE", "location",
"mActivityManager", null,
"mAlarmManager", null,
"mKeyguardManager", null,
"mNotificationManager", null,
"mPowerManager", null,
"mWindowManager", null,
"mLocationManager", null);
c$.sSharedPrefs = c$.prototype.sSharedPrefs =  new java.util.HashMap ();
Clazz.defineStatics (c$,
"MODE_PRIVATE", 0x0000,
"MODE_WORLD_READABLE", 0x0001,
"MODE_WORLD_WRITEABLE", 0x0002,
"MODE_APPEND", 0x8000);
});
