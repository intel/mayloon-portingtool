﻿Clazz.declarePackage ("android.content");
Clazz.load (null, "android.content.ContentProvider", ["android.content.ContentResolver", "android.content.res.AssetFileDescriptor", "android.os.ParcelFileDescriptor", "android.util.Log", "java.io.File", "$.FileNotFoundException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mContext = null;
this.mMyUid = 0;
this.mReadPermission = null;
this.mWritePermission = null;
this.mExported = false;
if (!Clazz.isClassDefined ("android.content.ContentProvider.Transport")) {
android.content.ContentProvider.$ContentProvider$Transport$ ();
}
Clazz.instantialize (this, arguments);
}, android.content, "ContentProvider");
Clazz.defineMethod (c$, "asBinder", 
function () {
return this;
});
Clazz.makeConstructor (c$, 
function () {
});
c$.coerceToLocalContentProvider = Clazz.defineMethod (c$, "coerceToLocalContentProvider", 
function (abstractInterface) {
return abstractInterface;
}, "android.content.ContentProvider");
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.defineMethod (c$, "setReadPermission", 
function (permission) {
this.mReadPermission = permission;
}, "~S");
Clazz.defineMethod (c$, "getReadPermission", 
function () {
return this.mReadPermission;
});
Clazz.defineMethod (c$, "setWritePermission", 
function (permission) {
this.mWritePermission = permission;
}, "~S");
Clazz.defineMethod (c$, "getWritePermission", 
function () {
return this.mWritePermission;
});
Clazz.defineMethod (c$, "bulkInsert", 
function (uri, values) {
var numValues = values.length;
for (var i = 0; i < numValues; i++) {
this.insert (uri, values[i]);
}
return numValues;
}, "android.net.Uri,~A");
Clazz.defineMethod (c$, "openFile", 
function (uri, mode) {
throw  new java.io.FileNotFoundException ("No files supported by provider at " + uri);
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "openAssetFile", 
function (uri, mode) {
var fd = this.openFile (uri, mode);
return fd != null ?  new android.content.res.AssetFileDescriptor (fd, 0, -1) : null;
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "openFileHelper", 
function (uri, mode) {
var c = this.query (uri, ["_data"], null, null, null);
var count = (c != null) ? c.getCount () : 0;
if (count != 1) {
if (c != null) {
c.close ();
}if (count == 0) {
throw  new java.io.FileNotFoundException ("No entry for " + uri);
}throw  new java.io.FileNotFoundException ("Multiple items at " + uri);
}c.moveToFirst ();
var i = c.getColumnIndex ("_data");
var path = (i >= 0 ? c.getString (i) : null);
c.close ();
if (path == null) {
throw  new java.io.FileNotFoundException ("Column _data not found.");
}var modeBits = android.content.ContentResolver.modeToMode (uri, mode);
return android.os.ParcelFileDescriptor.open ( new java.io.File (path), modeBits);
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "getStreamTypes", 
function (uri, mimeTypeFilter) {
return null;
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "openTypedAssetFile", 
function (uri, mimeTypeFilter, opts) {
if ("*/*".equals (mimeTypeFilter)) {
return this.openAssetFile (uri, "r");
}var baseType = this.getType (uri);
if (baseType != null) {
return this.openAssetFile (uri, "r");
}throw  new java.io.FileNotFoundException ("Can't open " + uri + " as type " + mimeTypeFilter);
}, "android.net.Uri,~S,android.os.Bundle");
Clazz.defineMethod (c$, "openPipeHelper", 
function (uri, mimeType, opts, args, func) {
System.out.println ("ContentProvider.openPipeHelper:not supported method");
return null;
}, "android.net.Uri,~S,android.os.Bundle,~O,android.content.ContentProvider.PipeDataWriter");
Clazz.defineMethod (c$, "isTemporary", 
function () {
return false;
});
Clazz.defineMethod (c$, "getIContentProvider", 
function () {
return this;
});
Clazz.defineMethod (c$, "attachInfo", 
function (context, info) {
if (this.mContext == null) {
this.mContext = context;
if (info != null) {
this.setReadPermission (info.readPermission);
this.setWritePermission (info.writePermission);
this.mExported = info.exported;
}System.out.println ("ContentProvider: onCreate");
this.onCreate ();
}}, "android.content.Context,android.content.pm.ProviderInfo");
Clazz.defineMethod (c$, "call", 
function (method, arg, extras) {
return null;
}, "~S,~S,android.os.Bundle");
Clazz.defineMethod (c$, "shutdown", 
function () {
android.util.Log.w ("ContentProvider", "implement ContentProvider shutdown() to make sure all database connections are gracefully shutdown");
});
Clazz.defineMethod (c$, "applyBatch", 
function (operations) {
console.log("Missing method: applyBatch");
}, "java.util.ArrayList");
Clazz.defineMethod (c$, "onLowMemory", 
function () {
console.log("Missing method: onLowMemory");
});
c$.$ContentProvider$Transport$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.content.ContentProvider, "Transport");
Clazz.defineMethod (c$, "getContentProvider", 
function () {
return this.b$["android.content.ContentProvider"];
});
Clazz.defineMethod (c$, "getProviderName", 
function () {
return this.getContentProvider ().getClass ().getName ();
});
Clazz.defineMethod (c$, "query", 
function (a, b, c, d, e) {
return this.b$["android.content.ContentProvider"].query (a, b, c, d, e);
}, "android.net.Uri,~A,~S,~A,~S");
Clazz.defineMethod (c$, "getType", 
function (a) {
return this.b$["android.content.ContentProvider"].getType (a);
}, "android.net.Uri");
Clazz.defineMethod (c$, "insert", 
function (a, b) {
return this.b$["android.content.ContentProvider"].insert (a, b);
}, "android.net.Uri,android.content.ContentValues");
Clazz.defineMethod (c$, "bulkInsert", 
function (a, b) {
return this.b$["android.content.ContentProvider"].bulkInsert (a, b);
}, "android.net.Uri,~A");
Clazz.defineMethod (c$, "$delete", 
function (a, b, c) {
return this.b$["android.content.ContentProvider"].$delete (a, b, c);
}, "android.net.Uri,~S,~A");
Clazz.defineMethod (c$, "update", 
function (a, b, c, d) {
return this.b$["android.content.ContentProvider"].update (a, b, c, d);
}, "android.net.Uri,android.content.ContentValues,~S,~A");
Clazz.defineMethod (c$, "openFile", 
function (a, b) {
return this.b$["android.content.ContentProvider"].openFile (a, b);
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "openAssetFile", 
function (a, b) {
return this.b$["android.content.ContentProvider"].openAssetFile (a, b);
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "call", 
function (a, b, c) {
return this.b$["android.content.ContentProvider"].call (a, b, c);
}, "~S,~S,android.os.Bundle");
Clazz.defineMethod (c$, "getStreamTypes", 
function (a, b) {
return this.b$["android.content.ContentProvider"].getStreamTypes (a, b);
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "openTypedAssetFile", 
function (a, b, c) {
return this.b$["android.content.ContentProvider"].openTypedAssetFile (a, b, c);
}, "android.net.Uri,~S,android.os.Bundle");
c$ = Clazz.p0p ();
};
Clazz.declareInterface (android.content.ContentProvider, "PipeDataWriter");
Clazz.defineStatics (c$,
"TAG", "ContentProvider",
"DEBUG_PROVIDER", false);
});
