﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.content.IntentFilter"], "android.content.BroadcastFilter", ["android.util.PrintWriterPrinter", "java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.receiverList = null;
this.requiredPermission = null;
Clazz.instantialize (this, arguments);
}, android.content, "BroadcastFilter", android.content.IntentFilter);
Clazz.makeConstructor (c$, 
function (_filter, _receiverList, _requiredPermission) {
Clazz.superConstructor (this, android.content.BroadcastFilter, [_filter]);
this.receiverList = _receiverList;
this.requiredPermission = _requiredPermission;
}, "android.content.IntentFilter,android.content.ReceiverList,~S");
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
this.dumpInReceiverList (pw,  new android.util.PrintWriterPrinter (), prefix);
this.receiverList.dumpLocal (pw, prefix);
}, "java.io.PrintWriter,~S");
Clazz.defineMethod (c$, "dumpBrief", 
function (pw, prefix) {
this.dumpBroadcastFilterState (pw, prefix);
}, "java.io.PrintWriter,~S");
Clazz.defineMethod (c$, "dumpInReceiverList", 
function (pw, pr, prefix) {
Clazz.superCall (this, android.content.BroadcastFilter, "dump", [pr, prefix]);
this.dumpBroadcastFilterState (pw, prefix);
}, "java.io.PrintWriter,android.util.Printer,~S");
Clazz.defineMethod (c$, "dumpBroadcastFilterState", 
function (pw, prefix) {
if (this.requiredPermission != null) {
pw.print (prefix);
pw.print ("requiredPermission=");
pw.println (this.requiredPermission);
}}, "java.io.PrintWriter,~S");
Clazz.overrideMethod (c$, "toString", 
function () {
var sb =  new StringBuilder ();
sb.append ("BroadcastFilter{");
sb.append (' ');
sb.append (this.receiverList);
sb.append ('}');
return sb.toString ();
});
});
