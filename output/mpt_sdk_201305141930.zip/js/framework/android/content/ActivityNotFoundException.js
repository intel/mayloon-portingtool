﻿Clazz.declarePackage ("android.content");
Clazz.load (["java.lang.RuntimeException"], "android.content.ActivityNotFoundException", null, function () {
c$ = Clazz.declareType (android.content, "ActivityNotFoundException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.ActivityNotFoundException, []);
});
});
