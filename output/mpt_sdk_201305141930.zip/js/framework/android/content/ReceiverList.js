﻿Clazz.declarePackage ("android.content");
Clazz.load (["java.util.ArrayList"], "android.content.ReceiverList", ["android.util.PrintWriterPrinter", "java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.owner = null;
this.app = null;
this.receiver = null;
this.pid = 0;
this.uid = 0;
this.curBroadcast = null;
this.linkedToDeath = false;
this.stringName = null;
Clazz.instantialize (this, arguments);
}, android.content, "ReceiverList", java.util.ArrayList);
Clazz.makeConstructor (c$, 
function (_owner, _app, _pid, _uid, _receiver) {
Clazz.superConstructor (this, android.content.ReceiverList, []);
this.owner = _owner;
this.receiver = _receiver;
this.app = _app;
this.pid = _pid;
this.uid = _uid;
}, "android.app.ActivityManager,android.app.ProcessRecord,~N,~N,android.content.IIntentReceiver");
Clazz.overrideMethod (c$, "equals", 
function (o) {
return this === o;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return 10086;
});
Clazz.defineMethod (c$, "binderDied", 
function () {
this.linkedToDeath = false;
});
Clazz.defineMethod (c$, "dumpLocal", 
function (pw, prefix) {
pw.print (prefix);
pw.print ("app=");
pw.print (this.app);
pw.print (" pid=");
pw.print (this.pid);
pw.print (" uid=");
pw.println (this.uid);
if (this.curBroadcast != null || this.linkedToDeath) {
pw.print (prefix);
pw.print ("curBroadcast=");
pw.print (this.curBroadcast);
pw.print (" linkedToDeath=");
pw.println (this.linkedToDeath);
}}, "java.io.PrintWriter,~S");
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
var pr =  new android.util.PrintWriterPrinter ();
this.dumpLocal (pw, prefix);
var p2 = prefix + "  ";
var N = this.size ();
for (var i = 0; i < N; i++) {
var bf = this.get (i);
pw.print (prefix);
pw.print ("Filter #");
pw.print (i);
pw.print (": BroadcastFilter{");
pw.println ('}');
bf.dumpInReceiverList (pw, pr, p2);
}
}, "java.io.PrintWriter,~S");
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.stringName != null) {
return this.stringName;
}var sb =  new StringBuilder (128);
sb.append ("ReceiverList{");
sb.append (' ');
sb.append (this.pid);
sb.append (' ');
sb.append ((this.app != null ? this.app.processName : "(unknown name)"));
sb.append ('/');
sb.append (this.uid);
sb.append ('}');
return this.stringName = sb.toString ();
});
});
