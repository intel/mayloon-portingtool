﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.content.Intent", ["android.content.ComponentName", "android.graphics.Rect", "android.net.Uri", "android.os.Bundle", "android.util.Log", "com.android.internal.R", "com.android.internal.util.XmlUtils", "java.lang.Boolean", "$.Byte", "$.Double", "$.Float", "$.Long", "$.Short", "$.StringBuilder", "java.util.HashSet"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAction = null;
this.mData = null;
this.mType = null;
this.mPackage = null;
this.mComponent = null;
this.mFlags = 0;
this.mCategories = null;
this.mExtras = null;
this.mSourceBounds = null;
Clazz.instantialize (this, arguments);
}, android.content, "Intent", null, [android.os.Parcelable, Cloneable]);
c$.createChooser = Clazz.defineMethod (c$, "createChooser", 
function (target, title) {
var intent =  new android.content.Intent ("android.intent.action.CHOOSER");
intent.putExtra ("android.intent.extra.INTENT", target);
if (title != null) {
intent.putExtra ("android.intent.extra.TITLE", title);
}return intent;
}, "android.content.Intent,CharSequence");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (o) {
this.mAction = o.mAction;
this.mData = o.mData;
this.mType = o.mType;
this.mPackage = o.mPackage;
this.mComponent = o.mComponent;
this.mFlags = o.mFlags;
if (o.mCategories != null) {
this.mCategories =  new java.util.HashSet (o.mCategories);
}if (o.mExtras != null) {
this.mExtras =  new android.os.Bundle (o.mExtras);
}if (o.mSourceBounds != null) {
this.mSourceBounds =  new android.graphics.Rect (o.mSourceBounds);
}}, "android.content.Intent");
Clazz.overrideMethod (c$, "clone", 
function () {
return  new android.content.Intent (this);
});
Clazz.makeConstructor (c$, 
($fz = function (o, all) {
this.mAction = o.mAction;
this.mData = o.mData;
this.mType = o.mType;
this.mPackage = o.mPackage;
this.mComponent = o.mComponent;
if (o.mCategories != null) {
this.mCategories =  new java.util.HashSet (o.mCategories);
}}, $fz.isPrivate = true, $fz), "android.content.Intent,~B");
Clazz.defineMethod (c$, "cloneFilter", 
function () {
return  new android.content.Intent (this, false);
});
Clazz.makeConstructor (c$, 
function (action) {
this.mAction = action;
}, "~S");
Clazz.makeConstructor (c$, 
function (action, uri) {
this.mAction = action;
this.mData = uri;
}, "~S,android.net.Uri");
Clazz.makeConstructor (c$, 
function (packageContext, cls) {
this.mComponent =  new android.content.ComponentName (packageContext, cls);
}, "android.content.Context,Class");
Clazz.makeConstructor (c$, 
function (action, uri, packageContext, cls) {
this.mAction = action;
this.mData = uri;
this.mComponent =  new android.content.ComponentName (packageContext, cls);
}, "~S,android.net.Uri,android.content.Context,Class");
Clazz.makeConstructor (c$, 
function ($in) {
}, "android.os.Parcel");
c$.parseUri = Clazz.defineMethod (c$, "parseUri", 
function (uri, flags) {
var i = 0;
if ((flags & 1) != 0) {
if (!uri.startsWith ("intent:")) {
var intent =  new android.content.Intent ("android.intent.action.VIEW");
intent.setData (android.net.Uri.parse (uri));
return intent;
}}i = uri.lastIndexOf ("#");
if (i == -1) return  new android.content.Intent ("android.intent.action.VIEW", android.net.Uri.parse (uri));
if (!uri.startsWith ("#Intent;", i)) return android.content.Intent.getIntentOld (uri);
var intent =  new android.content.Intent ("android.intent.action.VIEW");
var data = i >= 0 ? uri.substring (0, i) : null;
var scheme = null;
i += "#Intent;".length;
while (!uri.startsWith ("end", i)) {
var eq = uri.indexOf ('=', i);
var semi = uri.indexOf (';', eq);
var value = android.net.Uri.decode (uri.substring (eq + 1, semi));
if (uri.startsWith ("action=", i)) {
intent.mAction = value;
} else if (uri.startsWith ("category=", i)) {
intent.addCategory (value);
} else if (uri.startsWith ("type=", i)) {
intent.mType = value;
} else if (uri.startsWith ("launchFlags=", i)) {
intent.mFlags = Integer.decode (value).intValue ();
} else if (uri.startsWith ("package=", i)) {
intent.mPackage = value;
} else if (uri.startsWith ("component=", i)) {
intent.mComponent = android.content.ComponentName.unflattenFromString (value);
} else if (uri.startsWith ("scheme=", i)) {
scheme = value;
} else if (uri.startsWith ("sourceBounds=", i)) {
intent.mSourceBounds = android.graphics.Rect.unflattenFromString (value);
} else {
var key = android.net.Uri.decode (uri.substring (i + 2, eq));
if (intent.mExtras == null) intent.mExtras =  new android.os.Bundle ();
var b = intent.mExtras;
if (uri.startsWith ("S.", i)) b.putString (key, value);
 else if (uri.startsWith ("B.", i)) b.putBoolean (key, Boolean.parseBoolean (value));
 else if (uri.startsWith ("b.", i)) b.putByte (key, Byte.parseByte (value));
 else if (uri.startsWith ("c.", i)) b.putChar (key, value.charAt (0));
 else if (uri.startsWith ("d.", i)) b.putDouble (key, Double.parseDouble (value));
 else if (uri.startsWith ("f.", i)) b.putFloat (key, Float.parseFloat (value));
 else if (uri.startsWith ("i.", i)) b.putInt (key, Integer.parseInt (value));
 else if (uri.startsWith ("l.", i)) b.putLong (key, Long.parseLong (value));
 else if (uri.startsWith ("s.", i)) b.putShort (key, Short.parseShort (value));
}i = semi + 1;
}
if (data != null) {
if (data.startsWith ("intent:")) {
data = data.substring (7);
if (scheme != null) {
data = scheme + ':' + data;
}}if (data.length > 0) {
intent.mData = android.net.Uri.parse (data);
}}return intent;
}, "~S,~N");
c$.getIntentOld = Clazz.defineMethod (c$, "getIntentOld", 
function (uri) {
var intent;
var i = uri.lastIndexOf ('#');
if (i >= 0) {
var action = null;
var intentFragmentStart = i;
var isIntentFragment = false;
i++;
if (uri.regionMatches (i, "action(", 0, 7)) {
isIntentFragment = true;
i += 7;
var j = uri.indexOf (')', i);
action = uri.substring (i, j);
i = j + 1;
}intent =  new android.content.Intent (action);
if (uri.regionMatches (i, "categories(", 0, 11)) {
isIntentFragment = true;
i += 11;
var j = uri.indexOf (')', i);
while (i < j) {
var sep = uri.indexOf ('!', i);
if (sep < 0) sep = j;
if (i < sep) {
intent.addCategory (uri.substring (i, sep));
}i = sep + 1;
}
i = j + 1;
}if (uri.regionMatches (i, "type(", 0, 5)) {
isIntentFragment = true;
i += 5;
var j = uri.indexOf (')', i);
intent.mType = uri.substring (i, j);
i = j + 1;
}if (uri.regionMatches (i, "launchFlags(", 0, 12)) {
isIntentFragment = true;
i += 12;
var j = uri.indexOf (')', i);
intent.mFlags = Integer.decode (uri.substring (i, j)).intValue ();
i = j + 1;
}if (uri.regionMatches (i, "component(", 0, 10)) {
isIntentFragment = true;
i += 10;
var j = uri.indexOf (')', i);
var sep = uri.indexOf ('!', i);
if (sep >= 0 && sep < j) {
var pkg = uri.substring (i, sep);
var cls = uri.substring (sep + 1, j);
intent.mComponent =  new android.content.ComponentName (pkg, cls);
}i = j + 1;
}if (uri.regionMatches (i, "extras(", 0, 7)) {
isIntentFragment = true;
i += 7;
var closeParen = uri.indexOf (')', i);
while (i < closeParen) {
var j = uri.indexOf ('=', i);
var type = uri.charAt (i);
i++;
var key = uri.substring (i, j);
i = j + 1;
j = uri.indexOf ('!', i);
if (j == -1 || j >= closeParen) j = closeParen;
var value = uri.substring (i, j);
i = j;
if (intent.mExtras == null) intent.mExtras =  new android.os.Bundle ();
switch (type) {
case 'S':
intent.mExtras.putString (key, android.net.Uri.decode (value));
break;
case 'B':
intent.mExtras.putBoolean (key, Boolean.parseBoolean (value));
break;
case 'b':
intent.mExtras.putByte (key, Byte.parseByte (value));
break;
case 'c':
intent.mExtras.putChar (key, android.net.Uri.decode (value).charAt (0));
break;
case 'd':
intent.mExtras.putDouble (key, Double.parseDouble (value));
break;
case 'f':
intent.mExtras.putFloat (key, Float.parseFloat (value));
break;
case 'i':
intent.mExtras.putInt (key, Integer.parseInt (value));
break;
case 'l':
intent.mExtras.putLong (key, Long.parseLong (value));
break;
case 's':
intent.mExtras.putShort (key, Short.parseShort (value));
break;
default:
break;
}
var ch = uri.charAt (i);
if ((ch).charCodeAt (0) == (')').charCodeAt (0)) break;
i++;
}
}if (isIntentFragment) {
intent.mData = android.net.Uri.parse (uri.substring (0, intentFragmentStart));
} else {
intent.mData = android.net.Uri.parse (uri);
}if (intent.mAction == null) {
intent.mAction = "android.intent.action.VIEW";
}} else {
intent =  new android.content.Intent ("android.intent.action.VIEW", android.net.Uri.parse (uri));
}return intent;
}, "~S");
Clazz.defineMethod (c$, "getAction", 
function () {
return this.mAction;
});
Clazz.defineMethod (c$, "getData", 
function () {
return this.mData;
});
Clazz.defineMethod (c$, "getDataString", 
function () {
return this.mData != null ? this.mData.toString () : null;
});
Clazz.defineMethod (c$, "getScheme", 
function () {
return this.mData != null ? this.mData.getScheme () : null;
});
Clazz.defineMethod (c$, "getType", 
function () {
return this.mType;
});
Clazz.defineMethod (c$, "hasCategory", 
function (category) {
return this.mCategories != null && this.mCategories.contains (category);
}, "~S");
Clazz.defineMethod (c$, "getCategories", 
function () {
return this.mCategories;
});
Clazz.defineMethod (c$, "setExtrasClassLoader", 
function (loader) {
if (this.mExtras != null) {
this.mExtras.setClassLoader (loader);
}}, "ClassLoader");
Clazz.defineMethod (c$, "hasExtra", 
function (name) {
return this.mExtras != null && this.mExtras.containsKey (name);
}, "~S");
Clazz.defineMethod (c$, "hasFileDescriptors", 
function () {
return this.mExtras != null && this.mExtras.hasFileDescriptors ();
});
Clazz.defineMethod (c$, "getExtra", 
function (name) {
return this.getExtra (name, null);
}, "~S");
Clazz.defineMethod (c$, "getBooleanExtra", 
function (name, defaultValue) {
return this.mExtras == null ? defaultValue : this.mExtras.getBoolean (name, defaultValue);
}, "~S,~B");
Clazz.defineMethod (c$, "getByteExtra", 
function (name, defaultValue) {
return this.mExtras == null ? defaultValue : this.mExtras.getByte (name, defaultValue);
}, "~S,~N");
Clazz.defineMethod (c$, "getShortExtra", 
function (name, defaultValue) {
return this.mExtras == null ? defaultValue : this.mExtras.getShort (name, defaultValue);
}, "~S,~N");
Clazz.defineMethod (c$, "getCharExtra", 
function (name, defaultValue) {
return this.mExtras == null ? defaultValue : this.mExtras.getChar (name, defaultValue);
}, "~S,~N");
Clazz.defineMethod (c$, "getIntExtra", 
function (name, defaultValue) {
return this.mExtras == null ? defaultValue : this.mExtras.getInt (name, defaultValue);
}, "~S,~N");
Clazz.defineMethod (c$, "getLongExtra", 
function (name, defaultValue) {
return this.mExtras == null ? defaultValue : this.mExtras.getLong (name, defaultValue);
}, "~S,~N");
Clazz.defineMethod (c$, "getFloatExtra", 
function (name, defaultValue) {
return this.mExtras == null ? defaultValue : this.mExtras.getFloat (name, defaultValue);
}, "~S,~N");
Clazz.defineMethod (c$, "getDoubleExtra", 
function (name, defaultValue) {
return this.mExtras == null ? defaultValue : this.mExtras.getDouble (name, defaultValue);
}, "~S,~N");
Clazz.defineMethod (c$, "getStringExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getString (name);
}, "~S");
Clazz.defineMethod (c$, "getCharSequenceExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getCharSequence (name);
}, "~S");
Clazz.defineMethod (c$, "getParcelableExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getParcelable (name);
}, "~S");
Clazz.defineMethod (c$, "getParcelableArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getParcelableArray (name);
}, "~S");
Clazz.defineMethod (c$, "getParcelableArrayListExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getParcelableArrayList (name);
}, "~S");
Clazz.defineMethod (c$, "getSerializableExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getSerializable (name);
}, "~S");
Clazz.defineMethod (c$, "getIntegerArrayListExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getIntegerArrayList (name);
}, "~S");
Clazz.defineMethod (c$, "getStringArrayListExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getStringArrayList (name);
}, "~S");
Clazz.defineMethod (c$, "getCharSequenceArrayListExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getCharSequenceArrayList (name);
}, "~S");
Clazz.defineMethod (c$, "getBooleanArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getBooleanArray (name);
}, "~S");
Clazz.defineMethod (c$, "getByteArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getByteArray (name);
}, "~S");
Clazz.defineMethod (c$, "getShortArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getShortArray (name);
}, "~S");
Clazz.defineMethod (c$, "getCharArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getCharArray (name);
}, "~S");
Clazz.defineMethod (c$, "getIntArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getIntArray (name);
}, "~S");
Clazz.defineMethod (c$, "getLongArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getLongArray (name);
}, "~S");
Clazz.defineMethod (c$, "getFloatArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getFloatArray (name);
}, "~S");
Clazz.defineMethod (c$, "getDoubleArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getDoubleArray (name);
}, "~S");
Clazz.defineMethod (c$, "getStringArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getStringArray (name);
}, "~S");
Clazz.defineMethod (c$, "getCharSequenceArrayExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getCharSequenceArray (name);
}, "~S");
Clazz.defineMethod (c$, "getBundleExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getBundle (name);
}, "~S");
Clazz.defineMethod (c$, "getExtra", 
function (name, defaultValue) {
var result = defaultValue;
if (this.mExtras != null) {
var result2 = this.mExtras.get (name);
if (result2 != null) {
result = result2;
}}return result;
}, "~S,~O");
Clazz.defineMethod (c$, "getExtras", 
function () {
return (this.mExtras != null) ?  new android.os.Bundle (this.mExtras) : null;
});
Clazz.defineMethod (c$, "getFlags", 
function () {
return this.mFlags;
});
Clazz.defineMethod (c$, "getPackage", 
function () {
return this.mPackage;
});
Clazz.defineMethod (c$, "getComponent", 
function () {
return this.mComponent;
});
Clazz.defineMethod (c$, "getSourceBounds", 
function () {
return this.mSourceBounds;
});
Clazz.defineMethod (c$, "setAction", 
function (action) {
this.mAction = action;
return this;
}, "~S");
Clazz.defineMethod (c$, "setData", 
function (data) {
this.mData = data;
this.mType = null;
return this;
}, "android.net.Uri");
Clazz.defineMethod (c$, "setType", 
function (type) {
this.mData = null;
this.mType = type;
return this;
}, "~S");
Clazz.defineMethod (c$, "setDataAndType", 
function (data, type) {
this.mData = data;
this.mType = type;
return this;
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "addCategory", 
function (category) {
if (this.mCategories == null) {
this.mCategories =  new java.util.HashSet ();
}this.mCategories.add (category);
return this;
}, "~S");
Clazz.defineMethod (c$, "removeCategory", 
function (category) {
if (this.mCategories != null) {
this.mCategories.remove (category);
if (this.mCategories.size () == 0) {
this.mCategories = null;
}}}, "~S");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putBoolean (name, value);
return this;
}, "~S,~B");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putByte (name, value);
return this;
}, "~S,~N");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putChar (name, value);
return this;
}, "~S,~N");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putShort (name, value);
return this;
}, "~S,~N");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putInt (name, value);
return this;
}, "~S,~N");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putLong (name, value);
return this;
}, "~S,~N");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putFloat (name, value);
return this;
}, "~S,~N");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putDouble (name, value);
return this;
}, "~S,~N");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putString (name, value);
return this;
}, "~S,~S");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putCharSequence (name, value);
return this;
}, "~S,CharSequence");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putParcelable (name, value);
return this;
}, "~S,android.os.Parcelable");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putParcelableArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putIBinder (name, value);
return this;
}, "~S,android.os.IBinder");
Clazz.defineMethod (c$, "getIBinderExtra", 
function (name) {
return this.mExtras == null ? null : this.mExtras.getIBinder (name);
}, "~S");
Clazz.defineMethod (c$, "putParcelableArrayListExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putParcelableArrayList (name, value);
return this;
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "putIntegerArrayListExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putIntegerArrayList (name, value);
return this;
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "putStringArrayListExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putStringArrayList (name, value);
return this;
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "putCharSequenceArrayListExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putCharSequenceArrayList (name, value);
return this;
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putSerializable (name, value);
return this;
}, "~S,java.io.Serializable");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putBooleanArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putByteArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putShortArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putCharArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putIntArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putLongArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putFloatArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putDoubleArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putStringArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putCharSequenceArray (name, value);
return this;
}, "~S,~A");
Clazz.defineMethod (c$, "putExtra", 
function (name, value) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putBundle (name, value);
return this;
}, "~S,android.os.Bundle");
Clazz.defineMethod (c$, "putExtras", 
function (src) {
if (src.mExtras != null) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle (src.mExtras);
} else {
this.mExtras.putAll (src.mExtras);
}}return this;
}, "android.content.Intent");
Clazz.defineMethod (c$, "putExtras", 
function (extras) {
if (this.mExtras == null) {
this.mExtras =  new android.os.Bundle ();
}this.mExtras.putAll (extras);
return this;
}, "android.os.Bundle");
Clazz.defineMethod (c$, "replaceExtras", 
function (src) {
this.mExtras = src.mExtras != null ?  new android.os.Bundle (src.mExtras) : null;
return this;
}, "android.content.Intent");
Clazz.defineMethod (c$, "replaceExtras", 
function (extras) {
this.mExtras = extras != null ?  new android.os.Bundle (extras) : null;
return this;
}, "android.os.Bundle");
Clazz.defineMethod (c$, "removeExtra", 
function (name) {
if (this.mExtras != null) {
this.mExtras.remove (name);
if (this.mExtras.size () == 0) {
this.mExtras = null;
}}}, "~S");
Clazz.defineMethod (c$, "setFlags", 
function (flags) {
this.mFlags = flags;
return this;
}, "~N");
Clazz.defineMethod (c$, "addFlags", 
function (flags) {
this.mFlags |= flags;
return this;
}, "~N");
Clazz.defineMethod (c$, "setPackage", 
function (packageName) {
this.mPackage = packageName;
return this;
}, "~S");
Clazz.defineMethod (c$, "setComponent", 
function (component) {
this.mComponent = component;
return this;
}, "android.content.ComponentName");
Clazz.defineMethod (c$, "setClassName", 
function (packageContext, className) {
this.mComponent =  new android.content.ComponentName (packageContext, className);
return this;
}, "android.content.Context,~S");
Clazz.defineMethod (c$, "setClassName", 
function (packageName, className) {
this.mComponent =  new android.content.ComponentName (packageName, className);
return this;
}, "~S,~S");
Clazz.defineMethod (c$, "setClass", 
function (packageContext, cls) {
this.mComponent =  new android.content.ComponentName (packageContext, cls);
return this;
}, "android.content.Context,Class");
Clazz.defineMethod (c$, "setSourceBounds", 
function (r) {
if (r != null) {
this.mSourceBounds =  new android.graphics.Rect (r);
} else {
r = null;
}}, "android.graphics.Rect");
Clazz.defineMethod (c$, "fillIn", 
function (other, flags) {
var changes = 0;
if (other.mAction != null && (this.mAction == null || (flags & 1) != 0)) {
this.mAction = other.mAction;
changes |= 1;
}if ((other.mData != null || other.mType != null) && ((this.mData == null && this.mType == null) || (flags & 2) != 0)) {
this.mData = other.mData;
this.mType = other.mType;
changes |= 2;
}if (other.mCategories != null && (this.mCategories == null || (flags & 4) != 0)) {
if (other.mCategories != null) {
this.mCategories =  new java.util.HashSet (other.mCategories);
}changes |= 4;
}if (other.mPackage != null && (this.mPackage == null || (flags & 16) != 0)) {
this.mPackage = other.mPackage;
changes |= 16;
}if (other.mComponent != null && (flags & 8) != 0) {
this.mComponent = other.mComponent;
changes |= 8;
}this.mFlags |= other.mFlags;
if (other.mSourceBounds != null && (this.mSourceBounds == null || (flags & 32) != 0)) {
this.mSourceBounds =  new android.graphics.Rect (other.mSourceBounds);
changes |= 32;
}if (this.mExtras == null) {
if (other.mExtras != null) {
this.mExtras =  new android.os.Bundle (other.mExtras);
}} else if (other.mExtras != null) {
try {
var newb =  new android.os.Bundle (other.mExtras);
newb.putAll (this.mExtras);
this.mExtras = newb;
} catch (e) {
if (Clazz.instanceOf (e, RuntimeException)) {
android.util.Log.w ("Intent", "Failure filling in extras", e);
} else {
throw e;
}
}
}return changes;
}, "android.content.Intent,~N");
Clazz.defineMethod (c$, "filterEquals", 
function (other) {
if (other == null) {
return false;
}if (this.mAction !== other.mAction) {
if (this.mAction != null) {
if (!this.mAction.equals (other.mAction)) {
return false;
}} else {
if (!other.mAction.equals (this.mAction)) {
return false;
}}}if (this.mData !== other.mData) {
if (this.mData != null) {
if (!this.mData.equals (other.mData)) {
return false;
}} else {
if (!other.mData.equals (this.mData)) {
return false;
}}}if (this.mType !== other.mType) {
if (this.mType != null) {
if (!this.mType.equals (other.mType)) {
return false;
}} else {
if (!other.mType.equals (this.mType)) {
return false;
}}}if (this.mPackage !== other.mPackage) {
if (this.mPackage != null) {
if (!this.mPackage.equals (other.mPackage)) {
return false;
}} else {
if (!other.mPackage.equals (this.mPackage)) {
return false;
}}}if (this.mComponent !== other.mComponent) {
if (this.mComponent != null) {
if (!this.mComponent.equals (other.mComponent)) {
return false;
}} else {
if (!other.mComponent.equals (this.mComponent)) {
return false;
}}}if (this.mCategories !== other.mCategories) {
if (this.mCategories != null) {
if (!this.mCategories.equals (other.mCategories)) {
return false;
}} else {
if (!other.mCategories.equals (this.mCategories)) {
return false;
}}}return true;
}, "android.content.Intent");
Clazz.defineMethod (c$, "filterHashCode", 
function () {
var code = 0;
if (this.mAction != null) {
code += this.mAction.hashCode ();
}if (this.mData != null) {
code += this.mData.hashCode ();
}if (this.mType != null) {
code += this.mType.hashCode ();
}if (this.mPackage != null) {
code += this.mPackage.hashCode ();
}if (this.mComponent != null) {
code += this.mComponent.hashCode ();
}if (this.mCategories != null) {
code += this.mCategories.hashCode ();
}return code;
});
Clazz.defineMethod (c$, "toString", 
function () {
var b =  new StringBuilder (128);
b.append ("Intent { ");
this.toShortString (b, true, true);
b.append (" }");
return b.toString ();
});
Clazz.defineMethod (c$, "toShortString", 
function (comp, extras) {
var b =  new StringBuilder (128);
this.toShortString (b, comp, extras);
return b.toString ();
}, "~B,~B");
Clazz.defineMethod (c$, "toShortString", 
function (b, comp, extras) {
var first = true;
if (this.mAction != null) {
b.append ("act=").append (this.mAction);
first = false;
}if (this.mCategories != null) {
if (!first) {
b.append (' ');
}first = false;
b.append ("cat=[");
var i = this.mCategories.iterator ();
var didone = false;
while (i.hasNext ()) {
if (didone) b.append (",");
didone = true;
b.append (i.next ());
}
b.append ("]");
}if (this.mData != null) {
if (!first) {
b.append (' ');
}first = false;
b.append ("dat=");
var scheme = this.mData.getScheme ();
if (scheme != null) {
if (scheme.equalsIgnoreCase ("tel")) {
b.append ("tel:xxx-xxx-xxxx");
} else if (scheme.equalsIgnoreCase ("smsto")) {
b.append ("smsto:xxx-xxx-xxxx");
} else {
b.append (this.mData);
}} else {
b.append (this.mData);
}}if (this.mType != null) {
if (!first) {
b.append (' ');
}first = false;
b.append ("typ=").append (this.mType);
}if (this.mFlags != 0) {
if (!first) {
b.append (' ');
}first = false;
b.append ("flg=0x").append (Integer.toHexString (this.mFlags));
}if (this.mPackage != null) {
if (!first) {
b.append (' ');
}first = false;
b.append ("pkg=").append (this.mPackage);
}if (comp && this.mComponent != null) {
if (!first) {
b.append (' ');
}first = false;
b.append ("cmp=").append (this.mComponent.flattenToShortString ());
}if (this.mSourceBounds != null) {
if (!first) {
b.append (' ');
}first = false;
b.append ("bnds=").append (this.mSourceBounds.toShortString ());
}if (extras && this.mExtras != null) {
if (!first) {
b.append (' ');
}first = false;
b.append ("(has extras)");
}}, "StringBuilder,~B,~B");
Clazz.defineMethod (c$, "toURI", 
function () {
return this.toUri (0);
});
Clazz.defineMethod (c$, "toUri", 
function (flags) {
var uri =  new StringBuilder (128);
var scheme = null;
if (this.mData != null) {
var data = this.mData.toString ();
if ((flags & 1) != 0) {
var N = data.length;
for (var i = 0; i < N; i++) {
var c = data.charAt (i);
if (((c).charCodeAt (0) >= ('a').charCodeAt (0) && (c).charCodeAt (0) <= ('z').charCodeAt (0)) || ((c).charCodeAt (0) >= ('A').charCodeAt (0) && (c).charCodeAt (0) <= ('Z').charCodeAt (0)) || (c).charCodeAt (0) == ('.').charCodeAt (0) || (c).charCodeAt (0) == ('-').charCodeAt (0)) {
continue ;}if ((c).charCodeAt (0) == (':').charCodeAt (0) && i > 0) {
scheme = data.substring (0, i);
uri.append ("intent:");
data = data.substring (i + 1);
break;
}break;
}
}uri.append (data);
} else if ((flags & 1) != 0) {
uri.append ("intent:");
}uri.append ("#Intent;");
if (scheme != null) {
uri.append ("scheme=").append (scheme).append (';');
}if (this.mAction != null) {
uri.append ("action=").append (android.net.Uri.encode (this.mAction)).append (';');
}if (this.mCategories != null) {
for (var category, $category = this.mCategories.iterator (); $category.hasNext () && ((category = $category.next ()) || true);) {
uri.append ("category=").append (android.net.Uri.encode (category)).append (';');
}
}if (this.mType != null) {
uri.append ("type=").append (android.net.Uri.encode (this.mType, "/")).append (';');
}if (this.mFlags != 0) {
uri.append ("launchFlags=0x").append (Integer.toHexString (this.mFlags)).append (';');
}if (this.mPackage != null) {
uri.append ("package=").append (android.net.Uri.encode (this.mPackage)).append (';');
}if (this.mComponent != null) {
uri.append ("component=").append (android.net.Uri.encode (this.mComponent.flattenToShortString (), "/")).append (';');
}if (this.mSourceBounds != null) {
uri.append ("sourceBounds=").append (android.net.Uri.encode (this.mSourceBounds.flattenToString ())).append (';');
}if (this.mExtras != null) {
for (var key, $key = this.mExtras.keySet ().iterator (); $key.hasNext () && ((key = $key.next ()) || true);) {
var value = this.mExtras.get (key);
var entryType = Clazz.instanceOf (value, String) ? 'S' : Clazz.instanceOf (value, Boolean) ? 'B' : Clazz.instanceOf (value, Byte) ? 'b' : Clazz.instanceOf (value, Character) ? 'c' : Clazz.instanceOf (value, Double) ? 'd' : Clazz.instanceOf (value, Float) ? 'f' : Clazz.instanceOf (value, Integer) ? 'i' : Clazz.instanceOf (value, Long) ? 'l' : Clazz.instanceOf (value, Short) ? 's' : '\0';
if ((entryType).charCodeAt (0) != ('\0').charCodeAt (0)) {
uri.append (entryType);
uri.append ('.');
uri.append (android.net.Uri.encode (key));
uri.append ('=');
uri.append (android.net.Uri.encode (value.toString ()));
uri.append (';');
}}
}uri.append ("end");
return uri.toString ();
}, "~N");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return (this.mExtras != null) ? this.mExtras.describeContents () : 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (out, i) {
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "resolveActivityInfo", 
function (pm, flags) {
var ai = null;
if (this.mComponent != null) {
try {
ai = pm.getActivityInfo (this.mComponent, flags);
} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
android.util.Log.e ("Intent>>>", "resolveActivityInfo, NameNotFoundException");
} else {
throw e;
}
}
} else {
var info = pm.resolveActivity (this, 65536 | flags);
if (info != null) {
ai = info.activityInfo;
} else {
android.util.Log.e ("Intent>>>", "resolveActivityInfo, mComponent is null");
}}return ai;
}, "android.content.pm.PackageManager,~N");
Clazz.defineMethod (c$, "resolveType", 
function (context) {
return this.resolveType (context.getContentResolver ());
}, "android.content.Context");
Clazz.defineMethod (c$, "resolveType", 
function (resolver) {
if (this.mType != null) {
return this.mType;
}if (this.mData != null) {
if ("content".equals (this.mData.getScheme ())) {
return resolver.getType (this.mData);
}}return null;
}, "android.content.ContentResolver");
Clazz.defineMethod (c$, "resolveTypeIfNeeded", 
function (resolver) {
if (this.mComponent != null) {
return this.mType;
}return this.resolveType (resolver);
}, "android.content.ContentResolver");
Clazz.defineMethod (c$, "setAllowFds", 
function (allowFds) {
if (this.mExtras != null) {
this.mExtras.setAllowFds (allowFds);
}}, "~B");
c$.parseIntent = Clazz.defineMethod (c$, "parseIntent", 
function (resources, parser, attrs) {
var intent =  new android.content.Intent ();
var sa = resources.obtainAttributes (attrs, com.android.internal.R.styleable.Intent);
intent.setAction (sa.getString (2));
var data = sa.getString (3);
var mimeType = sa.getString (1);
intent.setDataAndType (data != null ? android.net.Uri.parse (data) : null, mimeType);
var packageName = sa.getString (0);
var className = sa.getString (4);
if (packageName != null && className != null) {
intent.setComponent ( new android.content.ComponentName (packageName, className));
}sa.recycle ();
var outerDepth = parser.getDepth ();
var type;
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type == 3 || type == 4) {
continue ;}var nodeName = parser.getName ();
if (nodeName.equals ("category")) {
sa = resources.obtainAttributes (attrs, com.android.internal.R.styleable.IntentCategory);
var cat = sa.getString (0);
sa.recycle ();
if (cat != null) {
intent.addCategory (cat);
}com.android.internal.util.XmlUtils.skipCurrentTag (parser);
} else if (nodeName.equals ("extra")) {
if (intent.mExtras == null) {
intent.mExtras =  new android.os.Bundle ();
}com.android.internal.util.XmlUtils.skipCurrentTag (parser);
} else {
com.android.internal.util.XmlUtils.skipCurrentTag (parser);
}}
return intent;
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "readFromParcel", 
function ($in) {
console.log("Missing method: readFromParcel");
}, "android.os.Parcel");
Clazz.defineMethod (c$, "Intent", 
function (action) {
console.log("Missing method: Intent");
}, "~S");
c$.getIntent = Clazz.defineMethod (c$, "getIntent", 
function (uri) {
console.log("Missing method: getIntent");
}, "~S");
Clazz.defineMethod (c$, "getIntent", 
function () {
console.log("Missing method: getIntent");
});
Clazz.defineMethod (c$, "Intent", 
function (packageContext, cls) {
console.log("Missing method: Intent");
}, "android.content.Context,Class");
Clazz.defineMethod (c$, "Intent", 
function (o) {
console.log("Missing method: Intent");
}, "android.content.Intent");
Clazz.defineMethod (c$, "Intent", 
function () {
console.log("Missing method: Intent");
});
c$.$Intent$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content, "Intent$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
return  new android.content.Intent ($in);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.packageName = null;
this.resourceName = null;
Clazz.instantialize (this, arguments);
}, android.content.Intent, "ShortcutIconResource");
c$.fromContext = Clazz.defineMethod (c$, "fromContext", 
function (a, b) {
var c =  new android.content.Intent.ShortcutIconResource ();
c.packageName = a.getPackageName ();
c.resourceName = a.getResources ().getResourceName (b);
return c;
}, "android.content.Context,~N");
Clazz.defineMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return this.resourceName;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mIntent = null;
this.mHashCode = 0;
Clazz.instantialize (this, arguments);
}, android.content.Intent, "FilterComparison");
Clazz.makeConstructor (c$, 
function (a) {
this.mIntent = a;
this.mHashCode = a.filterHashCode ();
}, "android.content.Intent");
Clazz.defineMethod (c$, "getIntent", 
function () {
return this.mIntent;
});
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (Clazz.instanceOf (a, android.content.Intent.FilterComparison)) {
var b = (a).mIntent;
return this.mIntent.filterEquals (b);
}return false;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.mHashCode;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"ACTION_MAIN", "android.intent.action.MAIN",
"ACTION_VIEW", "android.intent.action.VIEW");
c$.ACTION_DEFAULT = c$.prototype.ACTION_DEFAULT = "android.intent.action.VIEW";
Clazz.defineStatics (c$,
"ACTION_ATTACH_DATA", "android.intent.action.ATTACH_DATA",
"ACTION_EDIT", "android.intent.action.EDIT",
"ACTION_INSERT_OR_EDIT", "android.intent.action.INSERT_OR_EDIT",
"ACTION_PICK", "android.intent.action.PICK",
"ACTION_CREATE_SHORTCUT", "android.intent.action.CREATE_SHORTCUT",
"EXTRA_SHORTCUT_INTENT", "android.intent.extra.shortcut.INTENT",
"EXTRA_SHORTCUT_NAME", "android.intent.extra.shortcut.NAME",
"EXTRA_SHORTCUT_ICON", "android.intent.extra.shortcut.ICON",
"EXTRA_SHORTCUT_ICON_RESOURCE", "android.intent.extra.shortcut.ICON_RESOURCE",
"ACTION_CHOOSER", "android.intent.action.CHOOSER",
"ACTION_GET_CONTENT", "android.intent.action.GET_CONTENT",
"ACTION_DIAL", "android.intent.action.DIAL",
"ACTION_CALL", "android.intent.action.CALL",
"ACTION_CALL_EMERGENCY", "android.intent.action.CALL_EMERGENCY",
"ACTION_CALL_PRIVILEGED", "android.intent.action.CALL_PRIVILEGED",
"ACTION_SENDTO", "android.intent.action.SENDTO",
"ACTION_SEND", "android.intent.action.SEND",
"ACTION_SEND_MULTIPLE", "android.intent.action.SEND_MULTIPLE",
"ACTION_ANSWER", "android.intent.action.ANSWER",
"ACTION_INSERT", "android.intent.action.INSERT",
"ACTION_DELETE", "android.intent.action.DELETE",
"ACTION_RUN", "android.intent.action.RUN",
"ACTION_SYNC", "android.intent.action.SYNC",
"ACTION_PICK_ACTIVITY", "android.intent.action.PICK_ACTIVITY",
"ACTION_SEARCH", "android.intent.action.SEARCH",
"ACTION_SYSTEM_TUTORIAL", "android.intent.action.SYSTEM_TUTORIAL",
"ACTION_WEB_SEARCH", "android.intent.action.WEB_SEARCH",
"ACTION_ALL_APPS", "android.intent.action.ALL_APPS",
"ACTION_SET_WALLPAPER", "android.intent.action.SET_WALLPAPER",
"ACTION_BUG_REPORT", "android.intent.action.BUG_REPORT",
"ACTION_FACTORY_TEST", "android.intent.action.FACTORY_TEST",
"ACTION_CALL_BUTTON", "android.intent.action.CALL_BUTTON",
"ACTION_VOICE_COMMAND", "android.intent.action.VOICE_COMMAND",
"ACTION_SEARCH_LONG_PRESS", "android.intent.action.SEARCH_LONG_PRESS",
"ACTION_APP_ERROR", "android.intent.action.APP_ERROR",
"ACTION_POWER_USAGE_SUMMARY", "android.intent.action.POWER_USAGE_SUMMARY",
"ACTION_UPGRADE_SETUP", "android.intent.action.UPGRADE_SETUP",
"METADATA_SETUP_VERSION", "android.SETUP_VERSION",
"ACTION_SCREEN_OFF", "android.intent.action.SCREEN_OFF",
"ACTION_SCREEN_ON", "android.intent.action.SCREEN_ON",
"ACTION_USER_PRESENT", "android.intent.action.USER_PRESENT",
"ACTION_TIME_TICK", "android.intent.action.TIME_TICK",
"ACTION_TIME_CHANGED", "android.intent.action.TIME_SET",
"ACTION_DATE_CHANGED", "android.intent.action.DATE_CHANGED",
"ACTION_TIMEZONE_CHANGED", "android.intent.action.TIMEZONE_CHANGED",
"ACTION_ALARM_CHANGED", "android.intent.action.ALARM_CHANGED",
"ACTION_SYNC_STATE_CHANGED", "android.intent.action.SYNC_STATE_CHANGED",
"ACTION_BOOT_COMPLETED", "android.intent.action.BOOT_COMPLETED",
"ACTION_CLOSE_SYSTEM_DIALOGS", "android.intent.action.CLOSE_SYSTEM_DIALOGS",
"ACTION_PACKAGE_INSTALL", "android.intent.action.PACKAGE_INSTALL",
"ACTION_PACKAGE_ADDED", "android.intent.action.PACKAGE_ADDED",
"ACTION_PACKAGE_REPLACED", "android.intent.action.PACKAGE_REPLACED",
"ACTION_PACKAGE_REMOVED", "android.intent.action.PACKAGE_REMOVED",
"ACTION_PACKAGE_CHANGED", "android.intent.action.PACKAGE_CHANGED",
"ACTION_QUERY_PACKAGE_RESTART", "android.intent.action.QUERY_PACKAGE_RESTART",
"ACTION_PACKAGE_RESTARTED", "android.intent.action.PACKAGE_RESTARTED",
"ACTION_PACKAGE_DATA_CLEARED", "android.intent.action.PACKAGE_DATA_CLEARED",
"ACTION_UID_REMOVED", "android.intent.action.UID_REMOVED",
"ACTION_EXTERNAL_APPLICATIONS_AVAILABLE", "android.intent.action.EXTERNAL_APPLICATIONS_AVAILABLE",
"ACTION_EXTERNAL_APPLICATIONS_UNAVAILABLE", "android.intent.action.EXTERNAL_APPLICATIONS_UNAVAILABLE",
"ACTION_WALLPAPER_CHANGED", "android.intent.action.WALLPAPER_CHANGED",
"ACTION_CONFIGURATION_CHANGED", "android.intent.action.CONFIGURATION_CHANGED",
"ACTION_LOCALE_CHANGED", "android.intent.action.LOCALE_CHANGED",
"ACTION_BATTERY_CHANGED", "android.intent.action.BATTERY_CHANGED",
"ACTION_BATTERY_LOW", "android.intent.action.BATTERY_LOW",
"ACTION_BATTERY_OKAY", "android.intent.action.BATTERY_OKAY",
"ACTION_POWER_CONNECTED", "android.intent.action.ACTION_POWER_CONNECTED",
"ACTION_POWER_DISCONNECTED", "android.intent.action.ACTION_POWER_DISCONNECTED",
"ACTION_SHUTDOWN", "android.intent.action.ACTION_SHUTDOWN",
"ACTION_REQUEST_SHUTDOWN", "android.intent.action.ACTION_REQUEST_SHUTDOWN",
"ACTION_DEVICE_STORAGE_LOW", "android.intent.action.DEVICE_STORAGE_LOW",
"ACTION_DEVICE_STORAGE_OK", "android.intent.action.DEVICE_STORAGE_OK",
"ACTION_DEVICE_STORAGE_FULL", "android.intent.action.DEVICE_STORAGE_FULL",
"ACTION_DEVICE_STORAGE_NOT_FULL", "android.intent.action.DEVICE_STORAGE_NOT_FULL",
"ACTION_MANAGE_PACKAGE_STORAGE", "android.intent.action.MANAGE_PACKAGE_STORAGE",
"ACTION_UMS_CONNECTED", "android.intent.action.UMS_CONNECTED",
"ACTION_UMS_DISCONNECTED", "android.intent.action.UMS_DISCONNECTED",
"ACTION_MEDIA_REMOVED", "android.intent.action.MEDIA_REMOVED",
"ACTION_MEDIA_UNMOUNTED", "android.intent.action.MEDIA_UNMOUNTED",
"ACTION_MEDIA_CHECKING", "android.intent.action.MEDIA_CHECKING",
"ACTION_MEDIA_NOFS", "android.intent.action.MEDIA_NOFS",
"ACTION_MEDIA_MOUNTED", "android.intent.action.MEDIA_MOUNTED",
"ACTION_MEDIA_SHARED", "android.intent.action.MEDIA_SHARED",
"ACTION_MEDIA_UNSHARED", "android.intent.action.MEDIA_UNSHARED",
"ACTION_MEDIA_BAD_REMOVAL", "android.intent.action.MEDIA_BAD_REMOVAL",
"ACTION_MEDIA_UNMOUNTABLE", "android.intent.action.MEDIA_UNMOUNTABLE",
"ACTION_MEDIA_EJECT", "android.intent.action.MEDIA_EJECT",
"ACTION_MEDIA_SCANNER_STARTED", "android.intent.action.MEDIA_SCANNER_STARTED",
"ACTION_MEDIA_SCANNER_FINISHED", "android.intent.action.MEDIA_SCANNER_FINISHED",
"ACTION_MEDIA_SCANNER_SCAN_FILE", "android.intent.action.MEDIA_SCANNER_SCAN_FILE",
"ACTION_MEDIA_BUTTON", "android.intent.action.MEDIA_BUTTON",
"ACTION_CAMERA_BUTTON", "android.intent.action.CAMERA_BUTTON",
"ACTION_GTALK_SERVICE_CONNECTED", "android.intent.action.GTALK_CONNECTED",
"ACTION_GTALK_SERVICE_DISCONNECTED", "android.intent.action.GTALK_DISCONNECTED",
"ACTION_INPUT_METHOD_CHANGED", "android.intent.action.INPUT_METHOD_CHANGED",
"ACTION_AIRPLANE_MODE_CHANGED", "android.intent.action.AIRPLANE_MODE",
"ACTION_PROVIDER_CHANGED", "android.intent.action.PROVIDER_CHANGED",
"ACTION_HEADSET_PLUG", "android.intent.action.HEADSET_PLUG",
"ACTION_NEW_OUTGOING_CALL", "android.intent.action.NEW_OUTGOING_CALL",
"ACTION_REBOOT", "android.intent.action.REBOOT",
"ACTION_DOCK_EVENT", "android.intent.action.DOCK_EVENT",
"ACTION_REMOTE_INTENT", "com.google.android.c2dm.intent.RECEIVE",
"ACTION_PRE_BOOT_COMPLETED", "android.intent.action.PRE_BOOT_COMPLETED",
"CATEGORY_DEFAULT", "android.intent.category.DEFAULT",
"CATEGORY_BROWSABLE", "android.intent.category.BROWSABLE",
"CATEGORY_ALTERNATIVE", "android.intent.category.ALTERNATIVE",
"CATEGORY_SELECTED_ALTERNATIVE", "android.intent.category.SELECTED_ALTERNATIVE",
"CATEGORY_TAB", "android.intent.category.TAB",
"CATEGORY_LAUNCHER", "android.intent.category.LAUNCHER",
"CATEGORY_INFO", "android.intent.category.INFO",
"CATEGORY_HOME", "android.intent.category.HOME",
"CATEGORY_PREFERENCE", "android.intent.category.PREFERENCE",
"CATEGORY_DEVELOPMENT_PREFERENCE", "android.intent.category.DEVELOPMENT_PREFERENCE",
"CATEGORY_EMBED", "android.intent.category.EMBED",
"CATEGORY_MONKEY", "android.intent.category.MONKEY",
"CATEGORY_TEST", "android.intent.category.TEST",
"CATEGORY_UNIT_TEST", "android.intent.category.UNIT_TEST",
"CATEGORY_SAMPLE_CODE", "android.intent.category.SAMPLE_CODE",
"CATEGORY_OPENABLE", "android.intent.category.OPENABLE",
"CATEGORY_FRAMEWORK_INSTRUMENTATION_TEST", "android.intent.category.FRAMEWORK_INSTRUMENTATION_TEST",
"CATEGORY_CAR_DOCK", "android.intent.category.CAR_DOCK",
"CATEGORY_DESK_DOCK", "android.intent.category.DESK_DOCK",
"CATEGORY_CAR_MODE", "android.intent.category.CAR_MODE",
"EXTRA_TEMPLATE", "android.intent.extra.TEMPLATE",
"EXTRA_TEXT", "android.intent.extra.TEXT",
"EXTRA_STREAM", "android.intent.extra.STREAM",
"EXTRA_EMAIL", "android.intent.extra.EMAIL",
"EXTRA_CC", "android.intent.extra.CC",
"EXTRA_BCC", "android.intent.extra.BCC",
"EXTRA_SUBJECT", "android.intent.extra.SUBJECT",
"EXTRA_INTENT", "android.intent.extra.INTENT",
"EXTRA_TITLE", "android.intent.extra.TITLE",
"EXTRA_INITIAL_INTENTS", "android.intent.extra.INITIAL_INTENTS",
"EXTRA_KEY_EVENT", "android.intent.extra.KEY_EVENT",
"EXTRA_KEY_CONFIRM", "android.intent.extra.KEY_CONFIRM",
"EXTRA_DONT_KILL_APP", "android.intent.extra.DONT_KILL_APP",
"EXTRA_PHONE_NUMBER", "android.intent.extra.PHONE_NUMBER",
"EXTRA_UID", "android.intent.extra.UID",
"EXTRA_PACKAGES", "android.intent.extra.PACKAGES",
"EXTRA_DATA_REMOVED", "android.intent.extra.DATA_REMOVED",
"EXTRA_REPLACING", "android.intent.extra.REPLACING",
"EXTRA_ALARM_COUNT", "android.intent.extra.ALARM_COUNT",
"EXTRA_DOCK_STATE", "android.intent.extra.DOCK_STATE",
"EXTRA_DOCK_STATE_UNDOCKED", 0,
"EXTRA_DOCK_STATE_DESK", 1,
"EXTRA_DOCK_STATE_CAR", 2,
"METADATA_DOCK_HOME", "android.dock_home",
"EXTRA_BUG_REPORT", "android.intent.extra.BUG_REPORT",
"EXTRA_INSTALLER_PACKAGE_NAME", "android.intent.extra.INSTALLER_PACKAGE_NAME",
"EXTRA_REMOTE_INTENT_TOKEN", "android.intent.extra.remote_intent_token",
"EXTRA_CHANGED_COMPONENT_NAME", "android.intent.extra.changed_component_name",
"EXTRA_CHANGED_COMPONENT_NAME_LIST", "android.intent.extra.changed_component_name_list",
"EXTRA_CHANGED_PACKAGE_LIST", "android.intent.extra.changed_package_list",
"EXTRA_CHANGED_UID_LIST", "android.intent.extra.changed_uid_list",
"EXTRA_CLIENT_LABEL", "android.intent.extra.client_label",
"EXTRA_CLIENT_INTENT", "android.intent.extra.client_intent",
"FLAG_GRANT_READ_URI_PERMISSION", 0x00000001,
"FLAG_GRANT_WRITE_URI_PERMISSION", 0x00000002,
"FLAG_FROM_BACKGROUND", 0x00000004,
"FLAG_DEBUG_LOG_RESOLUTION", 0x00000008,
"FLAG_ACTIVITY_NO_HISTORY", 0x40000000,
"FLAG_ACTIVITY_SINGLE_TOP", 0x20000000,
"FLAG_ACTIVITY_NEW_TASK", 0x10000000,
"FLAG_ACTIVITY_MULTIPLE_TASK", 0x08000000,
"FLAG_ACTIVITY_CLEAR_TOP", 0x04000000,
"FLAG_ACTIVITY_FORWARD_RESULT", 0x02000000,
"FLAG_ACTIVITY_PREVIOUS_IS_TOP", 0x01000000,
"FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS", 0x00800000,
"FLAG_ACTIVITY_BROUGHT_TO_FRONT", 0x00400000,
"FLAG_ACTIVITY_RESET_TASK_IF_NEEDED", 0x00200000,
"FLAG_ACTIVITY_LAUNCHED_FROM_HISTORY", 0x00100000,
"FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET", 0x00080000,
"FLAG_ACTIVITY_NO_USER_ACTION", 0x00040000,
"FLAG_ACTIVITY_REORDER_TO_FRONT", 0X00020000,
"FLAG_ACTIVITY_NO_ANIMATION", 0X00010000,
"FLAG_RECEIVER_REGISTERED_ONLY", 0x40000000,
"FLAG_RECEIVER_REPLACE_PENDING", 0x20000000,
"FLAG_RECEIVER_REGISTERED_ONLY_BEFORE_BOOT", 0x10000000,
"FLAG_RECEIVER_BOOT_UPGRADE", 0x08000000,
"IMMUTABLE_FLAGS", 3,
"URI_INTENT_SCHEME", 1,
"TAG", "Intent>>>",
"FILL_IN_ACTION", 1,
"FILL_IN_DATA", 2,
"FILL_IN_CATEGORIES", 4,
"FILL_IN_COMPONENT", 8,
"FILL_IN_PACKAGE", 16,
"FILL_IN_SOURCE_BOUNDS", 32);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.content.Intent$1") ? 0 : android.content.Intent.$Intent$1$ ()), Clazz.innerTypeInstance (android.content.Intent$1, this, null));
});
