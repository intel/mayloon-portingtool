﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.content.ContentProviderResult", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.TAG = "ContentProviderResult";
this.uri = null;
this.count = null;
Clazz.instantialize (this, arguments);
}, android.content, "ContentProviderResult", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function (uri) {
if (uri == null) throw  new IllegalArgumentException ("uri must not be null");
this.uri = uri;
this.count = null;
}, "android.net.Uri");
Clazz.makeConstructor (c$, 
function (count) {
this.count = new Integer (count);
this.uri = null;
}, "~N");
Clazz.makeConstructor (c$, 
function (source) {
var type = source.readInt ();
if (type == 1) {
this.count = new Integer (source.readInt ());
this.uri = null;
} else {
this.count = null;
System.out.println (this.TAG + ":Constructor is not implemented");
}}, "android.os.Parcel");
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, flags) {
if (this.uri == null) {
dest.writeInt (1);
dest.writeInt ((this.count).intValue ());
} else {
dest.writeInt (2);
System.out.println (this.TAG + ":writeToParcel is not implemented");
}}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.overrideMethod (c$, "toString", 
function () {
if (this.uri != null) {
return "ContentProviderResult(uri=" + this.uri.toString () + ")";
}return "ContentProviderResult(count=" + this.count + ")";
});
c$.$ContentProviderResult$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content, "ContentProviderResult$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (source) {
return  new android.content.ContentProviderResult (source);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.content.ContentProviderResult$1") ? 0 : android.content.ContentProviderResult.$ContentProviderResult$1$ ()), Clazz.innerTypeInstance (android.content.ContentProviderResult$1, this, null));
});
