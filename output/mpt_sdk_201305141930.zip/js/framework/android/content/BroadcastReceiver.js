﻿Clazz.declarePackage ("android.content");
Clazz.load (null, "android.content.BroadcastReceiver", ["android.os.Bundle", "android.util.Log", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mResultCode = 0;
this.mResultData = null;
this.mResultExtras = null;
this.mAbortBroadcast = false;
this.mDebugUnregister = false;
this.mOrderedHint = false;
this.mInitialStickyHint = false;
Clazz.instantialize (this, arguments);
}, android.content, "BroadcastReceiver");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "peekService", 
function (myContext, service) {
var binder = null;
return binder;
}, "android.content.Context,android.content.Intent");
Clazz.defineMethod (c$, "setResultCode", 
function (code) {
this.checkSynchronousHint ();
this.mResultCode = code;
}, "~N");
Clazz.defineMethod (c$, "getResultCode", 
function () {
return this.mResultCode;
});
Clazz.defineMethod (c$, "setResultData", 
function (data) {
this.checkSynchronousHint ();
this.mResultData = data;
}, "~S");
Clazz.defineMethod (c$, "getResultData", 
function () {
return this.mResultData;
});
Clazz.defineMethod (c$, "setResultExtras", 
function (extras) {
this.checkSynchronousHint ();
this.mResultExtras = extras;
}, "android.os.Bundle");
Clazz.defineMethod (c$, "getResultExtras", 
function (makeMap) {
var e = this.mResultExtras;
if (!makeMap) return e;
if (e == null) this.mResultExtras = e =  new android.os.Bundle ();
return e;
}, "~B");
Clazz.defineMethod (c$, "setResult", 
function (code, data, extras) {
this.checkSynchronousHint ();
this.mResultCode = code;
this.mResultData = data;
this.mResultExtras = extras;
}, "~N,~S,android.os.Bundle");
Clazz.defineMethod (c$, "getAbortBroadcast", 
function () {
return this.mAbortBroadcast;
});
Clazz.defineMethod (c$, "abortBroadcast", 
function () {
this.checkSynchronousHint ();
this.mAbortBroadcast = true;
});
Clazz.defineMethod (c$, "clearAbortBroadcast", 
function () {
this.mAbortBroadcast = false;
});
Clazz.defineMethod (c$, "isOrderedBroadcast", 
function () {
return this.mOrderedHint;
});
Clazz.defineMethod (c$, "isInitialStickyBroadcast", 
function () {
return this.mInitialStickyHint;
});
Clazz.defineMethod (c$, "setOrderedHint", 
function (isOrdered) {
this.mOrderedHint = isOrdered;
}, "~B");
Clazz.defineMethod (c$, "setInitialStickyHint", 
function (isInitialSticky) {
this.mInitialStickyHint = isInitialSticky;
}, "~B");
Clazz.defineMethod (c$, "setDebugUnregister", 
function (debug) {
this.mDebugUnregister = debug;
}, "~B");
Clazz.defineMethod (c$, "getDebugUnregister", 
function () {
return this.mDebugUnregister;
});
Clazz.defineMethod (c$, "checkSynchronousHint", 
function () {
if (this.mOrderedHint || this.mInitialStickyHint) {
return ;
}var e =  new RuntimeException ("BroadcastReceiver trying to return result during a non-ordered broadcast");
e.fillInStackTrace ();
android.util.Log.e ("BroadcastReceiver", e.getMessage (), e);
});
});
