﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.content.pm.PackageItemInfo", "android.os.Parcelable"], "android.content.pm.ApplicationInfo", ["android.content.res.Resources"], function () {
c$ = Clazz.decorateAsClass (function () {
this.taskAffinity = null;
this.permission = null;
this.processName = null;
this.className = null;
this.descriptionRes = 0;
this.theme = 0;
this.manageSpaceActivityName = null;
this.backupAgentName = null;
this.flags = 0;
this.sourceDir = null;
this.publicSourceDir = null;
this.resourceDirs = null;
this.sharedLibraryFiles = null;
this.dataDir = null;
this.nativeLibraryDir = null;
this.uid = 0;
this.targetSdkVersion = 0;
this.enabled = true;
this.installLocation = -1;
Clazz.instantialize (this, arguments);
}, android.content.pm, "ApplicationInfo", android.content.pm.PackageItemInfo, android.os.Parcelable);
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
Clazz.superCall (this, android.content.pm.ApplicationInfo, "dumpFront", [pw, prefix]);
if (this.className != null) {
pw.println (prefix + "className=" + this.className);
}if (this.permission != null) {
pw.println (prefix + "permission=" + this.permission);
}pw.println (prefix + "processName=" + this.processName);
pw.println (prefix + "taskAffinity=" + this.taskAffinity);
pw.println (prefix + "uid=" + this.uid + " flags=0x" + Integer.toHexString (this.flags) + " theme=0x" + Integer.toHexString (this.theme));
pw.println (prefix + "sourceDir=" + this.sourceDir);
if (this.sourceDir == null) {
if (this.publicSourceDir != null) {
pw.println (prefix + "publicSourceDir=" + this.publicSourceDir);
}} else if (!this.sourceDir.equals (this.publicSourceDir)) {
pw.println (prefix + "publicSourceDir=" + this.publicSourceDir);
}if (this.resourceDirs != null) {
pw.println (prefix + "resourceDirs=" + this.resourceDirs);
}pw.println (prefix + "dataDir=" + this.dataDir);
if (this.sharedLibraryFiles != null) {
pw.println (prefix + "sharedLibraryFiles=" + this.sharedLibraryFiles);
}pw.println (prefix + "enabled=" + this.enabled + " targetSdkVersion=" + this.targetSdkVersion);
if (this.manageSpaceActivityName != null) {
pw.println (prefix + "manageSpaceActivityName=" + this.manageSpaceActivityName);
}if (this.descriptionRes != 0) {
pw.println (prefix + "description=0x" + Integer.toHexString (this.descriptionRes));
}Clazz.superCall (this, android.content.pm.ApplicationInfo, "dumpBack", [pw, prefix]);
}, "android.util.Printer,~S");
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.pm.ApplicationInfo, []);
});
Clazz.makeConstructor (c$, 
function (orig) {
Clazz.superConstructor (this, android.content.pm.ApplicationInfo, [orig]);
this.taskAffinity = orig.taskAffinity;
this.permission = orig.permission;
this.processName = orig.processName;
this.className = orig.className;
this.theme = orig.theme;
this.flags = orig.flags;
this.sourceDir = orig.sourceDir;
this.publicSourceDir = orig.publicSourceDir;
this.nativeLibraryDir = orig.nativeLibraryDir;
this.resourceDirs = orig.resourceDirs;
this.sharedLibraryFiles = orig.sharedLibraryFiles;
this.dataDir = orig.dataDir;
this.uid = orig.uid;
this.targetSdkVersion = orig.targetSdkVersion;
this.enabled = orig.enabled;
this.installLocation = orig.installLocation;
this.manageSpaceActivityName = orig.manageSpaceActivityName;
this.descriptionRes = orig.descriptionRes;
}, "android.content.pm.ApplicationInfo");
Clazz.overrideMethod (c$, "toString", 
function () {
return "ApplicationInfo{" + this.packageName + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "loadDescription", 
function (pm) {
if (this.descriptionRes != 0) {
var label = pm.getText (this.packageName, this.descriptionRes, this);
if (label != null) {
return label;
}}return null;
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "disableCompatibilityMode", 
function () {
this.flags |= (540160);
});
Clazz.overrideMethod (c$, "loadDefaultIcon", 
function (pm) {
if ((this.flags & 262144) != 0 && this.isPackageUnavailable (pm)) {
return android.content.res.Resources.getSystem ().getDrawable (17302245);
}return pm.getDefaultActivityIcon ();
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "isPackageUnavailable", 
($fz = function (pm) {
return pm.getPackageInfo (this.packageName, 0) == null;
}, $fz.isPrivate = true, $fz), "android.content.pm.PackageManager");
Clazz.overrideMethod (c$, "getApplicationInfo", 
function () {
return this;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mPM = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.ApplicationInfo, "DisplayNameComparator", null, java.util.Comparator);
Clazz.makeConstructor (c$, 
function (a) {
this.mPM = a;
}, "android.content.pm.PackageManager");
Clazz.overrideMethod (c$, "compare", 
function (a, b) {
var c = this.mPM.getApplicationLabel (a);
if (c == null) {
c = a.packageName;
}var d = this.mPM.getApplicationLabel (b);
if (d == null) {
d = b.packageName;
}return 0;
}, "android.content.pm.ApplicationInfo,android.content.pm.ApplicationInfo");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"FLAG_SYSTEM", 1,
"FLAG_DEBUGGABLE", 2,
"FLAG_HAS_CODE", 4,
"FLAG_PERSISTENT", 8,
"FLAG_FACTORY_TEST", 16,
"FLAG_ALLOW_TASK_REPARENTING", 32,
"FLAG_ALLOW_CLEAR_USER_DATA", 64,
"FLAG_UPDATED_SYSTEM_APP", 128,
"FLAG_TEST_ONLY", 256,
"FLAG_SUPPORTS_SMALL_SCREENS", 512,
"FLAG_SUPPORTS_NORMAL_SCREENS", 1024,
"FLAG_SUPPORTS_LARGE_SCREENS", 2048,
"FLAG_RESIZEABLE_FOR_SCREENS", 4096,
"FLAG_SUPPORTS_SCREEN_DENSITIES", 8192,
"FLAG_VM_SAFE_MODE", 16384,
"FLAG_ALLOW_BACKUP", 32768,
"FLAG_KILL_AFTER_RESTORE", 65536,
"FLAG_RESTORE_ANY_VERSION", 131072,
"FLAG_EXTERNAL_STORAGE", 262144,
"FLAG_SUPPORTS_XLARGE_SCREENS", 524288,
"FLAG_NEVER_ENCRYPT", 1073741824,
"FLAG_FORWARD_LOCK", 536870912,
"FLAG_CANT_SAVE_STATE", 134217728);
});
