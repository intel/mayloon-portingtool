﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (null, "android.content.pm.PackageItemInfo", ["android.text.TextUtils"], function () {
c$ = Clazz.decorateAsClass (function () {
this.name = null;
this.packageName = null;
this.labelRes = 0;
this.nonLocalizedLabel = null;
this.icon = 0;
this.logo = 0;
this.metaData = null;
Clazz.instantialize (this, arguments);
}, android.content.pm, "PackageItemInfo");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (orig) {
this.name = orig.name;
if (this.name != null) this.name = this.name.trim ();
this.packageName = orig.packageName;
this.labelRes = orig.labelRes;
this.nonLocalizedLabel = orig.nonLocalizedLabel;
if (this.nonLocalizedLabel != null) this.nonLocalizedLabel = this.nonLocalizedLabel.toString ().trim ();
this.icon = orig.icon;
this.logo = orig.logo;
this.metaData = orig.metaData;
}, "android.content.pm.PackageItemInfo");
Clazz.defineMethod (c$, "loadLabel", 
function (pm) {
if (this.nonLocalizedLabel != null) {
return this.nonLocalizedLabel;
}if (this.labelRes != 0) {
var label = pm.getText (this.packageName, this.labelRes, this.getApplicationInfo ());
if (label != null) {
return label.toString ().trim ();
}}if (this.name != null) {
return this.name;
}return this.packageName;
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "loadIcon", 
function (pm) {
if (this.icon != 0) {
var dr = pm.getDrawable (this.packageName, this.icon, this.getApplicationInfo ());
if (dr != null) {
return dr;
}}return this.loadDefaultIcon (pm);
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "loadDefaultIcon", 
function (pm) {
return pm.getDefaultActivityIcon ();
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "loadLogo", 
function (pm) {
if (this.logo != 0) {
var d = pm.getDrawable (this.packageName, this.logo, this.getApplicationInfo ());
if (d != null) {
return d;
}}return this.loadDefaultLogo (pm);
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "loadDefaultLogo", 
function (pm) {
return null;
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "loadXmlMetaData", 
function (pm, name) {
if (this.metaData != null) {
var resid = this.metaData.getInt (name);
if (resid != 0) {
return pm.getXml (this.packageName, resid, this.getApplicationInfo ());
}}return null;
}, "android.content.pm.PackageManager,~S");
Clazz.defineMethod (c$, "dumpFront", 
function (pw, prefix) {
if (this.name != null) {
pw.println (prefix + "name=" + this.name);
}pw.println (prefix + "packageName=" + this.packageName);
if (this.labelRes != 0 || this.nonLocalizedLabel != null || this.icon != 0) {
pw.println (prefix + "labelRes=0x" + Integer.toHexString (this.labelRes) + " nonLocalizedLabel=" + this.nonLocalizedLabel + " icon=0x" + Integer.toHexString (this.icon));
}}, "android.util.Printer,~S");
Clazz.defineMethod (c$, "dumpBack", 
function (pw, prefix) {
}, "android.util.Printer,~S");
Clazz.defineMethod (c$, "getApplicationInfo", 
function () {
return null;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, parcelableFlags) {
dest.writeString (this.name);
dest.writeString (this.packageName);
dest.writeInt (this.labelRes);
android.text.TextUtils.writeToParcel (this.nonLocalizedLabel, dest, parcelableFlags);
dest.writeInt (this.icon);
dest.writeInt (this.logo);
dest.writeBundle (this.metaData);
}, "android.os.Parcel,~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mPM = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageItemInfo, "DisplayNameComparator", null, java.util.Comparator);
Clazz.makeConstructor (c$, 
function (a) {
this.mPM = a;
}, "android.content.pm.PackageManager");
Clazz.overrideMethod (c$, "compare", 
function (a, b) {
var c = a.loadLabel (this.mPM);
if (c == null) c = a.name;
var d = b.loadLabel (this.mPM);
if (d == null) d = b.name;
return 0;
}, "android.content.pm.PackageItemInfo,android.content.pm.PackageItemInfo");
c$ = Clazz.p0p ();
});
