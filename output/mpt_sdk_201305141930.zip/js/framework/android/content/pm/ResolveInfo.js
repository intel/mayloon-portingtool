﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.os.Parcelable"], "android.content.pm.ResolveInfo", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.activityInfo = null;
this.serviceInfo = null;
this.filter = null;
this.priority = 0;
this.preferredOrder = 0;
this.match = 0;
this.specificIndex = -1;
this.isDefault = false;
this.labelRes = 0;
this.nonLocalizedLabel = null;
this.icon = 0;
this.resolvePackageName = null;
Clazz.instantialize (this, arguments);
}, android.content.pm, "ResolveInfo", null, android.os.Parcelable);
Clazz.defineMethod (c$, "loadLabel", 
function (pm) {
if (this.nonLocalizedLabel != null) {
return this.nonLocalizedLabel;
}var label;
if (this.resolvePackageName != null && this.labelRes != 0) {
label = pm.getText (this.resolvePackageName, this.labelRes, null);
if (label != null) {
return label.toString ().trim ();
}}var ci = this.activityInfo != null ? this.activityInfo : this.serviceInfo;
var ai = ci.applicationInfo;
if (this.labelRes != 0) {
label = pm.getText (ci.packageName, this.labelRes, ai);
if (label != null) {
return label.toString ().trim ();
}}var data = ci.loadLabel (pm);
if (data != null) data = data.toString ().trim ();
return data;
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "loadIcon", 
function (pm) {
var dr;
if (this.resolvePackageName != null && this.icon != 0) {
dr = pm.getDrawable (this.resolvePackageName, this.icon, null);
if (dr != null) {
return dr;
}}var ci = this.activityInfo != null ? this.activityInfo : this.serviceInfo;
var ai = ci.applicationInfo;
if (this.icon != 0) {
dr = pm.getDrawable (ci.packageName, this.icon, ai);
if (dr != null) {
return dr;
}}return ci.loadIcon (pm);
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "getIconResource", 
function () {
if (this.icon != 0) return this.icon;
if (this.activityInfo != null) return this.activityInfo.getIconResource ();
if (this.serviceInfo != null) return this.serviceInfo.getIconResource ();
return 0;
});
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
if (this.filter != null) {
pw.println (prefix + "Filter:");
this.filter.dump (pw, prefix + "  ");
}pw.println (prefix + "priority=" + this.priority + " preferredOrder=" + this.preferredOrder + " match=0x" + Integer.toHexString (this.match) + " specificIndex=" + this.specificIndex + " isDefault=" + this.isDefault);
if (this.resolvePackageName != null) {
pw.println (prefix + "resolvePackageName=" + this.resolvePackageName);
}if (this.labelRes != 0 || this.nonLocalizedLabel != null || this.icon != 0) {
pw.println (prefix + "labelRes=0x" + Integer.toHexString (this.labelRes) + " nonLocalizedLabel=" + this.nonLocalizedLabel + " icon=0x" + Integer.toHexString (this.icon));
}if (this.activityInfo != null) {
pw.println (prefix + "ActivityInfo:");
this.activityInfo.dump (pw, prefix + "  ");
} else if (this.serviceInfo != null) {
pw.println (prefix + "ServiceInfo:");
this.serviceInfo.dump (pw, prefix + "  ");
}}, "android.util.Printer,~S");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.overrideMethod (c$, "toString", 
function () {
var ci = this.activityInfo != null ? this.activityInfo : this.serviceInfo;
return "ResolveInfo{" + ci.name + " p=" + this.priority + " o=" + this.preferredOrder + " m=0x" + Integer.toHexString (this.match) + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mPM = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.ResolveInfo, "DisplayNameComparator", null, java.util.Comparator);
Clazz.makeConstructor (c$, 
function (a) {
this.mPM = a;
}, "android.content.pm.PackageManager");
Clazz.overrideMethod (c$, "compare", 
function (a, b) {
var c = a.loadLabel (this.mPM);
if (c == null) c = a.activityInfo.name;
var d = b.loadLabel (this.mPM);
if (d == null) d = b.activityInfo.name;
return 0;
}, "android.content.pm.ResolveInfo,android.content.pm.ResolveInfo");
c$ = Clazz.p0p ();
});
