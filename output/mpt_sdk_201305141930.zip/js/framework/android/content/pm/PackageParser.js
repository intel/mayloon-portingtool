﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.content.IntentFilter", "android.content.pm.ApplicationInfo", "java.util.ArrayList"], "android.content.pm.PackageParser", ["android.content.ComponentName", "android.content.pm.ActivityInfo", "$.InstrumentationInfo", "$.ProviderInfo", "$.ServiceInfo", "android.content.res.AssetManager", "$.Resources", "android.os.Bundle", "$.PatternMatcher", "android.util.Log", "com.android.internal.R", "com.android.internal.util.XmlUtils", "java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mParseInstrumentationArgs = null;
this.mArchiveSourcePath = null;
this.mSeparateProcesses = null;
this.mParseError = 1;
this.mParseActivityArgs = null;
this.mParseProviderArgs = null;
this.mParseServiceArgs = null;
Clazz.instantialize (this, arguments);
}, android.content.pm, "PackageParser");
Clazz.makeConstructor (c$, 
function (archiveSourcePath) {
this.mArchiveSourcePath = archiveSourcePath;
}, "~S");
Clazz.defineMethod (c$, "setSeparateProcesses", 
function (procs) {
this.mSeparateProcesses = procs;
}, "~A");
Clazz.defineMethod (c$, "getParseError", 
function () {
return this.mParseError;
});
Clazz.defineMethod (c$, "parsePackage", 
function (sourceFile, destCodePath, metrics, flags) {
this.mParseError = 1;
this.mArchiveSourcePath = sourceFile;
var parser = null;
var assmgr = null;
var assetError = true;
try {
assmgr =  new android.content.res.AssetManager ();
var cookie = assmgr.addAssetPath (this.mArchiveSourcePath);
if (cookie != 0) {
parser = assmgr.openXmlResourceParser (cookie, "AndroidManifest.xml");
assetError = false;
} else {
android.util.Log.w ("PackageParser", "Failed adding asset path:" + this.mArchiveSourcePath);
}assetError = false;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.w ("PackageParser", "Unable to read AndroidManifest.xml of " + this.mArchiveSourcePath, e);
} else {
throw e;
}
}
if (assetError) {
this.mParseError = -101;
return null;
}var errorText =  new Array (1);
var pkg = null;
try {
var res =  new android.content.res.Resources (assmgr, metrics, null);
pkg = this.parsePackage (res, parser, flags, errorText);
if (pkg == null) System.err.println (errorText[0]);
pkg.mResource = res;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
this.mParseError = -102;
} else {
throw e;
}
}
if (pkg == null) {
parser.close ();
if (this.mParseError == 1) {
this.mParseError = -108;
}return null;
}parser.close ();
pkg.mPath = destCodePath;
pkg.mScanPath = this.mArchiveSourcePath;
return pkg;
}, "~S,~S,android.util.DisplayMetrics,~N");
c$.validateName = Clazz.defineMethod (c$, "validateName", 
($fz = function (name, requiresSeparator) {
return null;
}, $fz.isPrivate = true, $fz), "~S,~B");
c$.parsePackageName = Clazz.defineMethod (c$, "parsePackageName", 
($fz = function (parser, attrs, flags, outError) {
var type = -1;
try {
while ((type = parser.next ()) != 2 && type != 1) {
;}
} catch (e) {
if (Clazz.instanceOf (e, org.xmlpull.v1.XmlPullParserException)) {
e.printStackTrace ();
} else {
throw e;
}
}
if (type != 2) {
outError[0] = "No start tag found";
return null;
}if ((flags & 2) != 0 && false) android.util.Log.v ("PackageParser", "Root element name: '" + parser.getName () + "'");
if (!parser.getName ().equals ("manifest")) {
outError[0] = "No <manifest> tag";
return null;
}var pkgName = attrs.getAttributeValue (null, "package");
if (pkgName == null || pkgName.length == 0) {
outError[0] = "<manifest> does not specify package";
return null;
}var nameError = android.content.pm.PackageParser.validateName (pkgName, true);
if (nameError != null && !"android".equals (pkgName)) {
outError[0] = "<manifest> specifies bad package name \"" + pkgName + "\": " + nameError;
return null;
}return pkgName.intern ();
}, $fz.isPrivate = true, $fz), "org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,~N,~A");
Clazz.defineMethod (c$, "parsePackage", 
($fz = function (res, parser, flags, outError) {
this.mParseInstrumentationArgs = null;
var attrs = parser;
this.mParseActivityArgs = null;
var pkgName = android.content.pm.PackageParser.parsePackageName (parser, attrs, flags, outError);
if (pkgName == null) {
this.mParseError = -106;
return null;
}var type = -1;
var foundApp = false;
var pkg =  new android.content.pm.PackageParser.Package (pkgName);
pkg.installLocation = -1;
pkg.applicationInfo.installLocation = pkg.installLocation;
var outerDepth = parser.getDepth ();
try {
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type == 3 || type == 4) {
continue ;}var tagName = parser.getName ();
if (tagName.equals ("application")) {
if (foundApp) {
outError[0] = "<manifest> has more than one <application>";
this.mParseError = -108;
return null;
}foundApp = true;
if (!this.parseApplication (pkg, res, parser, attrs, flags, outError)) {
return null;
}} else if (tagName.equals ("instrumentation")) {
if (this.parseInstrumentation (pkg, res, parser, attrs, outError) == null) {
return null;
}}}
} catch (e) {
if (Clazz.instanceOf (e, org.xmlpull.v1.XmlPullParserException)) {
e.printStackTrace ();
} else {
throw e;
}
}
if (foundApp == false) {
outError[0] = "<manifest> does not contain an <application> or <instrumentation>";
this.mParseError = -109;
return null;
}return pkg;
}, $fz.isPrivate = true, $fz), "android.content.res.Resources,android.content.res.XmlResourceParser,~N,~A");
c$.buildClassName = Clazz.defineMethod (c$, "buildClassName", 
($fz = function (pkg, clsSeq, outError) {
if (clsSeq == null || clsSeq.length <= 0) {
outError[0] = "Empty class name in package " + pkg;
return null;
}var cls = clsSeq.toString ();
var c = cls.charAt (0);
if ((c).charCodeAt (0) == ('.').charCodeAt (0)) {
return (pkg + cls).intern ();
}if (cls.indexOf ('.') < 0) {
var b =  new StringBuilder (pkg);
b.append ('.');
b.append (cls);
return b.toString ().intern ();
}if ((c).charCodeAt (0) >= ('a').charCodeAt (0) && (c).charCodeAt (0) <= ('z').charCodeAt (0)) {
return cls.intern ();
}outError[0] = "Bad class name " + cls + " in package " + pkg;
return null;
}, $fz.isPrivate = true, $fz), "~S,~S,~A");
c$.buildCompoundName = Clazz.defineMethod (c$, "buildCompoundName", 
($fz = function (pkg, procSeq, type, outError) {
var proc = procSeq.toString ();
var c = proc.charAt (0);
if (pkg != null && (c).charCodeAt (0) == (':').charCodeAt (0)) {
if (proc.length < 2) {
outError[0] = "Bad " + type + " name " + proc + " in package " + pkg + ": must be at least two characters";
return null;
}var subName = proc.substring (1);
var nameError = android.content.pm.PackageParser.validateName (subName, false);
if (nameError != null) {
outError[0] = "Invalid " + type + " name " + proc + " in package " + pkg + ": " + nameError;
return null;
}return (pkg + proc).intern ();
}var nameError = android.content.pm.PackageParser.validateName (proc, true);
if (nameError != null && !"system".equals (proc)) {
outError[0] = "Invalid " + type + " name " + proc + " in package " + pkg + ": " + nameError;
return null;
}return proc.intern ();
}, $fz.isPrivate = true, $fz), "~S,CharSequence,~S,~A");
c$.buildProcessName = Clazz.defineMethod (c$, "buildProcessName", 
($fz = function (pkg, defProc, procSeq, flags, separateProcesses, outError) {
if ((flags & 8) != 0 && !"system".equals (procSeq)) {
return defProc != null ? defProc : pkg;
}if (separateProcesses != null) {
for (var i = separateProcesses.length - 1; i >= 0; i--) {
var sp = separateProcesses[i];
if (sp.equals (pkg) || sp.equals (defProc) || sp.equals (procSeq)) {
return pkg;
}}
}if (procSeq == null || procSeq.length () <= 0) {
return defProc;
}return android.content.pm.PackageParser.buildCompoundName (pkg, procSeq, "process", outError);
}, $fz.isPrivate = true, $fz), "~S,~S,CharSequence,~N,~A,~A");
Clazz.defineMethod (c$, "parseInstrumentation", 
($fz = function (owner, res, parser, attrs, outError) {
var sa = res.obtainAttributes (attrs, com.android.internal.R.styleable.AndroidManifestInstrumentation);
if (this.mParseInstrumentationArgs == null) {
this.mParseInstrumentationArgs =  new android.content.pm.PackageParser.ParsePackageItemArgs (owner, outError, 2, 0, 1, 0);
this.mParseInstrumentationArgs.tag = "<instrumentation>";
}this.mParseInstrumentationArgs.sa = sa;
var a =  new android.content.pm.PackageParser.Instrumentation (this.mParseInstrumentationArgs,  new android.content.pm.InstrumentationInfo ());
if (outError[0] != null) {
sa.recycle ();
this.mParseError = -108;
return null;
}var str;
str = sa.getNonResourceString (3);
a.info.targetPackage = str != null ? str.intern () : null;
a.info.handleProfiling = sa.getBoolean (4, false);
a.info.functionalTest = sa.getBoolean (5, false);
sa.recycle ();
if (a.info.targetPackage == null) {
outError[0] = "<instrumentation> does not specify targetPackage";
this.mParseError = -108;
return null;
}if (!this.parseAllMetaData (res, parser, attrs, "<instrumentation>", a, outError)) {
this.mParseError = -108;
return null;
}owner.instrumentation.add (a);
return a;
}, $fz.isPrivate = true, $fz), "android.content.pm.PackageParser.Package,android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,~A");
Clazz.defineMethod (c$, "parseApplication", 
($fz = function (owner, res, parser, attrs, flags, outError) {
var ai = owner.applicationInfo;
var pkgName = owner.applicationInfo.packageName;
var sa = res.obtainAttributes (attrs, com.android.internal.R.styleable.AndroidManifestApplication);
var v = sa.peekValue (1);
var name = sa.getNonConfigurationString (3, 0);
if (name != null) {
ai.className = android.content.pm.PackageParser.buildClassName (pkgName, name, outError);
if (ai.className == null) {
sa.recycle ();
this.mParseError = -108;
return false;
}}ai.icon = sa.getResourceId (2, 0);
ai.theme = sa.getResourceId (0, 0);
ai.descriptionRes = sa.getResourceId (13, 0);
if (v != null) {
ai.labelRes = v.resourceId;
ai.nonLocalizedLabel = v.coerceToString ();
}if (outError[0] != null) {
this.mParseError = -108;
return false;
}var innerDepth = parser.getDepth ();
var type = -1;
try {
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > innerDepth)) {
if (type == 3 || type == 4) {
continue ;}var tagName = parser.getName ();
if (tagName.equals ("activity")) {
var a = this.parseActivity (owner, res, parser, attrs, flags, outError, false);
if (a == null) {
this.mParseError = -108;
return false;
}owner.activities.add (a);
} else if (tagName.equals ("receiver")) {
var a = this.parseActivity (owner, res, parser, attrs, flags, outError, true);
if (a == null) {
this.mParseError = -108;
return false;
}owner.receivers.add (a);
} else if (tagName.equals ("provider")) {
var p = this.parseProvider (owner, res, parser, attrs, flags, outError);
if (p == null) {
this.mParseError = -108;
return false;
}owner.providers.add (p);
android.util.Log.i ("PackageParser", "Provider parse is:" + p.className + ":" + p.getComponentShortName ());
} else if (tagName.equals ("service")) {
var a = this.parseService (owner, res, parser, attrs, flags, outError, false);
if (a == null) {
this.mParseError = -108;
return false;
}owner.services.add (a);
}}
} catch (e) {
if (Clazz.instanceOf (e, org.xmlpull.v1.XmlPullParserException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return true;
}, $fz.isPrivate = true, $fz), "android.content.pm.PackageParser.Package,android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,~N,~A");
Clazz.defineMethod (c$, "parseProvider", 
($fz = function (owner, res, parser, attrs, flags, outError) {
var sa = res.obtainAttributes (attrs, com.android.internal.R.styleable.AndroidManifestProvider);
if (this.mParseProviderArgs == null) {
this.mParseProviderArgs =  new android.content.pm.PackageParser.ParseComponentArgs (owner, outError, 2, 0, 1, 0, this.mSeparateProcesses, 8, 14, 6);
this.mParseProviderArgs.tag = "<provider>";
}this.mParseProviderArgs.sa = sa;
this.mParseProviderArgs.flags = flags;
var p =  new android.content.pm.PackageParser.Provider (this.mParseProviderArgs,  new android.content.pm.ProviderInfo ());
if (outError[0] != null) {
sa.recycle ();
return null;
}p.info.exported = sa.getBoolean (7, true);
var cpname = sa.getNonConfigurationString (10, 0);
p.info.isSyncable = sa.getBoolean (11, false);
var permission = sa.getNonConfigurationString (3, 0);
var str = sa.getNonConfigurationString (4, 0);
if (str == null) {
str = permission;
}if (str == null) {
p.info.readPermission = owner.applicationInfo.permission;
} else {
p.info.readPermission = str.length > 0 ? str.toString ().intern () : null;
}str = sa.getNonConfigurationString (5, 0);
if (str == null) {
str = permission;
}if (str == null) {
p.info.writePermission = owner.applicationInfo.permission;
} else {
p.info.writePermission = str.length > 0 ? str.toString ().intern () : null;
}p.info.grantUriPermissions = sa.getBoolean (13, false);
p.info.multiprocess = sa.getBoolean (9, false);
p.info.initOrder = sa.getInt (12, 0);
sa.recycle ();
if ((owner.applicationInfo.flags & 134217728) != 0) {
if (p.info.processName === owner.packageName) {
outError[0] = "Heavy-weight applications can not have providers in main process";
return null;
}}if (cpname == null) {
outError[0] = "<provider> does not incude authorities attribute";
return null;
}p.info.authority = cpname.intern ();
if (!this.parseProviderTags (res, parser, attrs, p, outError)) {
return null;
}return p;
}, $fz.isPrivate = true, $fz), "android.content.pm.PackageParser.Package,android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,~N,~A");
Clazz.defineMethod (c$, "parseAllMetaData", 
($fz = function (res, parser, attrs, tag, outInfo, outError) {
var outerDepth = parser.getDepth ();
var type;
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type == 3 || type == 4) {
continue ;}if (parser.getName ().equals ("meta-data")) {
if ((outInfo.metaData = this.parseMetaData (res, parser, attrs, outInfo.metaData, outError)) == null) {
return false;
}} else {
if (true) {
android.util.Log.w ("PackageParser", "Unknown element under " + tag + ": " + parser.getName () + " at " + this.mArchiveSourcePath + " " + parser.getPositionDescription ());
com.android.internal.util.XmlUtils.skipCurrentTag (parser);
continue ;}outError[0] = "Bad element under " + tag + ": " + parser.getName ();
return false;
}}
return true;
}, $fz.isPrivate = true, $fz), "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,~S,android.content.pm.PackageParser.Component,~A");
Clazz.defineMethod (c$, "parseMetaData", 
($fz = function (res, parser, attrs, data, outError) {
var sa = res.obtainAttributes (attrs, com.android.internal.R.styleable.AndroidManifestMetaData);
if (data == null) {
data =  new android.os.Bundle ();
}var name = sa.getNonConfigurationString (0, 0);
if (name == null) {
outError[0] = "<meta-data> requires an android:name attribute";
sa.recycle ();
return null;
}name = name.intern ();
var v = sa.peekValue (2);
if (v != null && v.resourceId != 0) {
data.putInt (name, v.resourceId);
} else {
v = sa.peekValue (1);
if (v != null) {
if (v.type == 3) {
var cs = v.coerceToString ();
data.putString (name, cs != null ? cs.toString ().intern () : null);
} else if (v.type == 18) {
data.putBoolean (name, v.data != 0);
} else if (v.type >= 16 && v.type <= 31) {
data.putInt (name, v.data);
} else if (v.type == 4) {
data.putFloat (name, v.getFloat ());
} else {
outError[0] = "<meta-data> only supports string, integer, float, color, boolean, and resource reference types";
data = null;
}} else {
outError[0] = "<meta-data> requires an android:value or android:resource attribute";
data = null;
}}sa.recycle ();
com.android.internal.util.XmlUtils.skipCurrentTag (parser);
return data;
}, $fz.isPrivate = true, $fz), "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,android.os.Bundle,~A");
Clazz.defineMethod (c$, "parseProviderTags", 
($fz = function (res, parser, attrs, outInfo, outError) {
var outerDepth = parser.getDepth ();
var type;
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type == 3 || type == 4) {
continue ;}if (parser.getName ().equals ("meta-data")) {
if ((outInfo.metaData = this.parseMetaData (res, parser, attrs, outInfo.metaData, outError)) == null) {
return false;
}} else if (parser.getName ().equals ("grant-uri-permission")) {
var sa = res.obtainAttributes (attrs, com.android.internal.R.styleable.AndroidManifestGrantUriPermission);
var pa = null;
var str = sa.getNonConfigurationString (0, 0);
if (str != null) {
pa =  new android.os.PatternMatcher (str, 0);
}str = sa.getNonConfigurationString (1, 0);
if (str != null) {
pa =  new android.os.PatternMatcher (str, 1);
}str = sa.getNonConfigurationString (2, 0);
if (str != null) {
pa =  new android.os.PatternMatcher (str, 2);
}sa.recycle ();
if (pa != null) {
if (outInfo.info.uriPermissionPatterns == null) {
outInfo.info.uriPermissionPatterns =  new Array (1);
outInfo.info.uriPermissionPatterns[0] = pa;
} else {
var N = outInfo.info.uriPermissionPatterns.length;
var newp =  new Array (N + 1);
System.arraycopy (outInfo.info.uriPermissionPatterns, 0, newp, 0, N);
newp[N] = pa;
outInfo.info.uriPermissionPatterns = newp;
}outInfo.info.grantUriPermissions = true;
} else {
outError[0] = "No path, pathPrefix, or pathPattern for <path-permission>";
return false;
}com.android.internal.util.XmlUtils.skipCurrentTag (parser);
} else {
outError[0] = "Bad element under <provider>: " + parser.getName ();
return false;
}}
return true;
}, $fz.isPrivate = true, $fz), "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,android.content.pm.PackageParser.Provider,~A");
Clazz.defineMethod (c$, "parseActivity", 
($fz = function (owner, res, parser, attrs, flags, outError, receiver) {
var sa = res.obtainAttributes (attrs, com.android.internal.R.styleable.AndroidManifestActivity);
if (this.mParseActivityArgs == null) {
this.mParseActivityArgs =  new android.content.pm.PackageParser.ParseComponentArgs (owner, outError, 3, 1, 2, 0, this.mSeparateProcesses, 7, 17, 5);
}this.mParseActivityArgs.tag = receiver ? "<receiver>" : "<activity>";
this.mParseActivityArgs.sa = sa;
this.mParseActivityArgs.flags = flags;
var a =  new android.content.pm.PackageParser.Activity (this.mParseActivityArgs,  new android.content.pm.ActivityInfo ());
if (outError[0] != null) {
System.out.println ("PackageParser" + outError[0]);
sa.recycle ();
return null;
}a.info.exported = true;
sa.recycle ();
if (outError[0] != null) {
return null;
}var outerDepth = parser.getDepth ();
var type = -1;
try {
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type == 3 || type == 4) {
continue ;}if (parser.getName ().equals ("intent-filter")) {
var intent =  new android.content.pm.PackageParser.ActivityIntentInfo (a);
if (!this.parseIntent (res, parser, attrs, flags, intent, outError, !receiver)) {
return null;
}if (intent.countActions () == 0) {
android.util.Log.w ("PackageParser", "No actions in intent filter at " + this.mArchiveSourcePath + " " + parser.getPositionDescription ());
} else {
a.intents.add (intent);
}} else if (parser.getName ().equals ("meta-data")) {
if ((a.metaData = this.parseMetaData (res, parser, attrs, a.metaData, outError)) == null) {
return null;
}}}
} catch (e) {
if (Clazz.instanceOf (e, org.xmlpull.v1.XmlPullParserException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return a;
}, $fz.isPrivate = true, $fz), "android.content.pm.PackageParser.Package,android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,~N,~A,~B");
Clazz.defineMethod (c$, "parseService", 
($fz = function (owner, res, parser, attrs, flags, outError, receiver) {
var sa = res.obtainAttributes (attrs, com.android.internal.R.styleable.AndroidManifestService);
if (this.mParseServiceArgs == null) {
this.mParseServiceArgs =  new android.content.pm.PackageParser.ParseComponentArgs (owner, outError, 2, 0, 1, 0, this.mSeparateProcesses, 6, 7, 4);
this.mParseServiceArgs.tag = "<services>";
}this.mParseServiceArgs.sa = sa;
this.mParseServiceArgs.flags = flags;
var s =  new android.content.pm.PackageParser.Service (this.mParseServiceArgs,  new android.content.pm.ServiceInfo ());
if (outError[0] != null) {
System.out.println ("PackageParser" + outError[0]);
sa.recycle ();
return null;
}s.info.exported = true;
sa.recycle ();
if (s.info.processName == null) s.info.processName = owner.packageName;
if (outError[0] != null) {
return null;
}var outerDepth = parser.getDepth ();
var type = -1;
try {
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type == 3 || type == 4) {
continue ;}if (parser.getName ().equals ("intent-filter")) {
var intent =  new android.content.pm.PackageParser.ServiceIntentInfo (s);
if (!this.parseIntent (res, parser, attrs, flags, intent, outError, !receiver)) {
return null;
}if (intent.countActions () == 0) {
android.util.Log.w ("PackageParser", "No actions in intent filter at " + this.mArchiveSourcePath + " " + parser.getPositionDescription ());
} else {
s.intents.add (intent);
}}}
} catch (e) {
if (Clazz.instanceOf (e, org.xmlpull.v1.XmlPullParserException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return s;
}, $fz.isPrivate = true, $fz), "android.content.pm.PackageParser.Package,android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,~N,~A,~B");
Clazz.defineMethod (c$, "parseIntent", 
($fz = function (res, parser, attrs, flags, outInfo, outError, isActivity) {
var sa = res.obtainAttributes (attrs, com.android.internal.R.styleable.AndroidManifestIntentFilter);
var priority = sa.getInt (2, 0);
if (priority > 0 && isActivity && (flags & 1) == 0) {
System.out.println ("PackageParser" + "Activity with priority > 0, forcing to 0 at " + this.mArchiveSourcePath);
priority = 0;
}outInfo.setPriority (priority);
var v = sa.peekValue (0);
if (v != null && (outInfo.labelRes = v.resourceId) == 0) {
outInfo.nonLocalizedLabel = v.coerceToString ();
}outInfo.icon = sa.getResourceId (1, 0);
sa.recycle ();
var outerDepth = parser.getDepth ();
var type = -1;
try {
while ((type = parser.next ()) != 1 && (type != 3 || parser.getDepth () > outerDepth)) {
if (type == 3 || type == 4) {
continue ;}var nodeName = parser.getName ();
if (nodeName.equals ("action")) {
var value = attrs.getAttributeValue ("http://schemas.android.com/apk/res/android", "name");
if (value == null || value === "") {
outError[0] = "No value supplied for <android:name>";
return false;
}com.android.internal.util.XmlUtils.skipCurrentTag (parser);
outInfo.addAction (value);
} else if (nodeName.equals ("category")) {
var value = attrs.getAttributeValue ("http://schemas.android.com/apk/res/android", "name");
if (value == null || value === "") {
outError[0] = "No value supplied for <android:name>";
return false;
}com.android.internal.util.XmlUtils.skipCurrentTag (parser);
outInfo.addCategory (value);
} else if (nodeName.equals ("data")) {
sa = res.obtainAttributes (attrs, com.android.internal.R.styleable.AndroidManifestData);
var str = sa.getNonConfigurationString (0, 0);
if (str != null) {
try {
outInfo.addDataType (str);
} catch (e) {
if (Clazz.instanceOf (e, android.content.IntentFilter.MalformedMimeTypeException)) {
outError[0] = e.toString ();
sa.recycle ();
return false;
} else {
throw e;
}
}
}str = sa.getNonConfigurationString (1, 0);
if (str != null) {
outInfo.addDataScheme (str);
}var host = sa.getNonConfigurationString (2, 0);
var port = sa.getNonConfigurationString (3, 0);
if (host != null) {
outInfo.addDataAuthority (host, port);
}str = sa.getNonConfigurationString (4, 0);
if (str != null) {
outInfo.addDataPath (str, 0);
}str = sa.getNonConfigurationString (5, 0);
if (str != null) {
outInfo.addDataPath (str, 1);
}str = sa.getNonConfigurationString (6, 0);
if (str != null) {
outInfo.addDataPath (str, 2);
}sa.recycle ();
com.android.internal.util.XmlUtils.skipCurrentTag (parser);
} else {
outError[0] = "Bad element under <intent-filter>:" + nodeName;
return false;
}}
} catch (e) {
if (Clazz.instanceOf (e, org.xmlpull.v1.XmlPullParserException)) {
e.printStackTrace ();
} else {
throw e;
}
}
outInfo.hasDefault = outInfo.hasCategory ("android.intent.category.DEFAULT");
return true;
}, $fz.isPrivate = true, $fz), "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet,~N,android.content.pm.PackageParser.IntentInfo,~A,~B");
c$.copyNeeded = Clazz.defineMethod (c$, "copyNeeded", 
($fz = function (flags, p, metaData) {
if (p.mSetEnabled != 0) {
var enabled = p.mSetEnabled == 1;
if (p.applicationInfo.enabled != enabled) {
return true;
}}if ((flags & 128) != 0 && (metaData != null || p.mAppMetaData != null)) {
return true;
}if ((flags & 1024) != 0 && p.usesLibraryFiles != null) {
return true;
}return false;
}, $fz.isPrivate = true, $fz), "~N,android.content.pm.PackageParser.Package,android.os.Bundle");
c$.generateApplicationInfo = Clazz.defineMethod (c$, "generateApplicationInfo", 
function (p, flags) {
if (p == null) return null;
if (!android.content.pm.PackageParser.copyNeeded (flags, p, null)) {
if (!android.content.pm.PackageParser.sCompatibilityModeEnabled) {
p.applicationInfo.disableCompatibilityMode ();
}return p.applicationInfo;
}var ai =  new android.content.pm.ApplicationInfo (p.applicationInfo);
if ((flags & 128) != 0) {
ai.metaData = p.mAppMetaData;
}if ((flags & 1024) != 0) {
ai.sharedLibraryFiles = p.usesLibraryFiles;
}if (!android.content.pm.PackageParser.sCompatibilityModeEnabled) {
ai.disableCompatibilityMode ();
}ai.enabled = p.mSetEnabled == 1;
return ai;
}, "android.content.pm.PackageParser.Package,~N");
c$.generateActivityInfo = Clazz.defineMethod (c$, "generateActivityInfo", 
function (a, flags) {
if (a == null) return null;
if (!android.content.pm.PackageParser.copyNeeded (flags, a.owner, a.metaData)) {
return a.info;
}var ai =  new android.content.pm.ActivityInfo (a.info);
ai.metaData = a.metaData;
ai.applicationInfo = android.content.pm.PackageParser.generateApplicationInfo (a.owner, flags);
return ai;
}, "android.content.pm.PackageParser.Activity,~N");
c$.generateServiceInfo = Clazz.defineMethod (c$, "generateServiceInfo", 
function (a, flags) {
if (a == null) return null;
if (!android.content.pm.PackageParser.copyNeeded (flags, a.owner, a.metaData)) {
return a.info;
}var ai =  new android.content.pm.ServiceInfo (a.info);
ai.metaData = a.metaData;
ai.applicationInfo = android.content.pm.PackageParser.generateApplicationInfo (a.owner, flags);
return ai;
}, "android.content.pm.PackageParser.Service,~N");
c$.setCompatibilityModeEnabled = Clazz.defineMethod (c$, "setCompatibilityModeEnabled", 
function (compatibilityModeEnabled) {
($t$ = android.content.pm.PackageParser.sCompatibilityModeEnabled = compatibilityModeEnabled, android.content.pm.PackageParser.prototype.sCompatibilityModeEnabled = android.content.pm.PackageParser.sCompatibilityModeEnabled, $t$);
}, "~B");
c$.generateProviderInfo = Clazz.defineMethod (c$, "generateProviderInfo", 
function (p, flags) {
if (p == null) return null;
if (!android.content.pm.PackageParser.copyNeeded (flags, p.owner, p.metaData) && ((flags & 2048) != 0 || p.info.uriPermissionPatterns == null)) {
return p.info;
}var pi =  new android.content.pm.ProviderInfo (p.info);
pi.metaData = p.metaData;
if ((flags & 2048) == 0) {
pi.uriPermissionPatterns = null;
}pi.applicationInfo = android.content.pm.PackageParser.generateApplicationInfo (p.owner, flags);
return pi;
}, "android.content.pm.PackageParser.Provider,~N");
c$.generateInstrumentationInfo = Clazz.defineMethod (c$, "generateInstrumentationInfo", 
function (i, flags) {
if (i == null) return null;
if ((flags & 128) == 0) {
return i.info;
}var ii =  new android.content.pm.InstrumentationInfo (i.info);
ii.metaData = i.metaData;
return null;
}, "android.content.pm.PackageParser.Instrumentation,~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.name = null;
this.sdkVersion = 0;
this.fileVersion = 0;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "NewPermissionInfo");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.name = a;
this.sdkVersion = b;
this.fileVersion = c;
}, "~S,~N,~N");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.owner = null;
this.outError = null;
this.nameRes = 0;
this.labelRes = 0;
this.iconRes = 0;
this.logoRes = 0;
this.tag = null;
this.sa = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "ParsePackageItemArgs");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e, f) {
this.owner = a;
this.outError = b;
this.nameRes = c;
this.labelRes = d;
this.iconRes = e;
this.logoRes = f;
}, "android.content.pm.PackageParser.Package,~A,~N,~N,~N,~N");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.sepProcesses = null;
this.processRes = 0;
this.descriptionRes = 0;
this.enabledRes = 0;
this.flags = 0;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "ParseComponentArgs", android.content.pm.PackageParser.ParsePackageItemArgs);
Clazz.makeConstructor (c$, 
function (a, b, c, d, e, f, g, h, i, j) {
Clazz.superConstructor (this, android.content.pm.PackageParser.ParseComponentArgs, [a, b, c, d, e, f]);
this.sepProcesses = g;
this.processRes = h;
this.descriptionRes = i;
this.enabledRes = j;
}, "android.content.pm.PackageParser.Package,~A,~N,~N,~N,~N,~A,~N,~N,~N");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.packageName = null;
this.installLocation = 0;
this.mScanPath = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "PackageLite");
Clazz.makeConstructor (c$, 
function (a, b) {
this.packageName = a;
this.installLocation = b;
}, "~S,~N");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mResource = null;
this.packageName = null;
this.applicationInfo = null;
this.activities = null;
this.receivers = null;
this.providers = null;
this.services = null;
this.instrumentation = null;
this.protectedBroadcasts = null;
this.usesLibraries = null;
this.usesOptionalLibraries = null;
this.usesLibraryFiles = null;
this.mOriginalPackages = null;
this.mRealPackage = null;
this.mAdoptPermissions = null;
this.mAppMetaData = null;
this.mPath = null;
this.mVersionCode = 0;
this.mVersionName = null;
this.mSharedUserId = null;
this.mSharedUserLabel = 0;
this.mPreferredOrder = 0;
this.mScanPath = null;
this.mDidDexOpt = false;
this.mSetEnabled = 0;
this.mExtras = null;
this.mOperationPending = false;
this.installLocation = 0;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "Package");
Clazz.prepareFields (c$, function () {
this.applicationInfo =  new android.content.pm.ApplicationInfo ();
this.activities =  new java.util.ArrayList (0);
this.receivers =  new java.util.ArrayList (0);
this.providers =  new java.util.ArrayList (0);
this.services =  new java.util.ArrayList (0);
this.instrumentation =  new java.util.ArrayList (0);
});
Clazz.makeConstructor (c$, 
function (a) {
this.packageName = a;
this.applicationInfo.packageName = a;
this.applicationInfo.uid = -1;
}, "~S");
Clazz.defineMethod (c$, "setPackageName", 
function (a) {
this.packageName = a;
this.applicationInfo.packageName = a;
for (var b = this.activities.size () - 1; b >= 0; b--) {
this.activities.get (b).setPackageName (a);
}
for (var c = this.receivers.size () - 1; c >= 0; c--) {
this.receivers.get (c).setPackageName (a);
}
for (var d = this.services.size () - 1; d >= 0; d--) {
this.services.get (d).setPackageName (a);
}
}, "~S");
Clazz.overrideMethod (c$, "toString", 
function () {
return "Package{" + this.packageName + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.owner = null;
this.intents = null;
this.className = null;
this.metaData = null;
this.componentName = null;
this.componentShortName = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "Component");
Clazz.makeConstructor (c$, 
function (a) {
this.owner = a;
this.intents = null;
this.className = null;
}, "android.content.pm.PackageParser.Package");
Clazz.makeConstructor (c$, 
function (a, b) {
this.owner = a.owner;
this.intents =  new java.util.ArrayList (0);
var c = a.sa.getNonConfigurationString (a.nameRes, 0);
if (c == null) {
this.className = null;
a.outError[0] = a.tag + " does not specify android:name";
return ;
}b.name = android.content.pm.PackageParser.buildClassName (this.owner.applicationInfo.packageName, c, a.outError);
if (b.name == null) {
this.className = null;
a.outError[0] = a.tag + " does not have valid android:name";
return ;
}this.className = b.name;
var d = a.sa.getResourceId (a.iconRes, 0);
if (d != 0) {
b.icon = d;
b.nonLocalizedLabel = null;
}var e = a.sa.peekValue (a.labelRes);
if (e != null && (b.labelRes = e.resourceId) == 0) {
b.nonLocalizedLabel = e.coerceToString ();
}b.packageName = this.owner.packageName;
}, "android.content.pm.PackageParser.ParsePackageItemArgs,android.content.pm.PackageItemInfo");
Clazz.makeConstructor (c$, 
function (a, b) {
this.owner = a.owner;
this.intents =  new java.util.ArrayList (0);
var c = a.sa.getNonConfigurationString (a.nameRes, 0);
if (c == null) {
this.className = null;
a.outError[0] = a.tag + " does not specify android:name";
return ;
}b.name = android.content.pm.PackageParser.buildClassName (this.owner.applicationInfo.packageName, c, a.outError);
if (b.name == null) {
this.className = null;
a.outError[0] = a.tag + " does not have valid android:name";
return ;
}this.className = b.name;
var d = a.sa.getResourceId (a.iconRes, 0);
if (d != 0) {
b.icon = d;
b.nonLocalizedLabel = null;
}var e = a.sa.peekValue (a.labelRes);
if (e != null && (b.labelRes = e.resourceId) == 0) {
b.nonLocalizedLabel = e.coerceToString ();
}b.packageName = this.owner.packageName;
if (a.outError[0] != null) {
return ;
}if (a.processRes != 0) {
var f;
f = a.sa.getNonConfigurationString (a.processRes, 0);
b.processName = android.content.pm.PackageParser.buildProcessName (this.owner.applicationInfo.packageName, this.owner.applicationInfo.processName, f, a.flags, a.sepProcesses, a.outError);
}if (a.descriptionRes != 0) {
b.descriptionRes = a.sa.getResourceId (a.descriptionRes, 0);
}b.enabled = a.sa.getBoolean (a.enabledRes, true);
}, "android.content.pm.PackageParser.ParseComponentArgs,android.content.pm.ComponentInfo");
Clazz.makeConstructor (c$, 
function (a) {
this.owner = a.owner;
this.intents = a.intents;
this.className = a.className;
this.componentName = a.componentName;
this.componentShortName = a.componentShortName;
}, "android.content.pm.PackageParser.Component");
Clazz.defineMethod (c$, "getComponentName", 
function () {
if (this.componentName != null) {
return this.componentName;
}if (this.className != null) {
this.componentName =  new android.content.ComponentName (this.owner.applicationInfo.packageName, this.className);
}return this.componentName;
});
Clazz.defineMethod (c$, "getComponentShortName", 
function () {
if (this.componentShortName != null) {
return this.componentShortName;
}var a = this.getComponentName ();
if (a != null) {
this.componentShortName = a.flattenToShortString ();
}return this.componentShortName;
});
Clazz.defineMethod (c$, "setPackageName", 
function (a) {
this.componentName = null;
this.componentShortName = null;
}, "~S");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.info = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "Activity", android.content.pm.PackageParser.Component);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.content.pm.PackageParser.Activity, [a, b]);
this.info = b;
this.info.applicationInfo = a.owner.applicationInfo;
}, "android.content.pm.PackageParser.ParseComponentArgs,android.content.pm.ActivityInfo");
Clazz.defineMethod (c$, "setPackageName", 
function (a) {
Clazz.superCall (this, android.content.pm.PackageParser.Activity, "setPackageName", [a]);
this.info.packageName = a;
}, "~S");
Clazz.overrideMethod (c$, "toString", 
function () {
return "Activity{" + this.getComponentShortName () + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.info = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "Service", android.content.pm.PackageParser.Component);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.content.pm.PackageParser.Service, [a, b]);
this.info = b;
this.info.applicationInfo = a.owner.applicationInfo;
}, "android.content.pm.PackageParser.ParseComponentArgs,android.content.pm.ServiceInfo");
Clazz.defineMethod (c$, "setPackageName", 
function (a) {
Clazz.superCall (this, android.content.pm.PackageParser.Service, "setPackageName", [a]);
this.info.packageName = a;
}, "~S");
Clazz.overrideMethod (c$, "toString", 
function () {
return "Service{" + this.getComponentShortName () + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.hasDefault = false;
this.labelRes = 0;
this.nonLocalizedLabel = null;
this.icon = 0;
this.logo = 0;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "IntentInfo", android.content.IntentFilter);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.activity = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "ActivityIntentInfo", android.content.pm.PackageParser.IntentInfo);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.content.pm.PackageParser.ActivityIntentInfo, []);
this.activity = a;
}, "android.content.pm.PackageParser.Activity");
Clazz.overrideMethod (c$, "toString", 
function () {
return "ActivityIntentInfo{" + this.activity.info.name + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.service = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "ServiceIntentInfo", android.content.pm.PackageParser.IntentInfo);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.content.pm.PackageParser.ServiceIntentInfo, []);
this.service = a;
}, "android.content.pm.PackageParser.Service");
Clazz.overrideMethod (c$, "toString", 
function () {
return "ActivityIntentInfo{" + this.service.info.name + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.info = null;
this.syncable = false;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "Provider", android.content.pm.PackageParser.Component);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.content.pm.PackageParser.Provider, [a, b]);
this.info = b;
this.info.applicationInfo = a.owner.applicationInfo;
this.syncable = false;
}, "android.content.pm.PackageParser.ParseComponentArgs,android.content.pm.ProviderInfo");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.content.pm.PackageParser.Provider, [a]);
this.info = a.info;
this.syncable = a.syncable;
}, "android.content.pm.PackageParser.Provider");
Clazz.defineMethod (c$, "setPackageName", 
function (a) {
Clazz.superCall (this, android.content.pm.PackageParser.Provider, "setPackageName", [a]);
this.info.packageName = a;
}, "~S");
Clazz.overrideMethod (c$, "toString", 
function () {
return "Provider{ " + this.info.name + "}";
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.info = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageParser, "Instrumentation", android.content.pm.PackageParser.Component);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.content.pm.PackageParser.Instrumentation, [a, b]);
this.info = b;
}, "android.content.pm.PackageParser.ParsePackageItemArgs,android.content.pm.InstrumentationInfo");
Clazz.defineMethod (c$, "setPackageName", 
function (a) {
Clazz.superCall (this, android.content.pm.PackageParser.Instrumentation, "setPackageName", [a]);
this.info.packageName = a;
}, "~S");
Clazz.overrideMethod (c$, "toString", 
function () {
return "Instrumentation{" + Integer.toHexString (System.identityHashCode (this)) + " " + this.getComponentShortName () + "}";
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"RIGID_PARSER", false,
"TAG", "PackageParser",
"sCompatibilityModeEnabled", true,
"PARSE_DEFAULT_INSTALL_LOCATION", -1,
"PARSE_IS_SYSTEM", 1,
"PARSE_CHATTY", 2,
"PARSE_MUST_BE_APK", 4,
"PARSE_IGNORE_PROCESSES", 8,
"PARSE_FORWARD_LOCK", 16,
"PARSE_ON_SDCARD", 32,
"PARSE_IS_SYSTEM_DIR", 64,
"ANDROID_RESOURCES", "http://schemas.android.com/apk/res/android");
});
