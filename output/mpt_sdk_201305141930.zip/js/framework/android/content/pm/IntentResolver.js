﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["java.util.Iterator", "$.HashMap", "$.HashSet"], "android.content.pm.IntentResolver", ["android.util.LogPrinter", "$.PrintWriterPrinter", "$.Slog", "java.util.ArrayList", "$.Collections"], function () {
c$ = Clazz.decorateAsClass (function () {
if (!Clazz.isClassDefined ("android.content.pm.IntentResolver.IteratorWrapper")) {
android.content.pm.IntentResolver.$IntentResolver$IteratorWrapper$ ();
}
this.mFilters = null;
this.mTypeToFilter = null;
this.mBaseTypeToFilter = null;
this.mWildTypeToFilter = null;
this.mSchemeToFilter = null;
this.mActionToFilter = null;
this.mTypedActionToFilter = null;
Clazz.instantialize (this, arguments);
}, android.content.pm, "IntentResolver");
Clazz.prepareFields (c$, function () {
this.mFilters =  new java.util.HashSet ();
this.mTypeToFilter =  new java.util.HashMap ();
this.mBaseTypeToFilter =  new java.util.HashMap ();
this.mWildTypeToFilter =  new java.util.HashMap ();
this.mSchemeToFilter =  new java.util.HashMap ();
this.mActionToFilter =  new java.util.HashMap ();
this.mTypedActionToFilter =  new java.util.HashMap ();
});
Clazz.defineMethod (c$, "addFilter", 
function (f) {
if (false) {
System.out.println ("IntentResolver" + "Adding filter: " + f);
f.dump ( new android.util.LogPrinter (2, "IntentResolver", 3), "      ");
System.out.println ("IntentResolver    Building Lookup Maps:");
}this.mFilters.add (f);
var numS = this.register_intent_filter (f, f.schemesIterator (), this.mSchemeToFilter, "      Scheme: ");
var numT = this.register_mime_types (f, "      Type: ");
if (numS == 0 && numT == 0) {
this.register_intent_filter (f, f.actionsIterator (), this.mActionToFilter, "      Action: ");
}if (numT != 0) {
this.register_intent_filter (f, f.actionsIterator (), this.mTypedActionToFilter, "      TypedAction: ");
}}, "~O");
Clazz.defineMethod (c$, "removeFilter", 
function (f) {
this.removeFilterInternal (f);
this.mFilters.remove (f);
}, "~O");
Clazz.defineMethod (c$, "removeFilterInternal", 
function (f) {
if (false) {
System.out.println ("IntentResolver" + "Removing filter: " + f);
f.dump ( new android.util.LogPrinter (2, "IntentResolver", 3), "      ");
System.out.println ("IntentResolver    Cleaning Lookup Maps:");
}var numS = this.unregister_intent_filter (f, f.schemesIterator (), this.mSchemeToFilter, "      Scheme: ");
var numT = this.unregister_mime_types (f, "      Type: ");
if (numS == 0 && numT == 0) {
this.unregister_intent_filter (f, f.actionsIterator (), this.mActionToFilter, "      Action: ");
}if (numT != 0) {
this.unregister_intent_filter (f, f.actionsIterator (), this.mTypedActionToFilter, "      TypedAction: ");
}}, "~O");
Clazz.defineMethod (c$, "dumpMap", 
function (out, titlePrefix, title, prefix, map, packageName, printFilter) {
var eprefix = prefix + "  ";
var fprefix = prefix + "    ";
var printedSomething = false;
var printer = null;
for (var e, $e = map.entrySet ().iterator (); $e.hasNext () && ((e = $e.next ()) || true);) {
var a = e.getValue ();
var N = a.size ();
var printedHeader = false;
for (var i = 0; i < N; i++) {
var filter = a.get (i);
if (packageName != null && !packageName.equals (this.packageForFilter (filter))) {
continue ;}if (title != null) {
out.print (titlePrefix);
out.println (title);
title = null;
}if (!printedHeader) {
out.print (eprefix);
out.print (e.getKey ());
out.println (":");
printedHeader = true;
}printedSomething = true;
this.dumpFilter (out, fprefix, filter);
if (printFilter) {
if (printer == null) {
printer =  new android.util.PrintWriterPrinter ();
}filter.dump (printer, fprefix + "  ");
}}
}
return printedSomething;
}, "java.io.PrintWriter,~S,~S,~S,java.util.Map,~S,~B");
Clazz.defineMethod (c$, "dump", 
function (out, title, prefix, packageName, printFilter) {
var innerPrefix = prefix + "  ";
var sepPrefix = "\n" + prefix;
var curPrefix = title + "\n" + prefix;
if (this.dumpMap (out, curPrefix, "Full MIME Types:", innerPrefix, this.mTypeToFilter, packageName, printFilter)) {
curPrefix = sepPrefix;
}if (this.dumpMap (out, curPrefix, "Base MIME Types:", innerPrefix, this.mBaseTypeToFilter, packageName, printFilter)) {
curPrefix = sepPrefix;
}if (this.dumpMap (out, curPrefix, "Wild MIME Types:", innerPrefix, this.mWildTypeToFilter, packageName, printFilter)) {
curPrefix = sepPrefix;
}if (this.dumpMap (out, curPrefix, "Schemes:", innerPrefix, this.mSchemeToFilter, packageName, printFilter)) {
curPrefix = sepPrefix;
}if (this.dumpMap (out, curPrefix, "Non-Data Actions:", innerPrefix, this.mActionToFilter, packageName, printFilter)) {
curPrefix = sepPrefix;
}if (this.dumpMap (out, curPrefix, "MIME Typed Actions:", innerPrefix, this.mTypedActionToFilter, packageName, printFilter)) {
curPrefix = sepPrefix;
}return curPrefix === sepPrefix;
}, "java.io.PrintWriter,~S,~S,~S,~B");
Clazz.defineMethod (c$, "filterIterator", 
function () {
return Clazz.innerTypeInstance (android.content.pm.IntentResolver.IteratorWrapper, this, null, this.mFilters.iterator ());
});
Clazz.defineMethod (c$, "filterSet", 
function () {
return java.util.Collections.unmodifiableSet (this.mFilters);
});
Clazz.defineMethod (c$, "queryIntentFromList", 
function (intent, resolvedType, defaultOnly, listCut) {
var resultList =  new java.util.ArrayList ();
var debug = false || ((intent.getFlags () & 8) != 0);
var scheme = intent.getScheme ();
var N = listCut.size ();
for (var i = 0; i < N; ++i) {
this.buildResolveList (intent, debug, defaultOnly, resolvedType, scheme, listCut.get (i), resultList);
}
this.sortResults (resultList);
return resultList;
}, "android.content.Intent,~S,~B,java.util.ArrayList");
Clazz.defineMethod (c$, "queryIntent", 
function (intent, resolvedType, defaultOnly) {
var scheme = intent.getScheme ();
var finalList =  new java.util.ArrayList ();
var debug = false || ((intent.getFlags () & 8) != 0);
if (debug) android.util.Slog.v ("IntentResolver", "Resolving type " + resolvedType + " scheme " + scheme + " of intent " + intent);
var firstTypeCut = null;
var secondTypeCut = null;
var thirdTypeCut = null;
var schemeCut = null;
if (resolvedType != null) {
var slashpos = resolvedType.indexOf ('/');
if (slashpos > 0) {
var baseType = resolvedType.substring (0, slashpos);
if (!baseType.equals ("*")) {
if (resolvedType.length != slashpos + 2 || (resolvedType.charAt (slashpos + 1)).charCodeAt (0) != ('*').charCodeAt (0)) {
firstTypeCut = this.mTypeToFilter.get (resolvedType);
if (debug) android.util.Slog.v ("IntentResolver", "First type cut: " + firstTypeCut);
secondTypeCut = this.mWildTypeToFilter.get (baseType);
if (debug) android.util.Slog.v ("IntentResolver", "Second type cut: " + secondTypeCut);
} else {
firstTypeCut = this.mBaseTypeToFilter.get (baseType);
if (debug) android.util.Slog.v ("IntentResolver", "First type cut: " + firstTypeCut);
secondTypeCut = this.mWildTypeToFilter.get (baseType);
if (debug) android.util.Slog.v ("IntentResolver", "Second type cut: " + secondTypeCut);
}thirdTypeCut = this.mWildTypeToFilter.get ("*");
if (debug) android.util.Slog.v ("IntentResolver", "Third type cut: " + thirdTypeCut);
} else if (intent.getAction () != null) {
firstTypeCut = this.mTypedActionToFilter.get (intent.getAction ());
if (debug) android.util.Slog.v ("IntentResolver", "Typed Action list: " + firstTypeCut);
}}}if (scheme != null) {
System.out.println ("mSchemeToFilter:" + this.mSchemeToFilter.size () + this.mSchemeToFilter);
schemeCut = this.mSchemeToFilter.get (scheme);
if (debug) android.util.Slog.v ("IntentResolver", "Scheme list: " + schemeCut);
}if (resolvedType == null && scheme == null && intent.getAction () != null) {
firstTypeCut = this.mActionToFilter.get (intent.getAction ());
if (debug) android.util.Slog.v ("IntentResolver", "Action list: " + firstTypeCut);
}if (firstTypeCut != null) {
this.buildResolveList (intent, debug, defaultOnly, resolvedType, scheme, firstTypeCut, finalList);
}if (secondTypeCut != null) {
this.buildResolveList (intent, debug, defaultOnly, resolvedType, scheme, secondTypeCut, finalList);
}if (thirdTypeCut != null) {
this.buildResolveList (intent, debug, defaultOnly, resolvedType, scheme, thirdTypeCut, finalList);
}if (schemeCut != null) {
this.buildResolveList (intent, debug, defaultOnly, resolvedType, scheme, schemeCut, finalList);
}this.sortResults (finalList);
if (debug) {
android.util.Slog.v ("IntentResolver", "Final result list:");
for (var r, $r = finalList.iterator (); $r.hasNext () && ((r = $r.next ()) || true);) {
android.util.Slog.v ("IntentResolver", "  " + r);
}
}return finalList;
}, "android.content.Intent,~S,~B");
Clazz.defineMethod (c$, "allowFilterResult", 
function (filter, dest) {
return true;
}, "~O,java.util.List");
Clazz.defineMethod (c$, "packageForFilter", 
function (filter) {
return null;
}, "~O");
Clazz.defineMethod (c$, "newResult", 
function (filter, match) {
return filter;
}, "~O,~N");
Clazz.defineMethod (c$, "sortResults", 
function (results) {
java.util.Collections.sort (results, android.content.pm.IntentResolver.mResolvePrioritySorter);
}, "java.util.List");
Clazz.defineMethod (c$, "dumpFilter", 
function (out, prefix, filter) {
out.print (prefix);
out.println (filter);
}, "java.io.PrintWriter,~S,~O");
Clazz.defineMethod (c$, "register_mime_types", 
($fz = function (filter, prefix) {
var i = filter.typesIterator ();
if (i == null) {
return 0;
}var num = 0;
while (i.hasNext ()) {
var name = i.next ();
num++;
if (false) android.util.Slog.v ("IntentResolver", prefix + name);
var baseName = name;
var slashpos = name.indexOf ('/');
if (slashpos > 0) {
baseName = name.substring (0, slashpos).intern ();
} else {
name = name + "/*";
}var array = this.mTypeToFilter.get (name);
if (array == null) {
array =  new java.util.ArrayList ();
this.mTypeToFilter.put (name, array);
}array.add (filter);
if (slashpos > 0) {
array = this.mBaseTypeToFilter.get (baseName);
if (array == null) {
array =  new java.util.ArrayList ();
this.mBaseTypeToFilter.put (baseName, array);
}array.add (filter);
} else {
array = this.mWildTypeToFilter.get (baseName);
if (array == null) {
array =  new java.util.ArrayList ();
this.mWildTypeToFilter.put (baseName, array);
}array.add (filter);
}}
return num;
}, $fz.isPrivate = true, $fz), "~O,~S");
Clazz.defineMethod (c$, "unregister_mime_types", 
($fz = function (filter, prefix) {
var i = filter.typesIterator ();
if (i == null) {
return 0;
}var num = 0;
while (i.hasNext ()) {
var name = i.next ();
num++;
if (false) android.util.Slog.v ("IntentResolver", prefix + name);
var baseName = name;
var slashpos = name.indexOf ('/');
if (slashpos > 0) {
baseName = name.substring (0, slashpos).intern ();
} else {
name = name + "/*";
}if (!this.remove_all_objects (this.mTypeToFilter.get (name), filter)) {
this.mTypeToFilter.remove (name);
}if (slashpos > 0) {
if (!this.remove_all_objects (this.mBaseTypeToFilter.get (baseName), filter)) {
this.mBaseTypeToFilter.remove (baseName);
}} else {
if (!this.remove_all_objects (this.mWildTypeToFilter.get (baseName), filter)) {
this.mWildTypeToFilter.remove (baseName);
}}}
return num;
}, $fz.isPrivate = true, $fz), "~O,~S");
Clazz.defineMethod (c$, "register_intent_filter", 
($fz = function (filter, i, dest, prefix) {
if (i == null) {
return 0;
}var num = 0;
while (i.hasNext ()) {
var name = i.next ();
num++;
if (false) android.util.Slog.v ("IntentResolver", prefix + name);
var array = dest.get (name);
if (array == null) {
array =  new java.util.ArrayList ();
dest.put (name, array);
}array.add (filter);
}
return num;
}, $fz.isPrivate = true, $fz), "~O,java.util.Iterator,java.util.HashMap,~S");
Clazz.defineMethod (c$, "unregister_intent_filter", 
($fz = function (filter, i, dest, prefix) {
if (i == null) {
return 0;
}var num = 0;
while (i.hasNext ()) {
var name = i.next ();
num++;
if (false) android.util.Slog.v ("IntentResolver", prefix + name);
if (!this.remove_all_objects (dest.get (name), filter)) {
dest.remove (name);
}}
return num;
}, $fz.isPrivate = true, $fz), "~O,java.util.Iterator,java.util.HashMap,~S");
Clazz.defineMethod (c$, "remove_all_objects", 
($fz = function (list, object) {
if (list != null) {
var N = list.size ();
for (var idx = 0; idx < N; idx++) {
if (list.get (idx) === object) {
list.remove (idx);
idx--;
N--;
}}
return N > 0;
}return false;
}, $fz.isPrivate = true, $fz), "java.util.List,~O");
Clazz.defineMethod (c$, "buildResolveList", 
($fz = function (intent, debug, defaultOnly, resolvedType, scheme, src, dest) {
var categories = intent.getCategories ();
var N = src != null ? src.size () : 0;
var hasNonDefaults = false;
var i;
for (i = 0; i < N; i++) {
var filter = src.get (i);
var match;
if (debug) android.util.Slog.v ("IntentResolver", "Matching against filter " + filter);
if (!this.allowFilterResult (filter, dest)) {
if (debug) {
android.util.Slog.v ("IntentResolver", "  Filter's target already added");
}continue ;}match = filter.match (intent.getAction (), resolvedType, scheme, intent.getData (), categories, "IntentResolver");
if (match >= 0) {
if (debug) android.util.Slog.v ("IntentResolver", "  Filter matched!  match=0x" + Integer.toHexString (match));
if (!defaultOnly || filter.hasCategory ("android.intent.category.DEFAULT")) {
var oneResult = this.newResult (filter, match);
if (oneResult != null) {
dest.add (oneResult);
}} else {
hasNonDefaults = true;
}} else {
if (debug) {
var reason;
switch (match) {
case -3:
reason = "action";
break;
case -4:
reason = "category";
break;
case -2:
reason = "data";
break;
case -1:
reason = "type";
break;
default:
reason = "unknown reason";
break;
}
android.util.Slog.v ("IntentResolver", "  Filter did not match: " + reason);
}}}
if (dest.size () == 0 && hasNonDefaults) {
android.util.Slog.w ("IntentResolver", "resolveIntent failed: found match, but none with Intent.CATEGORY_DEFAULT");
}}, $fz.isPrivate = true, $fz), "android.content.Intent,~B,~B,~S,~S,java.util.List,java.util.List");
c$.$IntentResolver$IteratorWrapper$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mI = null;
this.mCur = null;
Clazz.instantialize (this, arguments);
}, android.content.pm.IntentResolver, "IteratorWrapper", null, java.util.Iterator);
Clazz.makeConstructor (c$, 
function (a) {
this.mI = a;
}, "java.util.Iterator");
Clazz.defineMethod (c$, "hasNext", 
function () {
return this.mI.hasNext ();
});
Clazz.defineMethod (c$, "next", 
function () {
return (this.mCur = this.mI.next ());
});
Clazz.defineMethod (c$, "remove", 
function () {
if (this.mCur != null) {
this.b$["android.content.pm.IntentResolver"].removeFilterInternal (this.mCur);
}this.mI.remove ();
});
c$ = Clazz.p0p ();
};
c$.$IntentResolver$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content.pm, "IntentResolver$1", null, java.util.Comparator);
Clazz.overrideMethod (c$, "compare", 
function (o1, o2) {
var q1 = (o1).getPriority ();
var q2 = (o2).getPriority ();
return (q1 > q2) ? -1 : ((q1 < q2) ? 1 : 0);
}, "~O,~O");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"TAG", "IntentResolver",
"DEBUG", false,
"localLOGV", false);
c$.mResolvePrioritySorter = c$.prototype.mResolvePrioritySorter = ((Clazz.isClassDefined ("android.content.pm.IntentResolver$1") ? 0 : android.content.pm.IntentResolver.$IntentResolver$1$ ()), Clazz.innerTypeInstance (android.content.pm.IntentResolver$1, this, null));
});
