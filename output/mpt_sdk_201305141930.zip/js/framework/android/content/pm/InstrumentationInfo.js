﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.content.pm.PackageItemInfo", "android.os.Parcelable", "android.os.Parcelable.Creator"], "android.content.pm.InstrumentationInfo", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.targetPackage = null;
this.sourceDir = null;
this.publicSourceDir = null;
this.dataDir = null;
this.nativeLibraryDir = null;
this.handleProfiling = false;
this.functionalTest = false;
Clazz.instantialize (this, arguments);
}, android.content.pm, "InstrumentationInfo", android.content.pm.PackageItemInfo, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.pm.InstrumentationInfo, []);
});
Clazz.makeConstructor (c$, 
function (orig) {
Clazz.superConstructor (this, android.content.pm.InstrumentationInfo, [orig]);
this.targetPackage = orig.targetPackage;
this.sourceDir = orig.sourceDir;
this.publicSourceDir = orig.publicSourceDir;
this.dataDir = orig.dataDir;
this.nativeLibraryDir = orig.nativeLibraryDir;
this.handleProfiling = orig.handleProfiling;
this.functionalTest = orig.functionalTest;
}, "android.content.pm.InstrumentationInfo");
Clazz.overrideMethod (c$, "toString", 
function () {
return "InstrumentationInfo{" + Integer.toHexString (System.identityHashCode (this)) + " " + this.packageName + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, parcelableFlags) {
Clazz.superCall (this, android.content.pm.InstrumentationInfo, "writeToParcel", [dest, parcelableFlags]);
dest.writeString (this.targetPackage);
dest.writeString (this.sourceDir);
dest.writeString (this.publicSourceDir);
dest.writeString (this.dataDir);
dest.writeString (this.nativeLibraryDir);
dest.writeInt ((this.handleProfiling == false) ? 0 : 1);
dest.writeInt ((this.functionalTest == false) ? 0 : 1);
}, "android.os.Parcel,~N");
Clazz.makeConstructor (c$, 
($fz = function (source) {
Clazz.superConstructor (this, android.content.pm.InstrumentationInfo, []);
this.targetPackage = source.readString ();
this.sourceDir = source.readString ();
this.publicSourceDir = source.readString ();
this.dataDir = source.readString ();
this.nativeLibraryDir = source.readString ();
this.handleProfiling = source.readInt () != 0;
this.functionalTest = source.readInt () != 0;
}, $fz.isPrivate = true, $fz), "android.os.Parcel");
c$.$InstrumentationInfo$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content.pm, "InstrumentationInfo$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (source) {
return  new android.content.pm.InstrumentationInfo (source);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.content.pm.InstrumentationInfo$1") ? 0 : android.content.pm.InstrumentationInfo.$InstrumentationInfo$1$ ()), Clazz.innerTypeInstance (android.content.pm.InstrumentationInfo$1, this, null));
});
