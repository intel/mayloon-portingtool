﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.content.pm.PackageItemInfo"], "android.content.pm.ComponentInfo", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.applicationInfo = null;
this.processName = null;
this.descriptionRes = 0;
this.enabled = true;
this.exported = false;
Clazz.instantialize (this, arguments);
}, android.content.pm, "ComponentInfo", android.content.pm.PackageItemInfo);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.pm.ComponentInfo, []);
});
Clazz.makeConstructor (c$, 
function (orig) {
Clazz.superConstructor (this, android.content.pm.ComponentInfo, [orig]);
this.applicationInfo = orig.applicationInfo;
this.processName = orig.processName;
this.descriptionRes = orig.descriptionRes;
this.enabled = orig.enabled;
this.exported = orig.exported;
}, "android.content.pm.ComponentInfo");
Clazz.overrideMethod (c$, "loadLabel", 
function (pm) {
if (this.nonLocalizedLabel != null) {
return this.nonLocalizedLabel;
}var ai = this.applicationInfo;
var label;
if (this.labelRes != 0) {
label = pm.getText (this.packageName, this.labelRes, ai);
if (label != null) {
return label;
}}if (ai.nonLocalizedLabel != null) {
return ai.nonLocalizedLabel;
}if (ai.labelRes != 0) {
label = pm.getText (this.packageName, ai.labelRes, ai);
if (label != null) {
return label;
}}return this.name;
}, "android.content.pm.PackageManager");
Clazz.defineMethod (c$, "getIconResource", 
function () {
return this.icon != 0 ? this.icon : this.applicationInfo.icon;
});
Clazz.defineMethod (c$, "dumpFront", 
function (pw, prefix) {
Clazz.superCall (this, android.content.pm.ComponentInfo, "dumpFront", [pw, prefix]);
pw.println (prefix + "enabled=" + this.enabled + " exported=" + this.exported + " processName=" + this.processName);
if (this.descriptionRes != 0) {
pw.println (prefix + "description=" + this.descriptionRes);
}}, "android.util.Printer,~S");
Clazz.defineMethod (c$, "dumpBack", 
function (pw, prefix) {
if (this.applicationInfo != null) {
pw.println (prefix + "ApplicationInfo:");
this.applicationInfo.dump (pw, prefix + "  ");
} else {
pw.println (prefix + "ApplicationInfo: null");
}Clazz.superCall (this, android.content.pm.ComponentInfo, "dumpBack", [pw, prefix]);
}, "android.util.Printer,~S");
Clazz.overrideMethod (c$, "loadDefaultIcon", 
function (pm) {
return this.applicationInfo.loadIcon (pm);
}, "android.content.pm.PackageManager");
Clazz.overrideMethod (c$, "loadDefaultLogo", 
function (pm) {
return this.applicationInfo.loadLogo (pm);
}, "android.content.pm.PackageManager");
Clazz.overrideMethod (c$, "getApplicationInfo", 
function () {
return this.applicationInfo;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, parcelableFlags) {
Clazz.superCall (this, android.content.pm.ComponentInfo, "writeToParcel", [dest, parcelableFlags]);
this.applicationInfo.writeToParcel (dest, parcelableFlags);
dest.writeString (this.processName);
dest.writeInt (this.descriptionRes);
dest.writeInt (this.enabled ? 1 : 0);
dest.writeInt (this.exported ? 1 : 0);
}, "android.os.Parcel,~N");
});
