﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.os.Parcelable"], "android.content.pm.PackageInfo", ["java.io.File"], function () {
c$ = Clazz.decorateAsClass (function () {
this.packageName = null;
this.versionCode = 0;
this.versionName = null;
this.sharedUserId = null;
this.sharedUserLabel = 0;
this.applicationInfo = null;
this.firstInstallTime = 0;
this.lastUpdateTime = 0;
this.gids = null;
this.activities = null;
this.receivers = null;
this.requestedPermissions = null;
this.installLocation = 1;
Clazz.instantialize (this, arguments);
}, android.content.pm, "PackageInfo", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "getDataDirFile", 
function () {
if (this.packageName != null) {
return  new java.io.File (this.packageName);
} else {
return null;
}});
Clazz.overrideMethod (c$, "toString", 
function () {
return "PackageInfo{" + this.packageName + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineStatics (c$,
"INSTALL_LOCATION_UNSPECIFIED", -1,
"INSTALL_LOCATION_AUTO", 0,
"INSTALL_LOCATION_INTERNAL_ONLY", 1,
"INSTALL_LOCATION_PREFER_EXTERNAL", 2);
});
