﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.content.pm.ComponentInfo", "android.os.Parcelable", "android.os.Parcelable.Creator"], "android.content.pm.ActivityInfo", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.zIndex = 0;
this.theme = 0;
this.launchMode = 0;
this.permission = null;
this.taskAffinity = null;
this.targetActivity = null;
this.flags = 0;
this.screenOrientation = -1;
this.configChanges = 0;
this.softInputMode = 0;
Clazz.instantialize (this, arguments);
}, android.content.pm, "ActivityInfo", android.content.pm.ComponentInfo, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.pm.ActivityInfo, []);
});
Clazz.makeConstructor (c$, 
function (orig) {
Clazz.superConstructor (this, android.content.pm.ActivityInfo, [orig]);
this.theme = orig.theme;
this.launchMode = orig.launchMode;
this.permission = orig.permission;
this.taskAffinity = orig.taskAffinity;
this.targetActivity = orig.targetActivity;
this.flags = orig.flags;
this.screenOrientation = orig.screenOrientation;
this.configChanges = orig.configChanges;
this.softInputMode = orig.softInputMode;
}, "android.content.pm.ActivityInfo");
Clazz.makeConstructor (c$, 
function (source) {
Clazz.superConstructor (this, android.content.pm.ActivityInfo, []);
}, "android.os.Parcel");
Clazz.defineMethod (c$, "getThemeResource", 
function () {
return this.theme != 0 ? this.theme : this.applicationInfo.theme;
});
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
Clazz.superCall (this, android.content.pm.ActivityInfo, "dumpFront", [pw, prefix]);
if (this.permission != null) {
pw.println (prefix + "permission=" + this.permission);
}pw.println (prefix + "taskAffinity=" + this.taskAffinity + " targetActivity=" + this.targetActivity);
if (this.launchMode != 0 || this.flags != 0 || this.theme != 0) {
pw.println (prefix + "launchMode=" + this.launchMode + " flags=0x" + Integer.toHexString (this.flags) + " theme=0x" + Integer.toHexString (this.theme));
}if (this.screenOrientation != -1 || this.configChanges != 0 || this.softInputMode != 0) {
pw.println (prefix + "screenOrientation=" + this.screenOrientation + " configChanges=0x" + Integer.toHexString (this.configChanges) + " softInputMode=0x" + Integer.toHexString (this.softInputMode));
}Clazz.superCall (this, android.content.pm.ActivityInfo, "dumpBack", [pw, prefix]);
}, "android.util.Printer,~S");
Clazz.overrideMethod (c$, "toString", 
function () {
return "ActivityInfo{" + this.name + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, parcelableFlags) {
Clazz.superCall (this, android.content.pm.ActivityInfo, "writeToParcel", [dest, parcelableFlags]);
dest.writeInt (this.theme);
dest.writeInt (this.launchMode);
dest.writeString (this.permission);
dest.writeString (this.taskAffinity);
dest.writeString (this.targetActivity);
dest.writeInt (this.flags);
dest.writeInt (this.screenOrientation);
dest.writeInt (this.configChanges);
dest.writeInt (this.softInputMode);
}, "android.os.Parcel,~N");
c$.$ActivityInfo$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content.pm, "ActivityInfo$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (source) {
return  new android.content.pm.ActivityInfo (source);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"LAUNCH_MULTIPLE", 0,
"LAUNCH_SINGLE_TOP", 1,
"LAUNCH_SINGLE_TASK", 2,
"LAUNCH_SINGLE_INSTANCE", 3,
"FLAG_MULTIPROCESS", 0x0001,
"FLAG_FINISH_ON_TASK_LAUNCH", 0x0002,
"FLAG_CLEAR_TASK_ON_LAUNCH", 0x0004,
"FLAG_ALWAYS_RETAIN_TASK_STATE", 0x0008,
"FLAG_STATE_NOT_NEEDED", 0x0010,
"FLAG_EXCLUDE_FROM_RECENTS", 0x0020,
"FLAG_ALLOW_TASK_REPARENTING", 0x0040,
"FLAG_NO_HISTORY", 0x0080,
"FLAG_FINISH_ON_CLOSE_SYSTEM_DIALOGS", 0x0100,
"SCREEN_ORIENTATION_UNSPECIFIED", -1,
"SCREEN_ORIENTATION_LANDSCAPE", 0,
"SCREEN_ORIENTATION_PORTRAIT", 1,
"SCREEN_ORIENTATION_USER", 2,
"SCREEN_ORIENTATION_BEHIND", 3,
"SCREEN_ORIENTATION_SENSOR", 4,
"SCREEN_ORIENTATION_NOSENSOR", 5,
"SCREEN_ORIENTATION_SENSOR_LANDSCAPE", 6,
"SCREEN_ORIENTATION_SENSOR_PORTRAIT", 7,
"SCREEN_ORIENTATION_REVERSE_LANDSCAPE", 8,
"SCREEN_ORIENTATION_REVERSE_PORTRAIT", 9,
"SCREEN_ORIENTATION_FULL_SENSOR", 10,
"CONFIG_MCC", 0x0001,
"CONFIG_MNC", 0x0002,
"CONFIG_LOCALE", 0x0004,
"CONFIG_TOUCHSCREEN", 0x0008,
"CONFIG_KEYBOARD", 0x0010,
"CONFIG_KEYBOARD_HIDDEN", 0x0020,
"CONFIG_NAVIGATION", 0x0040,
"CONFIG_ORIENTATION", 0x0080,
"CONFIG_SCREEN_LAYOUT", 0x0100,
"CONFIG_UI_MODE", 0x0200,
"CONFIG_FONT_SCALE", 0x40000000);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.content.pm.ActivityInfo$1") ? 0 : android.content.pm.ActivityInfo.$ActivityInfo$1$ ()), Clazz.innerTypeInstance (android.content.pm.ActivityInfo$1, this, null));
});
