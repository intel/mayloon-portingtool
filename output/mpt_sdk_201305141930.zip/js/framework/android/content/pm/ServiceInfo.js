﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.content.pm.ComponentInfo", "android.os.Parcelable", "android.os.Parcelable.Creator"], "android.content.pm.ServiceInfo", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.permission = null;
Clazz.instantialize (this, arguments);
}, android.content.pm, "ServiceInfo", android.content.pm.ComponentInfo, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.pm.ServiceInfo, []);
});
Clazz.makeConstructor (c$, 
function (orig) {
Clazz.superConstructor (this, android.content.pm.ServiceInfo, [orig]);
this.permission = orig.permission;
}, "android.content.pm.ServiceInfo");
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
Clazz.superCall (this, android.content.pm.ServiceInfo, "dumpFront", [pw, prefix]);
pw.println (prefix + "permission=" + this.permission);
}, "android.util.Printer,~S");
Clazz.overrideMethod (c$, "toString", 
function () {
return "ServiceInfo{ " + this.name + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, parcelableFlags) {
Clazz.superCall (this, android.content.pm.ServiceInfo, "writeToParcel", [dest, parcelableFlags]);
dest.writeString (this.permission);
}, "android.os.Parcel,~N");
Clazz.makeConstructor (c$, 
($fz = function (source) {
Clazz.superConstructor (this, android.content.pm.ServiceInfo, []);
this.permission = source.readString ();
}, $fz.isPrivate = true, $fz), "android.os.Parcel");
c$.$ServiceInfo$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content.pm, "ServiceInfo$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (source) {
return  new android.content.pm.ServiceInfo (source);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.content.pm.ServiceInfo$1") ? 0 : android.content.pm.ServiceInfo.$ServiceInfo$1$ ()), Clazz.innerTypeInstance (android.content.pm.ServiceInfo$1, this, null));
});
