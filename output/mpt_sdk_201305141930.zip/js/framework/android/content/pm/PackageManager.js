﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.content.pm.IntentResolver", "android.util.AndroidException", "java.util.HashMap"], "android.content.pm.PackageManager", ["android.app.ActivityThread", "android.content.ComponentName", "$.Context", "android.content.pm.ActivityInfo", "$.PackageInfo", "$.PackageParser", "$.ResolveInfo", "android.content.res.Resources", "android.util.DisplayMetrics", "$.Log", "$.LogPrinter", "java.lang.RuntimeException", "$.StringBuilder", "java.lang.ref.WeakReference", "java.util.ArrayList", "$.Collections"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mProviders = null;
this.mProvidersByComponent = null;
this.sStringCache = null;
if (!Clazz.isClassDefined ("android.content.pm.PackageManager.ActivityIntentResolver")) {
android.content.pm.PackageManager.$PackageManager$ActivityIntentResolver$ ();
}
if (!Clazz.isClassDefined ("android.content.pm.PackageManager.ServiceIntentResolver")) {
android.content.pm.PackageManager.$PackageManager$ServiceIntentResolver$ ();
}
this.mActivities = null;
this.mServices = null;
this.mPackages = null;
this.mInstrumentation = null;
this.mReceivers = null;
Clazz.instantialize (this, arguments);
}, android.content.pm, "PackageManager");
Clazz.prepareFields (c$, function () {
this.mProviders =  new java.util.HashMap ();
this.mProvidersByComponent =  new java.util.HashMap ();
this.sStringCache =  new java.util.HashMap ();
this.mActivities = Clazz.innerTypeInstance (android.content.pm.PackageManager.ActivityIntentResolver, this, null);
this.mServices = Clazz.innerTypeInstance (android.content.pm.PackageManager.ServiceIntentResolver, this, null);
this.mPackages =  new java.util.HashMap ();
this.mInstrumentation =  new java.util.HashMap ();
this.mReceivers = Clazz.innerTypeInstance (android.content.pm.PackageManager.ActivityIntentResolver, this, null);
});
Clazz.makeConstructor (c$, 
function () {
var appsDir = "bin/apps/";
var apps =  new java.util.ArrayList ();
try{
var xmlhttp;
if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else  {// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.open("GET", appsDir, false);
//xmlhttp.overrideMimeType("text/plain; charset=x-user-defined");
xmlhttp.send();
var operationsHTML = xmlhttp.responseText;
//console.log(operationsHTML);
// FIXME: hack, works for Chromium only! On other browsers this will be access denied.
//
//	http://code.google.com/p/chromium/issues/detail?id=20450
//
// The responseText looks like if get from local file system
// <script>addRow("..","..",1,"4.0 kB","4/9/12 1:58:58 PM");</script>
// <script>addRow("com.intel.jsdroid.account","com.intel.jsdroid.account",1,"4.0 kB","4/25/12 12:14:30 AM");</script>
// <script>addRow("com.intel.jsdroid.calculator2","com.intel.jsdroid.calculator2",1,"4.0 kB","5/3/12 1:31:17 PM");</script>
// <script>addRow("com.intel.jsdroid.sample","com.intel.jsdroid.sample",1,"4.0 kB","5/3/12 1:48:47 PM");</script>
//
// or looks like if get from remote server
//
//  <table><tr><th><img src="/icons/blank.gif" alt="[ICO]"></th><th><a href="?C=N;O=D">Name</a></th><th><a href="?C=M;O=A">Last modified</a></th><th><a href="?C=S;O=A">Size</a></th><th><a href="?C=D;O=A">Description</a></th></tr><tr><th colspan="5"><hr></th></tr>
//  <tr><td valign="top"><img src="/icons/back.gif" alt="[DIR]"></td><td><a href="/mayloon/com.intel.jsdroid/bin/">Parent Directory</a></td><td>&nbsp;</td><td align="right">  - </td><td>&nbsp;</td></tr>
//  <tr><td valign="top"><img src="/icons/folder.gif" alt="[DIR]"></td><td><a href="com.example.android.snake/">com.example.android.snake/</a></td><td align="right">13-Jul-2012 15:55  </td><td align="right">  - </td><td>&nbsp;</td></tr>
//  <tr><td valign="top"><img src="/icons/folder.gif" alt="[DIR]"></td><td><a href="com.hykwok.StockPriceViewer/">com.hykwok.StockPriceViewer/</a></td><td align="right">13-Jul-2012 15:55  </td><td align="right">  - </td>
//
var offset = operationsHTML.indexOf('<script>addRow', 0);
if (offset != -1) {
operationsHTML = operationsHTML.substring(offset);
}
var match_results = operationsHTML.match(/"[A-z0-9]+(\.[A-z0-9]+)+(?=[\/]?")/g);
for (var i=0; i<match_results.length; i++) {
var app = match_results[i].substring(1);
if (!apps.contains(app)) {
apps.add (app);
}
}
console.log(apps.size() + " applications found.");
} catch (e){
console.log(e);
}
if (apps.isEmpty ()) {
}var blackList =  new java.util.ArrayList ();
blackList.add ("com.test");
blackList.add ("com.intel.jsdroid.sample");
blackList.add ("com.intel.jsdroid.provider.test");
blackList.add ("com.intel.llf.hellobroadcast");
blackList.add ("com.intel.jsdroid.sample.service");
blackList.add ("com.intel.jsdroid.jsMemo");
for (var appName, $appName = apps.iterator (); $appName.hasNext () && ((appName = $appName.next ()) || true);) {
if (blackList.indexOf (appName) < 0) this.installPackage (appName);
}
});
Clazz.defineMethod (c$, "getAllActivities", 
function (packageName) {
var p = this.mPackages.get (packageName);
if (p != null) {
} else {
android.util.Log.i ("PackageManager", "package not installed");
return null;
}var activities =  new Array (p.activities.size ());
for (var i = 0; i < p.activities.size (); ++i) {
activities[i] = p.activities.get (i).className;
}
return activities;
}, "~S");
Clazz.defineMethod (c$, "getLauncherActivity", 
function (packageName) {
var p = this.mPackages.get (packageName);
if (p != null) {
} else {
android.util.Log.i ("PackageManager", "package not installed");
return null;
}var findActionMain = false;
var findCategoryLaunch = false;
var activity = null;
var intentInfo = null;
for (var i = 0; i < p.activities.size (); ++i) {
activity = p.activities.get (i);
for (var j = 0; j < activity.intents.size (); ++j) {
intentInfo = activity.intents.get (j);
findActionMain = intentInfo.hasAction ("android.intent.action.MAIN");
findCategoryLaunch = intentInfo.hasCategory ("android.intent.category.LAUNCHER");
if (findActionMain == true && findCategoryLaunch == true) {
return activity.className;
} else {
findActionMain = false;
findCategoryLaunch = false;
}}
}
return null;
}, "~S");
Clazz.defineMethod (c$, "getApplicationLabel", 
function (info) {
return info.loadLabel (this);
}, "android.content.pm.ApplicationInfo");
Clazz.defineMethod (c$, "getText", 
function (packageName, resid, appInfo) {
var name =  new android.content.pm.PackageManager.ResourceName (packageName, resid);
var curAppPackageName = android.app.ActivityThread.currentApplication ().getPackageName ();
if (!curAppPackageName.equals (name.packageName)) {
return null;
}var text = this.getCachedString (name);
if (text != null) {
return text;
}if (appInfo == null) {
try {
appInfo = this.getApplicationInfo (packageName, 0);
} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
return null;
} else {
throw e;
}
}
}try {
var r = this.getResourcesForApplication (appInfo);
text = r.getText (resid);
this.putCachedString (name, text);
return text;
} catch (e$$) {
if (Clazz.instanceOf (e$$, android.content.pm.PackageManager.NameNotFoundException)) {
var e = e$$;
{
android.util.Log.w ("PackageManager", "Failure retrieving resources for" + appInfo.packageName);
}
} else if (Clazz.instanceOf (e$$, RuntimeException)) {
var e = e$$;
{
android.util.Log.w ("PackageManager", "Failure retrieving text 0x" + Integer.toHexString (resid) + " in package " + packageName, e);
}
} else {
throw e$$;
}
}
return null;
}, "~S,~N,android.content.pm.ApplicationInfo");
c$.fixProcessName = Clazz.defineMethod (c$, "fixProcessName", 
($fz = function (defProcessName, processName, uid) {
if (processName == null) {
return defProcessName;
}return processName;
}, $fz.isPrivate = true, $fz), "~S,~S,~N");
Clazz.defineMethod (c$, "installPackage", 
function (packageName) {
var pp =  new android.content.pm.PackageParser ("");
var dm =  new android.util.DisplayMetrics ();
dm.setToDefaults ();
android.util.Log.i ("PackageManager", "Trying to install " + packageName);
var newPackage = pp.parsePackage ("bin/apps/" + packageName + "/", "", dm, 0);
if (newPackage != null) {
this.mPackages.put (newPackage.packageName, newPackage);
var N = newPackage.activities.size ();
var r = null;
for (var i = 0; i < N; i++) {
var a = newPackage.activities.get (i);
a.info.processName = android.content.pm.PackageManager.fixProcessName (newPackage.applicationInfo.processName, a.info.processName, newPackage.applicationInfo.uid);
this.mActivities.addActivity (a, "activity");
if (r == null) {
r =  new StringBuilder (256);
} else {
r.append (' ');
}r.append (a.info.name);
}
if (r != null) {
}N = newPackage.instrumentation.size ();
r = null;
for (var i = 0; i < N; i++) {
var a = newPackage.instrumentation.get (i);
a.info.packageName = newPackage.applicationInfo.packageName;
a.info.sourceDir = newPackage.applicationInfo.sourceDir;
a.info.publicSourceDir = newPackage.applicationInfo.publicSourceDir;
a.info.dataDir = newPackage.applicationInfo.dataDir;
a.info.nativeLibraryDir = newPackage.applicationInfo.nativeLibraryDir;
this.mInstrumentation.put (a.getComponentName (), a);
if (r == null) {
r =  new StringBuilder (256);
} else {
r.append (' ');
}r.append (a.info.name);
}
if (r != null) {
}N = newPackage.receivers.size ();
r = null;
for (var i = 0; i < N; i++) {
var a = newPackage.receivers.get (i);
a.info.processName = android.content.pm.PackageManager.fixProcessName (newPackage.applicationInfo.processName, a.info.processName, newPackage.applicationInfo.uid);
this.mReceivers.addActivity (a, "receiver");
}
N = newPackage.services.size ();
android.util.Log.i ("PackageManager", "Number of services " + N);
r = null;
for (var i1 = 0; i1 < N; i1++) {
var s = newPackage.services.get (i1);
s.info.processName = android.content.pm.PackageManager.fixProcessName (newPackage.applicationInfo.processName, s.info.processName, newPackage.applicationInfo.uid);
this.mServices.addService (s, "service");
if (r == null) {
r =  new StringBuilder (256);
} else {
r.append (' ');
}r.append (s.info.name);
}
if (r != null) {
if (true) android.util.Log.d ("PackageManager", "  Services: " + r);
}N = newPackage.providers.size ();
r = null;
for (var i1 = 0; i1 < N; i1++) {
var p = newPackage.providers.get (i1);
p.info.processName = android.content.pm.PackageManager.fixProcessName (newPackage.applicationInfo.processName, p.info.processName, newPackage.applicationInfo.uid);
this.mProvidersByComponent.put ( new android.content.ComponentName (p.info.packageName, p.info.name), p);
p.syncable = p.info.isSyncable;
if (p.info.authority != null) {
var names = p.info.authority.$plit (";");
p.info.authority = null;
for (var j = 0; j < names.length; j++) {
if (j == 1 && p.syncable) {
p =  new android.content.pm.PackageParser.Provider (p);
p.syncable = false;
}if (!this.mProviders.containsKey (names[j])) {
this.mProviders.put (names[j], p);
if (p.info.authority == null) {
p.info.authority = names[j];
} else {
p.info.authority = p.info.authority + ";" + names[j];
}} else {
var other = this.mProviders.get (names[j]);
}}
}if (r == null) {
r =  new StringBuilder (256);
} else {
r.append (' ');
}r.append (p.info.name);
}
if (r != null) {
android.util.Log.i ("PackageManager", "  Providers: " + r);
}android.util.Log.i ("PackageManager", "successfully installed " + newPackage.packageName);
} else {
android.util.Log.e ("PackageManager", packageName + " is not installed");
}}, "~S");
Clazz.defineMethod (c$, "getPackageResources", 
function (packageName) {
return this.mPackages.get (packageName).mResource;
}, "~S");
Clazz.defineMethod (c$, "getDefaultActivityIcon", 
function () {
return android.content.res.Resources.getSystem ().getDrawable (17301651);
});
Clazz.defineMethod (c$, "getPackageInfo", 
function (packageName, flags) {
var pi = null;
var pkg = this.mPackages.get (packageName);
if (pkg != null) {
pi =  new android.content.pm.PackageInfo ();
pi.packageName = pkg.packageName;
pi.activities =  new Array (pkg.activities.size ());
for (var i = 0; i < pkg.activities.size (); ++i) {
pi.activities[i] = pkg.activities.get (i).info;
}
}return pi;
}, "~S,~N");
Clazz.defineMethod (c$, "getApplicationInfo", 
function (packageName, flags) {
var p = this.mPackages.get (packageName);
if (false) android.util.Log.v ("PackageManager", "getApplicationInfo " + packageName + ": " + p);
if (p != null) {
return android.content.pm.PackageParser.generateApplicationInfo (p, flags);
}if ("android".equals (packageName) || "system".equals (packageName)) {
}return null;
}, "~S,~N");
Clazz.defineMethod (c$, "getInstrumentationInfo", 
function (name, flags) {
var i = this.mInstrumentation.get (name);
return android.content.pm.PackageParser.generateInstrumentationInfo (i, flags);
}, "android.content.ComponentName,~N");
Clazz.defineMethod (c$, "getActivityInfo", 
function (cmpName, flags) {
var cls = cmpName.getClassName ();
var pkg = this.mPackages.get (cmpName.getPackageName ());
var activityinfo =  new android.content.pm.ActivityInfo ();
if (pkg != null) {
for (var i = 0; i < pkg.activities.size (); ++i) {
if (pkg.activities.get (i).className.equals (cls)) {
activityinfo = pkg.activities.get (i).info;
activityinfo.metaData = pkg.activities.get (i).metaData;
return activityinfo;
}}
}throw  new android.content.pm.PackageManager.NameNotFoundException ("Activity " + cls + " not found");
}, "android.content.ComponentName,~N");
Clazz.defineMethod (c$, "getServiceInfo", 
function (cmpName, flags) {
var cls = cmpName.getClassName ();
var pkg = this.mPackages.get (cmpName.getPackageName ());
if (pkg != null) {
for (var i = 0; i < pkg.services.size (); ++i) {
if (pkg.services.get (i).className.equals (cls)) {
return pkg.services.get (i).info;
}}
}throw  new android.content.pm.PackageManager.NameNotFoundException ("Service: " + cls + " not found");
}, "android.content.ComponentName,~N");
Clazz.defineMethod (c$, "getDrawable", 
function (packageName, resid, appInfo) {
var r = this.getPackageResources (packageName);
var dr = r.getDrawable (resid);
return dr;
}, "~S,~N,android.content.pm.ApplicationInfo");
Clazz.defineMethod (c$, "getXml", 
function (packageName, resid, appInfo) {
if (appInfo == null) {
try {
appInfo = this.getApplicationInfo (packageName, 0);
} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
return null;
} else {
throw e;
}
}
}try {
var r = this.getResourcesForApplication (appInfo);
return r.getXml (resid);
} catch (e$$) {
if (Clazz.instanceOf (e$$, RuntimeException)) {
var e = e$$;
{
android.util.Log.w ("PackageManager", "Failure retrieving xml 0x" + Integer.toHexString (resid) + " in package " + packageName, e);
}
} else if (Clazz.instanceOf (e$$, android.content.pm.PackageManager.NameNotFoundException)) {
var e = e$$;
{
android.util.Log.w ("PackageManager", "Failure retrieving resources for" + appInfo.packageName);
}
} else {
throw e$$;
}
}
return null;
}, "~S,~N,android.content.pm.ApplicationInfo");
Clazz.defineMethod (c$, "getResourcesForApplication", 
function (app) {
if (app.packageName.equals ("system")) {
return android.content.Context.getSystemContext ().getResources ();
}var r = android.app.ActivityThread.currentApplication ().getApplicationContext ().getResources ();
if (r != null) {
return r;
}throw  new android.content.pm.PackageManager.NameNotFoundException ("Unable to open " + app.publicSourceDir);
}, "android.content.pm.ApplicationInfo");
Clazz.defineMethod (c$, "resolveIntent", 
function (intent, resolvedType, flags) {
android.util.Log.i ("PackageManager", " resolveIntent1");
var query = this.queryIntentActivities (intent, resolvedType, flags);
android.util.Log.i ("PackageManager", " resolveIntent2");
android.util.Log.i ("PackageManager", ":" + query.size ());
return this.chooseBestActivity (intent, resolvedType, flags, query);
}, "android.content.Intent,~S,~N");
Clazz.defineMethod (c$, "resolveActivity", 
function (intent, flags) {
return this.resolveIntent (intent, null, flags);
}, "android.content.Intent,~N");
Clazz.defineMethod (c$, "resolveService", 
function (intent, resolvedType, flags) {
var query = this.queryIntentServices (intent, resolvedType, flags);
if (query != null) {
if (query.size () >= 1) {
return query.get (0);
}}return null;
}, "android.content.Intent,~S,~N");
Clazz.defineMethod (c$, "chooseBestActivity", 
($fz = function (intent, resolvedType, flags, query) {
if (query != null) {
var N = query.size ();
if (N == 1) {
return query.get (0);
} else if (N > 1) {
android.util.Log.i ("PackageManager", "impossible for now! N: " + N);
}}return null;
}, $fz.isPrivate = true, $fz), "android.content.Intent,~S,~N,java.util.List");
Clazz.defineMethod (c$, "queryIntentActivities", 
function (intent, resolvedType, flags) {
var comp = intent.getComponent ();
if (comp != null) {
var list =  new java.util.ArrayList (1);
var ai = null;
try {
ai = this.getActivityInfo (comp, flags);
} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
e.printStackTrace ();
} else {
throw e;
}
}
if (ai != null) {
var ri =  new android.content.pm.ResolveInfo ();
ri.activityInfo = ai;
list.add (ri);
}return list;
}var pkgName = intent.getPackage ();
android.util.Log.i ("PackageManager", "pkgname:" + pkgName);
if (pkgName == null) {
return this.mActivities.queryIntent (intent, resolvedType, flags);
}var pkg = this.mPackages.get (pkgName);
if (pkg != null) {
return this.mActivities.queryIntentForPackage (intent, resolvedType, flags, pkg.activities);
}return null;
}, "android.content.Intent,~S,~N");
Clazz.defineMethod (c$, "queryIntentServices", 
function (intent, resolvedType, flags) {
var comp = intent.getComponent ();
if (comp != null) {
var list =  new java.util.ArrayList (1);
var si;
try {
si = this.getServiceInfo (comp, flags);
if (si != null) {
var ri =  new android.content.pm.ResolveInfo ();
ri.serviceInfo = si;
list.add (ri);
}} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return list;
}var pkgName = intent.getPackage ();
if (pkgName == null) {
return this.mServices.queryIntent (intent, resolvedType, flags);
}var pkg = this.mPackages.get (pkgName);
if (pkg != null) {
return this.mServices.queryIntentForPackage (intent, resolvedType, flags, pkg.services);
}return null;
}, "android.content.Intent,~S,~N");
Clazz.defineMethod (c$, "queryIntentActivities", 
function (intent, flags) {
return this.queryIntentActivities (intent, null, flags);
}, "android.content.Intent,~N");
Clazz.defineMethod (c$, "resolveContentProvider", 
function (name, flags) {
var provider = this.mProviders.get (name);
return provider != null ? android.content.pm.PackageParser.generateProviderInfo (provider, flags) : null;
}, "~S,~N");
Clazz.defineMethod (c$, "getReceiverInfo", 
function (component, flags) {
{
var a = this.mReceivers.mActivities.get (component);
if (a != null) {
return android.content.pm.PackageParser.generateActivityInfo (a, flags);
}}return null;
}, "android.content.ComponentName,~N");
Clazz.defineMethod (c$, "queryIntentReceivers", 
function (intent, resolvedType, flags) {
var comp = intent.getComponent ();
if (comp != null) {
var list =  new java.util.ArrayList (1);
var ai = this.getReceiverInfo (comp, flags);
if (ai != null) {
var ri =  new android.content.pm.ResolveInfo ();
ri.activityInfo = ai;
list.add (ri);
}return list;
}var pkgName = intent.getPackage ();
if (pkgName == null) {
android.util.Log.i ("PackageManager", "pkgName null");
return this.mReceivers.queryIntent (intent, resolvedType, flags);
}var pkg = this.mPackages.get (pkgName);
if (pkg != null) {
return this.mReceivers.queryIntentForPackage (intent, resolvedType, flags, pkg.receivers);
}return null;
}, "android.content.Intent,~S,~N");
Clazz.defineMethod (c$, "queryIntentActivityOptions", 
function (caller, specifics, specificTypes, intent, resolvedType, flags) {
var resultsAction = intent.getAction ();
var results = this.queryIntentActivities (intent, resolvedType, flags | 64);
if (false) android.util.Log.v ("PackageManager", "Query " + intent + ": " + results);
var specificsPos = 0;
var N;
try {
if (specifics != null) {
for (var i = 0; i < specifics.length; i++) {
var sintent = specifics[i];
if (sintent == null) {
continue ;}if (false) android.util.Log.v ("PackageManager", "Specific #" + i + ": " + sintent);
var action = sintent.getAction ();
if (resultsAction != null && resultsAction.equals (action)) {
action = null;
}var comp = sintent.getComponent ();
var ri = null;
var ai = null;
if (comp == null) {
ri = this.resolveIntent (sintent, specificTypes != null ? specificTypes[i] : null, flags);
if (ri == null) {
continue ;}ai = ri.activityInfo;
comp =  new android.content.ComponentName (ai.applicationInfo.packageName, ai.name);
} else {
ai = this.getActivityInfo (comp, flags);
if (ai == null) {
continue ;}}if (false) android.util.Log.v ("PackageManager", "Specific #" + i + ": " + ai);
N = results.size ();
var j;
for (j = specificsPos; j < N; j++) {
var sri = results.get (j);
if ((sri.activityInfo.name.equals (comp.getClassName ()) && sri.activityInfo.applicationInfo.packageName.equals (comp.getPackageName ())) || (action != null && sri.filter.matchAction (action))) {
results.remove (j);
if (false) android.util.Log.v ("PackageManager", "Removing duplicate item from " + j + " due to specific " + specificsPos);
if (ri == null) {
ri = sri;
}j--;
N--;
}}
if (ri == null) {
ri =  new android.content.pm.ResolveInfo ();
ri.activityInfo = ai;
}results.add (specificsPos, ri);
ri.specificIndex = i;
specificsPos++;
}
}N = results.size ();
for (var i = specificsPos; i < N - 1; i++) {
var rii = results.get (i);
if (rii.filter == null) {
continue ;}var it = rii.filter.actionsIterator ();
if (it == null) {
continue ;}while (it.hasNext ()) {
var action = it.next ();
if (resultsAction != null && resultsAction.equals (action)) {
continue ;}for (var j = i + 1; j < N; j++) {
var rij = results.get (j);
if (rij.filter != null && rij.filter.hasAction (action)) {
results.remove (j);
if (false) android.util.Log.v ("PackageManager", "Removing duplicate item from " + j + " due to action " + action + " at " + i);
j--;
N--;
}}
}
if ((flags & 64) == 0) {
rii.filter = null;
}}
if (caller != null) {
N = results.size ();
for (var i = 0; i < N; i++) {
var ainfo = results.get (i).activityInfo;
if (caller.getPackageName ().equals (ainfo.applicationInfo.packageName) && caller.getClassName ().equals (ainfo.name)) {
results.remove (i);
break;
}}
}if ((flags & 64) == 0) {
N = results.size ();
for (var i = 0; i < N; i++) {
results.get (i).filter = null;
}
}if (false) android.util.Log.v ("PackageManager", "Result: " + results);
} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
throw  new RuntimeException ("Error parsing alias", e);
} else {
throw e;
}
}
return results;
}, "android.content.ComponentName,~A,~A,android.content.Intent,~S,~N");
Clazz.defineMethod (c$, "getCachedString", 
($fz = function (name) {
var wr = this.sStringCache.get (name);
if (wr != null) {
var cs = wr.get ();
if (cs != null) {
return cs;
}this.sStringCache.remove (name);
}return null;
}, $fz.isPrivate = true, $fz), "android.content.pm.PackageManager.ResourceName");
Clazz.defineMethod (c$, "putCachedString", 
($fz = function (name, cs) {
this.sStringCache.put (name,  new java.lang.ref.WeakReference (cs));
}, $fz.isPrivate = true, $fz), "android.content.pm.PackageManager.ResourceName,CharSequence");
Clazz.defineMethod (c$, "movePackage", 
function (packageName, observer, flags) {
console.log("Missing method: movePackage");
}, "~S,~O,~N");
Clazz.defineMethod (c$, "canonicalToCurrentPackageNames", 
function (names) {
console.log("Missing method: canonicalToCurrentPackageNames");
}, "~A");
Clazz.defineMethod (c$, "getSystemSharedLibraryNames", 
function () {
console.log("Missing method: getSystemSharedLibraryNames");
});
Clazz.defineMethod (c$, "getInstalledApplications", 
function (flags) {
console.log("Missing method: getInstalledApplications");
}, "~N");
Clazz.defineMethod (c$, "hasSystemFeature", 
function (name) {
console.log("Missing method: hasSystemFeature");
}, "~S");
Clazz.defineMethod (c$, "getInstallerPackageName", 
function (packageName) {
console.log("Missing method: getInstallerPackageName");
}, "~S");
Clazz.defineMethod (c$, "getPackagesForUid", 
function (uid) {
console.log("Missing method: getPackagesForUid");
}, "~N");
Clazz.defineMethod (c$, "getPackageGids", 
function (packageName) {
console.log("Missing method: getPackageGids");
}, "~S");
Clazz.defineMethod (c$, "getPreferredPackages", 
function (flags) {
console.log("Missing method: getPreferredPackages");
}, "~N");
Clazz.defineMethod (c$, "addPackageToPreferred", 
function (packageName) {
console.log("Missing method: addPackageToPreferred");
}, "~S");
Clazz.defineMethod (c$, "removePackageFromPreferred", 
function (packageName) {
console.log("Missing method: removePackageFromPreferred");
}, "~S");
Clazz.defineMethod (c$, "getApplicationEnabledSetting", 
function (packageName) {
console.log("Missing method: getApplicationEnabledSetting");
}, "~S");
Clazz.defineMethod (c$, "clearPackagePreferredActivities", 
function (packageName) {
console.log("Missing method: clearPackagePreferredActivities");
}, "~S");
Clazz.defineMethod (c$, "removePermission", 
function (name) {
console.log("Missing method: removePermission");
}, "~S");
Clazz.defineMethod (c$, "isSafeMode", 
function () {
console.log("Missing method: isSafeMode");
});
Clazz.defineMethod (c$, "getNameForUid", 
function (uid) {
console.log("Missing method: getNameForUid");
}, "~N");
Clazz.defineMethod (c$, "currentToCanonicalPackageNames", 
function (names) {
console.log("Missing method: currentToCanonicalPackageNames");
}, "~A");
Clazz.defineMethod (c$, "getInstalledPackages", 
function (flags) {
console.log("Missing method: getInstalledPackages");
}, "~N");
c$.$PackageManager$ActivityIntentResolver$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mActivities = null;
this.mFlags = 0;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageManager, "ActivityIntentResolver", android.content.pm.IntentResolver);
Clazz.prepareFields (c$, function () {
this.mActivities =  new java.util.HashMap ();
});
Clazz.defineMethod (c$, "queryIntent", 
function (a, b, c) {
this.mFlags = c ? 65536 : 0;
return Clazz.superCall (this, android.content.pm.PackageManager.ActivityIntentResolver, "queryIntent", [a, b, c]);
}, "android.content.Intent,~S,~B");
Clazz.defineMethod (c$, "queryIntent", 
function (a, b, c) {
this.mFlags = c;
return Clazz.superCall (this, android.content.pm.PackageManager.ActivityIntentResolver, "queryIntent", [a, b, (c & 65536) != 0]);
}, "android.content.Intent,~S,~N");
Clazz.defineMethod (c$, "queryIntentForPackage", 
function (a, b, c, d) {
if (d == null) {
return null;
}this.mFlags = c;
var e = (c & 65536) != 0;
var f = d.size ();
var g =  new java.util.ArrayList (f);
var h;
for (var i = 0; i < f; ++i) {
h = d.get (i).intents;
if (h != null && h.size () > 0) {
g.add (h);
}}
return Clazz.superCall (this, android.content.pm.PackageManager.ActivityIntentResolver, "queryIntentFromList", [a, b, e, g]);
}, "android.content.Intent,~S,~N,java.util.ArrayList");
Clazz.defineMethod (c$, "addActivity", 
function (a, b) {
this.mActivities.put (a.getComponentName (), a);
if (false) android.util.Log.v ("PackageManager", "  " + b + " " + (a.info.nonLocalizedLabel != null ? a.info.nonLocalizedLabel : a.info.name) + ":");
if (false) android.util.Log.v ("PackageManager", "    Class=" + a.info.name);
var c = a.intents.size ();
for (var d = 0; d < c; d++) {
var e = a.intents.get (d);
if (false) {
android.util.Log.v ("PackageManager", "    IntentFilter:");
e.dump ( new android.util.LogPrinter (2, "PackageManager"), "      ");
}if (!e.debugCheck ()) {
android.util.Log.w ("PackageManager", "==> For Activity " + a.info.name);
}this.addFilter (e);
}
}, "android.content.pm.PackageParser.Activity,~S");
Clazz.defineMethod (c$, "removeActivity", 
function (a, b) {
this.mActivities.remove (a.getComponentName ());
if (false) android.util.Log.v ("PackageManager", "  " + b + " " + (a.info.nonLocalizedLabel != null ? a.info.nonLocalizedLabel : a.info.name) + ":");
if (false) android.util.Log.v ("PackageManager", "    Class=" + a.info.name);
var c = a.intents.size ();
for (var d = 0; d < c; d++) {
var e = a.intents.get (d);
if (false) {
android.util.Log.v ("PackageManager", "    IntentFilter:");
e.dump ( new android.util.LogPrinter (2, "PackageManager"), "      ");
}this.removeFilter (e);
}
}, "android.content.pm.PackageParser.Activity,~S");
Clazz.overrideMethod (c$, "allowFilterResult", 
function (a, b) {
var c = a.activity.info;
for (var d = b.size () - 1; d >= 0; d--) {
var e = b.get (d).activityInfo;
if (e.name === c.name && e.packageName === c.packageName) {
return false;
}}
return true;
}, "android.content.pm.PackageParser.ActivityIntentInfo,java.util.List");
Clazz.overrideMethod (c$, "packageForFilter", 
function (a) {
return a.activity.owner.packageName;
}, "android.content.pm.PackageParser.ActivityIntentInfo");
Clazz.overrideMethod (c$, "newResult", 
function (a, b) {
var c = a.activity;
var d =  new android.content.pm.ResolveInfo ();
d.activityInfo = android.content.pm.PackageParser.generateActivityInfo (c, this.mFlags);
if ((this.mFlags & 64) != 0) {
d.filter = a;
}d.priority = a.getPriority ();
d.preferredOrder = c.owner.mPreferredOrder;
d.match = b;
d.isDefault = a.hasDefault;
d.labelRes = a.labelRes;
d.nonLocalizedLabel = a.nonLocalizedLabel;
d.icon = a.icon;
return d;
}, "android.content.pm.PackageParser.ActivityIntentInfo,~N");
Clazz.overrideMethod (c$, "sortResults", 
function (a) {
java.util.Collections.sort (a, android.content.pm.PackageManager.mResolvePrioritySorter);
}, "java.util.List");
Clazz.overrideMethod (c$, "dumpFilter", 
function (a, b, c) {
a.print (b);
a.print (' ');
a.print (c.activity.getComponentShortName ());
a.print (" filter ");
}, "java.io.PrintWriter,~S,android.content.pm.PackageParser.ActivityIntentInfo");
c$ = Clazz.p0p ();
};
c$.$PackageManager$ServiceIntentResolver$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mServices = null;
this.mFlags = 0;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageManager, "ServiceIntentResolver", android.content.pm.IntentResolver);
Clazz.prepareFields (c$, function () {
this.mServices =  new java.util.HashMap ();
});
Clazz.defineMethod (c$, "queryIntent", 
function (a, b, c) {
this.mFlags = c ? 65536 : 0;
return Clazz.superCall (this, android.content.pm.PackageManager.ServiceIntentResolver, "queryIntent", [a, b, c]);
}, "android.content.Intent,~S,~B");
Clazz.defineMethod (c$, "queryIntent", 
function (a, b, c) {
this.mFlags = c;
return Clazz.superCall (this, android.content.pm.PackageManager.ServiceIntentResolver, "queryIntent", [a, b, (c & 65536) != 0]);
}, "android.content.Intent,~S,~N");
Clazz.defineMethod (c$, "queryIntentForPackage", 
function (a, b, c, d) {
if (d == null) {
return null;
}this.mFlags = c;
var e = (c & 65536) != 0;
var f = d.size ();
var g =  new java.util.ArrayList (f);
var h;
for (var i = 0; i < f; ++i) {
h = d.get (i).intents;
if (h != null && h.size () > 0) {
g.add (h);
}}
return Clazz.superCall (this, android.content.pm.PackageManager.ServiceIntentResolver, "queryIntentFromList", [a, b, e, g]);
}, "android.content.Intent,~S,~N,java.util.ArrayList");
Clazz.defineMethod (c$, "addService", 
function (a, b) {
this.mServices.put (a.getComponentName (), a);
if (false) android.util.Log.v ("PackageManager", "  " + b + " " + (a.info.nonLocalizedLabel != null ? a.info.nonLocalizedLabel : a.info.name) + ":");
if (false) android.util.Log.v ("PackageManager", "    Class=" + a.info.name);
var c = a.intents.size ();
for (var d = 0; d < c; d++) {
var e = a.intents.get (d);
if (false) {
android.util.Log.v ("PackageManager", "    IntentFilter:");
e.dump ( new android.util.LogPrinter (2, "PackageManager"), "      ");
}if (!e.debugCheck ()) {
android.util.Log.w ("PackageManager", "==> For Activity " + a.info.name);
}this.addFilter (e);
}
}, "android.content.pm.PackageParser.Service,~S");
Clazz.defineMethod (c$, "removeService", 
function (a, b) {
this.mServices.remove (a.getComponentName ());
if (false) android.util.Log.v ("PackageManager", "  " + b + " " + (a.info.nonLocalizedLabel != null ? a.info.nonLocalizedLabel : a.info.name) + ":");
if (false) android.util.Log.v ("PackageManager", "    Class=" + a.info.name);
var c = a.intents.size ();
for (var d = 0; d < c; d++) {
var e = a.intents.get (d);
if (false) {
android.util.Log.v ("PackageManager", "    IntentFilter:");
e.dump ( new android.util.LogPrinter (2, "PackageManager"), "      ");
}this.removeFilter (e);
}
}, "android.content.pm.PackageParser.Service,~S");
Clazz.overrideMethod (c$, "allowFilterResult", 
function (a, b) {
var c = a.service.info;
for (var d = b.size () - 1; d >= 0; d--) {
var e = b.get (d).serviceInfo;
if (e.name === c.name && e.packageName === c.packageName) {
return false;
}}
return true;
}, "android.content.pm.PackageParser.ServiceIntentInfo,java.util.List");
Clazz.overrideMethod (c$, "packageForFilter", 
function (a) {
return a.service.owner.packageName;
}, "android.content.pm.PackageParser.ServiceIntentInfo");
Clazz.overrideMethod (c$, "newResult", 
function (a, b) {
var c = a.service;
var d =  new android.content.pm.ResolveInfo ();
d.serviceInfo = android.content.pm.PackageParser.generateServiceInfo (c, this.mFlags);
if ((this.mFlags & 64) != 0) {
d.filter = a;
}d.priority = a.getPriority ();
d.preferredOrder = c.owner.mPreferredOrder;
d.match = b;
d.isDefault = a.hasDefault;
d.labelRes = a.labelRes;
d.nonLocalizedLabel = a.nonLocalizedLabel;
d.icon = a.icon;
return d;
}, "android.content.pm.PackageParser.ServiceIntentInfo,~N");
Clazz.overrideMethod (c$, "sortResults", 
function (a) {
java.util.Collections.sort (a, android.content.pm.PackageManager.mResolvePrioritySorter);
}, "java.util.List");
Clazz.overrideMethod (c$, "dumpFilter", 
function (a, b, c) {
a.print (' ');
a.print (c.service.getComponentShortName ());
a.print (" filter ");
}, "java.io.PrintWriter,~S,android.content.pm.PackageParser.ServiceIntentInfo");
c$ = Clazz.p0p ();
};
c$.$PackageManager$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content.pm, "PackageManager$1", null, java.util.Comparator);
Clazz.overrideMethod (c$, "compare", 
function (r1, r2) {
var v1 = r1.priority;
var v2 = r2.priority;
if (v1 != v2) {
return (v1 > v2) ? -1 : 1;
}v1 = r1.preferredOrder;
v2 = r2.preferredOrder;
if (v1 != v2) {
return (v1 > v2) ? -1 : 1;
}if (r1.isDefault != r2.isDefault) {
return r1.isDefault ? -1 : 1;
}v1 = r1.match;
v2 = r2.match;
return (v1 > v2) ? -1 : ((v1 < v2) ? 1 : 0);
}, "android.content.pm.ResolveInfo,android.content.pm.ResolveInfo");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.declareType (android.content.pm.PackageManager, "NameNotFoundException", android.util.AndroidException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.pm.PackageManager.NameNotFoundException, []);
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.packageName = null;
this.iconId = 0;
Clazz.instantialize (this, arguments);
}, android.content.pm.PackageManager, "ResourceName");
Clazz.makeConstructor (c$, 
function (a, b) {
this.packageName = a;
this.iconId = b;
}, "~S,~N");
Clazz.makeConstructor (c$, 
function (a, b) {
this.construct (a.packageName, b);
}, "android.content.pm.ApplicationInfo,~N");
Clazz.makeConstructor (c$, 
function (a, b) {
this.construct (a.applicationInfo.packageName, b);
}, "android.content.pm.ComponentInfo,~N");
Clazz.makeConstructor (c$, 
function (a, b) {
this.construct (a.activityInfo.applicationInfo.packageName, b);
}, "android.content.pm.ResolveInfo,~N");
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (this === a) return true;
if (a == null || this.getClass () !== a.getClass ()) return false;
var b = a;
if (this.iconId != b.iconId) return false;
return !(this.packageName != null ? !this.packageName.equals (b.packageName) : b.packageName != null);
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
var a;
a = this.packageName.hashCode ();
a = 31 * a + this.iconId;
return a;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return "{ResourceName " + this.packageName + " / " + this.iconId + "}";
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"GET_ACTIVITIES", 0x00000001,
"GET_RECEIVERS", 0x00000002,
"GET_SERVICES", 0x00000004,
"GET_PROVIDERS", 0x00000008,
"GET_INSTRUMENTATION", 0x00000010,
"GET_INTENT_FILTERS", 0x00000020,
"GET_SIGNATURES", 0x00000040,
"GET_RESOLVED_FILTER", 0x00000040,
"GET_META_DATA", 0x00000080,
"GET_GIDS", 0x00000100,
"GET_DISABLED_COMPONENTS", 0x00000200,
"GET_SHARED_LIBRARY_FILES", 0x00000400,
"GET_URI_PERMISSION_PATTERNS", 0x00000800,
"GET_PERMISSIONS", 0x00001000,
"GET_UNINSTALLED_PACKAGES", 0x00002000,
"GET_CONFIGURATIONS", 0x00004000,
"MATCH_DEFAULT_ONLY", 0x00010000,
"PERMISSION_GRANTED", 0,
"PERMISSION_DENIED", -1,
"SIGNATURE_MATCH", 0,
"SIGNATURE_NEITHER_SIGNED", 1,
"SIGNATURE_FIRST_NOT_SIGNED", -1,
"SIGNATURE_SECOND_NOT_SIGNED", -2,
"SIGNATURE_NO_MATCH", -3,
"SIGNATURE_UNKNOWN_PACKAGE", -4,
"COMPONENT_ENABLED_STATE_DEFAULT", 0,
"COMPONENT_ENABLED_STATE_ENABLED", 1,
"COMPONENT_ENABLED_STATE_DISABLED", 2,
"INSTALL_FORWARD_LOCK", 0x00000001,
"INSTALL_REPLACE_EXISTING", 0x00000002,
"INSTALL_ALLOW_TEST", 0x00000004,
"INSTALL_EXTERNAL", 0x00000008,
"INSTALL_INTERNAL", 0x00000010,
"DONT_KILL_APP", 0x00000001,
"INSTALL_SUCCEEDED", 1,
"INSTALL_FAILED_ALREADY_EXISTS", -1,
"INSTALL_FAILED_INVALID_APK", -2,
"INSTALL_FAILED_INVALID_URI", -3,
"INSTALL_FAILED_INSUFFICIENT_STORAGE", -4,
"INSTALL_FAILED_DUPLICATE_PACKAGE", -5,
"INSTALL_FAILED_NO_SHARED_USER", -6,
"INSTALL_FAILED_UPDATE_INCOMPATIBLE", -7,
"INSTALL_FAILED_SHARED_USER_INCOMPATIBLE", -8,
"INSTALL_FAILED_MISSING_SHARED_LIBRARY", -9,
"INSTALL_FAILED_REPLACE_COULDNT_DELETE", -10,
"INSTALL_FAILED_DEXOPT", -11,
"INSTALL_FAILED_OLDER_SDK", -12,
"INSTALL_FAILED_CONFLICTING_PROVIDER", -13,
"INSTALL_FAILED_NEWER_SDK", -14,
"INSTALL_FAILED_TEST_ONLY", -15,
"INSTALL_FAILED_CPU_ABI_INCOMPATIBLE", -16,
"INSTALL_FAILED_MISSING_FEATURE", -17,
"INSTALL_FAILED_CONTAINER_ERROR", -18,
"INSTALL_FAILED_INVALID_INSTALL_LOCATION", -19,
"INSTALL_FAILED_MEDIA_UNAVAILABLE", -20,
"INSTALL_PARSE_FAILED_NOT_APK", -100,
"INSTALL_PARSE_FAILED_BAD_MANIFEST", -101,
"INSTALL_PARSE_FAILED_UNEXPECTED_EXCEPTION", -102,
"INSTALL_PARSE_FAILED_NO_CERTIFICATES", -103,
"INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES", -104,
"INSTALL_PARSE_FAILED_CERTIFICATE_ENCODING", -105,
"INSTALL_PARSE_FAILED_BAD_PACKAGE_NAME", -106,
"INSTALL_PARSE_FAILED_BAD_SHARED_USER_ID", -107,
"INSTALL_PARSE_FAILED_MANIFEST_MALFORMED", -108,
"INSTALL_PARSE_FAILED_MANIFEST_EMPTY", -109,
"INSTALL_FAILED_INTERNAL_ERROR", -110,
"UNINSTALL_SUCCEEDED", 1,
"UNINSTALL_FAILED_NOT_FOUND", -1,
"UNINSTALL_FAILED_SYSTEM", -2,
"UNINSTALL_FAILED_GENERIC_ERROR", -3,
"DONT_DELETE_DATA", 0x00000001,
"MOVE_SUCCEEDED", 1,
"MOVE_FAILED_INSUFFICIENT_STORAGE", -1,
"MOVE_FAILED_DOESNT_EXIST", -2,
"MOVE_FAILED_SYSTEM_PACKAGE", -3,
"MOVE_FAILED_FORWARD_LOCKED", -4,
"MOVE_FAILED_INVALID_LOCATION", -5,
"MOVE_FAILED_INTERNAL_ERROR", -6,
"MOVE_FAILED_OPERATION_PENDING", -7,
"MOVE_INTERNAL", 0x00000001,
"MOVE_EXTERNAL_MEDIA", 0x00000002,
"SHOW_INFO", false);
c$.mResolvePrioritySorter = c$.prototype.mResolvePrioritySorter = ((Clazz.isClassDefined ("android.content.pm.PackageManager$1") ? 0 : android.content.pm.PackageManager.$PackageManager$1$ ()), Clazz.innerTypeInstance (android.content.pm.PackageManager$1, this, null));
Clazz.defineStatics (c$,
"TAG", "PackageManager");
});
