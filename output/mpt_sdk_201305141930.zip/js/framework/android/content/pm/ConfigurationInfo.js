﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.os.Parcelable"], "android.content.pm.ConfigurationInfo", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.reqTouchScreen = 0;
this.reqKeyboardType = 0;
this.reqNavigation = 0;
this.reqInputFeatures = 0;
this.reqGlEsVersion = 0;
Clazz.instantialize (this, arguments);
}, android.content.pm, "ConfigurationInfo", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (orig) {
this.reqTouchScreen = orig.reqTouchScreen;
this.reqKeyboardType = orig.reqKeyboardType;
this.reqNavigation = orig.reqNavigation;
this.reqInputFeatures = orig.reqInputFeatures;
this.reqGlEsVersion = orig.reqGlEsVersion;
}, "android.content.pm.ConfigurationInfo");
Clazz.overrideMethod (c$, "toString", 
function () {
return "ConfigurationInfo{" + Integer.toHexString (System.identityHashCode (this)) + " touchscreen = " + this.reqTouchScreen + " inputMethod = " + this.reqKeyboardType + " navigation = " + this.reqNavigation + " reqInputFeatures = " + this.reqInputFeatures + " reqGlEsVersion = " + this.reqGlEsVersion + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (dest, parcelableFlags) {
dest.writeInt (this.reqTouchScreen);
dest.writeInt (this.reqKeyboardType);
dest.writeInt (this.reqNavigation);
dest.writeInt (this.reqInputFeatures);
dest.writeInt (this.reqGlEsVersion);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "getGlEsVersion", 
function () {
var major = ((this.reqGlEsVersion & 0xffff0000) >> 16);
var minor = this.reqGlEsVersion & 0x0000ffff;
return String.valueOf (major) + "." + String.valueOf (minor);
});
Clazz.defineStatics (c$,
"INPUT_FEATURE_HARD_KEYBOARD", 0x00000001,
"INPUT_FEATURE_FIVE_WAY_NAV", 0x00000002,
"GL_ES_VERSION_UNDEFINED", 0);
});
