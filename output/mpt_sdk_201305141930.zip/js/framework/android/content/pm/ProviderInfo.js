﻿Clazz.declarePackage ("android.content.pm");
Clazz.load (["android.content.pm.ComponentInfo"], "android.content.pm.ProviderInfo", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.TAG = "ProviderInfo";
this.authority = null;
this.readPermission = null;
this.writePermission = null;
this.grantUriPermissions = false;
this.uriPermissionPatterns = null;
this.multiprocess = false;
this.initOrder = 0;
this.isSyncable = false;
Clazz.instantialize (this, arguments);
}, android.content.pm, "ProviderInfo", android.content.pm.ComponentInfo);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.pm.ProviderInfo, []);
});
Clazz.makeConstructor (c$, 
function (orig) {
Clazz.superConstructor (this, android.content.pm.ProviderInfo, [orig]);
this.authority = orig.authority;
this.readPermission = orig.readPermission;
this.writePermission = orig.writePermission;
this.grantUriPermissions = orig.grantUriPermissions;
this.uriPermissionPatterns = orig.uriPermissionPatterns;
this.multiprocess = orig.multiprocess;
this.initOrder = orig.initOrder;
this.isSyncable = orig.isSyncable;
}, "android.content.pm.ProviderInfo");
Clazz.defineMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (out, parcelableFlags) {
Clazz.superCall (this, android.content.pm.ProviderInfo, "writeToParcel", [out, parcelableFlags]);
out.writeString (this.authority);
out.writeString (this.readPermission);
out.writeString (this.writePermission);
out.writeInt (this.grantUriPermissions ? 1 : 0);
out.writeTypedArray (this.uriPermissionPatterns, parcelableFlags);
out.writeInt (this.multiprocess ? 1 : 0);
out.writeInt (this.initOrder);
out.writeInt (this.isSyncable ? 1 : 0);
}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return "ContentProviderInfo{name=" + this.authority + " className=" + this.name + " isSyncable=" + (this.isSyncable ? "true" : "false") + "}";
});
});
