﻿Clazz.declarePackage ("android.content");
c$ = Clazz.declareInterface (android.content, "DialogInterface");
Clazz.declareInterface (android.content.DialogInterface, "OnCancelListener");
Clazz.declareInterface (android.content.DialogInterface, "OnDismissListener");
Clazz.declareInterface (android.content.DialogInterface, "OnShowListener");
Clazz.declareInterface (android.content.DialogInterface, "OnClickListener");
Clazz.declareInterface (android.content.DialogInterface, "OnMultiChoiceClickListener");
Clazz.declareInterface (android.content.DialogInterface, "OnKeyListener");
Clazz.defineStatics (c$,
"BUTTON_POSITIVE", -1,
"BUTTON_NEGATIVE", -2,
"BUTTON_NEUTRAL", -3,
"BUTTON1", -1,
"BUTTON2", -2,
"BUTTON3", -3);
