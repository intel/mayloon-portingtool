﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.os.Binder"], "android.content.BroadcastRecord", ["android.os.SystemClock", "android.util.PrintWriterPrinter", "$.TimeUtils"], function () {
c$ = Clazz.decorateAsClass (function () {
this.intent = null;
this.callerApp = null;
this.callerPackage = null;
this.callingPid = 0;
this.callingUid = 0;
this.ordered = false;
this.sticky = false;
this.initialSticky = false;
this.requiredPermission = null;
this.receivers = null;
this.dispatchTime = 0;
this.receiverTime = 0;
this.finishTime = 0;
this.resultCode = 0;
this.resultData = null;
this.resultExtras = null;
this.resultAbort = false;
this.nextReceiver = 0;
this.receiver = null;
this.state = 0;
this.anrCount = 0;
this.curFilter = null;
this.curApp = null;
this.curComponent = null;
this.curReceiver = null;
Clazz.instantialize (this, arguments);
}, android.content, "BroadcastRecord", android.os.Binder);
Clazz.defineMethod (c$, "dump", 
function (pw, prefix) {
var now = android.os.SystemClock.uptimeMillis ();
pw.print (prefix);
pw.println (this);
pw.print (prefix);
pw.println (this.intent);
if (this.sticky) {
var bundle = this.intent.getExtras ();
if (bundle != null) {
pw.print (prefix);
pw.print ("extras: ");
pw.println (bundle.toString ());
}}pw.print (prefix);
pw.print ("caller=");
pw.print (this.callerPackage);
pw.print (" ");
pw.print (this.callerApp != null ? this.callerApp.toShortString () : "null");
pw.print (" pid=");
pw.print (this.callingPid);
pw.print (" uid=");
pw.println (this.callingUid);
if (this.requiredPermission != null) {
pw.print (prefix);
pw.print ("requiredPermission=");
pw.println (this.requiredPermission);
}pw.print (prefix);
pw.print ("dispatchTime=");
android.util.TimeUtils.formatDuration (this.dispatchTime, now);
if (this.finishTime != 0) {
pw.print (" finishTime=");
android.util.TimeUtils.formatDuration (this.finishTime, now);
} else {
pw.print (" receiverTime=");
android.util.TimeUtils.formatDuration (this.receiverTime, now);
}pw.println ("");
if (this.anrCount != 0) {
pw.print (prefix);
pw.print ("anrCount=");
pw.println (this.anrCount);
}if (this.resultCode != -1 || this.resultData != null) {
pw.print (prefix);
pw.print ("resultTo=");
pw.print (" resultCode=");
pw.print (this.resultCode);
pw.print (" resultData=");
pw.println (this.resultData);
}if (this.resultExtras != null) {
pw.print (prefix);
pw.print ("resultExtras=");
pw.println (this.resultExtras);
}if (this.resultAbort || this.ordered || this.sticky || this.initialSticky) {
pw.print (prefix);
pw.print ("resultAbort=");
pw.print (this.resultAbort);
pw.print (" ordered=");
pw.print (this.ordered);
pw.print (" sticky=");
pw.print (this.sticky);
pw.print (" initialSticky=");
pw.println (this.initialSticky);
}if (this.nextReceiver != 0 || this.receiver != null) {
pw.print (prefix);
pw.print ("nextReceiver=");
pw.print (this.nextReceiver);
pw.print (" receiver=");
pw.println (this.receiver);
}if (this.curFilter != null) {
pw.print (prefix);
pw.print ("curFilter=");
pw.println (this.curFilter);
}if (this.curReceiver != null) {
pw.print (prefix);
pw.print ("curReceiver=");
pw.println (this.curReceiver);
}if (this.curApp != null) {
pw.print (prefix);
pw.print ("curApp=");
pw.println (this.curApp);
pw.print (prefix);
pw.print ("curComponent=");
pw.println ((this.curComponent != null ? this.curComponent.toShortString () : "--"));
if (this.curReceiver != null && this.curReceiver.applicationInfo != null) {
pw.print (prefix);
pw.print ("curSourceDir=");
pw.println (this.curReceiver.applicationInfo.sourceDir);
}}var stateStr = " (?)";
switch (this.state) {
case 0:
stateStr = " (IDLE)";
break;
case 1:
stateStr = " (APP_RECEIVE)";
break;
case 2:
stateStr = " (CALL_IN_RECEIVE)";
break;
case 3:
stateStr = " (CALL_DONE_RECEIVE)";
break;
}
pw.print (prefix);
pw.print ("state=");
pw.print (this.state);
pw.println (stateStr);
var N = this.receivers != null ? this.receivers.size () : 0;
var p2 = prefix + "  ";
var printer =  new android.util.PrintWriterPrinter ();
for (var i = 0; i < N; i++) {
var o = this.receivers.get (i);
pw.print (prefix);
pw.print ("Receiver #");
pw.print (i);
pw.print (": ");
pw.println (o);
if (Clazz.instanceOf (o, android.content.BroadcastFilter)) (o).dumpBrief (pw, p2);
 else if (Clazz.instanceOf (o, android.content.pm.ResolveInfo)) (o).dump (printer, p2);
}
}, "java.io.PrintWriter,~S");
Clazz.makeConstructor (c$, 
function (_intent, _callerApp, _callerPackage, _callingPid, _callingUid, _requiredPermission, _receivers, _resultCode, _resultData, _resultExtras, _serialized, _sticky, _initialSticky) {
Clazz.superConstructor (this, android.content.BroadcastRecord, []);
this.intent = _intent;
this.callerApp = _callerApp;
this.callerPackage = _callerPackage;
this.callingPid = _callingPid;
this.callingUid = _callingUid;
this.requiredPermission = _requiredPermission;
this.receivers = _receivers;
this.resultCode = _resultCode;
this.resultData = _resultData;
this.resultExtras = _resultExtras;
this.ordered = _serialized;
this.sticky = _sticky;
this.initialSticky = _initialSticky;
this.nextReceiver = 0;
this.state = 0;
}, "android.content.Intent,android.app.ProcessRecord,~S,~N,~N,~S,java.util.List,~N,~S,android.os.Bundle,~B,~B,~B");
Clazz.defineMethod (c$, "toString", 
function () {
return "BroadcastRecord{ " + this.intent.getAction () + "}";
});
Clazz.defineStatics (c$,
"IDLE", 0,
"APP_RECEIVE", 1,
"CALL_IN_RECEIVE", 2,
"CALL_DONE_RECEIVE", 3);
});
