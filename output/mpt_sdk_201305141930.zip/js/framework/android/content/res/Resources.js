﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["java.lang.RuntimeException", "android.content.res.Configuration", "android.os.Build", "android.util.DisplayMetrics", "$.SparseArray", "$.TypedValue"], "android.content.res.Resources", ["android.content.res.AssetFileDescriptor", "$.AssetManager", "$.ColorStateList", "$.PluralRules", "$.TypedArray", "android.graphics.drawable.ColorDrawable", "$.Drawable", "android.util.Log", "java.lang.ref.WeakReference"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mColorStateListCache = null;
this.mAssets = null;
this.mConfiguration = null;
this.mTmpValue = null;
this.mCachedStyledAttributes = null;
this.mLastCachedXmlBlockIndex = -1;
this.mCachedXmlBlockIds = null;
this.mCachedXmlBlocks = null;
this.mPluralRule = null;
this.mMetrics = null;
if (!Clazz.isClassDefined ("android.content.res.Resources.Theme")) {
android.content.res.Resources.$Resources$Theme$ ();
}
Clazz.instantialize (this, arguments);
}, android.content.res, "Resources");
Clazz.prepareFields (c$, function () {
this.mColorStateListCache =  new android.util.SparseArray ();
this.mConfiguration =  new android.content.res.Configuration ();
this.mTmpValue =  new android.util.TypedValue ();
this.mCachedXmlBlockIds = [0, 0, 0, 0];
this.mCachedXmlBlocks =  new Array (4);
this.mMetrics =  new android.util.DisplayMetrics ();
});
Clazz.makeConstructor (c$, 
function (assets) {
this.mAssets = assets;
this.updateConfiguration (null, null);
assets.ensureStringBlocks ();
}, "android.content.res.AssetManager");
Clazz.makeConstructor (c$, 
function (assets, metrics, config) {
this.mAssets = assets;
this.mMetrics.setToDefaults ();
this.updateConfiguration (config, metrics);
assets.ensureStringBlocks ();
}, "android.content.res.AssetManager,android.util.DisplayMetrics,android.content.res.Configuration");
Clazz.defineMethod (c$, "getLayout", 
function (id) {
return this.loadXmlResourceParser (id, "layout");
}, "~N");
Clazz.defineMethod (c$, "loadXmlResourceParser", 
function (id, type) {
var value = this.mTmpValue;
this.getValue (id, value, true);
if (value.type == 3) {
return this.loadXmlResourceParser (value.string.toString (), id, value.assetCookie, type);
}return null;
}, "~N,~S");
Clazz.defineMethod (c$, "getValue", 
function (id, outValue, resolveRefs) {
var found = this.mAssets.getResourceValue (id, outValue, resolveRefs);
if (found) {
return ;
}throw  new android.content.res.Resources.NotFoundException ("Resource ID #0x" + Integer.toHexString (id));
}, "~N,android.util.TypedValue,~B");
Clazz.defineMethod (c$, "loadXmlResourceParser", 
function (file, id, assetCookie, type) {
if (id != 0) {
try {
var num = this.mCachedXmlBlockIds.length;
for (var i = 0; i < num; i++) {
if (this.mCachedXmlBlockIds[i] == id) {
return this.mCachedXmlBlocks[i].newParser ();
}}
var block = this.mAssets.openXmlBlockAsset (assetCookie, file);
if (block != null) {
var pos = this.mLastCachedXmlBlockIndex + 1;
if (pos >= num) pos = 0;
this.mLastCachedXmlBlockIndex = pos;
var oldBlock = this.mCachedXmlBlocks[pos];
if (oldBlock != null) {
oldBlock.close ();
}this.mCachedXmlBlockIds[pos] = id;
this.mCachedXmlBlocks[pos] = block;
return block.newParser ();
}} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
e.printStackTrace ();
} else {
throw e;
}
}
}return null;
}, "~S,~N,~N,~S");
Clazz.defineMethod (c$, "obtainAttributes", 
function (set, attrs) {
var len = attrs.length;
var array = this.getCachedStyledAttributes (len);
var parser = set;
this.mAssets.retrieveAttributes (parser.mParseState, attrs, array.mData, array.mIndices);
array.mRsrcs = attrs;
array.mXml = parser;
return array;
}, "android.util.AttributeSet,~A");
Clazz.defineMethod (c$, "updateConfiguration", 
function (config, metrics) {
{
var configChanges = 0xfffffff;
if (config != null) {
configChanges = this.mConfiguration.updateFrom (config);
}if (this.mConfiguration.locale == null) {
}if (metrics != null) {
this.mMetrics.setTo (metrics);
}this.mMetrics.scaledDensity = this.mMetrics.density * this.mConfiguration.fontScale;
var locale = null;
if (this.mConfiguration.locale != null) {
locale = this.mConfiguration.locale.getLanguage ();
if (this.mConfiguration.locale.getCountry () != null) {
locale += "-" + this.mConfiguration.locale.getCountry ();
}}var width;
var height;
if (this.mMetrics.widthPixels >= this.mMetrics.heightPixels) {
width = this.mMetrics.widthPixels;
height = this.mMetrics.heightPixels;
} else {
width = this.mMetrics.heightPixels;
height = this.mMetrics.widthPixels;
}var keyboardHidden = this.mConfiguration.keyboardHidden;
if (keyboardHidden == 1 && this.mConfiguration.hardKeyboardHidden == 2) {
keyboardHidden = 3;
}this.mAssets.setConfiguration (this.mConfiguration.mcc, this.mConfiguration.mnc, locale, this.mConfiguration.orientation, this.mConfiguration.touchscreen, Math.round ((this.mMetrics.density * 160)), this.mConfiguration.keyboard, keyboardHidden, this.mConfiguration.navigation, width, height, this.mConfiguration.screenLayout, this.mConfiguration.uiMode, android.content.res.Resources.sSdkVersion);
this.mColorStateListCache.clear ();
}{
if (this.mPluralRule != null) {
this.mPluralRule = android.content.res.PluralRules.ruleForLocale (config.locale);
}}}, "android.content.res.Configuration,android.util.DisplayMetrics");
Clazz.defineMethod (c$, "getCachedStyledAttributes", 
($fz = function (len) {
var attrs = this.mCachedStyledAttributes;
if (attrs != null) {
this.mCachedStyledAttributes = null;
attrs.mLength = len;
var fullLen = len * 6;
if (attrs.mData.length >= fullLen) {
return attrs;
}attrs.mData =  Clazz.newArray (fullLen, 0);
attrs.mIndices =  Clazz.newArray (1 + len, 0);
return attrs;
}return  new android.content.res.TypedArray (this,  Clazz.newArray (len * 6, 0),  Clazz.newArray (1 + len, 0), len);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getColor", 
function (id) {
var value = this.mTmpValue;
this.getValue (id, value, true);
if (value.type >= 16 && value.type <= 31) {
return value.data;
} else if (value.type == 3) {
System.out.println ("ColorStateList not support now");
}return 0;
}, "~N");
Clazz.defineMethod (c$, "getString", 
function (id) {
var res = this.getText (id);
if (res != null) {
return res.toString ();
}return null;
}, "~N");
Clazz.defineMethod (c$, "getString", 
function (id, formatArgs) {
var raw = this.getString (id);
return String.format (this.mConfiguration.locale, raw, [formatArgs]);
}, "~N,~A");
Clazz.defineMethod (c$, "getAnimation", 
function (id) {
return this.loadXmlResourceParser (id, "anim");
}, "~N");
Clazz.defineMethod (c$, "getXml", 
function (id) {
return this.loadXmlResourceParser (id, "xml");
}, "~N");
Clazz.defineMethod (c$, "getIdentifier", 
function (name, defType, defPackage) {
try {
android.util.Log.d ("Resources", name);
return Integer.parseInt (name);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
return this.mAssets.getResourceIdentifier (name, defType, defPackage);
}, "~S,~S,~S");
Clazz.defineMethod (c$, "getText", 
function (id) {
if (id < 0) {
throw  new RuntimeException ("Resources.getText -> id is smaller than 0");
}var res = this.mAssets.getResourceText (id);
if (res != null) {
return res;
}return null;
}, "~N");
Clazz.defineMethod (c$, "getStringArray", 
function (id) {
var res = this.mAssets.getResourceStringArray (id);
if (res != null) {
return res;
}throw  new android.content.res.Resources.NotFoundException ("String array resource ID #0x" + Integer.toHexString (id));
}, "~N");
Clazz.defineMethod (c$, "getDimensionPixelSize", 
function (id) {
var value = this.mTmpValue;
this.getValue (id, value, true);
if (value.type == 5) {
return android.util.TypedValue.complexToDimensionPixelSize (value.data, this.mMetrics);
}throw  new android.content.res.Resources.NotFoundException ("Resource ID #0x" + Integer.toHexString (id) + " type #0x" + Integer.toHexString (value.type) + " is not valid");
}, "~N");
Clazz.defineMethod (c$, "getTextArray", 
function (id) {
var res = this.mAssets.getResourceTextArray (id);
if (res != null) {
return res;
}throw  new android.content.res.Resources.NotFoundException ("Text array resource ID #0x" + Integer.toHexString (id));
}, "~N");
Clazz.defineMethod (c$, "getDrawable", 
function (id) {
var value = this.mTmpValue;
this.getValue (id, value, true);
return this.loadDrawable (value, id);
}, "~N");
Clazz.defineMethod (c$, "loadDrawable", 
function (value, id) {
var dr = null;
if (value.type >= 28 && value.type <= 31) {
dr =  new android.graphics.drawable.ColorDrawable (value.data);
}if (dr == null) {
var file = value.string.toString ();
if (file.endsWith (".xml")) {
var rp = this.loadXmlResourceParser (file, id, value.assetCookie, "drawable");
try {
dr = android.graphics.drawable.Drawable.createFromXml (this, rp);
} catch (e$$) {
if (Clazz.instanceOf (e$$, org.xmlpull.v1.XmlPullParserException)) {
var e = e$$;
{
dr = null;
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var e = e$$;
{
dr = null;
}
} else {
throw e$$;
}
}
rp.close ();
} else {
try {
// If we have yeild method, we will use the browser to load the image.
// if (window.yield) {
if (false) { // Currently yield can't work well, we will never receive the onload event.
// After we have find a sync mechasim, we will replace it with our new Sync API.
dr = android.graphics.drawable.Drawable.createFromResource(this, value, file, id, null);
return dr;
}
var is = this.mAssets.openNonAsset (value.assetCookie, file, 2);
dr = android.graphics.drawable.Drawable.createFromResourceStream (this, value, is, file, null);
is.close ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
}}if (dr == null) {
android.util.Log.e ("Resources", "Can't get resource: " + value.string.toString ());
}return dr;
}, "android.util.TypedValue,~N");
Clazz.defineMethod (c$, "openRawResource", 
function (id, value) {
this.getValue (id, value, true);
try {
return this.mAssets.openNonAsset (value.assetCookie, value.string.toString (), 2);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
System.out.println ("openRawResource Exception");
return null;
} else {
throw e;
}
}
}, "~N,android.util.TypedValue");
Clazz.defineMethod (c$, "openRawResourceFd", 
function (id) {
{
var value = this.mTmpValue;
this.getValue (id, value, true);
var raw = "";
// This is safe because the app's asset path is always added secondly
raw += this.mAssets.am.mAssetPaths.array[1].path;
raw += "";
raw += value.string.toString ();
return  new android.content.res.AssetFileDescriptor (null, 0, 0, raw);
}}, "~N");
Clazz.defineMethod (c$, "openRawResource", 
function (id) {
{
return this.openRawResource (id, this.mTmpValue);
}}, "~N");
Clazz.defineMethod (c$, "loadColorStateList", 
function (value, id) {
var key = (value.assetCookie << 24) | value.data;
var csl;
if (value.type >= 28 && value.type <= 31) {
csl = android.content.res.ColorStateList.$valueOf (value.data);
return csl;
}csl = this.getCachedColorStateList (key);
if (csl != null) {
return csl;
}if (value.string == null) {
throw  new android.content.res.Resources.NotFoundException ("Resource is not a ColorStateList (color or path): " + value);
}var file = value.string.toString ();
if (file.endsWith (".xml")) {
try {
var rp = this.loadXmlResourceParser (file, id, value.assetCookie, "colorstatelist");
csl = android.content.res.ColorStateList.createFromXml (this, rp);
rp.close ();
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
var rnf =  new android.content.res.Resources.NotFoundException ("File " + file + " from color state list resource ID #0x" + Integer.toHexString (id));
rnf.initCause (e);
throw rnf;
} else {
throw e;
}
}
} else {
throw  new android.content.res.Resources.NotFoundException ("File " + file + " from drawable resource ID #0x" + Integer.toHexString (id) + ": .xml extension required");
}if (csl != null) {
{
this.mColorStateListCache.put (key,  new java.lang.ref.WeakReference (csl));
}}return csl;
}, "android.util.TypedValue,~N");
Clazz.defineMethod (c$, "getCachedColorStateList", 
($fz = function (key) {
{
var wr = this.mColorStateListCache.get (key);
if (wr != null) {
var entry = wr.get ();
if (entry != null) {
return entry;
} else {
this.mColorStateListCache.$delete (key);
}}}return null;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getResourceName", 
function (resid) {
var str = this.mAssets.getResourceName (resid);
return str;
}, "~N");
Clazz.defineMethod (c$, "getDisplayMetrics", 
function () {
return this.mMetrics;
});
c$.updateSystemConfiguration = Clazz.defineMethod (c$, "updateSystemConfiguration", 
function (config, metrics) {
if (android.content.res.Resources.mSystem != null) {
android.content.res.Resources.mSystem.updateConfiguration (config, metrics);
}}, "android.content.res.Configuration,android.util.DisplayMetrics");
c$.getSystem = Clazz.defineMethod (c$, "getSystem", 
function () {
var ret = android.content.res.Resources.mSystem;
if (ret == null) {
ret =  new android.content.res.Resources ();
($t$ = android.content.res.Resources.mSystem = ret, android.content.res.Resources.prototype.mSystem = android.content.res.Resources.mSystem, $t$);
}return ret;
});
Clazz.makeConstructor (c$, 
($fz = function () {
this.mAssets = android.content.res.AssetManager.getSystem ();
this.mConfiguration.setToDefaults ();
this.mMetrics.setToDefaults ();
this.updateConfiguration (null, null);
this.mAssets.ensureStringBlocks ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "newTheme", 
function () {
return Clazz.innerTypeInstance (android.content.res.Resources.Theme, this, null);
});
Clazz.defineMethod (c$, "getBoolean", 
function (id) {
{
var value = this.mTmpValue;
this.getValue (id, value, true);
if (value.type >= 16 && value.type <= 31) {
return value.data != 0;
}throw  new android.content.res.Resources.NotFoundException ("Resource ID #0x" + Integer.toHexString (id) + " type #0x" + Integer.toHexString (value.type) + " is not valid");
}}, "~N");
Clazz.defineMethod (c$, "getQuantityString", 
function (id, quantity) {
return this.getQuantityText (id, quantity).toString ();
}, "~N,~N");
Clazz.defineMethod (c$, "getQuantityText", 
function (id, quantity) {
var rule = this.getPluralRule ();
var res = this.mAssets.getResourceBagText (id, rule.attrForNumber (quantity));
if (res != null) {
return res;
}res = this.mAssets.getResourceBagText (id, 16777220);
if (res != null) {
return res;
}throw  new android.content.res.Resources.NotFoundException ("Plural resource ID #0x" + Integer.toHexString (id) + " quantity=" + quantity + " item=" + android.content.res.PluralRules.stringForQuantity (rule.quantityForNumber (quantity)));
}, "~N,~N");
Clazz.defineMethod (c$, "getPluralRule", 
($fz = function () {
{
if (this.mPluralRule == null) {
this.mPluralRule = android.content.res.PluralRules.ruleForLocale (this.mConfiguration.locale);
}return this.mPluralRule;
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getConfiguration", 
function () {
return this.mConfiguration;
});
Clazz.defineMethod (c$, "getAssets", 
function () {
return this.mAssets;
});
Clazz.defineMethod (c$, "getMovie", 
function (id) {
console.log("Missing method: getMovie");
}, "~N");
Clazz.defineMethod (c$, "getResourceTypeName", 
function (resid) {
console.log("Missing method: getResourceTypeName");
}, "~N");
Clazz.defineMethod (c$, "getIntArray", 
function (id) {
console.log("Missing method: getIntArray");
}, "~N");
Clazz.defineMethod (c$, "getInteger", 
function (id) {
console.log("Missing method: getInteger");
}, "~N");
Clazz.defineMethod (c$, "getDimension", 
function (id) {
console.log("Missing method: getDimension");
}, "~N");
Clazz.defineMethod (c$, "finishPreloading", 
function () {
console.log("Missing method: finishPreloading");
});
Clazz.defineMethod (c$, "getString", 
function (id, formatArgs) {
console.log("Missing method: getString");
}, "~N,~O");
Clazz.defineMethod (c$, "getResourceEntryName", 
function (resid) {
console.log("Missing method: getResourceEntryName");
}, "~N");
Clazz.defineMethod (c$, "getResourcePackageName", 
function (resid) {
console.log("Missing method: getResourcePackageName");
}, "~N");
Clazz.defineMethod (c$, "flushLayoutCache", 
function () {
console.log("Missing method: flushLayoutCache");
});
Clazz.defineMethod (c$, "getDimensionPixelOffset", 
function (id) {
console.log("Missing method: getDimensionPixelOffset");
}, "~N");
Clazz.defineMethod (c$, "getColorStateList", 
function (id) {
console.log("Missing method: getColorStateList");
}, "~N");
Clazz.defineMethod (c$, "obtainTypedArray", 
function (id) {
console.log("Missing method: obtainTypedArray");
}, "~N");
c$.$Resources$Theme$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mAssets = null;
this.mTheme = null;
Clazz.instantialize (this, arguments);
}, android.content.res.Resources, "Theme");
Clazz.defineMethod (c$, "applyStyle", 
function (a, b) {
android.content.res.AssetManager.applyThemeStyle (this.mTheme, a, b);
}, "~N,~B");
Clazz.defineMethod (c$, "setTo", 
function (a) {
android.content.res.AssetManager.copyTheme (this.mTheme, a.mTheme);
}, "android.content.res.Resources.Theme");
Clazz.defineMethod (c$, "obtainStyledAttributes", 
function (a) {
var b = a.length;
var c = this.b$["android.content.res.Resources"].getCachedStyledAttributes (b);
c.mRsrcs = a;
android.content.res.AssetManager.applyStyle (this.mTheme, 0, 0, null, a, c.mData, c.mIndices);
return c;
}, "~A");
Clazz.defineMethod (c$, "obtainStyledAttributes", 
function (a, b) {
var c = b.length;
var d = this.b$["android.content.res.Resources"].getCachedStyledAttributes (c);
d.mRsrcs = b;
android.content.res.AssetManager.applyStyle (this.mTheme, 0, a, null, b, d.mData, d.mIndices);
if (false) {
var e = d.mData;
System.out.println ("**********************************************************");
System.out.println ("**********************************************************");
System.out.println ("**********************************************************");
System.out.println ("Attributes:");
var f = "  Attrs:";
var g;
for (g = 0; g < b.length; g++) {
f = f + " 0x" + Integer.toHexString (b[g]);
}
System.out.println (f);
f = "  Found:";
var h =  new android.util.TypedValue ();
for (g = 0; g < b.length; g++) {
var i = g * 6;
h.type = e[i + 0];
h.data = e[i + 1];
h.assetCookie = e[i + 2];
h.resourceId = e[i + 3];
f = f + " 0x" + Integer.toHexString (b[g]) + "=" + h;
}
System.out.println (f);
}return d;
}, "~N,~A");
Clazz.defineMethod (c$, "obtainStyledAttributes", 
function (a, b, c, d) {
var e = b.length;
var f = this.b$["android.content.res.Resources"].getCachedStyledAttributes (e);
android.content.res.AssetManager.applyStyle (this.mTheme, c, d, a, b, f.mData, f.mIndices);
f.mRsrcs = b;
f.mXml = a;
if (false) {
var g = f.mData;
System.out.println ("Attributes:");
var h = "  Attrs:";
var i;
for (i = 0; i < a.getAttributeCount (); i++) {
h = h + " " + a.getAttributeName (i);
var j = a.getAttributeNameResource (i);
if (j != 0) {
h = h + "(0x" + Integer.toHexString (j) + ")";
}h = h + "=" + a.getAttributeValue (i);
h += "\n";
}
System.out.println (h);
h = "  Found:";
var j =  new android.util.TypedValue ();
for (i = 0; i < b.length; i++) {
var k = i * 6;
j.type = g[k + 0];
j.data = g[k + 1];
j.assetCookie = g[k + 2];
j.resourceId = g[k + 3];
h = h + " 0x" + Integer.toHexString (b[i]) + "=" + j;
h += "\n";
}
System.out.println (h);
}return f;
}, "android.util.AttributeSet,~A,~N,~N");
Clazz.defineMethod (c$, "resolveAttribute", 
function (a, b, c) {
return false;
}, "~N,android.util.TypedValue,~B");
Clazz.defineMethod (c$, "dump", 
function (a, b, c) {
}, "~N,~S,~S");
Clazz.makeConstructor (c$, 
function () {
this.mAssets = this.b$["android.content.res.Resources"].mAssets;
this.mTheme = this.mAssets.createTheme ();
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.declareType (android.content.res.Resources, "NotFoundException", RuntimeException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.res.Resources.NotFoundException, []);
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "Resources",
"DEBUG_LOAD", false,
"DEBUG_CONFIG", false);
c$.sSdkVersion = c$.prototype.sSdkVersion = android.os.Build.VERSION.SDK_INT + ("REL".equals (android.os.Build.VERSION.CODENAME) ? 0 : 1);
c$.mSync = c$.prototype.mSync =  new JavaObject ();
Clazz.defineStatics (c$,
"mSystem", null);
});
