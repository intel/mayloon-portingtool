﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["java.io.InputStream", "android.content.res.ResourceTypes", "android.util.TypedValue", "java.util.ArrayList"], "android.content.res.AssetManager", ["android.content.res.Asset", "$.ResTable", "$.ResXMLTree", "$.StringBlock", "$.XmlBlock", "android.util.Log", "$.Time", "java.lang.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.am = null;
this.mStringBlocks = null;
this.mValue = null;
if (!Clazz.isClassDefined ("android.content.res.AssetManager.AssetInputStream")) {
android.content.res.AssetManager.$AssetManager$AssetInputStream$ ();
}
Clazz.instantialize (this, arguments);
}, android.content.res, "AssetManager");
Clazz.prepareFields (c$, function () {
this.mValue =  new android.util.TypedValue ();
});
Clazz.makeConstructor (c$, 
function () {
this.init ();
android.content.res.AssetManager.ensureSystemAssets ();
});
Clazz.defineMethod (c$, "getResourceValue", 
function (ident, outValue, resolveRefs) {
var block = this.loadResourceValue (ident, outValue, resolveRefs);
if (block >= 0) {
if (outValue.type != 3) {
return true;
}outValue.string = this.mStringBlocks[block].get (outValue.data);
return true;
}return false;
}, "~N,android.util.TypedValue,~B");
Clazz.defineMethod (c$, "getResourceText", 
function (ident) {
var tmpValue = this.mValue;
var block = this.loadResourceValue (ident, tmpValue, true);
if (block >= 0) {
if (tmpValue.type == 3) {
return this.mStringBlocks[block].get (tmpValue.data);
}return tmpValue.coerceToString ();
}return null;
}, "~N");
Clazz.defineMethod (c$, "getResourceTextArray", 
function (id) {
var rawInfoArray = this.getArrayStringInfo (id);
if (rawInfoArray == null) {
throw  new NullPointerException ("AssetManager.getResourceTextArray rawInfoArray is null");
}var rawInfoArrayLen = rawInfoArray.length;
var infoArrayLen = Math.floor (rawInfoArrayLen / 2);
var block;
var index;
var retArray =  new Array (infoArrayLen);
for (var i = 0, j = 0; i < rawInfoArrayLen; i = i + 2, j++) {
block = rawInfoArray[i];
index = rawInfoArray[i + 1];
retArray[j] = index >= 0 ? this.mStringBlocks[block].get (index) : null;
}
return retArray;
}, "~N");
Clazz.defineMethod (c$, "getResourceStringArray", 
function (id) {
android.util.Log.e ("AssetManager", "getResourceStringArray is not implemented yet");
return null;
}, "~N");
Clazz.defineMethod (c$, "getArrayStringInfo", 
($fz = function (arrayResId) {
var result = null;
if (this.am == null) {
return result;
}var res = this.am.getResources (true);
var startOfBag =  new java.util.ArrayList ();
var N = res.getBagLocked (arrayResId, startOfBag, null);
if (N < 0) {
return result;
}result =  Clazz.newArray (N * 2, 0);
var value;
for (var i = 0, j = 0; i < N; i++) {
var stringIndex = -1;
var stringBlock = 0;
var bag = startOfBag.get (i);
value = bag.map.value;
stringBlock = res.resolveReference (value, bag.stringBlock, null, null, null);
if (value.dataType == 3) {
stringIndex = value.data;
}if (stringBlock == -5) {
return result;
}result[j++] = stringBlock;
result[j++] = stringIndex;
}
return result;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getPooledString", 
function (block, id) {
return this.mStringBlocks[block - 1].get (id);
}, "~N,~N");
Clazz.defineMethod (c$, "openXmlBlockAsset", 
function (cookie, fileName) {
var rt = this.openXmlAssetNative (cookie, fileName);
if (rt != null) {
var res =  new android.content.res.XmlBlock (this, rt);
return res;
}return null;
}, "~N,~S");
Clazz.defineMethod (c$, "ensureStringBlocks", 
function () {
if (this.mStringBlocks == null) {
this.makeStringBlocks (true);
}});
Clazz.defineMethod (c$, "makeStringBlocks", 
($fz = function (copyFromSystem) {
var sysNum = copyFromSystem ? android.content.res.AssetManager.sSystem.mStringBlocks.length : 0;
if (sysNum > 0) android.util.Log.i ("AssetManager", "makeStringBlocks, sysNum = " + sysNum);
var num = this.getStringBlockCount ();
this.mStringBlocks =  new Array (num);
for (var i = 0; i < num; i++) {
if (i < sysNum) {
this.mStringBlocks[i] = android.content.res.AssetManager.sSystem.mStringBlocks[i];
} else {
this.mStringBlocks[i] =  new android.content.res.StringBlock (this.getNativeStringBlock (i), true);
}}
}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "addAssetPaths", 
function (paths) {
if (paths == null) {
return null;
}var cookies =  Clazz.newArray (paths.length, 0);
for (var i = 0; i < paths.length; i++) {
cookies[i] = this.addAssetPath (paths[i]);
}
return cookies;
}, "~A");
Clazz.defineMethod (c$, "addAssetPath", 
function (path) {
if (this.am == null) return -1;
var cookie =  new java.util.ArrayList ();
cookie.add ( new Integer (0));
if (true == this.am.addAssetPath (path, cookie)) return cookie.get (0).intValue ();
return 0;
}, "~S");
Clazz.defineMethod (c$, "getResourceName", 
function (resid) {
return Integer.toString (resid, 16);
}, "~N");
Clazz.defineMethod (c$, "loadResourceValue", 
($fz = function (ident, outValue, resolve) {
if (this.am == null) return 0;
var res = this.am.getResources (false);
var value =  new android.content.res.ResourceTypes.Res_value ();
var config =  new android.content.res.ResourceTypes.ResTable_config ();
var typeSpecFlags =  new java.util.ArrayList ();
typeSpecFlags.add ( new Integer (0));
var block = res.getResource (ident, value, false, typeSpecFlags, config);
if (block == -5) {
return block;
}var ref =  new java.util.ArrayList ();
ref.add ( new Integer (ident));
if (resolve) {
block = res.resolveReference (value, block, ref, null, null);
if (block == -5) return 0;
}if (block >= 0) {
outValue.type = value.dataType;
outValue.data = value.data;
outValue.string = null;
outValue.resourceId = (ref.get (0)).intValue ();
outValue.changingConfigurations = (typeSpecFlags.get (0)).intValue ();
outValue.assetCookie = res.getTableCookie (block);
if (config != null) {
outValue.density = config.density;
}}return block;
}, $fz.isPrivate = true, $fz), "~N,android.util.TypedValue,~B");
c$.applyStyle = Clazz.defineMethod (c$, "applyStyle", 
function (theme, defStyleAttr, defStyleRes, set, attrs, outValues, outIndices) {
var res = theme.getResTable ();
var xmlParser = set != null ? (set).mParseState : null;
var config =  new android.content.res.ResourceTypes.ResTable_config ();
var value =  new android.content.res.ResourceTypes.Res_value ();
if (attrs == null || outValues == null) return false;
var NI = attrs.length;
var NV = outValues.length;
if (NV < (NI * 6)) return false;
var indices = null;
var indicesIdx = 0;
if (outIndices != null) indices = outIndices;
var defStyleBagTypeSetFlags =  new java.util.ArrayList ();
defStyleBagTypeSetFlags.add ( new Integer (0));
if (defStyleAttr != 0) {
var tmp =  new android.content.res.ResourceTypes.Res_value ();
if (theme.getAttribute (defStyleAttr, tmp, defStyleBagTypeSetFlags) >= 0) {
if (tmp.dataType == 1) {
defStyleRes = tmp.data;
}}}var style = 0;
var styleBagTypeSetFlags =  new java.util.ArrayList ();
styleBagTypeSetFlags.add ( new Integer (0));
if (xmlParser != null) {
var idx = xmlParser.indexOfStyle ();
if (idx >= 0 && xmlParser.getAttributeValue (idx, value) >= 0) {
if (value.dataType == 2) {
if (theme.getAttribute (value.data, value, styleBagTypeSetFlags) < 0) {
value.dataType = 0;
}}if (value.dataType == 1) {
style = value.data;
}}}var defStyleEnt =  new java.util.ArrayList ();
var defStyleTypeSetFlags =  new java.util.ArrayList ();
defStyleTypeSetFlags.add ( new Integer (0));
var bagOff = defStyleRes != 0 ? res.getBagLocked (defStyleRes, defStyleEnt, defStyleTypeSetFlags) : -1;
var tmp = (defStyleTypeSetFlags.get (0)).intValue () | (defStyleBagTypeSetFlags.get (0)).intValue ();
var endDefStyleEnt = defStyleEnt.size ();
var iDefStyle = 0;
var styleEnt =  new java.util.ArrayList ();
var styleTypeSetFlags =  new java.util.ArrayList ();
styleTypeSetFlags.add ( new Integer (0));
bagOff = style != 0 ? res.getBagLocked (style, styleEnt, styleTypeSetFlags) : -1;
tmp = (styleTypeSetFlags.get (0)).intValue () | (styleBagTypeSetFlags.get (0)).intValue ();
var endStyleEnt = styleEnt.size ();
var iStyle = 0;
var NX = (xmlParser != null) ? xmlParser.getAttributeCount () : 0;
var ix = 0;
var curXmlAttr = (xmlParser != null) ? xmlParser.getAttributeNameResID (ix) : 0;
var kXmlBlock = 0x10000000;
var block = 0;
var indexOutValue = 0;
var typeSetFlags =  new java.util.ArrayList ();
typeSetFlags.add ( new Integer (0));
for (var ii = 0; ii < NI; ++ii) {
var curIdent = attrs[ii];
value.dataType = 0;
value.data = 0;
typeSetFlags.set (0,  new Integer (0));
config.density = 0;
while (ix < NX && curIdent > curXmlAttr) {
ix++;
curXmlAttr = xmlParser.getAttributeNameResID (ix);
}
if (ix < NX && curIdent == curXmlAttr) {
block = kXmlBlock;
xmlParser.getAttributeValue (ix, value);
ix++;
curXmlAttr = xmlParser.getAttributeNameResID (ix);
}while (iStyle < endStyleEnt && curIdent > styleEnt.get (iStyle).map.name.ident) {
iStyle++;
}
if (iStyle < endStyleEnt && curIdent == styleEnt.get (iStyle).map.name.ident) {
if (value.dataType == 0) {
block = styleEnt.get (iStyle).stringBlock;
typeSetFlags.set (0, styleTypeSetFlags.get (0));
value.copyFrom (styleEnt.get (iStyle).map.value);
}iStyle++;
}while (iDefStyle < endDefStyleEnt && curIdent > defStyleEnt.get (iDefStyle).map.name.ident) {
iDefStyle++;
}
if (iDefStyle < endDefStyleEnt && curIdent == defStyleEnt.get (iDefStyle).map.name.ident) {
if (value.dataType == 0) {
block = defStyleEnt.get (iDefStyle).stringBlock;
typeSetFlags.set (0, defStyleTypeSetFlags.get (0));
value.copyFrom (defStyleEnt.get (iDefStyle).map.value);
}iDefStyle++;
}var resid =  new java.util.ArrayList ();
resid.add ( new Integer (0));
if (value.dataType != 0) {
var newBlock = theme.resolveAttributeReference (value, block, resid, typeSetFlags, config);
if (newBlock >= 0) block = newBlock;
} else {
var newBlock = theme.getAttribute (curIdent, value, typeSetFlags);
if (newBlock >= 0) {
newBlock = res.resolveReference (value, block, resid, typeSetFlags, config);
if (newBlock == -5) {
return false;
}if (newBlock >= 0) block = newBlock;
}}if (value.dataType == 1 && value.data == 0) {
value.dataType = 0;
}outValues[indexOutValue + 0] = value.dataType;
outValues[indexOutValue + 1] = value.data;
outValues[indexOutValue + 2] = block != kXmlBlock ? res.getTableCookie (block) : -1;
outValues[indexOutValue + 3] = (resid.get (0)).intValue ();
outValues[indexOutValue + 4] = (typeSetFlags.get (0)).intValue ();
outValues[indexOutValue + 5] = config.density;
if (indices != null && value.dataType != 0) {
indicesIdx++;
indices[indicesIdx] = ii;
}indexOutValue += 6;
}
if (indices != null) indices[0] = indicesIdx;
return true;
}, "android.content.res.ResTable.Theme,~N,~N,android.util.AttributeSet,~A,~A,~A");
Clazz.defineMethod (c$, "retrieveAttributes", 
function (xmlParser, attrs, outValues, outIndices) {
if (xmlParser == null || attrs == null || outValues == null || this.am == null) return false;
var res = this.am.getResources (false);
var config =  new android.content.res.ResourceTypes.ResTable_config ();
var value =  new android.content.res.ResourceTypes.Res_value ();
var NI = attrs.length;
var NV = outValues.length;
if (NV < NI * (6)) return false;
var NX = xmlParser.getAttributeCount ();
var ix = 0;
var curXmlAttr = xmlParser.getAttributeNameResID (ix);
var kXmlBlock = 0x10000000;
var block = 0;
var typeSetFlags =  new java.util.ArrayList ();
typeSetFlags.add ( new Integer (0));
var offset = 0;
var indicesIdx = 0;
for (var ii = 0; ii < NI; ii++) {
var curIdent = attrs[ii];
value.dataType = 0;
value.data = 0;
typeSetFlags.set (0,  new Integer (0));
while (ix < NX && curIdent > curXmlAttr) {
ix++;
curXmlAttr = xmlParser.getAttributeNameResID (ix);
}
if (ix < NX && curIdent == curXmlAttr) {
block = kXmlBlock;
xmlParser.getAttributeValue (ix, value);
ix++;
curXmlAttr = xmlParser.getAttributeNameResID (ix);
}var resid =  new java.util.ArrayList ();
resid.add ( new Integer (0));
if (value.dataType != 0) {
var newBlock = 0;
newBlock = res.resolveReference (value, block, resid, typeSetFlags, config);
if (newBlock == -5) {
return false;
}if (newBlock >= 0) block = newBlock;
}if (value.dataType == 1 && value.data == 0) {
value.dataType = 0;
}outValues[0 + offset] = value.dataType;
outValues[1 + offset] = value.data;
outValues[2 + offset] = block != kXmlBlock ? res.getTableCookie (block) : -1;
outValues[3 + offset] = (resid.get (0)).intValue ();
outValues[4 + offset] = (typeSetFlags.get (0)).intValue ();
outValues[5 + offset] = 0;
if (outIndices != null && value.dataType != 0) {
indicesIdx++;
outIndices[indicesIdx] = ii;
}offset += 6;
}
if (outIndices != null) {
outIndices[0] = indicesIdx;
}return true;
}, "android.content.res.ResXMLParser,~A,~A,~A");
Clazz.defineMethod (c$, "getStringBlockCount", 
($fz = function () {
if (this.am == null) return 0;
return this.am.getResources (false).getTableCount ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getNativeStringBlock", 
($fz = function (block) {
if (this.am == null) return null;
return this.am.getResources (false).getTableStringBlock (block);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "openXmlAssetNative", 
($fz = function (cookie, fileName) {
if (this.am == null) return null;
var a = (cookie == 0) ? this.am.openNonAsset (fileName, 3) : this.am.openNonAsset (cookie, fileName, 3);
if (a == null) return null;
var block =  new android.content.res.ResXMLTree ();
var err = block.setTo (a.getBuffer (true), 0, a.getLength (), true);
if (err != 0) {
return null;
}return block;
}, $fz.isPrivate = true, $fz), "~N,~S");
Clazz.defineMethod (c$, "init", 
($fz = function () {
this.am =  new android.content.res.AssetManager.nativeAssetManager ();
this.am.addDefaultAssets ();
}, $fz.isPrivate = true, $fz));
c$.ensureSystemAssets = Clazz.defineMethod (c$, "ensureSystemAssets", 
($fz = function () {
if (android.content.res.AssetManager.sSystem == null) {
var system =  new android.content.res.AssetManager (true);
system.addAssetPath ("res_sys/framework-res.apk_FILES/");
system.makeStringBlocks (false);
($t$ = android.content.res.AssetManager.sSystem = system, android.content.res.AssetManager.prototype.sSystem = android.content.res.AssetManager.sSystem, $t$);
}}, $fz.isPrivate = true, $fz));
Clazz.makeConstructor (c$, 
($fz = function (isSystem) {
this.init ();
}, $fz.isPrivate = true, $fz), "~B");
c$.getSystem = Clazz.defineMethod (c$, "getSystem", 
function () {
android.content.res.AssetManager.ensureSystemAssets ();
return android.content.res.AssetManager.sSystem;
});
Clazz.defineMethod (c$, "openXmlResourceParser", 
function (cookie, fileName) {
var block = this.openXmlBlockAsset (cookie, fileName);
var rp = block.newParser ();
block.close ();
return rp;
}, "~N,~S");
Clazz.defineMethod (c$, "createTheme", 
function () {
if (this.am == null) return null;
return  new android.content.res.ResTable.Theme (this.am.getResources (false));
});
c$.applyThemeStyle = Clazz.defineMethod (c$, "applyThemeStyle", 
function (mTheme, resID, force) {
mTheme.applyStyle (resID, force);
}, "android.content.res.ResTable.Theme,~N,~B");
c$.copyTheme = Clazz.defineMethod (c$, "copyTheme", 
function (dest, source) {
dest.setTo (source);
}, "android.content.res.ResTable.Theme,android.content.res.ResTable.Theme");
Clazz.defineMethod (c$, "openNonAsset", 
function (assetCookie, string, accessStreaming) {
if (this.am == null) return null;
var asset = this.am.openNonAsset (assetCookie, string, accessStreaming);
return Clazz.innerTypeInstance (android.content.res.AssetManager.AssetInputStream, this, null, asset);
}, "~N,~S,~N");
Clazz.defineMethod (c$, "getResourceBagText", 
function (ident, bagEntryId) {
{
var tmpValue = this.mValue;
var block = this.loadResourceBagValue (ident, bagEntryId, tmpValue, true);
if (block >= 0) {
if (tmpValue.type == 3) {
return this.mStringBlocks[block].get (tmpValue.data);
}return tmpValue.coerceToString ();
}}return null;
}, "~N,~N");
Clazz.defineMethod (c$, "isUpToDate", 
function () {
return true;
});
Clazz.defineMethod (c$, "setConfiguration", 
function (mcc, mnc, locale, orientation, touchscreen, density, keyboard, keyboardHidden, navigation, screenWidth, screenHeight, screenLayout, uiMode, majorVersion) {
if (this.am == null) {
return ;
}var config =  new android.content.res.ResourceTypes.ResTable_config ();
config.mcc = mcc;
config.mnc = mnc;
config.orientation = orientation;
config.touchscreen = touchscreen;
config.density = density;
config.keyboard = keyboard;
config.inputFlags = keyboardHidden;
config.navigation = navigation;
config.screenWidth = screenWidth;
config.screenHeight = screenHeight;
config.screenLayout = screenLayout;
config.uiMode = uiMode;
config.sdkVersion = majorVersion;
config.minorVersion = 0;
this.am.setConfiguration (config, locale);
}, "~N,~N,~S,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "open", 
function (fileName) {
console.log("Missing method: open");
}, "~S");
Clazz.defineMethod (c$, "getLocales", 
function () {
console.log("Missing method: getLocales");
});
Clazz.overrideMethod (c$, "finalize", 
function () {
console.log("Missing method: finalize");
});
Clazz.defineMethod (c$, "openNonAsset", 
function (fileName) {
console.log("Missing method: openNonAsset");
}, "~S");
Clazz.defineMethod (c$, "open", 
function (fileName, accessMode) {
console.log("Missing method: open");
}, "~S,~N");
Clazz.defineMethod (c$, "close", 
function () {
console.log("Missing method: close");
});
Clazz.defineMethod (c$, "openNonAsset", 
function (fileName, accessMode) {
console.log("Missing method: openNonAsset");
}, "~S,~N");
Clazz.defineMethod (c$, "list", 
function (path) {
console.log("Missing method: list");
}, "~S");
Clazz.defineMethod (c$, "openNonAsset", 
function (cookie, fileName) {
console.log("Missing method: openNonAsset");
}, "~N,~S");
c$.$AssetManager$AssetInputStream$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mAsset = null;
Clazz.instantialize (this, arguments);
}, android.content.res.AssetManager, "AssetInputStream", java.io.InputStream);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.content.res.AssetManager.AssetInputStream, []);
this.mAsset = a;
}, "android.content.res.Asset");
Clazz.defineMethod (c$, "read", 
function () {
return this.mAsset.read ();
});
Clazz.defineMethod (c$, "getAssetInt", 
function () {
return this.mAsset;
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mResources = null;
this.mLocale = null;
this.mConfig = null;
this.mAssetPaths = null;
Clazz.instantialize (this, arguments);
}, android.content.res.AssetManager, "nativeAssetManager");
Clazz.prepareFields (c$, function () {
this.mConfig =  new android.content.res.ResourceTypes.ResTable_config ();
this.mAssetPaths =  new java.util.ArrayList ();
});
Clazz.defineMethod (c$, "addDefaultAssets", 
function () {
var a = "res_sys/framework-res.apk_FILES/";
return this.addAssetPath (a, null);
});
Clazz.defineMethod (c$, "addAssetPath", 
function (a, b) {
var c =  new android.content.res.AssetManager.nativeAssetManager.asset_path ();
c.path = a;
c.type = 3;
for (var d = 0; d < this.mAssetPaths.size (); ++d) {
if (this.mAssetPaths.get (d).path.equals (c.path)) {
if (b != null) {
b.set (0,  new Integer (d + 1));
}return true;
}}
this.mAssetPaths.add (c);
if (b != null) {
b.set (0,  new Integer (this.mAssetPaths.size ()));
}return true;
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "setLocale", 
function (a) {
this.setLocaleLocked (a);
}, "~S");
Clazz.defineMethod (c$, "setLocaleLocked", 
function (a) {
if (this.mLocale != null) {
}this.mLocale = a;
this.updateResourceParamsLocked ();
}, "~S");
Clazz.defineMethod (c$, "getResources", 
function (a) {
var b = this.getResTable (a);
return b;
}, "~B");
Clazz.defineMethod (c$, "getResTable", 
function (a) {
var b = this.mResources;
if (b != null) return b;
for (var c = 0; c < this.mAssetPaths.size (); ++c) {
var d = null;
var e = null;
var f = this.mAssetPaths.get (c);
if (c == 0) {
e = android.content.res.ResTable.getSharedRes (f.path);
if (e == null) {
android.util.Log.d ("AssetManager", "load framework-res, this is the first and the last time");
e =  new android.content.res.ResTable ();
System.err.println ("System starts parsing framework-res.apk/resources.arsc at: " + android.util.Time.getCurrentTime ());
var g = this.openNonAssetInPathLocked ("resources.arsc", 3, f);
e.add (g, c + 1, false);
System.err.println ("System finishes parsing framework-res.apk/resources.arsc at: " + android.util.Time.getCurrentTime ());
android.content.res.ResTable.addShared (f.path, e);
if (b == null) b = e;
return b;
}} else {
d = this.openNonAssetInPathLocked ("resources.arsc", 3, f);
}if (d != null || e != null) {
if (b == null) {
this.mResources = b =  new android.content.res.ResTable ();
this.updateResourceParamsLocked ();
}if (e != null) b.add (e);
 else b.add (d, c + 1, false);
}}
if (b == null) this.mResources = b =  new android.content.res.ResTable ();
return b;
}, "~B");
Clazz.defineMethod (c$, "openNonAsset", 
function (a, b) {
var c = this.mAssetPaths.size ();
while (c > 0) {
var d = this.openNonAssetInPathLocked (a, b, this.mAssetPaths.get (c));
if (d != null) return d;
}
return null;
}, "~S,~N");
Clazz.defineMethod (c$, "openNonAsset", 
function (a, b, c) {
var d = a - 1;
if (d < this.mAssetPaths.size ()) {
var e = this.openNonAssetInPathLocked (b, c, this.mAssetPaths.get (d));
if (e != null) return e;
}return null;
}, "~N,~S,~N");
Clazz.defineMethod (c$, "openNonAssetInPathLocked", 
function (a, b, c) {
var d = null;
if (c.type == 3) {
var e = c.path + a;
d = this.openAssetFromFileLocked (e, b);
if (d != null) d.setAssetSource (e);
}return d;
}, "~S,~N,android.content.res.AssetManager.nativeAssetManager.asset_path");
Clazz.defineMethod (c$, "openAssetFromFileLocked", 
function (a, b) {
var c = null;
c = android.content.res.Asset.createFromFile (a, b);
return c;
}, "~S,~N");
Clazz.defineMethod (c$, "setConfiguration", 
function (a, b) {
this.mConfig = a;
if (b != null) {
this.setLocaleLocked (b);
} else if ((a.language[0]).charCodeAt (0) != 0) {
var c =  Clazz.newArray (8, '\0');
c[0] = a.language[0];
c[1] = a.language[1];
if ((a.country[0]).charCodeAt (0) != 0) {
c[2] = '_';
c[3] = a.country[0];
c[4] = a.country[1];
c[5] = String.fromCharCode ( 0);
} else {
c[3] = String.fromCharCode ( 0);
}this.setLocaleLocked (c.toString ());
} else {
this.updateResourceParamsLocked ();
}}, "android.content.res.ResourceTypes.ResTable_config,~S");
Clazz.defineMethod (c$, "updateResourceParamsLocked", 
function () {
var a = this.mResources;
if (a == null) {
return ;
}var b = this.mLocale != null ? this.mLocale.length : 0;
this.mConfig.language[0] = String.fromCharCode ( 0);
this.mConfig.language[1] = String.fromCharCode ( 0);
this.mConfig.country[0] = String.fromCharCode ( 0);
this.mConfig.country[1] = String.fromCharCode ( 0);
if (b >= 2) {
this.mConfig.language[0] = this.mLocale.charAt (0);
this.mConfig.language[1] = this.mLocale.charAt (1);
}if (b >= 5) {
this.mConfig.country[0] = this.mLocale.charAt (3);
this.mConfig.country[1] = this.mLocale.charAt (4);
}a.setParameters (this.mConfig);
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.path = null;
this.type = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.AssetManager.nativeAssetManager, "asset_path");
c$ = Clazz.p0p ();
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "AssetManager",
"ACCESS_UNKNOWN", 0,
"ACCESS_RANDOM", 1,
"ACCESS_STREAMING", 2,
"ACCESS_BUFFER", 3,
"STYLE_NUM_ENTRIES", 6,
"STYLE_TYPE", 0,
"STYLE_DATA", 1,
"STYLE_ASSET_COOKIE", 2,
"STYLE_RESOURCE_ID", 3,
"STYLE_CHANGING_CONFIGURATIONS", 4,
"STYLE_DENSITY", 5,
"sSystem", null);
});
