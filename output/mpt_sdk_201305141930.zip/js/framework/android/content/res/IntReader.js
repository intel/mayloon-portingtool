﻿Clazz.declarePackage ("android.content.res");
Clazz.load (null, "android.content.res.IntReader", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mData = null;
this.mBigEndian = false;
this.mPosition = -1;
Clazz.instantialize (this, arguments);
}, android.content.res, "IntReader");
Clazz.makeConstructor (c$, 
function (data, offset, bigEndian) {
this.reset (data, offset, bigEndian);
}, "~A,~N,~B");
Clazz.defineMethod (c$, "reset", 
function (data, offset, bigEndian) {
this.mData = data;
this.mBigEndian = bigEndian;
this.mPosition = offset;
}, "~A,~N,~B");
Clazz.defineMethod (c$, "close", 
function () {
this.reset (null, -1, false);
});
Clazz.defineMethod (c$, "getData", 
function () {
return this.mData;
});
Clazz.defineMethod (c$, "isBigEndian", 
function () {
return this.mBigEndian;
});
Clazz.defineMethod (c$, "setBigEndian", 
function (bigEndian) {
this.mBigEndian = bigEndian;
}, "~B");
Clazz.defineMethod (c$, "readByte", 
function () {
return (this.readInt (1) & 0xff);
});
Clazz.defineMethod (c$, "readShort", 
function () {
return (this.readInt (2) & 0xffff);
});
Clazz.defineMethod (c$, "readInt", 
function () {
return this.readInt (4);
});
Clazz.defineMethod (c$, "readInt", 
function (length) {
if (length < 0 || length > 4) {
throw  new IllegalArgumentException ();
}var result = 0;
if (this.mBigEndian) {
for (var i = (length - 1) * 8; i >= 0; i -= 8) {
var b = this.mData[this.mPosition];
this.mPosition += 1;
result += (b & 0xff) << i;
}
} else {
length *= 8;
for (var i = 0; i != length; i += 8) {
var b = this.mData[this.mPosition];
this.mPosition += 1;
result += (b & 0xff) << i;
}
}return result;
}, "~N");
Clazz.defineMethod (c$, "readIntArray", 
function (length) {
var array =  Clazz.newArray (length, 0);
this.readIntArray (array, 0, length);
return array;
}, "~N");
Clazz.defineMethod (c$, "readIntArray", 
function (array, offset, length) {
for (; length > 0; length -= 1) {
array[offset++] = this.readInt ();
}
}, "~A,~N,~N");
Clazz.defineMethod (c$, "readByteArray", 
function (length) {
var array =  Clazz.newArray (length, 0);
for (var i = 0; i < length; ++i) array[i] = this.mData[this.mPosition + i];

this.mPosition += length;
return array;
}, "~N");
Clazz.defineMethod (c$, "readWCharArray", 
function (length) {
var array =  Clazz.newArray (length, '\0');
var offset = 0;
for (; length > 0; length -= 1) {
array[offset++] = String.fromCharCode ((this.readInt (2) & 0xff));
}
return array;
}, "~N");
Clazz.defineMethod (c$, "skip", 
function (bytes) {
if (bytes <= 0) {
return ;
}this.mPosition += bytes;
}, "~N");
Clazz.defineMethod (c$, "skipInt", 
function () {
this.skip (4);
});
Clazz.defineMethod (c$, "getPosition", 
function () {
return this.mPosition;
});
Clazz.defineMethod (c$, "setPosition", 
function (position) {
this.mPosition = position;
}, "~N");
});
