﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["android.content.res.ResXMLParser", "$.ResStringPool"], "android.content.res.ResXMLTree", ["android.content.res.ChunkUtil", "$.IntReader", "$.ResourceTypes"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mError = -1;
this.mHeader = null;
this.mSize = 0;
this.mDataEnd = 0;
this.mStrings = null;
this.mResIds = null;
this.mNumResIds = 0;
this.mRootNode = null;
this.mRootExt = 0;
this.mRootCode = 0;
Clazz.instantialize (this, arguments);
}, android.content.res, "ResXMLTree", android.content.res.ResXMLParser);
Clazz.prepareFields (c$, function () {
this.mStrings =  new android.content.res.ResStringPool ();
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.res.ResXMLTree, []);
Clazz.superCall (this, android.content.res.ResXMLTree, "init", [this]);
this.restart ();
});
Clazz.makeConstructor (c$, 
function (data, offset, size, copyData) {
Clazz.superConstructor (this, android.content.res.ResXMLTree, []);
Clazz.superCall (this, android.content.res.ResXMLTree, "init", [this]);
this.mReader =  new android.content.res.IntReader (data, offset, false);
this.setTo (data, offset, size, copyData);
}, "~A,~N,~N,~B");
Clazz.defineMethod (c$, "setTo", 
function (data, offset, size, copyData) {
try {
this.uninit ();
if (this.mReader == null) this.mReader =  new android.content.res.IntReader (data, offset, false);
this.mEventCode = 0;
this.mReader.setPosition (offset);
var chunk =  new android.content.res.ResourceTypes.ResChunk_header (this.mReader.getData (), this.mReader.getPosition (), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt ());
android.content.res.ChunkUtil.checkType (chunk.type, 3);
this.mHeader =  new android.content.res.ResourceTypes.ResXMLTree_header (chunk);
this.mSize = this.mHeader.header.size;
if (this.mHeader.header.headerSize > this.mSize || this.mSize > size) {
this.mError = -3;
this.restart ();
return this.mError;
}this.mDataEnd = this.mHeader.header.pointer.offset + this.mSize;
this.mStrings.uninit ();
this.mRootNode = null;
this.mResIds = null;
this.mNumResIds = 0;
this.mReader.setPosition (this.mHeader.header.pointer.offset + this.mHeader.header.headerSize);
chunk =  new android.content.res.ResourceTypes.ResChunk_header (this.mReader.getData (), this.mReader.getPosition (), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt ());
var lastChunk = chunk;
while (chunk.pointer.offset < (this.mDataEnd - android.content.res.ResourceTypes.ResChunk_header.sizeof ()) && (chunk.pointer.offset < (this.mDataEnd - chunk.size))) {
var type = chunk.type;
var chunkSize = chunk.size;
if (type == 1) {
this.mStrings.setTo (data, chunk.pointer.offset, chunkSize, false);
} else if (type == 384) {
this.mReader.setPosition (chunk.pointer.offset + chunk.headerSize);
this.mNumResIds = Math.floor ((chunk.size - chunk.headerSize) / 4);
this.mResIds = this.mReader.readIntArray (this.mNumResIds);
} else if (type >= 256 && type <= 383) {
this.mCurNode =  new android.content.res.ResourceTypes.ResXMLTree_node (lastChunk, this.mReader.readInt (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()));
if (this.nextNode () == -1) {
this.mError = -3;
this.restart ();
return this.mError;
}this.mRootNode = this.mCurNode;
this.mRootExt = this.mCurExt;
this.mRootCode = this.mEventCode;
break;
} else {
System.out.println ("Skipping unknown chunk!");
}lastChunk = chunk;
this.mReader.setPosition (lastChunk.pointer.offset + lastChunk.size);
chunk =  new android.content.res.ResourceTypes.ResChunk_header (this.mReader.getData (), this.mReader.getPosition (), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt ());
}
if (this.mRootNode == null) {
System.out.println ("");
this.mError = -3;
this.restart ();
return this.mError;
}this.mError = this.mStrings.getError ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
this.restart ();
return this.mError;
}, "~A,~N,~N,~B");
Clazz.defineMethod (c$, "getError", 
function () {
return this.mError;
});
Clazz.defineMethod (c$, "uninit", 
function () {
this.mStrings.uninit ();
this.mReader = null;
this.restart ();
});
});
