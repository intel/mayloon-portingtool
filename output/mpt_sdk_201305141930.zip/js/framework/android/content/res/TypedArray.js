﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["android.util.TypedValue", "java.util.HashMap"], "android.content.res.TypedArray", ["android.util.Log", "$.MathUtils", "java.lang.ArrayIndexOutOfBoundsException", "$.Float", "$.RuntimeException", "$.UnsupportedOperationException", "java.util.Arrays"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mResources = null;
this.mXml = null;
this.mRsrcs = null;
this.mData = null;
this.mIndices = null;
this.mLength = 0;
this.mValue = null;
this.mPooledStrings = null;
Clazz.instantialize (this, arguments);
}, android.content.res, "TypedArray");
Clazz.prepareFields (c$, function () {
this.mValue =  new android.util.TypedValue ();
this.mPooledStrings =  new java.util.HashMap ();
});
Clazz.defineMethod (c$, "length", 
function () {
return this.mLength;
});
Clazz.defineMethod (c$, "getIndexCount", 
function () {
return this.mIndices[0];
});
Clazz.defineMethod (c$, "getIndex", 
function (at) {
return this.mIndices[1 + at];
}, "~N");
Clazz.defineMethod (c$, "getResourceId", 
function (index, defValue) {
index *= 6;
var data = this.mData;
if (data[index + 0] != 0) {
var resid = data[index + 3];
if (resid != 0) {
return resid;
}}return defValue;
}, "~N,~N");
Clazz.defineMethod (c$, "getText", 
function (index) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return null;
} else if (type == 3) {
return this.loadStringValueAt (index);
}var v = this.mValue;
if (this.getValueAt (index, v)) {
android.util.Log.w ("Resources", "Converting to string: " + v);
return v.coerceToString ();
}System.out.println ("Resources" + "getString of bad type: 0x" + Integer.toHexString (type));
return null;
}, "~N");
Clazz.defineMethod (c$, "getString", 
function (index) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return null;
} else if (type == 3) {
return this.loadStringValueAt (index).toString ();
}var v = this.mValue;
if (this.getValueAt (index, v)) {
android.util.Log.w ("Resources", "Converting to string: " + v);
var cs = v.coerceToString ();
return cs != null ? cs.toString () : null;
}android.util.Log.w ("Resources", "getString of bad type: 0x" + Integer.toHexString (type));
return null;
}, "~N");
Clazz.defineMethod (c$, "getBoolean", 
function (index, defValue) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return defValue;
} else if (type >= 16 && type <= 31) {
return data[index + 1] != 0;
}var v = this.mValue;
if (this.getValueAt (index, v)) {
android.util.Log.w ("Resources", "Converting to boolean: " + v);
return android.content.res.TypedArray.convertValueToBoolean (v.coerceToString (), defValue);
}android.util.Log.w ("Resources", "getBoolean of bad type: 0x" + Integer.toHexString (type));
return defValue;
}, "~N,~B");
Clazz.defineMethod (c$, "getInt", 
function (index, defValue) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return defValue;
} else if (type >= 16 && type <= 31) {
return data[index + 1];
}var v = this.mValue;
if (this.getValueAt (index, v)) {
android.util.Log.w ("Resources", "Converting to int: " + v);
return android.content.res.TypedArray.convertValueToInt (v.coerceToString (), defValue);
}android.util.Log.w ("Resources", "getInt of bad type: 0x" + Integer.toHexString (type));
return defValue;
}, "~N,~N");
Clazz.defineMethod (c$, "getFloat", 
function (index, defValue) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return defValue;
} else if (type == 4) {
return android.util.MathUtils.myIntBitsToFloat (data[index + 1]);
} else if (type >= 16 && type <= 31) {
return data[index + 1];
}var v = this.mValue;
if (this.getValueAt (index, v)) {
android.util.Log.w ("Resources", "Converting to float: " + v);
var str = v.coerceToString ();
if (str != null) {
return Float.parseFloat (str.toString ());
}}android.util.Log.w ("Resources", "getFloat of bad type: 0x" + Integer.toHexString (type));
return defValue;
}, "~N,~N");
Clazz.defineMethod (c$, "getDimension", 
function (index, defValue) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return defValue;
} else if (type == 5) {
return android.util.TypedValue.complexToDimension (data[index + 1], this.mResources.mMetrics);
}throw  new UnsupportedOperationException ("Can't convert to dimension: type=0x" + Integer.toHexString (type));
}, "~N,~N");
Clazz.defineMethod (c$, "getDimensionPixelOffset", 
function (index, defValue) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return defValue;
} else if (type == 5) {
return android.util.TypedValue.complexToDimensionPixelOffset (data[index + 1], this.mResources.mMetrics);
}throw  new UnsupportedOperationException ("Can't convert to dimension: type=0x" + Integer.toHexString (type));
}, "~N,~N");
Clazz.defineMethod (c$, "getDimensionPixelSize", 
function (index, defValue) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return defValue;
} else if (type == 5) {
return android.util.TypedValue.complexToDimensionPixelSize (data[index + 1], this.mResources.mMetrics);
}throw  new UnsupportedOperationException ("Can't convert to dimension: type=0x" + Integer.toHexString (type));
}, "~N,~N");
Clazz.defineMethod (c$, "getLayoutDimension", 
function (index, name) {
index *= 6;
if (index < 0 || index >= this.mData.length) {
throw  new ArrayIndexOutOfBoundsException ("TypedArray.getLayoutDimension param index is Out of Bounds");
}var data = this.mData;
var type = data[index + 0];
if (type >= 16 && type <= 31) {
return data[index + 1];
} else if (type == 5) {
var rValue = android.util.TypedValue.complexToDimensionPixelSize (data[index + 1], this.mResources.mMetrics);
return rValue;
}throw  new RuntimeException (": You must supply a " + name + " attribute.");
}, "~N,~S");
Clazz.defineMethod (c$, "recycle", 
function () {
{
var cached = this.mResources.mCachedStyledAttributes;
if (cached == null || cached.mData.length < this.mData.length) {
this.mXml = null;
this.mResources.mCachedStyledAttributes = this;
}}});
Clazz.defineMethod (c$, "getValueAt", 
($fz = function (index, outValue) {
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return false;
}outValue.type = type;
outValue.data = data[index + 1];
outValue.assetCookie = data[index + 2];
outValue.resourceId = data[index + 3];
outValue.changingConfigurations = data[index + 4];
outValue.density = data[index + 5];
outValue.string = (type == 3) ? this.loadStringValueAt (index) : null;
return true;
}, $fz.isPrivate = true, $fz), "~N,android.util.TypedValue");
Clazz.defineMethod (c$, "loadStringValueAt", 
($fz = function (index) {
var data = this.mData;
var cookie = data[index + 2];
if (cookie < 0) {
if (this.mXml != null) {
return this.mXml.getPooledString (data[index + 1]);
}return null;
}return this.mResources.mAssets.getPooledString (cookie, data[index + 1]);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.makeConstructor (c$, 
function (resources, data, indices, len) {
this.mResources = resources;
this.mData = data;
this.mIndices = indices;
this.mLength = len;
}, "android.content.res.Resources,~A,~A,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return java.util.Arrays.toString (this.mData);
});
Clazz.defineMethod (c$, "peekValue", 
function (index) {
var value = this.mValue;
if (this.getValueAt (index * 6, value)) {
return value;
}return null;
}, "~N");
Clazz.defineMethod (c$, "getNonResourceString", 
function (index) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 3) {
var cookie = data[index + 2];
if (cookie < 0) {
return this.mXml.getPooledString (data[index + 1]).toString ();
}}return null;
}, "~N");
Clazz.defineMethod (c$, "getNonConfigurationString", 
function (index, allowedChangingConfigs) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if ((data[index + 4] & ~allowedChangingConfigs) != 0) {
return null;
}if (type == 0) {
return null;
} else if (type == 3) {
return this.loadStringValueAt (index).toString ();
}var v = this.mValue;
if (this.getValueAt (index, v)) {
var cs = v.coerceToString ();
return cs != null ? cs.toString () : null;
}return null;
}, "~N,~N");
c$.convertValueToInt = Clazz.defineMethod (c$, "convertValueToInt", 
function (charSeq, defaultValue) {
if (null == charSeq) return defaultValue;
var nm = charSeq.toString ();
var sign = 1;
var index = 0;
var len = nm.length;
var base = 10;
if (('-').charCodeAt (0) == (nm.charAt (0)).charCodeAt (0)) {
sign = -1;
index++;
}if (('0').charCodeAt (0) == (nm.charAt (index)).charCodeAt (0)) {
if (index == (len - 1)) return 0;
var c = nm.charAt (index + 1);
if (('x').charCodeAt (0) == (c).charCodeAt (0) || ('X').charCodeAt (0) == (c).charCodeAt (0)) {
index += 2;
base = 16;
} else {
index++;
base = 8;
}} else if (('#').charCodeAt (0) == (nm.charAt (index)).charCodeAt (0)) {
index++;
base = 16;
}return Integer.parseInt (nm.substring (index), base) * sign;
}, "CharSequence,~N");
c$.convertValueToBoolean = Clazz.defineMethod (c$, "convertValueToBoolean", 
function (value, defaultValue) {
var result = false;
if (null == value) return defaultValue;
if (value.equals ("1") || value.equals ("true") || value.equals ("TRUE")) result = true;
return result;
}, "CharSequence,~B");
Clazz.defineMethod (c$, "hasValue", 
function (index) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
return type != 0;
}, "~N");
Clazz.defineMethod (c$, "getDrawable", 
function (index) {
var value = this.mValue;
if (this.getValueAt (index * 6, value)) {
if (false) {
System.out.println ("******************************************************************");
System.out.println ("Got drawable resource: type=" + value.type + " str=" + value.string + " int=0x" + Integer.toHexString (value.data) + " cookie=" + value.assetCookie);
System.out.println ("******************************************************************");
}return this.mResources.loadDrawable (value, value.resourceId);
}return null;
}, "~N");
Clazz.defineMethod (c$, "getTextArray", 
function (index) {
var value = this.mValue;
if (this.getValueAt (index * 6, value)) {
if (false) {
System.out.println ("******************************************************************");
System.out.println ("Got drawable resource: type=" + value.type + " str=" + value.string + " int=0x" + Integer.toHexString (value.data) + " cookie=" + value.assetCookie);
System.out.println ("******************************************************************");
}return this.mResources.getTextArray (value.resourceId);
}return null;
}, "~N");
Clazz.defineMethod (c$, "getColorStateList", 
function (index) {
var value = this.mValue;
if (this.getValueAt (index * 6, value)) {
return this.mResources.loadColorStateList (value, value.resourceId);
}return null;
}, "~N");
Clazz.defineMethod (c$, "getColor", 
function (index, defValue) {
index *= 6;
var data = this.mData;
var type = data[index + 0];
if (type == 0) {
return defValue;
} else if (type >= 16 && type <= 31) {
return data[index + 1];
} else if (type == 3) {
var value = this.mValue;
if (this.getValueAt (index, value)) {
var csl = this.mResources.loadColorStateList (value, value.resourceId);
return csl.getDefaultColor ();
}return defValue;
}throw  new UnsupportedOperationException ("Can't convert to color: type=0x" + Integer.toHexString (type));
}, "~N,~N");
Clazz.defineMethod (c$, "getPositionDescription", 
function () {
console.log("Missing method: getPositionDescription");
});
Clazz.defineMethod (c$, "getResources", 
function () {
console.log("Missing method: getResources");
});
});
