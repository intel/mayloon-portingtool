﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["android.content.res.Asset"], "android.content.res._FileAsset", ["android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mBuf = null;
this.mStart = 0;
this.mLength = 0;
this.mOffset = 0;
this.mFileName = null;
Clazz.instantialize (this, arguments);
}, android.content.res, "_FileAsset", android.content.res.Asset);
Clazz.overrideMethod (c$, "getBuffer", 
function (wordAligned) {
return this.mBuf;
}, "~B");
Clazz.overrideMethod (c$, "getLength", 
function () {
return this.mLength;
});
Clazz.defineMethod (c$, "openChunk", 
function (fileName, offset, length) {
var fileLength = -1;
if (android.content.res.Asset.DEBUG) System.out.println ("openChunk>>>File: " + fileName);
var xmlhttp;
if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
xmlhttp=new XMLHttpRequest();
}
else  {// code for IE6, IE5
xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
}
xmlhttp.open("GET", fileName, false);
xmlhttp.responseType = "arraybuffer";
xmlhttp.send(null);
var data = null;
if (xmlhttp.response || xmlhttp.mozResponseArrayBuffer) {
data = new Uint8Array(xmlhttp.response || xmlhttp.mozResponseArrayBuffer);
}
if (data != null) {
var fileLength = data.length;
if (length < 0) length = fileLength;
if ((offset + length) > fileLength) {
return android.util.Errors.BAD_INDEX;
}
if (length == fileLength) {
this.mBuf = data;
} else {
this.mBuf = data.subarray(offset, offset + length);
}
}
if (this.mBuf != null) {
if (android.content.res.Asset.DEBUG) android.util.Log.d ("Asset", "read: " + this.mBuf.length + " bytes");
} else {
android.util.Log.e ("Asset", "mBuf == null");
}this.mStart = offset;
this.mLength = length;
this.mFileName = fileName;
return 0;
}, "~S,~N,~N");
Clazz.defineMethod (c$, "read", 
function (buf, count) {
var actualRead = 0;
while ((this.mOffset < this.mLength) && (actualRead < count)) {
buf[actualRead] = this.mBuf[this.mOffset];
this.mOffset++;
actualRead++;
}
return actualRead;
}, "~A,~N");
Clazz.defineMethod (c$, "read", 
function () {
if (this.mOffset < this.mLength) {
this.mOffset++;
return this.mBuf[this.mOffset - 1];
} else return -1;
});
Clazz.overrideMethod (c$, "seek", 
function (offset, whence) {
switch (whence) {
case 1:
this.mOffset = offset >= this.mLength ? this.mLength - 1 : offset;
break;
case 2:
offset = this.mOffset + offset;
this.mOffset = offset >= this.mLength ? this.mLength - 1 : offset;
break;
case 3:
offset = this.mLength + offset;
this.mOffset = offset >= this.mLength ? this.mLength - 1 : offset;
break;
default:
}
return this.mOffset;
}, "~N,~N");
Clazz.defineStatics (c$,
"SEEK_SET", 1,
"SEEK_CUR", 2,
"SEEK_END", 3);
});
