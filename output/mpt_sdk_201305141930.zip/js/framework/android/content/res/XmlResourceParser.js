﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["android.util.AttributeSet", "org.xmlpull.v1.XmlPullParser"], "android.content.res.XmlResourceParser", null, function () {
Clazz.declareInterface (android.content.res, "XmlResourceParser", [org.xmlpull.v1.XmlPullParser, android.util.AttributeSet]);
});
