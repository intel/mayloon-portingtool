﻿Clazz.declarePackage ("android.content.res");
Clazz.load (null, "android.content.res.StringBlock", ["android.content.res.ResStringPool"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mNative = null;
this.mOwnsNative = false;
this.mStrings = null;
this.mStyleIDs = null;
Clazz.instantialize (this, arguments);
}, android.content.res, "StringBlock");
Clazz.makeConstructor (c$, 
function (data, useSparse) {
this.mNative = android.content.res.StringBlock.nativeCreate (data, 0, data.length);
this.mOwnsNative = true;
}, "~A,~B");
Clazz.makeConstructor (c$, 
function (data, offset, size, useSparse) {
this.mNative = android.content.res.StringBlock.nativeCreate (data, offset, size);
this.mOwnsNative = true;
}, "~A,~N,~N,~B");
Clazz.defineMethod (c$, "get", 
function (idx) {
if (this.mStrings != null) {
var res = this.mStrings[idx];
if (res != null) {
return res;
}} else {
var num = android.content.res.StringBlock.nativeGetSize (this.mNative);
this.mStrings =  new Array (num);
}var str = android.content.res.StringBlock.nativeGetString (this.mNative, idx);
var res = str;
var style = android.content.res.StringBlock.nativeGetStyle (this.mNative, idx);
if (style != null) {
if (this.mStyleIDs == null) {
this.mStyleIDs =  new android.content.res.StringBlock.StyleIDs ();
this.mStyleIDs.boldId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "b");
this.mStyleIDs.italicId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "i");
this.mStyleIDs.underlineId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "u");
this.mStyleIDs.ttId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "tt");
this.mStyleIDs.bigId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "big");
this.mStyleIDs.smallId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "small");
this.mStyleIDs.supId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "sup");
this.mStyleIDs.subId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "sub");
this.mStyleIDs.strikeId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "strike");
this.mStyleIDs.listItemId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "li");
this.mStyleIDs.marqueeId = android.content.res.StringBlock.nativeIndexOfString (this.mNative, "marquee");
}}if (this.mStrings != null) this.mStrings[idx] = res;
return res;
}, "~N");
Clazz.overrideMethod (c$, "finalize", 
function () {
if (this.mOwnsNative) {
android.content.res.StringBlock.nativeDestroy (this.mNative);
}});
Clazz.makeConstructor (c$, 
function (obj, useSparse) {
this.mNative = obj;
this.mOwnsNative = false;
}, "android.content.res.ResStringPool,~B");
c$.nativeCreate = Clazz.defineMethod (c$, "nativeCreate", 
($fz = function (data, offset, size) {
var sp = null;
try {
sp =  new android.content.res.ResStringPool (data, offset, size, true);
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return sp;
}, $fz.isPrivate = true, $fz), "~A,~N,~N");
c$.nativeGetSize = Clazz.defineMethod (c$, "nativeGetSize", 
($fz = function (obj) {
return obj.size ();
}, $fz.isPrivate = true, $fz), "android.content.res.ResStringPool");
c$.nativeGetString = Clazz.defineMethod (c$, "nativeGetString", 
($fz = function (obj, idx) {
return obj.stringAt (idx);
}, $fz.isPrivate = true, $fz), "android.content.res.ResStringPool,~N");
c$.nativeGetStyle = Clazz.defineMethod (c$, "nativeGetStyle", 
($fz = function (obj, idx) {
return null;
}, $fz.isPrivate = true, $fz), "android.content.res.ResStringPool,~N");
c$.nativeIndexOfString = Clazz.defineMethod (c$, "nativeIndexOfString", 
($fz = function (obj, str) {
return obj.indexOfString (str);
}, $fz.isPrivate = true, $fz), "android.content.res.ResStringPool,~S");
c$.nativeDestroy = Clazz.defineMethod (c$, "nativeDestroy", 
($fz = function (obj) {
obj = null;
}, $fz.isPrivate = true, $fz), "android.content.res.ResStringPool");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.boldId = 0;
this.italicId = 0;
this.underlineId = 0;
this.ttId = 0;
this.bigId = 0;
this.smallId = 0;
this.subId = 0;
this.supId = 0;
this.strikeId = 0;
this.listItemId = 0;
this.marqueeId = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.StringBlock, "StyleIDs");
c$ = Clazz.p0p ();
});
