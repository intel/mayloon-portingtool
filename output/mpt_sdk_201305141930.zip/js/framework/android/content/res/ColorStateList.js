﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["android.util.SparseArray"], "android.content.res.ColorStateList", ["android.util.ArrayUtils", "$.StateSet", "java.lang.ref.WeakReference", "java.util.Arrays", "org.xmlpull.v1.XmlPullParserException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mStateSpecs = null;
this.mColors = null;
this.mDefaultColor = 0xffff0000;
Clazz.instantialize (this, arguments);
}, android.content.res, "ColorStateList");
Clazz.makeConstructor (c$, 
($fz = function () {
}, $fz.isPrivate = true, $fz));
Clazz.makeConstructor (c$, 
function (states, colors) {
this.mStateSpecs = states;
this.mColors = colors;
if (states.length > 0) {
this.mDefaultColor = colors[0];
for (var i = 0; i < states.length; i++) {
if (states[i].length == 0) {
this.mDefaultColor = colors[i];
}}
}}, "~A,~A");
c$.$valueOf = Clazz.defineMethod (c$, "$valueOf", 
function (color) {
{
var ref = android.content.res.ColorStateList.sCache.get (color);
var csl = ref != null ? ref.get () : null;
if (csl != null) {
return csl;
}csl =  new android.content.res.ColorStateList (android.content.res.ColorStateList.EMPTY, [color]);
android.content.res.ColorStateList.sCache.put (color,  new java.lang.ref.WeakReference (csl));
return csl;
}}, "~N");
c$.createFromXml = Clazz.defineMethod (c$, "createFromXml", 
function (r, parser) {
var attrs = parser;
var type;
while ((type = parser.next ()) != 2 && type != 1) {
}
if (type != 2) {
throw  new org.xmlpull.v1.XmlPullParserException ("No start tag found");
}return android.content.res.ColorStateList.createFromXmlInner (r, parser, attrs);
}, "android.content.res.Resources,org.xmlpull.v1.XmlPullParser");
c$.createFromXmlInner = Clazz.defineMethod (c$, "createFromXmlInner", 
($fz = function (r, parser, attrs) {
var colorStateList;
var name = parser.getName ();
if (name.equals ("selector")) {
colorStateList =  new android.content.res.ColorStateList ();
} else {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": invalid drawable tag " + name);
}colorStateList.inflate (r, parser, attrs);
return colorStateList;
}, $fz.isPrivate = true, $fz), "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "withAlpha", 
function (alpha) {
var colors =  Clazz.newArray (this.mColors.length, 0);
var len = colors.length;
for (var i = 0; i < len; i++) {
colors[i] = (this.mColors[i] & 0xFFFFFF) | (alpha << 24);
}
return  new android.content.res.ColorStateList (this.mStateSpecs, colors);
}, "~N");
Clazz.defineMethod (c$, "inflate", 
($fz = function (r, parser, attrs) {
var type;
var innerDepth = parser.getDepth () + 1;
var depth;
var listAllocated = 20;
var listSize = 0;
var colorList =  Clazz.newArray (listAllocated, 0);
var stateSpecList =  Clazz.newArray (listAllocated, 0);
while ((type = parser.next ()) != 1 && ((depth = parser.getDepth ()) >= innerDepth || type != 3)) {
if (type != 2) {
continue ;}if (depth > innerDepth || !parser.getName ().equals ("item")) {
continue ;}var colorRes = 0;
var color = 0xffff0000;
var haveColor = false;
var i;
var j = 0;
var numAttrs = attrs.getAttributeCount ();
var stateSpec =  Clazz.newArray (numAttrs, 0);
for (i = 0; i < numAttrs; i++) {
var stateResId = attrs.getAttributeNameResource (i);
if (stateResId == 0) break;
if (stateResId == 16843173) {
colorRes = attrs.getAttributeResourceValue (i, 0);
if (colorRes == 0) {
color = attrs.getAttributeIntValue (i, color);
haveColor = true;
}} else {
stateSpec[j++] = attrs.getAttributeBooleanValue (i, false) ? stateResId : -stateResId;
}}
stateSpec = android.util.StateSet.trimStateSet (stateSpec, j);
if (colorRes != 0) {
color = r.getColor (colorRes);
} else if (!haveColor) {
throw  new org.xmlpull.v1.XmlPullParserException (parser.getPositionDescription () + ": <item> tag requires a 'android:color' attribute.");
}if (listSize == 0 || stateSpec.length == 0) {
this.mDefaultColor = color;
}if (listSize + 1 >= listAllocated) {
listAllocated = android.util.ArrayUtils.idealIntArraySize (listSize + 1);
var ncolor =  Clazz.newArray (listAllocated, 0);
System.arraycopy (colorList, 0, ncolor, 0, listSize);
var nstate =  Clazz.newArray (listAllocated, 0);
System.arraycopy (stateSpecList, 0, nstate, 0, listSize);
colorList = ncolor;
stateSpecList = nstate;
}colorList[listSize] = color;
stateSpecList[listSize] = stateSpec;
listSize++;
}
this.mColors =  Clazz.newArray (listSize, 0);
this.mStateSpecs =  Clazz.newArray (listSize, 0);
System.arraycopy (colorList, 0, this.mColors, 0, listSize);
System.arraycopy (stateSpecList, 0, this.mStateSpecs, 0, listSize);
}, $fz.isPrivate = true, $fz), "android.content.res.Resources,org.xmlpull.v1.XmlPullParser,android.util.AttributeSet");
Clazz.defineMethod (c$, "isStateful", 
function () {
return this.mStateSpecs.length > 1;
});
Clazz.defineMethod (c$, "getColorForState", 
function (stateSet, defaultColor) {
var setLength = this.mStateSpecs.length;
for (var i = 0; i < setLength; i++) {
var stateSpec = this.mStateSpecs[i];
if (android.util.StateSet.stateSetMatches (stateSpec, stateSet)) {
return this.mColors[i];
}}
return defaultColor;
}, "~A,~N");
Clazz.defineMethod (c$, "getDefaultColor", 
function () {
return this.mDefaultColor;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return "ColorStateList{mStateSpecs=" + java.util.Arrays.deepToString (this.mStateSpecs) + "mColors=" + java.util.Arrays.toString (this.mColors) + "mDefaultColor=" + this.mDefaultColor + '}';
});
Clazz.defineMethod (c$, "describeContents", 
function () {
console.log("Missing method: describeContents");
});
Clazz.defineStatics (c$,
"EMPTY", [ Clazz.newArray (0, 0)]);
c$.sCache = c$.prototype.sCache =  new android.util.SparseArray ();
});
