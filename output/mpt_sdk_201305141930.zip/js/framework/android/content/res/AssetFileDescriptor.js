﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["android.os.ParcelFileDescriptor", "$.Parcelable", "android.os.Parcelable.Creator"], "android.content.res.AssetFileDescriptor", ["java.io.IOException", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFd = null;
this.mStartOffset = 0;
this.mLength = 0;
this.mRealPath = null;
Clazz.instantialize (this, arguments);
}, android.content.res, "AssetFileDescriptor", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function (fd, startOffset, length) {
if (length < 0 && startOffset != 0) {
throw  new IllegalArgumentException ("startOffset must be 0 when using UNKNOWN_LENGTH");
}this.mFd = fd;
this.mStartOffset = startOffset;
this.mLength = length;
}, "android.os.ParcelFileDescriptor,~N,~N");
Clazz.makeConstructor (c$, 
function (fd, startOffset, length, realPath) {
if (length < 0 && startOffset != 0) {
throw  new IllegalArgumentException ("startOffset must be 0 when using UNKNOWN_LENGTH");
}this.mFd = fd;
this.mStartOffset = startOffset;
this.mLength = length;
this.mRealPath = realPath;
}, "android.os.ParcelFileDescriptor,~N,~N,~S");
Clazz.defineMethod (c$, "getParcelFileDescriptor", 
function () {
return this.mFd;
});
Clazz.defineMethod (c$, "getFileDescriptor", 
function () {
return this.mFd.getFileDescriptor ();
});
Clazz.defineMethod (c$, "getRealPath", 
function () {
return this.mRealPath;
});
Clazz.defineMethod (c$, "getStartOffset", 
function () {
return this.mStartOffset;
});
Clazz.defineMethod (c$, "getLength", 
function () {
if (this.mLength >= 0) {
return this.mLength;
}var len = this.mFd.getStatSize ();
return len >= 0 ? len : -1;
});
Clazz.defineMethod (c$, "getDeclaredLength", 
function () {
return this.mLength;
});
Clazz.defineMethod (c$, "close", 
function () {
this.mFd.close ();
});
Clazz.defineMethod (c$, "createInputStream", 
function () {
if (this.mLength < 0) {
return  new android.os.ParcelFileDescriptor.AutoCloseInputStream (this.mFd);
}return  new android.content.res.AssetFileDescriptor.AutoCloseInputStream (this);
});
Clazz.defineMethod (c$, "createOutputStream", 
function () {
if (this.mLength < 0) {
return  new android.os.ParcelFileDescriptor.AutoCloseOutputStream (this.mFd);
}return  new android.content.res.AssetFileDescriptor.AutoCloseOutputStream (this);
});
Clazz.overrideMethod (c$, "toString", 
function () {
return "{AssetFileDescriptor: " + this.mFd + " start=" + this.mStartOffset + " len=" + this.mLength + "}";
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return this.mFd.describeContents ();
});
Clazz.defineMethod (c$, "writeToParcel", 
function (out, flags) {
this.mFd.writeToParcel (out, flags);
out.writeLong (this.mStartOffset);
out.writeLong (this.mLength);
}, "android.os.Parcel,~N");
Clazz.makeConstructor (c$, 
function (src) {
this.mFd = android.os.ParcelFileDescriptor.CREATOR.createFromParcel (src);
this.mStartOffset = src.readLong ();
this.mLength = src.readLong ();
}, "android.os.Parcel");
c$.$AssetFileDescriptor$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content.res, "AssetFileDescriptor$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
return  new android.content.res.AssetFileDescriptor ($in);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mRemaining = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.AssetFileDescriptor, "AutoCloseInputStream", android.os.ParcelFileDescriptor.AutoCloseInputStream);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, [a.getParcelFileDescriptor ()]);
Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, "skip", [a.getStartOffset ()]);
this.mRemaining = a.getLength ();
}, "android.content.res.AssetFileDescriptor");
Clazz.defineMethod (c$, "available", 
function () {
return this.mRemaining >= 0 ? (this.mRemaining < 0x7fffffff ? this.mRemaining : 0x7fffffff) : Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, "available", []);
});
Clazz.defineMethod (c$, "read", 
function () {
var a =  Clazz.newArray (1, 0);
var b = this.read (a, 0, 1);
return b == -1 ? -1 : a[0] & 0xff;
});
Clazz.defineMethod (c$, "read", 
function (a, b, c) {
if (this.mRemaining >= 0) {
if (this.mRemaining == 0) return -1;
if (c > this.mRemaining) c = this.mRemaining;
var d = Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, "read", [a, b, c]);
if (d >= 0) this.mRemaining -= d;
return d;
}return Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, "read", [a, b, c]);
}, "~A,~N,~N");
Clazz.defineMethod (c$, "read", 
function (a) {
return this.read (a, 0, a.length);
}, "~A");
Clazz.defineMethod (c$, "skip", 
function (a) {
if (this.mRemaining >= 0) {
if (this.mRemaining == 0) return -1;
if (a > this.mRemaining) a = this.mRemaining;
var b = Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, "skip", [a]);
if (b >= 0) this.mRemaining -= b;
return b;
}return Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, "skip", [a]);
}, "~N");
Clazz.defineMethod (c$, "mark", 
function (a) {
if (this.mRemaining >= 0) {
return ;
}Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, "mark", [a]);
}, "~N");
Clazz.defineMethod (c$, "markSupported", 
function () {
if (this.mRemaining >= 0) {
return false;
}return Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, "markSupported", []);
});
Clazz.defineMethod (c$, "reset", 
function () {
if (this.mRemaining >= 0) {
return ;
}Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseInputStream, "reset", []);
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mRemaining = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.AssetFileDescriptor, "AutoCloseOutputStream", android.os.ParcelFileDescriptor.AutoCloseOutputStream);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.content.res.AssetFileDescriptor.AutoCloseOutputStream, [a.getParcelFileDescriptor ()]);
if (a.getParcelFileDescriptor ().seekTo (a.getStartOffset ()) < 0) {
throw  new java.io.IOException ("Unable to seek");
}this.mRemaining = a.getLength ();
}, "android.content.res.AssetFileDescriptor");
Clazz.defineMethod (c$, "write", 
function (a, b, c) {
if (this.mRemaining >= 0) {
if (this.mRemaining == 0) return ;
if (c > this.mRemaining) c = this.mRemaining;
Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseOutputStream, "write", [a, b, c]);
this.mRemaining -= c;
return ;
}Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseOutputStream, "write", [a, b, c]);
}, "~A,~N,~N");
Clazz.defineMethod (c$, "write", 
function (a) {
if (this.mRemaining >= 0) {
if (this.mRemaining == 0) return ;
var b = a.length;
if (b > this.mRemaining) b = this.mRemaining;
Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseOutputStream, "write", [a]);
this.mRemaining -= b;
return ;
}Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseOutputStream, "write", [a]);
}, "~A");
Clazz.defineMethod (c$, "write", 
function (a) {
if (this.mRemaining >= 0) {
if (this.mRemaining == 0) return ;
Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseOutputStream, "write", [a]);
this.mRemaining--;
return ;
}Clazz.superCall (this, android.content.res.AssetFileDescriptor.AutoCloseOutputStream, "write", [a]);
}, "~N");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"UNKNOWN_LENGTH", -1);
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.content.res.AssetFileDescriptor$1") ? 0 : android.content.res.AssetFileDescriptor.$AssetFileDescriptor$1$ ()), Clazz.innerTypeInstance (android.content.res.AssetFileDescriptor$1, this, null));
});
