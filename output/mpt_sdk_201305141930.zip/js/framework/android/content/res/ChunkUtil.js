﻿Clazz.declarePackage ("android.content.res");
Clazz.load (null, "android.content.res.ChunkUtil", ["java.io.IOException"], function () {
c$ = Clazz.declareType (android.content.res, "ChunkUtil");
c$.checkType = Clazz.defineMethod (c$, "checkType", 
function (type, expectedType) {
if (type != expectedType) {
throw  new java.io.IOException ("Expected chunk of type 0x" + Integer.toHexString (expectedType) + ", read 0x" + Integer.toHexString (type) + ".");
}}, "~N,~N");
});
