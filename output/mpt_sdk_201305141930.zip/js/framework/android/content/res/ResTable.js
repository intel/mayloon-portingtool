﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["android.content.res.ResStringPool", "$.ResourceTypes", "java.util.ArrayList", "$.HashMap"], "android.content.res.ResTable", ["android.content.res.IntArray", "$.IntReader", "android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mError = -1;
this.mHeaders = null;
this.mPackageGroups = null;
this.mPackageMap = null;
this.mParams = null;
Clazz.instantialize (this, arguments);
}, android.content.res, "ResTable");
Clazz.prepareFields (c$, function () {
this.mHeaders =  new java.util.ArrayList ();
this.mPackageGroups =  new java.util.ArrayList ();
this.mPackageMap =  Clazz.newArray (256, 0);
this.mParams =  new android.content.res.ResourceTypes.ResTable_config ();
});
c$.getSharedRes = Clazz.defineMethod (c$, "getSharedRes", 
function (path) {
return android.content.res.ResTable.sharedRes.get (path);
}, "~S");
c$.addShared = Clazz.defineMethod (c$, "addShared", 
function (path, res) {
android.content.res.ResTable.sharedRes.put (path, res);
}, "~S,android.content.res.ResTable");
Clazz.makeConstructor (c$, 
function () {
for (var i = 0; i < 256; ++i) this.mPackageMap[i] = 0;

});
Clazz.makeConstructor (c$, 
function (data, offset, size, cookie, copyData) {
for (var i = 0; i < 256; ++i) this.mPackageMap[i] = 0;

}, "~A,~N,~N,~N,~B");
Clazz.defineMethod (c$, "getTableCount", 
function () {
return this.mHeaders.size ();
});
Clazz.defineMethod (c$, "getTableStringBlock", 
function (index) {
return this.mHeaders.get (index).values;
}, "~N");
Clazz.defineMethod (c$, "getTableCookie", 
function (index) {
return this.mHeaders.get (index).cookie;
}, "~N");
Clazz.defineMethod (c$, "add", 
function (inData, offset, size, cookie, copyData) {
if (inData == null) return 0;
var data = inData;
var header =  new android.content.res.ResTable.Header (this);
header.index = this.mHeaders.size ();
header.cookie = cookie;
this.mHeaders.add (header);
var curPackage = 0;
var reader =  new android.content.res.IntReader (data, offset, false);
try {
header.header =  new android.content.res.ResourceTypes.ResTable_header ( new android.content.res.ResourceTypes.ResChunk_header (data, reader.getPosition (), reader.readInt (2), reader.readInt (2), reader.readInt ()), reader.readInt ());
header.size = header.header.header.size;
android.util.Log.d ("ResTable", "Loading ResTable...");
if (header.header.header.headerSize > header.size || header.size > size) {
return (this.mError = -3);
}header.dataEnd = header.header.header.pointer.offset + header.size;
reader.setPosition (header.header.header.pointer.offset + header.header.header.headerSize);
var chunk =  new android.content.res.ResourceTypes.ResChunk_header (data, reader.getPosition (), reader.readInt (2), reader.readInt (2), reader.readInt ());
while (chunk.pointer.offset <= (header.dataEnd - android.content.res.ResourceTypes.ResChunk_header.sizeof ()) && chunk.pointer.offset <= (header.dataEnd - chunk.size)) {
var csize = chunk.size;
var ctype = chunk.type;
if (ctype == 1) {
if (header.values.getError () != 0) {
var err = header.values.setTo (data, chunk.pointer.offset, csize, false);
if (err != 0) return (this.mError = err);
} else {
System.out.println ("Multiple string chunks found in resource table.");
}} else if (ctype == 512) {
if (curPackage >= header.header.packageCount) {
System.out.println ("More package chunks were found than the " + header.header.packageCount + " declared in the header.");
return (this.mError = -3);
}if (this.parsePackage (data, chunk.pointer.offset, header) != 0) {
return this.mError;
}curPackage++;
} else {
System.out.println ("Unknown chunk type!");
}reader.setPosition (chunk.pointer.offset + chunk.size);
if (reader.getPosition () >= header.dataEnd) break;
chunk =  new android.content.res.ResourceTypes.ResChunk_header (data, reader.getPosition (), reader.readInt (2), reader.readInt (2), reader.readInt ());
}
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
if (curPackage < header.header.packageCount) {
return (this.mError = -3);
}this.mError = header.values.getError ();
if (this.mError != 0) System.out.println ("No string values found in resource table!");
return this.mError;
}, "~O,~N,~N,~N,~B");
Clazz.defineMethod (c$, "parsePackage", 
function (data, base, header) {
try {
var reader =  new android.content.res.IntReader (data, base, false);
var pkg =  new android.content.res.ResourceTypes.ResTable_package ( new android.content.res.ResourceTypes.ResChunk_header (data, reader.getPosition (), reader.readInt (2), reader.readInt (2), reader.readInt ()), reader.readInt (), reader.readWCharArray (128), reader.readInt (), reader.readInt (), reader.readInt (), reader.readInt ());
var err = 0;
var pkgSize = pkg.header.size;
if (pkg.typeStrings >= pkgSize) {
System.out.println ("ResTable_package type strings at " + pkg.typeStrings + " are past chunk size " + pkgSize);
return (this.mError = -3);
}if ((pkg.typeStrings & 0x3) != 0) {
System.out.println ("ResTable_package type strings at " + pkg.typeStrings + " is not on an integer boundary.");
return (this.mError = -3);
}if (pkg.keyStrings >= pkgSize) {
System.out.println ("ResTable_package key strings at " + pkg.keyStrings + " are past chunk size " + pkgSize);
return (this.mError = -3);
}if ((pkg.keyStrings & 0x3) != 0) {
System.out.println ("ResTable_package key strings at " + pkg.keyStrings + " is not on an integer boundary.");
return (this.mError = -3);
}var _package = null;
var group = null;
var id = pkg.id;
if (id != 0 && id < 256) {
_package =  new android.content.res.ResTable.Package (this, header, pkg);
var idx = this.mPackageMap[id];
if (idx == 0) {
idx = this.mPackageGroups.size () + 1;
group =  new android.content.res.ResTable.PackageGroup (this, pkg.name, id);
err = _package.typeStrings.setTo (data, base + pkg.typeStrings, header.dataEnd - (base + pkg.typeStrings), false);
if (err != 0) return (this.mError = err);
err = _package.keyStrings.setTo (data, base + pkg.keyStrings, header.dataEnd - (base + pkg.keyStrings), false);
if (err != 0) return (this.mError = err);
this.mPackageGroups.add (group);
group.basePackage = _package;
this.mPackageMap[id] = idx;
}if (false == group.packages.add (_package)) return (this.mError = -6);
} else {
System.out.println ("impossible here!");
return 0;
}reader.setPosition (pkg.header.pointer.offset + pkg.header.headerSize);
var chunk =  new android.content.res.ResourceTypes.ResChunk_header (data, reader.getPosition (), reader.readInt (2), reader.readInt (2), reader.readInt ());
var endPos = pkg.header.pointer.offset + pkg.header.size;
while (chunk.pointer.offset <= (endPos - android.content.res.ResourceTypes.ResChunk_header.sizeof ()) && chunk.pointer.offset <= (endPos - chunk.size)) {
var csize = chunk.size;
var ctype = chunk.type;
if (ctype == 514) {
var typeSpec =  new android.content.res.ResourceTypes.ResTable_typeSpec (chunk, reader.readInt (1), reader.readInt (1), reader.readInt (2), reader.readInt (4));
if (typeSpec.id == 0) {
System.out.println ("ResTable_type has an id of 0.");
return (this.mError = -3);
}while (_package.types.size () < typeSpec.id) {
_package.types.add (null);
}
var t = _package.types.get (typeSpec.id - 1);
if (t == null) {
t =  new android.content.res.ResTable.Type (header, _package, typeSpec.entryCount);
_package.types.set (typeSpec.id - 1, t);
} else {
System.out.println ("ResTable_typeSpec entry count inconsistent: given " + typeSpec.entryCount + ", previously " + t.entryCount);
return (this.mError = -3);
}reader.setPosition (typeSpec.header.pointer.offset + typeSpec.header.headerSize);
t.typeSpecFlags =  new android.content.res.IntArray (reader.getData (), reader.getPosition (), typeSpec.entryCount);
} else if (ctype == 513) {
var type =  new android.content.res.ResourceTypes.ResTable_type (chunk, reader.readInt (1), reader.readInt (1), reader.readInt (2), reader.readInt (), reader.readInt ());
var typeSize = type.header.size;
if (type.header.headerSize + 4 * type.entryCount > typeSize) {
System.out.println ("ResTable_type entry index to " + (type.header.headerSize + 4 * type.entryCount) + " extends beyond chunk end " + typeSize);
return (this.mError = -3);
}if (type.entryCount != 0 && type.entriesStart > (typeSize - android.content.res.ResourceTypes.ResTable_entry.sizeof ())) {
System.out.println ("ResTable_type entriesStart at " + type.entriesStart + " extends beyond chunk end " + typeSize);
return (this.mError = -3);
}if (type.id == 0) {
System.out.println ("ResTable_type has an id of 0.");
return (this.mError = -3);
}while (_package.types.size () < type.id) {
_package.types.add (null);
}
var t = _package.types.get (type.id - 1);
if (t == null) {
t =  new android.content.res.ResTable.Type (header, _package, type.entryCount);
_package.types.set (type.id - 1, t);
} else if (type.entryCount != t.entryCount) {
System.out.println ("ResTable_type entry count inconsistent: given " + type.entryCount + ", previously " + t.entryCount);
return (this.mError = -3);
}type.config = this.readConfigFlags (reader);
if ((type.config.language[0]).charCodeAt (0) == ('\00').charCodeAt (0) && (type.config.country[0]).charCodeAt (0) == ('\00').charCodeAt (0)) {
var entryOffsets =  new android.content.res.IntArray (data, reader.getPosition (), type.entryCount);
reader.setPosition (reader.getPosition () + type.entryCount * 4);
type.entryOffsets = entryOffsets;
type.resPointers =  new android.content.res.ResourceTypes.ResPointers (reader.getPosition (), data);
t.configs.add (type);
}} else {
}reader.setPosition (chunk.pointer.offset + csize);
if (reader.getPosition () >= endPos) break;
chunk =  new android.content.res.ResourceTypes.ResChunk_header (data, reader.getPosition (), reader.readInt (2), reader.readInt (2), reader.readInt ());
}
if (group.typeCount == 0) group.typeCount = _package.types.size ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return 0;
}, "~A,~N,android.content.res.ResTable.Header");
Clazz.defineMethod (c$, "readConfigFlags", 
($fz = function (mIn) {
var size = mIn.readInt ();
if (size < 28) {
System.out.println ("Config size < 28!");
return null;
}var isInvalid = false;
var mcc = mIn.readShort ();
var mnc = mIn.readShort ();
var language = [String.fromCharCode (mIn.readByte ()), String.fromCharCode (mIn.readByte ())];
var country = [String.fromCharCode (mIn.readByte ()), String.fromCharCode (mIn.readByte ())];
var orientation = mIn.readByte ();
var touchscreen = mIn.readByte ();
var density = mIn.readShort ();
var keyboard = mIn.readByte ();
var navigation = mIn.readByte ();
var inputFlags = mIn.readByte ();
mIn.skip (1);
var screenWidth = mIn.readShort ();
var screenHeight = mIn.readShort ();
var sdkVersion = mIn.readShort ();
mIn.skip (2);
var screenLayout = 0;
var uiMode = 0;
var smallestScreenWidthDp = 0;
if (size >= 32) {
screenLayout = mIn.readByte ();
uiMode = mIn.readByte ();
smallestScreenWidthDp = mIn.readShort ();
}var screenWidthDp = 0;
var screenHeightDp = 0;
if (size >= 36) {
screenWidthDp = mIn.readShort ();
screenHeightDp = mIn.readShort ();
}var exceedingSize = size - 36;
if (exceedingSize > 0) {
System.out.println ("Impossible ?!");
}return  new android.content.res.ResourceTypes.ResTable_config (mcc, mnc, language, country, orientation, touchscreen, density, keyboard, navigation, inputFlags, screenWidth, screenHeight, sdkVersion, screenLayout, uiMode, smallestScreenWidthDp, screenWidthDp, screenHeightDp, isInvalid);
}, $fz.isPrivate = true, $fz), "android.content.res.IntReader");
Clazz.defineMethod (c$, "add", 
function (asset, cookie, copyData) {
var data = asset.getBuffer (true);
if (data == null) return -4;
var size = asset.getLength ();
return this.add (data, 0, size, cookie, copyData);
}, "android.content.res.Asset,~N,~B");
Clazz.defineMethod (c$, "add", 
function (src) {
this.mError = src.mError;
for (var i = 0; i < src.mHeaders.size (); i++) {
this.mHeaders.add (src.mHeaders.get (i));
}
for (var i = 0; i < src.mPackageGroups.size (); i++) {
var srcPg = src.mPackageGroups.get (i);
var pg =  new android.content.res.ResTable.PackageGroup (this, srcPg.name, srcPg.id);
for (var j = 0; j < srcPg.packages.size (); j++) {
pg.packages.add (srcPg.packages.get (j));
}
pg.basePackage = srcPg.basePackage;
pg.typeCount = srcPg.typeCount;
this.mPackageGroups.add (pg);
}
for (var i = 0; i < 256; ++i) {
System.arraycopy (src.mPackageMap, 0, this.mPackageMap, 0, 256);
}
return this.mError;
}, "android.content.res.ResTable");
Clazz.defineMethod (c$, "getError", 
function () {
return this.mError;
});
Clazz.defineMethod (c$, "getResourceName", 
function (resID, outName) {
return false;
}, "~N,java.util.ArrayList");
Clazz.defineMethod (c$, "getResource", 
function (resID, outValue, mayBeBag, outSpecFlags, outConfig) {
if (resID < 0) return -5;
var p = this.getResourcePackageIndex (resID);
var t = android.content.res.ResTable.Res_GETTYPE (resID);
var e = android.content.res.ResTable.Res_GETENTRY (resID);
if (p < 0 || t < 0) return -5;
var bestValue = null;
var bestPackage = null;
var bestItem =  new android.content.res.ResourceTypes.ResTable_config ();
if (outSpecFlags != null) outSpecFlags.set (0,  new Integer (0));
var grp = this.mPackageGroups.get (p);
if (grp == null) return -5;
var ip = grp.packages.size ();
while (ip > 0) {
ip--;
var curPackage = grp.packages.get (ip);
var type =  new java.util.ArrayList ();
var entry =  new java.util.ArrayList ();
var typeClass =  new java.util.ArrayList ();
var offset = this.getEntry (curPackage, t, e, this.mParams, type, entry, typeClass);
if (offset <= 0) {
if (offset < 0) return offset;
continue ;}if ((entry.get (0).flags & 1) != 0) {
continue ;}if (offset > (type.get (0).header.size - android.content.res.ResourceTypes.Res_value.sizeof ())) return -3;
var item = (entry.get (0)).value;
var thisConfig = type.get (0).config;
if (outSpecFlags != null) {
if (typeClass.get (0).typeSpecFlags != null) {
var old = (outSpecFlags.get (0)).intValue ();
outSpecFlags.set (0, new Integer (old | typeClass.get (0).typeSpecFlags.getEntry (e)));
} else {
outSpecFlags.set (0, new Integer (-1));
}}bestValue = item;
bestItem = thisConfig;
bestPackage = curPackage;
if (bestValue != null) break;
}
if (bestValue != null) {
outValue.copyFrom (bestValue);
if (outConfig != null) outConfig.copyFrom (bestItem);
return bestPackage.header.index;
}return -7;
}, "~N,android.content.res.ResourceTypes.Res_value,~B,java.util.ArrayList,android.content.res.ResourceTypes.ResTable_config");
Clazz.defineMethod (c$, "getResource", 
function (res, outValue, outSpecFlags) {
return this.getResource (res.ident, outValue, false, outSpecFlags, null);
}, "android.content.res.ResourceTypes.ResTable_ref,android.content.res.ResourceTypes.Res_value,java.util.ArrayList");
Clazz.defineMethod (c$, "resolveReference", 
function (value, blockIndex, outLastRef, inoutTypeSpecFlags, outConfig) {
var count = 0;
while (blockIndex >= 0 && value.dataType == 1 && value.data != 0 && count < 20) {
if (outLastRef != null) {
outLastRef.set (0,  new Integer (value.data));
}var newFlags =  new java.util.ArrayList ();
newFlags.add ( new Integer (0));
var newIndex = this.getResource (value.data, value, true, newFlags, outConfig);
if (newIndex == -5) return -5;
if (inoutTypeSpecFlags != null) inoutTypeSpecFlags.set (0, newFlags.get (0));
if (newIndex < 0) return blockIndex;
blockIndex = newIndex;
count++;
}
return blockIndex;
}, "android.content.res.ResourceTypes.Res_value,~N,java.util.ArrayList,java.util.ArrayList,android.content.res.ResourceTypes.ResTable_config");
Clazz.defineMethod (c$, "getResourcePackageIndex", 
function (resID) {
return this.mPackageMap[android.content.res.ResTable.Res_GETPACKAGE (resID) + 1] - 1;
}, "~N");
Clazz.defineMethod (c$, "getBagLocked", 
function (resID, outBag, outTypeSpecFlags) {
if (resID < 0) {
return -5;
}if (this.mError != 0) return this.mError;
var p = this.getResourcePackageIndex (resID);
var t = android.content.res.ResTable.Res_GETTYPE (resID);
var e = android.content.res.ResTable.Res_GETENTRY (resID);
if (p < 0 || t < 0) return -5;
var grp = this.mPackageGroups.get (p);
if (grp == null) return -5;
if (t >= grp.typeCount) return -5;
var basePackage = grp.packages.get (0);
var typeConfigs = basePackage.getType (t);
var NENTRY = typeConfigs.entryCount;
if (e >= NENTRY) return -5;
if (grp.bags != null) {
var typeSet = grp.bags[t];
if (typeSet != null) {
var set = typeSet[e];
if (set != null) {
if (set.isFFFFFFFF != true) {
if (outTypeSpecFlags != null) outTypeSpecFlags.set (0, new Integer (set.mBagHeader.typeSpecFlags));
for (var i = 0; i < set.mBagEntries.size (); ++i) outBag.add (set.mBagEntries.get (i));

return set.mBagHeader.numAttrs;
}return -5;
}}}if (grp.bags == null) {
grp.bags =  new Array (grp.typeCount);
for (var i = 0; i < grp.typeCount; ++i) grp.bags[i] = null;

}var typeSet = grp.bags[t];
if (typeSet == null) {
typeSet =  new Array (NENTRY);
for (var i = 0; i < NENTRY; ++i) typeSet[i] = null;

grp.bags[t] = typeSet;
}var set = null;
var badBag =  new android.content.res.ResTable.Bag ();
badBag.isFFFFFFFF = true;
typeSet[e] = badBag;
var ip = grp.packages.size ();
while (ip > 0) {
ip--;
var _package = grp.packages.get (ip);
var type =  new java.util.ArrayList ();
var entry =  new java.util.ArrayList ();
var typeClass =  new java.util.ArrayList ();
var offset = this.getEntry (_package, t, e, this.mParams, type, entry, typeClass);
if (offset <= 0) {
if (offset < 0) return offset;
continue ;}if ((entry.get (0).flags & 1) == 0) continue ;var entrySize = entry.get (0).size;
var parent = entrySize >= android.content.res.ResourceTypes.ResTable_map_entry.sizeof () ? (entry.get (0)).parent.ident : 0;
var count = entrySize >= android.content.res.ResourceTypes.ResTable_map_entry.sizeof () ? (entry.get (0)).count : 0;
var N = count;
if (set == null) {
if (parent != 0) {
var parentBag =  new java.util.ArrayList ();
var parentTypeSpecFlags =  new java.util.ArrayList ();
parentTypeSpecFlags.add ( new Integer (0));
var NP = this.getBagLocked (parent, parentBag, parentTypeSpecFlags);
var NT = ((NP >= 0) ? NP : 0) + N;
set =  new android.content.res.ResTable.Bag ();
set.mBagEntries =  new java.util.ArrayList (NT);
for (var i = 0; i < NT; ++i) set.mBagEntries.add ( new android.content.res.ResTable.bag_entry ());

if (NP > 0) {
for (var i = 0; i < NP; ++i) {
set.mBagEntries.set (i,  new android.content.res.ResTable.bag_entry (parentBag.get (i)));
}
set.mBagHeader.numAttrs = NP;
} else {
set.mBagHeader.numAttrs = 0;
}set.mBagHeader.availAttrs = NT;
set.mBagHeader.typeSpecFlags = (parentTypeSpecFlags.get (0)).intValue ();
} else {
set =  new android.content.res.ResTable.Bag ();
set.mBagEntries =  new java.util.ArrayList (N);
for (var i = 0; i < N; ++i) set.mBagEntries.add ( new android.content.res.ResTable.bag_entry ());

set.mBagHeader =  new android.content.res.ResTable.bag_set (0, N, 0);
}}if (typeClass.get (0).typeSpecFlags != null) {
set.mBagHeader.typeSpecFlags |= typeClass.get (0).typeSpecFlags.getEntry (e);
} else {
set.mBagHeader.typeSpecFlags = -1;
}var curOff = offset;
var map = null;
var entries = set.mBagEntries;
var curEntry = 0;
var pos = 0;
while (pos < count) {
if (curOff > (type.get (0).header.size - android.content.res.ResourceTypes.ResTable_map.sizeof ())) {
return -3;
}map = (entry.get (0)).entries[pos];
N++;
var newName = map.name.ident;
var isInside;
var oldName = 0;
while ((isInside = (curEntry < set.mBagHeader.numAttrs)) && (oldName = entries.get (curEntry).map.name.ident) < newName) {
curEntry++;
}
if ((isInside == false) || oldName != newName) {
if (set.mBagHeader.numAttrs >= set.mBagHeader.availAttrs) {
var newAvail = set.mBagHeader.availAttrs + N;
for (var i = 0; i < N; ++i) {
set.mBagEntries.add (null);
}
set.mBagHeader.availAttrs = newAvail;
entries = set.mBagEntries;
}if (isInside == true) {
entries.add (curEntry,  new android.content.res.ResTable.bag_entry ());
set.mBagHeader.numAttrs++;
}} else {
}var cur = entries.get (curEntry);
if (cur == null) {
System.out.println ("Shit!");
}cur.stringBlock = _package.header.index;
cur.map.name.ident = newName;
cur.map.value.copyFrom (map.value);
curEntry++;
pos++;
var size = map.value.size;
curOff += size + android.content.res.ResourceTypes.ResTable_map.sizeof () - android.content.res.ResourceTypes.Res_value.sizeof ();
}
if (curEntry > set.mBagHeader.numAttrs) {
set.mBagHeader.numAttrs = curEntry;
}}
typeSet[e] = set;
if (set != null) {
if (outTypeSpecFlags != null) outTypeSpecFlags.set (0, new Integer (set.mBagHeader.typeSpecFlags));
for (var i = 0; i < set.mBagEntries.size (); ++i) outBag.add (set.mBagEntries.get (i));

return set.mBagHeader.numAttrs;
}return -5;
}, "~N,java.util.ArrayList,java.util.ArrayList");
Clazz.defineMethod (c$, "setParameters", 
function (params) {
this.mParams = params;
for (var i = 0; i < this.mPackageGroups.size (); i++) {
android.util.Log.i ("ResTable", "CLEARING BAGS FOR GROUP" + i + "!");
this.mPackageGroups.get (i).clearBagCache ();
}
}, "android.content.res.ResourceTypes.ResTable_config");
Clazz.defineMethod (c$, "getParameters", 
function (params) {
params = this.mParams;
}, "android.content.res.ResourceTypes.ResTable_config");
Clazz.defineMethod (c$, "getEntry", 
function (_package, typeIndex, entryIndex, config, outType, outEntry, outTypeClass) {
var allTypes = _package.getType (typeIndex);
if (allTypes == null) return 0;
if (entryIndex >= allTypes.entryCount) return -3;
var type = null;
var offset = -1;
var bestConfig =  new android.content.res.ResourceTypes.ResTable_config ();
var NT = allTypes.configs.size ();
for (var i = 0; i < NT; ++i) {
var thisType = allTypes.configs.get (i);
if (thisType == null) continue ;var thisConfig = thisType.config;
var thisOffset = -1;
if (thisType.entryOffsets != null) thisOffset = thisType.entryOffsets.getEntry (entryIndex);
if (thisOffset == -1) {
continue ;}if (type != null) {
if (!thisConfig.isBetterThan (bestConfig, config)) {
android.util.Log.i ("ResTable", "This config is worse than last!");
continue ;}}type = thisType;
offset = thisOffset;
bestConfig = thisConfig;
if (config == null) break;
}
if (type == null) {
android.util.Log.e ("ResTable", "No value found for requested entry!");
return -5;
}var entry = type.resources.get (new Integer (offset));
if (entry == null) {
try {
var res = null;
var reader =  new android.content.res.IntReader (type.resPointers.data, type.resPointers.base + offset, false);
var size = reader.readInt (2);
var flags = reader.readInt (2);
var specNamesId = reader.readInt ();
var newEntry = null;
if ((flags & 1) == 0) {
res =  new android.content.res.ResourceTypes.Res_value (reader.readInt (2), reader.readByte (), reader.readByte (), reader.readInt ());
newEntry =  new android.content.res.ResourceTypes.ResTable_value_entry (size, flags,  new android.content.res.ResourceTypes.ResStringPool_ref (specNamesId));
(newEntry).value.copyFrom (res);
} else {
var ident = reader.readInt ();
var count = reader.readInt ();
newEntry =  new android.content.res.ResourceTypes.ResTable_map_entry (size, flags,  new android.content.res.ResourceTypes.ResStringPool_ref (specNamesId),  new android.content.res.ResourceTypes.ResTable_ref (ident), count);
var items =  new Array (count);
for (var k = 0; k < count; ++k) {
items[k] =  new android.content.res.ResourceTypes.ResTable_map ( new android.content.res.ResourceTypes.ResTable_ref (reader.readInt ()),  new android.content.res.ResourceTypes.Res_value (reader.readInt (2), reader.readInt (1), reader.readInt (1), reader.readInt ()));
}
(newEntry).entries = items;
}type.resources.put (new Integer (offset), newEntry);
entry = newEntry;
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
}outType.add (type);
outEntry.add (entry);
if (outTypeClass != null) {
outTypeClass.add (allTypes);
}return offset + entry.size;
}, "android.content.res.ResTable.Package,~N,~N,android.content.res.ResourceTypes.ResTable_config,java.util.ArrayList,java.util.ArrayList,java.util.ArrayList");
c$.Res_GETPACKAGE = Clazz.defineMethod (c$, "Res_GETPACKAGE", 
function (id) {
return ((id >> 24) - 1);
}, "~N");
c$.Res_GETTYPE = Clazz.defineMethod (c$, "Res_GETTYPE", 
function (id) {
return (((id >> 16) & 0xFF) - 1);
}, "~N");
c$.Res_GETENTRY = Clazz.defineMethod (c$, "Res_GETENTRY", 
function (id) {
return (id & 0xffff);
}, "~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mPackage = null;
this.mType = null;
this.mName = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable, "resource_name");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.mPackage = a;
this.mType = b;
this.mName = c;
}, "~S,~S,~S");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mTable = null;
this.mPackages = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable, "Theme");
Clazz.prepareFields (c$, function () {
this.mPackages =  new Array (255);
});
Clazz.makeConstructor (c$, 
function (a) {
this.mTable = a;
for (var b = 0; b < 255; ++b) {
this.mPackages[b] = null;
}
}, "android.content.res.ResTable");
Clazz.defineMethod (c$, "getResTable", 
function () {
return this.mTable;
});
Clazz.defineMethod (c$, "applyStyle", 
function (a, b) {
var c =  new java.util.ArrayList ();
var d =  new java.util.ArrayList ();
d.add ( new Integer (0));
var e = this.mTable.getBagLocked (a, c, d);
if (e < 0) return e;
var f = 0xffffffff;
var g = 0;
var h = null;
var i = 0xffffffff;
var j = 0;
var k = null;
var l = 0;
while (l < e) {
var m = c.get (l);
var n = m.map.name.ident;
var o = android.content.res.ResTable.Res_GETPACKAGE (n);
var p = android.content.res.ResTable.Res_GETTYPE (n);
var q = android.content.res.ResTable.Res_GETENTRY (n);
if (f != o) {
var r = this.mTable.getResourcePackageIndex (n);
if (r < 0) {
l++;
continue ;}f = o;
g = r;
h = this.mPackages[r];
if (h == null) {
var s = this.mTable.mPackageGroups.get (r);
var t = s.typeCount;
h =  new android.content.res.ResTable.Theme.package_info ();
h.types =  new Array (t);
for (var u = 0; u < t; ++u) h.types[u] =  new android.content.res.ResTable.Theme.type_info ();

h.numTypes = t;
this.mPackages[r] = h;
}i = 0xffffffff;
}if (i != p) {
if (p >= h.numTypes) {
l++;
continue ;}i = p;
k = h.types[p].entries;
if (k == null) {
var r = this.mTable.mPackageGroups.get (g);
var s = r.packages.get (0).getType (p);
var t = s != null ? s.entryCount : 0;
k =  new Array (t);
for (var u = 0; u < t; ++u) k[u] =  new android.content.res.ResTable.Theme.theme_entry ();

h.types[p].numEntries = t;
h.types[p].entries = k;
}j = h.types[p].numEntries;
}if (q >= j) {
l++;
continue ;}var r = k[q];
if (b || r.value.dataType == 0) {
r.stringBlock = c.get (l).stringBlock;
r.typeSpecFlags |= (d.get (0)).intValue ();
r.value.copyFrom (c.get (l).map.value);
}l++;
}
return 0;
}, "~N,~B");
Clazz.defineMethod (c$, "setTo", 
function (a) {
if (this.mTable === a.mTable) {
for (var b = 0; b < 255; b++) {
if (this.mPackages[b] != null) {
this.mPackages[b] = null;
}if (a.mPackages[b] != null) {
this.mPackages[b] = this.copy_package (a.mPackages[b]);
} else {
this.mPackages[b] = null;
}}
} else {
for (var b = 0; b < 255; b++) {
if (this.mPackages[b] != null) {
this.mPackages[b] = null;
}if (b == 0 && a.mPackages[b] != null) {
this.mPackages[b] = this.copy_package (a.mPackages[b]);
} else {
this.mPackages[b] = null;
}}
}return 0;
}, "android.content.res.ResTable.Theme");
Clazz.defineMethod (c$, "getAttribute", 
function (a, b, c) {
var d = 20;
if (c != null) c.set (0,  new Integer (0));
do {
var e = this.mTable.getResourcePackageIndex (a);
var f = android.content.res.ResTable.Res_GETTYPE (a);
var g = android.content.res.ResTable.Res_GETENTRY (a);
if (e >= 0) {
var h = this.mPackages[e];
if (h != null) {
if (f < h.numTypes) {
var i = h.types[f];
if (g < i.numEntries) {
var j = i.entries[g];
if (c != null) {
c.set (0, new Integer ((c.get (0)).intValue () | j.typeSpecFlags));
}var k = j.value.dataType;
if (k == 2) {
if (d > 0) {
d--;
a = j.value.data;
continue ;}return -5;
} else if (k != 0) {
b.copyFrom (j.value);
return j.stringBlock;
}return -5;
}}}}break;
} while (true);
return -5;
}, "~N,android.content.res.ResourceTypes.Res_value,java.util.ArrayList");
Clazz.defineMethod (c$, "resolveAttributeReference", 
function (a, b, c, d, e) {
if (a.dataType == 2) {
var f =  new java.util.ArrayList ();
f.add ( new Integer (0));
b = this.getAttribute (a.data, a, f);
if (d != null) d.set (0, new Integer ((d.get (0)).intValue () | (f.get (0)).intValue ()));
if (b < 0) return b;
}return this.mTable.resolveReference (a, b, c, d, e);
}, "android.content.res.ResourceTypes.Res_value,~N,java.util.ArrayList,java.util.ArrayList,android.content.res.ResourceTypes.ResTable_config");
Clazz.defineMethod (c$, "dumpToLog", 
function () {
});
Clazz.defineMethod (c$, "copy_package", 
function (a) {
var b =  new android.content.res.ResTable.Theme.package_info ();
b.types =  new Array (a.numTypes);
for (var c = 0; c < a.numTypes; c++) {
b.types[c] =  new android.content.res.ResTable.Theme.type_info ();
}
b.numTypes = a.numTypes;
for (var d = 0; d < b.numTypes; d++) {
var e = a.types[d].numEntries;
b.types[d].numEntries = e;
var f = a.types[d].entries;
if (f != null) {
var g =  new Array (e);
for (var h = 0; h < e; h++) {
g[h] =  new android.content.res.ResTable.Theme.theme_entry ();
}
b.types[d].entries = g;
for (var i = 0; i < e; ++i) {
g[i].copyFrom (f[i]);
}
} else {
b.types[d].entries = null;
}}
return b;
}, "android.content.res.ResTable.Theme.package_info");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.stringBlock = 0;
this.typeSpecFlags = 0;
this.value = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable.Theme, "theme_entry");
Clazz.prepareFields (c$, function () {
this.value =  new android.content.res.ResourceTypes.Res_value ();
});
Clazz.defineMethod (c$, "copyFrom", 
function (a) {
this.stringBlock = a.stringBlock;
this.typeSpecFlags = a.typeSpecFlags;
this.value.copyFrom (a.value);
}, "android.content.res.ResTable.Theme.theme_entry");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.numEntries = 0;
this.entries = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable.Theme, "type_info");
Clazz.makeConstructor (c$, 
function () {
this.numEntries = 0;
this.entries = null;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.numTypes = 0;
this.types = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable.Theme, "package_info");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"RES_MAXPACKAGE", 255);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.header = null;
this.size = 0;
this.dataEnd = 0;
this.index = 0;
this.cookie = 0;
this.values = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable, "Header");
Clazz.prepareFields (c$, function () {
this.values =  new android.content.res.ResStringPool ();
});
Clazz.makeConstructor (c$, 
function (a) {
}, "android.content.res.ResTable");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.entryCount = 0;
this.typeSpecFlags = null;
this.configs = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable, "Type");
Clazz.prepareFields (c$, function () {
this.configs =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.entryCount = c;
}, "android.content.res.ResTable.Header,android.content.res.ResTable.Package,~N");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.header = null;
this.types = null;
this.typeStrings = null;
this.keyStrings = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable, "Package");
Clazz.prepareFields (c$, function () {
this.types =  new java.util.ArrayList ();
this.typeStrings =  new android.content.res.ResStringPool ();
this.keyStrings =  new android.content.res.ResStringPool ();
});
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.header = b;
}, "android.content.res.ResTable,android.content.res.ResTable.Header,android.content.res.ResourceTypes.ResTable_package");
Clazz.defineMethod (c$, "getType", 
function (a) {
return a < this.types.size () ? this.types.get (a) : null;
}, "~N");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.numAttrs = 0;
this.availAttrs = 0;
this.typeSpecFlags = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable, "bag_set");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.numAttrs = a;
this.availAttrs = b;
this.typeSpecFlags = c;
}, "~N,~N,~N");
Clazz.makeConstructor (c$, 
function () {
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.stringBlock = 0;
this.map = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable, "bag_entry");
Clazz.makeConstructor (c$, 
function (a) {
this.stringBlock = a.stringBlock;
this.map =  new android.content.res.ResourceTypes.ResTable_map (a.map.name, a.map.value);
}, "android.content.res.ResTable.bag_entry");
Clazz.makeConstructor (c$, 
function () {
this.map =  new android.content.res.ResourceTypes.ResTable_map ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mBagHeader = null;
this.mBagEntries = null;
this.isFFFFFFFF = false;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable, "Bag");
Clazz.prepareFields (c$, function () {
this.mBagHeader =  new android.content.res.ResTable.bag_set ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.name = null;
this.id = 0;
this.packages = null;
this.basePackage = null;
this.typeCount = 0;
this.bags = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResTable, "PackageGroup");
Clazz.prepareFields (c$, function () {
this.packages =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.name = b;
this.id = c;
}, "android.content.res.ResTable,~S,~N");
Clazz.defineMethod (c$, "clearBagCache", 
function () {
this.bags = null;
});
c$ = Clazz.p0p ();
c$.sharedRes = c$.prototype.sharedRes =  new java.util.HashMap ();
Clazz.defineStatics (c$,
"TAG", "ResTable",
"KNOWN_CONFIG_BYTES", 36,
"MAX_PACKAGE_NUM", 256,
"Res_MAXPACKAGE", 255);
});
