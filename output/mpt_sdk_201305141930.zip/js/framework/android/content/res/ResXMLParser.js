﻿Clazz.declarePackage ("android.content.res");
Clazz.load (null, "android.content.res.ResXMLParser", ["android.content.res.ResourceTypes"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mTree = null;
this.mEventCode = 0;
this.mCurNode = null;
this.mCurExt = 0;
this.mReader = null;
Clazz.instantialize (this, arguments);
}, android.content.res, "ResXMLParser");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.makeConstructor (c$, 
function (tree) {
this.init (tree);
}, "android.content.res.ResXMLTree");
Clazz.defineMethod (c$, "init", 
function (tree) {
this.mTree = tree;
this.mReader = tree.mReader;
this.mEventCode = -1;
}, "android.content.res.ResXMLTree");
Clazz.defineMethod (c$, "restart", 
function () {
this.mCurNode = null;
this.mEventCode = this.mTree.mError == 0 ? 0 : -1;
});
Clazz.defineMethod (c$, "getStrings", 
function () {
return this.mTree.mStrings;
});
Clazz.defineMethod (c$, "getEventType", 
function () {
return this.mEventCode;
});
Clazz.defineMethod (c$, "next", 
function () {
if (this.mEventCode == 0) {
this.mCurNode = this.mTree.mRootNode;
this.mCurExt = this.mTree.mRootExt;
return (this.mEventCode = this.mTree.mRootCode);
} else if (this.mEventCode >= 256) {
try {
return this.nextNode ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
}return this.mEventCode;
});
Clazz.defineMethod (c$, "nextNode", 
function () {
if (this.mEventCode < 0) {
return this.mEventCode;
}do {
this.mReader.setPosition (this.mCurNode.header.pointer.offset + this.mCurNode.header.size);
if (this.mReader.getPosition () >= this.mTree.mDataEnd) {
this.mCurNode = null;
return (this.mEventCode = 1);
}var next =  new android.content.res.ResourceTypes.ResXMLTree_node ( new android.content.res.ResourceTypes.ResChunk_header (this.mReader.getData (), this.mReader.getPosition (), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt ()), this.mReader.readInt (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()));
this.mCurNode = next;
var headerSize = next.header.headerSize;
var totalSize = next.header.size;
this.mCurExt = next.header.pointer.offset + headerSize;
var minExtSize = 0;
var eventCode = next.header.type;
switch ((this.mEventCode = eventCode)) {
case 256:
case 257:
minExtSize = android.content.res.ResourceTypes.ResXMLTree_namespaceExt.sizeof ();
break;
case 258:
minExtSize = android.content.res.ResourceTypes.ResXMLTree_attrExt.sizeof ();
break;
case 259:
minExtSize = android.content.res.ResourceTypes.ResXMLTree_endElementExt.sizeof ();
break;
case 260:
minExtSize = android.content.res.ResourceTypes.ResXMLTree_cdataExt.sizeof ();
break;
default:
continue ;}
if ((totalSize - headerSize) < minExtSize) {
return (this.mEventCode = -1);
}return eventCode;
} while (true);
});
Clazz.defineMethod (c$, "getCommentID", 
function () {
return this.mCurNode != null ? this.mCurNode.comment.index : -1;
});
Clazz.defineMethod (c$, "getLineNumber", 
function () {
return this.mCurNode != null ? this.mCurNode.lineNumber : -1;
});
Clazz.defineMethod (c$, "getTextID", 
function () {
try {
if (this.mEventCode == 260) {
this.mReader.setPosition (this.mCurExt);
var ext =  new android.content.res.ResourceTypes.ResXMLTree_cdataExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.Res_value (this.mReader.readInt (2), this.mReader.readByte (), this.mReader.readByte (), this.mReader.readInt ()));
return ext.data.index;
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -1;
});
Clazz.defineMethod (c$, "getElementNamespaceID", 
function () {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var ext =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
return ext.ns.index;
}if (this.mEventCode == 259) {
this.mReader.setPosition (this.mCurExt);
var ext =  new android.content.res.ResourceTypes.ResXMLTree_endElementExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()));
return ext.ns.index;
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -1;
});
Clazz.defineMethod (c$, "getElementNamespace", 
function () {
var id = this.getElementNamespaceID ();
return id >= 0 ? this.mTree.mStrings.stringAt (id) : null;
});
Clazz.defineMethod (c$, "getElementNameID", 
function () {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var ext =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
return ext.name.index;
}if (this.mEventCode == 259) {
this.mReader.setPosition (this.mCurExt);
var ext =  new android.content.res.ResourceTypes.ResXMLTree_endElementExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()));
return ext.name.index;
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -1;
});
Clazz.defineMethod (c$, "getElementName", 
function () {
var id = this.getElementNameID ();
return id >= 0 ? this.mTree.mStrings.stringAt (id) : null;
});
Clazz.defineMethod (c$, "getAttributeCount", 
function () {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var ext =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
return ext.attributeCount;
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return 0;
});
Clazz.defineMethod (c$, "getAttributeNamespaceID", 
function (idx) {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var tag =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
if (idx < tag.attributeCount) {
this.mReader.setPosition (tag.offset + tag.attributeStart + tag.attributeSize * idx);
var attr =  new android.content.res.ResourceTypes.ResXMLTree_attribute (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.Res_value (this.mReader.readInt (2), this.mReader.readByte (), this.mReader.readByte (), this.mReader.readInt ()));
return attr.ns.index;
}}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -2;
}, "~N");
Clazz.defineMethod (c$, "getAttributeNamespace", 
function (idx) {
var id = this.getAttributeNamespaceID (idx);
return id >= 0 ? this.mTree.mStrings.stringAt (id) : null;
}, "~N");
Clazz.defineMethod (c$, "getAttributeNameID", 
function (idx) {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var tag =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
if (idx < tag.attributeCount) {
this.mReader.setPosition (tag.offset + tag.attributeStart + tag.attributeSize * idx);
var attr =  new android.content.res.ResourceTypes.ResXMLTree_attribute (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.Res_value (this.mReader.readInt (2), this.mReader.readByte (), this.mReader.readByte (), this.mReader.readInt ()));
return attr.name.index;
}}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -1;
}, "~N");
Clazz.defineMethod (c$, "getAttributeName", 
function (idx) {
var id = this.getAttributeNameID (idx);
return id >= 0 ? this.mTree.mStrings.stringAt (id) : null;
}, "~N");
Clazz.defineMethod (c$, "getAttributeNameResID", 
function (idx) {
var id = this.getAttributeNameID (idx);
if (id >= 0 && id < this.mTree.mNumResIds) return this.mTree.mResIds[id];
return 0;
}, "~N");
Clazz.defineMethod (c$, "getAttributeValueStringID", 
function (idx) {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var tag =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
if (idx < tag.attributeCount) {
this.mReader.setPosition (tag.offset + tag.attributeStart + tag.attributeSize * idx);
var attr =  new android.content.res.ResourceTypes.ResXMLTree_attribute (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.Res_value (this.mReader.readInt (2), this.mReader.readByte (), this.mReader.readByte (), this.mReader.readInt ()));
return attr.rawValue.index;
}}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -1;
}, "~N");
Clazz.defineMethod (c$, "getAttributeValue", 
function (idx, outValue) {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var tag =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
if (idx < tag.attributeCount) {
this.mReader.setPosition (tag.offset + tag.attributeStart + tag.attributeSize * idx);
var attr =  new android.content.res.ResourceTypes.ResXMLTree_attribute (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.Res_value (this.mReader.readInt (2), this.mReader.readByte (), this.mReader.readByte (), this.mReader.readInt ()));
outValue.copyFrom (attr.typedValue);
return android.content.res.ResourceTypes.Res_value.sizeof ();
}}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -3;
}, "~N,android.content.res.ResourceTypes.Res_value");
Clazz.defineMethod (c$, "getAttributeDataType", 
function (idx) {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var tag =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
if (idx < tag.attributeCount) {
this.mReader.setPosition (tag.offset + tag.attributeStart + tag.attributeSize * idx);
var attr =  new android.content.res.ResourceTypes.ResXMLTree_attribute (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.Res_value (this.mReader.readInt (2), this.mReader.readByte (), this.mReader.readByte (), this.mReader.readInt ()));
return attr.typedValue.dataType;
}}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return 0;
}, "~N");
Clazz.defineMethod (c$, "getAttributeData", 
function (idx) {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var tag =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
if (idx < tag.attributeCount) {
this.mReader.setPosition (tag.offset + tag.attributeStart + tag.attributeSize * idx);
var attr =  new android.content.res.ResourceTypes.ResXMLTree_attribute (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.Res_value (this.mReader.readInt (2), this.mReader.readByte (), this.mReader.readByte (), this.mReader.readInt ()));
return attr.typedValue.data;
}}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return 0;
}, "~N");
Clazz.defineMethod (c$, "indexOfAttribute", 
function (namespace, name) {
if (this.mEventCode == 258) {
var N = this.getAttributeCount ();
for (var i = 0; i < N; ++i) {
var curNs = this.getAttributeNamespace (i);
var curAttr = this.getAttributeName (i);
if (curAttr.equals (name) == true) {
if (namespace == null) {
if (curNs == null) return i;
} else if (curNs != null) {
if (curNs.equals (namespace) == true) return i;
}}}
}return -2;
}, "~S,~S");
Clazz.defineMethod (c$, "indexOfID", 
function () {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var ext =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
var idx = ext.idIndex;
if (idx > 0) return (idx - 1);
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -2;
});
Clazz.defineMethod (c$, "indexOfClass", 
function () {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var ext =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
var idx = ext.classIndex;
if (idx > 0) return (idx - 1);
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -2;
});
Clazz.defineMethod (c$, "indexOfStyle", 
function () {
try {
if (this.mEventCode == 258) {
this.mReader.setPosition (this.mCurExt);
var ext =  new android.content.res.ResourceTypes.ResXMLTree_attrExt (this.mReader.getPosition (),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()),  new android.content.res.ResourceTypes.ResStringPool_ref (this.mReader.readInt ()), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2), this.mReader.readInt (2));
var idx = ext.styleIndex;
if (idx > 0) return (idx - 1);
}} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -2;
});
Clazz.defineStatics (c$,
"BAD_DOCUMENT", -1,
"START_DOCUMENT", 0,
"END_DOCUMENT", 1,
"FIRST_CHUNK_CODE", 256,
"START_NAMESPACE", 256,
"END_NAMESPACE", 257,
"START_TAG", 258,
"END_TAG", 259,
"TEXT", 260);
});
