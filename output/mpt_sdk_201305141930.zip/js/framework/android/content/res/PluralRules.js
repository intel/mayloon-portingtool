﻿Clazz.declarePackage ("android.content.res");
c$ = Clazz.declareType (android.content.res, "PluralRules");
Clazz.defineMethod (c$, "attrForNumber", 
function (n) {
return android.content.res.PluralRules.attrForQuantity (this.quantityForNumber (n));
}, "~N");
c$.attrForQuantity = Clazz.defineMethod (c$, "attrForQuantity", 
function (quantity) {
switch (quantity) {
case 1:
return 0x01000005;
case 2:
return 0x01000006;
case 4:
return 0x01000007;
case 8:
return 0x01000008;
case 16:
return 0x01000009;
default:
return 16777220;
}
}, "~N");
c$.stringForQuantity = Clazz.defineMethod (c$, "stringForQuantity", 
function (quantity) {
switch (quantity) {
case 1:
return "zero";
case 2:
return "one";
case 4:
return "two";
case 8:
return "few";
case 16:
return "many";
default:
return "other";
}
}, "~N");
c$.ruleForLocale = Clazz.defineMethod (c$, "ruleForLocale", 
function (locale) {
var lang = locale.getLanguage ();
if ("cs".equals (lang)) {
if (android.content.res.PluralRules.cs == null) ($t$ = android.content.res.PluralRules.cs =  new android.content.res.PluralRules.cs (), android.content.res.PluralRules.prototype.cs = android.content.res.PluralRules.cs, $t$);
return android.content.res.PluralRules.cs;
} else {
if (android.content.res.PluralRules.en == null) ($t$ = android.content.res.PluralRules.en =  new android.content.res.PluralRules.en (), android.content.res.PluralRules.prototype.en = android.content.res.PluralRules.en, $t$);
return android.content.res.PluralRules.en;
}}, "java.util.Locale");
Clazz.pu$h ();
c$ = Clazz.declareType (android.content.res.PluralRules, "cs", android.content.res.PluralRules);
Clazz.overrideMethod (c$, "quantityForNumber", 
function (a) {
if (a == 1) {
return 2;
} else if (a >= 2 && a <= 4) {
return 8;
} else {
return 0;
}}, "~N");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.declareType (android.content.res.PluralRules, "en", android.content.res.PluralRules);
Clazz.overrideMethod (c$, "quantityForNumber", 
function (a) {
if (a == 1) {
return 2;
} else {
return 0;
}}, "~N");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"QUANTITY_OTHER", 0x0000,
"QUANTITY_ZERO", 0x0001,
"QUANTITY_ONE", 0x0002,
"QUANTITY_TWO", 0x0004,
"QUANTITY_FEW", 0x0008,
"QUANTITY_MANY", 0x0010,
"ID_OTHER", 0x01000004,
"cs", null,
"en", null);
