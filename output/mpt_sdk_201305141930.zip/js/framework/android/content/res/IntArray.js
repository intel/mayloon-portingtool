﻿Clazz.declarePackage ("android.content.res");
Clazz.load (null, "android.content.res.IntArray", ["android.content.res.IntReader"], function () {
c$ = Clazz.decorateAsClass (function () {
this.data = null;
this.offset = 0;
this.length = 0;
this.reader = null;
Clazz.instantialize (this, arguments);
}, android.content.res, "IntArray");
Clazz.makeConstructor (c$, 
function (data, offset, length) {
this.data = data;
this.offset = offset;
this.length = length;
this.reader =  new android.content.res.IntReader (data, offset, false);
}, "~A,~N,~N");
Clazz.defineMethod (c$, "getEntry", 
function (index) {
var result = 0;
this.reader.setPosition (this.offset + index * 4);
try {
result = this.reader.readInt ();
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
} else {
throw e;
}
}
return result;
}, "~N");
});
