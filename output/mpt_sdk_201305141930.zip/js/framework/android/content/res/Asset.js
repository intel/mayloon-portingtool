﻿Clazz.declarePackage ("android.content.res");
c$ = Clazz.decorateAsClass (function () {
this.mAssetSource = null;
this.mAccessMode = 0;
this.mNext = null;
this.mPrev = null;
Clazz.instantialize (this, arguments);
}, android.content.res, "Asset");
Clazz.defineMethod (c$, "close", 
function () {
});
Clazz.defineMethod (c$, "getAssetSource", 
function () {
return this.mAssetSource;
});
Clazz.defineMethod (c$, "setAssetSource", 
function (path) {
this.mAssetSource = path;
}, "~S");
c$.createFromFile = Clazz.defineMethod (c$, "createFromFile", 
function (fileName, mode) {
var pAsset = null;
try {
pAsset = Class.forName ("android.content.res._FileAsset").newInstance ();
} catch (e$$) {
if (Clazz.instanceOf (e$$, InstantiationException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, IllegalAccessException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else if (Clazz.instanceOf (e$$, ClassNotFoundException)) {
var e = e$$;
{
e.printStackTrace ();
}
} else {
throw e$$;
}
}
var result = pAsset.openChunk (fileName, 0, -1);
if (result != 0) {
pAsset = null;
return null;
}pAsset.mAccessMode = mode;
return pAsset;
}, "~S,~N");
Clazz.defineStatics (c$,
"DEBUG", false,
"kFileTypeUnknown", 0,
"kFileTypeNonexistent", 1,
"kFileTypeRegular", 2,
"kFileTypeDirectory", 3);
