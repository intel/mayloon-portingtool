﻿Clazz.declarePackage ("android.content.res");
Clazz.load (null, "android.content.res.ResStringPool", ["android.content.res.ChunkUtil", "$.IntArray", "$.IntReader", "$.ResourceTypes", "java.io.IOException", "java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mEntriesOffset = -1;
this.mEntries = null;
this.mStringsOffset = -1;
this.mStrings = null;
this.mEntryStylesOffset = -1;
this.mEntryStyles = null;
this.mStylesOffset = -1;
this.mStyles = null;
this.mStylePoolSize = 0;
this.mStringPoolSize = 0;
this.mError = -1;
this.mHeader = null;
this.mSize = -1;
Clazz.instantialize (this, arguments);
}, android.content.res, "ResStringPool");
Clazz.makeConstructor (c$, 
function (data, offset, size, copyData) {
this.setTo (data, offset, size, copyData);
}, "~A,~N,~N,~B");
Clazz.defineMethod (c$, "setTo", 
function (data, offset, size, copyData) {
if (data == null || size <= 0) return (this.mError = -3);
this.uninit ();
var reader =  new android.content.res.IntReader (data, offset, false);
var chunk =  new android.content.res.ResourceTypes.ResChunk_header (data, reader.getPosition (), reader.readInt (2), reader.readInt (2), reader.readInt ());
android.content.res.ChunkUtil.checkType (chunk.type, 1);
this.mHeader =  new android.content.res.ResourceTypes.ResStringPool_header (chunk, reader.readInt (), reader.readInt (), reader.readInt (), reader.readInt (), reader.readInt ());
this.mSize = this.mHeader.header.size;
this.mEntriesOffset = this.mHeader.header.pointer.offset + this.mHeader.header.headerSize;
reader.setPosition (this.mEntriesOffset);
if (this.mHeader.stringCount > 0) {
this.mEntries =  new android.content.res.IntArray (reader.getData (), reader.getPosition (), this.mHeader.stringCount);
this.mStringsOffset = this.mHeader.header.pointer.offset + this.mHeader.stringsStart;
reader.setPosition (this.mStringsOffset);
var readSize = ((this.mHeader.styleCount == 0) ? this.mHeader.header.size : this.mHeader.stylesStart) - this.mHeader.stringsStart;
if ((readSize % 4) != 0) {
throw  new java.io.IOException ("String data size is not multiple of 4 (" + readSize + ").");
}this.mStrings =  new android.content.res.ResourceTypes.ResData_pointer (reader.getPosition (), data);
}if (this.mHeader.styleCount > 0) {
this.mEntryStylesOffset = this.mEntriesOffset + this.mHeader.stringCount;
reader.setPosition (this.mEntryStylesOffset);
this.mStylesOffset = this.mHeader.header.pointer.offset + this.mHeader.stylesStart;
reader.setPosition (this.mStylesOffset);
var readSize = (this.mHeader.header.size - this.mHeader.stylesStart);
if ((readSize % 4) != 0) {
throw  new java.io.IOException ("Style data size is not multiple of 4 (" + readSize + ").");
}}return (this.mError = 0);
}, "~A,~N,~N,~B");
Clazz.defineMethod (c$, "getCount", 
function () {
return this.mHeader.stringCount;
});
Clazz.defineMethod (c$, "stringAt", 
function (index) {
if (index < 0 || this.mEntries == null || index >= this.mEntries.length) {
return null;
}var isUTF8 = (this.mHeader.flags & 256) != 0;
var offset = this.mEntries.getEntry (index);
if (isUTF8 == true) {
var length = android.content.res.ResStringPool.getByte (this.mStrings, offset);
offset += 1;
var result =  new StringBuilder (length);
for (; length != 0; length -= 1) {
offset += 1;
result.append (String.fromCharCode (android.content.res.ResStringPool.getByte (this.mStrings, offset)));
}
return result.toString ();
} else {
var length = android.content.res.ResStringPool.getShort (this.mStrings, offset);
var result =  new StringBuilder (length);
for (; length != 0; length -= 1) {
offset += 2;
result.append (String.fromCharCode (android.content.res.ResStringPool.getShort (this.mStrings, offset)));
}
return result.toString ();
}}, "~N");
Clazz.defineMethod (c$, "get", 
function (index) {
return this.stringAt (index);
}, "~N");
Clazz.defineMethod (c$, "getHTML", 
function (index) {
var raw = this.stringAt (index);
if (raw == null) {
return raw;
}var style = this.getStyle (index);
if (style == null) {
return raw;
}var html =  new StringBuilder (raw.length + 32);
var offset = 0;
while (true) {
var i = -1;
for (var j = 0; j != style.length; j += 3) {
if (style[j + 1] == -1) {
continue ;}if (i == -1 || style[i + 1] > style[j + 1]) {
i = j;
}}
var start = ((i != -1) ? style[i + 1] : raw.length);
for (var j = 0; j != style.length; j += 3) {
var end = style[j + 2];
if (end == -1 || end >= start) {
continue ;}if (offset <= end) {
html.append (raw, offset, end + 1);
offset = end + 1;
}style[j + 2] = -1;
html.append ('<');
html.append ('/');
html.append (this.stringAt (style[j]));
html.append ('>');
}
if (offset < start) {
html.append (raw, offset, start);
offset = start;
}if (i == -1) {
break;
}html.append ('<');
html.append (this.stringAt (style[i]));
html.append ('>');
style[i + 1] = -1;
}
return html.toString ();
}, "~N");
Clazz.defineMethod (c$, "indexOfString", 
function (string) {
if (string == null) {
return -1;
}for (var i = 0; i != this.mEntries.length; ++i) {
var offset = this.mEntries.getEntry (i);
var length = android.content.res.ResStringPool.getShort (this.mStrings, offset);
if (length != string.length) {
continue ;}var j = 0;
for (; j != length; ++j) {
offset += 2;
if ((string.charAt (j)).charCodeAt (0) != android.content.res.ResStringPool.getShort (this.mStrings, offset)) {
break;
}}
if (j == length) {
return i;
}}
return -1;
}, "~S");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "getStyle", 
($fz = function (index) {
if (this.mEntryStyles == null || this.mStyles == null || index >= this.mEntryStyles.length) {
return null;
}var offset = Math.floor (this.mEntryStyles[index] / 4);
var style;
var count = 0;
for (var i = offset; i < this.mStyles.length; ++i) {
if (this.mStyles[i] == -1) {
break;
}count += 1;
}
if (count == 0 || (count % 3) != 0) {
return null;
}style =  Clazz.newArray (count, 0);
for (var i = offset, j = 0; i < this.mStyles.length; ) {
if (this.mStyles[i] == -1) {
break;
}style[j++] = this.mStyles[i++];
}
return style;
}, $fz.isPrivate = true, $fz), "~N");
c$.getShort = Clazz.defineMethod (c$, "getShort", 
($fz = function (pointer, offset) {
var reader =  new android.content.res.IntReader (pointer.data, pointer.offset, false);
var pos = reader.getPosition () + offset;
reader.setPosition (pos);
try {
var value = reader.readInt ();
return (value & 0xFFFF);
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -1;
}, $fz.isPrivate = true, $fz), "android.content.res.ResourceTypes.ResData_pointer,~N");
c$.getByte = Clazz.defineMethod (c$, "getByte", 
($fz = function (pointer, offset) {
var reader =  new android.content.res.IntReader (pointer.data, pointer.offset, false);
var pos = reader.getPosition () + offset;
reader.setPosition (pos);
try {
var value = reader.readInt ();
return (value & 0xff);
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
e.printStackTrace ();
} else {
throw e;
}
}
return -1;
}, $fz.isPrivate = true, $fz), "android.content.res.ResourceTypes.ResData_pointer,~N");
Clazz.defineMethod (c$, "uninit", 
function () {
this.mError = -1;
});
Clazz.defineMethod (c$, "getError", 
function () {
return this.mError;
});
Clazz.defineMethod (c$, "size", 
function () {
return (this.mError == 0) ? this.mHeader.stringCount : 0;
});
});
