﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["android.os.Parcelable"], "android.content.res.Configuration", ["java.lang.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.fontScale = 0;
this.mcc = 0;
this.mnc = 0;
this.locale = null;
this.userSetLocale = false;
this.screenLayout = 0;
this.touchscreen = 0;
this.keyboard = 0;
this.keyboardHidden = 0;
this.hardKeyboardHidden = 0;
this.navigation = 0;
this.navigationHidden = 0;
this.orientation = 0;
this.uiMode = 0;
this.seq = 0;
Clazz.instantialize (this, arguments);
}, android.content.res, "Configuration", null, [android.os.Parcelable, Comparable]);
Clazz.makeConstructor (c$, 
function () {
this.setToDefaults ();
});
Clazz.makeConstructor (c$, 
function (o) {
this.setTo (o);
}, "android.content.res.Configuration");
Clazz.defineMethod (c$, "setTo", 
function (o) {
this.fontScale = o.fontScale;
this.mcc = o.mcc;
this.mnc = o.mnc;
if (o.locale != null) {
this.locale = o.locale.clone ();
}this.userSetLocale = o.userSetLocale;
this.touchscreen = o.touchscreen;
this.keyboard = o.keyboard;
this.keyboardHidden = o.keyboardHidden;
this.hardKeyboardHidden = o.hardKeyboardHidden;
this.navigation = o.navigation;
this.navigationHidden = o.navigationHidden;
this.orientation = o.orientation;
this.screenLayout = o.screenLayout;
this.uiMode = o.uiMode;
this.seq = o.seq;
}, "android.content.res.Configuration");
Clazz.overrideMethod (c$, "toString", 
function () {
var sb =  new StringBuilder (128);
sb.append ("{ scale=");
sb.append (this.fontScale);
sb.append (" imsi=");
sb.append (this.mcc);
sb.append ("/");
sb.append (this.mnc);
sb.append (" loc=");
sb.append (this.locale);
sb.append (" touch=");
sb.append (this.touchscreen);
sb.append (" keys=");
sb.append (this.keyboard);
sb.append ("/");
sb.append (this.keyboardHidden);
sb.append ("/");
sb.append (this.hardKeyboardHidden);
sb.append (" nav=");
sb.append (this.navigation);
sb.append ("/");
sb.append (this.navigationHidden);
sb.append (" orien=");
sb.append (this.orientation);
sb.append (" layout=");
sb.append (this.screenLayout);
sb.append (" uiMode=");
sb.append (this.uiMode);
if (this.seq != 0) {
sb.append (" seq=");
sb.append (this.seq);
}sb.append ('}');
return sb.toString ();
});
Clazz.defineMethod (c$, "setToDefaults", 
function () {
this.fontScale = 1;
this.mcc = this.mnc = 0;
this.locale = null;
this.userSetLocale = false;
this.touchscreen = 0;
this.keyboard = 0;
this.keyboardHidden = 0;
this.hardKeyboardHidden = 0;
this.navigation = 0;
this.navigationHidden = 0;
this.orientation = 0;
this.screenLayout = 0;
this.uiMode = 0;
this.seq = 0;
});
Clazz.defineMethod (c$, "makeDefault", 
function () {
this.setToDefaults ();
});
Clazz.defineMethod (c$, "updateFrom", 
function (delta) {
var changed = 0;
if (delta.fontScale > 0 && this.fontScale != delta.fontScale) {
changed |= 1073741824;
this.fontScale = delta.fontScale;
}if (delta.mcc != 0 && this.mcc != delta.mcc) {
changed |= 1;
this.mcc = delta.mcc;
}if (delta.mnc != 0 && this.mnc != delta.mnc) {
changed |= 2;
this.mnc = delta.mnc;
}if (delta.locale != null && (this.locale == null || !this.locale.equals (delta.locale))) {
changed |= 4;
this.locale = delta.locale != null ? delta.locale.clone () : null;
}if (delta.userSetLocale && (!this.userSetLocale || ((changed & 4) != 0))) {
this.userSetLocale = true;
changed |= 4;
}if (delta.touchscreen != 0 && this.touchscreen != delta.touchscreen) {
changed |= 8;
this.touchscreen = delta.touchscreen;
}if (delta.keyboard != 0 && this.keyboard != delta.keyboard) {
changed |= 16;
this.keyboard = delta.keyboard;
}if (delta.keyboardHidden != 0 && this.keyboardHidden != delta.keyboardHidden) {
changed |= 32;
this.keyboardHidden = delta.keyboardHidden;
}if (delta.hardKeyboardHidden != 0 && this.hardKeyboardHidden != delta.hardKeyboardHidden) {
changed |= 32;
this.hardKeyboardHidden = delta.hardKeyboardHidden;
}if (delta.navigation != 0 && this.navigation != delta.navigation) {
changed |= 64;
this.navigation = delta.navigation;
}if (delta.navigationHidden != 0 && this.navigationHidden != delta.navigationHidden) {
changed |= 32;
this.navigationHidden = delta.navigationHidden;
}if (delta.orientation != 0 && this.orientation != delta.orientation) {
changed |= 128;
this.orientation = delta.orientation;
}if (delta.screenLayout != 0 && this.screenLayout != delta.screenLayout) {
changed |= 256;
this.screenLayout = delta.screenLayout;
}if (delta.uiMode != (0) && this.uiMode != delta.uiMode) {
changed |= 512;
if ((delta.uiMode & 15) != 0) {
this.uiMode = (this.uiMode & -16) | (delta.uiMode & 15);
}if ((delta.uiMode & 48) != 0) {
this.uiMode = (this.uiMode & -49) | (delta.uiMode & 48);
}}if (delta.seq != 0) {
this.seq = delta.seq;
}return changed;
}, "android.content.res.Configuration");
Clazz.defineMethod (c$, "diff", 
function (delta) {
var changed = 0;
if (delta.fontScale > 0 && this.fontScale != delta.fontScale) {
changed |= 1073741824;
}if (delta.mcc != 0 && this.mcc != delta.mcc) {
changed |= 1;
}if (delta.mnc != 0 && this.mnc != delta.mnc) {
changed |= 2;
}if (delta.locale != null && (this.locale == null || !this.locale.equals (delta.locale))) {
changed |= 4;
}if (delta.touchscreen != 0 && this.touchscreen != delta.touchscreen) {
changed |= 8;
}if (delta.keyboard != 0 && this.keyboard != delta.keyboard) {
changed |= 16;
}if (delta.keyboardHidden != 0 && this.keyboardHidden != delta.keyboardHidden) {
changed |= 32;
}if (delta.hardKeyboardHidden != 0 && this.hardKeyboardHidden != delta.hardKeyboardHidden) {
changed |= 32;
}if (delta.navigation != 0 && this.navigation != delta.navigation) {
changed |= 64;
}if (delta.navigationHidden != 0 && this.navigationHidden != delta.navigationHidden) {
changed |= 32;
}if (delta.orientation != 0 && this.orientation != delta.orientation) {
changed |= 128;
}if (delta.screenLayout != 0 && this.screenLayout != delta.screenLayout) {
changed |= 256;
}if (delta.uiMode != (0) && this.uiMode != delta.uiMode) {
changed |= 512;
}return changed;
}, "android.content.res.Configuration");
c$.needNewResources = Clazz.defineMethod (c$, "needNewResources", 
function (configChanges, interestingChanges) {
return (configChanges & (interestingChanges | 1073741824)) != 0;
}, "~N,~N");
Clazz.defineMethod (c$, "isOtherSeqNewer", 
function (other) {
if (other == null) {
return false;
}if (other.seq == 0) {
return true;
}if (this.seq == 0) {
return true;
}var diff = other.seq - this.seq;
if (diff > 0x10000) {
return false;
}return diff > 0;
}, "android.content.res.Configuration");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.overrideMethod (c$, "compareTo", 
function (that) {
var n;
var a = this.fontScale;
var b = that.fontScale;
if (a < b) return -1;
if (a > b) return 1;
n = this.mcc - that.mcc;
if (n != 0) return n;
n = this.mnc - that.mnc;
if (n != 0) return n;
if (this.locale == null) {
if (that.locale != null) return 1;
} else if (that.locale == null) {
return -1;
} else {
n = this.locale.getLanguage ().compareTo (that.locale.getLanguage ());
if (n != 0) return n;
n = this.locale.getCountry ().compareTo (that.locale.getCountry ());
if (n != 0) return n;
n = this.locale.getVariant ().compareTo (that.locale.getVariant ());
if (n != 0) return n;
}n = this.touchscreen - that.touchscreen;
if (n != 0) return n;
n = this.keyboard - that.keyboard;
if (n != 0) return n;
n = this.keyboardHidden - that.keyboardHidden;
if (n != 0) return n;
n = this.hardKeyboardHidden - that.hardKeyboardHidden;
if (n != 0) return n;
n = this.navigation - that.navigation;
if (n != 0) return n;
n = this.navigationHidden - that.navigationHidden;
if (n != 0) return n;
n = this.orientation - that.orientation;
if (n != 0) return n;
n = this.screenLayout - that.screenLayout;
if (n != 0) return n;
n = this.uiMode - that.uiMode;
return n;
}, "android.content.res.Configuration");
Clazz.defineMethod (c$, "equals", 
function (that) {
if (that == null) return false;
if (that === this) return true;
return this.compareTo (that) == 0;
}, "android.content.res.Configuration");
Clazz.defineMethod (c$, "equals", 
function (that) {
try {
return this.equals (that);
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
} else {
throw e;
}
}
return false;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return (Math.round (this.fontScale)) + this.mcc + this.mnc + (this.locale != null ? this.locale.hashCode () : 0) + this.touchscreen + this.keyboard + this.keyboardHidden + this.hardKeyboardHidden + this.navigation + this.navigationHidden + this.orientation + this.screenLayout + this.uiMode;
});
Clazz.defineMethod (c$, "readFromParcel", 
function (source) {
console.log("Missing method: readFromParcel");
}, "android.os.Parcel");
Clazz.defineStatics (c$,
"SCREENLAYOUT_SIZE_MASK", 0x0f,
"SCREENLAYOUT_SIZE_UNDEFINED", 0x00,
"SCREENLAYOUT_SIZE_SMALL", 0x01,
"SCREENLAYOUT_SIZE_NORMAL", 0x02,
"SCREENLAYOUT_SIZE_LARGE", 0x03,
"SCREENLAYOUT_SIZE_XLARGE", 0x04,
"SCREENLAYOUT_LONG_MASK", 0x30,
"SCREENLAYOUT_LONG_UNDEFINED", 0x00,
"SCREENLAYOUT_LONG_NO", 0x10,
"SCREENLAYOUT_LONG_YES", 0x20,
"SCREENLAYOUT_COMPAT_NEEDED", 0x10000000,
"TOUCHSCREEN_UNDEFINED", 0,
"TOUCHSCREEN_NOTOUCH", 1,
"TOUCHSCREEN_STYLUS", 2,
"TOUCHSCREEN_FINGER", 3,
"KEYBOARD_UNDEFINED", 0,
"KEYBOARD_NOKEYS", 1,
"KEYBOARD_QWERTY", 2,
"KEYBOARD_12KEY", 3,
"KEYBOARDHIDDEN_UNDEFINED", 0,
"KEYBOARDHIDDEN_NO", 1,
"KEYBOARDHIDDEN_YES", 2,
"KEYBOARDHIDDEN_SOFT", 3,
"HARDKEYBOARDHIDDEN_UNDEFINED", 0,
"HARDKEYBOARDHIDDEN_NO", 1,
"HARDKEYBOARDHIDDEN_YES", 2,
"NAVIGATION_UNDEFINED", 0,
"NAVIGATION_NONAV", 1,
"NAVIGATION_DPAD", 2,
"NAVIGATION_TRACKBALL", 3,
"NAVIGATION_WHEEL", 4,
"NAVIGATIONHIDDEN_UNDEFINED", 0,
"NAVIGATIONHIDDEN_NO", 1,
"NAVIGATIONHIDDEN_YES", 2,
"ORIENTATION_UNDEFINED", 0,
"ORIENTATION_PORTRAIT", 1,
"ORIENTATION_LANDSCAPE", 2,
"ORIENTATION_SQUARE", 3,
"UI_MODE_TYPE_MASK", 0x0f,
"UI_MODE_TYPE_UNDEFINED", 0x00,
"UI_MODE_TYPE_NORMAL", 0x01,
"UI_MODE_TYPE_DESK", 0x02,
"UI_MODE_TYPE_CAR", 0x03,
"UI_MODE_NIGHT_MASK", 0x30,
"UI_MODE_NIGHT_UNDEFINED", 0x00,
"UI_MODE_NIGHT_NO", 0x10,
"UI_MODE_NIGHT_YES", 0x20);
});
