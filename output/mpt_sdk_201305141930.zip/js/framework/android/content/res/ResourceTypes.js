﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["java.util.HashMap"], "android.content.res.ResourceTypes", ["java.lang.StringBuilder"], function () {
c$ = Clazz.declareType (android.content.res, "ResourceTypes");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.offset = 0;
this.data = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResData_pointer");
Clazz.makeConstructor (c$, 
function (a, b) {
this.offset = a;
this.data = b;
}, "~N,~A");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.type = 0;
this.headerSize = 0;
this.size = 0;
this.pointer = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResChunk_header");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e) {
this.pointer =  new android.content.res.ResourceTypes.ResData_pointer (b, a);
this.type = c;
this.headerSize = d;
this.size = e;
}, "~A,~N,~N,~N,~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return 8;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.size = 0;
this.res0 = 0;
this.dataType = 0;
this.data = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "Res_value");
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
this.size = a;
this.res0 = b;
this.dataType = c;
this.data = d;
}, "~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function () {
});
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return 8;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return "t = " + this.dataType + ", d = " + this.data;
});
Clazz.defineMethod (c$, "copyFrom", 
function (a) {
this.size = a.size;
this.res0 = a.res0;
this.dataType = a.dataType;
this.data = a.data;
}, "android.content.res.ResourceTypes.Res_value");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.ident = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_ref");
Clazz.makeConstructor (c$, 
function (a) {
this.ident = a;
}, "~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return 4;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.index = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResStringPool_ref");
Clazz.makeConstructor (c$, 
function (a) {
this.index = a;
}, "~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return 4;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.header = null;
this.stringCount = 0;
this.styleCount = 0;
this.flags = 0;
this.stringsStart = 0;
this.stylesStart = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResStringPool_header");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e, f) {
this.header = a;
this.stringCount = b;
this.styleCount = c;
this.flags = d;
this.stringsStart = e;
this.stylesStart = f;
}, "android.content.res.ResourceTypes.ResChunk_header,~N,~N,~N,~N,~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResChunk_header.sizeof () + 20;
});
Clazz.defineStatics (c$,
"UTF8_FLAG", 256);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.name = null;
this.firstChar = 0;
this.lastChar = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResStringPool_span");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.name = a;
this.firstChar = b;
this.lastChar = c;
}, "android.content.res.ResourceTypes.ResStringPool_ref,~N,~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResStringPool_ref.sizeof () + 8;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.header = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResXMLTree_header");
Clazz.makeConstructor (c$, 
function (a) {
this.header = a;
}, "android.content.res.ResourceTypes.ResChunk_header");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResChunk_header.sizeof ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.header = null;
this.lineNumber = 0;
this.comment = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResXMLTree_node");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.header = a;
this.lineNumber = b;
this.comment = c;
}, "android.content.res.ResourceTypes.ResChunk_header,~N,android.content.res.ResourceTypes.ResStringPool_ref");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResChunk_header.sizeof () + 4 + android.content.res.ResourceTypes.ResStringPool_ref.sizeof ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.offset = 0;
this.data = null;
this.typedData = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResXMLTree_cdataExt");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.data = b;
this.typedData = c;
this.offset = a;
}, "~N,android.content.res.ResourceTypes.ResStringPool_ref,android.content.res.ResourceTypes.Res_value");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResStringPool_ref.sizeof () + android.content.res.ResourceTypes.Res_value.sizeof ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.offset = 0;
this.prefix = null;
this.uri = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResXMLTree_namespaceExt");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.prefix = b;
this.uri = c;
this.offset = a;
}, "~N,android.content.res.ResourceTypes.ResStringPool_ref,android.content.res.ResourceTypes.ResStringPool_ref");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResStringPool_ref.sizeof () + android.content.res.ResourceTypes.ResStringPool_ref.sizeof ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.offset = 0;
this.ns = null;
this.name = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResXMLTree_endElementExt");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.ns = b;
this.name = c;
this.offset = a;
}, "~N,android.content.res.ResourceTypes.ResStringPool_ref,android.content.res.ResourceTypes.ResStringPool_ref");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResStringPool_ref.sizeof () + android.content.res.ResourceTypes.ResStringPool_ref.sizeof ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.offset = 0;
this.ns = null;
this.name = null;
this.attributeStart = 0;
this.attributeSize = 0;
this.attributeCount = 0;
this.idIndex = 0;
this.classIndex = 0;
this.styleIndex = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResXMLTree_attrExt");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e, f, g, h, i) {
this.ns = b;
this.name = c;
this.attributeStart = d;
this.attributeSize = e;
this.attributeCount = f;
this.idIndex = g;
this.classIndex = h;
this.styleIndex = i;
this.offset = a;
}, "~N,android.content.res.ResourceTypes.ResStringPool_ref,android.content.res.ResourceTypes.ResStringPool_ref,~N,~N,~N,~N,~N,~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResStringPool_ref.sizeof () + android.content.res.ResourceTypes.ResStringPool_ref.sizeof () + 12;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.offset = 0;
this.ns = null;
this.name = null;
this.rawValue = null;
this.typedValue = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResXMLTree_attribute");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e) {
this.ns = b;
this.name = c;
this.rawValue = d;
this.typedValue = e;
this.offset = a;
}, "~N,android.content.res.ResourceTypes.ResStringPool_ref,android.content.res.ResourceTypes.ResStringPool_ref,android.content.res.ResourceTypes.ResStringPool_ref,android.content.res.ResourceTypes.Res_value");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResStringPool_ref.sizeof () + android.content.res.ResourceTypes.ResStringPool_ref.sizeof () + android.content.res.ResourceTypes.ResStringPool_ref.sizeof () + android.content.res.ResourceTypes.Res_value.sizeof ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.header = null;
this.packageCount = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_header");
Clazz.makeConstructor (c$, 
function (a, b) {
this.header = a;
this.packageCount = b;
}, "android.content.res.ResourceTypes.ResChunk_header,~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResChunk_header.sizeof () + 4;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.header = null;
this.id = 0;
this.name = null;
this.typeStrings = 0;
this.lastPublicType = 0;
this.keyStrings = 0;
this.lastPublicKey = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_package");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e, f, g) {
this.header = a;
this.id = b;
this.name = String.valueOf (c);
this.typeStrings = d;
this.lastPublicType = e;
this.keyStrings = f;
this.lastPublicKey = g;
}, "android.content.res.ResourceTypes.ResChunk_header,~N,~A,~N,~N,~N,~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResChunk_header.sizeof () + 20 + 256;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.size = 0;
this.mcc = 0;
this.mnc = 0;
this.language = null;
this.country = null;
this.orientation = 0;
this.touchscreen = 0;
this.density = 0;
this.keyboard = 0;
this.navigation = 0;
this.inputFlags = 0;
this.screenWidth = 0;
this.screenHeight = 0;
this.sdkVersion = 0;
this.minorVersion = 0;
this.screenLayout = 0;
this.uiMode = 0;
this.smallestScreenWidthDp = 0;
this.screenWidthDp = 0;
this.screenHeightDp = 0;
this.isInvalid = false;
this.mQualifiers = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_config");
Clazz.makeConstructor (c$, 
function () {
this.mcc = 0;
this.mnc = 0;
this.language = ['\00', '\00'];
this.country = ['\00', '\00'];
this.orientation = 0;
this.touchscreen = 0;
this.density = 0;
this.keyboard = 0;
this.navigation = 0;
this.inputFlags = 0;
this.screenWidth = 0;
this.screenHeight = 0;
this.sdkVersion = 0;
this.screenLayout = 0;
this.uiMode = 0;
this.smallestScreenWidthDp = 0;
this.screenWidthDp = 0;
this.screenHeightDp = 0;
this.isInvalid = false;
this.mQualifiers = "";
});
Clazz.makeConstructor (c$, 
function (a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s) {
if (e < 0 || e > 3) {
e = 0;
s = true;
}if (f < 0 || f > 3) {
f = 0;
s = true;
}if (g < -1) {
g = 0;
s = true;
}if (h < 0 || h > 3) {
h = 0;
s = true;
}if (i < 0 || i > 4) {
i = 0;
s = true;
}this.mcc = a;
this.mnc = b;
this.language = c;
this.country = d;
this.orientation = e;
this.touchscreen = f;
this.density = g;
this.keyboard = h;
this.navigation = i;
this.inputFlags = j;
this.screenWidth = k;
this.screenHeight = l;
this.sdkVersion = m;
this.screenLayout = n;
this.uiMode = o;
this.smallestScreenWidthDp = p;
this.screenWidthDp = q;
this.screenHeightDp = r;
this.isInvalid = s;
this.mQualifiers = this.generateQualifiers ();
}, "~N,~N,~A,~A,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~N,~B");
Clazz.defineMethod (c$, "getQualifiers", 
function () {
return this.mQualifiers;
});
Clazz.defineMethod (c$, "generateQualifiers", 
($fz = function () {
var a =  new StringBuilder ();
if (this.mcc != 0) {
a.append ("-mcc").append (this.mcc);
if (this.mnc != 0) {
a.append ("-mnc").append (this.mnc);
}}if ((this.language[0]).charCodeAt (0) != ('\00').charCodeAt (0)) {
a.append ('-').append (this.language);
if ((this.country[0]).charCodeAt (0) != ('\00').charCodeAt (0)) {
a.append ("-r").append (this.country);
}}if (this.smallestScreenWidthDp != 0) {
a.append ("-sw").append (this.smallestScreenWidthDp).append ("dp");
}if (this.screenWidthDp != 0) {
a.append ("-w").append (this.screenWidthDp).append ("dp");
}if (this.screenHeightDp != 0) {
a.append ("-h").append (this.screenHeightDp).append ("dp");
}switch (this.screenLayout & 15) {
case 1:
a.append ("-small");
break;
case 2:
a.append ("-normal");
break;
case 3:
a.append ("-large");
break;
case 4:
a.append ("-xlarge");
break;
}
switch (this.screenLayout & 48) {
case 32:
a.append ("-long");
break;
case 16:
a.append ("-notlong");
break;
}
switch (this.orientation) {
case 1:
a.append ("-port");
break;
case 2:
a.append ("-land");
break;
case 3:
a.append ("-square");
break;
}
switch (this.uiMode & 15) {
case 3:
a.append ("-car");
break;
case 2:
a.append ("-desk");
break;
case 4:
a.append ("-television");
break;
}
switch (this.uiMode & 48) {
case 32:
a.append ("-night");
break;
case 16:
a.append ("-notnight");
break;
}
switch (this.density) {
case 0:
break;
case 120:
a.append ("-ldpi");
break;
case 160:
a.append ("-mdpi");
break;
case 240:
a.append ("-hdpi");
break;
case 320:
a.append ("-xhdpi");
break;
case -1:
a.append ("-nodpi");
break;
default:
a.append ('-').append (this.density).append ("dpi");
}
switch (this.touchscreen) {
case 1:
a.append ("-notouch");
break;
case 2:
a.append ("-stylus");
break;
case 3:
a.append ("-finger");
break;
}
switch (this.inputFlags & 3) {
case 1:
a.append ("-keysexposed");
break;
case 2:
a.append ("-keyshidden");
break;
case 3:
a.append ("-keyssoft");
break;
}
switch (this.keyboard) {
case 1:
a.append ("-nokeys");
break;
case 2:
a.append ("-qwerty");
break;
case 3:
a.append ("-12key");
break;
}
switch (this.inputFlags & 12) {
case 4:
a.append ("-navexposed");
break;
case 8:
a.append ("-navhidden");
break;
}
switch (this.navigation) {
case 1:
a.append ("-nonav");
break;
case 2:
a.append ("-dpad");
break;
case 3:
a.append ("-trackball");
break;
case 4:
a.append ("-wheel");
break;
}
if (this.screenWidth != 0 && this.screenHeight != 0) {
if (this.screenWidth > this.screenHeight) {
a.append ("-" + this.screenWidth + "x" + this.screenHeight);
} else {
a.append ("-" + this.screenHeight + "x" + this.screenWidth);
}}if (this.sdkVersion > this.getNaturalSdkVersionRequirement ()) {
a.append ("-v").append (this.sdkVersion);
}return a.toString ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getNaturalSdkVersionRequirement", 
($fz = function () {
if (this.smallestScreenWidthDp != 0 || this.screenWidthDp != 0 || this.screenHeightDp != 0) {
return 13;
}if ((this.uiMode & (63)) != 0) {
return 8;
}if ((this.screenLayout & (63)) != 0 || this.density != 0) {
return 4;
}return 0;
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "toString", 
function () {
return !this.getQualifiers ().equals ("") ? this.getQualifiers () : "[DEFAULT]";
});
Clazz.overrideMethod (c$, "equals", 
function (a) {
if (a == null) {
return false;
}if (this.getClass () !== a.getClass ()) {
return false;
}var b = a;
return this.mQualifiers.equals (b.mQualifiers);
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
var a = 3;
a = 97 * a + this.mQualifiers.hashCode ();
return a;
});
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return 32;
});
Clazz.defineMethod (c$, "instance_sizeof", 
function () {
return this.size;
});
Clazz.defineMethod (c$, "copyFrom", 
function (a) {
this.size = a.size;
this.mcc = a.mcc;
this.mnc = a.mnc;
this.language = a.language;
this.country = a.country;
this.orientation = a.orientation;
this.touchscreen = a.touchscreen;
this.density = a.density;
this.keyboard = a.keyboard;
this.navigation = a.navigation;
this.inputFlags = a.inputFlags;
this.screenWidth = a.screenWidth;
this.screenHeight = a.screenHeight;
this.sdkVersion = a.sdkVersion;
this.screenLayout = a.screenLayout;
this.uiMode = a.uiMode;
this.smallestScreenWidthDp = a.smallestScreenWidthDp;
this.screenWidthDp = a.screenWidthDp;
this.screenHeightDp = a.screenHeightDp;
this.isInvalid = a.isInvalid;
this.mQualifiers = a.generateQualifiers ();
}, "android.content.res.ResourceTypes.ResTable_config");
Clazz.defineMethod (c$, "isBetterThan", 
function (a, b) {
if (b != null) {
if (this.density != a.density) {
var c = (this.density != 0 ? this.density : 160);
var d = (a.density != 0 ? a.density : 160);
var e = true;
if (d > c) {
var f = c;
c = d;
d = f;
e = false;
}var f = (b.density != 0 ? b.density : 160);
if (f >= c) {
return e;
}if (d >= f) {
return !e;
}if (((2 * d) - f) * c > f * f) {
return !e;
} else {
return e;
}}return false;
}return false;
}, "android.content.res.ResourceTypes.ResTable_config,android.content.res.ResourceTypes.ResTable_config");
Clazz.defineStatics (c$,
"ORIENTATION_ANY", 0,
"ORIENTATION_PORT", 1,
"ORIENTATION_LAND", 2,
"ORIENTATION_SQUARE", 3,
"TOUCHSCREEN_ANY", 0,
"TOUCHSCREEN_NOTOUCH", 1,
"TOUCHSCREEN_STYLUS", 2,
"TOUCHSCREEN_FINGER", 3,
"DENSITY_DEFAULT", 0,
"DENSITY_LOW", 120,
"DENSITY_MEDIUM", 160,
"DENSITY_HIGH", 240,
"DENSITY_XHIGH", 320,
"DENSITY_NONE", -1,
"KEYBOARD_ANY", 0,
"KEYBOARD_NOKEYS", 1,
"KEYBOARD_QWERTY", 2,
"KEYBOARD_12KEY", 3,
"NAVIGATION_ANY", 0,
"NAVIGATION_NONAV", 1,
"NAVIGATION_DPAD", 2,
"NAVIGATION_TRACKBALL", 3,
"NAVIGATION_WHEEL", 4,
"MASK_KEYSHIDDEN", 0x3,
"KEYSHIDDEN_ANY", 0x0,
"KEYSHIDDEN_NO", 0x1,
"KEYSHIDDEN_YES", 0x2,
"KEYSHIDDEN_SOFT", 0x3,
"MASK_NAVHIDDEN", 0xc,
"NAVHIDDEN_ANY", 0x0,
"NAVHIDDEN_NO", 0x4,
"NAVHIDDEN_YES", 0x8,
"MASK_SCREENSIZE", 0x0f,
"SCREENSIZE_ANY", 0x00,
"SCREENSIZE_SMALL", 0x01,
"SCREENSIZE_NORMAL", 0x02,
"SCREENSIZE_LARGE", 0x03,
"SCREENSIZE_XLARGE", 0x04,
"MASK_SCREENLONG", 0x30,
"SCREENLONG_ANY", 0x00,
"SCREENLONG_NO", 0x10,
"SCREENLONG_YES", 0x20,
"MASK_UI_MODE_TYPE", 0x0f,
"UI_MODE_TYPE_ANY", 0x00,
"UI_MODE_TYPE_NORMAL", 0x01,
"UI_MODE_TYPE_DESK", 0x02,
"UI_MODE_TYPE_CAR", 0x03,
"UI_MODE_TYPE_TELEVISION", 0x04,
"MASK_UI_MODE_NIGHT", 0x30,
"UI_MODE_NIGHT_ANY", 0x00,
"UI_MODE_NIGHT_NO", 0x10,
"UI_MODE_NIGHT_YES", 0x20);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.header = null;
this.id = 0;
this.res0 = 0;
this.res1 = 0;
this.entryCount = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_typeSpec");
Clazz.makeConstructor (c$, 
function (a, b, c, d, e) {
this.header = a;
this.id = b;
this.res0 = c;
this.res1 = d;
this.entryCount = e;
}, "android.content.res.ResourceTypes.ResChunk_header,~N,~N,~N,~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResChunk_header.sizeof () + 2 + 2 + 4;
});
Clazz.defineStatics (c$,
"SPEC_PUBLIC", 0x40000000);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.base = 0;
this.data = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResPointers");
Clazz.makeConstructor (c$, 
function (a, b) {
this.base = a;
this.data = b;
}, "~N,~A");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.header = null;
this.id = 0;
this.res0 = 0;
this.res1 = 0;
this.entryCount = 0;
this.entriesStart = 0;
this.config = null;
this.resPointers = null;
this.resources = null;
this.entryOffsets = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_type");
Clazz.prepareFields (c$, function () {
this.resources =  new java.util.HashMap ();
});
Clazz.makeConstructor (c$, 
function (a, b, c, d, e, f) {
this.header = a;
this.id = b;
this.res0 = c;
this.res1 = d;
this.entryCount = e;
this.entriesStart = f;
}, "android.content.res.ResourceTypes.ResChunk_header,~N,~N,~N,~N,~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResChunk_header.sizeof () + 2 + 2 + 8 + android.content.res.ResourceTypes.ResTable_config.sizeof ();
});
Clazz.defineStatics (c$,
"NO_ENTRY", 0xFFFFFFFF);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.size = 0;
this.flags = 0;
this.key = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_entry");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.size = a;
this.flags = b;
this.key = c;
}, "~N,~N,android.content.res.ResourceTypes.ResStringPool_ref");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return 4 + android.content.res.ResourceTypes.ResStringPool_ref.sizeof ();
});
Clazz.defineMethod (c$, "instance_sizeof", 
function () {
return this.size;
});
Clazz.defineStatics (c$,
"FLAG_COMPLEX", 0x0001,
"FLAG_PUBLIC", 0x0002);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.value = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_value_entry", android.content.res.ResourceTypes.ResTable_entry);
Clazz.prepareFields (c$, function () {
this.value =  new android.content.res.ResourceTypes.Res_value ();
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.parent = null;
this.count = 0;
this.entries = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_map_entry", android.content.res.ResourceTypes.ResTable_entry);
Clazz.makeConstructor (c$, 
function (a, b, c, d, e) {
Clazz.superConstructor (this, android.content.res.ResourceTypes.ResTable_map_entry, [a, b, c]);
this.parent = d;
this.count = e;
}, "~N,~N,android.content.res.ResourceTypes.ResStringPool_ref,android.content.res.ResourceTypes.ResTable_ref,~N");
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResTable_entry.sizeof () + android.content.res.ResourceTypes.ResTable_ref.sizeof () + 4;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.name = null;
this.value = null;
Clazz.instantialize (this, arguments);
}, android.content.res.ResourceTypes, "ResTable_map");
Clazz.prepareFields (c$, function () {
this.name =  new android.content.res.ResourceTypes.ResTable_ref (0);
this.value =  new android.content.res.ResourceTypes.Res_value ();
});
c$.sizeof = Clazz.defineMethod (c$, "sizeof", 
function () {
return android.content.res.ResourceTypes.ResTable_ref.sizeof () + android.content.res.ResourceTypes.Res_value.sizeof ();
});
Clazz.makeConstructor (c$, 
function (a, b) {
this.name.ident = a.ident;
this.value.copyFrom (b);
}, "android.content.res.ResourceTypes.ResTable_ref,android.content.res.ResourceTypes.Res_value");
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineStatics (c$,
"ATTR_TYPE", (16777216),
"ATTR_MIN", (16777217),
"ATTR_MAX", (16777218),
"ATTR_L10N", (16777219),
"ATTR_OTHER", (16777220),
"ATTR_ZERO", (16777221),
"ATTR_ONE", (16777222),
"ATTR_TWO", (16777223),
"ATTR_FEW", (16777224),
"ATTR_MANY", (16777225),
"TYPE_ANY", 0x0000FFFF,
"TYPE_REFERENCE", 1,
"TYPE_STRING", 2,
"TYPE_INTEGER", 4,
"TYPE_BOOLEAN", 8,
"TYPE_COLOR", 16,
"TYPE_FLOAT", 32,
"TYPE_DIMENSION", 64,
"TYPE_FRACTION", 128,
"TYPE_ENUM", 65536,
"TYPE_FLAGS", 131072,
"L10N_NOT_REQUIRED", 0,
"L10N_SUGGESTED", 1);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"ENTRY_FLAG_COMPLEX", 0x00000001,
"RES_NULL_TYPE", 0x0000,
"RES_STRING_POOL_TYPE", 0x0001,
"RES_TABLE_TYPE", 0x0002,
"RES_XML_TYPE", 0x0003,
"RES_XML_FIRST_CHUNK_TYPE", 0x0100,
"RES_XML_START_NAMESPACE_TYPE", 0x0100,
"RES_XML_END_NAMESPACE_TYPE", 0x0101,
"RES_XML_START_ELEMENT_TYPE", 0x0102,
"RES_XML_END_ELEMENT_TYPE", 0x0103,
"RES_XML_CDATA_TYPE", 0x0104,
"RES_XML_LAST_CHUNK_TYPE", 0x017f,
"RES_XML_RESOURCE_MAP_TYPE", 0x0180,
"RES_TABLE_PACKAGE_TYPE", 0x0200,
"RES_TABLE_TYPE_TYPE", 0x0201,
"RES_TABLE_TYPE_SPEC_TYPE", 0x0202);
});
