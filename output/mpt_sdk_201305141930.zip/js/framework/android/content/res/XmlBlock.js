﻿Clazz.declarePackage ("android.content.res");
Clazz.load (["android.content.res.XmlResourceParser"], "android.content.res.XmlBlock", ["android.content.res.ResXMLParser", "$.ResXMLTree", "$.StringBlock", "android.util.TypedValue", "com.android.internal.util.XmlUtils", "java.lang.Float", "$.IndexOutOfBoundsException", "$.RuntimeException", "org.xmlpull.v1.XmlPullParser", "$.XmlPullParserException"], function () {
c$ = Clazz.decorateAsClass (function () {
if (!Clazz.isClassDefined ("android.content.res.XmlBlock.Parser")) {
android.content.res.XmlBlock.$XmlBlock$Parser$ ();
}
this.mAssets = null;
this.mNative = null;
this.mStrings = null;
this.mOpen = true;
this.mOpenCount = 1;
Clazz.instantialize (this, arguments);
}, android.content.res, "XmlBlock");
Clazz.makeConstructor (c$, 
function (assets, xmlBlock) {
this.mAssets = assets;
this.mNative = xmlBlock;
this.mStrings =  new android.content.res.StringBlock (android.content.res.XmlBlock.nativeGetStringBlock (xmlBlock), false);
}, "android.content.res.AssetManager,android.content.res.ResXMLTree");
Clazz.makeConstructor (c$, 
function (data) {
this.mAssets = null;
this.mNative = android.content.res.XmlBlock.nativeCreate (data, 0, data.length);
this.mStrings =  new android.content.res.StringBlock (android.content.res.XmlBlock.nativeGetStringBlock (this.mNative), false);
}, "~A");
Clazz.makeConstructor (c$, 
function (data, offset, size) {
this.mAssets = null;
this.mNative = android.content.res.XmlBlock.nativeCreate (data, offset, size);
this.mStrings =  new android.content.res.StringBlock (android.content.res.XmlBlock.nativeGetStringBlock (this.mNative), false);
}, "~A,~N,~N");
Clazz.defineMethod (c$, "close", 
function () {
if (this.mOpen) {
this.mOpen = false;
this.decOpenCountLocked ();
}});
Clazz.defineMethod (c$, "decOpenCountLocked", 
($fz = function () {
this.mOpenCount--;
if (this.mOpenCount == 0) {
android.content.res.XmlBlock.nativeDestroy (this.mNative);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "newParser", 
function () {
if (this.mNative != null) {
return Clazz.innerTypeInstance (android.content.res.XmlBlock.Parser, this, null, android.content.res.XmlBlock.nativeCreateParseState (this.mNative), this);
}return null;
});
Clazz.overrideMethod (c$, "finalize", 
function () {
this.close ();
});
c$.nativeCreate = Clazz.defineMethod (c$, "nativeCreate", 
($fz = function (data, offset, size) {
var osb =  new android.content.res.ResXMLTree (data, offset, size, true);
if (osb == null || osb.getError () != 0) {
return null;
}return osb;
}, $fz.isPrivate = true, $fz), "~A,~N,~N");
c$.nativeGetStringBlock = Clazz.defineMethod (c$, "nativeGetStringBlock", 
($fz = function (obj) {
if (obj == null) return null;
return obj.getStrings ();
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLTree");
c$.nativeCreateParseState = Clazz.defineMethod (c$, "nativeCreateParseState", 
($fz = function (obj) {
var st =  new android.content.res.ResXMLParser (obj);
st.restart ();
return st;
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLTree");
c$.nativeNext = Clazz.defineMethod (c$, "nativeNext", 
($fz = function (state) {
if (state == null) return 1;
do {
var code = state.next ();
switch (code) {
case 258:
return 2;
case 259:
return 3;
case 260:
return 4;
case 0:
return 0;
case 1:
return 1;
case -1:
return -1;
}
} while (true);
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeGetNamespace = Clazz.defineMethod (c$, "nativeGetNamespace", 
($fz = function (state) {
if (state == null) return -1;
return state.getElementNamespaceID ();
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeGetName = Clazz.defineMethod (c$, "nativeGetName", 
($fz = function (state) {
if (state == null) return -1;
return state.getElementNameID ();
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeGetText = Clazz.defineMethod (c$, "nativeGetText", 
($fz = function (state) {
if (state == null) return -1;
return state.getTextID ();
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeGetLineNumber = Clazz.defineMethod (c$, "nativeGetLineNumber", 
($fz = function (state) {
if (state == null) return 0;
return state.getLineNumber ();
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeGetAttributeCount = Clazz.defineMethod (c$, "nativeGetAttributeCount", 
($fz = function (state) {
if (state == null) return 0;
return state.getAttributeCount ();
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeGetAttributeNamespace = Clazz.defineMethod (c$, "nativeGetAttributeNamespace", 
($fz = function (state, idx) {
if (state == null) return 0;
return state.getAttributeNamespaceID (idx);
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser,~N");
c$.nativeGetAttributeName = Clazz.defineMethod (c$, "nativeGetAttributeName", 
($fz = function (state, idx) {
if (state == null) return 0;
return state.getAttributeNameID (idx);
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser,~N");
c$.nativeGetAttributeResource = Clazz.defineMethod (c$, "nativeGetAttributeResource", 
($fz = function (state, idx) {
if (state == null) return 0;
return state.getAttributeNameResID (idx);
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser,~N");
c$.nativeGetAttributeDataType = Clazz.defineMethod (c$, "nativeGetAttributeDataType", 
($fz = function (state, idx) {
if (state == null) return 0;
return state.getAttributeDataType (idx);
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser,~N");
c$.nativeGetAttributeData = Clazz.defineMethod (c$, "nativeGetAttributeData", 
($fz = function (state, idx) {
if (state == null) return 0;
return state.getAttributeData (idx);
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser,~N");
c$.nativeGetAttributeStringValue = Clazz.defineMethod (c$, "nativeGetAttributeStringValue", 
($fz = function (state, idx) {
if (state == null) return 0;
return state.getAttributeValueStringID (idx);
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser,~N");
c$.nativeGetAttributeIndex = Clazz.defineMethod (c$, "nativeGetAttributeIndex", 
($fz = function (state, namespace, name) {
if (state == null || name == null) return 0;
var idx = state.indexOfAttribute (namespace, name);
return idx;
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser,~S,~S");
c$.nativeGetIdAttribute = Clazz.defineMethod (c$, "nativeGetIdAttribute", 
($fz = function (state) {
if (state == null) return 0;
var idx = state.indexOfID ();
return idx >= 0 ? state.getAttributeValueStringID (idx) : -1;
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeGetClassAttribute = Clazz.defineMethod (c$, "nativeGetClassAttribute", 
($fz = function (state) {
if (state == null) return 0;
var idx = state.indexOfClass ();
return idx >= 0 ? state.getAttributeValueStringID (idx) : -1;
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeGetStyleAttribute = Clazz.defineMethod (c$, "nativeGetStyleAttribute", 
($fz = function (state) {
if (state == null) return 0;
var idx = state.indexOfStyle ();
return idx >= 0 ? state.getAttributeValueStringID (idx) : -1;
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeDestroyParseState = Clazz.defineMethod (c$, "nativeDestroyParseState", 
($fz = function (state) {
state = null;
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser");
c$.nativeDestroy = Clazz.defineMethod (c$, "nativeDestroy", 
($fz = function (obj) {
obj = null;
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLTree");
c$.nativeGetAttributeValueType = Clazz.defineMethod (c$, "nativeGetAttributeValueType", 
($fz = function (state, idx) {
if (state == null) return 0;
return idx >= 0 ? state.getAttributeDataType (idx) : 0;
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser,~N");
c$.nativeGetAttributeValueData = Clazz.defineMethod (c$, "nativeGetAttributeValueData", 
($fz = function (state, idx) {
if (state == null) return -1;
return idx >= 0 ? state.getAttributeData (idx) : -1;
}, $fz.isPrivate = true, $fz), "android.content.res.ResXMLParser,~N");
c$.$XmlBlock$Parser$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mParseState = null;
this.mBlock = null;
this.mStarted = false;
this.mDecNextDepth = false;
this.mDepth = 0;
this.mEventType = 0;
Clazz.instantialize (this, arguments);
}, android.content.res.XmlBlock, "Parser", null, android.content.res.XmlResourceParser);
Clazz.makeConstructor (c$, 
function (a, b) {
this.mParseState = a;
this.mBlock = b;
b.mOpenCount++;
}, "android.content.res.ResXMLParser,android.content.res.XmlBlock");
Clazz.overrideMethod (c$, "setFeature", 
function (a, b) {
if ("http://xmlpull.org/v1/doc/features.html#process-namespaces".equals (a) && b) {
return ;
}if ("http://xmlpull.org/v1/doc/features.html#report-namespace-prefixes".equals (a) && b) {
return ;
}throw  new org.xmlpull.v1.XmlPullParserException ("Unsupported feature: " + a);
}, "~S,~B");
Clazz.overrideMethod (c$, "getFeature", 
function (a) {
if ("http://xmlpull.org/v1/doc/features.html#process-namespaces".equals (a)) {
return true;
}if ("http://xmlpull.org/v1/doc/features.html#report-namespace-prefixes".equals (a)) {
return true;
}return false;
}, "~S");
Clazz.overrideMethod (c$, "setProperty", 
function (a, b) {
throw  new org.xmlpull.v1.XmlPullParserException ("setProperty() not supported");
}, "~S,~O");
Clazz.overrideMethod (c$, "getProperty", 
function (a) {
return null;
}, "~S");
Clazz.defineMethod (c$, "setInput", 
function (a) {
throw  new org.xmlpull.v1.XmlPullParserException ("setInput() not supported");
}, "java.io.Reader");
Clazz.defineMethod (c$, "setInput", 
function (a, b) {
throw  new org.xmlpull.v1.XmlPullParserException ("setInput() not supported");
}, "java.io.InputStream,~S");
Clazz.overrideMethod (c$, "defineEntityReplacementText", 
function (a, b) {
throw  new org.xmlpull.v1.XmlPullParserException ("defineEntityReplacementText() not supported");
}, "~S,~S");
Clazz.overrideMethod (c$, "getNamespacePrefix", 
function (a) {
throw  new org.xmlpull.v1.XmlPullParserException ("getNamespacePrefix() not supported");
}, "~N");
Clazz.overrideMethod (c$, "getInputEncoding", 
function () {
return null;
});
Clazz.defineMethod (c$, "getNamespace", 
function (a) {
throw  new RuntimeException ("getNamespace() not supported");
}, "~S");
Clazz.overrideMethod (c$, "getNamespaceCount", 
function (a) {
throw  new org.xmlpull.v1.XmlPullParserException ("getNamespaceCount() not supported");
}, "~N");
Clazz.overrideMethod (c$, "getPositionDescription", 
function () {
return "Binary XML file line #" + this.getLineNumber ();
});
Clazz.overrideMethod (c$, "getNamespaceUri", 
function (a) {
throw  new org.xmlpull.v1.XmlPullParserException ("getNamespaceUri() not supported");
}, "~N");
Clazz.overrideMethod (c$, "getColumnNumber", 
function () {
return -1;
});
Clazz.overrideMethod (c$, "getDepth", 
function () {
return this.mDepth;
});
Clazz.overrideMethod (c$, "getText", 
function () {
var a = android.content.res.XmlBlock.nativeGetText (this.mParseState);
return a >= 0 ? this.b$["android.content.res.XmlBlock"].mStrings.get (a).toString () : null;
});
Clazz.overrideMethod (c$, "getLineNumber", 
function () {
return android.content.res.XmlBlock.nativeGetLineNumber (this.mParseState);
});
Clazz.overrideMethod (c$, "getEventType", 
function () {
return this.mEventType;
});
Clazz.overrideMethod (c$, "isWhitespace", 
function () {
return false;
});
Clazz.overrideMethod (c$, "getPrefix", 
function () {
throw  new RuntimeException ("getPrefix not supported");
});
Clazz.overrideMethod (c$, "getTextCharacters", 
function (a) {
var b = this.getText ();
var c = null;
if (b != null) {
a[0] = 0;
a[1] = b.length;
c =  Clazz.newArray (b.length, '\0');
b.getChars (0, b.length, c, 0);
}return c;
}, "~A");
Clazz.defineMethod (c$, "getNamespace", 
function () {
var a = android.content.res.XmlBlock.nativeGetNamespace (this.mParseState);
return a >= 0 ? this.b$["android.content.res.XmlBlock"].mStrings.get (a).toString () : "";
});
Clazz.overrideMethod (c$, "getName", 
function () {
var a = android.content.res.XmlBlock.nativeGetName (this.mParseState);
return a >= 0 ? this.b$["android.content.res.XmlBlock"].mStrings.get (a).toString () : null;
});
Clazz.overrideMethod (c$, "getAttributeNamespace", 
function (a) {
var b = android.content.res.XmlBlock.nativeGetAttributeNamespace (this.mParseState, a);
if (false) System.out.println ("getAttributeNamespace of " + a + " = " + b);
if (b >= 0) return this.b$["android.content.res.XmlBlock"].mStrings.get (b).toString ();
 else if (b == -1) return "";
throw  new IndexOutOfBoundsException (String.valueOf (a));
}, "~N");
Clazz.overrideMethod (c$, "getAttributeName", 
function (a) {
var b = android.content.res.XmlBlock.nativeGetAttributeName (this.mParseState, a);
if (false) System.out.println ("getAttributeName of " + a + " = " + b);
if (b >= 0) return this.b$["android.content.res.XmlBlock"].mStrings.get (b).toString ();
throw  new IndexOutOfBoundsException (String.valueOf (a));
}, "~N");
Clazz.overrideMethod (c$, "getAttributePrefix", 
function (a) {
throw  new RuntimeException ("getAttributePrefix not supported");
}, "~N");
Clazz.overrideMethod (c$, "isEmptyElementTag", 
function () {
return false;
});
Clazz.overrideMethod (c$, "getAttributeCount", 
function () {
return this.mEventType == 2 ? android.content.res.XmlBlock.nativeGetAttributeCount (this.mParseState) : -1;
});
Clazz.defineMethod (c$, "getAttributeValue", 
function (a) {
var b = android.content.res.XmlBlock.nativeGetAttributeStringValue (this.mParseState, a);
if (false) System.out.println ("getAttributeValue of " + a + " = " + b);
if (b >= 0) return this.b$["android.content.res.XmlBlock"].mStrings.get (b).toString ();
var c = android.content.res.XmlBlock.nativeGetAttributeDataType (this.mParseState, a);
if (c == 0) {
throw  new IndexOutOfBoundsException (String.valueOf (a));
}var d = android.content.res.XmlBlock.nativeGetAttributeData (this.mParseState, a);
return android.util.TypedValue.coerceToString (c, d);
}, "~N");
Clazz.overrideMethod (c$, "getAttributeType", 
function (a) {
return "CDATA";
}, "~N");
Clazz.overrideMethod (c$, "isAttributeDefault", 
function (a) {
return false;
}, "~N");
Clazz.overrideMethod (c$, "nextToken", 
function () {
return this.next ();
});
Clazz.defineMethod (c$, "getAttributeValue", 
function (a, b) {
var c = android.content.res.XmlBlock.nativeGetAttributeIndex (this.mParseState, a, b);
if (c >= 0) {
if (false) System.out.println ("getAttributeName of " + a + ":" + b + " index = " + c);
if (false) System.out.println ("Namespace=" + this.getAttributeNamespace (c) + "Name=" + this.getAttributeName (c) + ", Value=" + this.getAttributeValue (c));
return this.getAttributeValue (c);
}return null;
}, "~S,~S");
Clazz.overrideMethod (c$, "next", 
function () {
if (!this.mStarted) {
this.mStarted = true;
return 0;
}if (this.mParseState == null) {
return 1;
}var a = android.content.res.XmlBlock.nativeNext (this.mParseState);
if (this.mDecNextDepth) {
this.mDepth--;
this.mDecNextDepth = false;
}switch (a) {
case 2:
this.mDepth++;
break;
case 3:
this.mDecNextDepth = true;
break;
}
this.mEventType = a;
if (a == 1) {
this.close ();
}return a;
});
Clazz.overrideMethod (c$, "require", 
function (a, b, c) {
if (a != this.getEventType () || (b != null && !b.equals (this.getNamespace ())) || (c != null && !c.equals (this.getName ()))) throw  new org.xmlpull.v1.XmlPullParserException ("expected " + org.xmlpull.v1.XmlPullParser.TYPES[a] + this.getPositionDescription ());
}, "~N,~S,~S");
Clazz.overrideMethod (c$, "nextText", 
function () {
if (this.getEventType () != 2) {
throw  new org.xmlpull.v1.XmlPullParserException (this.getPositionDescription () + ": parser must be on START_TAG to read next text", this, null);
}var a = this.next ();
if (a == 4) {
var b = this.getText ();
a = this.next ();
if (a != 3) {
throw  new org.xmlpull.v1.XmlPullParserException (this.getPositionDescription () + ": event TEXT it must be immediately followed by END_TAG", this, null);
}return b;
} else if (a == 3) {
return "";
} else {
throw  new org.xmlpull.v1.XmlPullParserException (this.getPositionDescription () + ": parser must be on START_TAG or TEXT to read text", this, null);
}});
Clazz.overrideMethod (c$, "nextTag", 
function () {
var a = this.next ();
if (a == 4 && this.isWhitespace ()) {
a = this.next ();
}if (a != 2 && a != 3) {
throw  new org.xmlpull.v1.XmlPullParserException (this.getPositionDescription () + ": expected start or end tag", this, null);
}return a;
});
Clazz.overrideMethod (c$, "getAttributeNameResource", 
function (a) {
return android.content.res.XmlBlock.nativeGetAttributeResource (this.mParseState, a);
}, "~N");
Clazz.defineMethod (c$, "getAttributeListValue", 
function (a, b, c, d) {
var e = android.content.res.XmlBlock.nativeGetAttributeIndex (this.mParseState, a, b);
if (e >= 0) {
return this.getAttributeListValue (e, c, d);
}return d;
}, "~S,~S,~A,~N");
Clazz.defineMethod (c$, "getAttributeBooleanValue", 
function (a, b, c) {
var d = android.content.res.XmlBlock.nativeGetAttributeIndex (this.mParseState, a, b);
if (d >= 0) {
return this.getAttributeBooleanValue (d, c);
}return c;
}, "~S,~S,~B");
Clazz.defineMethod (c$, "getAttributeResourceValue", 
function (a, b, c) {
var d = android.content.res.XmlBlock.nativeGetAttributeIndex (this.mParseState, a, b);
if (d >= 0) {
return this.getAttributeResourceValue (d, c);
}return c;
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getAttributeIntValue", 
function (a, b, c) {
var d = android.content.res.XmlBlock.nativeGetAttributeIndex (this.mParseState, a, b);
if (d >= 0) {
return this.getAttributeIntValue (d, c);
}return c;
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getAttributeUnsignedIntValue", 
function (a, b, c) {
var d = android.content.res.XmlBlock.nativeGetAttributeIndex (this.mParseState, a, b);
if (d >= 0) {
return this.getAttributeUnsignedIntValue (d, c);
}return c;
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getAttributeFloatValue", 
function (a, b, c) {
var d = android.content.res.XmlBlock.nativeGetAttributeIndex (this.mParseState, a, b);
if (d >= 0) {
return this.getAttributeFloatValue (d, c);
}return c;
}, "~S,~S,~N");
Clazz.defineMethod (c$, "getAttributeListValue", 
function (a, b, c) {
var d = android.content.res.XmlBlock.nativeGetAttributeDataType (this.mParseState, a);
var e = android.content.res.XmlBlock.nativeGetAttributeData (this.mParseState, a);
if (d == 3) {
return com.android.internal.util.XmlUtils.convertValueToList (this.b$["android.content.res.XmlBlock"].mStrings.get (e), b, c);
}return e;
}, "~N,~A,~N");
Clazz.defineMethod (c$, "getAttributeBooleanValue", 
function (a, b) {
var c = android.content.res.XmlBlock.nativeGetAttributeDataType (this.mParseState, a);
if (c >= 16 && c <= 31) {
return android.content.res.XmlBlock.nativeGetAttributeData (this.mParseState, a) != 0;
}return b;
}, "~N,~B");
Clazz.defineMethod (c$, "getAttributeResourceValue", 
function (a, b) {
var c = android.content.res.XmlBlock.nativeGetAttributeDataType (this.mParseState, a);
if (c == 1) {
return android.content.res.XmlBlock.nativeGetAttributeData (this.mParseState, a);
}return b;
}, "~N,~N");
Clazz.defineMethod (c$, "getAttributeIntValue", 
function (a, b) {
var c = android.content.res.XmlBlock.nativeGetAttributeDataType (this.mParseState, a);
if (c >= 16 && c <= 31) {
return android.content.res.XmlBlock.nativeGetAttributeData (this.mParseState, a);
}return b;
}, "~N,~N");
Clazz.defineMethod (c$, "getAttributeUnsignedIntValue", 
function (a, b) {
var c = android.content.res.XmlBlock.nativeGetAttributeDataType (this.mParseState, a);
if (c >= 16 && c <= 31) {
return android.content.res.XmlBlock.nativeGetAttributeData (this.mParseState, a);
}return b;
}, "~N,~N");
Clazz.defineMethod (c$, "getAttributeFloatValue", 
function (a, b) {
var c = android.content.res.XmlBlock.nativeGetAttributeDataType (this.mParseState, a);
if (c == 4) {
return Float.intBitsToFloat (android.content.res.XmlBlock.nativeGetAttributeData (this.mParseState, a));
}throw  new RuntimeException ("not a float!");
}, "~N,~N");
Clazz.overrideMethod (c$, "getIdAttribute", 
function () {
var a = android.content.res.XmlBlock.nativeGetIdAttribute (this.mParseState);
return a >= 0 ? this.b$["android.content.res.XmlBlock"].mStrings.get (a).toString () : null;
});
Clazz.overrideMethod (c$, "getClassAttribute", 
function () {
var a = android.content.res.XmlBlock.nativeGetClassAttribute (this.mParseState);
return a >= 0 ? this.b$["android.content.res.XmlBlock"].mStrings.get (a).toString () : null;
});
Clazz.overrideMethod (c$, "getIdAttributeResourceValue", 
function (a) {
return this.getAttributeResourceValue (null, "id", a);
}, "~N");
Clazz.overrideMethod (c$, "getStyleAttribute", 
function () {
return android.content.res.XmlBlock.nativeGetStyleAttribute (this.mParseState);
});
Clazz.overrideMethod (c$, "close", 
function () {
if (this.mParseState != null) {
android.content.res.XmlBlock.nativeDestroyParseState (this.mParseState);
this.mParseState = null;
this.mBlock.decOpenCountLocked ();
}});
Clazz.overrideMethod (c$, "finalize", 
function () {
this.close ();
});
Clazz.defineMethod (c$, "getPooledString", 
function (a) {
return this.b$["android.content.res.XmlBlock"].mStrings.get (a);
}, "~N");
Clazz.overrideMethod (c$, "getAttributeValueType", 
function (a) {
return android.content.res.XmlBlock.nativeGetAttributeValueType (this.mParseState, a);
}, "~N");
Clazz.overrideMethod (c$, "getAttributeValueData", 
function (a) {
return android.content.res.XmlBlock.nativeGetAttributeValueData (this.mParseState, a);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"DEBUG", false);
});
