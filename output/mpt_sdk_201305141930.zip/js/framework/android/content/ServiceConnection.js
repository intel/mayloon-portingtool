﻿Clazz.declarePackage ("android.content");
Clazz.declareInterface (android.content, "ServiceConnection");
