﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.content.Context"], "android.content.ContextWrapper", ["java.lang.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mBase = null;
Clazz.instantialize (this, arguments);
}, android.content, "ContextWrapper", android.content.Context);
Clazz.makeConstructor (c$, 
function (base) {
Clazz.superConstructor (this, android.content.ContextWrapper, []);
this.mBase = base;
}, "android.content.Context");
Clazz.defineMethod (c$, "attachBaseContext", 
function (base) {
if (this.mBase != null) {
throw  new IllegalStateException ("Base context already set");
}this.mBase = base;
}, "android.content.Context");
Clazz.defineMethod (c$, "getBaseContext", 
function () {
return this.mBase;
});
Clazz.defineMethod (c$, "getApplicationContext", 
function () {
return this.mBase.getApplicationContext ();
});
Clazz.defineMethod (c$, "getResources", 
function () {
return this.mBase.getResources ();
});
Clazz.defineMethod (c$, "getPackageManager", 
function () {
return this.mBase.getPackageManager ();
});
Clazz.defineMethod (c$, "setTheme", 
function (resid) {
this.mBase.setTheme (resid);
}, "~N");
Clazz.defineMethod (c$, "getTheme", 
function () {
return this.mBase.getTheme ();
});
Clazz.defineMethod (c$, "getClassLoader", 
function () {
return this.mBase.getClassLoader ();
});
Clazz.defineMethod (c$, "getPackageName", 
function () {
return this.mBase.getPackageName ();
});
Clazz.defineMethod (c$, "isRestricted", 
function () {
return this.mBase.isRestricted ();
});
Clazz.defineMethod (c$, "startActivity", 
function (intent) {
this.mBase.startActivity (intent);
}, "android.content.Intent");
Clazz.defineMethod (c$, "startService", 
function (service) {
return this.mBase.startService (service);
}, "android.content.Intent");
Clazz.defineMethod (c$, "bindService", 
function (service, conn, flags) {
return this.mBase.bindService (service, conn, flags);
}, "android.content.Intent,android.content.ServiceConnection,~N");
Clazz.defineMethod (c$, "unbindService", 
function (conn) {
this.mBase.unbindService (conn);
}, "android.content.ServiceConnection");
Clazz.defineMethod (c$, "registerReceiver", 
function (receiver, filter) {
return this.mBase.registerReceiver (receiver, filter);
}, "android.content.BroadcastReceiver,android.content.IntentFilter");
Clazz.defineMethod (c$, "registerReceiver", 
function (receiver, filter, broadcastPermission, scheduler) {
return this.mBase.registerReceiver (receiver, filter, broadcastPermission, scheduler);
}, "android.content.BroadcastReceiver,android.content.IntentFilter,~S,android.os.Handler");
});
