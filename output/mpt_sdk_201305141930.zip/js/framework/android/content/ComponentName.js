﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.os.Parcelable"], "android.content.ComponentName", ["java.lang.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPackage = null;
this.mClass = null;
Clazz.instantialize (this, arguments);
}, android.content, "ComponentName", null, [android.os.Parcelable, Cloneable, Comparable]);
Clazz.makeConstructor (c$, 
function (pkg, cls) {
if (pkg == null) throw  new NullPointerException ("package name is null");
if (cls == null) throw  new NullPointerException ("class name is null");
this.mPackage = pkg;
this.mClass = cls;
}, "~S,~S");
Clazz.makeConstructor (c$, 
function (pkg, cls) {
if (cls == null) throw  new NullPointerException ("class name is null");
this.mPackage = pkg.getPackageName ();
this.mClass = cls;
}, "android.content.Context,~S");
Clazz.makeConstructor (c$, 
function (pkg, cls) {
this.mPackage = pkg.getPackageName ();
this.mClass = cls.getName ();
}, "android.content.Context,Class");
Clazz.overrideMethod (c$, "clone", 
function () {
return  new android.content.ComponentName (this.mPackage, this.mClass);
});
Clazz.defineMethod (c$, "getPackageName", 
function () {
return this.mPackage;
});
Clazz.defineMethod (c$, "getClassName", 
function () {
return this.mClass;
});
Clazz.defineMethod (c$, "getShortClassName", 
function () {
if (this.mClass.startsWith (this.mPackage)) {
var PN = this.mPackage.length;
var CN = this.mClass.length;
if (CN > PN && (this.mClass.charAt (PN)).charCodeAt (0) == ('.').charCodeAt (0)) {
return this.mClass.substring (PN, CN);
}}return this.mClass;
});
Clazz.defineMethod (c$, "flattenToString", 
function () {
return this.mPackage + "/" + this.mClass;
});
Clazz.defineMethod (c$, "flattenToShortString", 
function () {
return this.mPackage + this.getShortClassName ();
});
c$.unflattenFromString = Clazz.defineMethod (c$, "unflattenFromString", 
function (str) {
var sep = str.indexOf ('/');
if (sep < 0 || (sep + 1) >= str.length) {
return null;
}var pkg = str.substring (0, sep);
var cls = str.substring (sep + 1);
if (cls.length > 0 && (cls.charAt (0)).charCodeAt (0) == ('.').charCodeAt (0)) {
cls = pkg + cls;
}return  new android.content.ComponentName (pkg, cls);
}, "~S");
Clazz.defineMethod (c$, "toShortString", 
function () {
return "{" + this.mPackage + "/" + this.mClass + "}";
});
Clazz.overrideMethod (c$, "toString", 
function () {
return "ComponentInfo{" + this.mPackage + "/" + this.mClass + "}";
});
Clazz.overrideMethod (c$, "equals", 
function (obj) {
try {
if (obj != null) {
var other = obj;
return this.mPackage.equals (other.mPackage) && this.mClass.equals (other.mClass);
}} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
} else {
throw e;
}
}
return false;
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.mPackage.hashCode () + this.mClass.hashCode ();
});
Clazz.overrideMethod (c$, "compareTo", 
function (that) {
var v;
v = this.mPackage.compareTo (that.mPackage);
if (v != 0) {
return v;
}return this.mClass.compareTo (that.mClass);
}, "android.content.ComponentName");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
c$.readFromParcel = Clazz.defineMethod (c$, "readFromParcel", 
function ($in) {
console.log("Missing method: readFromParcel");
}, "android.os.Parcel");
});
