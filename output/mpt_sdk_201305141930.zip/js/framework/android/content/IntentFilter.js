﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.os.Parcelable", "android.util.AndroidException"], "android.content.IntentFilter", ["android.os.PatternMatcher", "android.util.Log", "java.lang.RuntimeException", "$.StringBuilder", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPriority = 0;
this.mActions = null;
this.mCategories = null;
this.mDataSchemes = null;
this.mDataAuthorities = null;
this.mDataTypes = null;
this.mHasPartialTypes = false;
this.mDataPaths = null;
Clazz.instantialize (this, arguments);
}, android.content, "IntentFilter", null, android.os.Parcelable);
c$.findStringInSet = Clazz.defineMethod (c$, "findStringInSet", 
($fz = function (set, string, lengths, lenPos) {
if (set == null) return -1;
var N = lengths[lenPos];
for (var i = 0; i < N; i++) {
if (set[i].equals (string)) return i;
}
return -1;
}, $fz.isPrivate = true, $fz), "~A,~S,~A,~N");
c$.create = Clazz.defineMethod (c$, "create", 
function (action, dataType) {
try {
return  new android.content.IntentFilter (action, dataType);
} catch (e) {
if (Clazz.instanceOf (e, android.content.IntentFilter.MalformedMimeTypeException)) {
throw  new RuntimeException ("Bad MIME type", e);
} else {
throw e;
}
}
}, "~S,~S");
Clazz.makeConstructor (c$, 
function () {
this.mPriority = 0;
this.mActions =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
function (action) {
this.mPriority = 0;
this.mActions =  new java.util.ArrayList ();
this.addAction (action);
}, "~S");
Clazz.makeConstructor (c$, 
function (action, dataType) {
this.mPriority = 0;
this.mActions =  new java.util.ArrayList ();
this.addAction (action);
this.addDataType (dataType);
}, "~S,~S");
Clazz.makeConstructor (c$, 
function (o) {
this.mPriority = o.mPriority;
this.mActions =  new java.util.ArrayList (o.mActions);
if (o.mCategories != null) {
this.mCategories =  new java.util.ArrayList (o.mCategories);
}if (o.mDataTypes != null) {
this.mDataTypes =  new java.util.ArrayList (o.mDataTypes);
}if (o.mDataSchemes != null) {
this.mDataSchemes =  new java.util.ArrayList (o.mDataSchemes);
}if (o.mDataAuthorities != null) {
this.mDataAuthorities =  new java.util.ArrayList (o.mDataAuthorities);
}if (o.mDataPaths != null) {
this.mDataPaths =  new java.util.ArrayList (o.mDataPaths);
}this.mHasPartialTypes = o.mHasPartialTypes;
}, "android.content.IntentFilter");
Clazz.defineMethod (c$, "setPriority", 
function (priority) {
this.mPriority = priority;
}, "~N");
Clazz.defineMethod (c$, "getPriority", 
function () {
return this.mPriority;
});
Clazz.defineMethod (c$, "addAction", 
function (action) {
if (!this.mActions.contains (action)) {
this.mActions.add (action.intern ());
}}, "~S");
Clazz.defineMethod (c$, "countActions", 
function () {
return this.mActions.size ();
});
Clazz.defineMethod (c$, "getAction", 
function (index) {
return this.mActions.get (index);
}, "~N");
Clazz.defineMethod (c$, "hasAction", 
function (action) {
return this.mActions.contains (action);
}, "~S");
Clazz.defineMethod (c$, "matchAction", 
function (action) {
if (action == null || this.mActions == null || this.mActions.size () == 0) {
return false;
}return this.mActions.contains (action);
}, "~S");
Clazz.defineMethod (c$, "actionsIterator", 
function () {
return this.mActions != null ? this.mActions.iterator () : null;
});
Clazz.defineMethod (c$, "addDataType", 
function (type) {
var slashpos = type.indexOf ('/');
var typelen = type.length;
if (slashpos > 0 && typelen >= slashpos + 2) {
if (this.mDataTypes == null) this.mDataTypes =  new java.util.ArrayList ();
if (typelen == slashpos + 2 && (type.charAt (slashpos + 1)).charCodeAt (0) == ('*').charCodeAt (0)) {
var str = type.substring (0, slashpos);
if (!this.mDataTypes.contains (str)) {
this.mDataTypes.add (str.intern ());
}this.mHasPartialTypes = true;
} else {
if (!this.mDataTypes.contains (type)) {
this.mDataTypes.add (type.intern ());
}}return ;
}throw  new android.content.IntentFilter.MalformedMimeTypeException (type);
}, "~S");
Clazz.defineMethod (c$, "addDataPath", 
function (path, type) {
if (this.mDataPaths == null) this.mDataPaths =  new java.util.ArrayList ();
this.mDataPaths.add ( new android.os.PatternMatcher (path.intern (), type));
}, "~S,~N");
Clazz.defineMethod (c$, "countDataPaths", 
function () {
return this.mDataPaths != null ? this.mDataPaths.size () : 0;
});
Clazz.defineMethod (c$, "getDataPath", 
function (index) {
return this.mDataPaths.get (index);
}, "~N");
Clazz.defineMethod (c$, "hasDataPath", 
function (data) {
if (this.mDataPaths == null) {
return false;
}var i = this.mDataPaths.iterator ();
while (i.hasNext ()) {
var pe = i.next ();
if (pe.match (data)) {
return true;
}}
return false;
}, "~S");
Clazz.defineMethod (c$, "pathsIterator", 
function () {
return this.mDataPaths != null ? this.mDataPaths.iterator () : null;
});
Clazz.defineMethod (c$, "hasDataType", 
function (type) {
return this.mDataTypes != null && this.findMimeType (type);
}, "~S");
Clazz.defineMethod (c$, "countDataTypes", 
function () {
return this.mDataTypes != null ? this.mDataTypes.size () : 0;
});
Clazz.defineMethod (c$, "getDataType", 
function (index) {
return this.mDataTypes.get (index);
}, "~N");
Clazz.defineMethod (c$, "typesIterator", 
function () {
return this.mDataTypes != null ? this.mDataTypes.iterator () : null;
});
Clazz.defineMethod (c$, "addDataScheme", 
function (scheme) {
if (this.mDataSchemes == null) this.mDataSchemes =  new java.util.ArrayList ();
if (!this.mDataSchemes.contains (scheme)) {
this.mDataSchemes.add (scheme.intern ());
}}, "~S");
Clazz.defineMethod (c$, "countDataSchemes", 
function () {
return this.mDataSchemes != null ? this.mDataSchemes.size () : 0;
});
Clazz.defineMethod (c$, "getDataScheme", 
function (index) {
return this.mDataSchemes.get (index);
}, "~N");
Clazz.defineMethod (c$, "hasDataScheme", 
function (scheme) {
return this.mDataSchemes != null && this.mDataSchemes.contains (scheme);
}, "~S");
Clazz.defineMethod (c$, "schemesIterator", 
function () {
return this.mDataSchemes != null ? this.mDataSchemes.iterator () : null;
});
Clazz.defineMethod (c$, "addDataAuthority", 
function (host, port) {
if (this.mDataAuthorities == null) this.mDataAuthorities =  new java.util.ArrayList ();
if (port != null) port = port.intern ();
this.mDataAuthorities.add ( new android.content.IntentFilter.AuthorityEntry (host.intern (), port));
}, "~S,~S");
Clazz.defineMethod (c$, "countDataAuthorities", 
function () {
return this.mDataAuthorities != null ? this.mDataAuthorities.size () : 0;
});
Clazz.defineMethod (c$, "getDataAuthority", 
function (index) {
return this.mDataAuthorities.get (index);
}, "~N");
Clazz.defineMethod (c$, "hasDataAuthority", 
function (data) {
return this.matchDataAuthority (data) >= 0;
}, "android.net.Uri");
Clazz.defineMethod (c$, "authoritiesIterator", 
function () {
return this.mDataAuthorities != null ? this.mDataAuthorities.iterator () : null;
});
Clazz.defineMethod (c$, "matchDataAuthority", 
function (data) {
if (this.mDataAuthorities == null) {
return -2;
}var i = this.mDataAuthorities.iterator ();
while (i.hasNext ()) {
var ae = i.next ();
var match = ae.match (data);
if (match >= 0) {
return match;
}}
return -2;
}, "android.net.Uri");
Clazz.defineMethod (c$, "matchData", 
function (type, scheme, data) {
var types = this.mDataTypes;
var schemes = this.mDataSchemes;
var authorities = this.mDataAuthorities;
var paths = this.mDataPaths;
var match = 1048576;
if (types == null && schemes == null) {
return ((type == null && data == null) ? (1081344) : -2);
}if (schemes != null) {
if (schemes.contains (scheme != null ? scheme : "")) {
match = 2097152;
} else {
return -2;
}if (authorities != null) {
var authMatch = this.matchDataAuthority (data);
if (authMatch >= 0) {
if (paths == null) {
match = authMatch;
} else if (this.hasDataPath (data.getPath ())) {
match = 5242880;
} else {
return -2;
}} else {
return -2;
}}} else {
if (scheme != null && !"".equals (scheme) && !"content".equals (scheme) && !"file".equals (scheme)) {
return -2;
}}if (types != null) {
if (this.findMimeType (type)) {
match = 6291456;
} else {
return -1;
}} else {
if (type != null) {
return -1;
}}return match + 32768;
}, "~S,~S,android.net.Uri");
Clazz.defineMethod (c$, "addCategory", 
function (category) {
if (this.mCategories == null) this.mCategories =  new java.util.ArrayList ();
if (!this.mCategories.contains (category)) {
this.mCategories.add (category.intern ());
}}, "~S");
Clazz.defineMethod (c$, "countCategories", 
function () {
return this.mCategories != null ? this.mCategories.size () : 0;
});
Clazz.defineMethod (c$, "getCategory", 
function (index) {
return this.mCategories.get (index);
}, "~N");
Clazz.defineMethod (c$, "hasCategory", 
function (category) {
return this.mCategories != null && this.mCategories.contains (category);
}, "~S");
Clazz.defineMethod (c$, "categoriesIterator", 
function () {
return this.mCategories != null ? this.mCategories.iterator () : null;
});
Clazz.defineMethod (c$, "matchCategories", 
function (categories) {
if (categories == null) {
return null;
}var it = categories.iterator ();
if (this.mCategories == null) {
return it.hasNext () ? it.next () : null;
}while (it.hasNext ()) {
var category = it.next ();
if (!this.mCategories.contains (category)) {
return category;
}}
return null;
}, "java.util.Set");
Clazz.defineMethod (c$, "match", 
function (action, type, scheme, data, categories, logTag) {
if (action != null && !this.matchAction (action)) {
if (false) android.util.Log.v (logTag, "No matching action " + action + " for " + this);
return -3;
}var dataMatch = this.matchData (type, scheme, data);
if (dataMatch < 0) {
if (false) {
if (dataMatch == -1) {
android.util.Log.v (logTag, "No matching type " + type + " for " + this);
}if (dataMatch == -2) {
android.util.Log.v (logTag, "No matching scheme/path " + data + " for " + this);
}}return dataMatch;
}var categoryMatch = this.matchCategories (categories);
if (categoryMatch != null) {
if (false) android.util.Log.v (logTag, "No matching category " + categoryMatch + " for " + this);
return -4;
}return dataMatch;
}, "~S,~S,~S,android.net.Uri,java.util.Set,~S");
Clazz.defineMethod (c$, "dump", 
function (du, prefix) {
var sb =  new StringBuilder (256);
if (this.mActions.size () > 0) {
var it = this.mActions.iterator ();
while (it.hasNext ()) {
sb.setLength (0);
sb.append (prefix);
sb.append ("Action: \"");
sb.append (it.next ());
sb.append ("\"");
du.println (sb.toString ());
}
}if (this.mCategories != null) {
var it = this.mCategories.iterator ();
while (it.hasNext ()) {
sb.setLength (0);
sb.append (prefix);
sb.append ("Category: \"");
sb.append (it.next ());
sb.append ("\"");
du.println (sb.toString ());
}
}if (this.mDataSchemes != null) {
var it = this.mDataSchemes.iterator ();
while (it.hasNext ()) {
sb.setLength (0);
sb.append (prefix);
sb.append ("Scheme: \"");
sb.append (it.next ());
sb.append ("\"");
du.println (sb.toString ());
}
}if (this.mDataAuthorities != null) {
var it = this.mDataAuthorities.iterator ();
while (it.hasNext ()) {
var ae = it.next ();
sb.setLength (0);
sb.append (prefix);
sb.append ("Authority: \"");
sb.append (ae.mHost);
sb.append ("\": ");
sb.append (ae.mPort);
if (ae.mWild) sb.append (" WILD");
du.println (sb.toString ());
}
}if (this.mDataTypes != null) {
var it = this.mDataTypes.iterator ();
while (it.hasNext ()) {
sb.setLength (0);
sb.append (prefix);
sb.append ("Type: \"");
sb.append (it.next ());
sb.append ("\"");
du.println (sb.toString ());
}
}if (this.mPriority != 0 || this.mHasPartialTypes) {
sb.setLength (0);
sb.append (prefix);
sb.append ("mPriority=");
sb.append (this.mPriority);
sb.append (", mHasPartialTypes=");
sb.append (this.mHasPartialTypes);
du.println (sb.toString ());
}}, "android.util.Printer,~S");
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "debugCheck", 
function () {
return true;
});
Clazz.defineMethod (c$, "findMimeType", 
($fz = function (type) {
var t = this.mDataTypes;
if (type == null) {
return false;
}if (t.contains (type)) {
return true;
}var typeLength = type.length;
if (typeLength == 3 && type.equals ("*/*")) {
return !t.isEmpty ();
}if (this.mHasPartialTypes && t.contains ("*")) {
return true;
}var slashpos = type.indexOf ('/');
if (slashpos > 0) {
if (this.mHasPartialTypes && t.contains (type.substring (0, slashpos))) {
return true;
}if (typeLength == slashpos + 2 && (type.charAt (slashpos + 1)).charCodeAt (0) == ('*').charCodeAt (0)) {
var it = t.iterator ();
while (it.hasNext ()) {
var v = it.next ();
if (type.regionMatches (0, v, 0, slashpos + 1)) {
return true;
}}
}}return false;
}, $fz.isPrivate = true, $fz), "~S");
Clazz.defineMethod (c$, "readFromXml", 
function (parser) {
console.log("Missing method: readFromXml");
}, "org.xmlpull.v1.XmlPullParser");
Clazz.pu$h ();
c$ = Clazz.declareType (android.content.IntentFilter, "MalformedMimeTypeException", android.util.AndroidException);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.content.IntentFilter.MalformedMimeTypeException, []);
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mOrigHost = null;
this.mHost = null;
this.mWild = false;
this.mPort = 0;
Clazz.instantialize (this, arguments);
}, android.content.IntentFilter, "AuthorityEntry");
Clazz.makeConstructor (c$, 
function (a, b) {
this.mOrigHost = a;
this.mWild = a.length > 0 && (a.charAt (0)).charCodeAt (0) == ('*').charCodeAt (0);
this.mHost = this.mWild ? a.substring (1).intern () : a;
this.mPort = b != null ? Integer.parseInt (b) : -1;
}, "~S,~S");
Clazz.defineMethod (c$, "getHost", 
function () {
return this.mOrigHost;
});
Clazz.defineMethod (c$, "getPort", 
function () {
return this.mPort;
});
Clazz.defineMethod (c$, "match", 
function (a) {
var b = a.getHost ();
if (b == null) {
return -2;
}if (false) android.util.Log.v ("IntentFilter", "Match host " + b + ": " + this.mHost);
if (this.mWild) {
if (b.length < this.mHost.length) {
return -2;
}b = b.substring (b.length - this.mHost.length);
}if (b.compareToIgnoreCase (this.mHost) != 0) {
return -2;
}if (this.mPort >= 0) {
if (this.mPort != a.getPort ()) {
return -2;
}return 4194304;
}return 3145728;
}, "android.net.Uri");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"SGLOB_STR", "sglob",
"PREFIX_STR", "prefix",
"LITERAL_STR", "literal",
"PATH_STR", "path",
"PORT_STR", "port",
"HOST_STR", "host",
"AUTH_STR", "auth",
"SCHEME_STR", "scheme",
"TYPE_STR", "type",
"CAT_STR", "cat",
"NAME_STR", "name",
"ACTION_STR", "action",
"SYSTEM_HIGH_PRIORITY", 1000,
"SYSTEM_LOW_PRIORITY", -1000,
"MATCH_CATEGORY_MASK", 0xfff0000,
"MATCH_ADJUSTMENT_MASK", 0x000ffff,
"MATCH_ADJUSTMENT_NORMAL", 0x8000,
"MATCH_CATEGORY_EMPTY", 0x0100000,
"MATCH_CATEGORY_SCHEME", 0x0200000,
"MATCH_CATEGORY_HOST", 0x0300000,
"MATCH_CATEGORY_PORT", 0x0400000,
"MATCH_CATEGORY_PATH", 0x0500000,
"MATCH_CATEGORY_TYPE", 0x0600000,
"NO_MATCH_TYPE", -1,
"NO_MATCH_DATA", -2,
"NO_MATCH_ACTION", -3,
"NO_MATCH_CATEGORY", -4);
});
