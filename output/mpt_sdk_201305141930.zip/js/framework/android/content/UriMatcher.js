﻿Clazz.declarePackage ("android.content");
Clazz.load (["java.util.regex.Pattern"], "android.content.UriMatcher", ["java.lang.IllegalArgumentException", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mCode = 0;
this.mWhich = 0;
this.mText = null;
this.mChildren = null;
Clazz.instantialize (this, arguments);
}, android.content, "UriMatcher");
Clazz.makeConstructor (c$, 
function (code) {
this.mCode = code;
this.mWhich = -1;
this.mChildren =  new java.util.ArrayList ();
this.mText = null;
}, "~N");
Clazz.makeConstructor (c$, 
($fz = function () {
this.mCode = -1;
this.mWhich = -1;
this.mChildren =  new java.util.ArrayList ();
this.mText = null;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "addURI", 
function (authority, path, code) {
if (code < 0) {
throw  new IllegalArgumentException ("code " + code + " is invalid: it must be positive");
}var tokens = (path != null ? android.content.UriMatcher.PATH_SPLIT_PATTERN.split (path) : null);
var numTokens = tokens != null ? tokens.length : 0;
var node = this;
for (var i = -1; i < numTokens; i++) {
var token = i < 0 ? authority : tokens[i];
var children = node.mChildren;
var numChildren = children.size ();
var child;
var j;
for (j = 0; j < numChildren; j++) {
child = children.get (j);
if (token.equals (child.mText)) {
node = child;
break;
}}
if (j == numChildren) {
child =  new android.content.UriMatcher ();
if (token.equals ("#")) {
child.mWhich = 1;
} else if (token.equals ("*")) {
child.mWhich = 2;
} else {
child.mWhich = 0;
}child.mText = token;
node.mChildren.add (child);
node = child;
}}
node.mCode = code;
}, "~S,StringBuilder,~N");
Clazz.defineMethod (c$, "addURI", 
function (authority, path, code) {
if (code < 0) {
throw  new IllegalArgumentException ("code " + code + " is invalid: it must be positive");
}var tokens = path != null ? android.content.UriMatcher.PATH_SPLIT_PATTERN.split (path) : null;
var numTokens = tokens != null ? tokens.length : 0;
var node = this;
for (var i = -1; i < numTokens; i++) {
var token = i < 0 ? authority : tokens[i];
var children = node.mChildren;
var numChildren = children.size ();
var child;
var j;
for (j = 0; j < numChildren; j++) {
child = children.get (j);
if (token.equals (child.mText)) {
node = child;
break;
}}
if (j == numChildren) {
child =  new android.content.UriMatcher ();
if (token.equals ("#")) {
child.mWhich = 1;
} else if (token.equals ("*")) {
child.mWhich = 2;
} else {
child.mWhich = 0;
}child.mText = token;
node.mChildren.add (child);
node = child;
}}
node.mCode = code;
}, "~S,~S,~N");
Clazz.defineMethod (c$, "match", 
function (uri) {
var pathSegments = uri.getPathSegments ();
var li = pathSegments.size ();
var node = this;
if (li == 0 && uri.getAuthority () == null) {
return this.mCode;
}for (var i = -1; i < li; i++) {
var u = i < 0 ? uri.getAuthority () : pathSegments.get (i);
var list = node.mChildren;
if (list == null) {
break;
}node = null;
var lj = list.size ();
for (var j = 0; j < lj; j++) {
var n = list.get (j);
which_switch : switch (n.mWhich) {
case 0:
if (n.mText.equals (u)) {
node = n;
}break;
case 1:
var lk = u.length;
for (var k = 0; k < lk; k++) {
var c = u.charAt (k);
if ((c).charCodeAt (0) < ('0').charCodeAt (0) || (c).charCodeAt (0) > ('9').charCodeAt (0)) {
break which_switch;
}}
node = n;
break;
case 2:
node = n;
break;
}
if (node != null) {
break;
}}
if (node == null) {
return -1;
}}
return node.mCode;
}, "android.net.Uri");
Clazz.defineStatics (c$,
"NO_MATCH", -1);
c$.PATH_SPLIT_PATTERN = c$.prototype.PATH_SPLIT_PATTERN = java.util.regex.Pattern.compile ("/");
Clazz.defineStatics (c$,
"EXACT", 0,
"NUMBER", 1,
"TEXT", 2);
});
