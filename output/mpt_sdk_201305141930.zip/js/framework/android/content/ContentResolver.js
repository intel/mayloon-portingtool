﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.database.CursorWrapper", "java.util.Random"], "android.content.ContentResolver", ["android.content.ContentService", "$.Context", "android.util.Log", "java.io.FileNotFoundException", "java.lang.IllegalArgumentException", "$.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mRandom = null;
if (!Clazz.isClassDefined ("android.content.ContentResolver.CursorWrapperInner")) {
android.content.ContentResolver.$ContentResolver$CursorWrapperInner$ ();
}
this.mContext = null;
Clazz.instantialize (this, arguments);
}, android.content, "ContentResolver");
Clazz.prepareFields (c$, function () {
this.mRandom =  new java.util.Random ();
});
Clazz.makeConstructor (c$, 
function (context) {
this.mContext = context;
}, "android.content.Context");
Clazz.defineMethod (c$, "acquireExistingProvider", 
function (c, name) {
return this.acquireProvider (c, name);
}, "android.content.Context,~S");
Clazz.defineMethod (c$, "getType", 
function (url) {
var provider = this.acquireProvider (url);
System.out.println ("provider:" + url + provider);
if (provider != null) {
try {
return provider.getType (url);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.w ("ContentResolver", "Failed to get type for: " + url + " (" + e.getMessage () + ")");
return null;
} else {
throw e;
}
} finally {
this.releaseProvider (provider);
}
}if (!"content".equals (url.getScheme ())) {
return null;
}try {
var type = (android.content.Context.getSystemContext ().getSystemService ("activity")).getProviderMimeType (url);
return type;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.w ("ContentResolver", "Failed to get type for: " + url + " (" + e.getMessage () + ")");
return null;
} else {
throw e;
}
}
}, "android.net.Uri");
Clazz.defineMethod (c$, "getStreamTypes", 
function (url, mimeTypeFilter) {
var provider = this.acquireProvider (url);
if (provider == null) {
return null;
}try {
return provider.getStreamTypes (url, mimeTypeFilter);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
return null;
} else {
throw e;
}
} finally {
this.releaseProvider (provider);
}
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "query", 
function (uri, projection, selection, selectionArgs, sortOrder) {
var provider = this.acquireProvider (uri);
if (provider == null) {
return null;
}try {
var qCursor = provider.query (uri, projection, selection, selectionArgs, sortOrder);
if (qCursor == null) {
this.releaseProvider (provider);
return null;
}qCursor.getCount ();
return Clazz.innerTypeInstance (android.content.ContentResolver.CursorWrapperInner, this, null, qCursor, provider);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
this.releaseProvider (provider);
return null;
} else {
throw e;
}
}
}, "android.net.Uri,~A,~S,~A,~S");
c$.modeToMode = Clazz.defineMethod (c$, "modeToMode", 
function (uri, mode) {
var modeBits;
if ("r".equals (mode)) {
modeBits = 268435456;
} else if ("w".equals (mode) || "wt".equals (mode)) {
modeBits = 738197504;
} else if ("wa".equals (mode)) {
modeBits = 704643072;
} else if ("rw".equals (mode)) {
modeBits = 939524096;
} else if ("rwt".equals (mode)) {
modeBits = 1006632960;
} else {
throw  new java.io.FileNotFoundException ("Bad mode for " + uri + ": " + mode);
}return modeBits;
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "insert", 
function (url, values) {
if (android.content.ContentResolver.DEBUG_PROVIDER) System.out.println ("ContentResolver:acquireProvider");
var provider = this.acquireProvider (url);
if (provider == null) {
System.out.println ("Content Provider is null");
}try {
var createdRow = provider.insert (url, values);
return createdRow;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
} finally {
this.releaseProvider (provider);
}
return null;
}, "android.net.Uri,android.content.ContentValues");
Clazz.defineMethod (c$, "bulkInsert", 
function (url, values) {
return 0;
}, "android.net.Uri,~A");
Clazz.defineMethod (c$, "$delete", 
function (url, where, selectionArgs) {
var provider = this.acquireProvider (url);
if (provider == null) {
throw  new IllegalArgumentException ("Unknown URL " + url);
}try {
var rowsDeleted = provider.$delete (url, where, selectionArgs);
return rowsDeleted;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
return -1;
} else {
throw e;
}
} finally {
this.releaseProvider (provider);
}
}, "android.net.Uri,~S,~A");
Clazz.defineMethod (c$, "update", 
function (uri, values, where, selectionArgs) {
var provider = this.acquireProvider (uri);
if (provider == null) {
throw  new IllegalArgumentException ("Unknown URI " + uri);
}try {
var rowsUpdated = provider.update (uri, values, where, selectionArgs);
return rowsUpdated;
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
return -1;
} else {
throw e;
}
} finally {
this.releaseProvider (provider);
}
}, "android.net.Uri,android.content.ContentValues,~S,~A");
Clazz.defineMethod (c$, "call", 
function (uri, method, arg, extras) {
if (uri == null) {
throw  new NullPointerException ("uri == null");
}if (method == null) {
throw  new NullPointerException ("method == null");
}var provider = this.acquireProvider (uri);
if (provider == null) {
throw  new IllegalArgumentException ("Unknown URI " + uri);
}try {
return provider.call (method, arg, extras);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
return null;
} else {
throw e;
}
} finally {
this.releaseProvider (provider);
}
}, "android.net.Uri,~S,~S,android.os.Bundle");
Clazz.defineMethod (c$, "acquireProvider", 
function (uri) {
if (android.content.ContentResolver.DEBUG_PROVIDER) System.out.println ("ContentResolver Calling acquireProvider(uri)");
if (!"content".equals (uri.getScheme ())) {
System.out.println ("ContentResolverbyte");
return null;
}var auth = uri.getAuthority ();
if (auth != null) {
if (android.content.ContentResolver.DEBUG_PROVIDER) System.out.println ("ContentResolver Calling acquireProvider(mContext, uri.getAuthority())");
return this.acquireProvider (this.mContext, uri.getAuthority ());
}if (android.content.ContentResolver.DEBUG_PROVIDER) System.out.println ("ContentResolverbye...");
return null;
}, "android.net.Uri");
Clazz.defineMethod (c$, "acquireExistingProvider", 
function (uri) {
if (!"content".equals (uri.getScheme ())) {
return null;
}var auth = uri.getAuthority ();
if (auth != null) {
return this.acquireExistingProvider (this.mContext, uri.getAuthority ());
}return null;
}, "android.net.Uri");
Clazz.defineMethod (c$, "acquireProvider", 
function (name) {
if (name == null) {
return null;
}return this.acquireProvider (this.mContext, name);
}, "~S");
Clazz.defineMethod (c$, "registerContentObserver", 
function (uri, notifyForDescendents, observer) {
try {
this.getContentService ().registerContentObserver (uri, notifyForDescendents, observer.getContentObserver ());
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
}, "android.net.Uri,~B,android.database.ContentObserver");
Clazz.defineMethod (c$, "getContentService", 
function () {
return android.content.ContentService.getContentService ();
});
Clazz.defineMethod (c$, "unregisterContentObserver", 
function (observer) {
try {
var contentObserver = observer.releaseContentObserver ();
if (contentObserver != null) {
this.getContentService ().unregisterContentObserver (contentObserver);
}} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
} else {
throw e;
}
}
}, "android.database.ContentObserver");
Clazz.defineMethod (c$, "notifyChange", 
function (uri, observer) {
this.notifyChange (uri, observer, true);
}, "android.net.Uri,android.database.ContentObserver");
Clazz.defineMethod (c$, "notifyChange", 
function (uri, observer, syncToNetwork) {
this.getContentService ().notifyChange (uri, observer == null ? null : observer.getContentObserver (), observer != null && observer.deliverSelfNotifications (), syncToNetwork);
}, "android.net.Uri,android.database.ContentObserver,~B");
Clazz.defineMethod (c$, "startSync", 
function (uri, extras) {
}, "android.net.Uri,android.os.Bundle");
Clazz.defineMethod (c$, "openAssetFileDescriptor", 
function (uri, string) {
return null;
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "openFileDescriptor", 
function (uri, string) {
return null;
}, "android.net.Uri,~S");
Clazz.defineMethod (c$, "openOutputStream", 
function (url) {
return null;
}, "android.net.Uri");
Clazz.defineMethod (c$, "openInputStream", 
function (url) {
return null;
}, "android.net.Uri");
c$.setMasterSyncAutomatically = Clazz.defineMethod (c$, "setMasterSyncAutomatically", 
function (sync) {
console.log("Missing method: setMasterSyncAutomatically");
}, "~B");
c$.getCurrentSync = Clazz.defineMethod (c$, "getCurrentSync", 
function () {
console.log("Missing method: getCurrentSync");
});
c$.getMasterSyncAutomatically = Clazz.defineMethod (c$, "getMasterSyncAutomatically", 
function () {
console.log("Missing method: getMasterSyncAutomatically");
});
c$.removeStatusChangeListener = Clazz.defineMethod (c$, "removeStatusChangeListener", 
function (handle) {
console.log("Missing method: removeStatusChangeListener");
}, "~O");
c$.$ContentResolver$CursorWrapperInner$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mContentProvider = null;
this.mCloseFlag = false;
Clazz.instantialize (this, arguments);
}, android.content.ContentResolver, "CursorWrapperInner", android.database.CursorWrapper);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.content.ContentResolver.CursorWrapperInner, [a]);
this.mContentProvider = b;
}, "android.database.Cursor,android.content.ContentProvider");
Clazz.defineMethod (c$, "close", 
function () {
Clazz.superCall (this, android.content.ContentResolver.CursorWrapperInner, "close", []);
this.b$["android.content.ContentResolver"].releaseProvider (this.mContentProvider);
this.mCloseFlag = true;
});
Clazz.defineMethod (c$, "finalize", 
function () {
try {
if (!this.mCloseFlag) {
android.util.Log.w ("CursorWrapperInner", "Cursor finalized without prior close()");
this.close ();
}} finally {
Clazz.superCall (this, android.content.ContentResolver.CursorWrapperInner, "finalize", []);
}
});
Clazz.defineStatics (c$,
"TAG", "CursorWrapperInner");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"SYNC_EXTRAS_ACCOUNT", "account",
"SYNC_EXTRAS_EXPEDITED", "expedited",
"SYNC_EXTRAS_FORCE", "force",
"DEBUG_PROVIDER", false,
"SYNC_EXTRAS_IGNORE_SETTINGS", "ignore_settings",
"SYNC_EXTRAS_IGNORE_BACKOFF", "ignore_backoff",
"SYNC_EXTRAS_DO_NOT_RETRY", "do_not_retry",
"SYNC_EXTRAS_MANUAL", "force",
"SYNC_EXTRAS_UPLOAD", "upload",
"SYNC_EXTRAS_OVERRIDE_TOO_MANY_DELETIONS", "deletions_override",
"SYNC_EXTRAS_DISCARD_LOCAL_DELETIONS", "discard_deletions",
"SYNC_EXTRAS_INITIALIZE", "initialize",
"SCHEME_CONTENT", "content",
"SCHEME_ANDROID_RESOURCE", "android.resource",
"SCHEME_FILE", "file",
"CURSOR_ITEM_BASE_TYPE", "vnd.android.cursor.item",
"CURSOR_DIR_BASE_TYPE", "vnd.android.cursor.dir",
"SYNC_ERROR_SYNC_ALREADY_IN_PROGRESS", 1,
"SYNC_ERROR_AUTHENTICATION", 2,
"SYNC_ERROR_IO", 3,
"SYNC_ERROR_PARSE", 4,
"SYNC_ERROR_CONFLICT", 5,
"SYNC_ERROR_TOO_MANY_DELETIONS", 6,
"SYNC_ERROR_TOO_MANY_RETRIES", 7,
"SYNC_ERROR_INTERNAL", 8,
"SYNC_OBSERVER_TYPE_SETTINGS", 1,
"SYNC_OBSERVER_TYPE_PENDING", 2,
"SYNC_OBSERVER_TYPE_ACTIVE", 4,
"SYNC_OBSERVER_TYPE_STATUS", 8,
"SYNC_OBSERVER_TYPE_ALL", 0x7fffffff,
"SLOW_THRESHOLD_MILLIS", 500,
"CONTENT_SERVICE_NAME", "content",
"TAG", "ContentResolver");
});
