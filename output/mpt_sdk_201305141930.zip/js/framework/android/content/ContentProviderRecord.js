﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.app.ActivityManager", "java.util.HashSet"], "android.content.ContentProviderRecord", ["android.content.ComponentName"], function () {
c$ = Clazz.decorateAsClass (function () {
this.clients = null;
this.uid = 0;
this.appInfo = null;
this.name = null;
this.externals = 0;
this.app = null;
this.launchingApp = null;
this.stringName = null;
Clazz.instantialize (this, arguments);
}, android.content, "ContentProviderRecord", android.app.ActivityManager.ContentProviderHolder);
Clazz.prepareFields (c$, function () {
this.clients =  new java.util.HashSet ();
});
Clazz.makeConstructor (c$, 
function (_info, ai) {
Clazz.superConstructor (this, android.content.ContentProviderRecord, [_info]);
this.uid = ai.uid;
this.appInfo = ai;
this.name =  new android.content.ComponentName (_info.packageName, _info.name);
this.noReleaseNeeded = true;
}, "android.content.pm.ProviderInfo,android.content.pm.ApplicationInfo");
Clazz.makeConstructor (c$, 
function (cpr) {
Clazz.superConstructor (this, android.content.ContentProviderRecord, [cpr.info]);
this.uid = cpr.uid;
this.appInfo = cpr.appInfo;
this.name = cpr.name;
this.noReleaseNeeded = cpr.noReleaseNeeded;
}, "android.content.ContentProviderRecord");
Clazz.defineMethod (c$, "canRunHere", 
function (app) {
return true;
}, "android.app.ProcessRecord");
});
