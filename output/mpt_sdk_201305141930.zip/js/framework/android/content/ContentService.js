﻿Clazz.declarePackage ("android.content");
Clazz.load (["java.util.ArrayList"], "android.content.ContentService", ["android.util.Log", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mContext = null;
this.mRootNode = null;
Clazz.instantialize (this, arguments);
}, android.content, "ContentService");
Clazz.prepareFields (c$, function () {
this.mRootNode =  new android.content.ContentService.ObserverNode ("");
});
Clazz.makeConstructor (c$, 
function (context) {
this.mContext = context;
}, "android.content.Context");
c$.main = Clazz.defineMethod (c$, "main", 
function (context) {
($t$ = android.content.ContentService.instance =  new android.content.ContentService (context), android.content.ContentService.prototype.instance = android.content.ContentService.instance, $t$);
return android.content.ContentService.instance;
}, "android.content.Context");
c$.getContentService = Clazz.defineMethod (c$, "getContentService", 
function () {
return android.content.ContentService.instance;
});
Clazz.defineMethod (c$, "registerContentObserver", 
function (uri, notifyForDescendents, observer) {
if (observer == null || uri == null) {
throw  new IllegalArgumentException ("You must pass a valid uri and observer");
}if (android.content.ContentService.DEBUG) {
System.out.println (" ContentService<< Register Content Observer...");
}this.mRootNode.addObserverLocked (uri, observer, notifyForDescendents, this.mRootNode);
}, "android.net.Uri,~B,android.database.ContentObserver");
Clazz.defineMethod (c$, "notifyChange", 
function (uri, observer, observerWantsSelfNotifications, syncToNetwork) {
if (android.content.ContentService.DEBUG) System.out.println (" ContentService<< Notify change...");
var calls =  new java.util.ArrayList ();
this.mRootNode.collectObserversLocked (uri, 0, observer, observerWantsSelfNotifications, calls);
var numCalls = calls.size ();
for (var i = 0; i < numCalls; i++) {
var oc = calls.get (i);
try {
oc.mObserver.onChange (oc.mSelfNotify);
if (android.content.ContentService.DEBUG) {
android.util.Log.v (" ContentService<< ", "Notified " + oc.mObserver + " of " + "update at " + uri);
}} catch (ex) {
if (Clazz.instanceOf (ex, Exception)) {
var list = oc.mNode.mObservers;
var numList = list.size ();
for (var j = 0; j < numList; j++) {
var oe = list.get (j);
if (oe.observer === oc.mObserver || oc.mObserver == null) {
list.remove (j);
j--;
numList--;
}}
} else {
throw ex;
}
}
}
}, "android.net.Uri,android.database.ContentObserver,~B,~B");
Clazz.defineMethod (c$, "unregisterContentObserver", 
function (observer) {
if (observer == null) {
throw  new IllegalArgumentException ("You must pass a valid observer");
}this.mRootNode.removeObserverLocked (observer);
if (android.content.ContentService.DEBUG) android.util.Log.v (" ContentService<< ", "Unregistered observer " + observer);
}, "android.database.ContentObserver");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mNode = null;
this.mObserver = null;
this.mSelfNotify = false;
Clazz.instantialize (this, arguments);
}, android.content.ContentService, "ObserverCall");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.mNode = a;
this.mObserver = b;
this.mSelfNotify = c;
}, "android.content.ContentService.ObserverNode,android.database.ContentObserver,~B");
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mName = null;
this.mChildren = null;
this.mObservers = null;
if (!Clazz.isClassDefined ("android.content.ContentService.ObserverNode.ObserverEntry")) {
android.content.ContentService.ObserverNode.$ContentService$ObserverNode$ObserverEntry$ ();
}
Clazz.instantialize (this, arguments);
}, android.content.ContentService, "ObserverNode");
Clazz.prepareFields (c$, function () {
this.mChildren =  new java.util.ArrayList ();
this.mObservers =  new java.util.ArrayList ();
});
Clazz.makeConstructor (c$, 
function (a) {
this.mName = a;
}, "~S");
Clazz.defineMethod (c$, "countUriSegments", 
($fz = function (a) {
if (a == null) {
return 0;
}return a.getPathSegments ().size () + 1;
}, $fz.isPrivate = true, $fz), "android.net.Uri");
Clazz.defineMethod (c$, "getUriSegment", 
($fz = function (a, b) {
if (a != null) {
if (b == 0) {
return a.getAuthority ();
} else {
return a.getPathSegments ().get (b - 1);
}} else {
return null;
}}, $fz.isPrivate = true, $fz), "android.net.Uri,~N");
Clazz.defineMethod (c$, "addObserverLocked", 
function (a, b, c, d) {
this.addObserverLocked (a, 0, b, c, d);
}, "android.net.Uri,android.database.ContentObserver,~B,~O");
Clazz.defineMethod (c$, "removeObserverLocked", 
function (a) {
var b = this.mChildren.size ();
for (var c = 0; c < b; c++) {
var d = this.mChildren.get (c).removeObserverLocked (a);
if (d) {
this.mChildren.remove (c);
c--;
b--;
}}
b = this.mObservers.size ();
for (var d = 0; d < b; d++) {
var e = this.mObservers.get (d);
if (e.observer === a) {
this.mObservers.remove (d);
break;
}}
if (this.mChildren.size () == 0 && this.mObservers.size () == 0) {
return true;
}return false;
}, "android.database.ContentObserver");
Clazz.defineMethod (c$, "addObserverLocked", 
($fz = function (a, b, c, d, e) {
if (b == this.countUriSegments (a)) {
this.mObservers.add (Clazz.innerTypeInstance (android.content.ContentService.ObserverNode.ObserverEntry, this, null, c, d, e));
return ;
}var f = this.getUriSegment (a, b);
if (f == null) {
throw  new IllegalArgumentException ("Invalid Uri (" + a + ") used for observer");
}var g = this.mChildren.size ();
for (var h = 0; h < g; h++) {
var i = this.mChildren.get (h);
if (i.mName.equals (f)) {
i.addObserverLocked (a, b + 1, c, d, e);
return ;
}}
var i =  new android.content.ContentService.ObserverNode (f);
this.mChildren.add (i);
i.addObserverLocked (a, b + 1, c, d, e);
}, $fz.isPrivate = true, $fz), "android.net.Uri,~N,android.database.ContentObserver,~B,~O");
Clazz.defineMethod (c$, "collectMyObserversLocked", 
($fz = function (a, b, c, d) {
var e = this.mObservers.size ();
for (var f = 0; f < e; f++) {
var g = this.mObservers.get (f);
if (g.observer === b && !c) {
continue ;}if (a || (!a && g.notifyForDescendents)) {
d.add ( new android.content.ContentService.ObserverCall (this, g.observer, c));
}}
}, $fz.isPrivate = true, $fz), "~B,android.database.ContentObserver,~B,java.util.ArrayList");
Clazz.defineMethod (c$, "collectObserversLocked", 
function (a, b, c, d, e) {
var f = null;
var g = this.countUriSegments (a);
if (b >= g) {
this.collectMyObserversLocked (true, c, d, e);
} else if (b < g) {
f = this.getUriSegment (a, b);
this.collectMyObserversLocked (false, c, d, e);
}var h = this.mChildren.size ();
for (var i = 0; i < h; i++) {
var j = this.mChildren.get (i);
if (f == null || j.mName.equals (f)) {
j.collectObserversLocked (a, b + 1, c, d, e);
if (f != null) {
break;
}}}
}, "android.net.Uri,~N,android.database.ContentObserver,~B,java.util.ArrayList");
c$.$ContentService$ObserverNode$ObserverEntry$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.notifyForDescendents = false;
this.observer = null;
Clazz.instantialize (this, arguments);
}, android.content.ContentService.ObserverNode, "ObserverEntry");
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.notifyForDescendents = b;
this.observer = a;
}, "android.database.ContentObserver,~B,~O");
c$ = Clazz.p0p ();
};
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", " ContentService<< ",
"DEBUG", true,
"instance", null);
});
