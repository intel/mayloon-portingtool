﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.os.Parcelable", "android.os.Parcelable.Creator"], "android.content.ContentValues", ["android.util.Log", "java.lang.Boolean", "$.Byte", "$.Double", "$.Float", "$.Long", "$.Short", "$.StringBuilder", "java.util.HashMap"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mValues = null;
Clazz.instantialize (this, arguments);
}, android.content, "ContentValues", null, android.os.Parcelable);
Clazz.makeConstructor (c$, 
function () {
this.mValues =  new java.util.HashMap (8);
});
Clazz.makeConstructor (c$, 
function (size) {
this.mValues =  new java.util.HashMap (size, 1.0);
}, "~N");
Clazz.makeConstructor (c$, 
function (from) {
this.mValues =  new java.util.HashMap (from.mValues);
}, "android.content.ContentValues");
Clazz.makeConstructor (c$, 
($fz = function (values) {
this.mValues = values;
}, $fz.isPrivate = true, $fz), "java.util.HashMap");
Clazz.overrideMethod (c$, "equals", 
function (object) {
if (!(Clazz.instanceOf (object, android.content.ContentValues))) {
return false;
}return this.mValues.equals ((object).mValues);
}, "~O");
Clazz.overrideMethod (c$, "hashCode", 
function () {
return this.mValues.hashCode ();
});
Clazz.defineMethod (c$, "put", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,~S");
Clazz.defineMethod (c$, "putAll", 
function (other) {
this.mValues.putAll (other.mValues);
}, "android.content.ContentValues");
Clazz.defineMethod (c$, "put", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,Byte");
Clazz.defineMethod (c$, "put", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,Short");
Clazz.defineMethod (c$, "put", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,Integer");
Clazz.defineMethod (c$, "put", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,Long");
Clazz.defineMethod (c$, "put", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,Float");
Clazz.defineMethod (c$, "put", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,Double");
Clazz.defineMethod (c$, "put", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,Boolean");
Clazz.defineMethod (c$, "put", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,~A");
Clazz.defineMethod (c$, "putNull", 
function (key) {
this.mValues.put (key, null);
}, "~S");
Clazz.defineMethod (c$, "size", 
function () {
return this.mValues.size ();
});
Clazz.defineMethod (c$, "remove", 
function (key) {
this.mValues.remove (key);
}, "~S");
Clazz.defineMethod (c$, "clear", 
function () {
this.mValues.clear ();
});
Clazz.defineMethod (c$, "containsKey", 
function (key) {
return this.mValues.containsKey (key);
}, "~S");
Clazz.defineMethod (c$, "get", 
function (key) {
return this.mValues.get (key);
}, "~S");
Clazz.defineMethod (c$, "getAsString", 
function (key) {
var value = this.mValues.get (key);
return value != null ? value.toString () : null;
}, "~S");
Clazz.defineMethod (c$, "getAsLong", 
function (key) {
var value = this.mValues.get (key);
try {
return value != null ? (value).longValue () : null;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
if (Clazz.instanceOf (value, CharSequence)) {
try {
return Long.$valueOf (value.toString ());
} catch (e2) {
if (Clazz.instanceOf (e2, NumberFormatException)) {
android.util.Log.e ("ContentValues", "Cannot parse Long value for " + value + " at key " + key);
return null;
} else {
throw e2;
}
}
} else {
android.util.Log.e ("ContentValues", "Cannot cast value for " + key + " to a Long: " + value, e);
return null;
}} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getAsInteger", 
function (key) {
var value = this.mValues.get (key);
try {
return value != null ? (value).intValue () : null;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
if (Clazz.instanceOf (value, CharSequence)) {
try {
return Integer.$valueOf (value.toString ());
} catch (e2) {
if (Clazz.instanceOf (e2, NumberFormatException)) {
android.util.Log.e ("ContentValues", "Cannot parse Integer value for " + value + " at key " + key);
return null;
} else {
throw e2;
}
}
} else {
android.util.Log.e ("ContentValues", "Cannot cast value for " + key + " to a Integer: " + value, e);
return null;
}} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getAsShort", 
function (key) {
var value = this.mValues.get (key);
try {
return value != null ? (value).shortValue () : null;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
if (Clazz.instanceOf (value, CharSequence)) {
try {
return Short.$valueOf (value.toString ());
} catch (e2) {
if (Clazz.instanceOf (e2, NumberFormatException)) {
android.util.Log.e ("ContentValues", "Cannot parse Short value for " + value + " at key " + key);
return null;
} else {
throw e2;
}
}
} else {
android.util.Log.e ("ContentValues", "Cannot cast value for " + key + " to a Short: " + value, e);
return null;
}} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getAsByte", 
function (key) {
var value = this.mValues.get (key);
try {
return value != null ? (value).byteValue () : null;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
if (Clazz.instanceOf (value, CharSequence)) {
try {
return Byte.$valueOf (value.toString ());
} catch (e2) {
if (Clazz.instanceOf (e2, NumberFormatException)) {
android.util.Log.e ("ContentValues", "Cannot parse Byte value for " + value + " at key " + key);
return null;
} else {
throw e2;
}
}
} else {
android.util.Log.e ("ContentValues", "Cannot cast value for " + key + " to a Byte: " + value, e);
return null;
}} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getAsDouble", 
function (key) {
var value = this.mValues.get (key);
try {
return value != null ? (value).doubleValue () : null;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
if (Clazz.instanceOf (value, CharSequence)) {
try {
return Double.$valueOf (value.toString ());
} catch (e2) {
if (Clazz.instanceOf (e2, NumberFormatException)) {
android.util.Log.e ("ContentValues", "Cannot parse Double value for " + value + " at key " + key);
return null;
} else {
throw e2;
}
}
} else {
android.util.Log.e ("ContentValues", "Cannot cast value for " + key + " to a Double: " + value, e);
return null;
}} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getAsFloat", 
function (key) {
var value = this.mValues.get (key);
try {
return value != null ? (value).floatValue () : null;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
if (Clazz.instanceOf (value, CharSequence)) {
try {
return Float.$valueOf (value.toString ());
} catch (e2) {
if (Clazz.instanceOf (e2, NumberFormatException)) {
android.util.Log.e ("ContentValues", "Cannot parse Float value for " + value + " at key " + key);
return null;
} else {
throw e2;
}
}
} else {
android.util.Log.e ("ContentValues", "Cannot cast value for " + key + " to a Float: " + value, e);
return null;
}} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getAsBoolean", 
function (key) {
var value = this.mValues.get (key);
try {
return value;
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
if (Clazz.instanceOf (value, CharSequence)) {
return Boolean.$valueOf (value.toString ());
} else if (Clazz.instanceOf (value, Number)) {
return (value).intValue () != 0;
} else {
android.util.Log.e ("ContentValues", "Cannot cast value for " + key + " to a Boolean: " + value, e);
return null;
}} else {
throw e;
}
}
}, "~S");
Clazz.defineMethod (c$, "getAsByteArray", 
function (key) {
var value = this.mValues.get (key);
if (Clazz.instanceOf (value, Array)) {
return value;
} else {
return null;
}}, "~S");
Clazz.defineMethod (c$, "valueSet", 
function () {
return this.mValues.entrySet ();
});
Clazz.defineMethod (c$, "keySet", 
function () {
return this.mValues.keySet ();
});
Clazz.overrideMethod (c$, "describeContents", 
function () {
return 0;
});
Clazz.defineMethod (c$, "writeToParcel", 
function (parcel, flags) {
parcel.writeMap (this.mValues);
}, "android.os.Parcel,~N");
Clazz.defineMethod (c$, "putStringArrayList", 
function (key, value) {
this.mValues.put (key, value);
}, "~S,java.util.ArrayList");
Clazz.defineMethod (c$, "getStringArrayList", 
function (key) {
return this.mValues.get (key);
}, "~S");
Clazz.defineMethod (c$, "toString", 
function () {
var sb =  new StringBuilder ();
for (var name, $name = this.mValues.keySet ().iterator (); $name.hasNext () && ((name = $name.next ()) || true);) {
var value = this.getAsString (name);
if (sb.length () > 0) sb.append (" ");
sb.append (name + "=" + value);
}
return sb.toString ();
});
c$.$ContentValues$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.content, "ContentValues$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function ($in) {
var values = $in.readHashMap (null);
return  new android.content.ContentValues (values);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (size) {
return  new Array (size);
}, "~N");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"TAG", "ContentValues");
c$.CREATOR = c$.prototype.CREATOR = ((Clazz.isClassDefined ("android.content.ContentValues$1") ? 0 : android.content.ContentValues.$ContentValues$1$ ()), Clazz.innerTypeInstance (android.content.ContentValues$1, this, null));
});
