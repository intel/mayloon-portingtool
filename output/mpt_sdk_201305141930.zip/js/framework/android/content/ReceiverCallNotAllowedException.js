﻿Clazz.declarePackage ("android.content");
Clazz.load (["android.util.AndroidRuntimeException"], "android.content.ReceiverCallNotAllowedException", null, function () {
c$ = Clazz.declareType (android.content, "ReceiverCallNotAllowedException", android.util.AndroidRuntimeException);
});
