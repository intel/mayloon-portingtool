﻿Clazz.declarePackage ("android.content");
Clazz.declareInterface (android.content, "SharedPreferences");
Clazz.declareInterface (android.content.SharedPreferences, "OnSharedPreferenceChangeListener");
Clazz.declareInterface (android.content.SharedPreferences, "Editor");
