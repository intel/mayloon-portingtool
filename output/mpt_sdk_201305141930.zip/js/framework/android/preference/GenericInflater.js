﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.content.Context", "android.util.AttributeSet", "java.util.HashMap"], "android.preference.GenericInflater", ["android.view.InflateException", "java.lang.IllegalStateException", "$.NullPointerException", "org.xmlpull.v1.XmlPullParser"], function () {
c$ = Clazz.decorateAsClass (function () {
this.DEBUG = false;
this.mContext = null;
this.mFactorySet = false;
this.mFactory = null;
this.mConstructorArgs = null;
this.mDefaultPackage = null;
Clazz.instantialize (this, arguments);
}, android.preference, "GenericInflater");
Clazz.prepareFields (c$, function () {
this.mConstructorArgs =  new Array (2);
});
Clazz.makeConstructor (c$, 
function (context) {
this.mContext = context;
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (original, newContext) {
this.mContext = newContext;
this.mFactory = original.mFactory;
}, "android.preference.GenericInflater,android.content.Context");
Clazz.defineMethod (c$, "setDefaultPackage", 
function (defaultPackage) {
this.mDefaultPackage = defaultPackage;
}, "~S");
Clazz.defineMethod (c$, "getDefaultPackage", 
function () {
return this.mDefaultPackage;
});
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.defineMethod (c$, "getFactory", 
function () {
return this.mFactory;
});
Clazz.defineMethod (c$, "setFactory", 
function (factory) {
if (this.mFactorySet) {
throw  new IllegalStateException ("A factory has already been set on this inflater");
}if (factory == null) {
throw  new NullPointerException ("Given factory can not be null");
}this.mFactorySet = true;
if (this.mFactory == null) {
this.mFactory = factory;
} else {
this.mFactory =  new android.preference.GenericInflater.FactoryMerger (factory, this.mFactory);
}}, "android.preference.GenericInflater.Factory");
Clazz.defineMethod (c$, "inflate", 
function (resource, root) {
return this.inflate (resource, root, root != null);
}, "~N,~O");
Clazz.defineMethod (c$, "inflate", 
function (parser, root) {
return this.inflate (parser, root, root != null);
}, "org.xmlpull.v1.XmlPullParser,~O");
Clazz.defineMethod (c$, "inflate", 
function (resource, root, attachToRoot) {
if (false) System.out.println ("INFLATING from resource: " + resource);
var parser = this.getContext ().getResources ().getXml (resource);
try {
return this.inflate (parser, root, attachToRoot);
} finally {
parser.close ();
}
}, "~N,~O,~B");
Clazz.defineMethod (c$, "inflate", 
function (parser, root, attachToRoot) {
{
var attrs = parser;
this.mConstructorArgs[0] = this.mContext;
var result = root;
try {
var type;
while ((type = parser.next ()) != parser.START_TAG && type != parser.END_DOCUMENT) {
;}
if (type != parser.START_TAG) {
throw  new android.view.InflateException (parser.getPositionDescription () + ": No start tag found!");
}if (false) {
System.out.println ("**************************");
System.out.println ("Creating root: " + parser.getName ());
System.out.println ("**************************");
}var xmlRoot = this.createItemFromTag (parser, parser.getName (), attrs);
result = this.onMergeRoots (root, attachToRoot, xmlRoot);
if (false) {
System.out.println ("-----> start inflating children");
}this.rInflate (parser, result, attrs);
if (false) {
System.out.println ("-----> done inflating children");
}} catch (e$$) {
if (Clazz.instanceOf (e$$, android.view.InflateException)) {
var e = e$$;
{
throw e;
}
} else if (Clazz.instanceOf (e$$, org.xmlpull.v1.XmlPullParserException)) {
var e = e$$;
{
var ex =  new android.view.InflateException (e.getMessage ());
ex.initCause (e);
throw ex;
}
} else if (Clazz.instanceOf (e$$, java.io.IOException)) {
var e = e$$;
{
var ex =  new android.view.InflateException (parser.getPositionDescription () + ": " + e.getMessage ());
ex.initCause (e);
throw ex;
}
} else {
throw e$$;
}
}
return result;
}}, "org.xmlpull.v1.XmlPullParser,~O,~B");
Clazz.defineMethod (c$, "createItem", 
function (name, prefix, attrs) {
var constructor = android.preference.GenericInflater.sConstructorMap.get (name);
try {
if (null == constructor) {
var classPath = prefix != null ? (prefix + name) : name;
var clazz = Class.forName (classPath);
constructor = clazz.getConstructor (android.preference.GenericInflater.mConstructorSignature);
android.preference.GenericInflater.sConstructorMap.put (name, constructor);
}var args = this.mConstructorArgs;
args[1] = attrs;
return constructor.newInstance (args);
} catch (e$$) {
if (Clazz.instanceOf (e$$, NoSuchMethodException)) {
var e = e$$;
{
var ie =  new android.view.InflateException (attrs.getPositionDescription () + ": Error inflating class " + (prefix != null ? (prefix + name) : name));
ie.initCause (e);
throw ie;
}
} else if (Clazz.instanceOf (e$$, ClassNotFoundException)) {
var e = e$$;
{
throw e;
}
} else if (Clazz.instanceOf (e$$, Exception)) {
var e = e$$;
{
var ie =  new android.view.InflateException (attrs.getPositionDescription () + ": Error inflating class " + constructor.getClass ().getName ());
ie.initCause (e);
throw ie;
}
} else {
throw e$$;
}
}
}, "~S,~S,android.util.AttributeSet");
Clazz.defineMethod (c$, "onCreateItem", 
function (name, attrs) {
return this.createItem (name, this.mDefaultPackage, attrs);
}, "~S,android.util.AttributeSet");
Clazz.defineMethod (c$, "createItemFromTag", 
($fz = function (parser, name, attrs) {
if (false) System.out.println ("******** Creating item: " + name);
try {
var item = (this.mFactory == null) ? null : this.mFactory.onCreateItem (name, this.mContext, attrs);
if (item == null) {
if (-1 == name.indexOf ('.')) {
item = this.onCreateItem (name, attrs);
} else {
item = this.createItem (name, null, attrs);
}}if (false) System.out.println ("Created item is: " + item);
return item;
} catch (e$$) {
if (Clazz.instanceOf (e$$, android.view.InflateException)) {
var e = e$$;
{
throw e;
}
} else if (Clazz.instanceOf (e$$, ClassNotFoundException)) {
var e = e$$;
{
var ie =  new android.view.InflateException (attrs.getPositionDescription () + ": Error inflating class " + name);
ie.initCause (e);
throw ie;
}
} else if (Clazz.instanceOf (e$$, Exception)) {
var e = e$$;
{
var ie =  new android.view.InflateException (attrs.getPositionDescription () + ": Error inflating class " + name);
ie.initCause (e);
throw ie;
}
} else {
throw e$$;
}
}
}, $fz.isPrivate = true, $fz), "org.xmlpull.v1.XmlPullParser,~S,android.util.AttributeSet");
Clazz.defineMethod (c$, "rInflate", 
($fz = function (parser, parent, attrs) {
var depth = parser.getDepth ();
var type;
while (((type = parser.next ()) != parser.END_TAG || parser.getDepth () > depth) && type != parser.END_DOCUMENT) {
if (type != parser.START_TAG) {
continue ;}if (this.onCreateCustomFromTag (parser, parent, attrs)) {
continue ;}if (false) {
System.out.println ("Now inflating tag: " + parser.getName ());
}var name = parser.getName ();
var item = this.createItemFromTag (parser, name, attrs);
if (false) {
System.out.println ("Creating params from parent: " + parent);
}(parent).addItemFromInflater (item);
if (false) {
System.out.println ("-----> start inflating children");
}this.rInflate (parser, item, attrs);
if (false) {
System.out.println ("-----> done inflating children");
}}
}, $fz.isPrivate = true, $fz), "org.xmlpull.v1.XmlPullParser,~O,android.util.AttributeSet");
Clazz.defineMethod (c$, "onCreateCustomFromTag", 
function (parser, parent, attrs) {
return false;
}, "org.xmlpull.v1.XmlPullParser,~O,android.util.AttributeSet");
Clazz.defineMethod (c$, "onMergeRoots", 
function (givenRoot, attachToGivenRoot, xmlRoot) {
return xmlRoot;
}, "~O,~B,~O");
Clazz.declareInterface (android.preference.GenericInflater, "Parent");
Clazz.declareInterface (android.preference.GenericInflater, "Factory");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mF1 = null;
this.mF2 = null;
Clazz.instantialize (this, arguments);
}, android.preference.GenericInflater, "FactoryMerger", null, android.preference.GenericInflater.Factory);
Clazz.makeConstructor (c$, 
function (a, b) {
this.mF1 = a;
this.mF2 = b;
}, "android.preference.GenericInflater.Factory,android.preference.GenericInflater.Factory");
Clazz.defineMethod (c$, "onCreateItem", 
function (a, b, c) {
var d = this.mF1.onCreateItem (a, b, c);
if (d != null) return d;
return this.mF2.onCreateItem (a, b, c);
}, "~S,android.content.Context,android.util.AttributeSet");
c$ = Clazz.p0p ();
c$.mConstructorSignature = c$.prototype.mConstructorSignature = [android.content.Context, android.util.AttributeSet];
c$.sConstructorMap = c$.prototype.sConstructorMap =  new java.util.HashMap ();
});
