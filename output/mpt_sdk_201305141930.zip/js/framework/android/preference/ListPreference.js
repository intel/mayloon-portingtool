﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.preference.DialogPreference", "$.Preference", "android.os.Parcelable.Creator"], "android.preference.ListPreference", ["android.content.DialogInterface.OnClickListener", "com.android.internal.R", "java.lang.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mEntries = null;
this.mEntryValues = null;
this.mValue = null;
this.$mSummary = null;
this.mClickedDialogEntryIndex = 0;
Clazz.instantialize (this, arguments);
}, android.preference, "ListPreference", android.preference.DialogPreference);
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.preference.ListPreference, [context, attrs]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.ListPreference, 0, 0);
this.mEntries = a.getTextArray (0);
this.mEntryValues = a.getTextArray (1);
a.recycle ();
a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.Preference, 0, 0);
this.$mSummary = a.getString (6);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.defineMethod (c$, "setEntries", 
function (entries) {
this.mEntries = entries;
}, "~A");
Clazz.defineMethod (c$, "setEntries", 
function (entriesResId) {
this.setEntries (this.getContext ().getResources ().getTextArray (entriesResId));
}, "~N");
Clazz.defineMethod (c$, "getEntries", 
function () {
return this.mEntries;
});
Clazz.defineMethod (c$, "setEntryValues", 
function (entryValues) {
this.mEntryValues = entryValues;
}, "~A");
Clazz.defineMethod (c$, "setEntryValues", 
function (entryValuesResId) {
this.setEntryValues (this.getContext ().getResources ().getTextArray (entryValuesResId));
}, "~N");
Clazz.defineMethod (c$, "getEntryValues", 
function () {
return this.mEntryValues;
});
Clazz.defineMethod (c$, "setValue", 
function (value) {
this.mValue = value;
this.persistString (value);
}, "~S");
Clazz.defineMethod (c$, "getSummary", 
function () {
var entry = this.getEntry ();
if (this.$mSummary == null || entry == null) {
return Clazz.superCall (this, android.preference.ListPreference, "getSummary", []);
} else {
return String.format (this.$mSummary, [entry]);
}});
Clazz.defineMethod (c$, "setSummary", 
function (summary) {
Clazz.superCall (this, android.preference.ListPreference, "setSummary", [summary]);
if (summary == null && this.$mSummary != null) {
this.$mSummary = null;
} else if (summary != null && !summary.equals (this.$mSummary)) {
this.$mSummary = summary.toString ();
}}, "CharSequence");
Clazz.defineMethod (c$, "setValueIndex", 
function (index) {
if (this.mEntryValues != null) {
this.setValue (this.mEntryValues[index].toString ());
}}, "~N");
Clazz.defineMethod (c$, "getValue", 
function () {
return this.mValue;
});
Clazz.defineMethod (c$, "getEntry", 
function () {
var index = this.getValueIndex ();
return index >= 0 && this.mEntries != null ? this.mEntries[index] : null;
});
Clazz.defineMethod (c$, "findIndexOfValue", 
function (value) {
if (value != null && this.mEntryValues != null) {
for (var i = this.mEntryValues.length - 1; i >= 0; i--) {
if (this.mEntryValues[i].equals (value)) {
return i;
}}
}return -1;
}, "~S");
Clazz.defineMethod (c$, "getValueIndex", 
($fz = function () {
return this.findIndexOfValue (this.mValue);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "onPrepareDialogBuilder", 
function (builder) {
Clazz.superCall (this, android.preference.ListPreference, "onPrepareDialogBuilder", [builder]);
if (this.mEntries == null || this.mEntryValues == null) {
throw  new IllegalStateException ("ListPreference requires an entries array and an entryValues array.");
}this.mClickedDialogEntryIndex = this.getValueIndex ();
builder.setSingleChoiceItems (this.mEntries, this.mClickedDialogEntryIndex, ((Clazz.isClassDefined ("android.preference.ListPreference$1") ? 0 : android.preference.ListPreference.$ListPreference$1$ ()), Clazz.innerTypeInstance (android.preference.ListPreference$1, this, null)));
builder.setPositiveButton (null, null);
}, "android.app.AlertDialog.Builder");
Clazz.defineMethod (c$, "onDialogClosed", 
function (positiveResult) {
Clazz.superCall (this, android.preference.ListPreference, "onDialogClosed", [positiveResult]);
if (positiveResult && this.mClickedDialogEntryIndex >= 0 && this.mEntryValues != null) {
var value = this.mEntryValues[this.mClickedDialogEntryIndex].toString ();
if (this.callChangeListener (value)) {
this.setValue (value);
}}}, "~B");
Clazz.overrideMethod (c$, "onGetDefaultValue", 
function (a, index) {
return a.getString (index);
}, "android.content.res.TypedArray,~N");
Clazz.overrideMethod (c$, "onSetInitialValue", 
function (restoreValue, defaultValue) {
this.setValue (restoreValue ? this.getPersistedString (this.mValue) : defaultValue);
}, "~B,~O");
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
var superState = Clazz.superCall (this, android.preference.ListPreference, "onSaveInstanceState", []);
if (this.isPersistent ()) {
return superState;
}var myState =  new android.preference.ListPreference.SavedState (superState);
myState.value = this.getValue ();
return myState;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
if (state == null || !state.getClass ().equals (android.preference.ListPreference.SavedState)) {
Clazz.superCall (this, android.preference.ListPreference, "onRestoreInstanceState", [state]);
return ;
}var myState = state;
Clazz.superCall (this, android.preference.ListPreference, "onRestoreInstanceState", [myState.getSuperState ()]);
this.setValue (myState.value);
}, "android.os.Parcelable");
c$.$ListPreference$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.preference, "ListPreference$1", null, android.content.DialogInterface.OnClickListener);
Clazz.overrideMethod (c$, "onClick", 
function (dialog, which) {
this.b$["android.preference.ListPreference"].mClickedDialogEntryIndex = which;
this.b$["android.preference.ListPreference"].onClick (dialog, -1);
dialog.dismiss ();
}, "android.content.DialogInterface,~N");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.value = null;
Clazz.instantialize (this, arguments);
}, android.preference.ListPreference, "SavedState", android.preference.Preference.BaseSavedState);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.preference.ListPreference.SavedState, [a]);
this.value = a.readString ();
}, "android.os.Parcel");
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
Clazz.superCall (this, android.preference.ListPreference.SavedState, "writeToParcel", [a, b]);
a.writeString (this.value);
}, "android.os.Parcel,~N");
c$.$ListPreference$SavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.preference, "ListPreference$SavedState$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.preference.ListPreference.SavedState (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.$$CREATOR = c$.prototype.$$CREATOR = ((Clazz.isClassDefined ("android.preference.ListPreference$SavedState$1") ? 0 : android.preference.ListPreference.SavedState.$ListPreference$SavedState$1$ ()), Clazz.innerTypeInstance (android.preference.ListPreference$SavedState$1, this, null));
c$ = Clazz.p0p ();
});
