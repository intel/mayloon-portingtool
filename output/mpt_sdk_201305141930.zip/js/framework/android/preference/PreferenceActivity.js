﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.app.ListActivity", "android.preference.PreferenceManager", "android.os.Handler"], "android.preference.PreferenceActivity", ["android.os.Bundle", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPreferenceManager = null;
this.mSavedInstanceState = null;
this.$mHandler = null;
Clazz.instantialize (this, arguments);
}, android.preference, "PreferenceActivity", android.app.ListActivity, android.preference.PreferenceManager.OnPreferenceTreeClickListener);
Clazz.prepareFields (c$, function () {
this.$mHandler = ((Clazz.isClassDefined ("android.preference.PreferenceActivity$1") ? 0 : android.preference.PreferenceActivity.$PreferenceActivity$1$ ()), Clazz.innerTypeInstance (android.preference.PreferenceActivity$1, this, null));
});
Clazz.defineMethod (c$, "onCreate", 
function (savedInstanceState) {
Clazz.superCall (this, android.preference.PreferenceActivity, "onCreate", [savedInstanceState]);
this.mPreferenceManager = this.onCreatePreferenceManager ();
this.setContentView (17367116);
this.getListView ().setScrollBarStyle (0);
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onStop", 
function () {
Clazz.superCall (this, android.preference.PreferenceActivity, "onStop", []);
this.mPreferenceManager.dispatchActivityStop ();
});
Clazz.defineMethod (c$, "onDestroy", 
function () {
Clazz.superCall (this, android.preference.PreferenceActivity, "onDestroy", []);
this.mPreferenceManager.dispatchActivityDestroy ();
});
Clazz.defineMethod (c$, "onSaveInstanceState", 
function (outState) {
Clazz.superCall (this, android.preference.PreferenceActivity, "onSaveInstanceState", [outState]);
var preferenceScreen = this.getPreferenceScreen ();
if (preferenceScreen != null) {
var container =  new android.os.Bundle ();
preferenceScreen.saveHierarchyState (container);
outState.putBundle ("android:preferences", container);
}}, "android.os.Bundle");
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
var container = state.getBundle ("android:preferences");
if (container != null) {
var preferenceScreen = this.getPreferenceScreen ();
if (preferenceScreen != null) {
preferenceScreen.restoreHierarchyState (container);
this.mSavedInstanceState = state;
return ;
}}Clazz.superCall (this, android.preference.PreferenceActivity, "onRestoreInstanceState", [state]);
}, "android.os.Bundle");
Clazz.defineMethod (c$, "onActivityResult", 
function (requestCode, resultCode, data) {
Clazz.superCall (this, android.preference.PreferenceActivity, "onActivityResult", [requestCode, resultCode, data]);
this.mPreferenceManager.dispatchActivityResult (requestCode, resultCode, data);
}, "~N,~N,android.content.Intent");
Clazz.defineMethod (c$, "onContentChanged", 
function () {
Clazz.superCall (this, android.preference.PreferenceActivity, "onContentChanged", []);
this.postBindPreferences ();
});
Clazz.defineMethod (c$, "postBindPreferences", 
($fz = function () {
if (this.$mHandler.hasMessages (0)) return ;
this.$mHandler.obtainMessage (0).sendToTarget ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "bindPreferences", 
($fz = function () {
var preferenceScreen = this.getPreferenceScreen ();
if (preferenceScreen != null) {
preferenceScreen.bind (this.getListView ());
if (this.mSavedInstanceState != null) {
Clazz.superCall (this, android.preference.PreferenceActivity, "onRestoreInstanceState", [this.mSavedInstanceState]);
this.mSavedInstanceState = null;
}}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "onCreatePreferenceManager", 
($fz = function () {
var preferenceManager =  new android.preference.PreferenceManager (this, 100);
preferenceManager.setOnPreferenceTreeClickListener (this);
return preferenceManager;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "getPreferenceManager", 
function () {
return this.mPreferenceManager;
});
Clazz.defineMethod (c$, "requirePreferenceManager", 
($fz = function () {
if (this.mPreferenceManager == null) {
throw  new RuntimeException ("This should be called after super.onCreate.");
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setPreferenceScreen", 
function (preferenceScreen) {
if (this.mPreferenceManager.setPreferences (preferenceScreen) && preferenceScreen != null) {
this.postBindPreferences ();
var title = this.getPreferenceScreen ().getTitle ();
if (title != null) {
this.setTitle (title);
}}}, "android.preference.PreferenceScreen");
Clazz.defineMethod (c$, "getPreferenceScreen", 
function () {
return this.mPreferenceManager.getPreferenceScreen ();
});
Clazz.defineMethod (c$, "addPreferencesFromIntent", 
function (intent) {
this.requirePreferenceManager ();
this.setPreferenceScreen (this.mPreferenceManager.inflateFromIntent (intent, this.getPreferenceScreen ()));
}, "android.content.Intent");
Clazz.defineMethod (c$, "addPreferencesFromResource", 
function (preferencesResId) {
this.requirePreferenceManager ();
this.setPreferenceScreen (this.mPreferenceManager.inflateFromResource (this, preferencesResId, this.getPreferenceScreen ()));
}, "~N");
Clazz.overrideMethod (c$, "onPreferenceTreeClick", 
function (preferenceScreen, preference) {
return false;
}, "android.preference.PreferenceScreen,android.preference.Preference");
Clazz.defineMethod (c$, "findPreference", 
function (key) {
if (this.mPreferenceManager == null) {
return null;
}return this.mPreferenceManager.findPreference (key);
}, "CharSequence");
Clazz.overrideMethod (c$, "onNewIntent", 
function (intent) {
if (this.mPreferenceManager != null) {
this.mPreferenceManager.dispatchNewIntent (intent);
}}, "android.content.Intent");
c$.$PreferenceActivity$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.preference, "PreferenceActivity$1", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (msg) {
switch (msg.what) {
case 0:
this.b$["android.preference.PreferenceActivity"].bindPreferences ();
break;
}
}, "android.os.Message");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"PREFERENCES_TAG", "android:preferences",
"FIRST_REQUEST_CODE", 100,
"MSG_BIND_PREFERENCES", 0);
});
