﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.content.DialogInterface", "android.preference.Preference", "$.PreferenceGroup", "android.widget.AdapterView", "android.os.Parcelable.Creator"], "android.preference.PreferenceScreen", ["android.app.Dialog", "android.preference.PreferenceGroupAdapter", "android.text.TextUtils", "android.widget.ListView"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mRootAdapter = null;
this.mDialog = null;
this.mListView = null;
Clazz.instantialize (this, arguments);
}, android.preference, "PreferenceScreen", android.preference.PreferenceGroup, [android.widget.AdapterView.OnItemClickListener, android.content.DialogInterface.OnDismissListener]);
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.preference.PreferenceScreen, [context, attrs, 16842891]);
}, "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "getRootAdapter", 
function () {
if (this.mRootAdapter == null) {
this.mRootAdapter = this.onCreateRootAdapter ();
}return this.mRootAdapter;
});
Clazz.defineMethod (c$, "onCreateRootAdapter", 
function () {
return  new android.preference.PreferenceGroupAdapter (this);
});
Clazz.defineMethod (c$, "bind", 
function (listView) {
listView.setOnItemClickListener (this);
listView.setAdapter (this.getRootAdapter ());
this.onAttachedToActivity ();
}, "android.widget.ListView");
Clazz.overrideMethod (c$, "onClick", 
function () {
if (this.getIntent () != null || this.getPreferenceCount () == 0) {
return ;
}this.showDialog (null);
});
Clazz.defineMethod (c$, "showDialog", 
($fz = function (state) {
var context = this.getContext ();
if (this.mListView != null) {
this.mListView.setAdapter (null);
}this.mListView =  new android.widget.ListView (context);
this.bind (this.mListView);
var title = this.getTitle ();
var dialog = this.mDialog =  new android.app.Dialog (context, android.text.TextUtils.isEmpty (title) ? 16973830 : 16973829);
dialog.setContentView (this.mListView);
if (!android.text.TextUtils.isEmpty (title)) {
dialog.setTitle (title);
}dialog.setOnDismissListener (this);
if (state != null) {
dialog.onRestoreInstanceState (state);
}this.getPreferenceManager ().addPreferencesScreen (dialog);
dialog.show ();
}, $fz.isPrivate = true, $fz), "android.os.Bundle");
Clazz.overrideMethod (c$, "onDismiss", 
function (dialog) {
this.mDialog = null;
this.getPreferenceManager ().removePreferencesScreen (dialog);
}, "android.content.DialogInterface");
Clazz.defineMethod (c$, "getDialog", 
function () {
return this.mDialog;
});
Clazz.overrideMethod (c$, "onItemClick", 
function (parent, view, position, id) {
var item = this.getRootAdapter ().getItem (position);
if (!(Clazz.instanceOf (item, android.preference.Preference))) return ;
var preference = item;
preference.performClick (this);
}, "android.widget.AdapterView,android.view.View,~N,~N");
Clazz.overrideMethod (c$, "isOnSameScreenAsChildren", 
function () {
return false;
});
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
var superState = Clazz.superCall (this, android.preference.PreferenceScreen, "onSaveInstanceState", []);
var dialog = this.mDialog;
if (dialog == null || !dialog.isShowing ()) {
return superState;
}var myState =  new android.preference.PreferenceScreen.SavedState (superState);
myState.isDialogShowing = true;
myState.dialogBundle = dialog.onSaveInstanceState ();
return myState;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
if (state == null || !state.getClass ().equals (android.preference.PreferenceScreen.SavedState)) {
Clazz.superCall (this, android.preference.PreferenceScreen, "onRestoreInstanceState", [state]);
return ;
}var myState = state;
Clazz.superCall (this, android.preference.PreferenceScreen, "onRestoreInstanceState", [myState.getSuperState ()]);
if (myState.isDialogShowing) {
this.showDialog (myState.dialogBundle);
}}, "android.os.Parcelable");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.isDialogShowing = false;
this.dialogBundle = null;
Clazz.instantialize (this, arguments);
}, android.preference.PreferenceScreen, "SavedState", android.preference.Preference.BaseSavedState);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.preference.PreferenceScreen.SavedState, [a]);
this.isDialogShowing = a.readInt () == 1;
this.dialogBundle = a.readBundle ();
}, "android.os.Parcel");
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
Clazz.superCall (this, android.preference.PreferenceScreen.SavedState, "writeToParcel", [a, b]);
a.writeInt (this.isDialogShowing ? 1 : 0);
a.writeBundle (this.dialogBundle);
}, "android.os.Parcel,~N");
c$.$PreferenceScreen$SavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.preference, "PreferenceScreen$SavedState$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.preference.PreferenceScreen.SavedState (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.$$CREATOR = c$.prototype.$$CREATOR = ((Clazz.isClassDefined ("android.preference.PreferenceScreen$SavedState$1") ? 0 : android.preference.PreferenceScreen.SavedState.$PreferenceScreen$SavedState$1$ ()), Clazz.innerTypeInstance (android.preference.PreferenceScreen$SavedState$1, this, null));
c$ = Clazz.p0p ();
});
