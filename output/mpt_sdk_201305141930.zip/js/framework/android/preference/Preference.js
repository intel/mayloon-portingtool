﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.preference.OnDependencyChangeListener", "android.view.AbsSavedState", "android.os.Parcelable.Creator"], "android.preference.Preference", ["android.text.TextUtils", "com.android.internal.R", "com.android.internal.util.CharSequences", "java.lang.IllegalArgumentException", "$.IllegalStateException", "$.StringBuilder", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mContext = null;
this.mPreferenceManager = null;
this.mId = 0;
this.mOnChangeListener = null;
this.mOnClickListener = null;
this.mOrder = 2147483647;
this.mTitle = null;
this.mSummary = null;
this.mKey = null;
this.mIntent = null;
this.mEnabled = true;
this.mSelectable = true;
this.mRequiresKey = false;
this.mPersistent = true;
this.mDependencyKey = null;
this.mDefaultValue = null;
this.mDependencyMet = true;
this.mShouldDisableView = true;
this.mLayoutResId = 17367111;
this.mWidgetLayoutResId = 0;
this.mHasSpecifiedLayout = false;
this.mListener = null;
this.mDependents = null;
this.mBaseMethodCalled = false;
Clazz.instantialize (this, arguments);
}, android.preference, "Preference", null, [Comparable, android.preference.OnDependencyChangeListener]);
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
this.mContext = context;
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.Preference, defStyle, 0);
for (var i = a.getIndexCount (); i >= 0; i--) {
var attr = a.getIndex (i);
switch (attr) {
case 5:
this.mKey = a.getString (attr);
break;
case 3:
this.mTitle = a.getString (attr);
break;
case 6:
this.mSummary = a.getString (attr);
break;
case 7:
this.mOrder = a.getInt (attr, this.mOrder);
break;
case 2:
this.mLayoutResId = a.getResourceId (attr, this.mLayoutResId);
break;
case 8:
this.mWidgetLayoutResId = a.getResourceId (attr, this.mWidgetLayoutResId);
break;
case 1:
this.mEnabled = a.getBoolean (attr, true);
break;
case 4:
this.mSelectable = a.getBoolean (attr, true);
break;
case 0:
this.mPersistent = a.getBoolean (attr, this.mPersistent);
break;
case 9:
this.mDependencyKey = a.getString (attr);
break;
case 10:
this.mDefaultValue = this.onGetDefaultValue (a, attr);
break;
case 11:
this.mShouldDisableView = a.getBoolean (attr, this.mShouldDisableView);
break;
}
}
a.recycle ();
if (!this.getClass ().getName ().startsWith ("android.preference")) {
this.mHasSpecifiedLayout = true;
}}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 0);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.defineMethod (c$, "onGetDefaultValue", 
function (a, index) {
return null;
}, "android.content.res.TypedArray,~N");
Clazz.defineMethod (c$, "setIntent", 
function (intent) {
this.mIntent = intent;
}, "android.content.Intent");
Clazz.defineMethod (c$, "getIntent", 
function () {
return this.mIntent;
});
Clazz.defineMethod (c$, "setLayoutResource", 
function (layoutResId) {
if (layoutResId != this.mLayoutResId) {
this.mHasSpecifiedLayout = true;
}this.mLayoutResId = layoutResId;
}, "~N");
Clazz.defineMethod (c$, "getLayoutResource", 
function () {
return this.mLayoutResId;
});
Clazz.defineMethod (c$, "setWidgetLayoutResource", 
function (widgetLayoutResId) {
if (widgetLayoutResId != this.mWidgetLayoutResId) {
this.mHasSpecifiedLayout = true;
}this.mWidgetLayoutResId = widgetLayoutResId;
}, "~N");
Clazz.defineMethod (c$, "getWidgetLayoutResource", 
function () {
return this.mWidgetLayoutResId;
});
Clazz.defineMethod (c$, "getView", 
function (convertView, parent) {
if (convertView == null) {
convertView = this.onCreateView (parent);
}this.onBindView (convertView);
return convertView;
}, "android.view.View,android.view.ViewGroup");
Clazz.defineMethod (c$, "onCreateView", 
function (parent) {
var layoutInflater = this.mContext.getSystemService ("layout_inflater");
var layout = layoutInflater.inflate (this.mLayoutResId, parent, false);
if (this.mWidgetLayoutResId != 0) {
var widgetFrame = layout.findViewById (16908312);
layoutInflater.inflate (this.mWidgetLayoutResId, widgetFrame);
}return layout;
}, "android.view.ViewGroup");
Clazz.defineMethod (c$, "onBindView", 
function (view) {
var textView = view.findViewById (16908310);
if (textView != null) {
textView.setText (this.getTitle ());
}textView = view.findViewById (16908304);
if (textView != null) {
var summary = this.getSummary ();
if (!android.text.TextUtils.isEmpty (summary)) {
if (textView.getVisibility () != 0) {
textView.setVisibility (0);
}textView.setText (this.getSummary ());
} else {
if (textView.getVisibility () != 8) {
textView.setVisibility (8);
}}}if (this.mShouldDisableView) {
this.setEnabledStateOnViews (view, this.isEnabled ());
}}, "android.view.View");
Clazz.defineMethod (c$, "setEnabledStateOnViews", 
($fz = function (v, enabled) {
v.setEnabled (enabled);
if (Clazz.instanceOf (v, android.view.ViewGroup)) {
var vg = v;
for (var i = vg.getChildCount () - 1; i >= 0; i--) {
this.setEnabledStateOnViews (vg.getChildAt (i), enabled);
}
}}, $fz.isPrivate = true, $fz), "android.view.View,~B");
Clazz.defineMethod (c$, "setOrder", 
function (order) {
if (order != this.mOrder) {
this.mOrder = order;
this.notifyHierarchyChanged ();
}}, "~N");
Clazz.defineMethod (c$, "getOrder", 
function () {
return this.mOrder;
});
Clazz.defineMethod (c$, "setTitle", 
function (title) {
if (title == null && this.mTitle != null || title != null && !title.equals (this.mTitle)) {
this.mTitle = title;
this.notifyChanged ();
}}, "CharSequence");
Clazz.defineMethod (c$, "setTitle", 
function (titleResId) {
this.setTitle (this.mContext.getString (titleResId));
}, "~N");
Clazz.defineMethod (c$, "getTitle", 
function () {
return this.mTitle;
});
Clazz.defineMethod (c$, "getSummary", 
function () {
return this.mSummary;
});
Clazz.defineMethod (c$, "setSummary", 
function (summary) {
if (summary == null && this.mSummary != null || summary != null && !summary.equals (this.mSummary)) {
this.mSummary = summary;
this.notifyChanged ();
}}, "CharSequence");
Clazz.defineMethod (c$, "setSummary", 
function (summaryResId) {
this.setSummary (this.mContext.getString (summaryResId));
}, "~N");
Clazz.defineMethod (c$, "setEnabled", 
function (enabled) {
if (this.mEnabled != enabled) {
this.mEnabled = enabled;
this.notifyDependencyChange (this.shouldDisableDependents ());
this.notifyChanged ();
}}, "~B");
Clazz.defineMethod (c$, "isEnabled", 
function () {
return this.mEnabled && this.mDependencyMet;
});
Clazz.defineMethod (c$, "setSelectable", 
function (selectable) {
if (this.mSelectable != selectable) {
this.mSelectable = selectable;
this.notifyChanged ();
}}, "~B");
Clazz.defineMethod (c$, "isSelectable", 
function () {
return this.mSelectable;
});
Clazz.defineMethod (c$, "setShouldDisableView", 
function (shouldDisableView) {
this.mShouldDisableView = shouldDisableView;
this.notifyChanged ();
}, "~B");
Clazz.defineMethod (c$, "getShouldDisableView", 
function () {
return this.mShouldDisableView;
});
Clazz.defineMethod (c$, "getId", 
function () {
return this.mId;
});
Clazz.defineMethod (c$, "onClick", 
function () {
});
Clazz.defineMethod (c$, "setKey", 
function (key) {
this.mKey = key;
if (this.mRequiresKey && !this.hasKey ()) {
this.requireKey ();
}}, "~S");
Clazz.defineMethod (c$, "getKey", 
function () {
return this.mKey;
});
Clazz.defineMethod (c$, "requireKey", 
function () {
if (this.mKey == null) {
throw  new IllegalStateException ("Preference does not have a key assigned.");
}this.mRequiresKey = true;
});
Clazz.defineMethod (c$, "hasKey", 
function () {
return !android.text.TextUtils.isEmpty (this.mKey);
});
Clazz.defineMethod (c$, "isPersistent", 
function () {
return this.mPersistent;
});
Clazz.defineMethod (c$, "shouldPersist", 
function () {
return this.mPreferenceManager != null && this.isPersistent () && this.hasKey ();
});
Clazz.defineMethod (c$, "setPersistent", 
function (persistent) {
this.mPersistent = persistent;
}, "~B");
Clazz.defineMethod (c$, "callChangeListener", 
function (newValue) {
return this.mOnChangeListener == null ? true : this.mOnChangeListener.onPreferenceChange (this, newValue);
}, "~O");
Clazz.defineMethod (c$, "setOnPreferenceChangeListener", 
function (onPreferenceChangeListener) {
this.mOnChangeListener = onPreferenceChangeListener;
}, "android.preference.Preference.OnPreferenceChangeListener");
Clazz.defineMethod (c$, "getOnPreferenceChangeListener", 
function () {
return this.mOnChangeListener;
});
Clazz.defineMethod (c$, "setOnPreferenceClickListener", 
function (onPreferenceClickListener) {
this.mOnClickListener = onPreferenceClickListener;
}, "android.preference.Preference.OnPreferenceClickListener");
Clazz.defineMethod (c$, "getOnPreferenceClickListener", 
function () {
return this.mOnClickListener;
});
Clazz.defineMethod (c$, "performClick", 
function (preferenceScreen) {
if (!this.isEnabled ()) {
return ;
}this.onClick ();
if (this.mOnClickListener != null && this.mOnClickListener.onPreferenceClick (this)) {
return ;
}var preferenceManager = this.getPreferenceManager ();
if (preferenceManager != null) {
var listener = preferenceManager.getOnPreferenceTreeClickListener ();
if (preferenceScreen != null && listener != null && listener.onPreferenceTreeClick (preferenceScreen, this)) {
return ;
}}if (this.mIntent != null) {
var context = this.getContext ();
context.startActivity (this.mIntent);
}}, "android.preference.PreferenceScreen");
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.defineMethod (c$, "getSharedPreferences", 
function () {
if (this.mPreferenceManager == null) {
return null;
}return this.mPreferenceManager.getSharedPreferences ();
});
Clazz.defineMethod (c$, "getEditor", 
function () {
if (this.mPreferenceManager == null) {
return null;
}return this.mPreferenceManager.getEditor ();
});
Clazz.defineMethod (c$, "shouldCommit", 
function () {
if (this.mPreferenceManager == null) {
return false;
}return this.mPreferenceManager.shouldCommit ();
});
Clazz.overrideMethod (c$, "compareTo", 
function (another) {
if (this.mOrder != 2147483647 || (this.mOrder == 2147483647 && another.mOrder != 2147483647)) {
return this.mOrder - another.mOrder;
} else if (this.mTitle == null) {
return 1;
} else if (another.mTitle == null) {
return -1;
} else {
return com.android.internal.util.CharSequences.compareToIgnoreCase (this.mTitle, another.mTitle);
}}, "android.preference.Preference");
Clazz.defineMethod (c$, "setOnPreferenceChangeInternalListener", 
function (listener) {
this.mListener = listener;
}, "android.preference.Preference.OnPreferenceChangeInternalListener");
Clazz.defineMethod (c$, "notifyChanged", 
function () {
if (this.mListener != null) {
this.mListener.onPreferenceChange (this);
}});
Clazz.defineMethod (c$, "notifyHierarchyChanged", 
function () {
if (this.mListener != null) {
this.mListener.onPreferenceHierarchyChange (this);
}});
Clazz.defineMethod (c$, "getPreferenceManager", 
function () {
return this.mPreferenceManager;
});
Clazz.defineMethod (c$, "onAttachedToHierarchy", 
function (preferenceManager) {
this.mPreferenceManager = preferenceManager;
this.mId = preferenceManager.getNextId ();
this.dispatchSetInitialValue ();
}, "android.preference.PreferenceManager");
Clazz.defineMethod (c$, "onAttachedToActivity", 
function () {
this.registerDependency ();
});
Clazz.defineMethod (c$, "registerDependency", 
($fz = function () {
if (android.text.TextUtils.isEmpty (this.mDependencyKey)) return ;
var preference = this.findPreferenceInHierarchy (this.mDependencyKey);
if (preference != null) {
preference.registerDependent (this);
} else {
throw  new IllegalStateException ("Dependency \"" + this.mDependencyKey + "\" not found for preference \"" + this.mKey + "\" (title: \"" + this.mTitle + "\"");
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "unregisterDependency", 
($fz = function () {
if (this.mDependencyKey != null) {
var oldDependency = this.findPreferenceInHierarchy (this.mDependencyKey);
if (oldDependency != null) {
oldDependency.unregisterDependent (this);
}}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "findPreferenceInHierarchy", 
function (key) {
if (android.text.TextUtils.isEmpty (key) || this.mPreferenceManager == null) {
return null;
}return this.mPreferenceManager.findPreference (key);
}, "~S");
Clazz.defineMethod (c$, "registerDependent", 
($fz = function (dependent) {
if (this.mDependents == null) {
this.mDependents =  new java.util.ArrayList ();
}this.mDependents.add (dependent);
dependent.onDependencyChanged (this, this.shouldDisableDependents ());
}, $fz.isPrivate = true, $fz), "android.preference.Preference");
Clazz.defineMethod (c$, "unregisterDependent", 
($fz = function (dependent) {
if (this.mDependents != null) {
this.mDependents.remove (dependent);
}}, $fz.isPrivate = true, $fz), "android.preference.Preference");
Clazz.defineMethod (c$, "notifyDependencyChange", 
function (disableDependents) {
var dependents = this.mDependents;
if (dependents == null) {
return ;
}var dependentsCount = dependents.size ();
for (var i = 0; i < dependentsCount; i++) {
dependents.get (i).onDependencyChanged (this, disableDependents);
}
}, "~B");
Clazz.overrideMethod (c$, "onDependencyChanged", 
function (dependency, disableDependent) {
if (this.mDependencyMet == disableDependent) {
this.mDependencyMet = !disableDependent;
this.notifyDependencyChange (this.shouldDisableDependents ());
this.notifyChanged ();
}}, "android.preference.Preference,~B");
Clazz.defineMethod (c$, "shouldDisableDependents", 
function () {
return !this.isEnabled ();
});
Clazz.defineMethod (c$, "setDependency", 
function (dependencyKey) {
this.unregisterDependency ();
this.mDependencyKey = dependencyKey;
this.registerDependency ();
}, "~S");
Clazz.defineMethod (c$, "getDependency", 
function () {
return this.mDependencyKey;
});
Clazz.defineMethod (c$, "onPrepareForRemoval", 
function () {
this.unregisterDependency ();
});
Clazz.defineMethod (c$, "setDefaultValue", 
function (defaultValue) {
this.mDefaultValue = defaultValue;
}, "~O");
Clazz.defineMethod (c$, "dispatchSetInitialValue", 
($fz = function () {
var shouldPersist = this.shouldPersist ();
if (!shouldPersist || !this.getSharedPreferences ().contains (this.mKey)) {
if (this.mDefaultValue != null) {
this.onSetInitialValue (false, this.mDefaultValue);
}} else {
this.onSetInitialValue (true, null);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "onSetInitialValue", 
function (restorePersistedValue, defaultValue) {
}, "~B,~O");
Clazz.defineMethod (c$, "tryCommit", 
($fz = function (editor) {
if (this.mPreferenceManager.shouldCommit ()) {
try {
editor.apply ();
} catch (unused) {
if (Clazz.instanceOf (unused, AbstractMethodError)) {
editor.commit ();
} else {
throw unused;
}
}
}}, $fz.isPrivate = true, $fz), "android.content.SharedPreferences.Editor");
Clazz.defineMethod (c$, "persistString", 
function (value) {
if (this.shouldPersist ()) {
if (value === this.getPersistedString (null)) {
return true;
}var editor = this.mPreferenceManager.getEditor ();
editor.putString (this.mKey, value);
this.tryCommit (editor);
return true;
}return false;
}, "~S");
Clazz.defineMethod (c$, "getPersistedString", 
function (defaultReturnValue) {
if (!this.shouldPersist ()) {
return defaultReturnValue;
}return this.mPreferenceManager.getSharedPreferences ().getString (this.mKey, defaultReturnValue);
}, "~S");
Clazz.defineMethod (c$, "persistInt", 
function (value) {
if (this.shouldPersist ()) {
if (value == this.getPersistedInt (~value)) {
return true;
}var editor = this.mPreferenceManager.getEditor ();
editor.putInt (this.mKey, value);
this.tryCommit (editor);
return true;
}return false;
}, "~N");
Clazz.defineMethod (c$, "getPersistedInt", 
function (defaultReturnValue) {
if (!this.shouldPersist ()) {
return defaultReturnValue;
}return this.mPreferenceManager.getSharedPreferences ().getInt (this.mKey, defaultReturnValue);
}, "~N");
Clazz.defineMethod (c$, "persistFloat", 
function (value) {
if (this.shouldPersist ()) {
if (value == this.getPersistedFloat (NaN)) {
return true;
}var editor = this.mPreferenceManager.getEditor ();
editor.putFloat (this.mKey, value);
this.tryCommit (editor);
return true;
}return false;
}, "~N");
Clazz.defineMethod (c$, "getPersistedFloat", 
function (defaultReturnValue) {
if (!this.shouldPersist ()) {
return defaultReturnValue;
}return this.mPreferenceManager.getSharedPreferences ().getFloat (this.mKey, defaultReturnValue);
}, "~N");
Clazz.defineMethod (c$, "persistLong", 
function (value) {
if (this.shouldPersist ()) {
if (value == this.getPersistedLong (~value)) {
return true;
}var editor = this.mPreferenceManager.getEditor ();
editor.putLong (this.mKey, value);
this.tryCommit (editor);
return true;
}return false;
}, "~N");
Clazz.defineMethod (c$, "getPersistedLong", 
function (defaultReturnValue) {
if (!this.shouldPersist ()) {
return defaultReturnValue;
}return this.mPreferenceManager.getSharedPreferences ().getLong (this.mKey, defaultReturnValue);
}, "~N");
Clazz.defineMethod (c$, "persistBoolean", 
function (value) {
if (this.shouldPersist ()) {
if (value == this.getPersistedBoolean (!value)) {
return true;
}var editor = this.mPreferenceManager.getEditor ();
editor.putBoolean (this.mKey, value);
this.tryCommit (editor);
return true;
}return false;
}, "~B");
Clazz.defineMethod (c$, "getPersistedBoolean", 
function (defaultReturnValue) {
if (!this.shouldPersist ()) {
return defaultReturnValue;
}return this.mPreferenceManager.getSharedPreferences ().getBoolean (this.mKey, defaultReturnValue);
}, "~B");
Clazz.defineMethod (c$, "hasSpecifiedLayout", 
function () {
return this.mHasSpecifiedLayout;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return this.getFilterableStringBuilder ().toString ();
});
Clazz.defineMethod (c$, "getFilterableStringBuilder", 
function () {
var sb =  new StringBuilder ();
var title = this.getTitle ();
if (!android.text.TextUtils.isEmpty (title)) {
sb.append (title).append (' ');
}var summary = this.getSummary ();
if (!android.text.TextUtils.isEmpty (summary)) {
sb.append (summary).append (' ');
}if (sb.length () > 0) {
sb.setLength (sb.length () - 1);
}return sb;
});
Clazz.defineMethod (c$, "saveHierarchyState", 
function (container) {
this.dispatchSaveInstanceState (container);
}, "android.os.Bundle");
Clazz.defineMethod (c$, "dispatchSaveInstanceState", 
function (container) {
if (this.hasKey ()) {
this.mBaseMethodCalled = false;
var state = this.onSaveInstanceState ();
if (!this.mBaseMethodCalled) {
throw  new IllegalStateException ("Derived class did not call super.onSaveInstanceState()");
}if (state != null) {
container.putParcelable (this.mKey, state);
}}}, "android.os.Bundle");
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
this.mBaseMethodCalled = true;
return android.preference.Preference.BaseSavedState.EMPTY_STATE;
});
Clazz.defineMethod (c$, "restoreHierarchyState", 
function (container) {
this.dispatchRestoreInstanceState (container);
}, "android.os.Bundle");
Clazz.defineMethod (c$, "dispatchRestoreInstanceState", 
function (container) {
if (this.hasKey ()) {
var state = container.getParcelable (this.mKey);
if (state != null) {
this.mBaseMethodCalled = false;
this.onRestoreInstanceState (state);
if (!this.mBaseMethodCalled) {
throw  new IllegalStateException ("Derived class did not call super.onRestoreInstanceState()");
}}}}, "android.os.Bundle");
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
this.mBaseMethodCalled = true;
if (state !== android.preference.Preference.BaseSavedState.EMPTY_STATE && state != null) {
throw  new IllegalArgumentException ("Wrong state class -- expecting Preference State");
}}, "android.os.Parcelable");
Clazz.declareInterface (android.preference.Preference, "OnPreferenceChangeListener");
Clazz.declareInterface (android.preference.Preference, "OnPreferenceClickListener");
Clazz.declareInterface (android.preference.Preference, "OnPreferenceChangeInternalListener");
Clazz.pu$h ();
c$ = Clazz.declareType (android.preference.Preference, "BaseSavedState", android.view.AbsSavedState);
c$.$Preference$BaseSavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.preference, "Preference$BaseSavedState$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.preference.Preference.BaseSavedState (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.$CREATOR = c$.prototype.$CREATOR = ((Clazz.isClassDefined ("android.preference.Preference$BaseSavedState$1") ? 0 : android.preference.Preference.BaseSavedState.$Preference$BaseSavedState$1$ ()), Clazz.innerTypeInstance (android.preference.Preference$BaseSavedState$1, this, null));
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DEFAULT_ORDER", 2147483647);
});
