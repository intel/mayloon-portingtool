﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.preference.GenericInflater", "$.Preference"], "android.preference.PreferenceGroup", ["android.text.TextUtils", "com.android.internal.R", "java.util.ArrayList", "$.Collections"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPreferenceList = null;
this.mOrderingAsAdded = true;
this.mCurrentPreferenceOrder = 0;
this.mAttachedToActivity = false;
Clazz.instantialize (this, arguments);
}, android.preference, "PreferenceGroup", android.preference.Preference, android.preference.GenericInflater.Parent);
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.preference.PreferenceGroup, [context, attrs, defStyle]);
this.mPreferenceList =  new java.util.ArrayList ();
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.PreferenceGroup, defStyle, 0);
this.mOrderingAsAdded = a.getBoolean (0, this.mOrderingAsAdded);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 0);
}, "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "setOrderingAsAdded", 
function (orderingAsAdded) {
this.mOrderingAsAdded = orderingAsAdded;
}, "~B");
Clazz.defineMethod (c$, "isOrderingAsAdded", 
function () {
return this.mOrderingAsAdded;
});
Clazz.overrideMethod (c$, "addItemFromInflater", 
function (preference) {
this.addPreference (preference);
}, "android.preference.Preference");
Clazz.defineMethod (c$, "getPreferenceCount", 
function () {
return this.mPreferenceList.size ();
});
Clazz.defineMethod (c$, "getPreference", 
function (index) {
return this.mPreferenceList.get (index);
}, "~N");
Clazz.defineMethod (c$, "addPreference", 
function (preference) {
if (this.mPreferenceList.contains (preference)) {
return true;
}if (preference.getOrder () == 2147483647) {
if (this.mOrderingAsAdded) {
preference.setOrder (this.mCurrentPreferenceOrder++);
}if (Clazz.instanceOf (preference, android.preference.PreferenceGroup)) {
(preference).setOrderingAsAdded (this.mOrderingAsAdded);
}}var insertionIndex = java.util.Collections.binarySearch (this.mPreferenceList, preference);
if (insertionIndex < 0) {
insertionIndex = insertionIndex * -1 - 1;
}if (!this.onPrepareAddPreference (preference)) {
return false;
}{
this.mPreferenceList.add (insertionIndex, preference);
}preference.onAttachedToHierarchy (this.getPreferenceManager ());
if (this.mAttachedToActivity) {
preference.onAttachedToActivity ();
}this.notifyHierarchyChanged ();
return true;
}, "android.preference.Preference");
Clazz.defineMethod (c$, "removePreference", 
function (preference) {
var returnValue = this.removePreferenceInt (preference);
this.notifyHierarchyChanged ();
return returnValue;
}, "android.preference.Preference");
Clazz.defineMethod (c$, "removePreferenceInt", 
($fz = function (preference) {
{
preference.onPrepareForRemoval ();
return this.mPreferenceList.remove (preference);
}}, $fz.isPrivate = true, $fz), "android.preference.Preference");
Clazz.defineMethod (c$, "removeAll", 
function () {
{
var preferenceList = this.mPreferenceList;
for (var i = preferenceList.size () - 1; i >= 0; i--) {
this.removePreferenceInt (preferenceList.get (0));
}
}this.notifyHierarchyChanged ();
});
Clazz.defineMethod (c$, "onPrepareAddPreference", 
function (preference) {
if (!Clazz.superCall (this, android.preference.PreferenceGroup, "isEnabled", [])) {
preference.setEnabled (false);
}return true;
}, "android.preference.Preference");
Clazz.defineMethod (c$, "findPreference", 
function (key) {
if (android.text.TextUtils.equals (this.getKey (), key)) {
return this;
}var preferenceCount = this.getPreferenceCount ();
for (var i = 0; i < preferenceCount; i++) {
var preference = this.getPreference (i);
var curKey = preference.getKey ();
if (curKey != null && curKey.equals (key)) {
return preference;
}if (Clazz.instanceOf (preference, android.preference.PreferenceGroup)) {
var returnedPreference = (preference).findPreference (key);
if (returnedPreference != null) {
return returnedPreference;
}}}
return null;
}, "CharSequence");
Clazz.defineMethod (c$, "isOnSameScreenAsChildren", 
function () {
return true;
});
Clazz.defineMethod (c$, "onAttachedToActivity", 
function () {
Clazz.superCall (this, android.preference.PreferenceGroup, "onAttachedToActivity", []);
this.mAttachedToActivity = true;
var preferenceCount = this.getPreferenceCount ();
for (var i = 0; i < preferenceCount; i++) {
this.getPreference (i).onAttachedToActivity ();
}
});
Clazz.defineMethod (c$, "onPrepareForRemoval", 
function () {
Clazz.superCall (this, android.preference.PreferenceGroup, "onPrepareForRemoval", []);
this.mAttachedToActivity = false;
});
Clazz.defineMethod (c$, "setEnabled", 
function (enabled) {
Clazz.superCall (this, android.preference.PreferenceGroup, "setEnabled", [enabled]);
var preferenceCount = this.getPreferenceCount ();
for (var i = 0; i < preferenceCount; i++) {
this.getPreference (i).setEnabled (enabled);
}
}, "~B");
Clazz.defineMethod (c$, "sortPreferences", 
function () {
{
java.util.Collections.sort (this.mPreferenceList);
}});
Clazz.defineMethod (c$, "dispatchSaveInstanceState", 
function (container) {
Clazz.superCall (this, android.preference.PreferenceGroup, "dispatchSaveInstanceState", [container]);
var preferenceCount = this.getPreferenceCount ();
for (var i = 0; i < preferenceCount; i++) {
this.getPreference (i).dispatchSaveInstanceState (container);
}
}, "android.os.Bundle");
Clazz.defineMethod (c$, "dispatchRestoreInstanceState", 
function (container) {
Clazz.superCall (this, android.preference.PreferenceGroup, "dispatchRestoreInstanceState", [container]);
var preferenceCount = this.getPreferenceCount ();
for (var i = 0; i < preferenceCount; i++) {
this.getPreference (i).dispatchRestoreInstanceState (container);
}
}, "android.os.Bundle");
});
