﻿Clazz.declarePackage ("android.preference");
Clazz.declareInterface (android.preference, "OnDependencyChangeListener");
