﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.preference.GenericInflater"], "android.preference.PreferenceInflater", ["android.content.Intent", "android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPreferenceManager = null;
Clazz.instantialize (this, arguments);
}, android.preference, "PreferenceInflater", android.preference.GenericInflater);
Clazz.makeConstructor (c$, 
function (context, preferenceManager) {
Clazz.superConstructor (this, android.preference.PreferenceInflater, [context]);
this.init (preferenceManager);
}, "android.content.Context,android.preference.PreferenceManager");
Clazz.makeConstructor (c$, 
function (original, preferenceManager, newContext) {
Clazz.superConstructor (this, android.preference.PreferenceInflater, [original, newContext]);
this.init (preferenceManager);
}, "android.preference.GenericInflater,android.preference.PreferenceManager,android.content.Context");
Clazz.overrideMethod (c$, "cloneInContext", 
function (newContext) {
return  new android.preference.PreferenceInflater (this, this.mPreferenceManager, newContext);
}, "android.content.Context");
Clazz.defineMethod (c$, "init", 
($fz = function (preferenceManager) {
this.mPreferenceManager = preferenceManager;
this.setDefaultPackage ("android.preference.");
}, $fz.isPrivate = true, $fz), "android.preference.PreferenceManager");
Clazz.overrideMethod (c$, "onCreateCustomFromTag", 
function (parser, parentPreference, attrs) {
var tag = parser.getName ();
if (tag.equals ("intent")) {
var intent = null;
try {
intent = android.content.Intent.parseIntent (this.getContext ().getResources (), parser, attrs);
} catch (e) {
if (Clazz.instanceOf (e, java.io.IOException)) {
android.util.Log.w ("PreferenceInflater", "Could not parse Intent.");
android.util.Log.w ("PreferenceInflater", e);
} else {
throw e;
}
}
if (intent != null) {
parentPreference.setIntent (intent);
}return true;
}return false;
}, "org.xmlpull.v1.XmlPullParser,android.preference.Preference,android.util.AttributeSet");
Clazz.overrideMethod (c$, "onMergeRoots", 
function (givenRoot, attachToGivenRoot, xmlRoot) {
if (givenRoot == null) {
xmlRoot.onAttachedToHierarchy (this.mPreferenceManager);
return xmlRoot;
} else {
return givenRoot;
}}, "android.preference.PreferenceGroup,~B,android.preference.PreferenceGroup");
Clazz.defineStatics (c$,
"TAG", "PreferenceInflater",
"INTENT_TAG_NAME", "intent");
});
