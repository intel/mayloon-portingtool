﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.preference.Preference", "android.os.Parcelable.Creator"], "android.preference.CheckBoxPreference", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mSummaryOn = null;
this.mSummaryOff = null;
this.mChecked = false;
this.mSendAccessibilityEventViewClickedType = false;
this.mDisableDependentsState = false;
Clazz.instantialize (this, arguments);
}, android.preference, "CheckBoxPreference", android.preference.Preference);
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.preference.CheckBoxPreference, [context, attrs, defStyle]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.CheckBoxPreference, defStyle, 0);
this.mSummaryOn = a.getString (0);
this.mSummaryOff = a.getString (1);
this.mDisableDependentsState = a.getBoolean (2, false);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842895);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.defineMethod (c$, "onBindView", 
function (view) {
Clazz.superCall (this, android.preference.CheckBoxPreference, "onBindView", [view]);
var checkboxView = view.findViewById (16908289);
if (checkboxView != null && Clazz.instanceOf (checkboxView, android.widget.Checkable)) {
(checkboxView).setChecked (this.mChecked);
if (this.mSendAccessibilityEventViewClickedType && checkboxView.isEnabled ()) {
this.mSendAccessibilityEventViewClickedType = false;
}}var summaryView = view.findViewById (16908304);
if (summaryView != null) {
var useDefaultSummary = true;
if (this.mChecked && this.mSummaryOn != null) {
summaryView.setText (this.mSummaryOn);
useDefaultSummary = false;
} else if (!this.mChecked && this.mSummaryOff != null) {
summaryView.setText (this.mSummaryOff);
useDefaultSummary = false;
}if (useDefaultSummary) {
var summary = this.getSummary ();
if (summary != null) {
summaryView.setText (summary);
useDefaultSummary = false;
}}var newVisibility = 8;
if (!useDefaultSummary) {
newVisibility = 0;
}if (newVisibility != summaryView.getVisibility ()) {
summaryView.setVisibility (newVisibility);
}}}, "android.view.View");
Clazz.defineMethod (c$, "onClick", 
function () {
Clazz.superCall (this, android.preference.CheckBoxPreference, "onClick", []);
var newValue = !this.isChecked ();
this.mSendAccessibilityEventViewClickedType = true;
if (!this.callChangeListener (new Boolean (newValue))) {
return ;
}this.setChecked (newValue);
});
Clazz.defineMethod (c$, "setChecked", 
function (checked) {
if (this.mChecked != checked) {
this.mChecked = checked;
this.persistBoolean (checked);
this.notifyDependencyChange (this.shouldDisableDependents ());
this.notifyChanged ();
}}, "~B");
Clazz.defineMethod (c$, "isChecked", 
function () {
return this.mChecked;
});
Clazz.defineMethod (c$, "shouldDisableDependents", 
function () {
var shouldDisable = this.mDisableDependentsState ? this.mChecked : !this.mChecked;
return shouldDisable || Clazz.superCall (this, android.preference.CheckBoxPreference, "shouldDisableDependents", []);
});
Clazz.defineMethod (c$, "setSummaryOn", 
function (summary) {
this.mSummaryOn = summary;
if (this.isChecked ()) {
this.notifyChanged ();
}}, "CharSequence");
Clazz.defineMethod (c$, "setSummaryOn", 
function (summaryResId) {
this.setSummaryOn (this.getContext ().getString (summaryResId));
}, "~N");
Clazz.defineMethod (c$, "getSummaryOn", 
function () {
return this.mSummaryOn;
});
Clazz.defineMethod (c$, "setSummaryOff", 
function (summary) {
this.mSummaryOff = summary;
if (!this.isChecked ()) {
this.notifyChanged ();
}}, "CharSequence");
Clazz.defineMethod (c$, "setSummaryOff", 
function (summaryResId) {
this.setSummaryOff (this.getContext ().getString (summaryResId));
}, "~N");
Clazz.defineMethod (c$, "getSummaryOff", 
function () {
return this.mSummaryOff;
});
Clazz.defineMethod (c$, "getDisableDependentsState", 
function () {
return this.mDisableDependentsState;
});
Clazz.defineMethod (c$, "setDisableDependentsState", 
function (disableDependentsState) {
this.mDisableDependentsState = disableDependentsState;
}, "~B");
Clazz.overrideMethod (c$, "onGetDefaultValue", 
function (a, index) {
return a.getBoolean (index, false);
}, "android.content.res.TypedArray,~N");
Clazz.overrideMethod (c$, "onSetInitialValue", 
function (restoreValue, defaultValue) {
this.setChecked (restoreValue ? this.getPersistedBoolean (this.mChecked) : defaultValue);
}, "~B,~O");
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
var superState = Clazz.superCall (this, android.preference.CheckBoxPreference, "onSaveInstanceState", []);
if (this.isPersistent ()) {
return superState;
}var myState =  new android.preference.CheckBoxPreference.SavedState (superState);
myState.checked = this.isChecked ();
return myState;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
if (state == null || !state.getClass ().equals (android.preference.CheckBoxPreference.SavedState)) {
Clazz.superCall (this, android.preference.CheckBoxPreference, "onRestoreInstanceState", [state]);
return ;
}var myState = state;
Clazz.superCall (this, android.preference.CheckBoxPreference, "onRestoreInstanceState", [myState.getSuperState ()]);
this.setChecked (myState.checked);
}, "android.os.Parcelable");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.checked = false;
Clazz.instantialize (this, arguments);
}, android.preference.CheckBoxPreference, "SavedState", android.preference.Preference.BaseSavedState);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.preference.CheckBoxPreference.SavedState, [a]);
this.checked = a.readInt () == 1;
}, "android.os.Parcel");
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
Clazz.superCall (this, android.preference.CheckBoxPreference.SavedState, "writeToParcel", [a, b]);
a.writeInt (this.checked ? 1 : 0);
}, "android.os.Parcel,~N");
c$.$CheckBoxPreference$SavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.preference, "CheckBoxPreference$SavedState$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.preference.CheckBoxPreference.SavedState (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.$$CREATOR = c$.prototype.$$CREATOR = ((Clazz.isClassDefined ("android.preference.CheckBoxPreference$SavedState$1") ? 0 : android.preference.CheckBoxPreference.SavedState.$CheckBoxPreference$SavedState$1$ ()), Clazz.innerTypeInstance (android.preference.CheckBoxPreference$SavedState$1, this, null));
c$ = Clazz.p0p ();
});
