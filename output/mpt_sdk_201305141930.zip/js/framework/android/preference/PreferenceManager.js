﻿Clazz.declarePackage ("android.preference");
Clazz.load (null, "android.preference.PreferenceManager", ["android.preference.PreferenceInflater", "android.util.Log", "java.util.ArrayList", "$.HashSet"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mActivity = null;
this.mContext = null;
this.mNextId = 0;
this.mNextRequestCode = 0;
this.mSharedPreferences = null;
this.mEditor = null;
this.mNoCommit = false;
this.mSharedPreferencesName = null;
this.mSharedPreferencesMode = 0;
this.mActivityResultListeners = null;
this.mActivityStopListeners = null;
this.mActivityDestroyListeners = null;
this.mPreferenceScreen = null;
this.mPreferencesScreens = null;
this.mOnPreferenceTreeClickListener = null;
Clazz.instantialize (this, arguments);
}, android.preference, "PreferenceManager");
Clazz.makeConstructor (c$, 
function (activity, firstRequestCode) {
this.mActivity = activity;
this.mNextRequestCode = firstRequestCode;
this.init (activity);
}, "android.app.Activity,~N");
Clazz.defineMethod (c$, "init", 
($fz = function (context) {
this.mContext = context;
this.setSharedPreferencesName (android.preference.PreferenceManager.getDefaultSharedPreferencesName (context));
}, $fz.isPrivate = true, $fz), "android.content.Context");
Clazz.defineMethod (c$, "queryIntentActivities", 
($fz = function (queryIntent) {
return this.mContext.getPackageManager ().queryIntentActivities (queryIntent, 128);
}, $fz.isPrivate = true, $fz), "android.content.Intent");
Clazz.defineMethod (c$, "getNextId", 
function () {
{
return this.mNextId++;
}});
Clazz.defineMethod (c$, "getSharedPreferencesName", 
function () {
return this.mSharedPreferencesName;
});
Clazz.defineMethod (c$, "setSharedPreferencesName", 
function (sharedPreferencesName) {
this.mSharedPreferencesName = sharedPreferencesName;
this.mSharedPreferences = null;
}, "~S");
Clazz.defineMethod (c$, "getSharedPreferencesMode", 
function () {
return this.mSharedPreferencesMode;
});
Clazz.defineMethod (c$, "setSharedPreferencesMode", 
function (sharedPreferencesMode) {
this.mSharedPreferencesMode = sharedPreferencesMode;
this.mSharedPreferences = null;
}, "~N");
Clazz.defineMethod (c$, "findPreference", 
function (key) {
if (this.mPreferenceScreen == null) {
return null;
}return this.mPreferenceScreen.findPreference (key);
}, "CharSequence");
Clazz.defineMethod (c$, "getSharedPreferences", 
function () {
if (this.mSharedPreferences == null) {
this.mSharedPreferences = this.mContext.getSharedPreferences (this.mSharedPreferencesName, this.mSharedPreferencesMode);
}return this.mSharedPreferences;
});
Clazz.defineMethod (c$, "getPreferenceScreen", 
function () {
return this.mPreferenceScreen;
});
Clazz.defineMethod (c$, "setPreferences", 
function (preferenceScreen) {
if (preferenceScreen !== this.mPreferenceScreen) {
this.mPreferenceScreen = preferenceScreen;
return true;
}return false;
}, "android.preference.PreferenceScreen");
c$.getDefaultSharedPreferences = Clazz.defineMethod (c$, "getDefaultSharedPreferences", 
function (context) {
return context.getSharedPreferences (android.preference.PreferenceManager.getDefaultSharedPreferencesName (context), android.preference.PreferenceManager.getDefaultSharedPreferencesMode ());
}, "android.content.Context");
c$.getDefaultSharedPreferencesName = Clazz.defineMethod (c$, "getDefaultSharedPreferencesName", 
($fz = function (context) {
return context.getPackageName () + "_preferences";
}, $fz.isPrivate = true, $fz), "android.content.Context");
c$.getDefaultSharedPreferencesMode = Clazz.defineMethod (c$, "getDefaultSharedPreferencesMode", 
($fz = function () {
return 0;
}, $fz.isPrivate = true, $fz));
c$.setDefaultValues = Clazz.defineMethod (c$, "setDefaultValues", 
function (context, resId, readAgain) {
android.preference.PreferenceManager.setDefaultValues (context, android.preference.PreferenceManager.getDefaultSharedPreferencesName (context), android.preference.PreferenceManager.getDefaultSharedPreferencesMode (), resId, readAgain);
}, "android.content.Context,~N,~B");
c$.setDefaultValues = Clazz.defineMethod (c$, "setDefaultValues", 
function (context, sharedPreferencesName, sharedPreferencesMode, resId, readAgain) {
}, "android.content.Context,~S,~N,~N,~B");
Clazz.defineMethod (c$, "getEditor", 
function () {
if (this.mNoCommit) {
if (this.mEditor == null) {
this.mEditor = this.getSharedPreferences ().edit ();
}return this.mEditor;
} else {
return this.getSharedPreferences ().edit ();
}});
Clazz.defineMethod (c$, "shouldCommit", 
function () {
return !this.mNoCommit;
});
Clazz.defineMethod (c$, "setNoCommit", 
($fz = function (noCommit) {
if (!noCommit && this.mEditor != null) {
try {
this.mEditor.apply ();
} catch (unused) {
if (Clazz.instanceOf (unused, AbstractMethodError)) {
this.mEditor.commit ();
} else {
throw unused;
}
}
}this.mNoCommit = noCommit;
}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "getActivity", 
function () {
return this.mActivity;
});
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.defineMethod (c$, "registerOnActivityResultListener", 
function (listener) {
{
if (this.mActivityResultListeners == null) {
this.mActivityResultListeners =  new java.util.ArrayList ();
}if (!this.mActivityResultListeners.contains (listener)) {
this.mActivityResultListeners.add (listener);
}}}, "android.preference.PreferenceManager.OnActivityResultListener");
Clazz.defineMethod (c$, "unregisterOnActivityResultListener", 
function (listener) {
{
if (this.mActivityResultListeners != null) {
this.mActivityResultListeners.remove (listener);
}}}, "android.preference.PreferenceManager.OnActivityResultListener");
Clazz.defineMethod (c$, "dispatchActivityResult", 
function (requestCode, resultCode, data) {
var list;
{
if (this.mActivityResultListeners == null) return ;
list =  new java.util.ArrayList (this.mActivityResultListeners);
}var N = list.size ();
for (var i = 0; i < N; i++) {
if (list.get (i).onActivityResult (requestCode, resultCode, data)) {
break;
}}
}, "~N,~N,android.content.Intent");
Clazz.defineMethod (c$, "registerOnActivityStopListener", 
function (listener) {
{
if (this.mActivityStopListeners == null) {
this.mActivityStopListeners =  new java.util.ArrayList ();
}if (!this.mActivityStopListeners.contains (listener)) {
this.mActivityStopListeners.add (listener);
}}}, "android.preference.PreferenceManager.OnActivityStopListener");
Clazz.defineMethod (c$, "unregisterOnActivityStopListener", 
function (listener) {
{
if (this.mActivityStopListeners != null) {
this.mActivityStopListeners.remove (listener);
}}}, "android.preference.PreferenceManager.OnActivityStopListener");
Clazz.defineMethod (c$, "dispatchActivityStop", 
function () {
var list;
{
if (this.mActivityStopListeners == null) return ;
list =  new java.util.ArrayList (this.mActivityStopListeners);
}var N = list.size ();
for (var i = 0; i < N; i++) {
list.get (i).onActivityStop ();
}
});
Clazz.defineMethod (c$, "registerOnActivityDestroyListener", 
function (listener) {
{
if (this.mActivityDestroyListeners == null) {
this.mActivityDestroyListeners =  new java.util.ArrayList ();
}if (!this.mActivityDestroyListeners.contains (listener)) {
this.mActivityDestroyListeners.add (listener);
}}}, "android.preference.PreferenceManager.OnActivityDestroyListener");
Clazz.defineMethod (c$, "unregisterOnActivityDestroyListener", 
function (listener) {
{
if (this.mActivityDestroyListeners != null) {
this.mActivityDestroyListeners.remove (listener);
}}}, "android.preference.PreferenceManager.OnActivityDestroyListener");
Clazz.defineMethod (c$, "dispatchActivityDestroy", 
function () {
var list = null;
{
if (this.mActivityDestroyListeners != null) {
list =  new java.util.ArrayList (this.mActivityDestroyListeners);
}}if (list != null) {
var N = list.size ();
for (var i = 0; i < N; i++) {
list.get (i).onActivityDestroy ();
}
}this.dismissAllScreens ();
});
Clazz.defineMethod (c$, "getNextRequestCode", 
function () {
{
return this.mNextRequestCode++;
}});
Clazz.defineMethod (c$, "addPreferencesScreen", 
function (screen) {
{
if (this.mPreferencesScreens == null) {
this.mPreferencesScreens =  new java.util.ArrayList ();
}this.mPreferencesScreens.add (screen);
}}, "android.content.DialogInterface");
Clazz.defineMethod (c$, "removePreferencesScreen", 
function (screen) {
{
if (this.mPreferencesScreens == null) {
return ;
}this.mPreferencesScreens.remove (screen);
}}, "android.content.DialogInterface");
Clazz.defineMethod (c$, "dispatchNewIntent", 
function (intent) {
this.dismissAllScreens ();
}, "android.content.Intent");
Clazz.defineMethod (c$, "dismissAllScreens", 
($fz = function () {
var screensToDismiss;
{
if (this.mPreferencesScreens == null) {
return ;
}screensToDismiss =  new java.util.ArrayList (this.mPreferencesScreens);
this.mPreferencesScreens.clear ();
}for (var i = screensToDismiss.size () - 1; i >= 0; i--) {
screensToDismiss.get (i).dismiss ();
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "inflateFromIntent", 
function (queryIntent, rootPreferences) {
var activities = this.queryIntentActivities (queryIntent);
var inflatedRes =  new java.util.HashSet ();
for (var i = activities.size () - 1; i >= 0; i--) {
var activityInfo = activities.get (i).activityInfo;
var metaData = activityInfo.metaData;
if ((metaData == null) || !metaData.containsKey ("android.preference")) {
continue ;}var uniqueResId = activityInfo.packageName + ":" + activityInfo.metaData.getInt ("android.preference");
if (!inflatedRes.contains (uniqueResId)) {
inflatedRes.add (uniqueResId);
var context;
try {
context = this.mContext.createPackageContext (activityInfo.packageName, 0);
} catch (e) {
if (Clazz.instanceOf (e, android.content.pm.PackageManager.NameNotFoundException)) {
android.util.Log.w ("PreferenceManager", "Could not create context for " + activityInfo.packageName + ": " + android.util.Log.getStackTraceString (e));
continue ;} else {
throw e;
}
}
var inflater =  new android.preference.PreferenceInflater (context, this);
var parser = activityInfo.loadXmlMetaData (context.getPackageManager (), "android.preference");
rootPreferences = inflater.inflate (parser, rootPreferences, true);
parser.close ();
}}
rootPreferences.onAttachedToHierarchy (this);
return rootPreferences;
}, "android.content.Intent,android.preference.PreferenceScreen");
Clazz.defineMethod (c$, "inflateFromResource", 
function (context, resId, rootPreferences) {
this.setNoCommit (true);
var inflater =  new android.preference.PreferenceInflater (context, this);
rootPreferences = inflater.inflate (resId, rootPreferences, true);
rootPreferences.onAttachedToHierarchy (this);
this.setNoCommit (false);
return rootPreferences;
}, "android.content.Context,~N,android.preference.PreferenceScreen");
Clazz.defineMethod (c$, "setOnPreferenceTreeClickListener", 
function (listener) {
this.mOnPreferenceTreeClickListener = listener;
}, "android.preference.PreferenceManager.OnPreferenceTreeClickListener");
Clazz.defineMethod (c$, "getOnPreferenceTreeClickListener", 
function () {
return this.mOnPreferenceTreeClickListener;
});
Clazz.defineMethod (c$, "createPreferenceScreen", 
function (context) {
console.log("Missing method: createPreferenceScreen");
}, "android.content.Context");
Clazz.declareInterface (android.preference.PreferenceManager, "OnPreferenceTreeClickListener");
Clazz.declareInterface (android.preference.PreferenceManager, "OnActivityResultListener");
Clazz.declareInterface (android.preference.PreferenceManager, "OnActivityStopListener");
Clazz.declareInterface (android.preference.PreferenceManager, "OnActivityDestroyListener");
Clazz.defineStatics (c$,
"TAG", "PreferenceManager",
"METADATA_KEY_PREFERENCES", "android.preference",
"KEY_HAS_SET_DEFAULT_VALUES", "_has_set_default_values");
});
