﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.preference.PreferenceGroup"], "android.preference.PreferenceCategory", ["java.lang.IllegalArgumentException"], function () {
c$ = Clazz.declareType (android.preference, "PreferenceCategory", android.preference.PreferenceGroup);
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842892);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.defineMethod (c$, "onPrepareAddPreference", 
function (preference) {
if (Clazz.instanceOf (preference, android.preference.PreferenceCategory)) {
throw  new IllegalArgumentException ("Cannot add a PreferenceCategory directly to a PreferenceCategory");
}return Clazz.superCall (this, android.preference.PreferenceCategory, "onPrepareAddPreference", [preference]);
}, "android.preference.Preference");
Clazz.overrideMethod (c$, "isEnabled", 
function () {
return false;
});
Clazz.defineStatics (c$,
"TAG", "PreferenceCategory");
});
