﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.content.DialogInterface", "android.preference.Preference", "$.PreferenceManager", "android.os.Parcelable.Creator"], "android.preference.DialogPreference", ["android.app.AlertDialog", "android.text.TextUtils", "com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mBuilder = null;
this.mDialogTitle = null;
this.mDialogMessage = null;
this.mDialogIcon = null;
this.mPositiveButtonText = null;
this.mNegativeButtonText = null;
this.mDialogLayoutResId = 0;
this.mDialog = null;
this.mWhichButtonClicked = 0;
Clazz.instantialize (this, arguments);
}, android.preference, "DialogPreference", android.preference.Preference, [android.content.DialogInterface.OnClickListener, android.content.DialogInterface.OnDismissListener, android.preference.PreferenceManager.OnActivityDestroyListener]);
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.preference.DialogPreference, [context, attrs, defStyle]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.DialogPreference, defStyle, 0);
this.mDialogTitle = a.getString (0);
if (this.mDialogTitle == null) {
this.mDialogTitle = this.getTitle ();
}this.mDialogMessage = a.getString (1);
this.mDialogIcon = a.getDrawable (2);
this.mPositiveButtonText = a.getString (3);
this.mNegativeButtonText = a.getString (4);
this.mDialogLayoutResId = a.getResourceId (5, this.mDialogLayoutResId);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842897);
}, "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "setDialogTitle", 
function (dialogTitle) {
this.mDialogTitle = dialogTitle;
}, "CharSequence");
Clazz.defineMethod (c$, "setDialogTitle", 
function (dialogTitleResId) {
this.setDialogTitle (this.getContext ().getString (dialogTitleResId));
}, "~N");
Clazz.defineMethod (c$, "getDialogTitle", 
function () {
return this.mDialogTitle;
});
Clazz.defineMethod (c$, "setDialogMessage", 
function (dialogMessage) {
this.mDialogMessage = dialogMessage;
}, "CharSequence");
Clazz.defineMethod (c$, "setDialogMessage", 
function (dialogMessageResId) {
this.setDialogMessage (this.getContext ().getString (dialogMessageResId));
}, "~N");
Clazz.defineMethod (c$, "getDialogMessage", 
function () {
return this.mDialogMessage;
});
Clazz.defineMethod (c$, "setDialogIcon", 
function (dialogIcon) {
this.mDialogIcon = dialogIcon;
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setDialogIcon", 
function (dialogIconRes) {
this.mDialogIcon = this.getContext ().getResources ().getDrawable (dialogIconRes);
}, "~N");
Clazz.defineMethod (c$, "getDialogIcon", 
function () {
return this.mDialogIcon;
});
Clazz.defineMethod (c$, "setPositiveButtonText", 
function (positiveButtonText) {
this.mPositiveButtonText = positiveButtonText;
}, "CharSequence");
Clazz.defineMethod (c$, "setPositiveButtonText", 
function (positiveButtonTextResId) {
this.setPositiveButtonText (this.getContext ().getString (positiveButtonTextResId));
}, "~N");
Clazz.defineMethod (c$, "getPositiveButtonText", 
function () {
return this.mPositiveButtonText;
});
Clazz.defineMethod (c$, "setNegativeButtonText", 
function (negativeButtonText) {
this.mNegativeButtonText = negativeButtonText;
}, "CharSequence");
Clazz.defineMethod (c$, "setNegativeButtonText", 
function (negativeButtonTextResId) {
this.setNegativeButtonText (this.getContext ().getString (negativeButtonTextResId));
}, "~N");
Clazz.defineMethod (c$, "getNegativeButtonText", 
function () {
return this.mNegativeButtonText;
});
Clazz.defineMethod (c$, "setDialogLayoutResource", 
function (dialogLayoutResId) {
this.mDialogLayoutResId = dialogLayoutResId;
}, "~N");
Clazz.defineMethod (c$, "getDialogLayoutResource", 
function () {
return this.mDialogLayoutResId;
});
Clazz.defineMethod (c$, "onPrepareDialogBuilder", 
function (builder) {
}, "android.app.AlertDialog.Builder");
Clazz.defineMethod (c$, "onClick", 
function () {
this.showDialog (null);
});
Clazz.defineMethod (c$, "showDialog", 
function (state) {
var context = this.getContext ();
this.mWhichButtonClicked = -2;
this.mBuilder =  new android.app.AlertDialog.Builder (context).setTitle (this.mDialogTitle).setIcon (this.mDialogIcon).setPositiveButton (this.mPositiveButtonText, this).setNegativeButton (this.mNegativeButtonText, this);
var contentView = this.onCreateDialogView ();
if (contentView != null) {
this.onBindDialogView (contentView);
this.mBuilder.setView (contentView);
} else {
this.mBuilder.setMessage (this.mDialogMessage);
}this.onPrepareDialogBuilder (this.mBuilder);
this.getPreferenceManager ().registerOnActivityDestroyListener (this);
var dialog = this.mDialog = this.mBuilder.create ();
if (state != null) {
dialog.onRestoreInstanceState (state);
}if (this.needInputMethod ()) {
this.requestInputMethod (dialog);
}dialog.setOnDismissListener (this);
dialog.show ();
}, "android.os.Bundle");
Clazz.defineMethod (c$, "needInputMethod", 
function () {
return false;
});
Clazz.defineMethod (c$, "requestInputMethod", 
($fz = function (dialog) {
}, $fz.isPrivate = true, $fz), "android.app.Dialog");
Clazz.defineMethod (c$, "onCreateDialogView", 
function () {
if (this.mDialogLayoutResId == 0) {
return null;
}var inflater = this.getContext ().getSystemService ("layout_inflater");
return inflater.inflate (this.mDialogLayoutResId, null);
});
Clazz.defineMethod (c$, "onBindDialogView", 
function (view) {
var dialogMessageView = view.findViewById (16908299);
if (dialogMessageView != null) {
var message = this.getDialogMessage ();
var newVisibility = 8;
if (!android.text.TextUtils.isEmpty (message)) {
if (Clazz.instanceOf (dialogMessageView, android.widget.TextView)) {
(dialogMessageView).setText (message);
}newVisibility = 0;
}if (dialogMessageView.getVisibility () != newVisibility) {
dialogMessageView.setVisibility (newVisibility);
}}}, "android.view.View");
Clazz.defineMethod (c$, "onClick", 
function (dialog, which) {
this.mWhichButtonClicked = which;
}, "android.content.DialogInterface,~N");
Clazz.overrideMethod (c$, "onDismiss", 
function (dialog) {
this.getPreferenceManager ().unregisterOnActivityDestroyListener (this);
this.mDialog = null;
this.onDialogClosed (this.mWhichButtonClicked == -1);
}, "android.content.DialogInterface");
Clazz.defineMethod (c$, "onDialogClosed", 
function (positiveResult) {
}, "~B");
Clazz.defineMethod (c$, "getDialog", 
function () {
return this.mDialog;
});
Clazz.overrideMethod (c$, "onActivityDestroy", 
function () {
if (this.mDialog == null || !this.mDialog.isShowing ()) {
return ;
}this.mDialog.dismiss ();
});
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
var superState = Clazz.superCall (this, android.preference.DialogPreference, "onSaveInstanceState", []);
if (this.mDialog == null || !this.mDialog.isShowing ()) {
return superState;
}var myState =  new android.preference.DialogPreference.SavedState (superState);
myState.isDialogShowing = true;
myState.dialogBundle = this.mDialog.onSaveInstanceState ();
return myState;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
if (state == null || !state.getClass ().equals (android.preference.DialogPreference.SavedState)) {
Clazz.superCall (this, android.preference.DialogPreference, "onRestoreInstanceState", [state]);
return ;
}var myState = state;
Clazz.superCall (this, android.preference.DialogPreference, "onRestoreInstanceState", [myState.getSuperState ()]);
if (myState.isDialogShowing) {
this.showDialog (myState.dialogBundle);
}}, "android.os.Parcelable");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.isDialogShowing = false;
this.dialogBundle = null;
Clazz.instantialize (this, arguments);
}, android.preference.DialogPreference, "SavedState", android.preference.Preference.BaseSavedState);
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.preference.DialogPreference.SavedState, [a]);
this.isDialogShowing = a.readInt () == 1;
this.dialogBundle = a.readBundle ();
}, "android.os.Parcel");
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
Clazz.superCall (this, android.preference.DialogPreference.SavedState, "writeToParcel", [a, b]);
a.writeInt (this.isDialogShowing ? 1 : 0);
a.writeBundle (this.dialogBundle);
}, "android.os.Parcel,~N");
c$.$DialogPreference$SavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.preference, "DialogPreference$SavedState$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.preference.DialogPreference.SavedState (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.$$CREATOR = c$.prototype.$$CREATOR = ((Clazz.isClassDefined ("android.preference.DialogPreference$SavedState$1") ? 0 : android.preference.DialogPreference.SavedState.$DialogPreference$SavedState$1$ ()), Clazz.innerTypeInstance (android.preference.DialogPreference$SavedState$1, this, null));
c$ = Clazz.p0p ();
});
