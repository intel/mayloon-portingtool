﻿Clazz.declarePackage ("android.preference");
Clazz.load (["android.preference.Preference", "android.widget.BaseAdapter", "android.os.Handler"], "android.preference.PreferenceGroupAdapter", ["java.util.ArrayList", "$.Collections"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPreferenceGroup = null;
this.mPreferenceList = null;
this.mPreferenceLayouts = null;
this.mTempPreferenceLayout = null;
this.mHasReturnedViewTypeCount = false;
this.mIsSyncing = false;
this.mHandler = null;
this.mSyncRunnable = null;
Clazz.instantialize (this, arguments);
}, android.preference, "PreferenceGroupAdapter", android.widget.BaseAdapter, android.preference.Preference.OnPreferenceChangeInternalListener);
Clazz.prepareFields (c$, function () {
this.mTempPreferenceLayout =  new android.preference.PreferenceGroupAdapter.PreferenceLayout ();
this.mHandler =  new android.os.Handler ();
this.mSyncRunnable = ((Clazz.isClassDefined ("android.preference.PreferenceGroupAdapter$1") ? 0 : android.preference.PreferenceGroupAdapter.$PreferenceGroupAdapter$1$ ()), Clazz.innerTypeInstance (android.preference.PreferenceGroupAdapter$1, this, null));
});
Clazz.makeConstructor (c$, 
function (preferenceGroup) {
Clazz.superConstructor (this, android.preference.PreferenceGroupAdapter, []);
this.mPreferenceGroup = preferenceGroup;
this.mPreferenceGroup.setOnPreferenceChangeInternalListener (this);
this.mPreferenceList =  new java.util.ArrayList ();
this.mPreferenceLayouts =  new java.util.ArrayList ();
this.syncMyPreferences ();
}, "android.preference.PreferenceGroup");
Clazz.defineMethod (c$, "syncMyPreferences", 
($fz = function () {
{
if (this.mIsSyncing) {
return ;
}this.mIsSyncing = true;
}var newPreferenceList =  new java.util.ArrayList (this.mPreferenceList.size ());
this.flattenPreferenceGroup (newPreferenceList, this.mPreferenceGroup);
this.mPreferenceList = newPreferenceList;
this.notifyDataSetChanged ();
{
this.mIsSyncing = false;
this.notifyAll ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "flattenPreferenceGroup", 
($fz = function (preferences, group) {
group.sortPreferences ();
var groupSize = group.getPreferenceCount ();
for (var i = 0; i < groupSize; i++) {
var preference = group.getPreference (i);
preferences.add (preference);
if (!this.mHasReturnedViewTypeCount && !preference.hasSpecifiedLayout ()) {
this.addPreferenceClassName (preference);
}if (Clazz.instanceOf (preference, android.preference.PreferenceGroup)) {
var preferenceAsGroup = preference;
if (preferenceAsGroup.isOnSameScreenAsChildren ()) {
this.flattenPreferenceGroup (preferences, preferenceAsGroup);
}}preference.setOnPreferenceChangeInternalListener (this);
}
}, $fz.isPrivate = true, $fz), "java.util.List,android.preference.PreferenceGroup");
Clazz.defineMethod (c$, "createPreferenceLayout", 
($fz = function (preference, $in) {
var pl = $in != null ? $in :  new android.preference.PreferenceGroupAdapter.PreferenceLayout ();
pl.name = preference.getClass ().getName ();
pl.resId = preference.getLayoutResource ();
pl.widgetResId = preference.getWidgetLayoutResource ();
return pl;
}, $fz.isPrivate = true, $fz), "android.preference.Preference,android.preference.PreferenceGroupAdapter.PreferenceLayout");
Clazz.defineMethod (c$, "addPreferenceClassName", 
($fz = function (preference) {
var pl = this.createPreferenceLayout (preference, null);
var insertPos = java.util.Collections.binarySearch (this.mPreferenceLayouts, pl);
if (insertPos < 0) {
insertPos = insertPos * -1 - 1;
this.mPreferenceLayouts.add (insertPos, pl);
}}, $fz.isPrivate = true, $fz), "android.preference.Preference");
Clazz.overrideMethod (c$, "getCount", 
function () {
return this.mPreferenceList.size ();
});
Clazz.overrideMethod (c$, "getItem", 
function (position) {
if (position < 0 || position >= this.getCount ()) return null;
return this.mPreferenceList.get (position);
}, "~N");
Clazz.overrideMethod (c$, "getItemId", 
function (position) {
if (position < 0 || position >= this.getCount ()) return -9223372036854775808;
return this.getItem (position).getId ();
}, "~N");
Clazz.overrideMethod (c$, "getView", 
function (position, convertView, parent) {
var preference = this.getItem (position);
this.mTempPreferenceLayout = this.createPreferenceLayout (preference, this.mTempPreferenceLayout);
if (java.util.Collections.binarySearch (this.mPreferenceLayouts, this.mTempPreferenceLayout) < 0) {
convertView = null;
}return preference.getView (convertView, parent);
}, "~N,android.view.View,android.view.ViewGroup");
Clazz.overrideMethod (c$, "isEnabled", 
function (position) {
if (position < 0 || position >= this.getCount ()) return true;
return this.getItem (position).isSelectable ();
}, "~N");
Clazz.overrideMethod (c$, "areAllItemsEnabled", 
function () {
return false;
});
Clazz.overrideMethod (c$, "onPreferenceChange", 
function (preference) {
this.notifyDataSetChanged ();
}, "android.preference.Preference");
Clazz.overrideMethod (c$, "onPreferenceHierarchyChange", 
function (preference) {
this.mHandler.removeCallbacks (this.mSyncRunnable);
this.mHandler.post (this.mSyncRunnable);
}, "android.preference.Preference");
Clazz.overrideMethod (c$, "hasStableIds", 
function () {
return true;
});
Clazz.overrideMethod (c$, "getItemViewType", 
function (position) {
if (!this.mHasReturnedViewTypeCount) {
this.mHasReturnedViewTypeCount = true;
}var preference = this.getItem (position);
if (preference.hasSpecifiedLayout ()) {
return -1;
}this.mTempPreferenceLayout = this.createPreferenceLayout (preference, this.mTempPreferenceLayout);
var viewType = java.util.Collections.binarySearch (this.mPreferenceLayouts, this.mTempPreferenceLayout);
if (viewType < 0) {
return -1;
} else {
return viewType;
}}, "~N");
Clazz.overrideMethod (c$, "getViewTypeCount", 
function () {
if (!this.mHasReturnedViewTypeCount) {
this.mHasReturnedViewTypeCount = true;
}return Math.max (1, this.mPreferenceLayouts.size ());
});
c$.$PreferenceGroupAdapter$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.preference, "PreferenceGroupAdapter$1", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["android.preference.PreferenceGroupAdapter"].syncMyPreferences ();
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.resId = 0;
this.widgetResId = 0;
this.name = null;
Clazz.instantialize (this, arguments);
}, android.preference.PreferenceGroupAdapter, "PreferenceLayout", null, Comparable);
Clazz.overrideMethod (c$, "compareTo", 
function (a) {
var b = this.name.compareTo (a.name);
if (b == 0) {
if (this.resId == a.resId) {
if (this.widgetResId == a.widgetResId) {
return 0;
} else {
return this.widgetResId - a.widgetResId;
}} else {
return this.resId - a.resId;
}} else {
return b;
}}, "android.preference.PreferenceGroupAdapter.PreferenceLayout");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TAG", "PreferenceGroupAdapter");
});
