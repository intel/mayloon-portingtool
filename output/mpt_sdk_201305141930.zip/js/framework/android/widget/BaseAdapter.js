﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.ListAdapter", "$.SpinnerAdapter", "android.database.DataSetObservable"], "android.widget.BaseAdapter", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mDataSetObservable = null;
Clazz.instantialize (this, arguments);
}, android.widget, "BaseAdapter", null, [android.widget.ListAdapter, android.widget.SpinnerAdapter]);
Clazz.prepareFields (c$, function () {
this.mDataSetObservable =  new android.database.DataSetObservable ();
});
Clazz.overrideMethod (c$, "hasStableIds", 
function () {
return false;
});
Clazz.overrideMethod (c$, "areAllItemsEnabled", 
function () {
return true;
});
Clazz.overrideMethod (c$, "isEnabled", 
function (position) {
return true;
}, "~N");
Clazz.overrideMethod (c$, "getItemViewType", 
function (position) {
return 0;
}, "~N");
Clazz.overrideMethod (c$, "getViewTypeCount", 
function () {
return 1;
});
Clazz.defineMethod (c$, "notifyDataSetChanged", 
function () {
this.mDataSetObservable.notifyChanged ();
});
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.getCount () == 0;
});
Clazz.overrideMethod (c$, "registerDataSetObserver", 
function (observer) {
this.mDataSetObservable.registerObserver (observer);
}, "android.database.DataSetObserver");
Clazz.defineMethod (c$, "notifyDataSetInvalidated", 
function () {
this.mDataSetObservable.notifyInvalidated ();
});
Clazz.overrideMethod (c$, "unregisterDataSetObserver", 
function (observer) {
this.mDataSetObservable.unregisterObserver (observer);
}, "android.database.DataSetObserver");
Clazz.overrideMethod (c$, "getDropDownView", 
function (position, convertView, parent) {
return this.getView (position, convertView, parent);
}, "~N,android.view.View,android.view.ViewGroup");
});
