﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.util.Poolable", "android.view.ViewGroup", "android.graphics.Rect", "android.util.PoolableManager", "$.Pools", "$.SparseArray", "java.util.ArrayList", "$.HashSet", "$.LinkedList"], "android.widget.RelativeLayout", ["android.util.Log", "android.view.Gravity", "$.View", "com.android.internal.R", "java.lang.ArrayIndexOutOfBoundsException", "$.IllegalStateException", "$.StringBuilder"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mBaselineView = null;
this.mHasBaselineAlignedChild = false;
this.mGravity = 51;
this.mContentBounds = null;
this.mSelfBounds = null;
this.mIgnoreGravity = 0;
this.mTopToBottomLeftToRightSet = null;
this.mDirtyHierarchy = true;
this.mSortedHorizontalChildren = null;
this.mSortedVerticalChildren = null;
this.mGraph = null;
if (!Clazz.isClassDefined ("android.widget.RelativeLayout.TopToBottomLeftToRightComparator")) {
android.widget.RelativeLayout.$RelativeLayout$TopToBottomLeftToRightComparator$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "RelativeLayout", android.view.ViewGroup);
Clazz.prepareFields (c$, function () {
this.mContentBounds =  new android.graphics.Rect ();
this.mSelfBounds =  new android.graphics.Rect ();
this.mSortedHorizontalChildren =  new Array (0);
this.mSortedVerticalChildren =  new Array (0);
this.mGraph =  new android.widget.RelativeLayout.DependencyGraph ();
});
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.widget.RelativeLayout, [context, attrs]);
this.initFromAttributes (context, attrs);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.RelativeLayout, [context, attrs, defStyle]);
this.initFromAttributes (context, attrs);
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "initFromAttributes", 
($fz = function (context, attrs) {
var $private = Clazz.checkPrivateMethod (arguments);
if ($private != null) {
return $private.apply (this, arguments);
}
System.out.println ("initFromAttributes");
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.RelativeLayout);
this.mIgnoreGravity = a.getResourceId (1, -1);
this.mGravity = a.getInt (0, this.mGravity);
a.recycle ();
}, $fz.isPrivate = true, $fz), "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "setIgnoreGravity", 
function (viewId) {
this.mIgnoreGravity = viewId;
}, "~N");
Clazz.defineMethod (c$, "setGravity", 
function (gravity) {
android.util.Log.d ("RelativeLayout", "set gravity to: " + gravity);
if (this.mGravity != gravity) {
if ((gravity & 8388615) == 0) {
gravity |= 8388611;
}if ((gravity & 112) == 0) {
gravity |= 48;
}this.mGravity = gravity;
this.requestLayout ();
}}, "~N");
Clazz.defineMethod (c$, "setHorizontalGravity", 
function (horizontalGravity) {
android.util.Log.d ("RelativeLayout", "set horizontal gravity to: " + horizontalGravity);
var gravity = horizontalGravity & 8388615;
if ((this.mGravity & 8388615) != gravity) {
this.mGravity = (this.mGravity & -8388616) | gravity;
this.requestLayout ();
}}, "~N");
Clazz.defineMethod (c$, "setVerticalGravity", 
function (verticalGravity) {
android.util.Log.d ("RelativeLayout", "set vertical gravity to: " + verticalGravity);
var gravity = verticalGravity & 112;
if ((this.mGravity & 112) != gravity) {
this.mGravity = (this.mGravity & -113) | gravity;
this.requestLayout ();
}}, "~N");
Clazz.defineMethod (c$, "getBaseline", 
function () {
android.util.Log.d ("RelativeLayout", "getBaseline");
return this.mBaselineView != null ? this.mBaselineView.getBaseline () : Clazz.superCall (this, android.widget.RelativeLayout, "getBaseline", []);
});
Clazz.defineMethod (c$, "requestLayout", 
function () {
Clazz.superCall (this, android.widget.RelativeLayout, "requestLayout", []);
this.mDirtyHierarchy = true;
});
Clazz.defineMethod (c$, "sortChildren", 
($fz = function () {
var count = this.getChildCount ();
if (this.mSortedVerticalChildren.length != count) this.mSortedVerticalChildren =  new Array (count);
if (this.mSortedHorizontalChildren.length != count) this.mSortedHorizontalChildren =  new Array (count);
var graph = this.mGraph;
graph.clear ();
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
graph.add (child);
}
if (true) {
android.util.Log.d ("RelativeLayout", "=== Sorted vertical children");
graph.log (this.getResources (), [2, 3, 4, 6, 8]);
android.util.Log.d ("RelativeLayout", "=== Sorted horizontal children");
graph.log (this.getResources (), [0, 1, 5, 7]);
}graph.getSortedViews (this.mSortedVerticalChildren, [2, 3, 4, 6, 8]);
graph.getSortedViews (this.mSortedHorizontalChildren, [0, 1, 5, 7]);
if (true) {
android.util.Log.d ("RelativeLayout", "=== Ordered list of vertical children");
for (var view, $view = 0, $$view = this.mSortedVerticalChildren; $view < $$view.length && ((view = $$view[$view]) || true); $view++) {
android.widget.RelativeLayout.DependencyGraph.printViewId (this.getResources (), view);
}
android.util.Log.d ("RelativeLayout", "=== Ordered list of horizontal children");
for (var view, $view = 0, $$view = this.mSortedHorizontalChildren; $view < $$view.length && ((view = $$view[$view]) || true); $view++) {
android.widget.RelativeLayout.DependencyGraph.printViewId (this.getResources (), view);
}
}}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
if (this.mDirtyHierarchy) {
this.mDirtyHierarchy = false;
this.sortChildren ();
}var myWidth = -1;
var myHeight = -1;
var width = 0;
var height = 0;
var widthMode = android.view.View.MeasureSpec.getMode (widthMeasureSpec);
var heightMode = android.view.View.MeasureSpec.getMode (heightMeasureSpec);
var widthSize = android.view.View.MeasureSpec.getSize (widthMeasureSpec);
var heightSize = android.view.View.MeasureSpec.getSize (heightMeasureSpec);
if (widthMode != 0) {
myWidth = widthSize;
}if (heightMode != 0) {
myHeight = heightSize;
}if (widthMode == 1073741824) {
width = myWidth;
}if (heightMode == 1073741824) {
height = myHeight;
}this.mHasBaselineAlignedChild = false;
var ignore = null;
var gravity = this.mGravity & 8388615;
var horizontalGravity = gravity != 3 && gravity != 0;
gravity = this.mGravity & 112;
var verticalGravity = gravity != 48 && gravity != 0;
var left = 2147483647;
var top = 2147483647;
var right = -2147483648;
var bottom = -2147483648;
var offsetHorizontalAxis = false;
var offsetVerticalAxis = false;
if ((horizontalGravity || verticalGravity) && this.mIgnoreGravity != -1) {
ignore = this.findViewById (this.mIgnoreGravity);
}var isWrapContentWidth = widthMode != 1073741824;
var isWrapContentHeight = heightMode != 1073741824;
var views = this.mSortedHorizontalChildren;
var count = views.length;
for (var i = 0; i < count; i++) {
var child = views[i];
if (child.getVisibility () != 8) {
var params = child.getLayoutParams ();
this.applyHorizontalSizeRules (params, myWidth);
this.measureChildHorizontal (child, params, myWidth, myHeight);
if (this.positionChildHorizontal (child, params, myWidth, isWrapContentWidth)) {
offsetHorizontalAxis = true;
}}}
views = this.mSortedVerticalChildren;
count = views.length;
for (var i = 0; i < count; i++) {
var child = views[i];
if (child.getVisibility () != 8) {
var params = child.getLayoutParams ();
this.applyVerticalSizeRules (params, myHeight);
this.measureChild (child, params, myWidth, myHeight);
if (this.positionChildVertical (child, params, myHeight, isWrapContentHeight)) {
offsetVerticalAxis = true;
}if (isWrapContentWidth) {
width = Math.max (width, params.mRight);
}if (isWrapContentHeight) {
height = Math.max (height, params.mBottom);
}if (child !== ignore || verticalGravity) {
left = Math.min (left, params.mLeft - params.leftMargin);
top = Math.min (top, params.mTop - params.topMargin);
}if (child !== ignore || horizontalGravity) {
right = Math.max (right, params.mRight + params.rightMargin);
bottom = Math.max (bottom, params.mBottom + params.bottomMargin);
}}}
if (this.mHasBaselineAlignedChild) {
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (child.getVisibility () != 8) {
var params = child.getLayoutParams ();
this.alignBaseline (child, params);
if (child !== ignore || verticalGravity) {
left = Math.min (left, params.mLeft - params.leftMargin);
top = Math.min (top, params.mTop - params.topMargin);
}if (child !== ignore || horizontalGravity) {
right = Math.max (right, params.mRight + params.rightMargin);
bottom = Math.max (bottom, params.mBottom + params.bottomMargin);
}}}
}if (isWrapContentWidth) {
width += this.mPaddingRight;
if (this.mLayoutParams.width >= 0) {
width = Math.max (width, this.mLayoutParams.width);
}width = Math.max (width, this.getSuggestedMinimumWidth ());
width = android.view.View.resolveSize (width, widthMeasureSpec);
if (offsetHorizontalAxis) {
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (child.getVisibility () != 8) {
var params = child.getLayoutParams ();
var rules = params.getRules ();
if (rules[13] != 0 || rules[14] != 0) {
this.centerHorizontal (child, params, width);
} else if (rules[11] != 0) {
var childWidth = child.getMeasuredWidth ();
params.mLeft = width - this.mPaddingRight - childWidth;
params.mRight = params.mLeft + childWidth;
}}}
}}if (isWrapContentHeight) {
height += this.mPaddingBottom;
if (this.mLayoutParams.height >= 0) {
height = Math.max (height, this.mLayoutParams.height);
}height = Math.max (height, this.getSuggestedMinimumHeight ());
height = android.view.View.resolveSize (height, heightMeasureSpec);
if (offsetVerticalAxis) {
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (child.getVisibility () != 8) {
var params = child.getLayoutParams ();
var rules = params.getRules ();
if (rules[13] != 0 || rules[15] != 0) {
this.centerVertical (child, params, height);
} else if (rules[12] != 0) {
var childHeight = child.getMeasuredHeight ();
params.mTop = height - this.mPaddingBottom - childHeight;
params.mBottom = params.mTop + childHeight;
}}}
}}if (horizontalGravity || verticalGravity) {
var selfBounds = this.mSelfBounds;
selfBounds.set (this.mPaddingLeft, this.mPaddingTop, width - this.mPaddingRight, height - this.mPaddingBottom);
var contentBounds = this.mContentBounds;
var layoutDirection = this.getResolvedLayoutDirection ();
android.view.Gravity.apply (this.mGravity, right - left, bottom - top, selfBounds, contentBounds, layoutDirection);
var horizontalOffset = contentBounds.left - left;
var verticalOffset = contentBounds.top - top;
if (horizontalOffset != 0 || verticalOffset != 0) {
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (child.getVisibility () != 8 && child !== ignore) {
var params = child.getLayoutParams ();
if (horizontalGravity) {
params.mLeft += horizontalOffset;
params.mRight += horizontalOffset;
}if (verticalGravity) {
params.mTop += verticalOffset;
params.mBottom += verticalOffset;
}}}
}}this.setMeasuredDimension (width, height);
}, "~N,~N");
Clazz.defineMethod (c$, "alignBaseline", 
($fz = function (child, params) {
var rules = params.getRules ();
var anchorBaseline = this.getRelatedViewBaseline (rules, 4);
if (anchorBaseline != -1) {
var anchorParams = this.getRelatedViewParams (rules, 4);
if (anchorParams != null) {
var offset = anchorParams.mTop + anchorBaseline;
var baseline = child.getBaseline ();
if (baseline != -1) {
offset -= baseline;
}var height = params.mBottom - params.mTop;
params.mTop = offset;
params.mBottom = params.mTop + height;
}}if (this.mBaselineView == null) {
this.mBaselineView = child;
} else {
var lp = this.mBaselineView.getLayoutParams ();
if (params.mTop < lp.mTop || (params.mTop == lp.mTop && params.mLeft < lp.mLeft)) {
this.mBaselineView = child;
}}}, $fz.isPrivate = true, $fz), "android.view.View,android.widget.RelativeLayout.LayoutParams");
Clazz.defineMethod (c$, "measureChild", 
($fz = function (child, params, myWidth, myHeight) {
var childWidthMeasureSpec = this.getChildMeasureSpec (params.mLeft, params.mRight, params.width, params.leftMargin, params.rightMargin, this.mPaddingLeft, this.mPaddingRight, myWidth);
var childHeightMeasureSpec = this.getChildMeasureSpec (params.mTop, params.mBottom, params.height, params.topMargin, params.bottomMargin, this.mPaddingTop, this.mPaddingBottom, myHeight);
child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}, $fz.isPrivate = true, $fz), "android.view.View,android.widget.RelativeLayout.LayoutParams,~N,~N");
Clazz.defineMethod (c$, "measureChildHorizontal", 
($fz = function (child, params, myWidth, myHeight) {
var childWidthMeasureSpec = this.getChildMeasureSpec (params.mLeft, params.mRight, params.width, params.leftMargin, params.rightMargin, this.mPaddingLeft, this.mPaddingRight, myWidth);
var childHeightMeasureSpec;
if (params.width == -1) {
childHeightMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (myHeight, 1073741824);
} else {
childHeightMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (myHeight, -2147483648);
}child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}, $fz.isPrivate = true, $fz), "android.view.View,android.widget.RelativeLayout.LayoutParams,~N,~N");
Clazz.defineMethod (c$, "getChildMeasureSpec", 
($fz = function (childStart, childEnd, childSize, startMargin, endMargin, startPadding, endPadding, mySize) {
var childSpecMode = 0;
var childSpecSize = 0;
var tempStart = childStart;
var tempEnd = childEnd;
if (tempStart < 0) {
tempStart = startPadding + startMargin;
}if (tempEnd < 0) {
tempEnd = mySize - endPadding - endMargin;
}var maxAvailable = tempEnd - tempStart;
if (childStart >= 0 && childEnd >= 0) {
childSpecMode = 1073741824;
childSpecSize = maxAvailable;
} else {
if (childSize >= 0) {
childSpecMode = 1073741824;
if (maxAvailable >= 0) {
childSpecSize = Math.min (maxAvailable, childSize);
} else {
childSpecSize = childSize;
}} else if (childSize == -1) {
childSpecMode = 1073741824;
childSpecSize = maxAvailable;
} else if (childSize == -2) {
if (maxAvailable >= 0) {
childSpecMode = -2147483648;
childSpecSize = maxAvailable;
} else {
childSpecMode = 0;
childSpecSize = 0;
}}}return android.view.View.MeasureSpec.makeMeasureSpec (childSpecSize, childSpecMode);
}, $fz.isPrivate = true, $fz), "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "focusSearch", 
function (v, direction) {
System.out.println ("focusSearch");
return null;
}, "android.view.View,~N");
Clazz.defineMethod (c$, "positionChildHorizontal", 
($fz = function (child, params, myWidth, wrapContent) {
var rules = params.getRules ();
if (params.mLeft < 0 && params.mRight >= 0) {
params.mLeft = params.mRight - child.getMeasuredWidth ();
} else if (params.mLeft >= 0 && params.mRight < 0) {
params.mRight = params.mLeft + child.getMeasuredWidth ();
} else if (params.mLeft < 0 && params.mRight < 0) {
if (rules[13] != 0 || rules[14] != 0) {
if (!wrapContent) {
this.centerHorizontal (child, params, myWidth);
} else {
params.mLeft = this.mPaddingLeft + params.leftMargin;
params.mRight = params.mLeft + child.getMeasuredWidth ();
}return true;
} else {
params.mLeft = this.mPaddingLeft + params.leftMargin;
params.mRight = params.mLeft + child.getMeasuredWidth ();
}}return rules[11] != 0;
}, $fz.isPrivate = true, $fz), "android.view.View,android.widget.RelativeLayout.LayoutParams,~N,~B");
Clazz.defineMethod (c$, "positionChildVertical", 
($fz = function (child, params, myHeight, wrapContent) {
var rules = params.getRules ();
if (params.mTop < 0 && params.mBottom >= 0) {
params.mTop = params.mBottom - child.getMeasuredHeight ();
} else if (params.mTop >= 0 && params.mBottom < 0) {
params.mBottom = params.mTop + child.getMeasuredHeight ();
} else if (params.mTop < 0 && params.mBottom < 0) {
if (rules[13] != 0 || rules[15] != 0) {
if (!wrapContent) {
this.centerVertical (child, params, myHeight);
} else {
params.mTop = this.mPaddingTop + params.topMargin;
params.mBottom = params.mTop + child.getMeasuredHeight ();
}return true;
} else {
params.mTop = this.mPaddingTop + params.topMargin;
params.mBottom = params.mTop + child.getMeasuredHeight ();
}}return rules[12] != 0;
}, $fz.isPrivate = true, $fz), "android.view.View,android.widget.RelativeLayout.LayoutParams,~N,~B");
Clazz.defineMethod (c$, "applyHorizontalSizeRules", 
($fz = function (childParams, myWidth) {
var rules = childParams.getRules ();
var anchorParams;
childParams.mLeft = -1;
childParams.mRight = -1;
anchorParams = this.getRelatedViewParams (rules, 0);
if (anchorParams != null) {
childParams.mRight = anchorParams.mLeft - (anchorParams.leftMargin + childParams.rightMargin);
} else if (childParams.alignWithParent && rules[0] != 0) {
if (myWidth >= 0) {
childParams.mRight = myWidth - this.mPaddingRight - childParams.rightMargin;
} else {
}}anchorParams = this.getRelatedViewParams (rules, 1);
if (anchorParams != null) {
childParams.mLeft = anchorParams.mRight + (anchorParams.rightMargin + childParams.leftMargin);
} else if (childParams.alignWithParent && rules[1] != 0) {
childParams.mLeft = this.mPaddingLeft + childParams.leftMargin;
}anchorParams = this.getRelatedViewParams (rules, 5);
if (anchorParams != null) {
childParams.mLeft = anchorParams.mLeft + childParams.leftMargin;
} else if (childParams.alignWithParent && rules[5] != 0) {
childParams.mLeft = this.mPaddingLeft + childParams.leftMargin;
}anchorParams = this.getRelatedViewParams (rules, 7);
if (anchorParams != null) {
childParams.mRight = anchorParams.mRight - childParams.rightMargin;
} else if (childParams.alignWithParent && rules[7] != 0) {
if (myWidth >= 0) {
childParams.mRight = myWidth - this.mPaddingRight - childParams.rightMargin;
} else {
}}if (0 != rules[9]) {
childParams.mLeft = this.mPaddingLeft + childParams.leftMargin;
}if (0 != rules[11]) {
if (myWidth >= 0) {
childParams.mRight = myWidth - this.mPaddingRight - childParams.rightMargin;
} else {
}}}, $fz.isPrivate = true, $fz), "android.widget.RelativeLayout.LayoutParams,~N");
Clazz.defineMethod (c$, "applyVerticalSizeRules", 
($fz = function (childParams, myHeight) {
var rules = childParams.getRules ();
var anchorParams;
childParams.mTop = -1;
childParams.mBottom = -1;
anchorParams = this.getRelatedViewParams (rules, 2);
if (anchorParams != null) {
childParams.mBottom = anchorParams.mTop - (anchorParams.topMargin + childParams.bottomMargin);
} else if (childParams.alignWithParent && rules[2] != 0) {
if (myHeight >= 0) {
childParams.mBottom = myHeight - this.mPaddingBottom - childParams.bottomMargin;
} else {
}}anchorParams = this.getRelatedViewParams (rules, 3);
if (anchorParams != null) {
childParams.mTop = anchorParams.mBottom + (anchorParams.bottomMargin + childParams.topMargin);
} else if (childParams.alignWithParent && rules[3] != 0) {
childParams.mTop = this.mPaddingTop + childParams.topMargin;
}anchorParams = this.getRelatedViewParams (rules, 6);
if (anchorParams != null) {
childParams.mTop = anchorParams.mTop + childParams.topMargin;
} else if (childParams.alignWithParent && rules[6] != 0) {
childParams.mTop = this.mPaddingTop + childParams.topMargin;
}anchorParams = this.getRelatedViewParams (rules, 8);
if (anchorParams != null) {
childParams.mBottom = anchorParams.mBottom - childParams.bottomMargin;
} else if (childParams.alignWithParent && rules[8] != 0) {
if (myHeight >= 0) {
childParams.mBottom = myHeight - this.mPaddingBottom - childParams.bottomMargin;
} else {
}}if (0 != rules[10]) {
childParams.mTop = this.mPaddingTop + childParams.topMargin;
}if (0 != rules[12]) {
if (myHeight >= 0) {
childParams.mBottom = myHeight - this.mPaddingBottom - childParams.bottomMargin;
} else {
}}if (rules[4] != 0) {
this.mHasBaselineAlignedChild = true;
}}, $fz.isPrivate = true, $fz), "android.widget.RelativeLayout.LayoutParams,~N");
Clazz.defineMethod (c$, "getRelatedView", 
($fz = function (rules, relation) {
var id = rules[relation];
if (id != 0) {
var node = this.mGraph.mKeyNodes.get (id);
if (node == null) return null;
var v = node.view;
while (v.getVisibility () == 8) {
rules = (v.getLayoutParams ()).getRules ();
node = this.mGraph.mKeyNodes.get ((rules[relation]));
if (node == null) return null;
v = node.view;
}
return v;
}return null;
}, $fz.isPrivate = true, $fz), "~A,~N");
Clazz.defineMethod (c$, "getRelatedViewParams", 
($fz = function (rules, relation) {
var v = this.getRelatedView (rules, relation);
if (v != null) {
var params = v.getLayoutParams ();
if (Clazz.instanceOf (params, android.widget.RelativeLayout.LayoutParams)) {
return v.getLayoutParams ();
}}return null;
}, $fz.isPrivate = true, $fz), "~A,~N");
Clazz.defineMethod (c$, "getRelatedViewBaseline", 
($fz = function (rules, relation) {
var v = this.getRelatedView (rules, relation);
if (v != null) {
return v.getBaseline ();
}return -1;
}, $fz.isPrivate = true, $fz), "~A,~N");
Clazz.defineMethod (c$, "centerHorizontal", 
($fz = function (child, params, myWidth) {
var childWidth = child.getMeasuredWidth ();
var left = Math.floor ((myWidth - childWidth) / 2);
params.mLeft = left;
params.mRight = left + childWidth;
}, $fz.isPrivate = true, $fz), "android.view.View,android.widget.RelativeLayout.LayoutParams,~N");
Clazz.defineMethod (c$, "centerVertical", 
($fz = function (child, params, myHeight) {
var childHeight = child.getMeasuredHeight ();
var top = Math.floor ((myHeight - childHeight) / 2);
params.mTop = top;
params.mBottom = top + childHeight;
}, $fz.isPrivate = true, $fz), "android.view.View,android.widget.RelativeLayout.LayoutParams,~N");
Clazz.overrideMethod (c$, "onLayout", 
function (changed, l, t, r, b) {
var count = this.getChildCount ();
android.util.Log.d ("RelativeLayout", "relativelayout onLayout:" + l + "," + t + "," + r + "," + b);
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (child.getVisibility () != 8) {
var st = child.getLayoutParams ();
android.util.Log.d ("RelativeLayout", "relativelayout child:UIElementID" + child.getUIElementID () + " " + st.mLeft + "," + st.mTop + "," + st.mRight + "," + st.mBottom);
child.layout (st.mLeft, st.mTop, st.mRight, st.mBottom);
}}
}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (attrs) {
return  new android.widget.RelativeLayout.LayoutParams (this.getContext (), attrs);
}, "android.util.AttributeSet");
Clazz.overrideMethod (c$, "generateDefaultLayoutParams", 
function () {
return  new android.widget.RelativeLayout.LayoutParams (-2, -2);
});
Clazz.overrideMethod (c$, "checkLayoutParams", 
function (p) {
return Clazz.instanceOf (p, android.widget.RelativeLayout.LayoutParams);
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (p) {
System.out.println ("generateDefaultLayoutParams");
return  new android.widget.RelativeLayout.LayoutParams (p);
}, "android.view.ViewGroup.LayoutParams");
Clazz.overrideMethod (c$, "childDrawableStateChanged", 
function (child) {
android.util.Log.d ("RelativeLayout", "childDrawableStateChanged");
}, "android.view.View");
Clazz.defineMethod (c$, "addView", 
function (view, params) {
android.util.Log.d ("RelativeLayout", "addView");
this.addView (view, params, true);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
c$.$RelativeLayout$TopToBottomLeftToRightComparator$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.widget.RelativeLayout, "TopToBottomLeftToRightComparator", null, java.util.Comparator);
Clazz.overrideMethod (c$, "compare", 
function (a, b) {
var c = a.getTop () - b.getTop ();
if (c != 0) {
return c;
}var d = a.getLeft () - b.getLeft ();
if (d != 0) {
return d;
}var e = a.getHeight () - b.getHeight ();
if (e != 0) {
return e;
}var f = a.getWidth () - b.getWidth ();
if (f != 0) {
return f;
}return 0;
}, "android.view.View,android.view.View");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mRules = null;
this.mLeft = 0;
this.mTop = 0;
this.mRight = 0;
this.mBottom = 0;
this.alignWithParent = false;
Clazz.instantialize (this, arguments);
}, android.widget.RelativeLayout, "LayoutParams", android.view.ViewGroup.MarginLayoutParams);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.widget.RelativeLayout.LayoutParams, [a, b]);
var c = a.obtainStyledAttributes (b, com.android.internal.R.styleable.RelativeLayout_Layout);
this.mRules =  Clazz.newArray (16, 0);
var d = this.mRules;
var e = c.getIndexCount ();
for (var f = 0; f < e; f++) {
var g = c.getIndex (f);
switch (g) {
case 16:
this.alignWithParent = c.getBoolean (g, false);
break;
case 0:
d[0] = c.getResourceId (g, 0);
break;
case 1:
d[1] = c.getResourceId (g, 0);
break;
case 2:
d[2] = c.getResourceId (g, 0);
break;
case 3:
d[3] = c.getResourceId (g, 0);
break;
case 4:
d[4] = c.getResourceId (g, 0);
break;
case 5:
d[5] = c.getResourceId (g, 0);
break;
case 6:
d[6] = c.getResourceId (g, 0);
break;
case 7:
d[7] = c.getResourceId (g, 0);
break;
case 8:
d[8] = c.getResourceId (g, 0);
break;
case 9:
d[9] = c.getBoolean (g, false) ? -1 : 0;
break;
case 10:
d[10] = c.getBoolean (g, false) ? -1 : 0;
break;
case 11:
d[11] = c.getBoolean (g, false) ? -1 : 0;
break;
case 12:
d[12] = c.getBoolean (g, false) ? -1 : 0;
break;
case 13:
d[13] = c.getBoolean (g, false) ? -1 : 0;
break;
case 14:
d[14] = c.getBoolean (g, false) ? -1 : 0;
break;
case 15:
d[15] = c.getBoolean (g, false) ? -1 : 0;
break;
}
}
c.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.widget.RelativeLayout.LayoutParams, [a, b]);
this.mRules =  Clazz.newArray (16, 0);
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.widget.RelativeLayout.LayoutParams, [a]);
this.mRules =  Clazz.newArray (16, 0);
}, "android.view.ViewGroup.LayoutParams");
Clazz.makeConstructor (c$, 
function (a) {
Clazz.superConstructor (this, android.widget.RelativeLayout.LayoutParams, [a]);
this.mRules =  Clazz.newArray (16, 0);
}, "android.view.ViewGroup.MarginLayoutParams");
Clazz.overrideMethod (c$, "debug", 
function (a) {
return a + "ViewGroup.LayoutParams={ width=" + android.view.ViewGroup.LayoutParams.sizeToString (this.width) + ", height=" + android.view.ViewGroup.LayoutParams.sizeToString (this.height) + " }";
}, "~S");
Clazz.defineMethod (c$, "addRule", 
function (a) {
if (a < 0 || a >= this.mRules.length) {
throw  new ArrayIndexOutOfBoundsException ("Out of the limit of Array");
} else {
this.mRules[a] = -1;
}}, "~N");
Clazz.defineMethod (c$, "addRule", 
function (a, b) {
if (a < 0 || a >= this.mRules.length) {
throw  new ArrayIndexOutOfBoundsException ("Out of the limit of Array");
} else {
this.mRules[a] = b;
}}, "~N,~N");
Clazz.defineMethod (c$, "getRules", 
function () {
return this.mRules;
});
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mNodes = null;
this.mKeyNodes = null;
this.mRoots = null;
Clazz.instantialize (this, arguments);
}, android.widget.RelativeLayout, "DependencyGraph");
Clazz.prepareFields (c$, function () {
this.mNodes =  new java.util.ArrayList ();
this.mKeyNodes =  new android.util.SparseArray ();
this.mRoots =  new java.util.LinkedList ();
});
Clazz.defineMethod (c$, "clear", 
function () {
var a = this.mNodes;
var b = a.size ();
for (var c = 0; c < b; c++) {
a.get (c).release ();
}
a.clear ();
this.mKeyNodes.clear ();
this.mRoots.clear ();
});
Clazz.defineMethod (c$, "add", 
function (a) {
var b = a.getId ();
var c = android.widget.RelativeLayout.DependencyGraph.Node.acquire (a);
if (b != -1) {
this.mKeyNodes.put (b, c);
}this.mNodes.add (c);
}, "android.view.View");
Clazz.defineMethod (c$, "getSortedViews", 
function (a, b) {
var c = this.findRoots (b);
var d = 0;
while (c.size () > 0) {
var e = c.removeFirst ();
var f = e.view;
var g = f.getId ();
a[d++] = f;
var h = e.dependents;
for (var dependent, $dependent = h.iterator (); $dependent.hasNext () && ((dependent = $dependent.next ()) || true);) {
var i = dependent.dependencies;
i.remove (g);
if (i.size () == 0) {
c.add (dependent);
}}
}
if (d < a.length) {
throw  new IllegalStateException ("Circular dependencies cannot exist in RelativeLayout");
}}, "~A,~A");
Clazz.defineMethod (c$, "findRoots", 
($fz = function (a) {
var b = this.mKeyNodes;
var c = this.mNodes;
var d = c.size ();
for (var e = 0; e < d; e++) {
var f = c.get (e);
f.dependents.clear ();
f.dependencies.clear ();
}
for (var f = 0; f < d; f++) {
var g = c.get (f);
var h = g.view.getLayoutParams ();
var i = h.mRules;
var j = a.length;
for (var k = 0; k < j; k++) {
var l = i[a[k]];
if (l > 0) {
var m = b.get (l);
if (m == null || m === g) {
continue ;}m.dependents.add (g);
g.dependencies.put (l, m);
}}
}
var g = this.mRoots;
g.clear ();
for (var h = 0; h < d; h++) {
var i = c.get (h);
if (i.dependencies.size () == 0) g.add (i);
}
return g;
}, $fz.isPrivate = true, $fz), "~A");
Clazz.defineMethod (c$, "log", 
function (a, b) {
var c = this.findRoots (b);
for (var node, $node = c.iterator (); $node.hasNext () && ((node = $node.next ()) || true);) {
android.widget.RelativeLayout.DependencyGraph.printNode (a, node);
}
}, "android.content.res.Resources,~A");
c$.printViewId = Clazz.defineMethod (c$, "printViewId", 
function (a, b) {
if (b.getId () != -1) {
android.util.Log.d ("RelativeLayout", a.getResourceName (b.getId ()));
} else {
android.util.Log.d ("RelativeLayout", "NO_ID");
}}, "android.content.res.Resources,android.view.View");
c$.appendViewId = Clazz.defineMethod (c$, "appendViewId", 
($fz = function (a, b, c) {
if (b.view.getId () != -1) {
} else {
c.append ("NO_ID");
}}, $fz.isPrivate = true, $fz), "android.content.res.Resources,android.widget.RelativeLayout.DependencyGraph.Node,StringBuilder");
c$.printNode = Clazz.defineMethod (c$, "printNode", 
($fz = function (a, b) {
if (b.dependents.size () == 0) {
android.widget.RelativeLayout.DependencyGraph.printViewId (a, b.view);
} else {
for (var dependent, $dependent = b.dependents.iterator (); $dependent.hasNext () && ((dependent = $dependent.next ()) || true);) {
var c =  new StringBuilder ();
android.widget.RelativeLayout.DependencyGraph.appendViewId (a, b, c);
android.widget.RelativeLayout.DependencyGraph.printdependents (a, dependent, c);
}
}}, $fz.isPrivate = true, $fz), "android.content.res.Resources,android.widget.RelativeLayout.DependencyGraph.Node");
c$.printdependents = Clazz.defineMethod (c$, "printdependents", 
($fz = function (a, b, c) {
c.append (" -> ");
android.widget.RelativeLayout.DependencyGraph.appendViewId (a, b, c);
if (b.dependents.size () == 0) {
System.out.println ("RelativeLayout" + ":" + c.toString ());
} else {
for (var dependent, $dependent = b.dependents.iterator (); $dependent.hasNext () && ((dependent = $dependent.next ()) || true);) {
var d =  new StringBuilder (c);
android.widget.RelativeLayout.DependencyGraph.printdependents (a, dependent, d);
}
}}, $fz.isPrivate = true, $fz), "android.content.res.Resources,android.widget.RelativeLayout.DependencyGraph.Node,StringBuilder");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.view = null;
this.dependents = null;
this.dependencies = null;
this.mNext = null;
this.mIsPooled = false;
Clazz.instantialize (this, arguments);
}, android.widget.RelativeLayout.DependencyGraph, "Node", null, android.util.Poolable);
Clazz.prepareFields (c$, function () {
this.dependents =  new java.util.HashSet ();
this.dependencies =  new android.util.SparseArray ();
});
Clazz.overrideMethod (c$, "setNextPoolable", 
function (a) {
this.mNext = a;
}, "android.widget.RelativeLayout.DependencyGraph.Node");
Clazz.overrideMethod (c$, "getNextPoolable", 
function () {
return this.mNext;
});
Clazz.defineMethod (c$, "isPooled", 
function () {
return this.mIsPooled;
});
Clazz.defineMethod (c$, "setPooled", 
function (a) {
this.mIsPooled = a;
}, "~B");
c$.acquire = Clazz.defineMethod (c$, "acquire", 
function (a) {
var b = android.widget.RelativeLayout.DependencyGraph.Node.sPool.acquire ();
b.view = a;
return b;
}, "android.view.View");
Clazz.defineMethod (c$, "release", 
function () {
this.view = null;
this.dependents.clear ();
this.dependencies.clear ();
android.widget.RelativeLayout.DependencyGraph.Node.sPool.release (this);
});
c$.$RelativeLayout$DependencyGraph$Node$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.widget, "RelativeLayout$DependencyGraph$Node$1", null, android.util.PoolableManager);
Clazz.overrideMethod (c$, "newInstance", 
function () {
return  new android.widget.RelativeLayout.DependencyGraph.Node ();
});
Clazz.overrideMethod (c$, "onAcquired", 
function (a) {
}, "android.widget.RelativeLayout.DependencyGraph.Node");
Clazz.overrideMethod (c$, "onReleased", 
function (a) {
}, "android.widget.RelativeLayout.DependencyGraph.Node");
c$ = Clazz.p0p ();
};
Clazz.defineStatics (c$,
"POOL_LIMIT", 100);
c$.sPool = c$.prototype.sPool = android.util.Pools.finitePool (((Clazz.isClassDefined ("android.widget.RelativeLayout$DependencyGraph$Node$1") ? 0 : android.widget.RelativeLayout.DependencyGraph.Node.$RelativeLayout$DependencyGraph$Node$1$ ()), Clazz.innerTypeInstance (android.widget.RelativeLayout$DependencyGraph$Node$1, this, null)), 100);
c$ = Clazz.p0p ();
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"LOG_TAG", "RelativeLayout",
"DEBUG_GRAPH", true,
"TRUE", -1,
"LEFT_OF", 0,
"RIGHT_OF", 1,
"ABOVE", 2,
"BELOW", 3,
"ALIGN_BASELINE", 4,
"ALIGN_LEFT", 5,
"ALIGN_TOP", 6,
"ALIGN_RIGHT", 7,
"ALIGN_BOTTOM", 8,
"ALIGN_PARENT_LEFT", 9,
"ALIGN_PARENT_TOP", 10,
"ALIGN_PARENT_RIGHT", 11,
"ALIGN_PARENT_BOTTOM", 12,
"CENTER_IN_PARENT", 13,
"CENTER_HORIZONTAL", 14,
"CENTER_VERTICAL", 15,
"VERB_COUNT", 16);
});
