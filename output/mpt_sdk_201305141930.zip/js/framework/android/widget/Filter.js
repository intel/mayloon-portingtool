﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.os.Handler"], "android.widget.Filter", ["android.util.Log"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mThreadHandler = null;
this.mResultHandler = null;
this.mDelayer = null;
this.mLock = null;
if (!Clazz.isClassDefined ("android.widget.Filter.RequestHandler")) {
android.widget.Filter.$Filter$RequestHandler$ ();
}
if (!Clazz.isClassDefined ("android.widget.Filter.ResultsHandler")) {
android.widget.Filter.$Filter$ResultsHandler$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "Filter");
Clazz.prepareFields (c$, function () {
this.mLock =  new JavaObject ();
});
Clazz.makeConstructor (c$, 
function () {
this.mResultHandler = Clazz.innerTypeInstance (android.widget.Filter.ResultsHandler, this, null);
});
Clazz.defineMethod (c$, "setDelayer", 
function (delayer) {
{
this.mDelayer = delayer;
}}, "android.widget.Filter.Delayer");
Clazz.defineMethod (c$, "filter", 
function (constraint) {
this.filter (constraint, null);
}, "CharSequence");
Clazz.defineMethod (c$, "filter", 
function (constraint, listener) {
{
if (this.mThreadHandler == null) {
}var delay = (this.mDelayer == null) ? 0 : this.mDelayer.getPostingDelay (constraint);
var message = this.mThreadHandler.obtainMessage (-791613427);
var args =  new android.widget.Filter.RequestArguments ();
args.constraint = constraint != null ? constraint.toString () : null;
args.listener = listener;
message.obj = args;
this.mThreadHandler.removeMessages (-791613427);
this.mThreadHandler.removeMessages (-559038737);
this.mThreadHandler.sendMessageDelayed (message, delay);
}}, "CharSequence,android.widget.Filter.FilterListener");
Clazz.defineMethod (c$, "convertResultToString", 
function (resultValue) {
return resultValue == null ? "" : resultValue.toString ();
}, "~O");
c$.$Filter$RequestHandler$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.widget.Filter, "RequestHandler", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
var b = a.what;
var c;
switch (b) {
case -791613427:
var d = a.obj;
try {
d.results = this.b$["android.widget.Filter"].performFiltering (d.constraint);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
d.results =  new android.widget.Filter.FilterResults ();
android.util.Log.w ("Filter", "An exception occured during performFiltering()!", e);
} else {
throw e;
}
} finally {
c = this.b$["android.widget.Filter"].mResultHandler.obtainMessage (b);
c.obj = d;
c.sendToTarget ();
}
{
if (this.b$["android.widget.Filter"].mThreadHandler != null) {
var e = this.b$["android.widget.Filter"].mThreadHandler.obtainMessage (-559038737);
this.b$["android.widget.Filter"].mThreadHandler.sendMessageDelayed (e, 3000);
}}break;
case -559038737:
{
if (this.b$["android.widget.Filter"].mThreadHandler != null) {
this.b$["android.widget.Filter"].mThreadHandler.getLooper ().quit ();
this.b$["android.widget.Filter"].mThreadHandler = null;
}}break;
}
}, "android.os.Message");
c$ = Clazz.p0p ();
};
c$.$Filter$ResultsHandler$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.widget.Filter, "ResultsHandler", android.os.Handler);
Clazz.overrideMethod (c$, "handleMessage", 
function (a) {
var b = a.obj;
this.b$["android.widget.Filter"].publishResults (b.constraint, b.results);
if (b.listener != null) {
var c = b.results != null ? b.results.count : -1;
b.listener.onFilterComplete (c);
}}, "android.os.Message");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.values = null;
this.count = 0;
Clazz.instantialize (this, arguments);
}, android.widget.Filter, "FilterResults");
Clazz.makeConstructor (c$, 
function () {
});
c$ = Clazz.p0p ();
Clazz.declareInterface (android.widget.Filter, "FilterListener");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.constraint = null;
this.listener = null;
this.results = null;
Clazz.instantialize (this, arguments);
}, android.widget.Filter, "RequestArguments");
c$ = Clazz.p0p ();
Clazz.declareInterface (android.widget.Filter, "Delayer");
Clazz.defineStatics (c$,
"LOG_TAG", "Filter",
"THREAD_NAME", "Filter",
"FILTER_TOKEN", 0xD0D0F00D,
"FINISH_TOKEN", 0xDEADBEEF);
});
