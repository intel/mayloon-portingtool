﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.database.DataSetObserver", "android.view.ContextMenu", "$.ViewGroup"], "android.widget.AdapterView", ["android.os.SystemClock", "java.lang.IndexOutOfBoundsException", "$.NullPointerException", "$.RuntimeException", "$.UnsupportedOperationException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFirstPosition = 0;
this.mSpecificTop = 0;
this.mSyncPosition = 0;
this.mSyncRowId = -9223372036854775808;
this.mSyncHeight = 0;
this.mNeedSync = false;
this.mSyncMode = 0;
this.mLayoutHeight = 0;
this.mInLayout = false;
this.mOnItemSelectedListener = null;
this.mOnItemClickListener = null;
this.mOnItemLongClickListener = null;
this.mDataChanged = false;
this.mNextSelectedPosition = -1;
this.mNextSelectedRowId = -9223372036854775808;
this.mSelectedPosition = -1;
this.mSelectedRowId = -9223372036854775808;
this.mEmptyView = null;
this.mItemCount = 0;
this.mOldItemCount = 0;
this.mOldSelectedPosition = -1;
this.mOldSelectedRowId = -9223372036854775808;
this.mDesiredFocusableState = false;
this.mDesiredFocusableInTouchModeState = false;
this.mBlockLayoutRequests = false;
if (!Clazz.isClassDefined ("android.widget.AdapterView.AdapterDataSetObserver")) {
android.widget.AdapterView.$AdapterView$AdapterDataSetObserver$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "AdapterView", android.view.ViewGroup);
Clazz.defineMethod (c$, "setOnItemClickListener", 
function (listener) {
this.mOnItemClickListener = listener;
}, "android.widget.AdapterView.OnItemClickListener");
Clazz.defineMethod (c$, "getOnItemClickListener", 
function () {
return this.mOnItemClickListener;
});
Clazz.defineMethod (c$, "performItemClick", 
function (view, position, id) {
if (this.mOnItemClickListener != null) {
this.mOnItemClickListener.onItemClick (this, view, position, id);
return true;
}return false;
}, "android.view.View,~N,~N");
Clazz.defineMethod (c$, "setOnItemLongClickListener", 
function (listener) {
if (!this.isLongClickable ()) {
this.setLongClickable (true);
}this.mOnItemLongClickListener = listener;
}, "android.widget.AdapterView.OnItemLongClickListener");
Clazz.defineMethod (c$, "getOnItemLongClickListener", 
function () {
return this.mOnItemLongClickListener;
});
Clazz.defineMethod (c$, "setOnItemSelectedListener", 
function (listener) {
this.mOnItemSelectedListener = listener;
}, "android.widget.AdapterView.OnItemSelectedListener");
Clazz.defineMethod (c$, "getOnItemSelectedListener", 
function () {
return this.mOnItemSelectedListener;
});
Clazz.defineMethod (c$, "addView", 
function (child) {
throw  new UnsupportedOperationException ("addView(View) is not supported in AdapterView");
}, "android.view.View");
Clazz.defineMethod (c$, "addView", 
function (child, index) {
throw  new UnsupportedOperationException ("addView(View, int) is not supported in AdapterView");
}, "android.view.View,~N");
Clazz.defineMethod (c$, "addView", 
function (child, params) {
throw  new UnsupportedOperationException ("addView(View, LayoutParams) is not supported in AdapterView");
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addView", 
function (child, index, params) {
throw  new UnsupportedOperationException ("addView(View, int, LayoutParams) is not supported in AdapterView");
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams");
Clazz.overrideMethod (c$, "removeView", 
function (child) {
throw  new UnsupportedOperationException ("removeView(View) is not supported in AdapterView");
}, "android.view.View");
Clazz.overrideMethod (c$, "removeViewAt", 
function (index) {
throw  new UnsupportedOperationException ("removeViewAt(int) is not supported in AdapterView");
}, "~N");
Clazz.overrideMethod (c$, "removeAllViews", 
function () {
throw  new UnsupportedOperationException ("removeAllViews() is not supported in AdapterView");
});
Clazz.overrideMethod (c$, "onLayout", 
function (changed, left, top, right, bottom) {
this.mLayoutHeight = this.getHeight ();
}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "getSelectedItemPosition", 
function () {
return this.mNextSelectedPosition;
});
Clazz.defineMethod (c$, "getSelectedItemId", 
function () {
return this.mNextSelectedRowId;
});
Clazz.defineMethod (c$, "getSelectedItem", 
function () {
var adapter = this.getAdapter ();
var selection = this.getSelectedItemPosition ();
if (adapter != null && adapter.getCount () > 0 && selection >= 0) {
return adapter.getItem (selection);
} else {
return null;
}});
Clazz.defineMethod (c$, "getCount", 
function () {
return this.mItemCount;
});
Clazz.defineMethod (c$, "getPositionForView", 
function (view) {
var listItem = view;
if (listItem == null || listItem.getParent () == null) {
throw  new NullPointerException ();
}try {
var v;
while (!(v = listItem.getParent ()).equals (this)) {
listItem = v;
}
} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
return -1;
} else {
throw e;
}
}
var childCount = this.getChildCount ();
for (var i = 0; i < childCount; i++) {
if (this.getChildAt (i).equals (listItem)) {
return this.mFirstPosition + i;
}}
return -1;
}, "android.view.View");
Clazz.defineMethod (c$, "getFirstVisiblePosition", 
function () {
return this.mFirstPosition;
});
Clazz.defineMethod (c$, "getLastVisiblePosition", 
function () {
return this.mFirstPosition + this.getChildCount () - 1;
});
Clazz.defineMethod (c$, "setEmptyView", 
function (emptyView) {
this.mEmptyView = emptyView;
var adapter = this.getAdapter ();
var empty = ((adapter == null) || adapter.isEmpty ());
this.updateEmptyStatus (empty);
}, "android.view.View");
Clazz.defineMethod (c$, "getEmptyView", 
function () {
return this.mEmptyView;
});
Clazz.defineMethod (c$, "isInFilterMode", 
function () {
return false;
});
Clazz.defineMethod (c$, "setFocusable", 
function (focusable) {
var adapter = this.getAdapter ();
var empty = adapter == null || adapter.getCount () == 0;
this.mDesiredFocusableState = focusable;
if (!focusable) {
this.mDesiredFocusableInTouchModeState = false;
}Clazz.superCall (this, android.widget.AdapterView, "setFocusable", [focusable && (!empty || this.isInFilterMode ())]);
}, "~B");
Clazz.defineMethod (c$, "setFocusableInTouchMode", 
function (focusable) {
var adapter = this.getAdapter ();
var empty = adapter == null || adapter.getCount () == 0;
this.mDesiredFocusableInTouchModeState = focusable;
if (focusable) {
this.mDesiredFocusableState = true;
}Clazz.superCall (this, android.widget.AdapterView, "setFocusableInTouchMode", [focusable && (!empty || this.isInFilterMode ())]);
}, "~B");
Clazz.defineMethod (c$, "checkFocus", 
function () {
var adapter = this.getAdapter ();
var empty = adapter == null || adapter.getCount () == 0;
var focusable = !empty || this.isInFilterMode ();
Clazz.superCall (this, android.widget.AdapterView, "setFocusableInTouchMode", [focusable && this.mDesiredFocusableInTouchModeState]);
Clazz.superCall (this, android.widget.AdapterView, "setFocusable", [focusable && this.mDesiredFocusableState]);
if (this.mEmptyView != null) {
this.updateEmptyStatus ((adapter == null) || adapter.isEmpty ());
}});
Clazz.defineMethod (c$, "updateEmptyStatus", 
($fz = function (empty) {
if (this.isInFilterMode ()) {
empty = false;
}if (empty) {
if (this.mEmptyView != null) {
this.mEmptyView.setVisibility (0);
this.setVisibility (8);
} else {
this.setVisibility (0);
}if (this.mDataChanged) {
this.onLayout (false, this.mLeft, this.mTop, this.mRight, this.mBottom);
}} else {
if (this.mEmptyView != null) this.mEmptyView.setVisibility (8);
this.setVisibility (0);
}}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "getItemAtPosition", 
function (position) {
var adapter = this.getAdapter ();
if (adapter != null && position >= adapter.getCount ()) {
throw  new IndexOutOfBoundsException ();
}return (adapter == null || position < 0) ? null : adapter.getItem (position);
}, "~N");
Clazz.defineMethod (c$, "getItemIdAtPosition", 
function (position) {
var adapter = this.getAdapter ();
return (adapter == null || position < 0) ? -9223372036854775808 : adapter.getItemId (position);
}, "~N");
Clazz.overrideMethod (c$, "setOnClickListener", 
function (l) {
throw  new RuntimeException ("Don\'t call setOnClickListener for an AdapterView. You probably want setOnItemClickListener instead");
}, "android.view.View.OnClickListener");
Clazz.defineMethod (c$, "selectionChanged", 
function () {
if (this.mOnItemSelectedListener != null) {
if (this.mInLayout || this.mBlockLayoutRequests) {
} else {
this.fireOnSelected ();
}}});
Clazz.defineMethod (c$, "fireOnSelected", 
($fz = function () {
if (this.mOnItemSelectedListener == null) return ;
var selection = this.getSelectedItemPosition ();
if (selection >= 0) {
var v = this.getSelectedView ();
this.mOnItemSelectedListener.onItemSelected (this, v, selection, this.getAdapter ().getItemId (selection));
} else {
this.mOnItemSelectedListener.onNothingSelected (this);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "handleDataChanged", 
function () {
var count = this.mItemCount;
var found = false;
if (count > 0) {
var newPos;
if (this.mNeedSync) {
this.mNeedSync = false;
newPos = this.findSyncPosition ();
if (newPos >= 0) {
var selectablePos = this.lookForSelectablePosition (newPos, true);
if (selectablePos == newPos) {
this.setNextSelectedPositionInt (newPos);
found = true;
}}}if (!found) {
newPos = this.getSelectedItemPosition ();
if (newPos >= count) {
newPos = count - 1;
}if (newPos < 0) {
newPos = 0;
}var selectablePos = this.lookForSelectablePosition (newPos, true);
if (selectablePos < 0) {
selectablePos = this.lookForSelectablePosition (newPos, false);
}if (selectablePos >= 0) {
this.setNextSelectedPositionInt (selectablePos);
this.checkSelectionChanged ();
found = true;
}}}if (!found) {
this.mSelectedPosition = -1;
this.mSelectedRowId = -9223372036854775808;
this.mNextSelectedPosition = -1;
this.mNextSelectedRowId = -9223372036854775808;
this.mNeedSync = false;
this.checkSelectionChanged ();
}});
Clazz.defineMethod (c$, "checkSelectionChanged", 
function () {
if ((this.mSelectedPosition != this.mOldSelectedPosition) || (this.mSelectedRowId != this.mOldSelectedRowId)) {
this.selectionChanged ();
this.mOldSelectedPosition = this.mSelectedPosition;
this.mOldSelectedRowId = this.mSelectedRowId;
}});
Clazz.defineMethod (c$, "findSyncPosition", 
function () {
var count = this.mItemCount;
if (count == 0) {
return -1;
}var idToMatch = this.mSyncRowId;
var seed = this.mSyncPosition;
if (idToMatch == -9223372036854775808) {
return -1;
}seed = Math.max (0, seed);
seed = Math.min (count - 1, seed);
var endTime = android.os.SystemClock.uptimeMillis () + 100;
var rowId;
var first = seed;
var last = seed;
var next = false;
var hitFirst;
var hitLast;
var adapter = this.getAdapter ();
if (adapter == null) {
return -1;
}while (android.os.SystemClock.uptimeMillis () <= endTime) {
rowId = adapter.getItemId (seed);
if (rowId == idToMatch) {
return seed;
}hitLast = last == count - 1;
hitFirst = first == 0;
if (hitLast && hitFirst) {
break;
}if (hitFirst || (next && !hitLast)) {
last++;
seed = last;
next = false;
} else if (hitLast || (!next && !hitFirst)) {
first--;
seed = first;
next = true;
}}
return -1;
});
Clazz.defineMethod (c$, "lookForSelectablePosition", 
function (position, lookDown) {
return position;
}, "~N,~B");
Clazz.defineMethod (c$, "setSelectedPositionInt", 
function (position) {
this.mSelectedPosition = position;
this.mSelectedRowId = this.getItemIdAtPosition (position);
}, "~N");
Clazz.defineMethod (c$, "setNextSelectedPositionInt", 
function (position) {
this.mNextSelectedPosition = position;
this.mNextSelectedRowId = this.getItemIdAtPosition (position);
if (this.mNeedSync && this.mSyncMode == 0 && position >= 0) {
this.mSyncPosition = position;
this.mSyncRowId = this.mNextSelectedRowId;
}}, "~N");
Clazz.defineMethod (c$, "rememberSyncState", 
function () {
if (this.getChildCount () > 0) {
this.mNeedSync = true;
this.mSyncHeight = this.mLayoutHeight;
if (this.mSelectedPosition >= 0) {
var v = this.getChildAt (this.mSelectedPosition - this.mFirstPosition);
this.mSyncRowId = this.mNextSelectedRowId;
this.mSyncPosition = this.mNextSelectedPosition;
if (v != null) {
this.mSpecificTop = v.getTop ();
}this.mSyncMode = 0;
} else {
var v = this.getChildAt (0);
var adapter = this.getAdapter ();
if (this.mFirstPosition >= 0 && this.mFirstPosition < adapter.getCount ()) {
this.mSyncRowId = adapter.getItemId (this.mFirstPosition);
} else {
this.mSyncRowId = -1;
}this.mSyncPosition = this.mFirstPosition;
if (v != null) {
this.mSpecificTop = v.getTop ();
}this.mSyncMode = 1;
}}});
c$.$AdapterView$AdapterDataSetObserver$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mInstanceState = null;
Clazz.instantialize (this, arguments);
}, android.widget.AdapterView, "AdapterDataSetObserver", android.database.DataSetObserver);
Clazz.overrideMethod (c$, "onChanged", 
function () {
this.b$["android.widget.AdapterView"].mDataChanged = true;
this.b$["android.widget.AdapterView"].mOldItemCount = this.b$["android.widget.AdapterView"].mItemCount;
this.b$["android.widget.AdapterView"].mItemCount = this.b$["android.widget.AdapterView"].getAdapter ().getCount ();
if (this.b$["android.widget.AdapterView"].getAdapter ().hasStableIds () && this.mInstanceState != null && this.b$["android.widget.AdapterView"].mOldItemCount == 0 && this.b$["android.widget.AdapterView"].mItemCount > 0) {
this.mInstanceState = null;
} else {
this.b$["android.widget.AdapterView"].rememberSyncState ();
}this.b$["android.widget.AdapterView"].checkFocus ();
this.b$["android.widget.AdapterView"].requestLayout ();
});
Clazz.overrideMethod (c$, "onInvalidated", 
function () {
this.b$["android.widget.AdapterView"].mDataChanged = true;
if (this.b$["android.widget.AdapterView"].getAdapter ().hasStableIds ()) {
}this.b$["android.widget.AdapterView"].mOldItemCount = this.b$["android.widget.AdapterView"].mItemCount;
this.b$["android.widget.AdapterView"].mItemCount = 0;
this.b$["android.widget.AdapterView"].mSelectedPosition = -1;
this.b$["android.widget.AdapterView"].mSelectedRowId = -9223372036854775808;
this.b$["android.widget.AdapterView"].mNextSelectedPosition = -1;
this.b$["android.widget.AdapterView"].mNextSelectedRowId = -9223372036854775808;
this.b$["android.widget.AdapterView"].mNeedSync = false;
this.b$["android.widget.AdapterView"].checkFocus ();
this.b$["android.widget.AdapterView"].requestLayout ();
});
Clazz.defineMethod (c$, "clearSavedState", 
function () {
this.mInstanceState = null;
});
c$ = Clazz.p0p ();
};
Clazz.declareInterface (android.widget.AdapterView, "OnItemClickListener");
Clazz.declareInterface (android.widget.AdapterView, "OnItemLongClickListener");
Clazz.declareInterface (android.widget.AdapterView, "OnItemSelectedListener");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.targetView = null;
this.position = 0;
this.id = 0;
Clazz.instantialize (this, arguments);
}, android.widget.AdapterView, "AdapterContextMenuInfo", null, android.view.ContextMenu.ContextMenuInfo);
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.targetView = a;
this.position = b;
this.id = c;
}, "android.view.View,~N,~N");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"ITEM_VIEW_TYPE_IGNORE", -1,
"ITEM_VIEW_TYPE_HEADER_OR_FOOTER", -2,
"SYNC_SELECTED_POSITION", 0,
"SYNC_FIRST_POSITION", 1,
"SYNC_MAX_DURATION_MILLIS", 100,
"INVALID_POSITION", -1,
"INVALID_ROW_ID", -9223372036854775808);
});
