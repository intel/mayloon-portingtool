﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.AbsListView", "android.graphics.Rect", "com.google.android.collect.Lists"], "android.widget.ListView", ["android.graphics.Paint", "android.util.Log", "$.LongSparseArray", "$.SparseBooleanArray", "android.view.View", "$.ViewGroup", "android.widget.AdapterView", "$.ArrayAdapter", "$.HeaderViewListAdapter", "com.android.internal.R", "java.lang.Boolean", "$.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
if (!Clazz.isClassDefined ("android.widget.ListView.FixedViewInfo")) {
android.widget.ListView.$ListView$FixedViewInfo$ ();
}
this.mHeaderViewInfos = null;
this.mFooterViewInfos = null;
this.mDivider = null;
this.mDividerHeight = 0;
this.mOverScrollHeader = null;
this.mOverScrollFooter = null;
this.mIsCacheColorOpaque = false;
this.mDividerIsOpaque = false;
this.mClipDivider = false;
this.mHeaderDividersEnabled = false;
this.mFooterDividersEnabled = false;
this.mAreAllItemsSelectable = true;
this.mItemsCanFocus = false;
this.mChoiceMode = 0;
this.mCheckStates = null;
this.mCheckedIdStates = null;
this.$mTempRect = null;
this.mDividerPaint = null;
this.mFocusSelector = null;
if (!Clazz.isClassDefined ("android.widget.ListView.FocusSelector")) {
android.widget.ListView.$ListView$FocusSelector$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "ListView", android.widget.AbsListView);
Clazz.prepareFields (c$, function () {
this.mHeaderViewInfos = com.google.android.collect.Lists.newArrayList ();
this.mFooterViewInfos = com.google.android.collect.Lists.newArrayList ();
this.$mTempRect =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842868);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.ListView, [context, attrs, defStyle]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.ListView, defStyle, 0);
var entries = a.getTextArray (0);
if (entries != null) {
this.setAdapter ( new android.widget.ArrayAdapter (context, 17367043, entries));
}var d = a.getDrawable (1);
if (d != null) {
this.setDivider (d);
}var osHeader = a.getDrawable (6);
if (osHeader != null) {
this.setOverscrollHeader (osHeader);
}var osFooter = a.getDrawable (7);
if (osFooter != null) {
this.setOverscrollFooter (osFooter);
}var dividerHeight = a.getDimensionPixelSize (2, 0);
if (dividerHeight != 0) {
this.setDividerHeight (dividerHeight);
}this.setChoiceMode (a.getInt (3, 0));
this.mHeaderDividersEnabled = a.getBoolean (4, true);
this.mFooterDividersEnabled = a.getBoolean (5, true);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "adjustViewsUpOrDown", 
($fz = function () {
var childCount = this.getChildCount ();
var delta;
if (childCount > 0) {
var child;
if (!this.mStackFromBottom) {
child = this.getChildAt (0);
delta = child.getTop () - this.mListPadding.top;
if (this.mFirstPosition != 0) {
}if (delta < 0) {
delta = 0;
}} else {
child = this.getChildAt (childCount - 1);
delta = child.getBottom () - (this.getHeight () - this.mListPadding.bottom);
if (this.mFirstPosition + childCount < this.mItemCount) {
}if (delta > 0) {
delta = 0;
}}if (delta != 0) {
this.offsetChildrenTopAndBottom (-delta);
}}}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "getAdapter", 
function () {
return this.mAdapter;
});
Clazz.overrideMethod (c$, "setAdapter", 
function (adapter) {
if (null != this.mAdapter) {
this.mAdapter.unregisterDataSetObserver (this.mDataSetObserver);
}this.resetList ();
if (this.mHeaderViewInfos.size () > 0 || this.mFooterViewInfos.size () > 0) {
this.mAdapter =  new android.widget.HeaderViewListAdapter (this.mHeaderViewInfos, this.mFooterViewInfos, adapter);
} else {
this.mAdapter = adapter;
}this.mOldSelectedPosition = -1;
this.mOldSelectedRowId = -9223372036854775808;
if (this.mAdapter != null) {
this.mAreAllItemsSelectable = this.mAdapter.areAllItemsEnabled ();
this.mOldItemCount = this.mItemCount;
this.mItemCount = this.mAdapter.getCount ();
this.checkFocus ();
this.mDataSetObserver = Clazz.innerTypeInstance (android.widget.AdapterView.AdapterDataSetObserver, this, null);
this.mAdapter.registerDataSetObserver (this.mDataSetObserver);
var position;
if (this.mStackFromBottom) {
position = this.lookForSelectablePosition (this.mItemCount - 1, false);
} else {
position = this.lookForSelectablePosition (0, true);
}this.setSelectedPositionInt (position);
this.setNextSelectedPositionInt (position);
if (this.mItemCount == 0) {
this.checkSelectionChanged ();
}if (this.mChoiceMode != 0 && this.mAdapter.hasStableIds () && this.mCheckedIdStates == null) {
this.mCheckedIdStates =  new android.util.LongSparseArray ();
}} else {
this.mAreAllItemsSelectable = true;
this.checkFocus ();
this.checkSelectionChanged ();
}if (this.mCheckStates != null) {
this.mCheckStates.clear ();
}if (this.mCheckedIdStates != null) {
this.mCheckedIdStates.clear ();
}this.requestLayout ();
}, "android.widget.ListAdapter");
Clazz.defineMethod (c$, "resetList", 
function () {
Clazz.superCall (this, android.widget.ListView, "resetList", []);
this.mLayoutMode = 0;
});
Clazz.overrideMethod (c$, "requestChildRectangleOnScreen", 
function (child, rect, immediate) {
var rectTopWithinChild = rect.top;
rect.offset (child.getLeft (), child.getTop ());
rect.offset (-child.getScrollX (), -child.getScrollY ());
var height = this.getHeight ();
var listUnfadedTop = this.getScrollY ();
var listUnfadedBottom = listUnfadedTop + height;
var childCount = this.getChildCount ();
var bottomOfBottomChild = this.getChildAt (childCount - 1).getBottom ();
var scrollYDelta = 0;
if (rect.bottom > listUnfadedBottom && rect.top > listUnfadedTop) {
if (rect.height () > height) {
scrollYDelta += (rect.top - listUnfadedTop);
} else {
scrollYDelta += (rect.bottom - listUnfadedBottom);
}var distanceToBottom = bottomOfBottomChild - listUnfadedBottom;
scrollYDelta = Math.min (scrollYDelta, distanceToBottom);
} else if (rect.top < listUnfadedTop && rect.bottom < listUnfadedBottom) {
if (rect.height () > height) {
scrollYDelta -= (listUnfadedBottom - rect.bottom);
} else {
scrollYDelta -= (listUnfadedTop - rect.top);
}var top = this.getChildAt (0).getTop ();
var deltaToTop = top - listUnfadedTop;
scrollYDelta = Math.max (scrollYDelta, deltaToTop);
}var scroll = scrollYDelta != 0;
if (scroll) {
this.mSelectedTop = child.getTop ();
this.invalidate ();
}return scroll;
}, "android.view.View,android.graphics.Rect,~B");
Clazz.overrideMethod (c$, "fillGap", 
function (down) {
var count = this.getChildCount ();
if (down) {
var startOffset = count > 0 ? this.getChildAt (count - 1).getBottom () + this.mDividerHeight : this.getListPaddingTop ();
this.fillDown (this.mFirstPosition + count, startOffset);
this.correctTooHigh (this.getChildCount ());
} else {
var startOffset = count > 0 ? this.getChildAt (0).getTop () - this.mDividerHeight : this.getHeight () - this.getListPaddingBottom ();
this.fillUp (this.mFirstPosition - 1, startOffset);
this.correctTooLow (this.getChildCount ());
}}, "~B");
Clazz.defineMethod (c$, "fillDown", 
($fz = function (pos, nextTop) {
var selectedView = null;
var end = (this.mBottom - this.mTop) - this.mListPadding.bottom;
while (nextTop < end && pos < this.mItemCount) {
var selected = pos == this.mSelectedPosition;
var child = this.makeAndAddView (pos, nextTop, true, this.mListPadding.left, selected);
nextTop = child.getBottom () + this.mDividerHeight;
if (selected) {
selectedView = child;
}pos++;
}
return selectedView;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "fillUp", 
($fz = function (pos, nextBottom) {
var selectedView = null;
var end = this.mListPadding.top;
while (nextBottom > end && pos >= 0) {
var selected = pos == this.mSelectedPosition;
var child = this.makeAndAddView (pos, nextBottom, false, this.mListPadding.left, selected);
nextBottom = child.getTop () - this.mDividerHeight;
if (selected) {
selectedView = child;
}pos--;
}
this.mFirstPosition = pos + 1;
return selectedView;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "fillFromTop", 
($fz = function (nextTop) {
this.mFirstPosition = Math.min (this.mFirstPosition, this.mSelectedPosition);
this.mFirstPosition = Math.min (this.mFirstPosition, this.mItemCount - 1);
if (this.mFirstPosition < 0) {
this.mFirstPosition = 0;
}return this.fillDown (this.mFirstPosition, nextTop);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "fillFromMiddle", 
($fz = function (childrenTop, childrenBottom) {
System.out.println ("childrenTop: " + childrenTop + ", childrenBottom: " + childrenBottom);
var height = childrenBottom - childrenTop;
var position = this.reconcileSelectedPosition ();
var sel = this.makeAndAddView (position, childrenTop, true, this.mListPadding.left, true);
this.mFirstPosition = position;
var selHeight = sel.getMeasuredHeight ();
if (selHeight <= height) {
sel.offsetTopAndBottom (Math.floor ((height - selHeight) / 2));
}this.fillAboveAndBelow (sel, position);
if (!this.mStackFromBottom) {
this.correctTooHigh (this.getChildCount ());
} else {
this.correctTooLow (this.getChildCount ());
}return sel;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "fillAboveAndBelow", 
($fz = function (sel, position) {
var dividerHeight = this.mDividerHeight;
if (!this.mStackFromBottom) {
this.fillUp (position - 1, sel.getTop () - dividerHeight);
this.adjustViewsUpOrDown ();
this.fillDown (position + 1, sel.getBottom () + dividerHeight);
} else {
this.fillDown (position + 1, sel.getBottom () + dividerHeight);
this.adjustViewsUpOrDown ();
this.fillUp (position - 1, sel.getTop () - dividerHeight);
}}, $fz.isPrivate = true, $fz), "android.view.View,~N");
Clazz.defineMethod (c$, "fillFromSelection", 
($fz = function (selectedTop, childrenTop, childrenBottom) {
System.out.println ("selectedTop: " + selectedTop + ", childrenTop: " + childrenTop + ", childrenBottom: " + childrenBottom);
var fadingEdgeLength = 0;
var selectedPosition = this.mSelectedPosition;
var sel;
var topSelectionPixel = this.getTopSelectionPixel (childrenTop, fadingEdgeLength, selectedPosition);
var bottomSelectionPixel = this.getBottomSelectionPixel (childrenBottom, fadingEdgeLength, selectedPosition);
sel = this.makeAndAddView (selectedPosition, selectedTop, true, this.mListPadding.left, true);
if (sel.getBottom () > bottomSelectionPixel) {
var spaceAbove = sel.getTop () - topSelectionPixel;
var spaceBelow = sel.getBottom () - bottomSelectionPixel;
var offset = Math.min (spaceAbove, spaceBelow);
sel.offsetTopAndBottom (-offset);
} else if (sel.getTop () < topSelectionPixel) {
var spaceAbove = topSelectionPixel - sel.getTop ();
var spaceBelow = bottomSelectionPixel - sel.getBottom ();
var offset = Math.min (spaceAbove, spaceBelow);
sel.offsetTopAndBottom (offset);
}this.fillAboveAndBelow (sel, selectedPosition);
if (!this.mStackFromBottom) {
this.correctTooHigh (this.getChildCount ());
} else {
this.correctTooLow (this.getChildCount ());
}return sel;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "getBottomSelectionPixel", 
($fz = function (childrenBottom, fadingEdgeLength, selectedPosition) {
var bottomSelectionPixel = childrenBottom;
if (selectedPosition != this.mItemCount - 1) {
bottomSelectionPixel -= fadingEdgeLength;
}return bottomSelectionPixel;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "getTopSelectionPixel", 
($fz = function (childrenTop, fadingEdgeLength, selectedPosition) {
var topSelectionPixel = childrenTop;
if (selectedPosition > 0) {
topSelectionPixel += fadingEdgeLength;
}return topSelectionPixel;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "moveSelection", 
($fz = function (oldSel, newSel, delta, childrenTop, childrenBottom) {
var fadingEdgeLength = 0;
var selectedPosition = this.mSelectedPosition;
var sel;
var topSelectionPixel = this.getTopSelectionPixel (childrenTop, fadingEdgeLength, selectedPosition);
var bottomSelectionPixel = this.getBottomSelectionPixel (childrenTop, fadingEdgeLength, selectedPosition);
if (delta > 0) {
oldSel = this.makeAndAddView (selectedPosition - 1, oldSel.getTop (), true, this.mListPadding.left, false);
var dividerHeight = this.mDividerHeight;
sel = this.makeAndAddView (selectedPosition, oldSel.getBottom () + dividerHeight, true, this.mListPadding.left, true);
if (sel.getBottom () > bottomSelectionPixel) {
var spaceAbove = sel.getTop () - topSelectionPixel;
var spaceBelow = sel.getBottom () - bottomSelectionPixel;
var halfVerticalSpace = Math.floor ((childrenBottom - childrenTop) / 2);
var offset = Math.min (spaceAbove, spaceBelow);
offset = Math.min (offset, halfVerticalSpace);
oldSel.offsetTopAndBottom (-offset);
sel.offsetTopAndBottom (-offset);
}if (!this.mStackFromBottom) {
this.fillUp (this.mSelectedPosition - 2, sel.getTop () - dividerHeight);
this.adjustViewsUpOrDown ();
this.fillDown (this.mSelectedPosition + 1, sel.getBottom () + dividerHeight);
} else {
this.fillDown (this.mSelectedPosition + 1, sel.getBottom () + dividerHeight);
this.adjustViewsUpOrDown ();
this.fillUp (this.mSelectedPosition - 2, sel.getTop () - dividerHeight);
}} else if (delta < 0) {
if (newSel != null) {
sel = this.makeAndAddView (selectedPosition, newSel.getTop (), true, this.mListPadding.left, true);
} else {
sel = this.makeAndAddView (selectedPosition, oldSel.getTop (), false, this.mListPadding.left, true);
}if (sel.getTop () < topSelectionPixel) {
var spaceAbove = topSelectionPixel - sel.getTop ();
var spaceBelow = bottomSelectionPixel - sel.getBottom ();
var halfVerticalSpace = Math.floor ((childrenBottom - childrenTop) / 2);
var offset = Math.min (spaceAbove, spaceBelow);
offset = Math.min (offset, halfVerticalSpace);
sel.offsetTopAndBottom (offset);
}this.fillAboveAndBelow (sel, selectedPosition);
} else {
var oldTop = oldSel.getTop ();
sel = this.makeAndAddView (selectedPosition, oldTop, true, this.mListPadding.left, true);
if (oldTop < childrenTop) {
var newBottom = sel.getBottom ();
if (newBottom < childrenTop + 20) {
sel.offsetTopAndBottom (childrenTop - sel.getTop ());
}}this.fillAboveAndBelow (sel, selectedPosition);
}return sel;
}, $fz.isPrivate = true, $fz), "android.view.View,android.view.View,~N,~N,~N");
Clazz.defineMethod (c$, "onSizeChanged", 
function (w, h, oldw, oldh) {
if (this.getChildCount () > 0) {
var focusedChild = this.getFocusedChild ();
if (focusedChild != null) {
var childPosition = this.mFirstPosition + this.indexOfChild (focusedChild);
var childBottom = focusedChild.getBottom ();
var offset = Math.max (0, childBottom - (h - this.mPaddingTop));
var top = focusedChild.getTop () - offset;
if (this.mFocusSelector == null) {
this.mFocusSelector = Clazz.innerTypeInstance (android.widget.ListView.FocusSelector, this, null);
}}}Clazz.superCall (this, android.widget.ListView, "onSizeChanged", [w, h, oldw, oldh]);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
Clazz.superCall (this, android.widget.ListView, "onMeasure", [widthMeasureSpec, heightMeasureSpec]);
var widthMode = android.view.View.MeasureSpec.getMode (widthMeasureSpec);
var heightMode = android.view.View.MeasureSpec.getMode (heightMeasureSpec);
var widthSize = android.view.View.MeasureSpec.getSize (widthMeasureSpec);
var heightSize = android.view.View.MeasureSpec.getSize (heightMeasureSpec);
var childWidth = 0;
var childHeight = 0;
this.mItemCount = this.mAdapter == null ? 0 : this.mAdapter.getCount ();
if (this.mItemCount > 0 && (widthMode == 0 || heightMode == 0)) {
var child = this.obtainView (0);
this.measureScrapChild (child, 0, widthMeasureSpec);
childWidth = child.getMeasuredWidth ();
childHeight = child.getMeasuredHeight ();
}if (widthMode == 0) {
widthSize = this.mListPadding.left + this.mListPadding.right + childWidth;
}if (heightMode == 0) {
heightSize = this.mListPadding.top + this.mListPadding.bottom + childHeight;
}if (heightMode == -2147483648) {
heightSize = this.measureHeightOfChildren (widthMeasureSpec, 0, -1, heightSize, -1);
}this.setMeasuredDimension (widthSize, heightSize);
this.mWidthMeasureSpec = widthMeasureSpec;
}, "~N,~N");
Clazz.defineMethod (c$, "measureScrapChild", 
($fz = function (child, position, widthMeasureSpec) {
var p = child.getLayoutParams ();
if (p == null) {
p =  new android.widget.AbsListView.LayoutParams (-1, -2, 0);
child.setLayoutParams (p);
}p.viewType = this.mAdapter.getItemViewType (position);
p.forceAdd = true;
var childWidthSpec = android.view.ViewGroup.getChildMeasureSpec (widthMeasureSpec, this.mListPadding.left + this.mListPadding.right, p.width);
var lpHeight = p.height;
var childHeightSpec;
if (lpHeight > 0) {
childHeightSpec = android.view.View.MeasureSpec.makeMeasureSpec (lpHeight, 1073741824);
} else {
childHeightSpec = android.view.View.MeasureSpec.makeMeasureSpec (0, 0);
}child.measure (childWidthSpec, childHeightSpec);
}, $fz.isPrivate = true, $fz), "android.view.View,~N,~N");
Clazz.defineMethod (c$, "recycleOnMeasure", 
function () {
return true;
});
Clazz.defineMethod (c$, "measureHeightOfChildren", 
function (widthMeasureSpec, startPosition, endPosition, maxHeight, disallowPartialChildPosition) {
var adapter = this.mAdapter;
if (adapter == null) {
return this.mListPadding.top + this.mListPadding.bottom;
}var returnedHeight = this.mListPadding.top + this.mListPadding.bottom;
var dividerHeight = ((this.mDividerHeight > 0) && this.mDivider != null) ? this.mDividerHeight : 0;
var prevHeightWithoutPartialChild = 0;
var i;
var child;
endPosition = (endPosition == -1) ? adapter.getCount () - 1 : endPosition;
for (i = startPosition; i <= endPosition; ++i) {
child = this.obtainView (i);
this.measureScrapChild (child, i, widthMeasureSpec);
if (i > 0) {
returnedHeight += dividerHeight;
}returnedHeight += child.getMeasuredHeight ();
if (returnedHeight >= maxHeight) {
return (disallowPartialChildPosition >= 0) && (i > disallowPartialChildPosition) && (prevHeightWithoutPartialChild > 0) && (returnedHeight != maxHeight) ? prevHeightWithoutPartialChild : maxHeight;
}if ((disallowPartialChildPosition >= 0) && (i >= disallowPartialChildPosition)) {
prevHeightWithoutPartialChild = returnedHeight;
}}
return returnedHeight;
}, "~N,~N,~N,~N,~N");
Clazz.overrideMethod (c$, "findMotionRow", 
function (y) {
var childCount = this.getChildCount ();
if (childCount > 0) {
if (!this.mStackFromBottom) {
for (var i = 0; i < childCount; i++) {
var v = this.getChildAt (i);
if (y <= v.getBottom ()) {
return this.mFirstPosition + i;
}}
} else {
for (var i = childCount - 1; i >= 0; i--) {
var v = this.getChildAt (i);
if (y >= v.getTop ()) {
return this.mFirstPosition + i;
}}
}}return -1;
}, "~N");
Clazz.defineMethod (c$, "fillSpecific", 
($fz = function (position, top) {
System.out.println ("position: " + position + ", top: " + top);
var tempIsSelected = position == this.mSelectedPosition;
var temp = this.makeAndAddView (position, top, true, this.mListPadding.left, tempIsSelected);
this.mFirstPosition = position;
var above;
var below;
var dividerHeight = 0;
if (this.mStackFromBottom == false) {
above = this.fillUp (position - 1, temp.getTop () - 0);
this.adjustViewsUpOrDown ();
below = this.fillDown (position + 1, temp.getBottom () + 0);
var childCount = this.getChildCount ();
if (childCount > 0) {
this.correctTooHigh (childCount);
}} else {
below = this.fillDown (position + 1, temp.getBottom () + 0);
this.adjustViewsUpOrDown ();
above = this.fillUp (position - 1, temp.getTop () - 0);
var childCount = this.getChildCount ();
if (childCount > 0) {
this.correctTooLow (childCount);
}}if (tempIsSelected) {
return temp;
} else if (above != null) {
return above;
} else {
return below;
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "correctTooHigh", 
($fz = function (childCount) {
var lastPosition = this.mFirstPosition + childCount - 1;
if (lastPosition == this.mItemCount - 1 && childCount > 0) {
var lastChild = this.getChildAt (childCount - 1);
var lastBottom = lastChild.getBottom ();
var end = (this.mBottom - this.mTop) - this.mListPadding.bottom;
var bottomOffset = end - lastBottom;
var firstChild = this.getChildAt (0);
var firstTop = firstChild.getTop ();
if (bottomOffset > 0 && (this.mFirstPosition > 0 || firstTop < this.mListPadding.top)) {
if (this.mFirstPosition == 0) {
bottomOffset = Math.min (bottomOffset, this.mListPadding.top - firstTop);
}this.offsetChildrenTopAndBottom (bottomOffset);
if (this.mFirstPosition > 0) {
this.fillUp (this.mFirstPosition - 1, firstChild.getTop ());
this.adjustViewsUpOrDown ();
}}}}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "correctTooLow", 
($fz = function (childCount) {
if (this.mFirstPosition == 0 && childCount > 0) {
var firstChild = this.getChildAt (0);
var firstTop = firstChild.getTop ();
var start = this.mListPadding.top;
var end = (this.mBottom - this.mTop) - this.mListPadding.bottom;
var topOffset = firstTop - start;
var lastChild = this.getChildAt (childCount - 1);
var lastBottom = lastChild.getBottom ();
var lastPosition = this.mFirstPosition + childCount - 1;
if (topOffset > 0) {
if (lastPosition < this.mItemCount - 1 || lastBottom > end) {
if (lastPosition == this.mItemCount - 1) {
topOffset = Math.min (topOffset, lastBottom - end);
}this.offsetChildrenTopAndBottom (-topOffset);
if (lastPosition < this.mItemCount - 1) {
this.fillDown (lastPosition + 1, lastChild.getBottom ());
this.adjustViewsUpOrDown ();
}} else if (lastPosition == this.mItemCount - 1) {
this.adjustViewsUpOrDown ();
}}}}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "layoutChildren", 
function () {
var blockLayoutRequests = this.mBlockLayoutRequests;
if (blockLayoutRequests == false) {
this.mBlockLayoutRequests = true;
} else {
return ;
}try {
Clazz.superCall (this, android.widget.ListView, "layoutChildren", []);
this.invalidate ();
if (this.mAdapter == null) {
this.resetList ();
this.invokeOnItemScrollListener ();
return ;
}var childrenTop = this.mListPadding.top;
var childrenBottom = this.mBottom - this.mTop - this.mListPadding.bottom;
var childCount = this.getChildCount ();
var index = 0;
var delta = 0;
var sel;
var oldSel = null;
var oldFirst = null;
var newSel = null;
switch (this.mLayoutMode) {
case 2:
index = this.mNextSelectedPosition - this.mFirstPosition;
if (index >= 0 && index < childCount) {
newSel = this.getChildAt (index);
}break;
case 1:
case 3:
case 4:
case 5:
break;
case 6:
default:
index = this.mSelectedPosition - this.mFirstPosition;
if (index >= 0 && index < childCount) {
oldSel = this.getChildAt (index);
}oldFirst = this.getChildAt (0);
if (this.mNextSelectedPosition >= 0) {
delta = this.mNextSelectedPosition - this.mSelectedPosition;
}newSel = this.getChildAt (index + delta);
}
var dataChanged = this.mDataChanged;
if (dataChanged) {
this.handleDataChanged ();
}if (this.mItemCount == 0) {
this.resetList ();
this.invokeOnItemScrollListener ();
return ;
} else if (this.mItemCount != this.mAdapter.getCount ()) {
throw  new IllegalStateException ("The content of the adapter has changed but ListView did not receive a notification. Make sure the content of your adapter is not modified from a background thread, but only from the UI thread. [in ListView(" + this.getUIElementID () + ", " + this.getClass ().getName () + ") with Adapter(" + this.mAdapter.getClass ().getName () + ")]");
}this.setSelectedPositionInt (this.mNextSelectedPosition);
this.mLayoutMode = 0;
switch (this.mLayoutMode) {
case 2:
if (newSel != null) {
sel = this.fillFromSelection (newSel.getTop (), childrenTop, childrenBottom);
} else {
sel = this.fillFromMiddle (childrenTop, childrenBottom);
}break;
case 5:
sel = this.fillSpecific (this.mSyncPosition, this.mSpecificTop);
break;
case 3:
sel = this.fillUp (this.mItemCount - 1, childrenBottom);
this.adjustViewsUpOrDown ();
break;
case 1:
this.mFirstPosition = 0;
sel = this.fillFromTop (childrenTop);
this.adjustViewsUpOrDown ();
break;
case 4:
sel = this.fillSpecific (this.reconcileSelectedPosition (), this.mSpecificTop);
break;
case 6:
sel = this.moveSelection (oldSel, newSel, delta, childrenTop, childrenBottom);
break;
default:
if (childCount == 0) {
if (!this.mStackFromBottom) {
var position = this.lookForSelectablePosition (0, true);
this.setSelectedPositionInt (position);
sel = this.fillFromTop (childrenTop);
} else {
var position = this.lookForSelectablePosition (this.mItemCount - 1, false);
this.setSelectedPositionInt (position);
sel = this.fillUp (this.mItemCount - 1, childrenBottom);
}} else {
android.util.Log.i ("ListView", "ListView mLayoutMode = " + this.mLayoutMode);
if (this.mSelectedPosition >= 0 && this.mSelectedPosition < this.mItemCount) {
sel = this.fillSpecific (this.mSelectedPosition, oldSel == null ? childrenTop : oldSel.getTop ());
} else if (this.mFirstPosition < this.mItemCount) {
sel = this.fillSpecific (this.mFirstPosition, oldFirst == null ? childrenTop : oldFirst.getTop ());
} else {
sel = this.fillSpecific (0, childrenTop);
}}break;
}
if (sel != null) {
this.mSelectedTop = sel.getTop ();
} else {
}this.mLayoutMode = 0;
this.mDataChanged = false;
this.mNeedSync = false;
this.setNextSelectedPositionInt (this.mSelectedPosition);
if (this.mItemCount > 0) {
this.checkSelectionChanged ();
}this.invokeOnItemScrollListener ();
} finally {
if (!blockLayoutRequests) {
this.mBlockLayoutRequests = false;
}}
});
Clazz.defineMethod (c$, "makeAndAddView", 
($fz = function (position, y, flow, childrenLeft, selected) {
var child = null;
child = this.obtainView (position);
this.setupChild (child, position, y, flow, childrenLeft, selected);
return child;
}, $fz.isPrivate = true, $fz), "~N,~N,~B,~N,~B");
Clazz.defineMethod (c$, "setupChild", 
($fz = function (child, position, y, flowDown, childrenLeft, selected) {
var isSelected = selected;
var updateChildSelected = isSelected != child.isSelected ();
var needToMeasure = child.isLayoutRequested ();
var p = child.getLayoutParams ();
if (p == null) {
p =  new android.widget.AbsListView.LayoutParams (-1, -2, 0);
}p.viewType = this.mAdapter.getItemViewType (position);
p.forceAdd = false;
if (p.viewType == -2) {
p.recycledHeaderFooter = true;
}this.addViewInLayout (child, flowDown ? -1 : 0, p, true);
if (updateChildSelected) {
child.setSelected (isSelected);
}if (this.mChoiceMode != 0 && this.mCheckStates != null) {
if (Clazz.instanceOf (child, android.widget.Checkable)) {
(child).setChecked (this.mCheckStates.get (position));
}}if (needToMeasure) {
var childWidthSpec = android.view.ViewGroup.getChildMeasureSpec (this.mWidthMeasureSpec, this.mListPadding.left + this.mListPadding.right, p.width);
var lpHeight = p.height;
var childHeightSpec;
if (lpHeight > 0) {
childHeightSpec = android.view.View.MeasureSpec.makeMeasureSpec (lpHeight, 1073741824);
} else {
childHeightSpec = android.view.View.MeasureSpec.makeMeasureSpec (0, 0);
}child.measure (childWidthSpec, childHeightSpec);
} else {
this.cleanupLayoutState (child);
}var w = child.getMeasuredWidth ();
var h = child.getMeasuredHeight ();
var childTop = flowDown ? y : y - h;
if (needToMeasure) {
var childRight = childrenLeft + w;
var childBottom = childTop + h;
child.layout (childrenLeft, childTop, childRight, childBottom);
} else {
child.offsetLeftAndRight (childrenLeft - child.getLeft ());
child.offsetTopAndBottom (childTop - child.getTop ());
}}, $fz.isPrivate = true, $fz), "android.view.View,~N,~N,~B,~N,~B");
Clazz.overrideMethod (c$, "setSelection", 
function (position) {
this.setSelectionFromTop (position, 0);
}, "~N");
Clazz.defineMethod (c$, "setSelectionFromTop", 
function (position, y) {
if (this.mAdapter == null) {
return ;
}if (!this.isInTouchMode ()) {
position = this.lookForSelectablePosition (position, true);
if (position >= 0) {
this.setNextSelectedPositionInt (position);
}} else {
this.mResurrectToPosition = position;
}if (position >= 0) {
this.mLayoutMode = 4;
this.mSpecificTop = this.mListPadding.top + y;
if (this.mNeedSync) {
this.mSyncPosition = position;
this.mSyncRowId = this.mAdapter.getItemId (position);
}this.requestLayout ();
}}, "~N,~N");
Clazz.overrideMethod (c$, "setSelectionInt", 
function (position) {
this.setNextSelectedPositionInt (position);
var awakeScrollbars = false;
var selectedPosition = this.mSelectedPosition;
if (selectedPosition >= 0) {
if (position == selectedPosition - 1) {
awakeScrollbars = true;
} else if (position == selectedPosition + 1) {
awakeScrollbars = true;
}}this.layoutChildren ();
}, "~N");
Clazz.overrideMethod (c$, "lookForSelectablePosition", 
function (position, lookDown) {
var adapter = this.mAdapter;
if (adapter == null || this.isInTouchMode ()) {
return -1;
}var count = adapter.getCount ();
if (!this.mAreAllItemsSelectable) {
if (lookDown) {
position = Math.max (0, position);
while (position < count && !adapter.isEnabled (position)) {
position++;
}
} else {
position = Math.min (position, count - 1);
while (position >= 0 && !adapter.isEnabled (position)) {
position--;
}
}if (position < 0 || position >= count) {
return -1;
}return position;
} else {
if (position < 0 || position >= count) {
return -1;
}return position;
}}, "~N,~B");
Clazz.defineMethod (c$, "dispatchKeyEvent", 
function (event) {
var handled = Clazz.superCall (this, android.widget.ListView, "dispatchKeyEvent", [event]);
if (!handled) {
var focused = this.getFocusedChild ();
if (focused != null && event.getAction () == 0) {
handled = this.onKeyDown (event.getKeyCode (), event);
}}return handled;
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyDown", 
function (keyCode, event) {
return this.commonKey (keyCode, 1, event);
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "commonKey", 
($fz = function (keyCode, count, event) {
if (this.mAdapter == null) {
return false;
}if (this.mDataChanged) {
this.layoutChildren ();
}var handled = false;
var action = event.getAction ();
if (action != 1) {
if (this.mSelectedPosition < 0) {
switch (keyCode) {
case 38:
case 40:
case 23:
case 13:
case 62:
return true;
}
}switch (keyCode) {
case 38:
if (!event.isAltPressed ()) {
while (count > 0) {
handled = this.arrowScroll (33);
count--;
}
} else {
handled = this.fullScroll (33);
}break;
case 40:
if (!event.isAltPressed ()) {
while (count > 0) {
handled = this.arrowScroll (130);
count--;
}
} else {
handled = this.fullScroll (130);
}break;
case 23:
case 13:
handled = true;
break;
case 62:
handled = true;
break;
}
}if (handled) {
return true;
} else {
switch (action) {
case 0:
return Clazz.superCall (this, android.widget.ListView, "onKeyDown", [keyCode, event]);
case 1:
return Clazz.superCall (this, android.widget.ListView, "onKeyUp", [keyCode, event]);
case 2:
return Clazz.superCall (this, android.widget.ListView, "onKeyMultiple", [keyCode, count, event]);
default:
return false;
}
}}, $fz.isPrivate = true, $fz), "~N,~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "arrowScroll", 
function (direction) {
try {
this.mInLayout = true;
var handled = this.arrowScrollImpl (direction);
if (handled) {
}return handled;
} finally {
this.mInLayout = false;
}
}, "~N");
Clazz.defineMethod (c$, "arrowScrollImpl", 
($fz = function (direction) {
if (this.getChildCount () <= 0) {
return false;
}var selectedView = this.getSelectedView ();
var nextSelectedPosition = this.lookForSelectablePositionOnScreen (direction);
var amountToScroll = this.amountToScroll (direction, nextSelectedPosition);
var focusResult = null;
if (focusResult != null) {
nextSelectedPosition = focusResult.getSelectedPosition ();
amountToScroll = focusResult.getAmountToScroll ();
}var needToRedraw = focusResult != null;
if (nextSelectedPosition != -1) {
this.setSelectedPositionInt (nextSelectedPosition);
this.setNextSelectedPositionInt (nextSelectedPosition);
selectedView = this.getSelectedView ();
if (this.mItemsCanFocus && focusResult == null) {
var focused = this.getFocusedChild ();
if (focused != null) {
focused.clearFocus ();
}}needToRedraw = true;
this.checkSelectionChanged ();
}if (amountToScroll > 0) {
needToRedraw = true;
}if (this.mItemsCanFocus && (focusResult == null) && selectedView != null && selectedView.hasFocus ()) {
var focused = selectedView.findFocus ();
if (this.distanceToView (focused) > 0) {
focused.clearFocus ();
}}if (nextSelectedPosition == -1 && selectedView != null && !this.isViewAncestorOf (selectedView, this)) {
selectedView = null;
this.hideSelector ();
this.mResurrectToPosition = -1;
}if (needToRedraw) {
if (selectedView != null) {
this.mSelectedTop = selectedView.getTop ();
}if (!this.awakenScrollBars ()) {
this.invalidate ();
}this.invokeOnItemScrollListener ();
return true;
}return false;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "amountToScroll", 
($fz = function (direction, nextSelectedPosition) {
var listBottom = this.getHeight () - this.mListPadding.bottom;
var listTop = this.mListPadding.top;
var numChildren = this.getChildCount ();
if (direction == 130) {
var indexToMakeVisible = numChildren - 1;
if (nextSelectedPosition != -1) {
indexToMakeVisible = nextSelectedPosition - this.mFirstPosition;
}var positionToMakeVisible = this.mFirstPosition + indexToMakeVisible;
var viewToMakeVisible = this.getChildAt (indexToMakeVisible);
var goalBottom = listBottom;
if (positionToMakeVisible < this.mItemCount - 1) {
goalBottom -= this.getArrowScrollPreviewLength ();
}if (viewToMakeVisible.getBottom () <= goalBottom) {
return 0;
}if (nextSelectedPosition != -1 && (goalBottom - viewToMakeVisible.getTop ()) >= this.getMaxScrollAmount ()) {
return 0;
}var amountToScroll = (viewToMakeVisible.getBottom () - goalBottom);
if ((this.mFirstPosition + numChildren) == this.mItemCount) {
var max = this.getChildAt (numChildren - 1).getBottom () - listBottom;
amountToScroll = Math.min (amountToScroll, max);
}return Math.min (amountToScroll, this.getMaxScrollAmount ());
} else {
var indexToMakeVisible = 0;
if (nextSelectedPosition != -1) {
indexToMakeVisible = nextSelectedPosition - this.mFirstPosition;
}var positionToMakeVisible = this.mFirstPosition + indexToMakeVisible;
var viewToMakeVisible = this.getChildAt (indexToMakeVisible);
var goalTop = listTop;
if (positionToMakeVisible > 0) {
goalTop += this.getArrowScrollPreviewLength ();
}if (viewToMakeVisible.getTop () >= goalTop) {
return 0;
}if (nextSelectedPosition != -1 && (viewToMakeVisible.getBottom () - goalTop) >= this.getMaxScrollAmount ()) {
return 0;
}var amountToScroll = (goalTop - viewToMakeVisible.getTop ());
if (this.mFirstPosition == 0) {
var max = listTop - this.getChildAt (0).getTop ();
amountToScroll = Math.min (amountToScroll, max);
}return Math.min (amountToScroll, this.getMaxScrollAmount ());
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "getArrowScrollPreviewLength", 
($fz = function () {
return Math.max (2, this.getVerticalFadingEdgeLength ());
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "pageScroll", 
function (direction) {
var nextPage = -1;
var down = false;
if (direction == 33) {
nextPage = Math.max (0, this.mSelectedPosition - this.getChildCount () - 1);
} else if (direction == 130) {
nextPage = Math.min (this.mItemCount - 1, this.mSelectedPosition + this.getChildCount () - 1);
down = true;
}if (nextPage >= 0) {
var position = this.lookForSelectablePosition (nextPage, down);
if (position >= 0) {
this.mLayoutMode = 4;
this.mSpecificTop = this.mPaddingTop + 0;
if (down && position > this.mItemCount - this.getChildCount ()) {
this.mLayoutMode = 3;
}if (!down && position < this.getChildCount ()) {
this.mLayoutMode = 1;
}this.setSelectionInt (position);
this.invokeOnItemScrollListener ();
return true;
}}return false;
}, "~N");
Clazz.defineMethod (c$, "fullScroll", 
function (direction) {
var moved = false;
if (direction == 33) {
if (this.mSelectedPosition != 0) {
var position = this.lookForSelectablePosition (0, true);
if (position >= 0) {
this.mLayoutMode = 1;
this.setSelectionInt (position);
this.invokeOnItemScrollListener ();
}moved = true;
}} else if (direction == 130) {
if (this.mSelectedPosition < this.mItemCount - 1) {
var position = this.lookForSelectablePosition (this.mItemCount - 1, true);
if (position >= 0) {
this.mLayoutMode = 3;
this.setSelectionInt (position);
this.invokeOnItemScrollListener ();
}moved = true;
}}return moved;
}, "~N");
Clazz.defineMethod (c$, "measureItem", 
($fz = function (child) {
var p = child.getLayoutParams ();
if (p == null) {
p =  new android.view.ViewGroup.LayoutParams (-1, -2);
}var childWidthSpec = android.view.ViewGroup.getChildMeasureSpec (this.mWidthMeasureSpec, this.mListPadding.left + this.mListPadding.right, p.width);
var lpHeight = p.height;
var childHeightSpec;
if (lpHeight > 0) {
childHeightSpec = android.view.View.MeasureSpec.makeMeasureSpec (lpHeight, 1073741824);
} else {
childHeightSpec = android.view.View.MeasureSpec.makeMeasureSpec (0, 0);
}child.measure (childWidthSpec, childHeightSpec);
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "relayoutMeasuredItem", 
($fz = function (child) {
var w = child.getMeasuredWidth ();
var h = child.getMeasuredHeight ();
var childLeft = this.mListPadding.left;
var childRight = childLeft + w;
var childTop = child.getTop ();
var childBottom = childTop + h;
child.layout (childLeft, childTop, childRight, childBottom);
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "lookForSelectablePositionOnScreen", 
($fz = function (direction) {
var firstPosition = this.mFirstPosition;
if (direction == 130) {
var startPos = (this.mSelectedPosition != -1) ? this.mSelectedPosition + 1 : firstPosition;
if (startPos >= this.mAdapter.getCount ()) {
return -1;
}if (startPos < firstPosition) {
startPos = firstPosition;
}var lastVisiblePos = this.getLastVisiblePosition ();
var adapter = this.getAdapter ();
for (var pos = startPos; pos <= lastVisiblePos; pos++) {
if (adapter.isEnabled (pos) && this.getChildAt (pos - firstPosition).getVisibility () == 0) {
return pos;
}}
} else {
var last = firstPosition + this.getChildCount () - 1;
var startPos = (this.mSelectedPosition != -1) ? this.mSelectedPosition - 1 : firstPosition + this.getChildCount () - 1;
if (startPos < 0) {
return -1;
}if (startPos > last) {
startPos = last;
}var adapter = this.getAdapter ();
for (var pos = startPos; pos >= firstPosition; pos--) {
if (adapter.isEnabled (pos) && this.getChildAt (pos - firstPosition).getVisibility () == 0) {
return pos;
}}
}return -1;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "isViewAncestorOf", 
($fz = function (child, parent) {
if (child === parent) {
return true;
}var theParent = child.getParent ();
return (Clazz.instanceOf (theParent, android.view.ViewGroup)) && this.isViewAncestorOf (theParent, parent);
}, $fz.isPrivate = true, $fz), "android.view.View,android.view.View");
Clazz.defineMethod (c$, "distanceToView", 
($fz = function (descendant) {
var distance = 0;
descendant.getDrawingRect (this.$mTempRect);
this.offsetDescendantRectToMyCoords (descendant, this.$mTempRect);
var listBottom = this.mBottom - this.mTop - this.mListPadding.bottom;
if (this.$mTempRect.bottom < this.mListPadding.top) {
distance = this.mListPadding.top - this.$mTempRect.bottom;
} else if (this.$mTempRect.top > listBottom) {
distance = this.$mTempRect.top - listBottom;
}return distance;
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "setItemsCanFocus", 
function (itemsCanFocus) {
this.mItemsCanFocus = itemsCanFocus;
if (!itemsCanFocus) {
this.setDescendantFocusability (393216);
}}, "~B");
Clazz.defineMethod (c$, "isOpaque", 
function () {
return (this.mCachingStarted && this.mIsCacheColorOpaque && this.mDividerIsOpaque && this.hasOpaqueScrollbars ()) || Clazz.superCall (this, android.widget.ListView, "isOpaque", []);
});
Clazz.defineMethod (c$, "setCacheColorHint", 
function (color) {
var opaque = (color >>> 24) == 0xFF;
this.mIsCacheColorOpaque = opaque;
if (opaque) {
if (this.mDividerPaint == null) {
this.mDividerPaint =  new android.graphics.Paint ();
}this.mDividerPaint.setColor (color);
}Clazz.superCall (this, android.widget.ListView, "setCacheColorHint", [color]);
}, "~N");
Clazz.defineMethod (c$, "drawOverscrollHeader", 
function (canvas, drawable, bounds) {
var height = drawable.getMinimumHeight ();
canvas.save ();
canvas.clipRect (bounds);
var span = bounds.bottom - bounds.top;
if (span < height) {
bounds.top = bounds.bottom - height;
}drawable.setBounds (bounds);
drawable.draw (canvas);
canvas.restore ();
}, "android.graphics.Canvas,android.graphics.drawable.Drawable,android.graphics.Rect");
Clazz.defineMethod (c$, "drawOverscrollFooter", 
function (canvas, drawable, bounds) {
var height = drawable.getMinimumHeight ();
canvas.save ();
canvas.clipRect (bounds);
var span = bounds.bottom - bounds.top;
if (span < height) {
bounds.bottom = bounds.top + height;
}drawable.setBounds (bounds);
drawable.draw (canvas);
canvas.restore ();
}, "android.graphics.Canvas,android.graphics.drawable.Drawable,android.graphics.Rect");
Clazz.defineMethod (c$, "dispatchDraw", 
function (canvas) {
var dividerHeight = this.mDividerHeight;
var overscrollHeader = this.mOverScrollHeader;
var overscrollFooter = this.mOverScrollFooter;
var drawOverscrollHeader = overscrollHeader != null;
var drawOverscrollFooter = overscrollFooter != null;
var drawDividers = dividerHeight > 0 && this.mDivider != null;
if (drawDividers || drawOverscrollHeader || drawOverscrollFooter) {
var bounds = this.$mTempRect;
bounds.left = this.mPaddingLeft;
bounds.right = this.mRight - this.mLeft - this.mPaddingRight;
var count = this.getChildCount ();
var headerCount = this.mHeaderViewInfos.size ();
var itemCount = this.mItemCount;
var footerLimit = itemCount - this.mFooterViewInfos.size () - 1;
var headerDividers = this.mHeaderDividersEnabled;
var footerDividers = this.mFooterDividersEnabled;
var first = this.mFirstPosition;
var areAllItemsSelectable = this.mAreAllItemsSelectable;
var adapter = this.mAdapter;
var fillForMissingDividers = drawDividers && this.isOpaque () && !Clazz.superCall (this, android.widget.ListView, "isOpaque", []);
if (fillForMissingDividers && this.mDividerPaint == null && this.mIsCacheColorOpaque) {
this.mDividerPaint =  new android.graphics.Paint ();
this.mDividerPaint.setColor (this.getCacheColorHint ());
}var paint = this.mDividerPaint;
var listBottom = this.mBottom - this.mTop - this.mListPadding.bottom + this.mScrollY;
if (!this.mStackFromBottom) {
var bottom = 0;
var scrollY = this.mScrollY;
if (count > 0 && scrollY < 0) {
if (drawOverscrollHeader) {
bounds.bottom = 0;
bounds.top = scrollY;
this.drawOverscrollHeader (canvas, overscrollHeader, bounds);
} else if (drawDividers) {
bounds.bottom = 0;
bounds.top = -dividerHeight;
this.drawDivider (canvas, bounds, -1);
}}for (var i = 0; i < count; i++) {
if ((headerDividers || first + i >= headerCount) && (footerDividers || first + i < footerLimit)) {
var child = this.getChildAt (i);
bottom = child.getBottom ();
if (drawDividers && (bottom < listBottom && !(drawOverscrollFooter && i == count - 1))) {
if ((areAllItemsSelectable || (adapter.isEnabled (first + i) && (i == count - 1 || adapter.isEnabled (first + i + 1))))) {
bounds.top = bottom;
bounds.bottom = bottom + dividerHeight;
this.drawDivider (canvas, bounds, i);
} else if (fillForMissingDividers) {
bounds.top = bottom;
bounds.bottom = bottom + dividerHeight;
canvas.drawRect (bounds, paint);
}}}}
var overFooterBottom = this.mBottom + this.mScrollY;
if (drawOverscrollFooter && first + count == itemCount && overFooterBottom > bottom) {
bounds.top = bottom;
bounds.bottom = overFooterBottom;
this.drawOverscrollFooter (canvas, overscrollFooter, bounds);
}} else {
var top;
var listTop = this.mListPadding.top;
var scrollY = this.mScrollY;
if (count > 0 && drawOverscrollHeader) {
bounds.top = scrollY;
bounds.bottom = this.getChildAt (0).getTop ();
this.drawOverscrollHeader (canvas, overscrollHeader, bounds);
}var start = drawOverscrollHeader ? 1 : 0;
for (var i = start; i < count; i++) {
if ((headerDividers || first + i >= headerCount) && (footerDividers || first + i < footerLimit)) {
var child = this.getChildAt (i);
top = child.getTop ();
if (drawDividers && top > listTop) {
if ((areAllItemsSelectable || (adapter.isEnabled (first + i) && (i == count - 1 || adapter.isEnabled (first + i + 1))))) {
bounds.top = top - dividerHeight;
bounds.bottom = top;
this.drawDivider (canvas, bounds, i - 1);
} else if (fillForMissingDividers) {
bounds.top = top - dividerHeight;
bounds.bottom = top;
canvas.drawRect (bounds, paint);
}}}}
if (count > 0 && scrollY > 0) {
if (drawOverscrollFooter) {
var absListBottom = this.mBottom;
bounds.top = absListBottom;
bounds.bottom = absListBottom + scrollY;
this.drawOverscrollFooter (canvas, overscrollFooter, bounds);
} else if (drawDividers) {
bounds.top = listBottom;
bounds.bottom = listBottom + dividerHeight;
this.drawDivider (canvas, bounds, -1);
}}}}Clazz.superCall (this, android.widget.ListView, "dispatchDraw", [canvas]);
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "getItemsCanFocus", 
function () {
return this.mItemsCanFocus;
});
Clazz.defineMethod (c$, "drawDivider", 
function (canvas, bounds, childIndex) {
var divider = this.mDivider;
var clipDivider = this.mClipDivider;
if (!clipDivider) {
divider.setBounds (bounds);
} else {
canvas.save ();
canvas.clipRect (bounds);
}divider.draw (canvas);
if (clipDivider) {
canvas.restore ();
}}, "android.graphics.Canvas,android.graphics.Rect,~N");
Clazz.defineMethod (c$, "getDivider", 
function () {
return this.mDivider;
});
Clazz.defineMethod (c$, "setDivider", 
function (divider) {
if (divider != null) {
this.mDividerHeight = divider.getIntrinsicHeight ();
this.mClipDivider = Clazz.instanceOf (divider, android.graphics.drawable.ColorDrawable);
} else {
this.mDividerHeight = 0;
this.mClipDivider = false;
}this.mDivider = divider;
this.mDividerIsOpaque = divider == null || divider.getOpacity () == -1;
this.requestLayoutIfNecessary ();
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "getDividerHeight", 
function () {
return this.mDividerHeight;
});
Clazz.defineMethod (c$, "setDividerHeight", 
function (height) {
this.mDividerHeight = height;
this.requestLayoutIfNecessary ();
}, "~N");
Clazz.defineMethod (c$, "setHeaderDividersEnabled", 
function (headerDividersEnabled) {
this.mHeaderDividersEnabled = headerDividersEnabled;
this.invalidate ();
}, "~B");
Clazz.defineMethod (c$, "setFooterDividersEnabled", 
function (footerDividersEnabled) {
this.mFooterDividersEnabled = footerDividersEnabled;
this.invalidate ();
}, "~B");
Clazz.defineMethod (c$, "setOverscrollHeader", 
function (header) {
this.mOverScrollHeader = header;
if (this.mScrollY < 0) {
this.invalidate ();
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "getOverscrollHeader", 
function () {
return this.mOverScrollHeader;
});
Clazz.defineMethod (c$, "setOverscrollFooter", 
function (footer) {
this.mOverScrollFooter = footer;
this.invalidate ();
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "getOverscrollFooter", 
function () {
return this.mOverScrollFooter;
});
Clazz.defineMethod (c$, "onFocusChanged", 
function (gainFocus, direction, previouslyFocusedRect) {
Clazz.superCall (this, android.widget.ListView, "onFocusChanged", [gainFocus, direction, previouslyFocusedRect]);
var closetChildIndex = -1;
if (gainFocus && previouslyFocusedRect != null) {
previouslyFocusedRect.offset (this.mScrollX, this.mScrollY);
var adapter = this.mAdapter;
if (adapter.getCount () < this.getChildCount () + this.mFirstPosition) {
this.mLayoutMode = 0;
this.layoutChildren ();
}var otherRect = this.$mTempRect;
var minDistance = 2147483647;
var childCount = this.getChildCount ();
var firstPosition = this.mFirstPosition;
for (var i = 0; i < childCount; i++) {
if (!adapter.isEnabled (firstPosition + i)) {
continue ;}var other = this.getChildAt (i);
other.getDrawingRect (otherRect);
this.offsetDescendantRectToMyCoords (other, otherRect);
var distance = android.widget.AbsListView.getDistance (previouslyFocusedRect, otherRect, direction);
if (distance < minDistance) {
minDistance = distance;
closetChildIndex = i;
}}
}if (closetChildIndex >= 0) {
this.setSelection (closetChildIndex + this.mFirstPosition);
} else {
this.requestLayout ();
}}, "~B,~N,android.graphics.Rect");
Clazz.defineMethod (c$, "onFinishInflate", 
function () {
Clazz.superCall (this, android.widget.ListView, "onFinishInflate", []);
var count = this.getChildCount ();
if (count > 0) {
this.removeAllViews ();
}});
Clazz.defineMethod (c$, "findViewTraversal", 
function (id) {
var v;
v = Clazz.superCall (this, android.widget.ListView, "findViewTraversal", [id]);
if (v == null) {
v = this.findViewInHeadersOrFooters (this.mHeaderViewInfos, id);
if (v != null) {
return v;
}v = this.findViewInHeadersOrFooters (this.mFooterViewInfos, id);
if (v != null) {
return v;
}}return v;
}, "~N");
Clazz.defineMethod (c$, "findViewInHeadersOrFooters", 
function (where, id) {
if (where != null) {
var len = where.size ();
var v;
for (var i = 0; i < len; i++) {
v = where.get (i).view;
if (!v.isRootNamespace ()) {
v = v.findViewById (id);
if (v != null) {
return v;
}}}
}return null;
}, "java.util.ArrayList,~N");
Clazz.defineMethod (c$, "findViewWithTagTraversal", 
function (tag) {
var v;
v = Clazz.superCall (this, android.widget.ListView, "findViewWithTagTraversal", [tag]);
if (v == null) {
v = this.findViewTagInHeadersOrFooters (this.mHeaderViewInfos, tag);
if (v != null) {
return v;
}v = this.findViewTagInHeadersOrFooters (this.mFooterViewInfos, tag);
if (v != null) {
return v;
}}return v;
}, "~O");
Clazz.defineMethod (c$, "findViewTagInHeadersOrFooters", 
function (where, tag) {
if (where != null) {
var len = where.size ();
var v;
for (var i = 0; i < len; i++) {
v = where.get (i).view;
if (!v.isRootNamespace ()) {
v = v.findViewWithTag (tag);
if (v != null) {
return v;
}}}
}return null;
}, "java.util.ArrayList,~O");
Clazz.defineMethod (c$, "onTouchEvent", 
function (ev) {
if (this.mItemsCanFocus && ev.getAction () == 0 && ev.getEdgeFlags () != 0) {
return false;
}return Clazz.superCall (this, android.widget.ListView, "onTouchEvent", [ev]);
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "getChoiceMode", 
function () {
return this.mChoiceMode;
});
Clazz.defineMethod (c$, "setChoiceMode", 
function (choiceMode) {
this.mChoiceMode = choiceMode;
if (this.mChoiceMode != 0) {
if (this.mCheckStates == null) {
this.mCheckStates =  new android.util.SparseBooleanArray ();
}if (this.mCheckedIdStates == null && this.mAdapter != null && this.mAdapter.hasStableIds ()) {
this.mCheckedIdStates =  new android.util.LongSparseArray ();
}}}, "~N");
Clazz.defineMethod (c$, "setItemChecked", 
function (position, value) {
if (this.mChoiceMode == 0) {
return ;
}if (this.mChoiceMode == 2) {
this.mCheckStates.put (position, value);
if (this.mCheckedIdStates != null && this.mAdapter.hasStableIds ()) {
if (value) {
this.mCheckedIdStates.put (this.mAdapter.getItemId (position), Boolean.TRUE);
} else {
this.mCheckedIdStates.$delete (this.mAdapter.getItemId (position));
}}} else {
var updateIds = this.mCheckedIdStates != null && this.mAdapter.hasStableIds ();
if (value || this.isItemChecked (position)) {
this.mCheckStates.clear ();
if (updateIds) {
this.mCheckedIdStates.clear ();
}}if (value) {
this.mCheckStates.put (position, true);
if (updateIds) {
this.mCheckedIdStates.put (this.mAdapter.getItemId (position), Boolean.TRUE);
}}}if (!this.mInLayout && !this.mBlockLayoutRequests) {
this.mDataChanged = true;
this.rememberSyncState ();
this.requestLayout ();
}}, "~N,~B");
Clazz.defineMethod (c$, "isItemChecked", 
function (position) {
if (this.mChoiceMode != 0 && this.mCheckStates != null) {
return this.mCheckStates.get (position);
}return false;
}, "~N");
Clazz.defineMethod (c$, "getCheckedItemPosition", 
function () {
if (this.mChoiceMode == 1 && this.mCheckStates != null && this.mCheckStates.size () == 1) {
return this.mCheckStates.keyAt (0);
}return -1;
});
Clazz.defineMethod (c$, "getCheckedItemPositions", 
function () {
if (this.mChoiceMode != 0) {
return this.mCheckStates;
}return null;
});
Clazz.defineMethod (c$, "getCheckItemIds", 
function () {
if (this.mAdapter != null && this.mAdapter.hasStableIds ()) {
return this.getCheckedItemIds ();
}if (this.mChoiceMode != 0 && this.mCheckStates != null && this.mAdapter != null) {
var states = this.mCheckStates;
var count = states.size ();
var ids =  Clazz.newArray (count, 0);
var adapter = this.mAdapter;
var checkedCount = 0;
for (var i = 0; i < count; i++) {
if (states.valueAt (i)) {
ids[checkedCount++] = adapter.getItemId (states.keyAt (i));
}}
if (checkedCount == count) {
return ids;
} else {
var result =  Clazz.newArray (checkedCount, 0);
System.arraycopy (ids, 0, result, 0, checkedCount);
return result;
}}return  Clazz.newArray (0, 0);
});
Clazz.defineMethod (c$, "getCheckedItemIds", 
function () {
if (this.mChoiceMode == 0 || this.mCheckedIdStates == null || this.mAdapter == null) {
return  Clazz.newArray (0, 0);
}var idStates = this.mCheckedIdStates;
var count = idStates.size ();
var ids =  Clazz.newArray (count, 0);
for (var i = 0; i < count; i++) {
ids[i] = idStates.keyAt (i);
}
return ids;
});
Clazz.defineMethod (c$, "clearChoices", 
function () {
if (this.mCheckStates != null) {
this.mCheckStates.clear ();
}if (this.mCheckedIdStates != null) {
this.mCheckedIdStates.clear ();
}});
Clazz.defineMethod (c$, "focusSearch", 
function (v, direction) {
return null;
}, "android.view.View,~N");
Clazz.overrideMethod (c$, "childDrawableStateChanged", 
function (child) {
}, "android.view.View");
Clazz.defineMethod (c$, "canAnimate", 
function () {
return Clazz.superCall (this, android.widget.ListView, "canAnimate", []) && this.mItemCount > 0;
});
Clazz.defineMethod (c$, "getMaxScrollAmount", 
function () {
return Math.round ((0.33 * (this.mBottom - this.mTop)));
});
Clazz.defineMethod (c$, "addFooterView", 
function (v, data, isSelectable) {
var info = Clazz.innerTypeInstance (android.widget.ListView.FixedViewInfo, this, null);
info.view = v;
info.data = data;
info.isSelectable = isSelectable;
this.mFooterViewInfos.add (info);
if (this.mDataSetObserver != null) {
this.mDataSetObserver.onChanged ();
}}, "android.view.View,~O,~B");
Clazz.defineMethod (c$, "addFooterView", 
function (v) {
this.addFooterView (v, null, true);
}, "android.view.View");
Clazz.overrideMethod (c$, "getFooterViewsCount", 
function () {
return this.mFooterViewInfos.size ();
});
Clazz.defineMethod (c$, "addHeaderView", 
function (v, data, isSelectable) {
if (this.mAdapter != null) {
throw  new IllegalStateException ("Cannot add header view to list -- setAdapter has already been called.");
}var info = Clazz.innerTypeInstance (android.widget.ListView.FixedViewInfo, this, null);
info.view = v;
info.data = data;
info.isSelectable = isSelectable;
this.mHeaderViewInfos.add (info);
}, "android.view.View,~O,~B");
Clazz.defineMethod (c$, "addHeaderView", 
function (v) {
this.addHeaderView (v, null, true);
}, "android.view.View");
Clazz.overrideMethod (c$, "getHeaderViewsCount", 
function () {
return this.mHeaderViewInfos.size ();
});
Clazz.defineMethod (c$, "removeFooterView", 
function (v) {
if (this.mFooterViewInfos.size () > 0) {
var result = false;
if ((this.mAdapter).removeFooter (v)) {
this.mDataSetObserver.onChanged ();
result = true;
}this.removeFixedViewInfo (v, this.mFooterViewInfos);
return result;
}return false;
}, "android.view.View");
Clazz.defineMethod (c$, "removeFixedViewInfo", 
($fz = function (v, where) {
var len = where.size ();
for (var i = 0; i < len; ++i) {
var info = where.get (i);
if (info.view === v) {
where.remove (i);
break;
}}
}, $fz.isPrivate = true, $fz), "android.view.View,java.util.ArrayList");
Clazz.defineMethod (c$, "setSelectionAfterHeaderView", 
function () {
var count = this.mHeaderViewInfos.size ();
if (count > 0) {
this.mNextSelectedPosition = 0;
return ;
}if (this.mAdapter != null) {
this.setSelection (count);
} else {
this.mNextSelectedPosition = count;
this.mLayoutMode = 2;
}});
c$.$ListView$FixedViewInfo$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.view = null;
this.data = null;
this.isSelectable = false;
Clazz.instantialize (this, arguments);
}, android.widget.ListView, "FixedViewInfo");
c$ = Clazz.p0p ();
};
c$.$ListView$FocusSelector$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mPosition = 0;
this.mPositionTop = 0;
Clazz.instantialize (this, arguments);
}, android.widget.ListView, "FocusSelector", null, Runnable);
Clazz.defineMethod (c$, "setup", 
function (a, b) {
this.mPosition = a;
this.mPositionTop = b;
return this;
}, "~N,~N");
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["android.widget.ListView"].setSelectionFromTop (this.mPosition, this.mPositionTop);
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mSelectedPosition = 0;
this.mAmountToScroll = 0;
Clazz.instantialize (this, arguments);
}, android.widget.ListView, "ArrowScrollFocusResult");
Clazz.defineMethod (c$, "populate", 
function (a, b) {
this.mSelectedPosition = a;
this.mAmountToScroll = b;
}, "~N,~N");
Clazz.defineMethod (c$, "getSelectedPosition", 
function () {
return this.mSelectedPosition;
});
Clazz.defineMethod (c$, "getAmountToScroll", 
function () {
return this.mAmountToScroll;
});
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"NO_POSITION", -1,
"CHOICE_MODE_NONE", 0,
"CHOICE_MODE_SINGLE", 1,
"CHOICE_MODE_MULTIPLE", 2,
"MAX_SCROLL_FACTOR", 0.33,
"MIN_SCROLL_PREVIEW_PIXELS", 2);
});
