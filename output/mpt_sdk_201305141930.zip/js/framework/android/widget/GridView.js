﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.AbsListView", "android.graphics.Rect"], "android.widget.GridView", ["android.view.View", "$.ViewGroup", "android.widget.AdapterView", "com.android.internal.R", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mNumColumns = -1;
this.mHorizontalSpacing = 0;
this.mRequestedHorizontalSpacing = 0;
this.mVerticalSpacing = 0;
this.mStretchMode = 2;
this.mColumnWidth = 0;
this.mRequestedColumnWidth = 0;
this.mRequestedNumColumns = 0;
this.mReferenceView = null;
this.mReferenceViewInSelectedRow = null;
this.mGravity = 3;
this.$mTempRect = null;
Clazz.instantialize (this, arguments);
}, android.widget, "GridView", android.widget.AbsListView);
Clazz.prepareFields (c$, function () {
this.$mTempRect =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842865);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.GridView, [context, attrs, defStyle]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.GridView, defStyle, 0);
var hSpacing = a.getDimensionPixelOffset (1, 0);
this.setHorizontalSpacing (hSpacing);
var vSpacing = a.getDimensionPixelOffset (2, 0);
this.setVerticalSpacing (vSpacing);
var index = a.getInt (3, 2);
if (index >= 0) {
this.setStretchMode (index);
}var columnWidth = a.getDimensionPixelOffset (4, -1);
if (columnWidth > 0) {
this.setColumnWidth (columnWidth);
}var numColumns = a.getInt (5, 1);
this.setNumColumns (numColumns);
index = a.getInt (0, -1);
if (index >= 0) {
this.setGravity (index);
}a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.overrideMethod (c$, "getAdapter", 
function () {
return this.mAdapter;
});
Clazz.overrideMethod (c$, "setAdapter", 
function (adapter) {
if (null != this.mAdapter) {
this.mAdapter.unregisterDataSetObserver (this.mDataSetObserver);
}this.resetList ();
this.mAdapter = adapter;
this.mOldSelectedPosition = -1;
this.mOldSelectedRowId = -9223372036854775808;
if (this.mAdapter != null) {
this.mOldItemCount = this.mItemCount;
this.mItemCount = this.mAdapter.getCount ();
this.mDataChanged = true;
this.checkFocus ();
this.mDataSetObserver = Clazz.innerTypeInstance (android.widget.AdapterView.AdapterDataSetObserver, this, null);
this.mAdapter.registerDataSetObserver (this.mDataSetObserver);
var position;
if (this.mStackFromBottom) {
position = this.lookForSelectablePosition (this.mItemCount - 1, false);
} else {
position = this.lookForSelectablePosition (0, true);
}this.setSelectedPositionInt (position);
this.setNextSelectedPositionInt (position);
this.checkSelectionChanged ();
} else {
this.checkFocus ();
this.checkSelectionChanged ();
}this.requestLayout ();
}, "android.widget.ListAdapter");
Clazz.overrideMethod (c$, "lookForSelectablePosition", 
function (position, lookDown) {
var adapter = this.mAdapter;
if (adapter == null || this.isInTouchMode ()) {
return -1;
}if (position < 0 || position >= this.mItemCount) {
return -1;
}return position;
}, "~N,~B");
Clazz.overrideMethod (c$, "fillGap", 
function (down) {
var numColumns = this.mNumColumns;
var verticalSpacing = this.mVerticalSpacing;
var count = this.getChildCount ();
if (down) {
var startOffset = count > 0 ? this.getChildAt (count - 1).getBottom () + verticalSpacing : this.getListPaddingTop ();
var position = this.mFirstPosition + count;
if (this.mStackFromBottom) {
position += numColumns - 1;
}this.fillDown (position, startOffset);
this.correctTooHigh (numColumns, verticalSpacing, this.getChildCount ());
} else {
var startOffset = count > 0 ? this.getChildAt (0).getTop () - verticalSpacing : this.getHeight () - this.getListPaddingBottom ();
var position = this.mFirstPosition;
if (!this.mStackFromBottom) {
position -= numColumns;
} else {
position--;
}this.fillUp (position, startOffset);
this.correctTooLow (numColumns, verticalSpacing, this.getChildCount ());
}}, "~B");
Clazz.defineMethod (c$, "fillDown", 
($fz = function (pos, nextTop) {
var selectedView = null;
var end = (this.mBottom - this.mTop) - this.mListPadding.bottom;
while (nextTop < end && pos < this.mItemCount) {
var temp = this.makeRow (pos, nextTop, true);
if (temp != null) {
selectedView = temp;
}nextTop = this.mReferenceView.getBottom () + this.mVerticalSpacing;
pos += this.mNumColumns;
}
return selectedView;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "makeRow", 
($fz = function (startPos, y, flow) {
var columnWidth = this.mColumnWidth;
var horizontalSpacing = this.mHorizontalSpacing;
var last;
var nextLeft = this.mListPadding.left + ((this.mStretchMode == 3) ? horizontalSpacing : 0);
if (!this.mStackFromBottom) {
last = Math.min (startPos + this.mNumColumns, this.mItemCount);
} else {
last = startPos + 1;
startPos = Math.max (0, startPos - this.mNumColumns + 1);
if (last - startPos < this.mNumColumns) {
nextLeft += (this.mNumColumns - (last - startPos)) * (columnWidth + horizontalSpacing);
}}var selectedView = null;
var hasFocus = false;
var inClick = false;
var selectedPosition = this.mSelectedPosition;
var child = null;
for (var pos = startPos; pos < last; pos++) {
var selected = pos == selectedPosition;
var where = flow ? -1 : pos - startPos;
child = this.makeAndAddView (pos, y, flow, nextLeft, selected, where);
nextLeft += columnWidth;
if (pos < last - 1) {
nextLeft += horizontalSpacing;
}if (selected && (false)) {
selectedView = child;
}}
this.mReferenceView = child;
if (selectedView != null) {
this.mReferenceViewInSelectedRow = this.mReferenceView;
}return selectedView;
}, $fz.isPrivate = true, $fz), "~N,~N,~B");
Clazz.defineMethod (c$, "fillUp", 
($fz = function (pos, nextBottom) {
var selectedView = null;
var end = this.mListPadding.top;
while (nextBottom > end && pos >= 0) {
var temp = this.makeRow (pos, nextBottom, false);
if (temp != null) {
selectedView = temp;
}nextBottom = this.mReferenceView.getTop () - this.mVerticalSpacing;
this.mFirstPosition = pos;
pos -= this.mNumColumns;
}
if (this.mStackFromBottom) {
this.mFirstPosition = Math.max (0, pos + 1);
}return selectedView;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "fillFromTop", 
($fz = function (nextTop) {
this.mFirstPosition = Math.min (this.mFirstPosition, this.mSelectedPosition);
this.mFirstPosition = Math.min (this.mFirstPosition, this.mItemCount - 1);
if (this.mFirstPosition < 0) {
this.mFirstPosition = 0;
}this.mFirstPosition -= this.mFirstPosition % this.mNumColumns;
return this.fillDown (this.mFirstPosition, nextTop);
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "fillFromBottom", 
($fz = function (lastPosition, nextBottom) {
lastPosition = Math.max (lastPosition, this.mSelectedPosition);
lastPosition = Math.min (lastPosition, this.mItemCount - 1);
var invertedPosition = this.mItemCount - 1 - lastPosition;
lastPosition = this.mItemCount - 1 - (invertedPosition - (invertedPosition % this.mNumColumns));
return this.fillUp (lastPosition, nextBottom);
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "fillSelection", 
($fz = function (childrenTop, childrenBottom) {
var selectedPosition = this.reconcileSelectedPosition ();
var numColumns = this.mNumColumns;
var verticalSpacing = this.mVerticalSpacing;
var rowStart;
var rowEnd = -1;
if (!this.mStackFromBottom) {
rowStart = selectedPosition - (selectedPosition % numColumns);
} else {
var invertedSelection = this.mItemCount - 1 - selectedPosition;
rowEnd = this.mItemCount - 1 - (invertedSelection - (invertedSelection % numColumns));
rowStart = Math.max (0, rowEnd - numColumns + 1);
}var fadingEdgeLength = this.getVerticalFadingEdgeLength ();
var topSelectionPixel = this.getTopSelectionPixel (childrenTop, fadingEdgeLength, rowStart);
var sel = this.makeRow (this.mStackFromBottom ? rowEnd : rowStart, topSelectionPixel, true);
this.mFirstPosition = rowStart;
var referenceView = this.mReferenceView;
if (!this.mStackFromBottom) {
this.fillDown (rowStart + numColumns, referenceView.getBottom () + verticalSpacing);
this.pinToBottom (childrenBottom);
this.fillUp (rowStart - numColumns, referenceView.getTop () - verticalSpacing);
this.adjustViewsUpOrDown ();
} else {
var bottomSelectionPixel = this.getBottomSelectionPixel (childrenBottom, fadingEdgeLength, numColumns, rowStart);
var offset = bottomSelectionPixel - referenceView.getBottom ();
this.offsetChildrenTopAndBottom (offset);
this.fillUp (rowStart - 1, referenceView.getTop () - verticalSpacing);
this.pinToTop (childrenTop);
this.fillDown (rowEnd + numColumns, referenceView.getBottom () + verticalSpacing);
this.adjustViewsUpOrDown ();
}return sel;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "pinToTop", 
($fz = function (childrenTop) {
if (this.mFirstPosition == 0) {
var top = this.getChildAt (0).getTop ();
var offset = childrenTop - top;
if (offset < 0) {
this.offsetChildrenTopAndBottom (offset);
}}}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "pinToBottom", 
($fz = function (childrenBottom) {
var count = this.getChildCount ();
if (this.mFirstPosition + count == this.mItemCount) {
var bottom = this.getChildAt (count - 1).getBottom ();
var offset = childrenBottom - bottom;
if (offset > 0) {
this.offsetChildrenTopAndBottom (offset);
}}}, $fz.isPrivate = true, $fz), "~N");
Clazz.overrideMethod (c$, "findMotionRow", 
function (y) {
var childCount = this.getChildCount ();
if (childCount > 0) {
var numColumns = this.mNumColumns;
if (!this.mStackFromBottom) {
for (var i = 0; i < childCount; i += numColumns) {
if (y <= this.getChildAt (i).getBottom ()) {
return this.mFirstPosition + i;
}}
} else {
for (var i = childCount - 1; i >= 0; i -= numColumns) {
if (y >= this.getChildAt (i).getTop ()) {
return this.mFirstPosition + i;
}}
}}return -1;
}, "~N");
Clazz.defineMethod (c$, "fillSpecific", 
($fz = function (position, top) {
var numColumns = this.mNumColumns;
var motionRowStart;
var motionRowEnd = -1;
if (!this.mStackFromBottom) {
motionRowStart = position - (position % numColumns);
} else {
var invertedSelection = this.mItemCount - 1 - position;
motionRowEnd = this.mItemCount - 1 - (invertedSelection - (invertedSelection % numColumns));
motionRowStart = Math.max (0, motionRowEnd - numColumns + 1);
}var temp = this.makeRow (this.mStackFromBottom ? motionRowEnd : motionRowStart, top, true);
this.mFirstPosition = motionRowStart;
var referenceView = this.mReferenceView;
if (referenceView == null) {
return null;
}var verticalSpacing = this.mVerticalSpacing;
var above;
var below;
if (!this.mStackFromBottom) {
above = this.fillUp (motionRowStart - numColumns, referenceView.getTop () - verticalSpacing);
this.adjustViewsUpOrDown ();
below = this.fillDown (motionRowStart + numColumns, referenceView.getBottom () + verticalSpacing);
var childCount = this.getChildCount ();
if (childCount > 0) {
this.correctTooHigh (numColumns, verticalSpacing, childCount);
}} else {
below = this.fillDown (motionRowEnd + numColumns, referenceView.getBottom () + verticalSpacing);
this.adjustViewsUpOrDown ();
above = this.fillUp (motionRowStart - 1, referenceView.getTop () - verticalSpacing);
var childCount = this.getChildCount ();
if (childCount > 0) {
this.correctTooLow (numColumns, verticalSpacing, childCount);
}}if (temp != null) {
return temp;
} else if (above != null) {
return above;
} else {
return below;
}}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "correctTooHigh", 
($fz = function (numColumns, verticalSpacing, childCount) {
var lastPosition = this.mFirstPosition + childCount - 1;
if (lastPosition == this.mItemCount - 1 && childCount > 0) {
var lastChild = this.getChildAt (childCount - 1);
var lastBottom = lastChild.getBottom ();
var end = (this.mBottom - this.mTop) - this.mListPadding.bottom;
var bottomOffset = end - lastBottom;
var firstChild = this.getChildAt (0);
var firstTop = firstChild.getTop ();
if (bottomOffset > 0 && (this.mFirstPosition > 0 || firstTop < this.mListPadding.top)) {
if (this.mFirstPosition == 0) {
bottomOffset = Math.min (bottomOffset, this.mListPadding.top - firstTop);
}this.offsetChildrenTopAndBottom (bottomOffset);
if (this.mFirstPosition > 0) {
this.fillUp (this.mFirstPosition - (this.mStackFromBottom ? 1 : numColumns), firstChild.getTop () - verticalSpacing);
this.adjustViewsUpOrDown ();
}}}}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "correctTooLow", 
($fz = function (numColumns, verticalSpacing, childCount) {
if (this.mFirstPosition == 0 && childCount > 0) {
var firstChild = this.getChildAt (0);
var firstTop = firstChild.getTop ();
var start = this.mListPadding.top;
var end = (this.mBottom - this.mTop) - this.mListPadding.bottom;
var topOffset = firstTop - start;
var lastChild = this.getChildAt (childCount - 1);
var lastBottom = lastChild.getBottom ();
var lastPosition = this.mFirstPosition + childCount - 1;
if (topOffset > 0 && (lastPosition < this.mItemCount - 1 || lastBottom > end)) {
if (lastPosition == this.mItemCount - 1) {
topOffset = Math.min (topOffset, lastBottom - end);
}this.offsetChildrenTopAndBottom (-topOffset);
if (lastPosition < this.mItemCount - 1) {
this.fillDown (lastPosition + (!this.mStackFromBottom ? 1 : numColumns), lastChild.getBottom () + verticalSpacing);
this.adjustViewsUpOrDown ();
}}}}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "fillFromSelection", 
($fz = function (selectedTop, childrenTop, childrenBottom) {
var fadingEdgeLength = this.getVerticalFadingEdgeLength ();
var selectedPosition = this.mSelectedPosition;
var numColumns = this.mNumColumns;
var verticalSpacing = this.mVerticalSpacing;
var rowStart;
var rowEnd = -1;
if (!this.mStackFromBottom) {
rowStart = selectedPosition - (selectedPosition % numColumns);
} else {
var invertedSelection = this.mItemCount - 1 - selectedPosition;
rowEnd = this.mItemCount - 1 - (invertedSelection - (invertedSelection % numColumns));
rowStart = Math.max (0, rowEnd - numColumns + 1);
}var sel;
var referenceView;
var topSelectionPixel = this.getTopSelectionPixel (childrenTop, fadingEdgeLength, rowStart);
var bottomSelectionPixel = this.getBottomSelectionPixel (childrenBottom, fadingEdgeLength, numColumns, rowStart);
sel = this.makeRow (this.mStackFromBottom ? rowEnd : rowStart, selectedTop, true);
this.mFirstPosition = rowStart;
referenceView = this.mReferenceView;
this.adjustForTopFadingEdge (referenceView, topSelectionPixel, bottomSelectionPixel);
this.adjustForBottomFadingEdge (referenceView, topSelectionPixel, bottomSelectionPixel);
if (!this.mStackFromBottom) {
this.fillUp (rowStart - numColumns, referenceView.getTop () - verticalSpacing);
this.adjustViewsUpOrDown ();
this.fillDown (rowStart + numColumns, referenceView.getBottom () + verticalSpacing);
} else {
this.fillDown (rowEnd + numColumns, referenceView.getBottom () + verticalSpacing);
this.adjustViewsUpOrDown ();
this.fillUp (rowStart - 1, referenceView.getTop () - verticalSpacing);
}return sel;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "getBottomSelectionPixel", 
($fz = function (childrenBottom, fadingEdgeLength, numColumns, rowStart) {
var bottomSelectionPixel = childrenBottom;
if (rowStart + numColumns - 1 < this.mItemCount - 1) {
bottomSelectionPixel -= fadingEdgeLength;
}return bottomSelectionPixel;
}, $fz.isPrivate = true, $fz), "~N,~N,~N,~N");
Clazz.defineMethod (c$, "getTopSelectionPixel", 
($fz = function (childrenTop, fadingEdgeLength, rowStart) {
var topSelectionPixel = childrenTop;
if (rowStart > 0) {
topSelectionPixel += fadingEdgeLength;
}return topSelectionPixel;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "adjustForBottomFadingEdge", 
($fz = function (childInSelectedRow, topSelectionPixel, bottomSelectionPixel) {
if (childInSelectedRow.getBottom () > bottomSelectionPixel) {
var spaceAbove = childInSelectedRow.getTop () - topSelectionPixel;
var spaceBelow = childInSelectedRow.getBottom () - bottomSelectionPixel;
var offset = Math.min (spaceAbove, spaceBelow);
this.offsetChildrenTopAndBottom (-offset);
}}, $fz.isPrivate = true, $fz), "android.view.View,~N,~N");
Clazz.defineMethod (c$, "adjustForTopFadingEdge", 
($fz = function (childInSelectedRow, topSelectionPixel, bottomSelectionPixel) {
if (childInSelectedRow.getTop () < topSelectionPixel) {
var spaceAbove = topSelectionPixel - childInSelectedRow.getTop ();
var spaceBelow = bottomSelectionPixel - childInSelectedRow.getBottom ();
var offset = Math.min (spaceAbove, spaceBelow);
this.offsetChildrenTopAndBottom (offset);
}}, $fz.isPrivate = true, $fz), "android.view.View,~N,~N");
Clazz.defineMethod (c$, "moveSelection", 
($fz = function (delta, childrenTop, childrenBottom) {
var fadingEdgeLength = this.getVerticalFadingEdgeLength ();
var selectedPosition = this.mSelectedPosition;
var numColumns = this.mNumColumns;
var verticalSpacing = this.mVerticalSpacing;
var oldRowStart;
var rowStart;
var rowEnd = -1;
if (!this.mStackFromBottom) {
oldRowStart = (selectedPosition - delta) - ((selectedPosition - delta) % numColumns);
rowStart = selectedPosition - (selectedPosition % numColumns);
} else {
var invertedSelection = this.mItemCount - 1 - selectedPosition;
rowEnd = this.mItemCount - 1 - (invertedSelection - (invertedSelection % numColumns));
rowStart = Math.max (0, rowEnd - numColumns + 1);
invertedSelection = this.mItemCount - 1 - (selectedPosition - delta);
oldRowStart = this.mItemCount - 1 - (invertedSelection - (invertedSelection % numColumns));
oldRowStart = Math.max (0, oldRowStart - numColumns + 1);
}var rowDelta = rowStart - oldRowStart;
var topSelectionPixel = this.getTopSelectionPixel (childrenTop, fadingEdgeLength, rowStart);
var bottomSelectionPixel = this.getBottomSelectionPixel (childrenBottom, fadingEdgeLength, numColumns, rowStart);
this.mFirstPosition = rowStart;
var sel;
var referenceView;
if (rowDelta > 0) {
var oldBottom = this.mReferenceViewInSelectedRow == null ? 0 : this.mReferenceViewInSelectedRow.getBottom ();
sel = this.makeRow (this.mStackFromBottom ? rowEnd : rowStart, oldBottom + verticalSpacing, true);
referenceView = this.mReferenceView;
this.adjustForBottomFadingEdge (referenceView, topSelectionPixel, bottomSelectionPixel);
} else if (rowDelta < 0) {
var oldTop = this.mReferenceViewInSelectedRow == null ? 0 : this.mReferenceViewInSelectedRow.getTop ();
sel = this.makeRow (this.mStackFromBottom ? rowEnd : rowStart, oldTop - verticalSpacing, false);
referenceView = this.mReferenceView;
this.adjustForTopFadingEdge (referenceView, topSelectionPixel, bottomSelectionPixel);
} else {
var oldTop = this.mReferenceViewInSelectedRow == null ? 0 : this.mReferenceViewInSelectedRow.getTop ();
sel = this.makeRow (this.mStackFromBottom ? rowEnd : rowStart, oldTop, true);
referenceView = this.mReferenceView;
}if (!this.mStackFromBottom) {
this.fillUp (rowStart - numColumns, referenceView.getTop () - verticalSpacing);
this.adjustViewsUpOrDown ();
this.fillDown (rowStart + numColumns, referenceView.getBottom () + verticalSpacing);
} else {
this.fillDown (rowEnd + numColumns, referenceView.getBottom () + verticalSpacing);
this.adjustViewsUpOrDown ();
this.fillUp (rowStart - 1, referenceView.getTop () - verticalSpacing);
}return sel;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "determineColumns", 
($fz = function (availableSpace) {
var requestedHorizontalSpacing = this.mRequestedHorizontalSpacing;
var stretchMode = this.mStretchMode;
var requestedColumnWidth = this.mRequestedColumnWidth;
if (this.mRequestedNumColumns == -1) {
if (requestedColumnWidth > 0) {
this.mNumColumns = Math.floor ((availableSpace + requestedHorizontalSpacing) / (requestedColumnWidth + requestedHorizontalSpacing));
} else {
this.mNumColumns = 2;
}} else {
this.mNumColumns = this.mRequestedNumColumns;
}if (this.mNumColumns <= 0) {
this.mNumColumns = 1;
}switch (stretchMode) {
case 0:
this.mColumnWidth = requestedColumnWidth;
this.mHorizontalSpacing = requestedHorizontalSpacing;
break;
default:
var spaceLeftOver = availableSpace - (this.mNumColumns * requestedColumnWidth) - ((this.mNumColumns - 1) * requestedHorizontalSpacing);
switch (stretchMode) {
case 2:
this.mColumnWidth = requestedColumnWidth + Math.floor (spaceLeftOver / this.mNumColumns);
this.mHorizontalSpacing = requestedHorizontalSpacing;
break;
case 1:
this.mColumnWidth = requestedColumnWidth;
if (this.mNumColumns > 1) {
this.mHorizontalSpacing = requestedHorizontalSpacing + Math.floor (spaceLeftOver / (this.mNumColumns - 1));
} else {
this.mHorizontalSpacing = requestedHorizontalSpacing + spaceLeftOver;
}break;
case 3:
this.mColumnWidth = requestedColumnWidth;
if (this.mNumColumns > 1) {
this.mHorizontalSpacing = requestedHorizontalSpacing + Math.floor (spaceLeftOver / (this.mNumColumns + 1));
} else {
this.mHorizontalSpacing = requestedHorizontalSpacing + spaceLeftOver;
}break;
}
break;
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
Clazz.superCall (this, android.widget.GridView, "onMeasure", [widthMeasureSpec, heightMeasureSpec]);
var widthMode = android.view.View.MeasureSpec.getMode (widthMeasureSpec);
var heightMode = android.view.View.MeasureSpec.getMode (heightMeasureSpec);
var widthSize = android.view.View.MeasureSpec.getSize (widthMeasureSpec);
var heightSize = android.view.View.MeasureSpec.getSize (heightMeasureSpec);
if (widthMode == 0) {
if (this.mColumnWidth > 0) {
widthSize = this.mColumnWidth + this.mListPadding.left + this.mListPadding.right;
} else {
widthSize = this.mListPadding.left + this.mListPadding.right;
}widthSize += this.getVerticalScrollbarWidth ();
}var childWidth = widthSize - this.mListPadding.left - this.mListPadding.right;
this.determineColumns (childWidth);
var childHeight = 0;
this.mItemCount = this.mAdapter == null ? 0 : this.mAdapter.getCount ();
var count = this.mItemCount;
if (count > 0) {
var child = this.obtainView (0);
var p = child.getLayoutParams ();
if (p == null) {
p =  new android.widget.AbsListView.LayoutParams (-1, -2, 0);
child.setLayoutParams (p);
}p.viewType = this.mAdapter.getItemViewType (0);
p.forceAdd = true;
var childHeightSpec = android.view.ViewGroup.getChildMeasureSpec (android.view.View.MeasureSpec.makeMeasureSpec (0, 0), 0, p.height);
var childWidthSpec = android.view.ViewGroup.getChildMeasureSpec (android.view.View.MeasureSpec.makeMeasureSpec (this.mColumnWidth, 1073741824), 0, p.width);
child.measure (childWidthSpec, childHeightSpec);
childHeight = child.getMeasuredHeight ();
}if (heightMode == 0) {
heightSize = this.mListPadding.top + this.mListPadding.bottom + childHeight + this.getVerticalFadingEdgeLength () * 2;
}if (heightMode == -2147483648) {
var ourSize = this.mListPadding.top + this.mListPadding.bottom;
var numColumns = this.mNumColumns;
for (var i = 0; i < count; i += numColumns) {
ourSize += childHeight;
if (i + numColumns < count) {
ourSize += this.mVerticalSpacing;
}if (ourSize >= heightSize) {
ourSize = heightSize;
break;
}}
heightSize = ourSize;
}this.setMeasuredDimension (widthSize, heightSize);
this.mWidthMeasureSpec = widthMeasureSpec;
}, "~N,~N");
Clazz.defineMethod (c$, "layoutChildren", 
function () {
var blockLayoutRequests = this.mBlockLayoutRequests;
if (!blockLayoutRequests) {
this.mBlockLayoutRequests = true;
}try {
Clazz.superCall (this, android.widget.GridView, "layoutChildren", []);
this.invalidate ();
if (this.mAdapter == null) {
this.resetList ();
this.invokeOnItemScrollListener ();
return ;
}var childrenTop = this.mListPadding.top;
var childrenBottom = this.mBottom - this.mTop - this.mListPadding.bottom;
var childCount = this.getChildCount ();
var index;
var delta = 0;
var sel;
var oldSel = null;
var oldFirst = null;
var newSel = null;
switch (this.mLayoutMode) {
case 2:
index = this.mNextSelectedPosition - this.mFirstPosition;
if (index >= 0 && index < childCount) {
newSel = this.getChildAt (index);
}break;
case 1:
case 3:
case 4:
case 5:
break;
case 6:
if (this.mNextSelectedPosition >= 0) {
delta = this.mNextSelectedPosition - this.mSelectedPosition;
}break;
default:
index = this.mSelectedPosition - this.mFirstPosition;
if (index >= 0 && index < childCount) {
oldSel = this.getChildAt (index);
}oldFirst = this.getChildAt (0);
}
var dataChanged = this.mDataChanged;
if (dataChanged) {
this.handleDataChanged ();
}if (this.mItemCount == 0) {
this.resetList ();
this.invokeOnItemScrollListener ();
return ;
}this.setSelectedPositionInt (this.mNextSelectedPosition);
this.detachAllViewsFromParent ();
switch (this.mLayoutMode) {
case 2:
if (newSel != null) {
sel = this.fillFromSelection (newSel.getTop (), childrenTop, childrenBottom);
} else {
sel = this.fillSelection (childrenTop, childrenBottom);
}break;
case 1:
this.mFirstPosition = 0;
sel = this.fillFromTop (childrenTop);
this.adjustViewsUpOrDown ();
break;
case 3:
sel = this.fillUp (this.mItemCount - 1, childrenBottom);
this.adjustViewsUpOrDown ();
break;
case 4:
sel = this.fillSpecific (this.mSelectedPosition, this.mSpecificTop);
break;
case 5:
sel = this.fillSpecific (this.mSyncPosition, this.mSpecificTop);
break;
case 6:
sel = this.moveSelection (delta, childrenTop, childrenBottom);
break;
default:
if (childCount == 0) {
if (!this.mStackFromBottom) {
this.setSelectedPositionInt (this.mAdapter == null || this.isInTouchMode () ? -1 : 0);
sel = this.fillFromTop (childrenTop);
} else {
var last = this.mItemCount - 1;
this.setSelectedPositionInt (this.mAdapter == null || this.isInTouchMode () ? -1 : last);
sel = this.fillFromBottom (last, childrenBottom);
}} else {
if (this.mSelectedPosition >= 0 && this.mSelectedPosition < this.mItemCount) {
sel = this.fillSpecific (this.mSelectedPosition, oldSel == null ? childrenTop : oldSel.getTop ());
} else if (this.mFirstPosition < this.mItemCount) {
sel = this.fillSpecific (this.mFirstPosition, oldFirst == null ? childrenTop : oldFirst.getTop ());
} else {
sel = this.fillSpecific (0, childrenTop);
}}break;
}
this.mLayoutMode = 0;
this.mDataChanged = false;
this.mNeedSync = false;
this.setNextSelectedPositionInt (this.mSelectedPosition);
if (this.mItemCount > 0) {
this.checkSelectionChanged ();
}this.invokeOnItemScrollListener ();
} finally {
if (!blockLayoutRequests) {
this.mBlockLayoutRequests = false;
}}
});
Clazz.defineMethod (c$, "makeAndAddView", 
($fz = function (position, y, flow, childrenLeft, selected, where) {
var child;
child = this.obtainView (position);
this.setupChild (child, position, y, flow, childrenLeft, selected, false, where);
return child;
}, $fz.isPrivate = true, $fz), "~N,~N,~B,~N,~B,~N");
Clazz.defineMethod (c$, "setupChild", 
($fz = function (child, position, y, flow, childrenLeft, selected, recycled, where) {
var isSelected = selected;
var updateChildSelected = isSelected != child.isSelected ();
var isPressed = false;
var updateChildPressed = false != child.isPressed ();
var needToMeasure = !recycled || updateChildSelected || child.isLayoutRequested ();
var p = child.getLayoutParams ();
if (p == null) {
p =  new android.widget.AbsListView.LayoutParams (-1, -2, 0);
}p.viewType = this.mAdapter.getItemViewType (position);
if (recycled && !p.forceAdd) {
this.attachViewToParent (child, where, p);
} else {
p.forceAdd = false;
this.addViewInLayout (child, where, p, true);
}if (updateChildSelected) {
child.setSelected (isSelected);
if (isSelected) {
this.requestFocus ();
}}if (updateChildPressed) {
child.setPressed (false);
}if (needToMeasure) {
var childHeightSpec = android.view.ViewGroup.getChildMeasureSpec (android.view.View.MeasureSpec.makeMeasureSpec (0, 0), 0, p.height);
var childWidthSpec = android.view.ViewGroup.getChildMeasureSpec (android.view.View.MeasureSpec.makeMeasureSpec (this.mColumnWidth, 1073741824), 0, p.width);
child.measure (childWidthSpec, childHeightSpec);
} else {
this.cleanupLayoutState (child);
}var w = child.getMeasuredWidth ();
var h = child.getMeasuredHeight ();
var childLeft;
var childTop = flow ? y : y - h;
switch (this.mGravity & 7) {
case 3:
childLeft = childrenLeft;
break;
case 1:
childLeft = childrenLeft + (Math.floor ((this.mColumnWidth - w) / 2));
break;
case 5:
childLeft = childrenLeft + this.mColumnWidth - w;
break;
default:
childLeft = childrenLeft;
break;
}
if (needToMeasure) {
var childRight = childLeft + w;
var childBottom = childTop + h;
child.layout (childLeft, childTop, childRight, childBottom);
} else {
child.offsetLeftAndRight (childLeft - child.getLeft ());
child.offsetTopAndBottom (childTop - child.getTop ());
}}, $fz.isPrivate = true, $fz), "android.view.View,~N,~N,~B,~N,~B,~B,~N");
Clazz.overrideMethod (c$, "setSelection", 
function (position) {
if (!this.isInTouchMode ()) {
this.setNextSelectedPositionInt (position);
} else {
this.mResurrectToPosition = position;
}this.mLayoutMode = 2;
this.requestLayout ();
}, "~N");
Clazz.overrideMethod (c$, "setSelectionInt", 
function (position) {
this.setNextSelectedPositionInt (position);
this.layoutChildren ();
}, "~N");
Clazz.defineMethod (c$, "onKeyDown", 
function (keyCode, event) {
return this.commonKey (keyCode, 1, event);
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyMultiple", 
function (keyCode, repeatCount, event) {
return this.commonKey (keyCode, repeatCount, event);
}, "~N,~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyUp", 
function (keyCode, event) {
return this.commonKey (keyCode, 1, event);
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "commonKey", 
($fz = function (keyCode, count, event) {
if (this.mAdapter == null) {
return false;
}if (this.mDataChanged) {
this.layoutChildren ();
}var handled = false;
var action = event.getAction ();
if (action != 1) {
if (this.mSelectedPosition < 0) {
switch (keyCode) {
case 38:
case 40:
case 37:
case 39:
case 23:
case 62:
case 13:
return true;
}
}switch (keyCode) {
case 37:
handled = this.arrowScroll (17);
break;
case 39:
handled = this.arrowScroll (66);
break;
case 38:
if (!event.isAltPressed ()) {
handled = this.arrowScroll (33);
} else {
handled = this.fullScroll (33);
}break;
case 40:
if (!event.isAltPressed ()) {
handled = this.arrowScroll (130);
} else {
handled = this.fullScroll (130);
}break;
case 23:
case 13:
{
if (this.getChildCount () > 0 && event.getRepeatCount () == 0) {
}return true;
}case 62:
break;
}
}if (handled) {
return true;
} else {
switch (action) {
case 0:
return Clazz.superCall (this, android.widget.GridView, "onKeyDown", [keyCode, event]);
case 1:
return Clazz.superCall (this, android.widget.GridView, "onKeyUp", [keyCode, event]);
case 2:
return Clazz.superCall (this, android.widget.GridView, "onKeyMultiple", [keyCode, count, event]);
default:
return false;
}
}}, $fz.isPrivate = true, $fz), "~N,~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "pageScroll", 
function (direction) {
var nextPage = -1;
if (direction == 33) {
nextPage = Math.max (0, this.mSelectedPosition - this.getChildCount () - 1);
} else if (direction == 130) {
nextPage = Math.min (this.mItemCount - 1, this.mSelectedPosition + this.getChildCount () - 1);
}if (nextPage >= 0) {
this.setSelectionInt (nextPage);
this.invokeOnItemScrollListener ();
return true;
}return false;
}, "~N");
Clazz.defineMethod (c$, "fullScroll", 
function (direction) {
var moved = false;
if (direction == 33) {
this.mLayoutMode = 2;
this.setSelectionInt (0);
this.invokeOnItemScrollListener ();
moved = true;
} else if (direction == 130) {
this.mLayoutMode = 2;
this.setSelectionInt (this.mItemCount - 1);
this.invokeOnItemScrollListener ();
moved = true;
}return moved;
}, "~N");
Clazz.defineMethod (c$, "arrowScroll", 
function (direction) {
var selectedPosition = this.mSelectedPosition;
var numColumns = this.mNumColumns;
var startOfRowPos;
var endOfRowPos;
var moved = false;
if (!this.mStackFromBottom) {
startOfRowPos = (Math.floor (selectedPosition / numColumns)) * numColumns;
endOfRowPos = Math.min (startOfRowPos + numColumns - 1, this.mItemCount - 1);
} else {
var invertedSelection = this.mItemCount - 1 - selectedPosition;
endOfRowPos = this.mItemCount - 1 - (Math.floor (invertedSelection / numColumns)) * numColumns;
startOfRowPos = Math.max (0, endOfRowPos - numColumns + 1);
}switch (direction) {
case 33:
if (startOfRowPos > 0) {
this.mLayoutMode = 6;
this.setSelectionInt (Math.max (0, selectedPosition - numColumns));
moved = true;
}break;
case 130:
if (endOfRowPos < this.mItemCount - 1) {
this.mLayoutMode = 6;
this.setSelectionInt (Math.min (selectedPosition + numColumns, this.mItemCount - 1));
moved = true;
}break;
case 17:
if (selectedPosition > startOfRowPos) {
this.mLayoutMode = 6;
this.setSelectionInt (Math.max (0, selectedPosition - 1));
moved = true;
}break;
case 66:
if (selectedPosition < endOfRowPos) {
this.mLayoutMode = 6;
this.setSelectionInt (Math.min (selectedPosition + 1, this.mItemCount - 1));
moved = true;
}break;
}
if (moved) {
this.invokeOnItemScrollListener ();
}return moved;
}, "~N");
Clazz.defineMethod (c$, "onFocusChanged", 
function (gainFocus, direction, previouslyFocusedRect) {
Clazz.superCall (this, android.widget.GridView, "onFocusChanged", [gainFocus, direction, previouslyFocusedRect]);
var closestChildIndex = -1;
if (gainFocus && previouslyFocusedRect != null) {
previouslyFocusedRect.offset (this.mScrollX, this.mScrollY);
var otherRect = this.$mTempRect;
var minDistance = 2147483647;
var childCount = this.getChildCount ();
for (var i = 0; i < childCount; i++) {
if (!this.isCandidateSelection (i, direction)) {
continue ;}var other = this.getChildAt (i);
other.getDrawingRect (otherRect);
this.offsetDescendantRectToMyCoords (other, otherRect);
var distance = android.widget.AbsListView.getDistance (previouslyFocusedRect, otherRect, direction);
if (distance < minDistance) {
minDistance = distance;
closestChildIndex = i;
}}
}if (closestChildIndex >= 0) {
this.setSelection (closestChildIndex + this.mFirstPosition);
} else {
this.requestLayout ();
}}, "~B,~N,android.graphics.Rect");
Clazz.defineMethod (c$, "isCandidateSelection", 
($fz = function (childIndex, direction) {
var count = this.getChildCount ();
var invertedIndex = count - 1 - childIndex;
var rowStart;
var rowEnd;
if (!this.mStackFromBottom) {
rowStart = childIndex - (childIndex % this.mNumColumns);
rowEnd = Math.max (rowStart + this.mNumColumns - 1, count);
} else {
rowEnd = count - 1 - (invertedIndex - (invertedIndex % this.mNumColumns));
rowStart = Math.max (0, rowEnd - this.mNumColumns + 1);
}switch (direction) {
case 66:
return childIndex == rowStart;
case 130:
return rowStart == 0;
case 17:
return childIndex == rowEnd;
case 33:
return rowEnd == count - 1;
default:
throw  new IllegalArgumentException ("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
}
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "setGravity", 
function (gravity) {
if (this.mGravity != gravity) {
this.mGravity = gravity;
this.requestLayoutIfNecessary ();
}}, "~N");
Clazz.defineMethod (c$, "setHorizontalSpacing", 
function (horizontalSpacing) {
if (horizontalSpacing != this.mRequestedHorizontalSpacing) {
this.mRequestedHorizontalSpacing = horizontalSpacing;
this.requestLayoutIfNecessary ();
}}, "~N");
Clazz.defineMethod (c$, "setVerticalSpacing", 
function (verticalSpacing) {
if (verticalSpacing != this.mVerticalSpacing) {
this.mVerticalSpacing = verticalSpacing;
this.requestLayoutIfNecessary ();
}}, "~N");
Clazz.defineMethod (c$, "setStretchMode", 
function (stretchMode) {
if (stretchMode != this.mStretchMode) {
this.mStretchMode = stretchMode;
this.requestLayoutIfNecessary ();
}}, "~N");
Clazz.defineMethod (c$, "getStretchMode", 
function () {
return this.mStretchMode;
});
Clazz.defineMethod (c$, "setColumnWidth", 
function (columnWidth) {
if (columnWidth != this.mRequestedColumnWidth) {
this.mRequestedColumnWidth = columnWidth;
this.requestLayoutIfNecessary ();
}}, "~N");
Clazz.defineMethod (c$, "setNumColumns", 
function (numColumns) {
if (numColumns != this.mRequestedNumColumns) {
this.mRequestedNumColumns = numColumns;
this.requestLayoutIfNecessary ();
}}, "~N");
Clazz.defineMethod (c$, "adjustViewsUpOrDown", 
($fz = function () {
var childCount = this.getChildCount ();
if (childCount > 0) {
var delta;
var child;
if (!this.mStackFromBottom) {
child = this.getChildAt (0);
delta = child.getTop () - this.mListPadding.top;
if (this.mFirstPosition != 0) {
delta -= this.mVerticalSpacing;
}if (delta < 0) {
delta = 0;
}} else {
child = this.getChildAt (childCount - 1);
delta = child.getBottom () - (this.getHeight () - this.mListPadding.bottom);
if (this.mFirstPosition + childCount < this.mItemCount) {
delta += this.mVerticalSpacing;
}if (delta > 0) {
delta = 0;
}}if (delta != 0) {
this.offsetChildrenTopAndBottom (-delta);
}}}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "computeVerticalScrollExtent", 
function () {
var count = this.getChildCount ();
if (count > 0) {
var numColumns = this.mNumColumns;
var rowCount = Math.floor ((count + numColumns - 1) / numColumns);
var extent = rowCount * 100;
var view = this.getChildAt (0);
var top = view.getTop ();
var height = view.getHeight ();
if (height > 0) {
extent += Math.floor ((top * 100) / height);
}view = this.getChildAt (count - 1);
var bottom = view.getBottom ();
height = view.getHeight ();
if (height > 0) {
extent -= Math.floor (((bottom - this.getHeight ()) * 100) / height);
}return extent;
}return 0;
});
Clazz.overrideMethod (c$, "computeVerticalScrollOffset", 
function () {
if (this.mFirstPosition >= 0 && this.getChildCount () > 0) {
var view = this.getChildAt (0);
var top = view.getTop ();
var height = view.getHeight ();
if (height > 0) {
var numColumns = this.mNumColumns;
var whichRow = Math.floor (this.mFirstPosition / numColumns);
var rowCount = Math.floor ((this.mItemCount + numColumns - 1) / numColumns);
return Math.max (whichRow * 100 - Math.floor ((top * 100) / height) + Math.round ((this.mScrollY / this.getHeight () * rowCount * 100)), 0);
}}return 0;
});
Clazz.overrideMethod (c$, "computeVerticalScrollRange", 
function () {
var numColumns = this.mNumColumns;
var rowCount = Math.floor ((this.mItemCount + numColumns - 1) / numColumns);
var result = Math.max (rowCount * 100, 0);
if (this.mScrollY != 0) {
result += Math.abs (Math.round ((this.mScrollY / this.getHeight () * rowCount * 100)));
}return result;
});
Clazz.defineMethod (c$, "focusSearch", 
function (v, direction) {
return null;
}, "android.view.View,~N");
Clazz.overrideMethod (c$, "childDrawableStateChanged", 
function (child) {
}, "android.view.View");
Clazz.defineMethod (c$, "addView", 
function (view, params) {
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineStatics (c$,
"NO_STRETCH", 0,
"STRETCH_SPACING", 1,
"STRETCH_COLUMN_WIDTH", 2,
"STRETCH_SPACING_UNIFORM", 3,
"AUTO_FIT", -1);
});
