﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.TextView"], "android.widget.Button", null, function () {
c$ = Clazz.declareType (android.widget, "Button", android.widget.TextView);
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842824);
}, "android.content.Context,android.util.AttributeSet");
});
