﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.CursorAdapter"], "android.widget.ResourceCursorAdapter", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mLayout = 0;
this.mDropDownLayout = 0;
this.mInflater = null;
Clazz.instantialize (this, arguments);
}, android.widget, "ResourceCursorAdapter", android.widget.CursorAdapter);
Clazz.makeConstructor (c$, 
function (context, layout, c) {
Clazz.superConstructor (this, android.widget.ResourceCursorAdapter, [context, c]);
this.mLayout = this.mDropDownLayout = layout;
this.mInflater = context.getSystemService ("layout_inflater");
}, "android.content.Context,~N,android.database.Cursor");
Clazz.makeConstructor (c$, 
function (context, layout, c, autoRequery) {
Clazz.superConstructor (this, android.widget.ResourceCursorAdapter, [context, c, autoRequery]);
this.mLayout = this.mDropDownLayout = layout;
this.mInflater = context.getSystemService ("layout_inflater");
}, "android.content.Context,~N,android.database.Cursor,~B");
Clazz.overrideMethod (c$, "newView", 
function (context, cursor, parent) {
return this.mInflater.inflate (this.mLayout, parent, false);
}, "android.content.Context,android.database.Cursor,android.view.ViewGroup");
Clazz.overrideMethod (c$, "newDropDownView", 
function (context, cursor, parent) {
return this.mInflater.inflate (this.mDropDownLayout, parent, false);
}, "android.content.Context,android.database.Cursor,android.view.ViewGroup");
Clazz.defineMethod (c$, "setViewResource", 
function (layout) {
this.mLayout = layout;
}, "~N");
Clazz.defineMethod (c$, "setDropDownViewResource", 
function (dropDownLayout) {
this.mDropDownLayout = dropDownLayout;
}, "~N");
});
