﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.FrameLayout", "android.graphics.Rect"], "android.widget.ScrollView", ["android.view.FocusFinder", "$.VelocityTracker", "$.View", "$.ViewConfiguration", "android.view.animation.AnimationUtils", "android.widget.EdgeGlow", "$.OverScroller", "com.android.internal.R", "java.lang.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mLastScroll = 0;
this.$mTempRect = null;
this.mScroller = null;
this.mEdgeGlowTop = null;
this.mEdgeGlowBottom = null;
this.mScrollViewMovedFocus = false;
this.mLastMotionY = 0;
this.mIsLayoutDirty = true;
this.mChildToScrollTo = null;
this.mIsBeingDragged = false;
this.mVelocityTracker = null;
this.mFillViewport = false;
this.mSmoothScrollingEnabled = true;
this.$mTouchSlop = 0;
this.mMinimumVelocity = 0;
this.mMaximumVelocity = 0;
this.mOverscrollDistance = 0;
this.mOverflingDistance = 0;
this.mActivePointerId = -1;
Clazz.instantialize (this, arguments);
}, android.widget, "ScrollView", android.widget.FrameLayout);
Clazz.prepareFields (c$, function () {
this.$mTempRect =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842880);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.ScrollView, [context, attrs, defStyle]);
this.initScrollView ();
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.ScrollView, defStyle, 0);
this.setFillViewport (a.getBoolean (0, false));
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.overrideMethod (c$, "getTopFadingEdgeStrength", 
function () {
if (this.getChildCount () == 0) {
return 0.0;
}var length = this.getVerticalFadingEdgeLength ();
if (this.mScrollY < length) {
return this.mScrollY / length;
}return 1.0;
});
Clazz.overrideMethod (c$, "getBottomFadingEdgeStrength", 
function () {
if (this.getChildCount () == 0) {
return 0.0;
}var length = this.getVerticalFadingEdgeLength ();
var bottomEdge = this.getHeight () - this.mPaddingBottom;
var span = this.getChildAt (0).getBottom () - this.mScrollY - bottomEdge;
if (span < length) {
return span / length;
}return 1.0;
});
Clazz.defineMethod (c$, "getMaxScrollAmount", 
function () {
return Math.round ((0.5 * (this.mBottom - this.mTop)));
});
Clazz.defineMethod (c$, "initScrollView", 
($fz = function () {
this.mScroller =  new android.widget.OverScroller (this.getContext ());
this.setFocusable (true);
this.setDescendantFocusability (262144);
this.setWillNotDraw (false);
var configuration = android.view.ViewConfiguration.get (this.mContext);
this.$mTouchSlop = configuration.getScaledTouchSlop ();
this.mMinimumVelocity = configuration.getScaledMinimumFlingVelocity ();
this.mMaximumVelocity = configuration.getScaledMaximumFlingVelocity ();
this.mOverscrollDistance = configuration.getScaledOverscrollDistance ();
this.mOverflingDistance = configuration.getScaledOverflingDistance ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "addView", 
function (child) {
if (this.getChildCount () > 0) {
throw  new IllegalStateException ("ScrollView can host only one direct child");
}Clazz.superCall (this, android.widget.ScrollView, "addView", [child]);
}, "android.view.View");
Clazz.defineMethod (c$, "addView", 
function (child, index) {
if (this.getChildCount () > 0) {
throw  new IllegalStateException ("ScrollView can host only one direct child");
}Clazz.superCall (this, android.widget.ScrollView, "addView", [child, index]);
}, "android.view.View,~N");
Clazz.defineMethod (c$, "addView", 
function (child, params) {
if (this.getChildCount () > 0) {
throw  new IllegalStateException ("ScrollView can host only one direct child");
}Clazz.superCall (this, android.widget.ScrollView, "addView", [child, params]);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addView", 
function (child, index, params) {
if (this.getChildCount () > 0) {
throw  new IllegalStateException ("ScrollView can host only one direct child");
}Clazz.superCall (this, android.widget.ScrollView, "addView", [child, index, params]);
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "canScroll", 
($fz = function () {
var child = this.getChildAt (0);
if (child != null) {
var childHeight = child.getHeight ();
return this.getHeight () < childHeight + this.mPaddingTop + this.mPaddingBottom;
}return false;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "isFillViewport", 
function () {
return this.mFillViewport;
});
Clazz.defineMethod (c$, "setFillViewport", 
function (fillViewport) {
if (fillViewport != this.mFillViewport) {
this.mFillViewport = fillViewport;
this.requestLayout ();
}}, "~B");
Clazz.defineMethod (c$, "isSmoothScrollingEnabled", 
function () {
return this.mSmoothScrollingEnabled;
});
Clazz.defineMethod (c$, "setSmoothScrollingEnabled", 
function (smoothScrollingEnabled) {
this.mSmoothScrollingEnabled = smoothScrollingEnabled;
}, "~B");
Clazz.defineMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
Clazz.superCall (this, android.widget.ScrollView, "onMeasure", [widthMeasureSpec, heightMeasureSpec]);
if (!this.mFillViewport) {
return ;
}var heightMode = android.view.View.MeasureSpec.getMode (heightMeasureSpec);
if (heightMode == 0) {
return ;
}if (this.getChildCount () > 0) {
var child = this.getChildAt (0);
var height = this.getMeasuredHeight ();
if (child.getMeasuredHeight () < height) {
var lp = child.getLayoutParams ();
var childWidthMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (widthMeasureSpec, this.mPaddingLeft + this.mPaddingRight, lp.width);
height -= this.mPaddingTop;
height -= this.mPaddingBottom;
var childHeightMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (height, 1073741824);
child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}}}, "~N,~N");
Clazz.defineMethod (c$, "dispatchKeyEvent", 
function (event) {
return Clazz.superCall (this, android.widget.ScrollView, "dispatchKeyEvent", [event]) || this.executeKeyEvent (event);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "executeKeyEvent", 
function (event) {
this.$mTempRect.setEmpty ();
if (!this.canScroll ()) {
if (this.isFocused () && event.getKeyCode () != 115) {
var currentFocused = this.findFocus ();
if (currentFocused === this) currentFocused = null;
var nextFocused = android.view.FocusFinder.getInstance ().findNextFocus (this, currentFocused, 130);
return nextFocused != null && nextFocused !== this && nextFocused.requestFocus (130);
}return false;
}var handled = false;
if (event.getAction () == 0) {
switch (event.getKeyCode ()) {
case 38:
if (!event.isAltPressed ()) {
handled = this.arrowScroll (33);
} else {
handled = this.fullScroll (33);
}break;
case 40:
if (!event.isAltPressed ()) {
handled = this.arrowScroll (130);
} else {
handled = this.fullScroll (130);
}break;
case 62:
this.pageScroll (event.isShiftPressed () ? 33 : 130);
break;
}
}return handled;
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "inChild", 
($fz = function (x, y) {
if (this.getChildCount () > 0) {
var scrollY = this.mScrollY;
var child = this.getChildAt (0);
return !(y < child.getTop () - scrollY || y >= child.getBottom () - scrollY || x < child.getLeft () || x >= child.getRight ());
}return false;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.overrideMethod (c$, "onInterceptTouchEvent", 
function (ev) {
var action = ev.getAction ();
if ((action == 2) && (this.mIsBeingDragged)) {
return true;
}switch (action & 255) {
case 2:
{
var activePointerId = this.mActivePointerId;
if (activePointerId == -1) {
break;
}var pointerIndex = ev.findPointerIndex (activePointerId);
var y = ev.getY (pointerIndex);
var yDiff = Math.round (Math.abs (y - this.mLastMotionY));
if (yDiff > this.$mTouchSlop) {
this.mIsBeingDragged = true;
this.mLastMotionY = y;
}break;
}case 0:
{
var y = ev.getY ();
if (!this.inChild (Math.round (ev.getX ()), Math.round (y))) {
this.mIsBeingDragged = false;
break;
}this.mLastMotionY = y;
this.mActivePointerId = ev.getPointerId (0);
this.mIsBeingDragged = !this.mScroller.isFinished ();
break;
}case 3:
case 1:
this.mIsBeingDragged = false;
this.mActivePointerId = -1;
if (this.mScroller.springBack (this.mScrollX, this.mScrollY, 0, 0, 0, this.getScrollRange ())) {
this.invalidate ();
}break;
case 6:
this.onSecondaryPointerUp (ev);
break;
}
return this.mIsBeingDragged;
}, "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onTouchEvent", 
function (ev) {
if (ev.getAction () == 0 && ev.getEdgeFlags () != 0) {
return false;
}if (this.mVelocityTracker == null) {
this.mVelocityTracker = android.view.VelocityTracker.obtain ();
}this.mVelocityTracker.addMovement (ev);
var action = ev.getAction ();
switch (action & 255) {
case 0:
{
var y = ev.getY ();
this.mIsBeingDragged = true;
if (!this.mScroller.isFinished ()) {
this.mScroller.abortAnimation ();
}this.mLastMotionY = y;
this.mActivePointerId = ev.getPointerId (0);
break;
}case 2:
if (this.mIsBeingDragged) {
var activePointerIndex = ev.findPointerIndex (this.mActivePointerId);
var y = ev.getY (activePointerIndex);
var deltaY = Math.round ((this.mLastMotionY - y));
this.mLastMotionY = y;
var oldX = this.mScrollX;
var oldY = this.mScrollY;
var range = this.getScrollRange ();
if (this.overScrollBy (0, deltaY, 0, this.mScrollY, 0, range, 0, this.mOverscrollDistance, true)) {
this.mVelocityTracker.clear ();
}this.onScrollChanged (this.mScrollX, this.mScrollY, oldX, oldY);
var overscrollMode = this.getOverScrollMode ();
if (overscrollMode == 0 || (overscrollMode == 1 && range > 0)) {
var pulledToY = oldY + deltaY;
if (pulledToY < 0) {
this.mEdgeGlowTop.onPull (deltaY / this.getHeight ());
if (!this.mEdgeGlowBottom.isFinished ()) {
this.mEdgeGlowBottom.onRelease ();
}} else if (pulledToY > range) {
this.mEdgeGlowBottom.onPull (deltaY / this.getHeight ());
if (!this.mEdgeGlowTop.isFinished ()) {
this.mEdgeGlowTop.onRelease ();
}}if (this.mEdgeGlowTop != null && (!this.mEdgeGlowTop.isFinished () || !this.mEdgeGlowBottom.isFinished ())) {
this.invalidate ();
}}}break;
case 1:
if (this.mIsBeingDragged) {
var velocityTracker = this.mVelocityTracker;
velocityTracker.computeCurrentVelocity (1000, this.mMaximumVelocity);
var initialVelocity = Math.round (velocityTracker.getYVelocity (this.mActivePointerId));
if (this.getChildCount () > 0) {
if ((Math.abs (initialVelocity) > this.mMinimumVelocity)) {
this.fling (-initialVelocity);
} else {
var bottom = this.getScrollRange ();
if (this.mScroller.springBack (this.mScrollX, this.mScrollY, 0, 0, 0, bottom)) {
this.invalidate ();
}}}this.mActivePointerId = -1;
this.mIsBeingDragged = false;
if (this.mVelocityTracker != null) {
this.mVelocityTracker.recycle ();
this.mVelocityTracker = null;
}if (this.mEdgeGlowTop != null) {
this.mEdgeGlowTop.onRelease ();
this.mEdgeGlowBottom.onRelease ();
}}break;
case 3:
if (this.mIsBeingDragged && this.getChildCount () > 0) {
if (this.mScroller.springBack (this.mScrollX, this.mScrollY, 0, 0, 0, this.getScrollRange ())) {
this.invalidate ();
}this.mActivePointerId = -1;
this.mIsBeingDragged = false;
if (this.mVelocityTracker != null) {
this.mVelocityTracker.recycle ();
this.mVelocityTracker = null;
}if (this.mEdgeGlowTop != null) {
this.mEdgeGlowTop.onRelease ();
this.mEdgeGlowBottom.onRelease ();
}}break;
case 6:
this.onSecondaryPointerUp (ev);
break;
}
return true;
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "onSecondaryPointerUp", 
($fz = function (ev) {
var pointerIndex = (ev.getAction () & 65280) >> 8;
var pointerId = ev.getPointerId (pointerIndex);
if (pointerId == this.mActivePointerId) {
var newPointerIndex = pointerIndex == 0 ? 1 : 0;
this.mLastMotionY = ev.getY (newPointerIndex);
this.mActivePointerId = ev.getPointerId (newPointerIndex);
if (this.mVelocityTracker != null) {
this.mVelocityTracker.clear ();
}}}, $fz.isPrivate = true, $fz), "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onOverScrolled", 
function (scrollX, scrollY, clampedX, clampedY) {
if (!this.mScroller.isFinished ()) {
this.mScrollX = scrollX;
this.mScrollY = scrollY;
if (clampedY) {
this.mScroller.springBack (this.mScrollX, this.mScrollY, 0, 0, 0, this.getScrollRange ());
}} else {
Clazz.superCall (this, android.widget.ScrollView, "scrollTo", [scrollX, scrollY]);
}this.awakenScrollBars ();
}, "~N,~N,~B,~B");
Clazz.defineMethod (c$, "getScrollRange", 
($fz = function () {
var scrollRange = 0;
if (this.getChildCount () > 0) {
var child = this.getChildAt (0);
scrollRange = Math.max (0, child.getHeight () - (this.getHeight () - this.mPaddingBottom - this.mPaddingTop));
}return scrollRange;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "findFocusableViewInMyBounds", 
($fz = function (topFocus, top, preferredFocusable) {
var fadingEdgeLength = Math.floor (this.getVerticalFadingEdgeLength () / 2);
var topWithoutFadingEdge = top + fadingEdgeLength;
var bottomWithoutFadingEdge = top + this.getHeight () - fadingEdgeLength;
if ((preferredFocusable != null) && (preferredFocusable.getTop () < bottomWithoutFadingEdge) && (preferredFocusable.getBottom () > topWithoutFadingEdge)) {
return preferredFocusable;
}return this.findFocusableViewInBounds (topFocus, topWithoutFadingEdge, bottomWithoutFadingEdge);
}, $fz.isPrivate = true, $fz), "~B,~N,android.view.View");
Clazz.defineMethod (c$, "findFocusableViewInBounds", 
($fz = function (topFocus, top, bottom) {
var focusables = this.getFocusables (2);
var focusCandidate = null;
var foundFullyContainedFocusable = false;
var count = focusables.size ();
for (var i = 0; i < count; i++) {
var view = focusables.get (i);
var viewTop = view.getTop ();
var viewBottom = view.getBottom ();
if (top < viewBottom && viewTop < bottom) {
var viewIsFullyContained = (top < viewTop) && (viewBottom < bottom);
if (focusCandidate == null) {
focusCandidate = view;
foundFullyContainedFocusable = viewIsFullyContained;
} else {
var viewIsCloserToBoundary = (topFocus && viewTop < focusCandidate.getTop ()) || (!topFocus && viewBottom > focusCandidate.getBottom ());
if (foundFullyContainedFocusable) {
if (viewIsFullyContained && viewIsCloserToBoundary) {
focusCandidate = view;
}} else {
if (viewIsFullyContained) {
focusCandidate = view;
foundFullyContainedFocusable = true;
} else if (viewIsCloserToBoundary) {
focusCandidate = view;
}}}}}
return focusCandidate;
}, $fz.isPrivate = true, $fz), "~B,~N,~N");
Clazz.defineMethod (c$, "pageScroll", 
function (direction) {
var down = direction == 130;
var height = this.getHeight ();
if (down) {
this.$mTempRect.top = this.getScrollY () + height;
var count = this.getChildCount ();
if (count > 0) {
var view = this.getChildAt (count - 1);
if (this.$mTempRect.top + height > view.getBottom ()) {
this.$mTempRect.top = view.getBottom () - height;
}}} else {
this.$mTempRect.top = this.getScrollY () - height;
if (this.$mTempRect.top < 0) {
this.$mTempRect.top = 0;
}}this.$mTempRect.bottom = this.$mTempRect.top + height;
return this.scrollAndFocus (direction, this.$mTempRect.top, this.$mTempRect.bottom);
}, "~N");
Clazz.defineMethod (c$, "fullScroll", 
function (direction) {
var down = direction == 130;
var height = this.getHeight ();
this.$mTempRect.top = 0;
this.$mTempRect.bottom = height;
if (down) {
var count = this.getChildCount ();
if (count > 0) {
var view = this.getChildAt (count - 1);
this.$mTempRect.bottom = view.getBottom ();
this.$mTempRect.top = this.$mTempRect.bottom - height;
}}return this.scrollAndFocus (direction, this.$mTempRect.top, this.$mTempRect.bottom);
}, "~N");
Clazz.defineMethod (c$, "scrollAndFocus", 
($fz = function (direction, top, bottom) {
var handled = true;
var height = this.getHeight ();
var containerTop = this.getScrollY ();
var containerBottom = containerTop + height;
var up = direction == 33;
var newFocused = this.findFocusableViewInBounds (up, top, bottom);
if (newFocused == null) {
newFocused = this;
}if (top >= containerTop && bottom <= containerBottom) {
handled = false;
} else {
var delta = up ? (top - containerTop) : (bottom - containerBottom);
this.doScrollY (delta);
}if (newFocused !== this.findFocus () && newFocused.requestFocus (direction)) {
this.mScrollViewMovedFocus = true;
this.mScrollViewMovedFocus = false;
}return handled;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "arrowScroll", 
function (direction) {
var currentFocused = this.findFocus ();
if (currentFocused === this) currentFocused = null;
var nextFocused = android.view.FocusFinder.getInstance ().findNextFocus (this, currentFocused, direction);
var maxJump = this.getMaxScrollAmount ();
if (nextFocused != null && this.isWithinDeltaOfScreen (nextFocused, maxJump, this.getHeight ())) {
nextFocused.getDrawingRect (this.$mTempRect);
this.offsetDescendantRectToMyCoords (nextFocused, this.$mTempRect);
var scrollDelta = this.computeScrollDeltaToGetChildRectOnScreen (this.$mTempRect);
this.doScrollY (scrollDelta);
nextFocused.requestFocus (direction);
} else {
var scrollDelta = maxJump;
if (direction == 33 && this.getScrollY () < scrollDelta) {
scrollDelta = this.getScrollY ();
} else if (direction == 130) {
if (this.getChildCount () > 0) {
var daBottom = this.getChildAt (0).getBottom ();
var screenBottom = this.getScrollY () + this.getHeight ();
if (daBottom - screenBottom < maxJump) {
scrollDelta = daBottom - screenBottom;
}}}if (scrollDelta == 0) {
return false;
}this.doScrollY (direction == 130 ? scrollDelta : -scrollDelta);
}if (currentFocused != null && currentFocused.isFocused () && this.isOffScreen (currentFocused)) {
var descendantFocusability = this.getDescendantFocusability ();
this.setDescendantFocusability (131072);
this.requestFocus ();
this.setDescendantFocusability (descendantFocusability);
}return true;
}, "~N");
Clazz.defineMethod (c$, "isOffScreen", 
($fz = function (descendant) {
return !this.isWithinDeltaOfScreen (descendant, 0, this.getHeight ());
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "isWithinDeltaOfScreen", 
($fz = function (descendant, delta, height) {
descendant.getDrawingRect (this.$mTempRect);
this.offsetDescendantRectToMyCoords (descendant, this.$mTempRect);
return (this.$mTempRect.bottom + delta) >= this.getScrollY () && (this.$mTempRect.top - delta) <= (this.getScrollY () + height);
}, $fz.isPrivate = true, $fz), "android.view.View,~N,~N");
Clazz.defineMethod (c$, "doScrollY", 
($fz = function (delta) {
if (delta != 0) {
if (this.mSmoothScrollingEnabled) {
this.smoothScrollBy (0, delta);
} else {
this.scrollBy (0, delta);
}}}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "smoothScrollBy", 
function (dx, dy) {
if (this.getChildCount () == 0) {
return ;
}var duration = android.view.animation.AnimationUtils.currentAnimationTimeMillis () - this.mLastScroll;
if (duration > 250) {
var height = this.getHeight () - this.mPaddingBottom - this.mPaddingTop;
var bottom = this.getChildAt (0).getHeight ();
var maxY = Math.max (0, bottom - height);
var scrollY = this.mScrollY;
dy = Math.max (0, Math.min (scrollY + dy, maxY)) - scrollY;
this.mScroller.startScroll (this.mScrollX, scrollY, 0, dy);
this.invalidate ();
} else {
if (!this.mScroller.isFinished ()) {
this.mScroller.abortAnimation ();
}this.scrollBy (dx, dy);
}this.mLastScroll = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
}, "~N,~N");
Clazz.defineMethod (c$, "smoothScrollTo", 
function (x, y) {
this.smoothScrollBy (x - this.mScrollX, y - this.mScrollY);
}, "~N,~N");
Clazz.overrideMethod (c$, "computeVerticalScrollRange", 
function () {
var count = this.getChildCount ();
var contentHeight = this.getHeight () - this.mPaddingBottom - this.mPaddingTop;
if (count == 0) {
return contentHeight;
}var scrollRange = this.getChildAt (0).getBottom ();
var scrollY = this.mScrollY;
var overscrollBottom = Math.max (0, scrollRange - contentHeight);
if (scrollY < 0) {
scrollRange -= scrollY;
} else if (scrollY > overscrollBottom) {
scrollRange += scrollY - overscrollBottom;
}return scrollRange;
});
Clazz.defineMethod (c$, "computeVerticalScrollOffset", 
function () {
return Math.max (0, Clazz.superCall (this, android.widget.ScrollView, "computeVerticalScrollOffset", []));
});
Clazz.overrideMethod (c$, "measureChild", 
function (child, parentWidthMeasureSpec, parentHeightMeasureSpec) {
var lp = child.getLayoutParams ();
var childWidthMeasureSpec;
var childHeightMeasureSpec;
childWidthMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (parentWidthMeasureSpec, this.mPaddingLeft + this.mPaddingRight, lp.width);
childHeightMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (0, 0);
child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}, "android.view.View,~N,~N");
Clazz.overrideMethod (c$, "measureChildWithMargins", 
function (child, parentWidthMeasureSpec, widthUsed, parentHeightMeasureSpec, heightUsed) {
var lp = child.getLayoutParams ();
var childWidthMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (parentWidthMeasureSpec, this.mPaddingLeft + this.mPaddingRight + lp.leftMargin + lp.rightMargin + widthUsed, lp.width);
var childHeightMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (lp.topMargin + lp.bottomMargin, 0);
child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}, "android.view.View,~N,~N,~N,~N");
Clazz.overrideMethod (c$, "computeScroll", 
function () {
if (this.mScroller.computeScrollOffset ()) {
var oldX = this.mScrollX;
var oldY = this.mScrollY;
var x = this.mScroller.getCurrX ();
var y = this.mScroller.getCurrY ();
if (oldX != x || oldY != y) {
this.overScrollBy (x - oldX, y - oldY, oldX, oldY, 0, this.getScrollRange (), 0, this.mOverflingDistance, false);
this.onScrollChanged (this.mScrollX, this.mScrollY, oldX, oldY);
var range = this.getScrollRange ();
var overscrollMode = this.getOverScrollMode ();
if (overscrollMode == 0 || (overscrollMode == 1 && range > 0)) {
if (y < 0 && oldY >= 0) {
this.mEdgeGlowTop.onAbsorb (Math.round (this.mScroller.getCurrVelocity ()));
} else if (y > range && oldY <= range) {
this.mEdgeGlowBottom.onAbsorb (Math.round (this.mScroller.getCurrVelocity ()));
}}}this.awakenScrollBars ();
this.postInvalidate ();
}});
Clazz.defineMethod (c$, "scrollToChild", 
($fz = function (child) {
child.getDrawingRect (this.$mTempRect);
this.offsetDescendantRectToMyCoords (child, this.$mTempRect);
var scrollDelta = this.computeScrollDeltaToGetChildRectOnScreen (this.$mTempRect);
if (scrollDelta != 0) {
this.scrollBy (0, scrollDelta);
}}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "scrollToChildRect", 
($fz = function (rect, immediate) {
var delta = this.computeScrollDeltaToGetChildRectOnScreen (rect);
var scroll = delta != 0;
if (scroll) {
if (immediate) {
this.scrollBy (0, delta);
} else {
this.smoothScrollBy (0, delta);
}}return scroll;
}, $fz.isPrivate = true, $fz), "android.graphics.Rect,~B");
Clazz.defineMethod (c$, "computeScrollDeltaToGetChildRectOnScreen", 
function (rect) {
if (this.getChildCount () == 0) return 0;
var height = this.getHeight ();
var screenTop = this.getScrollY ();
var screenBottom = screenTop + height;
var fadingEdge = this.getVerticalFadingEdgeLength ();
if (rect.top > 0) {
screenTop += fadingEdge;
}if (rect.bottom < this.getChildAt (0).getHeight ()) {
screenBottom -= fadingEdge;
}var scrollYDelta = 0;
if (rect.bottom > screenBottom && rect.top > screenTop) {
if (rect.height () > height) {
scrollYDelta += (rect.top - screenTop);
} else {
scrollYDelta += (rect.bottom - screenBottom);
}var bottom = this.getChildAt (0).getBottom ();
var distanceToBottom = bottom - screenBottom;
scrollYDelta = Math.min (scrollYDelta, distanceToBottom);
} else if (rect.top < screenTop && rect.bottom < screenBottom) {
if (rect.height () > height) {
scrollYDelta -= (screenBottom - rect.bottom);
} else {
scrollYDelta -= (screenTop - rect.top);
}scrollYDelta = Math.max (scrollYDelta, -this.getScrollY ());
}return scrollYDelta;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "requestChildFocus", 
function (child, focused) {
if (!this.mScrollViewMovedFocus) {
if (!this.mIsLayoutDirty) {
this.scrollToChild (focused);
} else {
this.mChildToScrollTo = focused;
}}Clazz.superCall (this, android.widget.ScrollView, "requestChildFocus", [child, focused]);
}, "android.view.View,android.view.View");
Clazz.overrideMethod (c$, "onRequestFocusInDescendants", 
function (direction, previouslyFocusedRect) {
if (direction == 2) {
direction = 130;
} else if (direction == 1) {
direction = 33;
}var nextFocus = previouslyFocusedRect == null ? android.view.FocusFinder.getInstance ().findNextFocus (this, null, direction) : android.view.FocusFinder.getInstance ().findNextFocusFromRect (this, previouslyFocusedRect, direction);
if (nextFocus == null) {
return false;
}if (this.isOffScreen (nextFocus)) {
return false;
}return nextFocus.requestFocus (direction, previouslyFocusedRect);
}, "~N,android.graphics.Rect");
Clazz.overrideMethod (c$, "requestChildRectangleOnScreen", 
function (child, rectangle, immediate) {
rectangle.offset (child.getLeft () - child.getScrollX (), child.getTop () - child.getScrollY ());
return this.scrollToChildRect (rectangle, immediate);
}, "android.view.View,android.graphics.Rect,~B");
Clazz.defineMethod (c$, "requestLayout", 
function () {
this.mIsLayoutDirty = true;
Clazz.superCall (this, android.widget.ScrollView, "requestLayout", []);
});
Clazz.defineMethod (c$, "onLayout", 
function (changed, l, t, r, b) {
Clazz.superCall (this, android.widget.ScrollView, "onLayout", [changed, l, t, r, b]);
this.mIsLayoutDirty = false;
if (this.mChildToScrollTo != null && this.isViewDescendantOf (this.mChildToScrollTo, this)) {
this.scrollToChild (this.mChildToScrollTo);
}this.mChildToScrollTo = null;
this.scrollTo (this.mScrollX, this.mScrollY);
}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "onSizeChanged", 
function (w, h, oldw, oldh) {
Clazz.superCall (this, android.widget.ScrollView, "onSizeChanged", [w, h, oldw, oldh]);
var currentFocused = this.findFocus ();
if (null == currentFocused || this === currentFocused) return ;
if (this.isWithinDeltaOfScreen (currentFocused, 0, oldh)) {
currentFocused.getDrawingRect (this.$mTempRect);
this.offsetDescendantRectToMyCoords (currentFocused, this.$mTempRect);
var scrollDelta = this.computeScrollDeltaToGetChildRectOnScreen (this.$mTempRect);
this.doScrollY (scrollDelta);
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "isViewDescendantOf", 
($fz = function (child, parent) {
if (child === parent) {
return true;
}var theParent = child.getParent ();
return (Clazz.instanceOf (theParent, android.view.ViewGroup)) && this.isViewDescendantOf (theParent, parent);
}, $fz.isPrivate = true, $fz), "android.view.View,android.view.View");
Clazz.defineMethod (c$, "fling", 
function (velocityY) {
if (this.getChildCount () > 0) {
var height = this.getHeight () - this.mPaddingBottom - this.mPaddingTop;
var bottom = this.getChildAt (0).getHeight ();
this.mScroller.fling (this.mScrollX, this.mScrollY, 0, velocityY, 0, 0, 0, Math.max (0, bottom - height), 0, Math.floor (height / 2));
var movingDown = velocityY > 0;
var newFocused = this.findFocusableViewInMyBounds (movingDown, this.mScroller.getFinalY (), this.findFocus ());
if (newFocused == null) {
newFocused = this;
}if (newFocused !== this.findFocus () && newFocused.requestFocus (movingDown ? 130 : 33)) {
this.mScrollViewMovedFocus = true;
this.mScrollViewMovedFocus = false;
}this.invalidate ();
}}, "~N");
Clazz.defineMethod (c$, "scrollTo", 
function (x, y) {
if (this.getChildCount () > 0) {
var child = this.getChildAt (0);
x = this.clamp (x, this.getWidth () - this.mPaddingRight - this.mPaddingLeft, child.getWidth ());
y = this.clamp (y, this.getHeight () - this.mPaddingBottom - this.mPaddingTop, child.getHeight ());
if (x != this.mScrollX || y != this.mScrollY) {
Clazz.superCall (this, android.widget.ScrollView, "scrollTo", [x, y]);
}}}, "~N,~N");
Clazz.defineMethod (c$, "setOverScrollMode", 
function (mode) {
if (mode != 2) {
if (this.mEdgeGlowTop == null) {
var res = this.getContext ().getResources ();
var edge = res.getDrawable (17302072);
var glow = res.getDrawable (17302073);
this.mEdgeGlowTop =  new android.widget.EdgeGlow (edge, glow);
this.mEdgeGlowBottom =  new android.widget.EdgeGlow (edge, glow);
}} else {
this.mEdgeGlowTop = null;
this.mEdgeGlowBottom = null;
}Clazz.superCall (this, android.widget.ScrollView, "setOverScrollMode", [mode]);
}, "~N");
Clazz.defineMethod (c$, "draw", 
function (canvas) {
Clazz.superCall (this, android.widget.ScrollView, "draw", [canvas]);
if (this.mEdgeGlowTop != null) {
var scrollY = this.mScrollY;
if (!this.mEdgeGlowTop.isFinished ()) {
var restoreCount = canvas.save ();
var width = this.getWidth ();
canvas.translate (Math.floor (-width / 2), Math.min (0, scrollY));
this.mEdgeGlowTop.setSize (width * 2, this.getHeight ());
if (this.mEdgeGlowTop.draw (canvas)) {
this.invalidate ();
}canvas.restoreToCount (restoreCount);
}if (!this.mEdgeGlowBottom.isFinished ()) {
var restoreCount = canvas.save ();
var width = this.getWidth ();
var height = this.getHeight ();
canvas.translate (Math.floor (-width / 2), Math.max (this.getScrollRange (), scrollY) + height);
canvas.rotate (180, width, 0);
this.mEdgeGlowBottom.setSize (width * 2, height);
if (this.mEdgeGlowBottom.draw (canvas)) {
this.invalidate ();
}canvas.restoreToCount (restoreCount);
}}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "clamp", 
($fz = function (n, my, child) {
if (my >= child || n < 0) {
return 0;
}if ((my + n) > child) {
return child - my;
}return n;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineStatics (c$,
"ANIMATED_SCROLL_GAP", 250,
"MAX_SCROLL_FACTOR", 0.5,
"INVALID_POINTER", -1);
});
