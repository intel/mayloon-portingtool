﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.ViewGroup", "android.widget.CompoundButton", "$.LinearLayout"], "android.widget.RadioGroup", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mCheckedId = -1;
this.mChildOnCheckedChangeListener = null;
this.mProtectFromCheckedChange = false;
this.mOnCheckedChangeListener = null;
this.mPassThroughListener = null;
if (!Clazz.isClassDefined ("android.widget.RadioGroup.CheckedStateTracker")) {
android.widget.RadioGroup.$RadioGroup$CheckedStateTracker$ ();
}
if (!Clazz.isClassDefined ("android.widget.RadioGroup.PassThroughHierarchyChangeListener")) {
android.widget.RadioGroup.$RadioGroup$PassThroughHierarchyChangeListener$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "RadioGroup", android.widget.LinearLayout);
Clazz.makeConstructor (c$, 
function (context) {
Clazz.superConstructor (this, android.widget.RadioGroup, [context]);
this.setOrientation (1);
this.init ();
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.widget.RadioGroup, [context, attrs]);
var attributes = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.RadioGroup, 16842878, 0);
var value = attributes.getResourceId (1, -1);
if (value != -1) {
this.mCheckedId = value;
}var index = attributes.getInt (0, 1);
this.setOrientation (index);
attributes.recycle ();
this.init ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "addView", 
function (child, index, params) {
if (Clazz.instanceOf (child, android.widget.RadioButton)) {
var button = child;
if (button.isChecked ()) {
this.mProtectFromCheckedChange = true;
if (this.mCheckedId != -1) {
this.setCheckedStateForView (this.mCheckedId, false);
}this.mProtectFromCheckedChange = false;
this.setCheckedId (button.getId ());
}}Clazz.superCall (this, android.widget.RadioGroup, "addView", [child, index, params]);
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "init", 
($fz = function () {
this.mChildOnCheckedChangeListener = Clazz.innerTypeInstance (android.widget.RadioGroup.CheckedStateTracker, this, null);
this.mPassThroughListener = Clazz.innerTypeInstance (android.widget.RadioGroup.PassThroughHierarchyChangeListener, this, null);
Clazz.superCall (this, android.widget.RadioGroup, "setOnHierarchyChangeListener", [this.mPassThroughListener]);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setOnHierarchyChangeListener", 
function (listener) {
this.mPassThroughListener.mOnHierarchyChangeListener = listener;
}, "android.view.ViewGroup.OnHierarchyChangeListener");
Clazz.defineMethod (c$, "onFinishInflate", 
function () {
Clazz.superCall (this, android.widget.RadioGroup, "onFinishInflate", []);
if (this.mCheckedId != -1) {
this.mProtectFromCheckedChange = true;
this.setCheckedStateForView (this.mCheckedId, true);
this.mProtectFromCheckedChange = false;
this.setCheckedId (this.mCheckedId);
}});
Clazz.defineMethod (c$, "addView", 
function (child, index, params, modifyDom) {
if (Clazz.instanceOf (child, android.widget.RadioButton)) {
var button = child;
if (button.isChecked ()) {
this.mProtectFromCheckedChange = true;
if (this.mCheckedId != -1) {
this.setCheckedStateForView (this.mCheckedId, false);
}this.mProtectFromCheckedChange = false;
this.setCheckedId (button.getId ());
}}Clazz.superCall (this, android.widget.RadioGroup, "addView", [child, index, params, modifyDom]);
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams,~B");
Clazz.defineMethod (c$, "check", 
function (id) {
if (id != -1 && (id == this.mCheckedId)) {
return ;
}if (this.mCheckedId != -1) {
this.setCheckedStateForView (this.mCheckedId, false);
}if (id != -1) {
this.setCheckedStateForView (id, true);
}this.setCheckedId (id);
}, "~N");
Clazz.defineMethod (c$, "setCheckedId", 
($fz = function (id) {
this.mCheckedId = id;
if (this.mOnCheckedChangeListener != null) {
this.mOnCheckedChangeListener.onCheckedChanged (this, this.mCheckedId);
}}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "setCheckedStateForView", 
($fz = function (viewId, checked) {
var checkedView = this.findViewById (viewId);
if (checkedView != null && Clazz.instanceOf (checkedView, android.widget.RadioButton)) {
(checkedView).setChecked (checked);
}}, $fz.isPrivate = true, $fz), "~N,~B");
Clazz.defineMethod (c$, "getCheckedRadioButtonId", 
function () {
return this.mCheckedId;
});
Clazz.defineMethod (c$, "clearCheck", 
function () {
this.check (-1);
});
Clazz.defineMethod (c$, "setOnCheckedChangeListener", 
function (listener) {
this.mOnCheckedChangeListener = listener;
}, "android.widget.RadioGroup.OnCheckedChangeListener");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (attrs) {
return  new android.widget.RadioGroup.LayoutParams (this.getContext (), attrs);
}, "android.util.AttributeSet");
Clazz.overrideMethod (c$, "checkLayoutParams", 
function (p) {
return Clazz.instanceOf (p, android.widget.RadioGroup.LayoutParams);
}, "android.view.ViewGroup.LayoutParams");
Clazz.overrideMethod (c$, "generateDefaultLayoutParams", 
function () {
return  new android.widget.RadioGroup.LayoutParams (-2, -2);
});
Clazz.defineMethod (c$, "LayoutParams", 
function (source) {
console.log("Missing method: LayoutParams");
}, "android.view.ViewGroup.MarginLayoutParams");
Clazz.defineMethod (c$, "LayoutParams", 
function (w, h, initWeight) {
console.log("Missing method: LayoutParams");
}, "~N,~N,~N");
Clazz.defineMethod (c$, "LayoutParams", 
function (w, h) {
console.log("Missing method: LayoutParams");
}, "~N,~N");
c$.$RadioGroup$CheckedStateTracker$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.widget.RadioGroup, "CheckedStateTracker", null, android.widget.CompoundButton.OnCheckedChangeListener);
Clazz.overrideMethod (c$, "onCheckedChanged", 
function (a, b) {
if (this.b$["android.widget.RadioGroup"].mProtectFromCheckedChange) {
return ;
}this.b$["android.widget.RadioGroup"].mProtectFromCheckedChange = true;
if (this.b$["android.widget.RadioGroup"].mCheckedId != -1) {
this.b$["android.widget.RadioGroup"].setCheckedStateForView (this.b$["android.widget.RadioGroup"].mCheckedId, false);
}this.b$["android.widget.RadioGroup"].mProtectFromCheckedChange = false;
var c = a.getId ();
this.b$["android.widget.RadioGroup"].setCheckedId (c);
}, "android.widget.CompoundButton,~B");
c$ = Clazz.p0p ();
};
c$.$RadioGroup$PassThroughHierarchyChangeListener$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mOnHierarchyChangeListener = null;
Clazz.instantialize (this, arguments);
}, android.widget.RadioGroup, "PassThroughHierarchyChangeListener", null, android.view.ViewGroup.OnHierarchyChangeListener);
Clazz.defineMethod (c$, "onChildViewAdded", 
function (a, b) {
if (a === this.b$["android.widget.RadioGroup"] && Clazz.instanceOf (b, android.widget.RadioButton)) {
var c = b.getId ();
if (c == -1) {
c = b.hashCode ();
b.setId (c);
}(b).setOnCheckedChangeWidgetListener (this.b$["android.widget.RadioGroup"].mChildOnCheckedChangeListener);
}if (this.mOnHierarchyChangeListener != null) {
this.mOnHierarchyChangeListener.onChildViewAdded (a, b);
}}, "android.view.View,android.view.View");
Clazz.defineMethod (c$, "onChildViewRemoved", 
function (a, b) {
if (a === this.b$["android.widget.RadioGroup"] && Clazz.instanceOf (b, android.widget.RadioButton)) {
(b).setOnCheckedChangeWidgetListener (null);
}if (this.mOnHierarchyChangeListener != null) {
this.mOnHierarchyChangeListener.onChildViewRemoved (a, b);
}}, "android.view.View,android.view.View");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.declareType (android.widget.RadioGroup, "LayoutParams", android.widget.LinearLayout.LayoutParams);
Clazz.overrideMethod (c$, "setBaseAttributes", 
function (a, b, c) {
if (a.hasValue (b)) {
this.width = a.getLayoutDimension (b, "layout_width");
} else {
this.width = -2;
}if (a.hasValue (c)) {
this.height = a.getLayoutDimension (c, "layout_height");
} else {
this.height = -2;
}}, "android.content.res.TypedArray,~N,~N");
c$ = Clazz.p0p ();
Clazz.declareInterface (android.widget.RadioGroup, "OnCheckedChangeListener");
});
