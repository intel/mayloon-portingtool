﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.FrameLayout", "android.graphics.Rect"], "android.widget.HorizontalScrollView", ["android.R", "android.view.FocusFinder", "$.VelocityTracker", "$.View", "$.ViewConfiguration", "android.view.animation.AnimationUtils", "android.widget.EdgeGlow", "$.OverScroller", "java.lang.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mLastScroll = 0;
this.$mTempRect = null;
this.mScroller = null;
this.mEdgeGlowLeft = null;
this.mEdgeGlowRight = null;
this.mScrollViewMovedFocus = false;
this.mLastMotionX = 0;
this.mIsLayoutDirty = true;
this.mChildToScrollTo = null;
this.mIsBeingDragged = false;
this.mVelocityTracker = null;
this.mFillViewport = false;
this.mSmoothScrollingEnabled = true;
this.$mTouchSlop = 0;
this.mMinimumVelocity = 0;
this.mMaximumVelocity = 0;
this.mOverscrollDistance = 0;
this.mOverflingDistance = 0;
this.mActivePointerId = -1;
Clazz.instantialize (this, arguments);
}, android.widget, "HorizontalScrollView", android.widget.FrameLayout);
Clazz.prepareFields (c$, function () {
this.$mTempRect =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16843471);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.HorizontalScrollView, [context, attrs, defStyle]);
this.initScrollView ();
var a = context.obtainStyledAttributes (attrs, android.R.styleable.HorizontalScrollView, defStyle, 0);
this.setFillViewport (a.getBoolean (0, false));
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.overrideMethod (c$, "getLeftFadingEdgeStrength", 
function () {
if (this.getChildCount () == 0) {
return 0.0;
}var length = this.getHorizontalFadingEdgeLength ();
if (this.mScrollX < length) {
return this.mScrollX / length;
}return 1.0;
});
Clazz.overrideMethod (c$, "getRightFadingEdgeStrength", 
function () {
if (this.getChildCount () == 0) {
return 0.0;
}var length = this.getHorizontalFadingEdgeLength ();
var rightEdge = this.getWidth () - this.mPaddingRight;
var span = this.getChildAt (0).getRight () - this.mScrollX - rightEdge;
if (span < length) {
return span / length;
}return 1.0;
});
Clazz.defineMethod (c$, "getMaxScrollAmount", 
function () {
return Math.round ((0.5 * (this.mRight - this.mLeft)));
});
Clazz.defineMethod (c$, "initScrollView", 
($fz = function () {
this.mScroller =  new android.widget.OverScroller (this.getContext ());
this.setFocusable (true);
this.setDescendantFocusability (262144);
this.setWillNotDraw (false);
var configuration = android.view.ViewConfiguration.get (this.mContext);
this.$mTouchSlop = configuration.getScaledTouchSlop ();
this.mMinimumVelocity = configuration.getScaledMinimumFlingVelocity ();
this.mMaximumVelocity = configuration.getScaledMaximumFlingVelocity ();
this.mOverscrollDistance = configuration.getScaledOverscrollDistance ();
this.mOverflingDistance = configuration.getScaledOverflingDistance ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "addView", 
function (child) {
if (this.getChildCount () > 0) {
throw  new IllegalStateException ("HorizontalScrollView can host only one direct child");
}Clazz.superCall (this, android.widget.HorizontalScrollView, "addView", [child]);
}, "android.view.View");
Clazz.defineMethod (c$, "addView", 
function (child, index) {
if (this.getChildCount () > 0) {
throw  new IllegalStateException ("HorizontalScrollView can host only one direct child");
}Clazz.superCall (this, android.widget.HorizontalScrollView, "addView", [child, index]);
}, "android.view.View,~N");
Clazz.defineMethod (c$, "addView", 
function (child, params) {
if (this.getChildCount () > 0) {
throw  new IllegalStateException ("HorizontalScrollView can host only one direct child");
}Clazz.superCall (this, android.widget.HorizontalScrollView, "addView", [child, params]);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "addView", 
function (child, index, params) {
if (this.getChildCount () > 0) {
throw  new IllegalStateException ("HorizontalScrollView can host only one direct child");
}Clazz.superCall (this, android.widget.HorizontalScrollView, "addView", [child, index, params]);
}, "android.view.View,~N,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "canScroll", 
($fz = function () {
var child = this.getChildAt (0);
if (child != null) {
var childWidth = child.getWidth ();
return this.getWidth () < childWidth + this.mPaddingLeft + this.mPaddingRight;
}return false;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "isFillViewport", 
function () {
return this.mFillViewport;
});
Clazz.defineMethod (c$, "setFillViewport", 
function (fillViewport) {
if (fillViewport != this.mFillViewport) {
this.mFillViewport = fillViewport;
this.requestLayout ();
}}, "~B");
Clazz.defineMethod (c$, "isSmoothScrollingEnabled", 
function () {
return this.mSmoothScrollingEnabled;
});
Clazz.defineMethod (c$, "setSmoothScrollingEnabled", 
function (smoothScrollingEnabled) {
this.mSmoothScrollingEnabled = smoothScrollingEnabled;
}, "~B");
Clazz.defineMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
Clazz.superCall (this, android.widget.HorizontalScrollView, "onMeasure", [widthMeasureSpec, heightMeasureSpec]);
if (!this.mFillViewport) {
return ;
}var widthMode = android.view.View.MeasureSpec.getMode (widthMeasureSpec);
if (widthMode == 0) {
return ;
}if (this.getChildCount () > 0) {
var child = this.getChildAt (0);
var width = this.getMeasuredWidth ();
if (child.getMeasuredWidth () < width) {
var lp = child.getLayoutParams ();
var childHeightMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (heightMeasureSpec, this.mPaddingTop + this.mPaddingBottom, lp.height);
width -= this.mPaddingLeft;
width -= this.mPaddingRight;
var childWidthMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (width, 1073741824);
child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}}}, "~N,~N");
Clazz.defineMethod (c$, "dispatchKeyEvent", 
function (event) {
return Clazz.superCall (this, android.widget.HorizontalScrollView, "dispatchKeyEvent", [event]) || this.executeKeyEvent (event);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "executeKeyEvent", 
function (event) {
this.$mTempRect.setEmpty ();
if (!this.canScroll ()) {
if (this.isFocused ()) {
var currentFocused = this.findFocus ();
if (currentFocused === this) currentFocused = null;
var nextFocused = android.view.FocusFinder.getInstance ().findNextFocus (this, currentFocused, 66);
return nextFocused != null && nextFocused !== this && nextFocused.requestFocus (66);
}return false;
}var handled = false;
if (event.getAction () == 0) {
switch (event.getKeyCode ()) {
case 37:
if (!event.isAltPressed ()) {
handled = this.arrowScroll (17);
} else {
handled = this.fullScroll (17);
}break;
case 39:
if (!event.isAltPressed ()) {
handled = this.arrowScroll (66);
} else {
handled = this.fullScroll (66);
}break;
case 62:
this.pageScroll (event.isShiftPressed () ? 17 : 66);
break;
}
}return handled;
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "inChild", 
($fz = function (x, y) {
if (this.getChildCount () > 0) {
var scrollX = this.mScrollX;
var child = this.getChildAt (0);
return !(y < child.getTop () || y >= child.getBottom () || x < child.getLeft () - scrollX || x >= child.getRight () - scrollX);
}return false;
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.overrideMethod (c$, "onInterceptTouchEvent", 
function (ev) {
var action = ev.getAction ();
if ((action == 2) && (this.mIsBeingDragged)) {
return true;
}switch (action & 255) {
case 2:
{
var activePointerId = this.mActivePointerId;
if (activePointerId == -1) {
break;
}var pointerIndex = ev.findPointerIndex (activePointerId);
var x = ev.getX (pointerIndex);
var xDiff = Math.round (Math.abs (x - this.mLastMotionX));
if (xDiff > this.$mTouchSlop) {
this.mIsBeingDragged = true;
this.mLastMotionX = x;
if (this.mParent != null) this.mParent.requestDisallowInterceptTouchEvent (true);
}break;
}case 0:
{
var x = ev.getX ();
if (!this.inChild (Math.round (x), Math.round (ev.getY ()))) {
this.mIsBeingDragged = false;
break;
}this.mLastMotionX = x;
this.mActivePointerId = ev.getPointerId (0);
this.mIsBeingDragged = !this.mScroller.isFinished ();
break;
}case 3:
case 1:
this.mIsBeingDragged = false;
this.mActivePointerId = -1;
if (this.mScroller.springBack (this.mScrollX, this.mScrollY, 0, this.getScrollRange (), 0, 0)) {
this.invalidate ();
}break;
case 6:
this.onSecondaryPointerUp (ev);
break;
}
return this.mIsBeingDragged;
}, "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onTouchEvent", 
function (ev) {
if (ev.getAction () == 0 && ev.getEdgeFlags () != 0) {
return false;
}if (this.mVelocityTracker == null) {
this.mVelocityTracker = android.view.VelocityTracker.obtain ();
}this.mVelocityTracker.addMovement (ev);
var action = ev.getAction ();
switch (action & 255) {
case 0:
{
this.mIsBeingDragged = this.getChildCount () != 0;
if (!this.mIsBeingDragged) {
return false;
}if (!this.mScroller.isFinished ()) {
this.mScroller.abortAnimation ();
}this.mLastMotionX = ev.getX ();
this.mActivePointerId = ev.getPointerId (0);
break;
}case 2:
if (this.mIsBeingDragged) {
var activePointerIndex = ev.findPointerIndex (this.mActivePointerId);
var x = ev.getX (activePointerIndex);
var deltaX = Math.round ((this.mLastMotionX - x));
this.mLastMotionX = x;
var oldX = this.mScrollX;
var oldY = this.mScrollY;
var range = this.getScrollRange ();
if (this.overScrollBy (deltaX, 0, this.mScrollX, 0, range, 0, this.mOverscrollDistance, 0, true)) {
this.mVelocityTracker.clear ();
}this.onScrollChanged (this.mScrollX, this.mScrollY, oldX, oldY);
var overscrollMode = this.getOverScrollMode ();
if (overscrollMode == 0 || (overscrollMode == 1 && range > 0)) {
var pulledToX = oldX + deltaX;
if (pulledToX < 0) {
this.mEdgeGlowLeft.onPull (deltaX / this.getWidth ());
if (!this.mEdgeGlowRight.isFinished ()) {
this.mEdgeGlowRight.onRelease ();
}} else if (pulledToX > range) {
this.mEdgeGlowRight.onPull (deltaX / this.getWidth ());
if (!this.mEdgeGlowLeft.isFinished ()) {
this.mEdgeGlowLeft.onRelease ();
}}if (this.mEdgeGlowLeft != null && (!this.mEdgeGlowLeft.isFinished () || !this.mEdgeGlowRight.isFinished ())) {
this.invalidate ();
}}}break;
case 1:
if (this.mIsBeingDragged) {
var velocityTracker = this.mVelocityTracker;
velocityTracker.computeCurrentVelocity (1000, this.mMaximumVelocity);
var initialVelocity = Math.round (velocityTracker.getXVelocity (this.mActivePointerId));
if (this.getChildCount () > 0) {
if ((Math.abs (initialVelocity) > this.mMinimumVelocity)) {
this.fling (-initialVelocity);
} else {
var right = this.getScrollRange ();
if (this.mScroller.springBack (this.mScrollX, this.mScrollY, 0, right, 0, 0)) {
this.invalidate ();
}}}this.mActivePointerId = -1;
this.mIsBeingDragged = false;
if (this.mVelocityTracker != null) {
this.mVelocityTracker.recycle ();
this.mVelocityTracker = null;
}if (this.mEdgeGlowLeft != null) {
this.mEdgeGlowLeft.onRelease ();
this.mEdgeGlowRight.onRelease ();
}}break;
case 3:
if (this.mIsBeingDragged && this.getChildCount () > 0) {
if (this.mScroller.springBack (this.mScrollX, this.mScrollY, 0, this.getScrollRange (), 0, 0)) {
this.invalidate ();
}this.mActivePointerId = -1;
this.mIsBeingDragged = false;
if (this.mVelocityTracker != null) {
this.mVelocityTracker.recycle ();
this.mVelocityTracker = null;
}if (this.mEdgeGlowLeft != null) {
this.mEdgeGlowLeft.onRelease ();
this.mEdgeGlowRight.onRelease ();
}}break;
case 6:
this.onSecondaryPointerUp (ev);
break;
}
return true;
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "onSecondaryPointerUp", 
($fz = function (ev) {
var pointerIndex = (ev.getAction () & 65280) >> 8;
var pointerId = ev.getPointerId (pointerIndex);
if (pointerId == this.mActivePointerId) {
var newPointerIndex = pointerIndex == 0 ? 1 : 0;
this.mLastMotionX = ev.getX (newPointerIndex);
this.mActivePointerId = ev.getPointerId (newPointerIndex);
if (this.mVelocityTracker != null) {
this.mVelocityTracker.clear ();
}}}, $fz.isPrivate = true, $fz), "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onOverScrolled", 
function (scrollX, scrollY, clampedX, clampedY) {
if (!this.mScroller.isFinished ()) {
this.mScrollX = scrollX;
this.mScrollY = scrollY;
if (clampedX) {
this.mScroller.springBack (this.mScrollX, this.mScrollY, 0, this.getScrollRange (), 0, 0);
}} else {
Clazz.superCall (this, android.widget.HorizontalScrollView, "scrollTo", [scrollX, scrollY]);
}this.awakenScrollBars ();
}, "~N,~N,~B,~B");
Clazz.defineMethod (c$, "getScrollRange", 
($fz = function () {
var scrollRange = 0;
if (this.getChildCount () > 0) {
var child = this.getChildAt (0);
scrollRange = Math.max (0, child.getWidth () - (this.getWidth () - this.mPaddingLeft - this.mPaddingRight));
}return scrollRange;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "findFocusableViewInMyBounds", 
($fz = function (leftFocus, left, preferredFocusable) {
var fadingEdgeLength = Math.floor (this.getHorizontalFadingEdgeLength () / 2);
var leftWithoutFadingEdge = left + fadingEdgeLength;
var rightWithoutFadingEdge = left + this.getWidth () - fadingEdgeLength;
if ((preferredFocusable != null) && (preferredFocusable.getLeft () < rightWithoutFadingEdge) && (preferredFocusable.getRight () > leftWithoutFadingEdge)) {
return preferredFocusable;
}return this.findFocusableViewInBounds (leftFocus, leftWithoutFadingEdge, rightWithoutFadingEdge);
}, $fz.isPrivate = true, $fz), "~B,~N,android.view.View");
Clazz.defineMethod (c$, "findFocusableViewInBounds", 
($fz = function (leftFocus, left, right) {
var focusables = this.getFocusables (2);
var focusCandidate = null;
var foundFullyContainedFocusable = false;
var count = focusables.size ();
for (var i = 0; i < count; i++) {
var view = focusables.get (i);
var viewLeft = view.getLeft ();
var viewRight = view.getRight ();
if (left < viewRight && viewLeft < right) {
var viewIsFullyContained = (left < viewLeft) && (viewRight < right);
if (focusCandidate == null) {
focusCandidate = view;
foundFullyContainedFocusable = viewIsFullyContained;
} else {
var viewIsCloserToBoundary = (leftFocus && viewLeft < focusCandidate.getLeft ()) || (!leftFocus && viewRight > focusCandidate.getRight ());
if (foundFullyContainedFocusable) {
if (viewIsFullyContained && viewIsCloserToBoundary) {
focusCandidate = view;
}} else {
if (viewIsFullyContained) {
focusCandidate = view;
foundFullyContainedFocusable = true;
} else if (viewIsCloserToBoundary) {
focusCandidate = view;
}}}}}
return focusCandidate;
}, $fz.isPrivate = true, $fz), "~B,~N,~N");
Clazz.defineMethod (c$, "pageScroll", 
function (direction) {
var right = direction == 66;
var width = this.getWidth ();
if (right) {
this.$mTempRect.left = this.getScrollX () + width;
var count = this.getChildCount ();
if (count > 0) {
var view = this.getChildAt (0);
if (this.$mTempRect.left + width > view.getRight ()) {
this.$mTempRect.left = view.getRight () - width;
}}} else {
this.$mTempRect.left = this.getScrollX () - width;
if (this.$mTempRect.left < 0) {
this.$mTempRect.left = 0;
}}this.$mTempRect.right = this.$mTempRect.left + width;
return this.scrollAndFocus (direction, this.$mTempRect.left, this.$mTempRect.right);
}, "~N");
Clazz.defineMethod (c$, "fullScroll", 
function (direction) {
var right = direction == 66;
var width = this.getWidth ();
this.$mTempRect.left = 0;
this.$mTempRect.right = width;
if (right) {
var count = this.getChildCount ();
if (count > 0) {
var view = this.getChildAt (0);
this.$mTempRect.right = view.getRight ();
this.$mTempRect.left = this.$mTempRect.right - width;
}}return this.scrollAndFocus (direction, this.$mTempRect.left, this.$mTempRect.right);
}, "~N");
Clazz.defineMethod (c$, "scrollAndFocus", 
($fz = function (direction, left, right) {
var handled = true;
var width = this.getWidth ();
var containerLeft = this.getScrollX ();
var containerRight = containerLeft + width;
var goLeft = direction == 17;
var newFocused = this.findFocusableViewInBounds (goLeft, left, right);
if (newFocused == null) {
newFocused = this;
}if (left >= containerLeft && right <= containerRight) {
handled = false;
} else {
var delta = goLeft ? (left - containerLeft) : (right - containerRight);
this.doScrollX (delta);
}if (newFocused !== this.findFocus () && newFocused.requestFocus (direction)) {
this.mScrollViewMovedFocus = true;
this.mScrollViewMovedFocus = false;
}return handled;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "arrowScroll", 
function (direction) {
var currentFocused = this.findFocus ();
if (currentFocused === this) currentFocused = null;
var nextFocused = android.view.FocusFinder.getInstance ().findNextFocus (this, currentFocused, direction);
var maxJump = this.getMaxScrollAmount ();
if (nextFocused != null && this.isWithinDeltaOfScreen (nextFocused, maxJump)) {
nextFocused.getDrawingRect (this.$mTempRect);
this.offsetDescendantRectToMyCoords (nextFocused, this.$mTempRect);
var scrollDelta = this.computeScrollDeltaToGetChildRectOnScreen (this.$mTempRect);
this.doScrollX (scrollDelta);
nextFocused.requestFocus (direction);
} else {
var scrollDelta = maxJump;
if (direction == 17 && this.getScrollX () < scrollDelta) {
scrollDelta = this.getScrollX ();
} else if (direction == 66 && this.getChildCount () > 0) {
var daRight = this.getChildAt (0).getRight ();
var screenRight = this.getScrollX () + this.getWidth ();
if (daRight - screenRight < maxJump) {
scrollDelta = daRight - screenRight;
}}if (scrollDelta == 0) {
return false;
}this.doScrollX (direction == 66 ? scrollDelta : -scrollDelta);
}if (currentFocused != null && currentFocused.isFocused () && this.isOffScreen (currentFocused)) {
var descendantFocusability = this.getDescendantFocusability ();
this.setDescendantFocusability (131072);
this.requestFocus ();
this.setDescendantFocusability (descendantFocusability);
}return true;
}, "~N");
Clazz.defineMethod (c$, "isOffScreen", 
($fz = function (descendant) {
return !this.isWithinDeltaOfScreen (descendant, 0);
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "isWithinDeltaOfScreen", 
($fz = function (descendant, delta) {
descendant.getDrawingRect (this.$mTempRect);
this.offsetDescendantRectToMyCoords (descendant, this.$mTempRect);
return (this.$mTempRect.right + delta) >= this.getScrollX () && (this.$mTempRect.left - delta) <= (this.getScrollX () + this.getWidth ());
}, $fz.isPrivate = true, $fz), "android.view.View,~N");
Clazz.defineMethod (c$, "doScrollX", 
($fz = function (delta) {
if (delta != 0) {
if (this.mSmoothScrollingEnabled) {
this.smoothScrollBy (delta, 0);
} else {
this.scrollBy (delta, 0);
}}}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "smoothScrollBy", 
function (dx, dy) {
if (this.getChildCount () == 0) {
return ;
}var duration = android.view.animation.AnimationUtils.currentAnimationTimeMillis () - this.mLastScroll;
if (duration > 250) {
var width = this.getWidth () - this.mPaddingRight - this.mPaddingLeft;
var right = this.getChildAt (0).getWidth ();
var maxX = Math.max (0, right - width);
var scrollX = this.mScrollX;
dx = Math.max (0, Math.min (scrollX + dx, maxX)) - scrollX;
this.mScroller.startScroll (scrollX, this.mScrollY, dx, 0);
this.invalidate ();
} else {
if (!this.mScroller.isFinished ()) {
this.mScroller.abortAnimation ();
}this.scrollBy (dx, dy);
}this.mLastScroll = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
}, "~N,~N");
Clazz.defineMethod (c$, "smoothScrollTo", 
function (x, y) {
this.smoothScrollBy (x - this.mScrollX, y - this.mScrollY);
}, "~N,~N");
Clazz.overrideMethod (c$, "computeHorizontalScrollRange", 
function () {
var count = this.getChildCount ();
var contentWidth = this.getWidth () - this.mPaddingLeft - this.mPaddingRight;
if (count == 0) {
return contentWidth;
}var scrollRange = this.getChildAt (0).getRight ();
var scrollX = this.mScrollX;
var overscrollRight = Math.max (0, scrollRange - contentWidth);
if (scrollX < 0) {
scrollRange -= scrollX;
} else if (scrollX > overscrollRight) {
scrollRange += scrollX - overscrollRight;
}return scrollRange;
});
Clazz.defineMethod (c$, "computeHorizontalScrollOffset", 
function () {
return Math.max (0, Clazz.superCall (this, android.widget.HorizontalScrollView, "computeHorizontalScrollOffset", []));
});
Clazz.overrideMethod (c$, "measureChild", 
function (child, parentWidthMeasureSpec, parentHeightMeasureSpec) {
var lp = child.getLayoutParams ();
var childWidthMeasureSpec;
var childHeightMeasureSpec;
childHeightMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (parentHeightMeasureSpec, this.mPaddingTop + this.mPaddingBottom, lp.height);
childWidthMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (0, 0);
child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}, "android.view.View,~N,~N");
Clazz.overrideMethod (c$, "measureChildWithMargins", 
function (child, parentWidthMeasureSpec, widthUsed, parentHeightMeasureSpec, heightUsed) {
var lp = child.getLayoutParams ();
var childHeightMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (parentHeightMeasureSpec, this.mPaddingTop + this.mPaddingBottom + lp.topMargin + lp.bottomMargin + heightUsed, lp.height);
var childWidthMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (lp.leftMargin + lp.rightMargin, 0);
child.measure (childWidthMeasureSpec, childHeightMeasureSpec);
}, "android.view.View,~N,~N,~N,~N");
Clazz.overrideMethod (c$, "computeScroll", 
function () {
if (this.mScroller.computeScrollOffset ()) {
var oldX = this.mScrollX;
var oldY = this.mScrollY;
var x = this.mScroller.getCurrX ();
var y = this.mScroller.getCurrY ();
if (oldX != x || oldY != y) {
this.overScrollBy (x - oldX, y - oldY, oldX, oldY, this.getScrollRange (), 0, this.mOverflingDistance, 0, false);
this.onScrollChanged (this.mScrollX, this.mScrollY, oldX, oldY);
var range = this.getScrollRange ();
var overscrollMode = this.getOverScrollMode ();
if (overscrollMode == 0 || (overscrollMode == 1 && range > 0)) {
if (x < 0 && oldX >= 0) {
this.mEdgeGlowLeft.onAbsorb (Math.round (this.mScroller.getCurrVelocity ()));
} else if (x > range && oldX <= range) {
this.mEdgeGlowRight.onAbsorb (Math.round (this.mScroller.getCurrVelocity ()));
}}}this.awakenScrollBars ();
this.postInvalidate ();
}});
Clazz.defineMethod (c$, "scrollToChild", 
($fz = function (child) {
child.getDrawingRect (this.$mTempRect);
this.offsetDescendantRectToMyCoords (child, this.$mTempRect);
var scrollDelta = this.computeScrollDeltaToGetChildRectOnScreen (this.$mTempRect);
if (scrollDelta != 0) {
this.scrollBy (scrollDelta, 0);
}}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "scrollToChildRect", 
($fz = function (rect, immediate) {
var delta = this.computeScrollDeltaToGetChildRectOnScreen (rect);
var scroll = delta != 0;
if (scroll) {
if (immediate) {
this.scrollBy (delta, 0);
} else {
this.smoothScrollBy (delta, 0);
}}return scroll;
}, $fz.isPrivate = true, $fz), "android.graphics.Rect,~B");
Clazz.defineMethod (c$, "computeScrollDeltaToGetChildRectOnScreen", 
function (rect) {
if (this.getChildCount () == 0) return 0;
var width = this.getWidth ();
var screenLeft = this.getScrollX ();
var screenRight = screenLeft + width;
var fadingEdge = this.getHorizontalFadingEdgeLength ();
if (rect.left > 0) {
screenLeft += fadingEdge;
}if (rect.right < this.getChildAt (0).getWidth ()) {
screenRight -= fadingEdge;
}var scrollXDelta = 0;
if (rect.right > screenRight && rect.left > screenLeft) {
if (rect.width () > width) {
scrollXDelta += (rect.left - screenLeft);
} else {
scrollXDelta += (rect.right - screenRight);
}var right = this.getChildAt (0).getRight ();
var distanceToRight = right - screenRight;
scrollXDelta = Math.min (scrollXDelta, distanceToRight);
} else if (rect.left < screenLeft && rect.right < screenRight) {
if (rect.width () > width) {
scrollXDelta -= (screenRight - rect.right);
} else {
scrollXDelta -= (screenLeft - rect.left);
}scrollXDelta = Math.max (scrollXDelta, -this.getScrollX ());
}return scrollXDelta;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "requestChildFocus", 
function (child, focused) {
if (!this.mScrollViewMovedFocus) {
if (!this.mIsLayoutDirty) {
this.scrollToChild (focused);
} else {
this.mChildToScrollTo = focused;
}}Clazz.superCall (this, android.widget.HorizontalScrollView, "requestChildFocus", [child, focused]);
}, "android.view.View,android.view.View");
Clazz.overrideMethod (c$, "onRequestFocusInDescendants", 
function (direction, previouslyFocusedRect) {
if (direction == 2) {
direction = 66;
} else if (direction == 1) {
direction = 17;
}var nextFocus = previouslyFocusedRect == null ? android.view.FocusFinder.getInstance ().findNextFocus (this, null, direction) : android.view.FocusFinder.getInstance ().findNextFocusFromRect (this, previouslyFocusedRect, direction);
if (nextFocus == null) {
return false;
}if (this.isOffScreen (nextFocus)) {
return false;
}return nextFocus.requestFocus (direction, previouslyFocusedRect);
}, "~N,android.graphics.Rect");
Clazz.overrideMethod (c$, "requestChildRectangleOnScreen", 
function (child, rectangle, immediate) {
rectangle.offset (child.getLeft () - child.getScrollX (), child.getTop () - child.getScrollY ());
return this.scrollToChildRect (rectangle, immediate);
}, "android.view.View,android.graphics.Rect,~B");
Clazz.defineMethod (c$, "requestLayout", 
function () {
this.mIsLayoutDirty = true;
Clazz.superCall (this, android.widget.HorizontalScrollView, "requestLayout", []);
});
Clazz.defineMethod (c$, "onLayout", 
function (changed, l, t, r, b) {
Clazz.superCall (this, android.widget.HorizontalScrollView, "onLayout", [changed, l, t, r, b]);
this.mIsLayoutDirty = false;
if (this.mChildToScrollTo != null && this.isViewDescendantOf (this.mChildToScrollTo, this)) {
this.scrollToChild (this.mChildToScrollTo);
}this.mChildToScrollTo = null;
this.scrollTo (this.mScrollX, this.mScrollY);
}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "onSizeChanged", 
function (w, h, oldw, oldh) {
Clazz.superCall (this, android.widget.HorizontalScrollView, "onSizeChanged", [w, h, oldw, oldh]);
var currentFocused = this.findFocus ();
if (null == currentFocused || this === currentFocused) return ;
var maxJump = this.mRight - this.mLeft;
if (this.isWithinDeltaOfScreen (currentFocused, maxJump)) {
currentFocused.getDrawingRect (this.$mTempRect);
this.offsetDescendantRectToMyCoords (currentFocused, this.$mTempRect);
var scrollDelta = this.computeScrollDeltaToGetChildRectOnScreen (this.$mTempRect);
this.doScrollX (scrollDelta);
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "isViewDescendantOf", 
($fz = function (child, parent) {
if (child === parent) {
return true;
}var theParent = child.getParent ();
return (Clazz.instanceOf (theParent, android.view.ViewGroup)) && this.isViewDescendantOf (theParent, parent);
}, $fz.isPrivate = true, $fz), "android.view.View,android.view.View");
Clazz.defineMethod (c$, "fling", 
function (velocityX) {
if (this.getChildCount () > 0) {
var width = this.getWidth () - this.mPaddingRight - this.mPaddingLeft;
var right = this.getChildAt (0).getWidth ();
this.mScroller.fling (this.mScrollX, this.mScrollY, velocityX, 0, 0, Math.max (0, right - width), 0, 0, Math.floor (width / 2), 0);
var movingRight = velocityX > 0;
var newFocused = this.findFocusableViewInMyBounds (movingRight, this.mScroller.getFinalX (), this.findFocus ());
if (newFocused == null) {
newFocused = this;
}if (newFocused !== this.findFocus () && newFocused.requestFocus (movingRight ? 66 : 17)) {
this.mScrollViewMovedFocus = true;
this.mScrollViewMovedFocus = false;
}this.invalidate ();
}}, "~N");
Clazz.defineMethod (c$, "scrollTo", 
function (x, y) {
if (this.getChildCount () > 0) {
var child = this.getChildAt (0);
x = this.clamp (x, this.getWidth () - this.mPaddingRight - this.mPaddingLeft, child.getWidth ());
y = this.clamp (y, this.getHeight () - this.mPaddingBottom - this.mPaddingTop, child.getHeight ());
if (x != this.mScrollX || y != this.mScrollY) {
Clazz.superCall (this, android.widget.HorizontalScrollView, "scrollTo", [x, y]);
}}}, "~N,~N");
Clazz.defineMethod (c$, "setOverScrollMode", 
function (mode) {
if (mode != 2) {
if (this.mEdgeGlowLeft == null) {
var res = this.getContext ().getResources ();
var edge = res.getDrawable (17302072);
var glow = res.getDrawable (17302073);
this.mEdgeGlowLeft =  new android.widget.EdgeGlow (edge, glow);
this.mEdgeGlowRight =  new android.widget.EdgeGlow (edge, glow);
}} else {
this.mEdgeGlowLeft = null;
this.mEdgeGlowRight = null;
}Clazz.superCall (this, android.widget.HorizontalScrollView, "setOverScrollMode", [mode]);
}, "~N");
Clazz.defineMethod (c$, "draw", 
function (canvas) {
Clazz.superCall (this, android.widget.HorizontalScrollView, "draw", [canvas]);
if (this.mEdgeGlowLeft != null) {
var scrollX = this.mScrollX;
if (!this.mEdgeGlowLeft.isFinished ()) {
var restoreCount = canvas.save ();
var height = this.getHeight ();
canvas.rotate (270);
canvas.translate (-height * 1.5, Math.min (0, scrollX));
this.mEdgeGlowLeft.setSize (this.getHeight () * 2, this.getWidth ());
if (this.mEdgeGlowLeft.draw (canvas)) {
this.invalidate ();
}canvas.restoreToCount (restoreCount);
}if (!this.mEdgeGlowRight.isFinished ()) {
var restoreCount = canvas.save ();
var width = this.getWidth ();
var height = this.getHeight ();
canvas.rotate (90);
canvas.translate (Math.floor (-height / 2), -(Math.max (this.getScrollRange (), scrollX) + width));
this.mEdgeGlowRight.setSize (height * 2, width);
if (this.mEdgeGlowRight.draw (canvas)) {
this.invalidate ();
}canvas.restoreToCount (restoreCount);
}}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "clamp", 
($fz = function (n, my, child) {
if (my >= child || n < 0) {
return 0;
}if ((my + n) > child) {
return child - my;
}return n;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineStatics (c$,
"ANIMATED_SCROLL_GAP", 250,
"MAX_SCROLL_FACTOR", 0.5,
"INVALID_POINTER", -1);
});
