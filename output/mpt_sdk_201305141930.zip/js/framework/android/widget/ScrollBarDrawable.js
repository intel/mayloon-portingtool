﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.graphics.drawable.Drawable", "android.graphics.Rect"], "android.widget.ScrollBarDrawable", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mVerticalTrack = null;
this.mHorizontalTrack = null;
this.mVerticalThumb = null;
this.mHorizontalThumb = null;
this.mRange = 0;
this.mOffset = 0;
this.mExtent = 0;
this.mVertical = false;
this.mChanged = false;
this.mRangeChanged = false;
this.mTempBounds = null;
this.mAlwaysDrawHorizontalTrack = false;
this.mAlwaysDrawVerticalTrack = false;
Clazz.instantialize (this, arguments);
}, android.widget, "ScrollBarDrawable", android.graphics.drawable.Drawable);
Clazz.prepareFields (c$, function () {
this.mTempBounds =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.widget.ScrollBarDrawable, []);
});
Clazz.defineMethod (c$, "setAlwaysDrawHorizontalTrack", 
function (alwaysDrawTrack) {
this.mAlwaysDrawHorizontalTrack = alwaysDrawTrack;
}, "~B");
Clazz.defineMethod (c$, "setAlwaysDrawVerticalTrack", 
function (alwaysDrawTrack) {
this.mAlwaysDrawVerticalTrack = alwaysDrawTrack;
}, "~B");
Clazz.defineMethod (c$, "getAlwaysDrawVerticalTrack", 
function () {
return this.mAlwaysDrawVerticalTrack;
});
Clazz.defineMethod (c$, "getAlwaysDrawHorizontalTrack", 
function () {
return this.mAlwaysDrawHorizontalTrack;
});
Clazz.defineMethod (c$, "setParameters", 
function (range, offset, extent, vertical) {
if (this.mVertical != vertical) {
this.mChanged = true;
}if (this.mRange != range || this.mOffset != offset || this.mExtent != extent) {
this.mRangeChanged = true;
}this.mRange = range;
this.mOffset = offset;
this.mExtent = extent;
this.mVertical = vertical;
}, "~N,~N,~N,~B");
Clazz.defineMethod (c$, "draw", 
function (canvas) {
var vertical = this.mVertical;
var extent = this.mExtent;
var range = this.mRange;
var drawTrack = true;
var drawThumb = true;
if (extent <= 0 || range <= extent) {
drawTrack = vertical ? this.mAlwaysDrawVerticalTrack : this.mAlwaysDrawHorizontalTrack;
drawThumb = false;
}var r = this.getBounds ();
if (drawTrack) {
this.drawTrack (canvas, r, vertical);
}if (drawThumb) {
var size = vertical ? r.height () : r.width ();
var thickness = vertical ? r.width () : r.height ();
var length = Math.round (size * extent / range);
var offset = Math.round ((size - length) * this.mOffset / (range - extent));
var minLength = thickness * 2;
if (length < minLength) {
length = minLength;
}if (offset + length > size) {
offset = size - length;
}this.drawThumb (canvas, r, offset, length, vertical);
}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "onBoundsChange", 
function (bounds) {
Clazz.superCall (this, android.widget.ScrollBarDrawable, "onBoundsChange", [bounds]);
this.mChanged = true;
}, "android.graphics.Rect");
Clazz.defineMethod (c$, "drawTrack", 
function (canvas, bounds, vertical) {
var track;
if (vertical) {
track = this.mVerticalTrack;
} else {
track = this.mHorizontalTrack;
}if (track != null) {
if (this.mChanged) {
track.setBounds (bounds);
}track.draw (canvas);
}}, "android.graphics.Canvas,android.graphics.Rect,~B");
Clazz.defineMethod (c$, "drawThumb", 
function (canvas, bounds, offset, length, vertical) {
var thumbRect = this.mTempBounds;
var changed = this.mRangeChanged || this.mChanged;
if (changed) {
if (vertical) {
thumbRect.set (bounds.left, bounds.top + offset, bounds.right, bounds.top + offset + length);
} else {
thumbRect.set (bounds.left + offset, bounds.top, bounds.left + offset + length, bounds.bottom);
}}if (vertical) {
var thumb = this.mVerticalThumb;
if (changed) thumb.setBounds (thumbRect);
thumb.draw (canvas);
} else {
var thumb = this.mHorizontalThumb;
if (changed) thumb.setBounds (thumbRect);
thumb.draw (canvas);
}}, "android.graphics.Canvas,android.graphics.Rect,~N,~N,~B");
Clazz.defineMethod (c$, "setVerticalThumbDrawable", 
function (thumb) {
if (thumb != null) {
this.mVerticalThumb = thumb;
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setVerticalTrackDrawable", 
function (track) {
this.mVerticalTrack = track;
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setHorizontalThumbDrawable", 
function (thumb) {
if (thumb != null) {
this.mHorizontalThumb = thumb;
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setHorizontalTrackDrawable", 
function (track) {
this.mHorizontalTrack = track;
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "getSize", 
function (vertical) {
if (vertical) {
return (this.mVerticalTrack != null ? this.mVerticalTrack : this.mVerticalThumb).getIntrinsicWidth ();
} else {
return (this.mHorizontalTrack != null ? this.mHorizontalTrack : this.mHorizontalThumb).getIntrinsicHeight ();
}}, "~B");
Clazz.defineMethod (c$, "setAlpha", 
function (alpha) {
if (this.mVerticalTrack != null) {
this.mVerticalTrack.setAlpha (alpha);
}this.mVerticalThumb.setAlpha (alpha);
if (this.mHorizontalTrack != null) {
this.mHorizontalTrack.setAlpha (alpha);
}this.mHorizontalThumb.setAlpha (alpha);
}, "~N");
Clazz.defineMethod (c$, "setColorFilter", 
function (cf) {
if (this.mVerticalTrack != null) {
this.mVerticalTrack.setColorFilter (cf);
}this.mVerticalThumb.setColorFilter (cf);
if (this.mHorizontalTrack != null) {
this.mHorizontalTrack.setColorFilter (cf);
}this.mHorizontalThumb.setColorFilter (cf);
}, "android.graphics.ColorFilter");
Clazz.overrideMethod (c$, "getOpacity", 
function () {
return -3;
});
Clazz.overrideMethod (c$, "toString", 
function () {
return "ScrollBarDrawable: range=" + this.mRange + " offset=" + this.mOffset + " extent=" + this.mExtent + (this.mVertical ? " V" : " H");
});
});
