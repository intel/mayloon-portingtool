﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.GestureDetector", "$.ViewGroup", "android.widget.AbsSpinner"], "android.widget.Gallery", ["android.util.Log", "android.widget.AdapterView", "com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mSpacing = 0;
this.mAnimationDuration = 400;
this.mUnselectedAlpha = 0;
this.mLeftMost = 0;
this.mRightMost = 0;
this.mGravity = 0;
this.mGestureDetector = null;
this.mDownTouchPosition = 0;
this.mDownTouchView = null;
this.mFlingRunnable = null;
this.mDisableSuppressSelectionChangedRunnable = null;
this.mShouldStopFling = false;
this.mSelectedChild = null;
this.mShouldCallbackDuringFling = true;
this.mShouldCallbackOnUnselectedItemClick = true;
this.mSuppressSelectionChanged = false;
this.mReceivedInvokeKeyDown = false;
this.mContextMenuInfo = null;
this.mIsFirstScroll = false;
if (!Clazz.isClassDefined ("android.widget.Gallery.FlingRunnable")) {
android.widget.Gallery.$Gallery$FlingRunnable$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "Gallery", android.widget.AbsSpinner, android.view.GestureDetector.OnGestureListener);
Clazz.prepareFields (c$, function () {
this.mFlingRunnable = Clazz.innerTypeInstance (android.widget.Gallery.FlingRunnable, this, null);
this.mDisableSuppressSelectionChangedRunnable = ((Clazz.isClassDefined ("android.widget.Gallery$1") ? 0 : android.widget.Gallery.$Gallery$1$ ()), Clazz.innerTypeInstance (android.widget.Gallery$1, this, null));
});
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842864);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.Gallery, [context, attrs, defStyle]);
this.mGestureDetector =  new android.view.GestureDetector (context, this);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.Gallery, defStyle, 0);
var index = a.getInt (0, -1);
if (index >= 0) {
this.setGravity (index);
}var animationDuration = a.getInt (1, -1);
if (animationDuration > 0) {
this.setAnimationDuration (animationDuration);
}var spacing = a.getDimensionPixelOffset (2, 0);
this.setSpacing (spacing);
var unselectedAlpha = a.getFloat (3, 0.5);
this.setUnselectedAlpha (unselectedAlpha);
a.recycle ();
this.mGroupFlags |= 1024;
this.mGroupFlags |= 2048;
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "setCallbackDuringFling", 
function (shouldCallback) {
this.mShouldCallbackDuringFling = shouldCallback;
}, "~B");
Clazz.defineMethod (c$, "setCallbackOnUnselectedItemClick", 
function (shouldCallback) {
this.mShouldCallbackOnUnselectedItemClick = shouldCallback;
}, "~B");
Clazz.defineMethod (c$, "setAnimationDuration", 
function (animationDurationMillis) {
this.mAnimationDuration = animationDurationMillis;
}, "~N");
Clazz.defineMethod (c$, "setSpacing", 
function (spacing) {
this.mSpacing = spacing;
}, "~N");
Clazz.defineMethod (c$, "setUnselectedAlpha", 
function (unselectedAlpha) {
this.mUnselectedAlpha = unselectedAlpha;
}, "~N");
Clazz.overrideMethod (c$, "getChildStaticTransformation", 
function (child, t) {
t.clear ();
t.setAlpha (child === this.mSelectedChild ? 1.0 : this.mUnselectedAlpha);
return true;
}, "android.view.View,android.view.animation.Transformation");
Clazz.overrideMethod (c$, "computeHorizontalScrollExtent", 
function () {
return 1;
});
Clazz.overrideMethod (c$, "computeHorizontalScrollOffset", 
function () {
return this.mSelectedPosition;
});
Clazz.overrideMethod (c$, "computeHorizontalScrollRange", 
function () {
return this.mItemCount;
});
Clazz.overrideMethod (c$, "checkLayoutParams", 
function (p) {
return Clazz.instanceOf (p, android.widget.Gallery.LayoutParams);
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (p) {
return  new android.widget.Gallery.LayoutParams (p);
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (attrs) {
return  new android.widget.Gallery.LayoutParams (this.getContext (), attrs);
}, "android.util.AttributeSet");
Clazz.overrideMethod (c$, "generateDefaultLayoutParams", 
function () {
return  new android.widget.Gallery.LayoutParams (-2, -2);
});
Clazz.defineMethod (c$, "onLayout", 
function (changed, l, t, r, b) {
Clazz.superCall (this, android.widget.Gallery, "onLayout", [changed, l, t, r, b]);
this.mInLayout = true;
this.layout (0, false);
this.mInLayout = false;
}, "~B,~N,~N,~N,~N");
Clazz.overrideMethod (c$, "getChildHeight", 
function (child) {
return child.getMeasuredHeight ();
}, "android.view.View");
Clazz.defineMethod (c$, "trackMotionScroll", 
function (deltaX) {
if (this.getChildCount () == 0) {
return ;
}var toLeft = deltaX < 0;
var limitedDeltaX = this.getLimitedMotionScrollAmount (toLeft, deltaX);
if (limitedDeltaX != deltaX) {
this.mFlingRunnable.endFling (false);
this.onFinishedMovement ();
}this.offsetChildrenLeftAndRight (limitedDeltaX);
this.detachOffScreenChildren (toLeft);
if (toLeft) {
this.fillToGalleryRight ();
} else {
this.fillToGalleryLeft ();
}this.mRecycler.clear ();
this.setSelectionToCenterChild ();
this.invalidate ();
}, "~N");
Clazz.defineMethod (c$, "getLimitedMotionScrollAmount", 
function (motionToLeft, deltaX) {
var extremeItemPosition = motionToLeft ? this.mItemCount - 1 : 0;
var extremeChild = this.getChildAt (extremeItemPosition - this.mFirstPosition);
if (extremeChild == null) {
return deltaX;
}var extremeChildCenter = android.widget.Gallery.getCenterOfView (extremeChild);
var galleryCenter = this.getCenterOfGallery ();
if (motionToLeft) {
if (extremeChildCenter <= galleryCenter) {
return 0;
}} else {
if (extremeChildCenter >= galleryCenter) {
return 0;
}}var centerDifference = galleryCenter - extremeChildCenter;
return motionToLeft ? Math.max (centerDifference, deltaX) : Math.min (centerDifference, deltaX);
}, "~B,~N");
Clazz.defineMethod (c$, "offsetChildrenLeftAndRight", 
($fz = function (offset) {
for (var i = this.getChildCount () - 1; i >= 0; i--) {
this.getChildAt (i).offsetLeftAndRight (offset);
}
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "getCenterOfGallery", 
($fz = function () {
return Math.floor ((this.getWidth () - this.mPaddingLeft - this.mPaddingRight) / 2) + this.mPaddingLeft;
}, $fz.isPrivate = true, $fz));
c$.getCenterOfView = Clazz.defineMethod (c$, "getCenterOfView", 
($fz = function (view) {
return view.getLeft () + Math.floor (view.getWidth () / 2);
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "detachOffScreenChildren", 
($fz = function (toLeft) {
var numChildren = this.getChildCount ();
var firstPosition = this.mFirstPosition;
var start = 0;
var count = 0;
if (toLeft) {
var galleryLeft = this.mPaddingLeft;
for (var i = 0; i < numChildren; i++) {
var child = this.getChildAt (i);
if (child.getRight () >= galleryLeft) {
break;
} else {
count++;
this.mRecycler.put (firstPosition + i, child);
}}
} else {
var galleryRight = this.getWidth () - this.mPaddingRight;
for (var i = numChildren - 1; i >= 0; i--) {
var child = this.getChildAt (i);
if (child.getLeft () <= galleryRight) {
break;
} else {
start = i;
count++;
this.mRecycler.put (firstPosition + i, child);
}}
}this.detachViewsFromParent (start, count);
if (toLeft) {
this.mFirstPosition += count;
}}, $fz.isPrivate = true, $fz), "~B");
Clazz.defineMethod (c$, "scrollIntoSlots", 
($fz = function () {
if (this.getChildCount () == 0 || this.mSelectedChild == null) return ;
var selectedCenter = android.widget.Gallery.getCenterOfView (this.mSelectedChild);
var targetCenter = this.getCenterOfGallery ();
var scrollAmount = targetCenter - selectedCenter;
if (scrollAmount != 0) {
this.mFlingRunnable.startUsingDistance (scrollAmount);
} else {
this.onFinishedMovement ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "onFinishedMovement", 
($fz = function () {
if (this.mSuppressSelectionChanged) {
this.mSuppressSelectionChanged = false;
Clazz.superCall (this, android.widget.Gallery, "selectionChanged", []);
}this.invalidate ();
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "selectionChanged", 
function () {
if (!this.mSuppressSelectionChanged) {
Clazz.superCall (this, android.widget.Gallery, "selectionChanged", []);
}});
Clazz.defineMethod (c$, "setSelectionToCenterChild", 
($fz = function () {
var selView = this.mSelectedChild;
if (this.mSelectedChild == null) return ;
var galleryCenter = this.getCenterOfGallery ();
if (selView.getLeft () <= galleryCenter && selView.getRight () >= galleryCenter) {
return ;
}var closestEdgeDistance = 2147483647;
var newSelectedChildIndex = 0;
for (var i = this.getChildCount () - 1; i >= 0; i--) {
var child = this.getChildAt (i);
if (child.getLeft () <= galleryCenter && child.getRight () >= galleryCenter) {
newSelectedChildIndex = i;
break;
}var childClosestEdgeDistance = Math.min (Math.abs (child.getLeft () - galleryCenter), Math.abs (child.getRight () - galleryCenter));
if (childClosestEdgeDistance < closestEdgeDistance) {
closestEdgeDistance = childClosestEdgeDistance;
newSelectedChildIndex = i;
}}
var newPos = this.mFirstPosition + newSelectedChildIndex;
if (newPos != this.mSelectedPosition) {
this.setSelectedPositionInt (newPos);
this.setNextSelectedPositionInt (newPos);
this.checkSelectionChanged ();
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "layout", 
function (delta, animate) {
var childrenLeft = this.mSpinnerPadding.left;
var childrenWidth = this.mRight - this.mLeft - this.mSpinnerPadding.left - this.mSpinnerPadding.right;
if (this.mDataChanged) {
this.handleDataChanged ();
}if (this.mItemCount == 0) {
this.resetList ();
return ;
}if (this.mNextSelectedPosition >= 0) {
this.setSelectedPositionInt (this.mNextSelectedPosition);
}this.recycleAllViews ();
this.detachAllViewsFromParent ();
this.mRightMost = 0;
this.mLeftMost = 0;
this.mFirstPosition = this.mSelectedPosition;
var sel = this.makeAndAddView (this.mSelectedPosition, 0, 0, true);
var selectedOffset = childrenLeft + (Math.floor (childrenWidth / 2)) - (Math.floor (sel.getWidth () / 2));
sel.offsetLeftAndRight (selectedOffset);
this.fillToGalleryRight ();
this.fillToGalleryLeft ();
this.mRecycler.clear ();
this.invalidate ();
this.checkSelectionChanged ();
this.mDataChanged = false;
this.mNeedSync = false;
this.setNextSelectedPositionInt (this.mSelectedPosition);
this.updateSelectedItemMetadata ();
}, "~N,~B");
Clazz.defineMethod (c$, "fillToGalleryLeft", 
($fz = function () {
var itemSpacing = this.mSpacing;
var galleryLeft = this.mPaddingLeft;
var prevIterationView = this.getChildAt (0);
var curPosition;
var curRightEdge;
if (prevIterationView != null) {
curPosition = this.mFirstPosition - 1;
curRightEdge = prevIterationView.getLeft () - itemSpacing;
} else {
curPosition = 0;
curRightEdge = this.mRight - this.mLeft - this.mPaddingRight;
this.mShouldStopFling = true;
}while (curRightEdge > galleryLeft && curPosition >= 0) {
prevIterationView = this.makeAndAddView (curPosition, curPosition - this.mSelectedPosition, curRightEdge, false);
this.mFirstPosition = curPosition;
curRightEdge = prevIterationView.getLeft () - itemSpacing;
curPosition--;
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "fillToGalleryRight", 
($fz = function () {
var itemSpacing = this.mSpacing;
var galleryRight = this.mRight - this.mLeft - this.mPaddingRight;
var numChildren = this.getChildCount ();
var numItems = this.mItemCount;
var prevIterationView = this.getChildAt (numChildren - 1);
var curPosition;
var curLeftEdge;
if (prevIterationView != null) {
curPosition = this.mFirstPosition + numChildren;
curLeftEdge = prevIterationView.getRight () + itemSpacing;
} else {
this.mFirstPosition = curPosition = this.mItemCount - 1;
curLeftEdge = this.mPaddingLeft;
this.mShouldStopFling = true;
}while (curLeftEdge < galleryRight && curPosition < numItems) {
prevIterationView = this.makeAndAddView (curPosition, curPosition - this.mSelectedPosition, curLeftEdge, true);
curLeftEdge = prevIterationView.getRight () + itemSpacing;
curPosition++;
}
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "makeAndAddView", 
($fz = function (position, offset, x, fromLeft) {
var child;
if (!this.mDataChanged) {
child = this.mRecycler.get (position);
if (child != null) {
var childLeft = child.getLeft ();
this.mRightMost = Math.max (this.mRightMost, childLeft + child.getMeasuredWidth ());
this.mLeftMost = Math.min (this.mLeftMost, childLeft);
this.setUpChild (child, offset, x, fromLeft);
return child;
}}child = this.mAdapter.getView (position, null, this);
this.setUpChild (child, offset, x, fromLeft);
return child;
}, $fz.isPrivate = true, $fz), "~N,~N,~N,~B");
Clazz.defineMethod (c$, "setUpChild", 
($fz = function (child, offset, x, fromLeft) {
var lp = child.getLayoutParams ();
if (lp == null) {
lp = this.generateDefaultLayoutParams ();
}this.addViewInLayout (child, fromLeft ? -1 : 0, lp);
child.setSelected (offset == 0);
var childHeightSpec = android.view.ViewGroup.getChildMeasureSpec (this.mHeightMeasureSpec, this.mSpinnerPadding.top + this.mSpinnerPadding.bottom, lp.height);
var childWidthSpec = android.view.ViewGroup.getChildMeasureSpec (this.mWidthMeasureSpec, this.mSpinnerPadding.left + this.mSpinnerPadding.right, lp.width);
child.measure (childWidthSpec, childHeightSpec);
var childLeft;
var childRight;
var childTop = this.calculateTop (child, true);
var childBottom = childTop + child.getMeasuredHeight ();
var width = child.getMeasuredWidth ();
if (fromLeft) {
childLeft = x;
childRight = childLeft + width;
} else {
childLeft = x - width;
childRight = x;
}child.layout (childLeft, childTop, childRight, childBottom);
}, $fz.isPrivate = true, $fz), "android.view.View,~N,~N,~B");
Clazz.defineMethod (c$, "calculateTop", 
($fz = function (child, duringLayout) {
var myHeight = duringLayout ? this.mMeasuredHeight : this.getHeight ();
var childHeight = duringLayout ? child.getMeasuredHeight () : child.getHeight ();
var childTop = 0;
switch (this.mGravity) {
case 48:
childTop = this.mSpinnerPadding.top;
break;
case 16:
var availableSpace = myHeight - this.mSpinnerPadding.bottom - this.mSpinnerPadding.top - childHeight;
childTop = this.mSpinnerPadding.top + (Math.floor (availableSpace / 2));
break;
case 80:
childTop = myHeight - this.mSpinnerPadding.bottom - childHeight;
break;
}
return childTop;
}, $fz.isPrivate = true, $fz), "android.view.View,~B");
Clazz.overrideMethod (c$, "onTouchEvent", 
function (event) {
var retValue = this.mGestureDetector.onTouchEvent (event);
var action = event.getAction ();
if (action == 1) {
this.onUp ();
} else if (action == 3) {
this.onCancel ();
}return retValue;
}, "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onSingleTapUp", 
function (e) {
if (this.mDownTouchPosition >= 0) {
this.scrollToChild (this.mDownTouchPosition - this.mFirstPosition);
if (this.mShouldCallbackOnUnselectedItemClick || this.mDownTouchPosition == this.mSelectedPosition) {
this.performItemClick (this.mDownTouchView, this.mDownTouchPosition, this.mAdapter.getItemId (this.mDownTouchPosition));
}return true;
}return false;
}, "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onFling", 
function (e1, e2, velocityX, velocityY) {
if (!this.mShouldCallbackDuringFling) {
this.removeCallbacks (this.mDisableSuppressSelectionChangedRunnable);
if (!this.mSuppressSelectionChanged) this.mSuppressSelectionChanged = true;
}this.mFlingRunnable.startUsingVelocity (Math.round (-velocityX));
return true;
}, "android.view.MotionEvent,android.view.MotionEvent,~N,~N");
Clazz.overrideMethod (c$, "onScroll", 
function (e1, e2, distanceX, distanceY) {
if (false) android.util.Log.v ("Gallery", String.valueOf (e2.getX () - e1.getX ()));
this.mParent.requestDisallowInterceptTouchEvent (true);
if (!this.mShouldCallbackDuringFling) {
if (this.mIsFirstScroll) {
if (!this.mSuppressSelectionChanged) this.mSuppressSelectionChanged = true;
}} else {
if (this.mSuppressSelectionChanged) this.mSuppressSelectionChanged = false;
}this.trackMotionScroll (-1 * Math.round (distanceX));
this.mIsFirstScroll = false;
return true;
}, "android.view.MotionEvent,android.view.MotionEvent,~N,~N");
Clazz.overrideMethod (c$, "onDown", 
function (e) {
this.mFlingRunnable.stop (false);
this.mDownTouchPosition = this.pointToPosition (Math.round (e.getX ()), Math.round (e.getY ()));
if (this.mDownTouchPosition >= 0) {
this.mDownTouchView = this.getChildAt (this.mDownTouchPosition - this.mFirstPosition);
this.mDownTouchView.setPressed (true);
}this.mIsFirstScroll = true;
return true;
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "onUp", 
function () {
this.scrollIntoSlots ();
this.dispatchUnpress ();
});
Clazz.defineMethod (c$, "onCancel", 
function () {
this.onUp ();
});
Clazz.overrideMethod (c$, "onLongPress", 
function (e) {
if (this.mDownTouchPosition < 0) {
return ;
}var id = this.getItemIdAtPosition (this.mDownTouchPosition);
this.dispatchLongPress (this.mDownTouchView, this.mDownTouchPosition, id);
}, "android.view.MotionEvent");
Clazz.overrideMethod (c$, "onShowPress", 
function (e) {
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "dispatchPress", 
($fz = function (child) {
if (child != null) {
child.setPressed (true);
}this.setPressed (true);
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "dispatchUnpress", 
($fz = function () {
for (var i = this.getChildCount () - 1; i >= 0; i--) {
this.getChildAt (i).setPressed (false);
}
this.setPressed (false);
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "dispatchSetSelected", 
function (selected) {
}, "~B");
Clazz.overrideMethod (c$, "dispatchSetPressed", 
function (pressed) {
if (this.mSelectedChild != null) {
this.mSelectedChild.setPressed (pressed);
}}, "~B");
Clazz.defineMethod (c$, "getContextMenuInfo", 
function () {
return this.mContextMenuInfo;
});
Clazz.defineMethod (c$, "showContextMenuForChild", 
function (originalView) {
var longPressPosition = this.getPositionForView (originalView);
if (longPressPosition < 0) {
return false;
}var longPressId = this.mAdapter.getItemId (longPressPosition);
return this.dispatchLongPress (originalView, longPressPosition, longPressId);
}, "android.view.View");
Clazz.overrideMethod (c$, "showContextMenu", 
function () {
if (this.isPressed () && this.mSelectedPosition >= 0) {
var index = this.mSelectedPosition - this.mFirstPosition;
var v = this.getChildAt (index);
return this.dispatchLongPress (v, this.mSelectedPosition, this.mSelectedRowId);
}return false;
});
Clazz.defineMethod (c$, "dispatchLongPress", 
($fz = function (view, position, id) {
var handled = false;
if (this.mOnItemLongClickListener != null) {
handled = this.mOnItemLongClickListener.onItemLongClick (this, this.mDownTouchView, this.mDownTouchPosition, id);
}if (!handled) {
this.mContextMenuInfo =  new android.widget.AdapterView.AdapterContextMenuInfo (view, position, id);
handled = Clazz.superCall (this, android.widget.Gallery, "showContextMenuForChild", [this]);
}if (handled) {
}return handled;
}, $fz.isPrivate = true, $fz), "android.view.View,~N,~N");
Clazz.overrideMethod (c$, "dispatchKeyEvent", 
function (event) {
return event.dispatch (this, null, null);
}, "android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyDown", 
function (keyCode, event) {
switch (keyCode) {
case 37:
if (this.movePrevious ()) {
}return true;
case 39:
if (this.moveNext ()) {
}return true;
case 23:
case 13:
this.mReceivedInvokeKeyDown = true;
}
return Clazz.superCall (this, android.widget.Gallery, "onKeyDown", [keyCode, event]);
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyUp", 
function (keyCode, event) {
switch (keyCode) {
case 23:
case 13:
{
if (this.mReceivedInvokeKeyDown) {
if (this.mItemCount > 0) {
this.dispatchPress (this.mSelectedChild);
var selectedIndex = this.mSelectedPosition - this.mFirstPosition;
this.performItemClick (this.getChildAt (selectedIndex), this.mSelectedPosition, this.mAdapter.getItemId (this.mSelectedPosition));
}}this.mReceivedInvokeKeyDown = false;
return true;
}}
return Clazz.superCall (this, android.widget.Gallery, "onKeyUp", [keyCode, event]);
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "movePrevious", 
function () {
if (this.mItemCount > 0 && this.mSelectedPosition > 0) {
this.scrollToChild (this.mSelectedPosition - this.mFirstPosition - 1);
return true;
} else {
return false;
}});
Clazz.defineMethod (c$, "moveNext", 
function () {
if (this.mItemCount > 0 && this.mSelectedPosition < this.mItemCount - 1) {
this.scrollToChild (this.mSelectedPosition - this.mFirstPosition + 1);
return true;
} else {
return false;
}});
Clazz.defineMethod (c$, "scrollToChild", 
($fz = function (childPosition) {
var child = this.getChildAt (childPosition);
if (child != null) {
var distance = this.getCenterOfGallery () - android.widget.Gallery.getCenterOfView (child);
this.mFlingRunnable.startUsingDistance (distance);
return true;
}return false;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "setSelectedPositionInt", 
function (position) {
Clazz.superCall (this, android.widget.Gallery, "setSelectedPositionInt", [position]);
this.updateSelectedItemMetadata ();
}, "~N");
Clazz.defineMethod (c$, "updateSelectedItemMetadata", 
($fz = function () {
var oldSelectedChild = this.mSelectedChild;
var child = this.mSelectedChild = this.getChildAt (this.mSelectedPosition - this.mFirstPosition);
if (child == null) {
return ;
}child.setSelected (true);
child.setFocusable (true);
if (this.hasFocus ()) {
child.requestFocus ();
}if (oldSelectedChild != null) {
oldSelectedChild.setSelected (false);
oldSelectedChild.setFocusable (false);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "setGravity", 
function (gravity) {
if (this.mGravity != gravity) {
this.mGravity = gravity;
this.requestLayout ();
}}, "~N");
Clazz.overrideMethod (c$, "getChildDrawingOrder", 
function (childCount, i) {
var selectedIndex = this.mSelectedPosition - this.mFirstPosition;
if (selectedIndex < 0) return i;
if (i == childCount - 1) {
return selectedIndex;
} else if (i >= selectedIndex) {
return i + 1;
} else {
return i;
}}, "~N,~N");
Clazz.defineMethod (c$, "onFocusChanged", 
function (gainFocus, direction, previouslyFocusedRect) {
Clazz.superCall (this, android.widget.Gallery, "onFocusChanged", [gainFocus, direction, previouslyFocusedRect]);
if (gainFocus && this.mSelectedChild != null) {
this.mSelectedChild.requestFocus (direction);
}}, "~B,~N,android.graphics.Rect");
c$.$Gallery$FlingRunnable$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mLastFlingX = 0;
Clazz.instantialize (this, arguments);
}, android.widget.Gallery, "FlingRunnable", null, Runnable);
Clazz.makeConstructor (c$, 
function () {
});
Clazz.defineMethod (c$, "startCommon", 
($fz = function () {
this.b$["android.widget.Gallery"].removeCallbacks (this);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "startUsingVelocity", 
function (a) {
if (a == 0) return ;
this.startCommon ();
var b = a < 0 ? 2147483647 : 0;
this.mLastFlingX = b;
}, "~N");
Clazz.defineMethod (c$, "startUsingDistance", 
function (a) {
if (a == 0) return ;
this.startCommon ();
this.mLastFlingX = 0;
}, "~N");
Clazz.defineMethod (c$, "stop", 
function (a) {
this.b$["android.widget.Gallery"].removeCallbacks (this);
this.endFling (a);
}, "~B");
Clazz.defineMethod (c$, "endFling", 
($fz = function (a) {
if (a) this.b$["android.widget.Gallery"].scrollIntoSlots ();
}, $fz.isPrivate = true, $fz), "~B");
Clazz.overrideMethod (c$, "run", 
function () {
if (this.b$["android.widget.Gallery"].mItemCount == 0) {
this.endFling (true);
return ;
}this.b$["android.widget.Gallery"].mShouldStopFling = false;
});
c$ = Clazz.p0p ();
};
c$.$Gallery$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.widget, "Gallery$1", null, Runnable);
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["android.widget.Gallery"].mSuppressSelectionChanged = false;
this.b$["android.widget.Gallery"].selectionChanged ();
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.declareType (android.widget.Gallery, "LayoutParams", android.view.ViewGroup.LayoutParams);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"$TAG", "Gallery",
"localLOGV", false,
"SCROLL_TO_FLING_UNCERTAINTY_TIMEOUT", 250);
});
