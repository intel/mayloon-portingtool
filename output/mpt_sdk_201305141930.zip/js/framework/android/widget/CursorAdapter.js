﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.database.ContentObserver", "$.DataSetObserver", "android.widget.BaseAdapter", "$.CursorFilterClient", "$.Filterable"], "android.widget.CursorAdapter", ["android.os.Handler", "android.util.Log", "android.widget.CursorFilter", "java.lang.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mDataValid = false;
this.mAutoRequery = false;
this.mCursor = null;
this.mContext = null;
this.mRowIDColumn = 0;
this.mChangeObserver = null;
this.mDataSetObserver = null;
this.mCursorFilter = null;
this.mFilterQueryProvider = null;
if (!Clazz.isClassDefined ("android.widget.CursorAdapter.ChangeObserver")) {
android.widget.CursorAdapter.$CursorAdapter$ChangeObserver$ ();
}
if (!Clazz.isClassDefined ("android.widget.CursorAdapter.MyDataSetObserver")) {
android.widget.CursorAdapter.$CursorAdapter$MyDataSetObserver$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "CursorAdapter", android.widget.BaseAdapter, [android.widget.Filterable, android.widget.CursorFilterClient]);
Clazz.prepareFields (c$, function () {
this.mDataSetObserver = Clazz.innerTypeInstance (android.widget.CursorAdapter.MyDataSetObserver, this, null);
});
Clazz.makeConstructor (c$, 
function (context, c) {
Clazz.superConstructor (this, android.widget.CursorAdapter, []);
this.init (context, c, true);
}, "android.content.Context,android.database.Cursor");
Clazz.makeConstructor (c$, 
function (context, c, autoRequery) {
Clazz.superConstructor (this, android.widget.CursorAdapter, []);
this.init (context, c, autoRequery);
}, "android.content.Context,android.database.Cursor,~B");
Clazz.defineMethod (c$, "init", 
function (context, c, autoRequery) {
var cursorPresent = c != null;
this.mAutoRequery = autoRequery;
this.mCursor = c;
this.mDataValid = cursorPresent;
this.mContext = context;
this.mRowIDColumn = cursorPresent ? c.getColumnIndexOrThrow ("_id") : -1;
this.mChangeObserver = Clazz.innerTypeInstance (android.widget.CursorAdapter.ChangeObserver, this, null);
if (cursorPresent) {
c.registerContentObserver (this.mChangeObserver);
c.registerDataSetObserver (this.mDataSetObserver);
}}, "android.content.Context,android.database.Cursor,~B");
Clazz.overrideMethod (c$, "getCursor", 
function () {
return this.mCursor;
});
Clazz.overrideMethod (c$, "getCount", 
function () {
if (this.mDataValid && this.mCursor != null) {
return this.mCursor.getCount ();
} else {
return 0;
}});
Clazz.overrideMethod (c$, "getItem", 
function (position) {
if (this.mDataValid && this.mCursor != null) {
this.mCursor.moveToPosition (position);
return this.mCursor;
} else {
return null;
}}, "~N");
Clazz.overrideMethod (c$, "getItemId", 
function (position) {
if (this.mDataValid && this.mCursor != null) {
if (this.mCursor.moveToPosition (position)) {
return this.mCursor.getLong (this.mRowIDColumn);
} else {
return 0;
}} else {
return 0;
}}, "~N");
Clazz.overrideMethod (c$, "hasStableIds", 
function () {
return true;
});
Clazz.overrideMethod (c$, "getView", 
function (position, convertView, parent) {
if (!this.mDataValid) {
throw  new IllegalStateException ("this should only be called when the cursor is valid");
}if (!this.mCursor.moveToPosition (position)) {
throw  new IllegalStateException ("couldn't move cursor to position " + position);
}var v;
if (convertView == null) {
v = this.newView (this.mContext, this.mCursor, parent);
} else {
v = convertView;
}this.bindView (v, this.mContext, this.mCursor);
return v;
}, "~N,android.view.View,android.view.ViewGroup");
Clazz.defineMethod (c$, "newDropDownView", 
function (context, cursor, parent) {
return this.newView (context, cursor, parent);
}, "android.content.Context,android.database.Cursor,android.view.ViewGroup");
Clazz.overrideMethod (c$, "changeCursor", 
function (cursor) {
if (cursor === this.mCursor) {
return ;
}if (this.mCursor != null) {
this.mCursor.unregisterContentObserver (this.mChangeObserver);
this.mCursor.unregisterDataSetObserver (this.mDataSetObserver);
this.mCursor.close ();
}this.mCursor = cursor;
if (cursor != null) {
cursor.registerContentObserver (this.mChangeObserver);
cursor.registerDataSetObserver (this.mDataSetObserver);
this.mRowIDColumn = cursor.getColumnIndexOrThrow ("_id");
this.mDataValid = true;
this.notifyDataSetChanged ();
} else {
this.mRowIDColumn = -1;
this.mDataValid = false;
this.notifyDataSetInvalidated ();
}}, "android.database.Cursor");
Clazz.overrideMethod (c$, "convertToString", 
function (cursor) {
return cursor == null ? "" : cursor.toString ();
}, "android.database.Cursor");
Clazz.overrideMethod (c$, "runQueryOnBackgroundThread", 
function (constraint) {
if (this.mFilterQueryProvider != null) {
return this.mFilterQueryProvider.runQuery (constraint);
}return this.mCursor;
}, "CharSequence");
Clazz.overrideMethod (c$, "getFilter", 
function () {
if (this.mCursorFilter == null) {
this.mCursorFilter =  new android.widget.CursorFilter (this);
}return this.mCursorFilter;
});
Clazz.defineMethod (c$, "getFilterQueryProvider", 
function () {
return this.mFilterQueryProvider;
});
Clazz.defineMethod (c$, "setFilterQueryProvider", 
function (filterQueryProvider) {
this.mFilterQueryProvider = filterQueryProvider;
}, "android.widget.FilterQueryProvider");
Clazz.defineMethod (c$, "onContentChanged", 
function () {
if (this.mAutoRequery && this.mCursor != null && !this.mCursor.isClosed ()) {
if (false) android.util.Log.v ("Cursor", "Auto requerying " + this.mCursor + " due to update");
this.mDataValid = this.mCursor.requery ();
}});
c$.$CursorAdapter$ChangeObserver$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.widget.CursorAdapter, "ChangeObserver", android.database.ContentObserver);
Clazz.makeConstructor (c$, 
function () {
Clazz.superConstructor (this, android.widget.CursorAdapter.ChangeObserver, [ new android.os.Handler ()]);
});
Clazz.overrideMethod (c$, "deliverSelfNotifications", 
function () {
return true;
});
Clazz.overrideMethod (c$, "onChange", 
function (a) {
this.b$["android.widget.CursorAdapter"].onContentChanged ();
}, "~B");
c$ = Clazz.p0p ();
};
c$.$CursorAdapter$MyDataSetObserver$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.widget.CursorAdapter, "MyDataSetObserver", android.database.DataSetObserver);
Clazz.overrideMethod (c$, "onChanged", 
function () {
this.b$["android.widget.CursorAdapter"].mDataValid = true;
this.b$["android.widget.CursorAdapter"].notifyDataSetChanged ();
});
Clazz.overrideMethod (c$, "onInvalidated", 
function () {
this.b$["android.widget.CursorAdapter"].mDataValid = false;
this.b$["android.widget.CursorAdapter"].notifyDataSetInvalidated ();
});
c$ = Clazz.p0p ();
};
});
