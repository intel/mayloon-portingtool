﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.Checkable", "$.TextView"], "android.widget.CheckedTextView", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mChecked = false;
this.mCheckMarkResource = 0;
this.mCheckMarkDrawable = null;
this.mBasePaddingRight = 0;
this.mCheckMarkWidth = 0;
Clazz.instantialize (this, arguments);
}, android.widget, "CheckedTextView", android.widget.TextView, android.widget.Checkable);
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 0);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.CheckedTextView, [context, attrs, defStyle]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.CheckedTextView, defStyle, 0);
var d = a.getDrawable (1);
if (d != null) {
this.setCheckMarkDrawable (d);
}var checked = a.getBoolean (0, false);
this.setChecked (checked);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.overrideMethod (c$, "toggle", 
function () {
this.setChecked (!this.mChecked);
});
Clazz.overrideMethod (c$, "isChecked", 
function () {
return this.mChecked;
});
Clazz.overrideMethod (c$, "setChecked", 
function (checked) {
if (this.mChecked != checked) {
this.mChecked = checked;
this.refreshDrawableState ();
}}, "~B");
Clazz.defineMethod (c$, "setCheckMarkDrawable", 
function (resid) {
if (resid != 0 && resid == this.mCheckMarkResource) {
return ;
}this.mCheckMarkResource = resid;
var d = null;
if (this.mCheckMarkResource != 0) {
d = this.getResources ().getDrawable (this.mCheckMarkResource);
}this.setCheckMarkDrawable (d);
}, "~N");
Clazz.defineMethod (c$, "setCheckMarkDrawable", 
function (d) {
if (this.mCheckMarkDrawable != null) {
this.mCheckMarkDrawable.setCallback (null);
this.unscheduleDrawable (this.mCheckMarkDrawable);
}if (d != null) {
d.setCallback (this);
d.setVisible (this.getVisibility () == 0, false);
d.setState (android.widget.CheckedTextView.CHECKED_STATE_SET);
this.setMinHeight (d.getIntrinsicHeight ());
this.mCheckMarkWidth = d.getIntrinsicWidth ();
this.mPaddingRight = this.mCheckMarkWidth + this.mBasePaddingRight;
d.setState (this.getDrawableState ());
} else {
this.mPaddingRight = this.mBasePaddingRight;
}this.mCheckMarkDrawable = d;
this.requestLayout ();
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setPadding", 
function (left, top, right, bottom) {
Clazz.superCall (this, android.widget.CheckedTextView, "setPadding", [left, top, right, bottom]);
this.mBasePaddingRight = this.mPaddingRight;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "onDraw", 
function (canvas) {
Clazz.superCall (this, android.widget.CheckedTextView, "onDraw", [canvas]);
var checkMarkDrawable = this.mCheckMarkDrawable;
if (checkMarkDrawable != null) {
var verticalGravity = this.getGravity () & 112;
var height = checkMarkDrawable.getIntrinsicHeight ();
var y = 0;
switch (verticalGravity) {
case 80:
y = this.getHeight () - height;
break;
case 16:
y = Math.floor ((this.getHeight () - height) / 2);
break;
}
var right = this.getWidth ();
checkMarkDrawable.setBounds (right - this.mCheckMarkWidth - this.mBasePaddingRight, y, right - this.mBasePaddingRight, y + height);
checkMarkDrawable.draw (canvas);
}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "onCreateDrawableState", 
function (extraSpace) {
var drawableState = Clazz.superCall (this, android.widget.CheckedTextView, "onCreateDrawableState", [extraSpace + 1]);
if (this.isChecked ()) {
android.view.View.mergeDrawableStates (drawableState, android.widget.CheckedTextView.CHECKED_STATE_SET);
}return drawableState;
}, "~N");
Clazz.defineMethod (c$, "drawableStateChanged", 
function () {
Clazz.superCall (this, android.widget.CheckedTextView, "drawableStateChanged", []);
if (this.mCheckMarkDrawable != null) {
var myDrawableState = this.getDrawableState ();
this.mCheckMarkDrawable.setState (myDrawableState);
this.invalidate ();
}});
Clazz.defineMethod (c$, "dispatchPopulateAccessibilityEvent", 
function (event) {
var populated = Clazz.superCall (this, android.widget.CheckedTextView, "dispatchPopulateAccessibilityEvent", [event]);
if (!populated) {
event.setChecked (this.mChecked);
}return populated;
}, "android.view.accessibility.AccessibilityEvent");
Clazz.defineStatics (c$,
"CHECKED_STATE_SET", [16842912]);
});
