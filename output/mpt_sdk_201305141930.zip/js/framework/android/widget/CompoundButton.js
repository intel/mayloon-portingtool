﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.View", "android.widget.Button", "$.Checkable", "android.os.Parcelable.Creator"], "android.widget.CompoundButton", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mChecked = false;
this.mButtonResource = 0;
this.mBroadcasting = false;
this.mButtonDrawable = null;
this.mOnCheckedChangeListener = null;
this.mOnCheckedChangeWidgetListener = null;
Clazz.instantialize (this, arguments);
}, android.widget, "CompoundButton", android.widget.Button, android.widget.Checkable);
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 0);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.CompoundButton, [context, attrs, defStyle]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.CompoundButton, defStyle, 0);
var d = a.getDrawable (1);
if (d != null) {
this.setButtonDrawable (d);
}var checked = a.getBoolean (0, false);
this.setChecked (checked);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.overrideMethod (c$, "toggle", 
function () {
this.setChecked (!this.mChecked);
});
Clazz.defineMethod (c$, "performClick", 
function () {
this.toggle ();
return Clazz.superCall (this, android.widget.CompoundButton, "performClick", []);
});
Clazz.overrideMethod (c$, "isChecked", 
function () {
return this.mChecked;
});
Clazz.overrideMethod (c$, "setChecked", 
function (checked) {
if (this.mChecked != checked) {
this.mChecked = checked;
this.refreshDrawableState ();
if (this.mBroadcasting) {
return ;
}this.mBroadcasting = true;
if (this.mOnCheckedChangeListener != null) {
this.mOnCheckedChangeListener.onCheckedChanged (this, this.mChecked);
}if (this.mOnCheckedChangeWidgetListener != null) {
this.mOnCheckedChangeWidgetListener.onCheckedChanged (this, this.mChecked);
}this.mBroadcasting = false;
}}, "~B");
Clazz.defineMethod (c$, "setOnCheckedChangeListener", 
function (listener) {
this.mOnCheckedChangeListener = listener;
}, "android.widget.CompoundButton.OnCheckedChangeListener");
Clazz.defineMethod (c$, "setOnCheckedChangeWidgetListener", 
function (listener) {
this.mOnCheckedChangeWidgetListener = listener;
}, "android.widget.CompoundButton.OnCheckedChangeListener");
Clazz.defineMethod (c$, "setButtonDrawable", 
function (resid) {
if (resid != 0 && resid == this.mButtonResource) {
return ;
}this.mButtonResource = resid;
var d = null;
if (this.mButtonResource != 0) {
d = this.getResources ().getDrawable (this.mButtonResource);
}this.setButtonDrawable (d);
}, "~N");
Clazz.defineMethod (c$, "setButtonDrawable", 
function (d) {
if (d != null) {
if (this.mButtonDrawable != null) {
this.mButtonDrawable.setCallback (null);
this.unscheduleDrawable (this.mButtonDrawable);
}d.setCallback (this);
d.setState (this.getDrawableState ());
d.setVisible (this.getVisibility () == 0, false);
this.mButtonDrawable = d;
this.mButtonDrawable.setState (null);
this.setMinHeight (this.mButtonDrawable.getIntrinsicHeight ());
}this.refreshDrawableState ();
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "dispatchPopulateAccessibilityEvent", 
function (event) {
var populated = Clazz.superCall (this, android.widget.CompoundButton, "dispatchPopulateAccessibilityEvent", [event]);
if (!populated) {
var resourceId = 0;
if (this.mChecked) {
resourceId = 17040216;
} else {
resourceId = 17040217;
}var state = this.getResources ().getString (resourceId);
event.getText ().add (state);
event.setChecked (this.mChecked);
}return populated;
}, "android.view.accessibility.AccessibilityEvent");
Clazz.defineMethod (c$, "onDraw", 
function (canvas) {
Clazz.superCall (this, android.widget.CompoundButton, "onDraw", [canvas]);
var buttonDrawable = this.mButtonDrawable;
if (buttonDrawable != null) {
var verticalGravity = this.getGravity () & 112;
var height = buttonDrawable.getIntrinsicHeight ();
var y = 0;
switch (verticalGravity) {
case 80:
y = this.getHeight () - height;
break;
case 16:
y = Math.floor ((this.getHeight () - height) / 2);
break;
}
buttonDrawable.setBounds (0, y, buttonDrawable.getIntrinsicWidth (), y + height);
buttonDrawable.draw (canvas);
}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "onCreateDrawableState", 
function (extraSpace) {
var drawableState = Clazz.superCall (this, android.widget.CompoundButton, "onCreateDrawableState", [extraSpace + 1]);
if (this.isChecked ()) {
android.view.View.mergeDrawableStates (drawableState, android.widget.CompoundButton.CHECKED_STATE_SET);
}return drawableState;
}, "~N");
Clazz.defineMethod (c$, "drawableStateChanged", 
function () {
Clazz.superCall (this, android.widget.CompoundButton, "drawableStateChanged", []);
if (this.mButtonDrawable != null) {
var myDrawableState = this.getDrawableState ();
this.mButtonDrawable.setState (myDrawableState);
this.invalidate ();
}});
Clazz.defineMethod (c$, "verifyDrawable", 
function (who) {
return Clazz.superCall (this, android.widget.CompoundButton, "verifyDrawable", [who]) || who === this.mButtonDrawable;
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
this.setFreezesText (true);
var superState = Clazz.superCall (this, android.widget.CompoundButton, "onSaveInstanceState", []);
var ss =  new android.widget.CompoundButton.SavedState (superState);
ss.checked = this.isChecked ();
return ss;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
var ss = state;
Clazz.superCall (this, android.widget.CompoundButton, "onRestoreInstanceState", [ss.getSuperState ()]);
this.setChecked (ss.checked);
this.requestLayout ();
}, "android.os.Parcelable");
Clazz.declareInterface (android.widget.CompoundButton, "OnCheckedChangeListener");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.checked = false;
Clazz.instantialize (this, arguments);
}, android.widget.CompoundButton, "SavedState", android.view.View.BaseSavedState);
Clazz.makeConstructor (c$, 
($fz = function (a) {
Clazz.superConstructor (this, android.widget.CompoundButton.SavedState, [a]);
this.checked = (a.readValue (null)).booleanValue ();
}, $fz.isPrivate = true, $fz), "android.os.Parcel");
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
Clazz.superCall (this, android.widget.CompoundButton.SavedState, "writeToParcel", [a, b]);
a.writeValue (new Boolean (this.checked));
}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return "CompoundButton.SavedState{" + Integer.toHexString (System.identityHashCode (this)) + " checked=" + this.checked + "}";
});
c$.$CompoundButton$SavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.widget, "CompoundButton$SavedState$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.widget.CompoundButton.SavedState (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.$$CREATOR = c$.prototype.$$CREATOR = ((Clazz.isClassDefined ("android.widget.CompoundButton$SavedState$1") ? 0 : android.widget.CompoundButton.SavedState.$CompoundButton$SavedState$1$ ()), Clazz.innerTypeInstance (android.widget.CompoundButton$SavedState$1, this, null));
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"CHECKED_STATE_SET", [16842912]);
});
