﻿Clazz.declarePackage ("android.widget");
Clazz.load (null, "android.widget.OverScroller", ["android.util.FloatMath", "android.view.ViewConfiguration", "android.view.animation.AnimationUtils"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mMode = 0;
this.mScrollerX = null;
this.mScrollerY = null;
this.mInterpolator = null;
Clazz.instantialize (this, arguments);
}, android.widget, "OverScroller");
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, interpolator) {
this.construct (context, interpolator, 0.16, 0.16);
}, "android.content.Context,android.view.animation.Interpolator");
Clazz.makeConstructor (c$, 
function (context, interpolator, bounceCoefficientX, bounceCoefficientY) {
this.mInterpolator = interpolator;
this.mScrollerX =  new android.widget.OverScroller.MagneticOverScroller ();
this.mScrollerY =  new android.widget.OverScroller.MagneticOverScroller ();
android.widget.OverScroller.MagneticOverScroller.initializeFromContext (context);
this.mScrollerX.setBounceCoefficient (bounceCoefficientX);
this.mScrollerY.setBounceCoefficient (bounceCoefficientY);
}, "android.content.Context,android.view.animation.Interpolator,~N,~N");
Clazz.defineMethod (c$, "isFinished", 
function () {
return this.mScrollerX.mFinished && this.mScrollerY.mFinished;
});
Clazz.defineMethod (c$, "forceFinished", 
function (finished) {
this.mScrollerX.mFinished = this.mScrollerY.mFinished = finished;
}, "~B");
Clazz.defineMethod (c$, "getCurrX", 
function () {
return this.mScrollerX.mCurrentPosition;
});
Clazz.defineMethod (c$, "getCurrY", 
function () {
return this.mScrollerY.mCurrentPosition;
});
Clazz.defineMethod (c$, "getCurrVelocity", 
function () {
var squaredNorm = this.mScrollerX.mCurrVelocity * this.mScrollerX.mCurrVelocity;
squaredNorm += this.mScrollerY.mCurrVelocity * this.mScrollerY.mCurrVelocity;
return android.util.FloatMath.sqrt (squaredNorm);
});
Clazz.defineMethod (c$, "getStartX", 
function () {
return this.mScrollerX.mStart;
});
Clazz.defineMethod (c$, "getStartY", 
function () {
return this.mScrollerY.mStart;
});
Clazz.defineMethod (c$, "getFinalX", 
function () {
return this.mScrollerX.mFinal;
});
Clazz.defineMethod (c$, "getFinalY", 
function () {
return this.mScrollerY.mFinal;
});
Clazz.defineMethod (c$, "getDuration", 
function () {
return Math.max (this.mScrollerX.mDuration, this.mScrollerY.mDuration);
});
Clazz.defineMethod (c$, "extendDuration", 
function (extend) {
this.mScrollerX.extendDuration (extend);
this.mScrollerY.extendDuration (extend);
}, "~N");
Clazz.defineMethod (c$, "setFinalX", 
function (newX) {
this.mScrollerX.setFinalPosition (newX);
}, "~N");
Clazz.defineMethod (c$, "setFinalY", 
function (newY) {
this.mScrollerY.setFinalPosition (newY);
}, "~N");
Clazz.defineMethod (c$, "computeScrollOffset", 
function () {
if (this.isFinished ()) {
return false;
}switch (this.mMode) {
case 0:
var time = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
var elapsedTime = time - this.mScrollerX.mStartTime;
var duration = this.mScrollerX.mDuration;
if (elapsedTime < duration) {
var q = (elapsedTime) / duration;
if (this.mInterpolator != null) {
q = this.mInterpolator.getInterpolation (q);
}this.mScrollerX.updateScroll (q);
this.mScrollerY.updateScroll (q);
} else {
this.abortAnimation ();
}break;
case 1:
if (!this.mScrollerX.mFinished) {
if (!this.mScrollerX.update ()) {
if (!this.mScrollerX.continueWhenFinished ()) {
this.mScrollerX.finish ();
}}}if (!this.mScrollerY.mFinished) {
if (!this.mScrollerY.update ()) {
if (!this.mScrollerY.continueWhenFinished ()) {
this.mScrollerY.finish ();
}}}break;
}
return true;
});
Clazz.defineMethod (c$, "startScroll", 
function (startX, startY, dx, dy) {
this.startScroll (startX, startY, dx, dy, 250);
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "startScroll", 
function (startX, startY, dx, dy, duration) {
this.mMode = 0;
this.mScrollerX.startScroll (startX, dx, duration);
this.mScrollerY.startScroll (startY, dy, duration);
}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "springBack", 
function (startX, startY, minX, maxX, minY, maxY) {
this.mMode = 1;
var spingbackX = this.mScrollerX.springback (startX, minX, maxX);
var spingbackY = this.mScrollerY.springback (startY, minY, maxY);
return spingbackX || spingbackY;
}, "~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "fling", 
function (startX, startY, velocityX, velocityY, minX, maxX, minY, maxY) {
this.fling (startX, startY, velocityX, velocityY, minX, maxX, minY, maxY, 0, 0);
}, "~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "fling", 
function (startX, startY, velocityX, velocityY, minX, maxX, minY, maxY, overX, overY) {
this.mMode = 1;
this.mScrollerX.fling (startX, velocityX, minX, maxX, overX);
this.mScrollerY.fling (startY, velocityY, minY, maxY, overY);
}, "~N,~N,~N,~N,~N,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "notifyHorizontalEdgeReached", 
function (startX, finalX, overX) {
this.mScrollerX.notifyEdgeReached (startX, finalX, overX);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "notifyVerticalEdgeReached", 
function (startY, finalY, overY) {
this.mScrollerY.notifyEdgeReached (startY, finalY, overY);
}, "~N,~N,~N");
Clazz.defineMethod (c$, "isOverScrolled", 
function () {
return ((!this.mScrollerX.mFinished && this.mScrollerX.mState != 0) || (!this.mScrollerY.mFinished && this.mScrollerY.mState != 0));
});
Clazz.defineMethod (c$, "abortAnimation", 
function () {
this.mScrollerX.finish ();
this.mScrollerY.finish ();
});
Clazz.defineMethod (c$, "timePassed", 
function () {
var time = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
var startTime = Math.min (this.mScrollerX.mStartTime, this.mScrollerY.mStartTime);
return (time - startTime);
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mStart = 0;
this.mCurrentPosition = 0;
this.mFinal = 0;
this.mVelocity = 0;
this.mCurrVelocity = 0;
this.mDeceleration = 0;
this.mStartTime = 0;
this.mDuration = 0;
this.mFinished = false;
this.mState = 0;
this.mOver = 0;
this.mBounceCoefficient = 0.16;
Clazz.instantialize (this, arguments);
}, android.widget.OverScroller, "MagneticOverScroller");
c$.initializeFromContext = Clazz.defineMethod (c$, "initializeFromContext", 
function (a) {
var b = a.getResources ().getDisplayMetrics ().density * 160.0;
($t$ = android.widget.OverScroller.MagneticOverScroller.GRAVITY = 9.80665 * 39.37 * b * android.view.ViewConfiguration.getScrollFriction (), android.widget.OverScroller.MagneticOverScroller.prototype.GRAVITY = android.widget.OverScroller.MagneticOverScroller.GRAVITY, $t$);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function () {
this.mFinished = true;
});
Clazz.defineMethod (c$, "updateScroll", 
function (a) {
this.mCurrentPosition = this.mStart + Math.round (a * (this.mFinal - this.mStart));
}, "~N");
c$.getDeceleration = Clazz.defineMethod (c$, "getDeceleration", 
function (a) {
return a > 0 ? ($t$ = - android.widget.OverScroller.MagneticOverScroller.GRAVITY, android.widget.OverScroller.MagneticOverScroller.prototype.GRAVITY = android.widget.OverScroller.MagneticOverScroller.GRAVITY, $t$) : android.widget.OverScroller.MagneticOverScroller.GRAVITY;
}, "~N");
c$.computeDuration = Clazz.defineMethod (c$, "computeDuration", 
function (a, b, c, d) {
var e = a - b;
var f = c * c - 2.0 * d * e;
if (f >= 0.0) {
var g = Math.sqrt (f);
if (d < 0.0) {
g = -g;
}return Math.round ((1000.0 * (-c - g) / d));
}return 0;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "startScroll", 
function (a, b, c) {
this.mFinished = false;
this.mStart = a;
this.mFinal = a + b;
this.mStartTime = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
this.mDuration = c;
this.mDeceleration = 0.0;
this.mVelocity = 0;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "fling", 
function (a, b, c, d) {
this.mFinished = false;
this.mStart = a;
this.mStartTime = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
this.mVelocity = b;
this.mDeceleration = android.widget.OverScroller.MagneticOverScroller.getDeceleration (b);
if (this.mStart < c) {
this.mDuration = 0;
this.mFinal = c;
return ;
}if (this.mStart > d) {
this.mDuration = 0;
this.mFinal = d;
return ;
}this.mDuration = Math.round ((-1000.0 * b / this.mDeceleration));
this.mFinal = a - Math.round ((b * b) / (2.0 * this.mDeceleration));
if (this.mFinal < c) {
this.mFinal = c;
this.mDuration = android.widget.OverScroller.MagneticOverScroller.computeDuration (this.mStart, c, this.mVelocity, this.mDeceleration);
}if (this.mFinal > d) {
this.mFinal = d;
this.mDuration = android.widget.OverScroller.MagneticOverScroller.computeDuration (this.mStart, d, this.mVelocity, this.mDeceleration);
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "finish", 
function () {
this.mCurrentPosition = this.mFinal;
this.mFinished = true;
});
Clazz.defineMethod (c$, "setFinalPosition", 
function (a) {
this.mFinal = a;
this.mFinished = false;
}, "~N");
Clazz.defineMethod (c$, "extendDuration", 
function (a) {
var b = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
var c = (b - this.mStartTime);
this.mDuration = c + a;
this.mFinished = false;
}, "~N");
Clazz.defineMethod (c$, "setBounceCoefficient", 
function (a) {
this.mBounceCoefficient = a;
}, "~N");
Clazz.defineMethod (c$, "springback", 
function (a, b, c) {
this.mFinished = true;
this.mStart = a;
this.mVelocity = 0;
this.mStartTime = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
this.mDuration = 0;
if (a < b) {
this.startSpringback (a, b, false);
} else if (a > c) {
this.startSpringback (a, c, true);
}return !this.mFinished;
}, "~N,~N,~N");
Clazz.defineMethod (c$, "startSpringback", 
($fz = function (a, b, c) {
this.mFinished = false;
this.mState = 2;
this.mStart = this.mFinal = b;
this.mDuration = 200;
this.mStartTime -= 100;
this.mVelocity = Math.round ((Math.abs (b - a) * 15.707964 * (c ? 1.0 : -1.0)));
}, $fz.isPrivate = true, $fz), "~N,~N,~B");
Clazz.defineMethod (c$, "fling", 
function (a, b, c, d, e) {
this.mState = 0;
this.mOver = e;
this.mFinished = false;
this.mStart = a;
this.mStartTime = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
this.mVelocity = b;
this.mDeceleration = android.widget.OverScroller.MagneticOverScroller.getDeceleration (b);
this.mDuration = Math.round ((-1000.0 * b / this.mDeceleration));
this.mFinal = a - Math.round ((b * b) / (2.0 * this.mDeceleration));
if (this.mFinal < c) {
this.mFinal = c;
this.mDuration = android.widget.OverScroller.MagneticOverScroller.computeDuration (this.mStart, c, this.mVelocity, this.mDeceleration);
}if (this.mFinal > d) {
this.mFinal = d;
this.mDuration = android.widget.OverScroller.MagneticOverScroller.computeDuration (this.mStart, d, this.mVelocity, this.mDeceleration);
}if (a > d) {
if (a >= d + e) {
this.springback (d + e, c, d);
} else {
if (b <= 0) {
this.springback (a, c, d);
} else {
var f = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
var g = Math.atan ((a - d) * 15.707964 / b) / 15.707964;
this.mStartTime = Math.round ((f - 1000.0 * g));
this.mStart = d;
this.mVelocity = Math.round ((b / Math.cos (g * 15.707964)));
this.onEdgeReached ();
}}} else {
if (a < c) {
if (a <= c - e) {
this.springback (c - e, c, d);
} else {
if (b >= 0) {
this.springback (a, c, d);
} else {
var f = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
var g = Math.atan ((a - c) * 15.707964 / b) / 15.707964;
this.mStartTime = Math.round ((f - 1000.0 * g));
this.mStart = c;
this.mVelocity = Math.round ((b / Math.cos (g * 15.707964)));
this.onEdgeReached ();
}}}}}, "~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "notifyEdgeReached", 
function (a, b, c) {
this.mDeceleration = android.widget.OverScroller.MagneticOverScroller.getDeceleration (this.mVelocity);
var d = this.mCurrVelocity / this.mDeceleration;
var e = b - a;
var f = -Math.sqrt ((2.0 * e / this.mDeceleration) + (d * d));
this.mVelocity = Math.round ((this.mDeceleration * f));
this.mStart = b;
this.mOver = c;
var g = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
this.mStartTime = Math.round ((g - 1000.0 * (d - f)));
this.onEdgeReached ();
}, "~N,~N,~N");
Clazz.defineMethod (c$, "onEdgeReached", 
($fz = function () {
var a = this.mVelocity / 15.707964;
if (Math.abs (a) < this.mOver) {
this.mState = 2;
this.mFinal = this.mStart;
this.mDuration = 200;
} else {
this.mState = 1;
var b = this.mVelocity > 0 ? this.mOver : -this.mOver;
this.mFinal = this.mStart + b;
this.mDuration = Math.round ((1000.0 * Math.asin (b / a) / 15.707964));
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "continueWhenFinished", 
function () {
switch (this.mState) {
case 0:
var a = Math.round ((-1000.0 * this.mVelocity / this.mDeceleration));
if (this.mDuration < a) {
this.mStart = this.mFinal;
this.mVelocity = Math.round ((this.mVelocity + this.mDeceleration * this.mDuration / 1000.0));
this.mStartTime += this.mDuration;
this.onEdgeReached ();
} else {
return false;
}break;
case 1:
this.mStartTime += this.mDuration;
this.startSpringback (this.mFinal, this.mFinal - (this.mVelocity > 0 ? this.mOver : -this.mOver), this.mVelocity > 0);
break;
case 2:
this.mVelocity = Math.round ((this.mVelocity * this.mBounceCoefficient));
if (Math.abs (this.mVelocity) < 3.4028235E38) {
return false;
}this.mStartTime += this.mDuration;
break;
}
this.update ();
return true;
});
Clazz.defineMethod (c$, "update", 
function () {
var a = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
var b = a - this.mStartTime;
if (b > this.mDuration) {
return false;
}var c;
var d = b / 1000.0;
if (this.mState == 0) {
this.mCurrVelocity = this.mVelocity + this.mDeceleration * d;
c = this.mVelocity * d + this.mDeceleration * d * d / 2.0;
} else {
var e = d * 15.707964;
this.mCurrVelocity = this.mVelocity * Math.cos (e);
c = this.mVelocity / 15.707964 * Math.sin (e);
}this.mCurrentPosition = this.mStart + Math.round (c);
return true;
});
Clazz.defineStatics (c$,
"GRAVITY", 0,
"TO_EDGE", 0,
"TO_BOUNDARY", 1,
"TO_BOUNCE", 2,
"OVERSCROLL_SPRINGBACK_DURATION", 200,
"TIME_COEF", 15.707964,
"MINIMUM_VELOCITY_FOR_BOUNCE", 3.4028235E38,
"DEFAULT_BOUNCE_COEFFICIENT", 0.16);
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"DEFAULT_DURATION", 250,
"SCROLL_MODE", 0,
"FLING_MODE", 1);
});
