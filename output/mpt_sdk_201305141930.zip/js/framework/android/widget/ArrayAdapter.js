﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.BaseAdapter", "$.Filter", "$.Filterable"], "android.widget.ArrayAdapter", ["android.util.Log", "java.lang.IllegalStateException", "$.NullPointerException", "java.util.ArrayList", "$.Arrays", "$.Collections"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mObjects = null;
this.mLock = null;
this.mResource = 0;
this.mDropDownResource = 0;
this.mFieldId = 0;
this.mNotifyOnChange = true;
this.mContext = null;
this.mOriginalValues = null;
this.mFilter = null;
this.mInflater = null;
if (!Clazz.isClassDefined ("android.widget.ArrayAdapter.ArrayFilter")) {
android.widget.ArrayAdapter.$ArrayAdapter$ArrayFilter$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "ArrayAdapter", android.widget.BaseAdapter, android.widget.Filterable);
Clazz.prepareFields (c$, function () {
this.mLock =  new JavaObject ();
});
Clazz.makeConstructor (c$, 
function (context, textViewResourceId) {
Clazz.superConstructor (this, android.widget.ArrayAdapter, []);
this.init (context, textViewResourceId, 0,  new java.util.ArrayList ());
}, "android.content.Context,~N");
Clazz.makeConstructor (c$, 
function (context, resource, textViewResourceId) {
Clazz.superConstructor (this, android.widget.ArrayAdapter, []);
this.init (context, resource, textViewResourceId,  new java.util.ArrayList ());
}, "android.content.Context,~N,~N");
Clazz.makeConstructor (c$, 
function (context, textViewResourceId, objects) {
Clazz.superConstructor (this, android.widget.ArrayAdapter, []);
this.init (context, textViewResourceId, 0, java.util.Arrays.asList (objects));
}, "android.content.Context,~N,~A");
Clazz.makeConstructor (c$, 
function (context, resource, textViewResourceId, objects) {
Clazz.superConstructor (this, android.widget.ArrayAdapter, []);
this.init (context, resource, textViewResourceId, java.util.Arrays.asList (objects));
}, "android.content.Context,~N,~N,~A");
Clazz.makeConstructor (c$, 
function (context, textViewResourceId, objects) {
Clazz.superConstructor (this, android.widget.ArrayAdapter, []);
this.init (context, textViewResourceId, 0, objects);
}, "android.content.Context,~N,java.util.List");
Clazz.makeConstructor (c$, 
function (context, resource, textViewResourceId, objects) {
Clazz.superConstructor (this, android.widget.ArrayAdapter, []);
this.init (context, resource, textViewResourceId, objects);
}, "android.content.Context,~N,~N,java.util.List");
Clazz.defineMethod (c$, "add", 
function (object) {
if (this.mOriginalValues != null) {
{
this.mOriginalValues.add (object);
if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}} else {
this.mObjects.add (object);
if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}}, "~O");
Clazz.defineMethod (c$, "insert", 
function (object, index) {
if (this.mOriginalValues != null) {
{
this.mOriginalValues.add (index, object);
if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}} else {
this.mObjects.add (index, object);
if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}}, "~O,~N");
Clazz.defineMethod (c$, "remove", 
function (object) {
if (this.mOriginalValues != null) {
{
this.mOriginalValues.remove (object);
}} else {
this.mObjects.remove (object);
}if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}, "~O");
Clazz.defineMethod (c$, "clear", 
function () {
if (this.mOriginalValues != null) {
{
this.mOriginalValues.clear ();
}} else {
this.mObjects.clear ();
}if (this.mNotifyOnChange) this.notifyDataSetChanged ();
});
Clazz.defineMethod (c$, "sort", 
function (comparator) {
java.util.Collections.sort (this.mObjects, comparator);
if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}, "java.util.Comparator");
Clazz.defineMethod (c$, "notifyDataSetChanged", 
function () {
Clazz.superCall (this, android.widget.ArrayAdapter, "notifyDataSetChanged", []);
this.mNotifyOnChange = true;
});
Clazz.defineMethod (c$, "setNotifyOnChange", 
function (notifyOnChange) {
this.mNotifyOnChange = notifyOnChange;
}, "~B");
Clazz.defineMethod (c$, "init", 
($fz = function (context, resource, textViewResourceId, objects) {
if (context == null) {
throw  new NullPointerException ("ArrayAdapter.init() -> context is null");
}this.mContext = context;
this.mInflater = context.getSystemService ("layout_inflater");
this.mResource = this.mDropDownResource = resource;
this.mObjects = objects;
this.mFieldId = textViewResourceId;
}, $fz.isPrivate = true, $fz), "android.content.Context,~N,~N,java.util.List");
Clazz.defineMethod (c$, "getContext", 
function () {
return this.mContext;
});
Clazz.overrideMethod (c$, "getCount", 
function () {
return this.mObjects.size ();
});
Clazz.overrideMethod (c$, "getItem", 
function (position) {
return this.mObjects.get (position);
}, "~N");
Clazz.defineMethod (c$, "getPosition", 
function (item) {
return this.mObjects.indexOf (item);
}, "~O");
Clazz.overrideMethod (c$, "getItemId", 
function (position) {
return position;
}, "~N");
Clazz.overrideMethod (c$, "getView", 
function (position, convertView, parent) {
return this.createViewFromResource (position, convertView, parent, this.mResource);
}, "~N,android.view.View,android.view.ViewGroup");
Clazz.defineMethod (c$, "createViewFromResource", 
($fz = function (position, convertView, parent, resource) {
var view;
var text;
if (convertView == null) {
view = this.mInflater.inflate (resource, parent, false);
} else {
view = convertView;
}try {
if (this.mFieldId == 0) {
if (!(Clazz.instanceOf (view, android.widget.TextView))) {
throw  new IllegalStateException ("ArrayAdapter.createViewFromResource view is not a TextView");
}text = view;
} else {
text = view.findViewById (this.mFieldId);
}} catch (e) {
if (Clazz.instanceOf (e, ClassCastException)) {
android.util.Log.e ("ArrayAdapter", "You must supply a resource ID for a TextView");
throw  new IllegalStateException ("ArrayAdapter requires the resource ID to be a TextView", e);
} else {
throw e;
}
}
var item = this.getItem (position);
if (Clazz.instanceOf (item, CharSequence)) {
text.setText (item);
} else {
text.setText (item.toString ());
}return view;
}, $fz.isPrivate = true, $fz), "~N,android.view.View,android.view.ViewGroup,~N");
Clazz.defineMethod (c$, "setDropDownViewResource", 
function (resource) {
this.mDropDownResource = resource;
}, "~N");
Clazz.overrideMethod (c$, "getDropDownView", 
function (position, convertView, parent) {
return this.createViewFromResource (position, convertView, parent, this.mDropDownResource);
}, "~N,android.view.View,android.view.ViewGroup");
c$.createFromResource = Clazz.defineMethod (c$, "createFromResource", 
function (context, textArrayResId, textViewResId) {
if (context == null) {
throw  new NullPointerException ("ArrayAdapter.createFromResource() -> context is null");
}var strings = context.getResources ().getTextArray (textArrayResId);
return  new android.widget.ArrayAdapter (context, textViewResId, strings);
}, "android.content.Context,~N,~N");
Clazz.overrideMethod (c$, "getFilter", 
function () {
if (this.mFilter == null) {
this.mFilter = Clazz.innerTypeInstance (android.widget.ArrayAdapter.ArrayFilter, this, null);
}return this.mFilter;
});
Clazz.defineMethod (c$, "addAll", 
function (collection) {
if (this.mOriginalValues != null) {
{
this.mOriginalValues.addAll (collection);
if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}} else {
this.mObjects.addAll (collection);
if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}}, "java.util.Collection");
Clazz.defineMethod (c$, "addAll", 
function (items) {
if (this.mOriginalValues != null) {
{
for (var item, $item = 0, $$item = items; $item < $$item.length && ((item = $$item[$item]) || true); $item++) {
this.mOriginalValues.add (item);
}
if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}} else {
for (var item, $item = 0, $$item = items; $item < $$item.length && ((item = $$item[$item]) || true); $item++) {
this.mObjects.add (item);
}
if (this.mNotifyOnChange) this.notifyDataSetChanged ();
}}, "~A");
c$.$ArrayAdapter$ArrayFilter$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.widget.ArrayAdapter, "ArrayFilter", android.widget.Filter);
Clazz.overrideMethod (c$, "performFiltering", 
function (a) {
var b =  new android.widget.Filter.FilterResults ();
if (this.b$["android.widget.ArrayAdapter"].mOriginalValues == null) {
{
this.b$["android.widget.ArrayAdapter"].mOriginalValues =  new java.util.ArrayList (this.b$["android.widget.ArrayAdapter"].mObjects);
}}if (a == null || a.length () == 0) {
{
var c =  new java.util.ArrayList (this.b$["android.widget.ArrayAdapter"].mOriginalValues);
b.values = c;
b.count = c.size ();
}} else {
var c = a.toString ().toLowerCase ();
var d = this.b$["android.widget.ArrayAdapter"].mOriginalValues;
var e = d.size ();
var f =  new java.util.ArrayList (e);
for (var g = 0; g < e; g++) {
var h = d.get (g);
var i = h.toString ().toLowerCase ();
if (i.startsWith (c)) {
f.add (h);
} else {
var j = i.$plit (" ");
var k = j.length;
for (var l = 0; l < k; l++) {
if (j[l].startsWith (c)) {
f.add (h);
break;
}}
}}
b.values = f;
b.count = f.size ();
}return b;
}, "CharSequence");
Clazz.overrideMethod (c$, "publishResults", 
function (a, b) {
this.b$["android.widget.ArrayAdapter"].mObjects = b.values;
if (b.count > 0) {
this.b$["android.widget.ArrayAdapter"].notifyDataSetChanged ();
} else {
}}, "CharSequence,android.widget.Filter.FilterResults");
c$ = Clazz.p0p ();
};
});
