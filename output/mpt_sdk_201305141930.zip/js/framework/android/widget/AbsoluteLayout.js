﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.ViewGroup"], "android.widget.AbsoluteLayout", ["com.android.internal.R"], function () {
c$ = Clazz.declareType (android.widget, "AbsoluteLayout", android.view.ViewGroup);
Clazz.overrideMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
var count = this.getChildCount ();
var maxHeight = 0;
var maxWidth = 0;
this.measureChildren (widthMeasureSpec, heightMeasureSpec);
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (child.getVisibility () != 8) {
var childRight;
var childBottom;
var lp = child.getLayoutParams ();
childRight = lp.x + child.getMeasuredWidth ();
childBottom = lp.y + child.getMeasuredHeight ();
maxWidth = Math.max (maxWidth, childRight);
maxHeight = Math.max (maxHeight, childBottom);
}}
maxWidth += this.mPaddingLeft + this.mPaddingRight;
maxHeight += this.mPaddingTop + this.mPaddingBottom;
maxHeight = Math.max (maxHeight, this.getSuggestedMinimumHeight ());
maxWidth = Math.max (maxWidth, this.getSuggestedMinimumWidth ());
this.setMeasuredDimension (android.view.View.resolveSize (maxWidth, widthMeasureSpec), android.view.View.resolveSize (maxHeight, heightMeasureSpec));
}, "~N,~N");
Clazz.overrideMethod (c$, "generateDefaultLayoutParams", 
function () {
return  new android.widget.AbsoluteLayout.LayoutParams (-2, -2, 0, 0);
});
Clazz.overrideMethod (c$, "onLayout", 
function (changed, l, t, r, b) {
var count = this.getChildCount ();
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (child.getVisibility () != 8) {
var lp = child.getLayoutParams ();
var childLeft = this.mPaddingLeft + lp.x;
var childTop = this.mPaddingTop + lp.y;
child.layout (childLeft, childTop, childLeft + child.getMeasuredWidth (), childTop + child.getMeasuredHeight ());
}}
}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (attrs) {
return  new android.widget.AbsoluteLayout.LayoutParams (this.getContext (), attrs);
}, "android.util.AttributeSet");
Clazz.overrideMethod (c$, "checkLayoutParams", 
function (p) {
return Clazz.instanceOf (p, android.widget.AbsoluteLayout.LayoutParams);
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (p) {
return  new android.widget.AbsoluteLayout.LayoutParams (p);
}, "android.view.ViewGroup.LayoutParams");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.x = 0;
this.y = 0;
Clazz.instantialize (this, arguments);
}, android.widget.AbsoluteLayout, "LayoutParams", android.view.ViewGroup.LayoutParams);
Clazz.makeConstructor (c$, 
function (a, b, c, d) {
Clazz.superConstructor (this, android.widget.AbsoluteLayout.LayoutParams, [a, b]);
this.x = c;
this.y = d;
}, "~N,~N,~N,~N");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.widget.AbsoluteLayout.LayoutParams, [a, b]);
var c = a.obtainStyledAttributes (b, com.android.internal.R.styleable.AbsoluteLayout_Layout);
this.x = c.getDimensionPixelOffset (0, 0);
this.y = c.getDimensionPixelOffset (1, 0);
c.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.overrideMethod (c$, "debug", 
function (a) {
return a + "Absolute.LayoutParams={width=" + android.view.ViewGroup.LayoutParams.sizeToString (this.width) + ", height=" + android.view.ViewGroup.LayoutParams.sizeToString (this.height) + " x=" + this.x + " y=" + this.y + "}";
}, "~S");
c$ = Clazz.p0p ();
});
