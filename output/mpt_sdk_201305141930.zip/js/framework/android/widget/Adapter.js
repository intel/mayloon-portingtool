﻿Clazz.declarePackage ("android.widget");
c$ = Clazz.declareInterface (android.widget, "Adapter");
Clazz.defineStatics (c$,
"IGNORE_ITEM_VIEW_TYPE", -1,
"NO_SELECTION", -2147483648);
