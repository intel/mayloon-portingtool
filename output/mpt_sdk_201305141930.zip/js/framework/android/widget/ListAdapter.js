﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.Adapter"], "android.widget.ListAdapter", null, function () {
Clazz.declareInterface (android.widget, "ListAdapter", android.widget.Adapter);
});
