﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.ImageView"], "android.widget.ImageButton", null, function () {
c$ = Clazz.declareType (android.widget, "ImageButton", android.widget.ImageView);
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842866);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.ImageButton, [context, attrs, defStyle]);
this.setFocusable (true);
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.overrideMethod (c$, "onSetAlpha", 
function (alpha) {
return false;
}, "~N");
});
