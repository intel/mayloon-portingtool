﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.View", "android.widget.AdapterView", "android.graphics.Rect", "android.os.Parcelable.Creator", "android.util.SparseArray"], "android.widget.AbsSpinner", ["android.view.ViewGroup", "android.widget.ArrayAdapter", "com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mAdapter = null;
this.mHeightMeasureSpec = 0;
this.mWidthMeasureSpec = 0;
this.$mBlockLayoutRequests = false;
this.mSelectionLeftPadding = 0;
this.mSelectionTopPadding = 0;
this.mSelectionRightPadding = 0;
this.mSelectionBottomPadding = 0;
this.mSpinnerPadding = null;
this.mRecycler = null;
this.mDataSetObserver = null;
this.mTouchFrame = null;
if (!Clazz.isClassDefined ("android.widget.AbsSpinner.RecycleBin")) {
android.widget.AbsSpinner.$AbsSpinner$RecycleBin$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "AbsSpinner", android.widget.AdapterView);
Clazz.prepareFields (c$, function () {
this.mSpinnerPadding =  new android.graphics.Rect ();
this.mRecycler = Clazz.innerTypeInstance (android.widget.AbsSpinner.RecycleBin, this, null);
});
Clazz.makeConstructor (c$, 
function (context) {
Clazz.superConstructor (this, android.widget.AbsSpinner, [context]);
this.initAbsSpinner ();
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 0);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.AbsSpinner, [context, attrs, defStyle]);
this.initAbsSpinner ();
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.AbsSpinner, defStyle, 0);
var entries = a.getTextArray (0);
if (entries != null) {
var adapter =  new android.widget.ArrayAdapter (context, 17367048, entries);
adapter.setDropDownViewResource (17367049);
this.setAdapter (adapter);
}a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "initAbsSpinner", 
($fz = function () {
this.setFocusable (true);
this.setWillNotDraw (false);
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "setAdapter", 
function (adapter) {
if (null != this.mAdapter) {
this.mAdapter.unregisterDataSetObserver (this.mDataSetObserver);
this.resetList ();
}this.mAdapter = adapter;
this.mOldSelectedPosition = -1;
this.mOldSelectedRowId = -9223372036854775808;
if (this.mAdapter != null) {
this.mOldItemCount = this.mItemCount;
this.mItemCount = this.mAdapter.getCount ();
this.checkFocus ();
this.mDataSetObserver = Clazz.innerTypeInstance (android.widget.AdapterView.AdapterDataSetObserver, this, null);
this.mAdapter.registerDataSetObserver (this.mDataSetObserver);
var position = this.mItemCount > 0 ? 0 : -1;
this.setSelectedPositionInt (position);
this.setNextSelectedPositionInt (position);
if (this.mItemCount == 0) {
this.checkSelectionChanged ();
}} else {
this.checkFocus ();
this.resetList ();
this.checkSelectionChanged ();
}this.requestLayout ();
}, "android.widget.SpinnerAdapter");
Clazz.defineMethod (c$, "resetList", 
function () {
this.mDataChanged = false;
this.mNeedSync = false;
this.removeAllViewsInLayout ();
this.mOldSelectedPosition = -1;
this.mOldSelectedRowId = -9223372036854775808;
this.setSelectedPositionInt (-1);
this.setNextSelectedPositionInt (-1);
this.invalidate ();
});
Clazz.overrideMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
var widthMode = android.view.View.MeasureSpec.getMode (widthMeasureSpec);
var widthSize;
var heightSize;
this.mSpinnerPadding.left = this.mPaddingLeft > this.mSelectionLeftPadding ? this.mPaddingLeft : this.mSelectionLeftPadding;
this.mSpinnerPadding.top = this.mPaddingTop > this.mSelectionTopPadding ? this.mPaddingTop : this.mSelectionTopPadding;
this.mSpinnerPadding.right = this.mPaddingRight > this.mSelectionRightPadding ? this.mPaddingRight : this.mSelectionRightPadding;
this.mSpinnerPadding.bottom = this.mPaddingBottom > this.mSelectionBottomPadding ? this.mPaddingBottom : this.mSelectionBottomPadding;
if (this.mDataChanged) {
this.handleDataChanged ();
}var preferredHeight = 0;
var preferredWidth = 0;
var needsMeasuring = true;
var selectedPosition = this.getSelectedItemPosition ();
if (selectedPosition >= 0 && this.mAdapter != null && selectedPosition < this.mAdapter.getCount ()) {
var view = this.mRecycler.get (selectedPosition);
if (view == null) {
view = this.mAdapter.getView (selectedPosition, null, this);
}if (view != null) {
this.mRecycler.put (selectedPosition, view);
}if (view != null) {
if (view.getLayoutParams () == null) {
this.$mBlockLayoutRequests = true;
view.setLayoutParams (this.generateDefaultLayoutParams ());
this.$mBlockLayoutRequests = false;
}this.measureChild (view, widthMeasureSpec, heightMeasureSpec);
preferredHeight = this.getChildHeight (view) + this.mSpinnerPadding.top + this.mSpinnerPadding.bottom;
preferredWidth = this.getChildWidth (view) + this.mSpinnerPadding.left + this.mSpinnerPadding.right;
needsMeasuring = false;
}}if (needsMeasuring) {
preferredHeight = this.mSpinnerPadding.top + this.mSpinnerPadding.bottom;
if (widthMode == 0) {
preferredWidth = this.mSpinnerPadding.left + this.mSpinnerPadding.right;
}}preferredHeight = Math.max (preferredHeight, this.getSuggestedMinimumHeight ());
preferredWidth = Math.max (preferredWidth, this.getSuggestedMinimumWidth ());
heightSize = android.view.View.resolveSize (preferredHeight, heightMeasureSpec);
widthSize = android.view.View.resolveSize (preferredWidth, widthMeasureSpec);
this.setMeasuredDimension (widthSize, heightSize);
this.mHeightMeasureSpec = heightMeasureSpec;
this.mWidthMeasureSpec = widthMeasureSpec;
}, "~N,~N");
Clazz.defineMethod (c$, "getChildHeight", 
function (child) {
return child.getMeasuredHeight ();
}, "android.view.View");
Clazz.defineMethod (c$, "getChildWidth", 
function (child) {
return child.getMeasuredWidth ();
}, "android.view.View");
Clazz.overrideMethod (c$, "generateDefaultLayoutParams", 
function () {
return  new android.view.ViewGroup.LayoutParams (-1, -2);
});
Clazz.defineMethod (c$, "recycleAllViews", 
function () {
var childCount = this.getChildCount ();
var recycleBin = this.mRecycler;
var position = this.mFirstPosition;
for (var i = 0; i < childCount; i++) {
var v = this.getChildAt (i);
var index = position + i;
recycleBin.put (index, v);
}
});
Clazz.defineMethod (c$, "setSelection", 
function (position, animate) {
var shouldAnimate = animate && this.mFirstPosition <= position && position <= this.mFirstPosition + this.getChildCount () - 1;
this.setSelectionInt (position, shouldAnimate);
}, "~N,~B");
Clazz.defineMethod (c$, "setSelection", 
function (position) {
this.setNextSelectedPositionInt (position);
this.requestLayout ();
this.invalidate ();
}, "~N");
Clazz.defineMethod (c$, "setSelectionInt", 
function (position, animate) {
if (position != this.mOldSelectedPosition) {
this.$mBlockLayoutRequests = true;
var delta = position - this.mSelectedPosition;
this.setNextSelectedPositionInt (position);
this.layout (delta, animate);
this.$mBlockLayoutRequests = false;
}}, "~N,~B");
Clazz.overrideMethod (c$, "getSelectedView", 
function () {
if (this.mItemCount > 0 && this.mSelectedPosition >= 0) {
return this.getChildAt (this.mSelectedPosition - this.mFirstPosition);
} else {
return null;
}});
Clazz.defineMethod (c$, "requestLayout", 
function () {
if (!this.$mBlockLayoutRequests) {
Clazz.superCall (this, android.widget.AbsSpinner, "requestLayout", []);
}});
Clazz.overrideMethod (c$, "getAdapter", 
function () {
return this.mAdapter;
});
Clazz.overrideMethod (c$, "getCount", 
function () {
return this.mItemCount;
});
Clazz.defineMethod (c$, "pointToPosition", 
function (x, y) {
var frame = this.mTouchFrame;
if (frame == null) {
this.mTouchFrame =  new android.graphics.Rect ();
frame = this.mTouchFrame;
}var count = this.getChildCount ();
for (var i = count - 1; i >= 0; i--) {
var child = this.getChildAt (i);
if (child.getVisibility () == 0) {
child.getHitRect (frame);
if (frame.contains (x, y)) {
return this.mFirstPosition + i;
}}}
return -1;
}, "~N,~N");
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
var superState = Clazz.superCall (this, android.widget.AbsSpinner, "onSaveInstanceState", []);
var ss =  new android.widget.AbsSpinner.SavedState (superState);
ss.selectedId = this.getSelectedItemId ();
if (ss.selectedId >= 0) {
ss.position = this.getSelectedItemPosition ();
} else {
ss.position = -1;
}return ss;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
var ss = state;
Clazz.superCall (this, android.widget.AbsSpinner, "onRestoreInstanceState", [ss.getSuperState ()]);
if (ss.selectedId >= 0) {
this.mDataChanged = true;
this.mNeedSync = true;
this.mSyncRowId = ss.selectedId;
this.mSyncPosition = ss.position;
this.mSyncMode = 0;
this.requestLayout ();
}}, "android.os.Parcelable");
c$.$AbsSpinner$RecycleBin$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mScrapHeap = null;
Clazz.instantialize (this, arguments);
}, android.widget.AbsSpinner, "RecycleBin");
Clazz.prepareFields (c$, function () {
this.mScrapHeap =  new android.util.SparseArray ();
});
Clazz.defineMethod (c$, "put", 
function (a, b) {
this.mScrapHeap.put (a, b);
}, "~N,android.view.View");
Clazz.defineMethod (c$, "get", 
function (a) {
var b = this.mScrapHeap.get (a);
if (b != null) {
this.mScrapHeap.$delete (a);
} else {
}return b;
}, "~N");
Clazz.defineMethod (c$, "clear", 
function () {
var a = this.mScrapHeap;
var b = a.size ();
for (var c = 0; c < b; c++) {
var d = a.valueAt (c);
if (d != null) {
this.b$["android.widget.AbsSpinner"].removeDetachedView (d, true);
}}
a.clear ();
});
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.selectedId = 0;
this.position = 0;
Clazz.instantialize (this, arguments);
}, android.widget.AbsSpinner, "SavedState", android.view.View.BaseSavedState);
Clazz.makeConstructor (c$, 
($fz = function (a) {
Clazz.superConstructor (this, android.widget.AbsSpinner.SavedState, [a]);
this.selectedId = a.readLong ();
this.position = a.readInt ();
}, $fz.isPrivate = true, $fz), "android.os.Parcel");
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
Clazz.superCall (this, android.widget.AbsSpinner.SavedState, "writeToParcel", [a, b]);
a.writeLong (this.selectedId);
a.writeInt (this.position);
}, "android.os.Parcel,~N");
Clazz.overrideMethod (c$, "toString", 
function () {
return "AbsSpinner.SavedState{" + Integer.toHexString (System.identityHashCode (this)) + " selectedId=" + this.selectedId + " position=" + this.position + "}";
});
c$.$AbsSpinner$SavedState$1$ = function () {
Clazz.pu$h ();
c$ = Clazz.declareAnonymous (android.widget, "AbsSpinner$SavedState$1", null, android.os.Parcelable.Creator);
Clazz.overrideMethod (c$, "createFromParcel", 
function (a) {
return  new android.widget.AbsSpinner.SavedState (a);
}, "android.os.Parcel");
Clazz.overrideMethod (c$, "newArray", 
function (a) {
return  new Array (a);
}, "~N");
c$ = Clazz.p0p ();
};
c$.$$CREATOR = c$.prototype.$$CREATOR = ((Clazz.isClassDefined ("android.widget.AbsSpinner$SavedState$1") ? 0 : android.widget.AbsSpinner.SavedState.$AbsSpinner$SavedState$1$ ()), Clazz.innerTypeInstance (android.widget.AbsSpinner$SavedState$1, this, null));
c$ = Clazz.p0p ();
});
