﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.Filter"], "android.widget.CursorFilter", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mClient = null;
Clazz.instantialize (this, arguments);
}, android.widget, "CursorFilter", android.widget.Filter);
Clazz.makeConstructor (c$, 
function (client) {
Clazz.superConstructor (this, android.widget.CursorFilter, []);
this.mClient = client;
}, "android.widget.CursorFilterClient");
Clazz.overrideMethod (c$, "convertResultToString", 
function (resultValue) {
return this.mClient.convertToString (resultValue);
}, "~O");
Clazz.overrideMethod (c$, "performFiltering", 
function (constraint) {
var cursor = this.mClient.runQueryOnBackgroundThread (constraint);
var results =  new android.widget.Filter.FilterResults ();
if (cursor != null) {
results.count = cursor.getCount ();
results.values = cursor;
} else {
results.count = 0;
results.values = null;
}return results;
}, "CharSequence");
Clazz.overrideMethod (c$, "publishResults", 
function (constraint, results) {
var oldCursor = this.mClient.getCursor ();
if (results.values != null && results.values !== oldCursor) {
this.mClient.changeCursor (results.values);
}}, "CharSequence,android.widget.Filter.FilterResults");
});
