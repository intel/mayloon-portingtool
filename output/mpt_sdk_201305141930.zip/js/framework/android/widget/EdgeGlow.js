﻿Clazz.declarePackage ("android.widget");
Clazz.load (null, "android.widget.EdgeGlow", ["android.view.animation.AnimationUtils", "$.DecelerateInterpolator"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mEdge = null;
this.mGlow = null;
this.mWidth = 0;
this.mHeight = 0;
this.mEdgeAlpha = 0;
this.mEdgeScaleY = 0;
this.mGlowAlpha = 0;
this.mGlowScaleY = 0;
this.mEdgeAlphaStart = 0;
this.mEdgeAlphaFinish = 0;
this.mEdgeScaleYStart = 0;
this.mEdgeScaleYFinish = 0;
this.mGlowAlphaStart = 0;
this.mGlowAlphaFinish = 0;
this.mGlowScaleYStart = 0;
this.mGlowScaleYFinish = 0;
this.mStartTime = 0;
this.mDuration = 0;
this.mInterpolator = null;
this.mState = 0;
this.mPullDistance = 0;
Clazz.instantialize (this, arguments);
}, android.widget, "EdgeGlow");
Clazz.makeConstructor (c$, 
function (edge, glow) {
this.mEdge = edge;
this.mGlow = glow;
this.mInterpolator =  new android.view.animation.DecelerateInterpolator ();
}, "android.graphics.drawable.Drawable,android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setSize", 
function (width, height) {
this.mWidth = width;
this.mHeight = height;
}, "~N,~N");
Clazz.defineMethod (c$, "isFinished", 
function () {
return this.mState == 0;
});
Clazz.defineMethod (c$, "finish", 
function () {
this.mState = 0;
});
Clazz.defineMethod (c$, "onPull", 
function (deltaDistance) {
var now = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
if (this.mState == 4 && now - this.mStartTime < this.mDuration) {
return ;
}if (this.mState != 1) {
this.mGlowScaleY = 1.0;
}this.mState = 1;
this.mStartTime = now;
this.mDuration = 167;
this.mPullDistance += deltaDistance;
var distance = Math.abs (this.mPullDistance);
this.mEdgeAlpha = this.mEdgeAlphaStart = Math.max (0.6, Math.min (distance, 0.8));
this.mEdgeScaleY = this.mEdgeScaleYStart = Math.max (0.5, Math.min (distance * 5, 1.));
this.mGlowAlpha = this.mGlowAlphaStart = Math.min (0.8, this.mGlowAlpha + (Math.abs (deltaDistance) * 0.8));
var glowChange = Math.abs (deltaDistance);
if (deltaDistance > 0 && this.mPullDistance < 0) {
glowChange = -glowChange;
}if (this.mPullDistance == 0) {
this.mGlowScaleY = 0;
}this.mGlowScaleY = this.mGlowScaleYStart = Math.min (3.0, Math.max (0, this.mGlowScaleY + glowChange * 5));
this.mEdgeAlphaFinish = this.mEdgeAlpha;
this.mEdgeScaleYFinish = this.mEdgeScaleY;
this.mGlowAlphaFinish = this.mGlowAlpha;
this.mGlowScaleYFinish = this.mGlowScaleY;
}, "~N");
Clazz.defineMethod (c$, "onRelease", 
function () {
this.mPullDistance = 0;
if (this.mState != 1 && this.mState != 4) {
return ;
}this.mState = 3;
this.mEdgeAlphaStart = this.mEdgeAlpha;
this.mEdgeScaleYStart = this.mEdgeScaleY;
this.mGlowAlphaStart = this.mGlowAlpha;
this.mGlowScaleYStart = this.mGlowScaleY;
this.mEdgeAlphaFinish = 0.;
this.mEdgeScaleYFinish = 0.;
this.mGlowAlphaFinish = 0.;
this.mGlowScaleYFinish = 0.;
this.mStartTime = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
this.mDuration = 1000;
});
Clazz.defineMethod (c$, "onAbsorb", 
function (velocity) {
this.mState = 2;
velocity = Math.max (100, Math.abs (velocity));
this.mStartTime = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
this.mDuration = 0.1 + (velocity * 0.03);
this.mEdgeAlphaStart = 0.;
this.mEdgeScaleY = this.mEdgeScaleYStart = 0.;
this.mGlowAlphaStart = 0.5;
this.mGlowScaleYStart = 0.;
this.mEdgeAlphaFinish = Math.max (0, Math.min (velocity * 8, 1));
this.mEdgeScaleYFinish = Math.max (0.5, Math.min (velocity * 8, 1.));
this.mGlowScaleYFinish = Math.min (0.025 + (velocity * (Math.floor (velocity / 100)) * 0.00015), 1.75);
this.mGlowAlphaFinish = Math.max (this.mGlowAlphaStart, Math.min (velocity * 16 * .00001, 0.8));
}, "~N");
Clazz.defineMethod (c$, "draw", 
function (canvas) {
this.update ();
var edgeHeight = this.mEdge.getIntrinsicHeight ();
var glowHeight = this.mGlow.getIntrinsicHeight ();
var distScale = this.mHeight / this.mWidth;
this.mGlow.setAlpha (Math.round ((Math.max (0, Math.min (this.mGlowAlpha, 1)) * 255)));
this.mGlow.setBounds (-this.mWidth, 0, this.mWidth * 2, Math.round (Math.min (glowHeight * this.mGlowScaleY * distScale * 0.6, this.mHeight * 3.0)));
this.mGlow.draw (canvas);
this.mEdge.setAlpha (Math.round ((Math.max (0, Math.min (this.mEdgeAlpha, 1)) * 255)));
this.mEdge.setBounds (0, 0, this.mWidth, Math.round ((edgeHeight * this.mEdgeScaleY)));
this.mEdge.draw (canvas);
return this.mState != 0;
}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "update", 
($fz = function () {
var time = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
var t = Math.min ((time - this.mStartTime) / this.mDuration, 1.);
var interp = this.mInterpolator.getInterpolation (t);
this.mEdgeAlpha = this.mEdgeAlphaStart + (this.mEdgeAlphaFinish - this.mEdgeAlphaStart) * interp;
this.mEdgeScaleY = this.mEdgeScaleYStart + (this.mEdgeScaleYFinish - this.mEdgeScaleYStart) * interp;
this.mGlowAlpha = this.mGlowAlphaStart + (this.mGlowAlphaFinish - this.mGlowAlphaStart) * interp;
this.mGlowScaleY = this.mGlowScaleYStart + (this.mGlowScaleYFinish - this.mGlowScaleYStart) * interp;
if (t >= 0.999) {
switch (this.mState) {
case 2:
this.mState = 3;
this.mStartTime = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
this.mDuration = 1000;
this.mEdgeAlphaStart = this.mEdgeAlpha;
this.mEdgeScaleYStart = this.mEdgeScaleY;
this.mGlowAlphaStart = this.mGlowAlpha;
this.mGlowScaleYStart = this.mGlowScaleY;
this.mEdgeAlphaFinish = 0.;
this.mEdgeScaleYFinish = 0.;
this.mGlowAlphaFinish = 0.;
this.mGlowScaleYFinish = 0.;
break;
case 1:
this.mState = 4;
this.mStartTime = android.view.animation.AnimationUtils.currentAnimationTimeMillis ();
this.mDuration = 1000;
this.mEdgeAlphaStart = this.mEdgeAlpha;
this.mEdgeScaleYStart = this.mEdgeScaleY;
this.mGlowAlphaStart = this.mGlowAlpha;
this.mGlowScaleYStart = this.mGlowScaleY;
this.mEdgeAlphaFinish = 0.;
this.mEdgeScaleYFinish = 0.;
this.mGlowAlphaFinish = 0.;
this.mGlowScaleYFinish = 0.;
break;
case 4:
var factor = this.mGlowScaleYFinish != 0 ? 1 / (this.mGlowScaleYFinish * this.mGlowScaleYFinish) : 3.4028235E38;
this.mEdgeScaleY = this.mEdgeScaleYStart + (this.mEdgeScaleYFinish - this.mEdgeScaleYStart) * interp * factor;
break;
case 3:
this.mState = 0;
break;
}
}}, $fz.isPrivate = true, $fz));
Clazz.defineStatics (c$,
"TAG", "EdgeGlow",
"RECEDE_TIME", 1000,
"PULL_TIME", 167,
"PULL_DECAY_TIME", 1000,
"MAX_ALPHA", 0.8,
"HELD_EDGE_ALPHA", 0.7,
"HELD_EDGE_SCALE_Y", 0.5,
"HELD_GLOW_ALPHA", 0.5,
"HELD_GLOW_SCALE_Y", 0.5,
"MAX_GLOW_HEIGHT", 3.,
"PULL_GLOW_BEGIN", 1.,
"PULL_EDGE_BEGIN", 0.6,
"MIN_VELOCITY", 100,
"EPSILON", 0.001,
"STATE_IDLE", 0,
"STATE_PULL", 1,
"STATE_ABSORB", 2,
"STATE_RECEDE", 3,
"STATE_PULL_DECAY", 4,
"PULL_DISTANCE_EDGE_FACTOR", 5,
"PULL_DISTANCE_GLOW_FACTOR", 5,
"PULL_DISTANCE_ALPHA_GLOW_FACTOR", 0.8,
"VELOCITY_EDGE_FACTOR", 8,
"VELOCITY_GLOW_FACTOR", 16);
});
