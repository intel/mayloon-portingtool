﻿Clazz.declarePackage ("android.widget");
Clazz.declareInterface (android.widget, "Filterable");
