﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.View", "java.lang.Enum", "android.graphics.Matrix", "$.RectF"], "android.widget.ImageView", ["android.graphics.PorterDuff", "$.PorterDuffColorFilter", "android.graphics.drawable.BitmapDrawable", "$.Drawable", "android.util.Log", "com.android.internal.R", "java.lang.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mUri = null;
this.mResource = 0;
this.mMatrix = null;
this.mScaleType = null;
this.mHaveFrame = false;
this.mAdjustViewBounds = false;
this.mMaxWidth = 2147483647;
this.mMaxHeight = 2147483647;
this.mColorFilter = null;
this.mAlpha = 255;
this.mViewAlphaScale = 256;
this.mColorMod = false;
this.mDrawable = null;
this.mState = null;
this.mMergeState = false;
this.mLevel = 0;
this.mDrawableWidth = 0;
this.mDrawableHeight = 0;
this.mDrawMatrix = null;
this.mTempSrc = null;
this.mTempDst = null;
this.mCropToPadding = false;
this.mBaselineAligned = false;
Clazz.instantialize (this, arguments);
}, android.widget, "ImageView", android.view.View);
Clazz.prepareFields (c$, function () {
this.mTempSrc =  new android.graphics.RectF ();
this.mTempDst =  new android.graphics.RectF ();
});
Clazz.makeConstructor (c$, 
function (context) {
Clazz.superConstructor (this, android.widget.ImageView, [context]);
this.initImageView ();
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 0);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.ImageView, [context, attrs, defStyle]);
this.initImageView ();
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.ImageView, defStyle, 0);
var d = a.getDrawable (0);
if (d != null) {
this.setImageDrawable (d);
}this.mBaselineAligned = a.getBoolean (6, false);
this.setAdjustViewBounds (a.getBoolean (2, false));
this.setMaxWidth (a.getDimensionPixelSize (3, 2147483647));
this.setMaxHeight (a.getDimensionPixelSize (4, 2147483647));
var index = a.getInt (1, -1);
if (index >= 0) {
this.setScaleType (android.widget.ImageView.sScaleTypeArray[index]);
}var tint = a.getInt (5, 0);
if (tint != 0) {
this.setColorFilter (tint);
}this.mCropToPadding = a.getBoolean (7, false);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "initImageView", 
($fz = function () {
this.mMatrix =  new android.graphics.Matrix ();
this.mScaleType = android.widget.ImageView.ScaleType.FIT_CENTER;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "verifyDrawable", 
function (dr) {
return this.mDrawable === dr || Clazz.superCall (this, android.widget.ImageView, "verifyDrawable", [dr]);
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "invalidateDrawable", 
function (dr) {
if (dr === this.mDrawable) {
this.invalidate ();
} else {
Clazz.superCall (this, android.widget.ImageView, "invalidateDrawable", [dr]);
}}, "android.graphics.drawable.Drawable");
Clazz.overrideMethod (c$, "onSetAlpha", 
function (alpha) {
if (this.getBackground () == null) {
var scale = alpha + (alpha >> 7);
if (this.mViewAlphaScale != scale) {
this.mViewAlphaScale = scale;
this.mColorMod = true;
this.applyColorMod ();
}return true;
}return false;
}, "~N");
Clazz.defineMethod (c$, "setAdjustViewBounds", 
function (adjustViewBounds) {
this.mAdjustViewBounds = adjustViewBounds;
if (adjustViewBounds) {
this.setScaleType (android.widget.ImageView.ScaleType.FIT_CENTER);
}}, "~B");
Clazz.defineMethod (c$, "setMaxWidth", 
function (maxWidth) {
this.mMaxWidth = maxWidth;
}, "~N");
Clazz.defineMethod (c$, "setMaxHeight", 
function (maxHeight) {
this.mMaxHeight = maxHeight;
}, "~N");
Clazz.defineMethod (c$, "getDrawable", 
function () {
return this.mDrawable;
});
Clazz.defineMethod (c$, "setImageResource", 
function (resId) {
if (this.mUri != null || this.mResource != resId) {
this.updateDrawable (null);
this.mResource = resId;
this.mUri = null;
this.resolveUri ();
this.requestLayout ();
this.invalidate ();
}}, "~N");
Clazz.defineMethod (c$, "setImageURI", 
function (uri) {
if (this.mResource != 0 || (this.mUri !== uri && (uri == null || this.mUri == null || !uri.equals (this.mUri)))) {
this.updateDrawable (null);
this.mResource = 0;
this.mUri = uri;
this.resolveUri ();
this.requestLayout ();
this.invalidate ();
}}, "android.net.Uri");
Clazz.defineMethod (c$, "setImageDrawable", 
function (drawable) {
if (this.mDrawable !== drawable) {
this.mResource = 0;
this.mUri = null;
this.updateDrawable (drawable);
this.requestLayout ();
this.invalidate ();
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "setImageBitmap", 
function (bm) {
if (bm == null) {
this.setImageDrawable ( new android.graphics.drawable.BitmapDrawable (this.mContext.getResources (), Clazz.castNullAs ("android.graphics.Bitmap")));
} else {
this.setImageDrawable ( new android.graphics.drawable.BitmapDrawable (this.mContext.getResources (), bm));
}}, "android.graphics.Bitmap");
Clazz.defineMethod (c$, "setImageState", 
function (state, merge) {
this.mState = state;
this.mMergeState = merge;
if (this.mDrawable != null) {
this.refreshDrawableState ();
this.resizeFromDrawable ();
}}, "~A,~B");
Clazz.defineMethod (c$, "setSelected", 
function (selected) {
Clazz.superCall (this, android.widget.ImageView, "setSelected", [selected]);
this.resizeFromDrawable ();
}, "~B");
Clazz.defineMethod (c$, "setImageLevel", 
function (level) {
this.mLevel = level;
if (this.mDrawable != null) {
this.mDrawable.setLevel (level);
this.resizeFromDrawable ();
}}, "~N");
Clazz.defineMethod (c$, "setScaleType", 
function (scaleType) {
if (scaleType == null) {
throw  new NullPointerException ();
}if (this.mScaleType !== scaleType) {
this.mScaleType = scaleType;
this.setWillNotCacheDrawing (this.mScaleType === android.widget.ImageView.ScaleType.CENTER);
this.requestLayout ();
this.invalidate ();
}}, "android.widget.ImageView.ScaleType");
Clazz.defineMethod (c$, "getScaleType", 
function () {
return this.mScaleType;
});
Clazz.defineMethod (c$, "getImageMatrix", 
function () {
return this.mMatrix;
});
Clazz.defineMethod (c$, "setImageMatrix", 
function (matrix) {
if (matrix != null && matrix.isIdentity ()) {
matrix = null;
}if (matrix == null && !this.mMatrix.isIdentity () || matrix != null && !this.mMatrix.equals (matrix)) {
this.mMatrix.set (matrix);
this.configureBounds ();
this.invalidate ();
}}, "android.graphics.Matrix");
Clazz.defineMethod (c$, "resolveUri", 
($fz = function () {
if (this.mDrawable != null) {
return ;
}var rsrc = this.getResources ();
if (rsrc == null) {
return ;
}var d = null;
if (this.mResource != 0) {
try {
d = rsrc.getDrawable (this.mResource);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.w ("ImageView", "Unable to find resource: " + this.mResource);
this.mUri = null;
} else {
throw e;
}
}
} else if (this.mUri != null) {
var scheme = this.mUri.getScheme ();
if ("android.resource".equals (scheme)) {
android.util.Log.e ("ImageView", "Unable to open content: " + this.mUri);
} else if ("content".equals (scheme) || "file".equals (scheme)) {
try {
d = android.graphics.drawable.Drawable.createFromStream (this.mContext.getContentResolver ().openInputStream (this.mUri), null);
} catch (e) {
if (Clazz.instanceOf (e, Exception)) {
android.util.Log.w ("ImageView", "Unable to open content: " + this.mUri);
} else {
throw e;
}
}
} else {
d = android.graphics.drawable.Drawable.createFromPath (this.mUri.toString ());
}if (d == null) {
System.out.println ("resolveUri failed on bad bitmap uri: " + this.mUri);
this.mUri = null;
}} else {
return ;
}this.updateDrawable (d);
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "onCreateDrawableState", 
function (extraSpace) {
if (this.mState == null) {
return Clazz.superCall (this, android.widget.ImageView, "onCreateDrawableState", [extraSpace]);
} else if (!this.mMergeState) {
return this.mState;
} else {
return android.view.View.mergeDrawableStates (Clazz.superCall (this, android.widget.ImageView, "onCreateDrawableState", [extraSpace + this.mState.length]), this.mState);
}}, "~N");
Clazz.defineMethod (c$, "updateDrawable", 
($fz = function (d) {
if (this.mDrawable != null) {
this.mDrawable.setCallback (null);
this.unscheduleDrawable (this.mDrawable, null);
}this.mDrawable = d;
if (d != null) {
d.setCallback (this);
if (d.isStateful ()) {
d.setState (this.getDrawableState ());
}d.setLevel (this.mLevel);
var r = d.copyBounds ();
var width = r.right - r.left;
var height = r.bottom - r.top;
if (width == 0 && height == 0) {
this.mDrawableWidth = d.getIntrinsicWidth ();
this.mDrawableHeight = d.getIntrinsicHeight ();
} else {
this.mDrawableWidth = r.right - r.left;
this.mDrawableHeight = r.bottom - r.top;
}this.applyColorMod ();
this.configureBounds ();
}}, $fz.isPrivate = true, $fz), "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "resizeFromDrawable", 
($fz = function () {
var d = this.mDrawable;
if (d != null) {
var w = d.getIntrinsicWidth ();
if (w < 0) w = this.mDrawableWidth;
var h = d.getIntrinsicHeight ();
if (h < 0) h = this.mDrawableHeight;
if (w != this.mDrawableWidth || h != this.mDrawableHeight) {
this.mDrawableWidth = w;
this.mDrawableHeight = h;
this.requestLayout ();
}}}, $fz.isPrivate = true, $fz));
c$.scaleTypeToScaleToFit = Clazz.defineMethod (c$, "scaleTypeToScaleToFit", 
($fz = function (st) {
return android.widget.ImageView.sS2FArray[st.nativeInt - 1];
}, $fz.isPrivate = true, $fz), "android.widget.ImageView.ScaleType");
Clazz.overrideMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
this.resolveUri ();
var w;
var h;
var desiredAspect = 0.0;
var resizeWidth = false;
var resizeHeight = false;
if (this.mDrawable == null) {
this.mDrawableWidth = -1;
this.mDrawableHeight = -1;
w = h = 0;
} else {
w = this.mDrawableWidth;
h = this.mDrawableHeight;
if (w <= 0) w = 1;
if (h <= 0) h = 1;
if (this.mAdjustViewBounds) {
var widthSpecMode = android.view.View.MeasureSpec.getMode (widthMeasureSpec);
var heightSpecMode = android.view.View.MeasureSpec.getMode (heightMeasureSpec);
resizeWidth = widthSpecMode != 1073741824;
resizeHeight = heightSpecMode != 1073741824;
desiredAspect = w / h;
}}var pleft = this.mPaddingLeft;
var pright = this.mPaddingRight;
var ptop = this.mPaddingTop;
var pbottom = this.mPaddingBottom;
var widthSize;
var heightSize;
if (resizeWidth || resizeHeight) {
widthSize = this.resolveAdjustedSize (w + pleft + pright, this.mMaxWidth, widthMeasureSpec);
heightSize = this.resolveAdjustedSize (h + ptop + pbottom, this.mMaxHeight, heightMeasureSpec);
if (desiredAspect != 0.0) {
var actualAspect = (widthSize - pleft - pright) / (heightSize - ptop - pbottom);
if (Math.abs (actualAspect - desiredAspect) > 0.0000001) {
var done = false;
if (resizeWidth) {
var newWidth = Math.round ((desiredAspect * (heightSize - ptop - pbottom))) + pleft + pright;
if (newWidth <= widthSize) {
widthSize = newWidth;
done = true;
}}if (!done && resizeHeight) {
var newHeight = Math.round (((widthSize - pleft - pright) / desiredAspect)) + ptop + pbottom;
if (newHeight <= heightSize) {
heightSize = newHeight;
}}}}} else {
w += pleft + pright;
h += ptop + pbottom;
w = Math.max (w, this.getSuggestedMinimumWidth ());
h = Math.max (h, this.getSuggestedMinimumHeight ());
widthSize = android.view.View.resolveSize (w, widthMeasureSpec);
heightSize = android.view.View.resolveSize (h, heightMeasureSpec);
}this.setMeasuredDimension (widthSize, heightSize);
}, "~N,~N");
Clazz.defineMethod (c$, "resolveAdjustedSize", 
($fz = function (desiredSize, maxSize, measureSpec) {
var result = desiredSize;
var specMode = android.view.View.MeasureSpec.getMode (measureSpec);
var specSize = android.view.View.MeasureSpec.getSize (measureSpec);
switch (specMode) {
case 0:
result = Math.min (desiredSize, maxSize);
break;
case -2147483648:
result = Math.min (Math.min (desiredSize, specSize), maxSize);
break;
case 1073741824:
result = specSize;
break;
}
return result;
}, $fz.isPrivate = true, $fz), "~N,~N,~N");
Clazz.defineMethod (c$, "setFrame", 
function (l, t, r, b) {
var changed = Clazz.superCall (this, android.widget.ImageView, "setFrame", [l, t, r, b]);
this.mHaveFrame = true;
this.configureBounds ();
return changed;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "configureBounds", 
($fz = function () {
if (this.mDrawable == null || !this.mHaveFrame) {
return ;
}var dwidth = this.mDrawableWidth;
var dheight = this.mDrawableHeight;
var vwidth = this.getWidth () - this.mPaddingLeft - this.mPaddingRight;
var vheight = this.getHeight () - this.mPaddingTop - this.mPaddingBottom;
var fits = (dwidth < 0 || vwidth == dwidth) && (dheight < 0 || vheight == dheight);
if (dwidth <= 0 || dheight <= 0 || android.widget.ImageView.ScaleType.FIT_XY === this.mScaleType) {
this.mDrawable.setBounds (0, 0, vwidth, vheight);
this.mDrawMatrix = null;
} else {
this.mDrawable.setBounds (0, 0, dwidth, dheight);
if (android.widget.ImageView.ScaleType.MATRIX === this.mScaleType) {
if (this.mMatrix.isIdentity ()) {
this.mDrawMatrix = null;
} else {
this.mDrawMatrix = this.mMatrix;
}} else if (fits) {
this.mDrawMatrix = null;
} else if (android.widget.ImageView.ScaleType.CENTER === this.mScaleType) {
this.mDrawMatrix = this.mMatrix;
this.mDrawMatrix.setTranslate (Math.round (((vwidth - dwidth) * 0.5 + 0.5)), Math.round (((vheight - dheight) * 0.5 + 0.5)));
} else if (android.widget.ImageView.ScaleType.CENTER_CROP === this.mScaleType) {
this.mDrawMatrix = this.mMatrix;
var scale;
var dx = 0;
var dy = 0;
if (dwidth * vheight > vwidth * dheight) {
scale = vheight / dheight;
dx = (vwidth - dwidth * scale) * 0.5;
} else {
scale = vwidth / dwidth;
dy = (vheight - dheight * scale) * 0.5;
}this.mDrawMatrix.setScale (scale, scale);
this.mDrawMatrix.postTranslate (Math.round ((dx + 0.5)), Math.round ((dy + 0.5)));
} else if (android.widget.ImageView.ScaleType.CENTER_INSIDE === this.mScaleType) {
this.mDrawMatrix = this.mMatrix;
var scale;
var dx;
var dy;
if (dwidth <= vwidth && dheight <= vheight) {
scale = 1.0;
} else {
scale = Math.min (vwidth / dwidth, vheight / dheight);
}dx = Math.round (((vwidth - dwidth * scale) * 0.5 + 0.5));
dy = Math.round (((vheight - dheight * scale) * 0.5 + 0.5));
this.mDrawMatrix.setScale (scale, scale);
this.mDrawMatrix.postTranslate (dx, dy);
} else {
this.mTempSrc.set (0, 0, dwidth, dheight);
this.mTempDst.set (0, 0, vwidth, vheight);
this.mDrawMatrix = this.mMatrix;
this.mDrawMatrix.setRectToRect (this.mTempSrc, this.mTempDst, android.widget.ImageView.scaleTypeToScaleToFit (this.mScaleType));
}}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "drawableStateChanged", 
function () {
Clazz.superCall (this, android.widget.ImageView, "drawableStateChanged", []);
var d = this.mDrawable;
if (d != null && d.isStateful ()) {
d.setState (this.getDrawableState ());
}});
Clazz.defineMethod (c$, "onDraw", 
function (canvas) {
Clazz.superCall (this, android.widget.ImageView, "onDraw", [canvas]);
if (this.mDrawable == null) {
return ;
}if (this.mDrawableWidth == 0 || this.mDrawableHeight == 0) {
return ;
}if (this.mDrawMatrix == null && this.mPaddingTop == 0 && this.mPaddingLeft == 0) {
this.mDrawable.draw (canvas);
} else {
var saveCount = canvas.getSaveCount ();
canvas.save ();
if (this.mCropToPadding) {
var scrollX = this.mScrollX;
var scrollY = this.mScrollY;
canvas.clipRect (scrollX + this.mPaddingLeft, scrollY + this.mPaddingTop, scrollX + this.mRight - this.mLeft - this.mPaddingRight, scrollY + this.mBottom - this.mTop - this.mPaddingBottom);
}canvas.translate (this.mPaddingLeft, this.mPaddingTop);
if (this.mDrawMatrix != null) {
canvas.concat (this.mDrawMatrix);
}this.mDrawable.draw (canvas);
canvas.restoreToCount (saveCount);
}}, "android.graphics.Canvas");
Clazz.overrideMethod (c$, "getBaseline", 
function () {
return this.mBaselineAligned ? this.getMeasuredHeight () : -1;
});
Clazz.defineMethod (c$, "setColorFilter", 
function (color, mode) {
this.setColorFilter ( new android.graphics.PorterDuffColorFilter (color, mode));
}, "~N,android.graphics.PorterDuff.Mode");
Clazz.defineMethod (c$, "setColorFilter", 
function (color) {
this.setColorFilter (color, android.graphics.PorterDuff.PorterDuff.Mode.SRC_ATOP);
}, "~N");
Clazz.defineMethod (c$, "clearColorFilter", 
function () {
this.setColorFilter (null);
});
Clazz.defineMethod (c$, "setColorFilter", 
function (cf) {
if (this.mColorFilter !== cf) {
this.mColorFilter = cf;
this.mColorMod = true;
this.applyColorMod ();
this.invalidate ();
}}, "android.graphics.ColorFilter");
Clazz.defineMethod (c$, "setAlpha", 
function (alpha) {
alpha &= 0xFF;
if (this.mAlpha != alpha) {
this.mAlpha = alpha;
this.mColorMod = true;
this.applyColorMod ();
this.invalidate ();
}}, "~N");
Clazz.defineMethod (c$, "applyColorMod", 
($fz = function () {
if (this.mDrawable != null && this.mColorMod) {
this.mDrawable = this.mDrawable.mutate ();
this.mDrawable.setColorFilter (this.mColorFilter);
this.mDrawable.setAlpha (this.mAlpha * this.mViewAlphaScale >> 8);
}}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "ScaleType", 
function (ni) {
console.log("Missing method: ScaleType");
}, "~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.nativeInt = 0;
Clazz.instantialize (this, arguments);
}, android.widget.ImageView, "ScaleType", Enum);
Clazz.makeConstructor (c$, 
function (a) {
this.nativeInt = a;
}, "~N");
Clazz.defineEnumConstant (c$, "MATRIX", 0, [0]);
Clazz.defineEnumConstant (c$, "FIT_XY", 1, [1]);
Clazz.defineEnumConstant (c$, "FIT_START", 2, [2]);
Clazz.defineEnumConstant (c$, "FIT_CENTER", 3, [3]);
Clazz.defineEnumConstant (c$, "FIT_END", 4, [4]);
Clazz.defineEnumConstant (c$, "CENTER", 5, [5]);
Clazz.defineEnumConstant (c$, "CENTER_CROP", 6, [6]);
Clazz.defineEnumConstant (c$, "CENTER_INSIDE", 7, [7]);
c$ = Clazz.p0p ();
c$.sScaleTypeArray = c$.prototype.sScaleTypeArray = [android.widget.ImageView.ScaleType.MATRIX, android.widget.ImageView.ScaleType.FIT_XY, android.widget.ImageView.ScaleType.FIT_START, android.widget.ImageView.ScaleType.FIT_CENTER, android.widget.ImageView.ScaleType.FIT_END, android.widget.ImageView.ScaleType.CENTER, android.widget.ImageView.ScaleType.CENTER_CROP, android.widget.ImageView.ScaleType.CENTER_INSIDE];
c$.sS2FArray = c$.prototype.sS2FArray = [android.graphics.Matrix.ScaleToFit.FILL, android.graphics.Matrix.ScaleToFit.START, android.graphics.Matrix.ScaleToFit.CENTER, android.graphics.Matrix.ScaleToFit.END];
});
