﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.View"], "android.widget.ProgressBar", ["android.graphics.drawable.AnimationDrawable", "$.LayerDrawable", "$.StateListDrawable", "android.view.animation.AlphaAnimation", "$.AnimationUtils", "$.LinearInterpolator", "$.Transformation", "com.android.internal.R", "java.lang.NullPointerException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.$mMinWidth = 0;
this.mMaxWidth = 0;
this.$mMinHeight = 0;
this.mMaxHeight = 0;
this.mProgress = 0;
this.mSecondaryProgress = 0;
this.mMax = 0;
this.mBehavior = 0;
this.mDuration = 0;
this.mIndeterminate = false;
this.mOnlyIndeterminate = false;
this.mTransformation = null;
this.mAnimation = null;
this.mIndeterminateDrawable = null;
this.mProgressDrawable = null;
this.mCurrentDrawable = null;
this.mSampleTile = null;
this.mNoInvalidate = false;
this.mInterpolator = null;
this.mRefreshProgressRunnable = null;
this.mShouldStartAnimationDrawable = false;
this.mLastDrawTime = 0;
this.mInDrawing = false;
if (!Clazz.isClassDefined ("android.widget.ProgressBar.RefreshProgressRunnable")) {
android.widget.ProgressBar.$ProgressBar$RefreshProgressRunnable$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "ProgressBar", android.view.View);
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
System.out.println (android.widget.ProgressBar.TAG + "ProgressBar(Context context)");
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842871);
System.out.println (android.widget.ProgressBar.TAG + "ProgressBar(Context context, AttributeSet attrs)");
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.ProgressBar, [context, attrs, defStyle]);
System.out.println (android.widget.ProgressBar.TAG + "ProgressBar(Context context, AttributeSet attrs, int defStyle)");
this.initProgressBar ();
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.ProgressBar, defStyle, 0);
this.mNoInvalidate = true;
var drawable = a.getDrawable (8);
if (drawable != null) {
System.out.println (android.widget.ProgressBar.TAG + "tileify");
drawable = this.tileify (drawable, false);
this.setProgressDrawable (drawable);
}this.mDuration = a.getInt (9, this.mDuration);
this.$mMinWidth = a.getDimensionPixelSize (11, this.$mMinWidth);
this.mMaxWidth = a.getDimensionPixelSize (0, this.mMaxWidth);
this.$mMinHeight = a.getDimensionPixelSize (12, this.$mMinHeight);
this.mMaxHeight = a.getDimensionPixelSize (1, this.mMaxHeight);
this.mBehavior = a.getInt (10, this.mBehavior);
var resID = a.getResourceId (13, 17432587);
if (resID > 0) {
this.setInterpolator (context, resID);
}this.setMax (a.getInt (2, this.mMax));
this.setProgress (a.getInt (3, this.mProgress));
this.setSecondaryProgress (a.getInt (4, this.mSecondaryProgress));
drawable = a.getDrawable (7);
if (drawable != null) {
drawable = this.tileifyIndeterminate (drawable);
this.setIndeterminateDrawable (drawable);
}this.mOnlyIndeterminate = a.getBoolean (6, this.mOnlyIndeterminate);
this.mNoInvalidate = false;
this.setIndeterminate (this.mOnlyIndeterminate || a.getBoolean (5, this.mIndeterminate));
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "tileify", 
($fz = function (drawable, clip) {
if (Clazz.instanceOf (drawable, android.graphics.drawable.LayerDrawable)) {
var background = drawable;
var N = background.getNumberOfLayers ();
var outDrawables =  new Array (N);
for (var i = 0; i < N; i++) {
var id = background.getId (i);
outDrawables[i] = this.tileify (background.getDrawable (i), (id == 16908301 || id == 16908303));
}
var newBg =  new android.graphics.drawable.LayerDrawable (outDrawables);
for (var i = 0; i < N; i++) {
newBg.setId (i, background.getId (i));
}
return newBg;
} else if (Clazz.instanceOf (drawable, android.graphics.drawable.StateListDrawable)) {
var $in = drawable;
var out =  new android.graphics.drawable.StateListDrawable ();
var numStates = $in.getStateCount ();
for (var i = 0; i < numStates; i++) {
out.addState ($in.getStateSet (i), this.tileify ($in.getStateDrawable (i), clip));
}
return out;
}return drawable;
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.Drawable,~B");
Clazz.defineMethod (c$, "tileifyIndeterminate", 
($fz = function (drawable) {
if (Clazz.instanceOf (drawable, android.graphics.drawable.AnimationDrawable)) {
var background = drawable;
var N = background.getNumberOfFrames ();
var newBg =  new android.graphics.drawable.AnimationDrawable ();
newBg.setOneShot (background.isOneShot ());
for (var i = 0; i < N; i++) {
var frame = this.tileify (background.getFrame (i), true);
frame.setLevel (10000);
newBg.addFrame (frame, background.getDuration (i));
}
newBg.setLevel (10000);
drawable = newBg;
}return drawable;
}, $fz.isPrivate = true, $fz), "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "initProgressBar", 
($fz = function () {
this.mMax = 100;
this.mProgress = 0;
this.mSecondaryProgress = 0;
this.mIndeterminate = false;
this.mOnlyIndeterminate = false;
this.mDuration = 4000;
this.mBehavior = 0;
this.$mMinWidth = 24;
this.mMaxWidth = 48;
this.$mMinHeight = 24;
this.mMaxHeight = 48;
}, $fz.isPrivate = true, $fz));
Clazz.defineMethod (c$, "isIndeterminate", 
function () {
return this.mIndeterminate;
});
Clazz.defineMethod (c$, "setIndeterminate", 
function (indeterminate) {
if ((!this.mOnlyIndeterminate || !this.mIndeterminate) && indeterminate != this.mIndeterminate) {
this.mIndeterminate = indeterminate;
if (indeterminate) {
this.mCurrentDrawable = this.mIndeterminateDrawable;
this.startAnimation ();
} else {
this.mCurrentDrawable = this.mProgressDrawable;
this.stopAnimation ();
}}}, "~B");
Clazz.defineMethod (c$, "getIndeterminateDrawable", 
function () {
return this.mIndeterminateDrawable;
});
Clazz.defineMethod (c$, "setIndeterminateDrawable", 
function (d) {
if (d != null) {
d.setCallback (this);
}this.mIndeterminateDrawable = d;
if (this.mIndeterminate) {
this.mCurrentDrawable = d;
this.postInvalidate ();
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "getProgressDrawable", 
function () {
return this.mProgressDrawable;
});
Clazz.defineMethod (c$, "setProgressDrawable", 
function (d) {
if (d != null) {
d.setCallback (this);
var drawableHeight = d.getMinimumHeight ();
if (this.mMaxHeight < drawableHeight) {
this.mMaxHeight = drawableHeight;
this.requestLayout ();
}}this.mProgressDrawable = d;
if (!this.mIndeterminate) {
this.mCurrentDrawable = d;
this.postInvalidate ();
}}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "getCurrentDrawable", 
function () {
return this.mCurrentDrawable;
});
Clazz.defineMethod (c$, "verifyDrawable", 
function (who) {
return who === this.mProgressDrawable || who === this.mIndeterminateDrawable || Clazz.superCall (this, android.widget.ProgressBar, "verifyDrawable", [who]);
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "postInvalidate", 
function () {
if (!this.mNoInvalidate) {
Clazz.superCall (this, android.widget.ProgressBar, "postInvalidate", []);
}});
Clazz.defineMethod (c$, "doRefreshProgress", 
($fz = function (id, progress, fromUser) {
var scale = this.mMax > 0 ? progress / this.mMax : 0;
var d = this.mCurrentDrawable;
if (d != null) {
var progressDrawable = null;
var level = Math.round ((scale * 10000));
(progressDrawable != null ? progressDrawable : d).setLevel (level);
} else {
this.invalidate ();
}if (id == 16908301) {
this.onProgressRefresh (scale, fromUser);
}}, $fz.isPrivate = true, $fz), "~N,~N,~B");
Clazz.defineMethod (c$, "onProgressRefresh", 
function (scale, fromUser) {
}, "~N,~B");
Clazz.defineMethod (c$, "refreshProgress", 
($fz = function (id, progress, fromUser) {
this.doRefreshProgress (id, progress, fromUser);
}, $fz.isPrivate = true, $fz), "~N,~N,~B");
Clazz.defineMethod (c$, "setProgress", 
function (progress) {
this.setProgress (progress, false);
}, "~N");
Clazz.defineMethod (c$, "setProgress", 
function (progress, fromUser) {
if (this.mIndeterminate) {
return ;
}if (progress < 0) {
progress = 0;
}if (progress > this.mMax) {
progress = this.mMax;
}if (progress != this.mProgress) {
this.mProgress = progress;
this.refreshProgress (16908301, this.mProgress, fromUser);
}}, "~N,~B");
Clazz.defineMethod (c$, "setSecondaryProgress", 
function (secondaryProgress) {
if (this.mIndeterminate) {
return ;
}if (secondaryProgress < 0) {
secondaryProgress = 0;
}if (secondaryProgress > this.mMax) {
secondaryProgress = this.mMax;
}if (secondaryProgress != this.mSecondaryProgress) {
this.mSecondaryProgress = secondaryProgress;
this.refreshProgress (16908303, this.mSecondaryProgress, false);
}}, "~N");
Clazz.defineMethod (c$, "getProgress", 
function () {
return this.mIndeterminate ? 0 : this.mProgress;
});
Clazz.defineMethod (c$, "getSecondaryProgress", 
function () {
return this.mIndeterminate ? 0 : this.mSecondaryProgress;
});
Clazz.defineMethod (c$, "getMax", 
function () {
return this.mMax;
});
Clazz.defineMethod (c$, "setMax", 
function (max) {
if (max < 0) {
max = 0;
}if (max != this.mMax) {
this.mMax = max;
this.postInvalidate ();
if (this.mProgress > max) {
this.mProgress = max;
}this.refreshProgress (16908301, this.mProgress, false);
}}, "~N");
Clazz.defineMethod (c$, "incrementProgressBy", 
function (diff) {
this.setProgress (this.mProgress + diff);
}, "~N");
Clazz.defineMethod (c$, "incrementSecondaryProgressBy", 
function (diff) {
this.setSecondaryProgress (this.mSecondaryProgress + diff);
}, "~N");
Clazz.defineMethod (c$, "startAnimation", 
function () {
if (this.getVisibility () != 0) {
return ;
}var run = null;
var instanceofAnimatable = true;
try {
var clazz = this.mIndeterminateDrawable.getClass ();
run = clazz.getDeclaredMethod ("isRunning", []);
} catch (e) {
if (Clazz.instanceOf (e, NoSuchMethodException)) {
instanceofAnimatable = false;
} else {
throw e;
}
}
if (instanceofAnimatable && run != null) {
this.mShouldStartAnimationDrawable = true;
this.mAnimation = null;
} else {
if (this.mInterpolator == null) {
this.mInterpolator =  new android.view.animation.LinearInterpolator ();
}this.mTransformation =  new android.view.animation.Transformation ();
this.mAnimation =  new android.view.animation.AlphaAnimation (0.0, 1.0);
this.mAnimation.setRepeatMode (this.mBehavior);
this.mAnimation.setRepeatCount (-1);
this.mAnimation.setDuration (this.mDuration);
this.mAnimation.setInterpolator (this.mInterpolator);
this.mAnimation.setStartTime (-1);
this.postInvalidate ();
}});
Clazz.defineMethod (c$, "stopAnimation", 
function () {
this.mAnimation = null;
this.mTransformation = null;
var run = null;
var instanceofAnimatable = true;
try {
var clazz = this.mIndeterminateDrawable.getClass ();
run = clazz.getDeclaredMethod ("isRunning", []);
} catch (e) {
if (Clazz.instanceOf (e, NoSuchMethodException)) {
instanceofAnimatable = false;
} else {
throw e;
}
}
if (instanceofAnimatable && run != null) {
(this.mIndeterminateDrawable).stop ();
this.mShouldStartAnimationDrawable = false;
}});
Clazz.defineMethod (c$, "setInterpolator", 
function (context, resID) {
this.setInterpolator (android.view.animation.AnimationUtils.loadInterpolator (context, resID));
}, "android.content.Context,~N");
Clazz.defineMethod (c$, "setInterpolator", 
function (interpolator) {
this.mInterpolator = interpolator;
}, "android.view.animation.Interpolator");
Clazz.defineMethod (c$, "getInterpolator", 
function () {
return this.mInterpolator;
});
Clazz.defineMethod (c$, "setVisibility", 
function (v) {
if (this.getVisibility () != v) {
Clazz.superCall (this, android.widget.ProgressBar, "setVisibility", [v]);
if (this.mIndeterminate) {
if (v == 8 || v == 4) {
this.stopAnimation ();
} else {
this.startAnimation ();
}}}}, "~N");
Clazz.defineMethod (c$, "invalidateDrawable", 
function (dr) {
if (!this.mInDrawing) {
if (this.verifyDrawable (dr)) {
if (dr == null) {
throw  new NullPointerException ();
}var dirty = dr.getBounds ();
var scrollX = this.mScrollX + this.mPaddingLeft;
var scrollY = this.mScrollY + this.mPaddingTop;
this.invalidate (dirty.left + scrollX, dirty.top + scrollY, dirty.right + scrollX, dirty.bottom + scrollY);
} else {
Clazz.superCall (this, android.widget.ProgressBar, "invalidateDrawable", [dr]);
}}}, "android.graphics.drawable.Drawable");
Clazz.overrideMethod (c$, "onSizeChanged", 
function (w, h, oldw, oldh) {
var right = w - this.mPaddingRight - this.mPaddingLeft;
var bottom = h - this.mPaddingBottom - this.mPaddingTop;
if (this.mIndeterminateDrawable != null) {
this.mIndeterminateDrawable.setBounds (0, 0, right, bottom);
}if (this.mProgressDrawable != null) {
this.mProgressDrawable.setBounds (0, 0, right, bottom);
}}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "onDraw", 
function (canvas) {
Clazz.superCall (this, android.widget.ProgressBar, "onDraw", [canvas]);
var d = this.mCurrentDrawable;
if (d != null) {
canvas.save ();
canvas.translate (this.mPaddingLeft, this.mPaddingTop);
d.draw (canvas);
canvas.restore ();
var instanceofAnimatable = true;
var run = null;
try {
var clazz = d.getClass ();
run = clazz.getDeclaredMethod ("isRunning", []);
} catch (e) {
if (Clazz.instanceOf (e, NoSuchMethodException)) {
instanceofAnimatable = false;
} else {
throw e;
}
}
if (this.mShouldStartAnimationDrawable && instanceofAnimatable && run != null) {
(d).start ();
this.mShouldStartAnimationDrawable = false;
}}}, "android.graphics.Canvas");
Clazz.overrideMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
var d = this.mCurrentDrawable;
var dw = 0;
var dh = 0;
if (d != null) {
dw = Math.max (this.$mMinWidth, Math.min (this.mMaxWidth, d.getIntrinsicWidth ()));
dh = Math.max (this.$mMinHeight, Math.min (this.mMaxHeight, d.getIntrinsicHeight ()));
}dw += this.mPaddingLeft + this.mPaddingRight;
dh += this.mPaddingTop + this.mPaddingBottom;
this.setMeasuredDimension (android.view.View.resolveSize (dw, widthMeasureSpec), android.view.View.resolveSize (dh, heightMeasureSpec));
}, "~N,~N");
Clazz.defineMethod (c$, "drawableStateChanged", 
function () {
Clazz.superCall (this, android.widget.ProgressBar, "drawableStateChanged", []);
var state = this.getDrawableState ();
if (this.mProgressDrawable != null && this.mProgressDrawable.isStateful ()) {
this.mProgressDrawable.setState (state);
}if (this.mIndeterminateDrawable != null && this.mIndeterminateDrawable.isStateful ()) {
this.mIndeterminateDrawable.setState (state);
}});
Clazz.defineMethod (c$, "onSaveInstanceState", 
function () {
var superState = Clazz.superCall (this, android.widget.ProgressBar, "onSaveInstanceState", []);
var ss =  new android.widget.ProgressBar.SavedState (superState);
ss.progress = this.mProgress;
ss.secondaryProgress = this.mSecondaryProgress;
return ss;
});
Clazz.defineMethod (c$, "onRestoreInstanceState", 
function (state) {
var ss = state;
Clazz.superCall (this, android.widget.ProgressBar, "onRestoreInstanceState", [ss.getSuperState ()]);
this.setProgress (ss.progress);
this.setSecondaryProgress (ss.secondaryProgress);
}, "android.os.Parcelable");
Clazz.defineMethod (c$, "onAttachedToWindow", 
function () {
Clazz.superCall (this, android.widget.ProgressBar, "onAttachedToWindow", []);
if (this.mIndeterminate) {
this.startAnimation ();
}});
Clazz.defineMethod (c$, "onDetachedFromWindow", 
function () {
Clazz.superCall (this, android.widget.ProgressBar, "onDetachedFromWindow", []);
if (this.mIndeterminate) {
this.stopAnimation ();
}});
c$.$ProgressBar$RefreshProgressRunnable$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
this.mId = 0;
this.mProgress = 0;
this.mFromUser = false;
Clazz.instantialize (this, arguments);
}, android.widget.ProgressBar, "RefreshProgressRunnable", null, Runnable);
Clazz.makeConstructor (c$, 
function (a, b, c) {
this.mId = a;
this.mProgress = b;
this.mFromUser = c;
}, "~N,~N,~B");
Clazz.overrideMethod (c$, "run", 
function () {
this.b$["android.widget.ProgressBar"].doRefreshProgress (this.mId, this.mProgress, this.mFromUser);
this.b$["android.widget.ProgressBar"].mRefreshProgressRunnable = this;
});
Clazz.defineMethod (c$, "setup", 
function (a, b, c) {
this.mId = a;
this.mProgress = b;
this.mFromUser = c;
}, "~N,~N,~B");
c$ = Clazz.p0p ();
};
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.progress = 0;
this.secondaryProgress = 0;
Clazz.instantialize (this, arguments);
}, android.widget.ProgressBar, "SavedState", android.view.View.BaseSavedState);
Clazz.defineMethod (c$, "writeToParcel", 
function (a, b) {
Clazz.superCall (this, android.widget.ProgressBar.SavedState, "writeToParcel", [a, b]);
a.writeInt (this.progress);
a.writeInt (this.secondaryProgress);
}, "android.os.Parcel,~N");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"MAX_LEVEL", 10000,
"ANIMATION_RESOLUTION", 200,
"DEBUG", true,
"TAG", "ProgressBar<<");
});
