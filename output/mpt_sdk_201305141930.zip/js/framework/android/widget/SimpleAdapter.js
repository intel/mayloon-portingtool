﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.BaseAdapter", "$.Filter"], "android.widget.SimpleAdapter", ["android.net.Uri", "java.lang.IllegalStateException", "$.NullPointerException", "java.util.ArrayList"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mTo = null;
this.mFrom = null;
this.mViewBinder = null;
this.mData = null;
this.mResource = 0;
this.mDropDownResource = 0;
this.mInflater = null;
this.mFilter = null;
this.mUnfilteredData = null;
if (!Clazz.isClassDefined ("android.widget.SimpleAdapter.SimpleFilter")) {
android.widget.SimpleAdapter.$SimpleAdapter$SimpleFilter$ ();
}
Clazz.instantialize (this, arguments);
}, android.widget, "SimpleAdapter", android.widget.BaseAdapter);
Clazz.makeConstructor (c$, 
function (context, data, resource, from, to) {
Clazz.superConstructor (this, android.widget.SimpleAdapter, []);
this.mData = data;
this.mResource = this.mDropDownResource = resource;
this.mFrom = from;
this.mTo = to;
this.mInflater = context.getSystemService ("layout_inflater");
}, "android.content.Context,java.util.List,~N,~A,~A");
Clazz.overrideMethod (c$, "getCount", 
function () {
return this.mData.size ();
});
Clazz.overrideMethod (c$, "getItem", 
function (position) {
return this.mData.get (position);
}, "~N");
Clazz.overrideMethod (c$, "getItemId", 
function (position) {
return position;
}, "~N");
Clazz.overrideMethod (c$, "getView", 
function (position, convertView, parent) {
return this.createViewFromResource (position, convertView, parent, this.mResource);
}, "~N,android.view.View,android.view.ViewGroup");
Clazz.defineMethod (c$, "createViewFromResource", 
($fz = function (position, convertView, parent, resource) {
var v;
if (convertView == null) {
v = this.mInflater.inflate (resource, parent, false);
} else {
v = convertView;
}this.bindView (position, v);
return v;
}, $fz.isPrivate = true, $fz), "~N,android.view.View,android.view.ViewGroup,~N");
Clazz.defineMethod (c$, "bindView", 
($fz = function (position, view) {
var dataSet = this.mData.get (position);
if (dataSet == null) {
return ;
}var binder = this.mViewBinder;
var from = this.mFrom;
var to = this.mTo;
var count = to.length;
for (var i = 0; i < count; i++) {
var v = view.findViewById (to[i]);
if (v != null) {
var data = dataSet.get (from[i]);
var text = data == null ? "" : data.toString ();
if (text == null) {
text = "";
}var bound = false;
if (binder != null) {
bound = binder.setViewValue (v, data, text);
}if (!bound) {
if (Clazz.instanceOf (v, android.widget.Checkable)) {
System.out.println ("impossible here");
if (Clazz.instanceOf (data, Boolean)) {
(v).setChecked ((data).booleanValue ());
} else if (Clazz.instanceOf (v, android.widget.TextView)) {
this.setViewText (v, text);
} else {
throw  new IllegalStateException (v.getClass ().getName () + " should be bound to a Boolean, not a " + (data == null ? "<unknown type>" : data.getClass ()));
}} else if (Clazz.instanceOf (v, android.widget.TextView)) {
this.setViewText (v, text);
} else if (Clazz.instanceOf (v, android.widget.ImageView)) {
if (Clazz.instanceOf (data, Integer)) {
this.setViewImage (v, (data).intValue ());
} else {
this.setViewImage (v, text);
}} else {
throw  new IllegalStateException (v.getClass ().getName () + " is not a " + " view that can be bounds by this SimpleAdapter");
}}}}
}, $fz.isPrivate = true, $fz), "~N,android.view.View");
Clazz.defineMethod (c$, "setViewImage", 
function (v, value) {
v.setImageResource (value);
}, "android.widget.ImageView,~N");
Clazz.defineMethod (c$, "setViewImage", 
function (v, value) {
if (value == null) {
throw  new NullPointerException ("SimpleAdapter.setViewImage ->value is null");
}try {
v.setImageResource (Integer.parseInt (value));
} catch (nfe) {
if (Clazz.instanceOf (nfe, NumberFormatException)) {
v.setImageURI (android.net.Uri.parse (value));
} else {
throw nfe;
}
}
}, "android.widget.ImageView,~S");
Clazz.defineMethod (c$, "getViewBinder", 
function () {
return this.mViewBinder;
});
Clazz.defineMethod (c$, "setViewBinder", 
function (viewBinder) {
this.mViewBinder = viewBinder;
}, "android.widget.SimpleAdapter.ViewBinder");
Clazz.defineMethod (c$, "setViewText", 
function (v, text) {
v.setText (text);
}, "android.widget.TextView,~S");
Clazz.defineMethod (c$, "getFilter", 
function () {
if (this.mFilter == null) {
this.mFilter = Clazz.innerTypeInstance (android.widget.SimpleAdapter.SimpleFilter, this, null);
}return this.mFilter;
});
Clazz.defineMethod (c$, "setDropDownViewResource", 
function (resource) {
this.mDropDownResource = resource;
}, "~N");
Clazz.overrideMethod (c$, "getDropDownView", 
function (position, convertView, parent) {
return this.createViewFromResource (position, convertView, parent, this.mDropDownResource);
}, "~N,android.view.View,android.view.ViewGroup");
c$.$SimpleAdapter$SimpleFilter$ = function () {
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
Clazz.prepareCallback (this, arguments);
Clazz.instantialize (this, arguments);
}, android.widget.SimpleAdapter, "SimpleFilter", android.widget.Filter);
Clazz.overrideMethod (c$, "performFiltering", 
function (a) {
var b =  new android.widget.Filter.FilterResults ();
if (this.b$["android.widget.SimpleAdapter"].mUnfilteredData == null) {
this.b$["android.widget.SimpleAdapter"].mUnfilteredData =  new java.util.ArrayList (this.b$["android.widget.SimpleAdapter"].mData);
}if (a == null || a.length () == 0) {
var c = this.b$["android.widget.SimpleAdapter"].mUnfilteredData;
b.values = c;
b.count = c.size ();
} else {
var c = a.toString ().toLowerCase ();
var d = this.b$["android.widget.SimpleAdapter"].mUnfilteredData;
var e = d.size ();
var f =  new java.util.ArrayList (e);
for (var g = 0; g < e; g++) {
var h = d.get (g);
if (h != null) {
var i = this.b$["android.widget.SimpleAdapter"].mTo.length;
for (var j = 0; j < i; j++) {
var k = h.get (this.b$["android.widget.SimpleAdapter"].mFrom[j]);
var l = k.$plit (" ");
var m = l.length;
for (var n = 0; n < m; n++) {
var o = l[n];
if (o.toLowerCase ().startsWith (c)) {
f.add (h);
break;
}}
}
}}
b.values = f;
b.count = f.size ();
}return b;
}, "CharSequence");
Clazz.overrideMethod (c$, "publishResults", 
function (a, b) {
this.b$["android.widget.SimpleAdapter"].mData = b.values;
if (b.count > 0) {
this.b$["android.widget.SimpleAdapter"].notifyDataSetChanged ();
} else {
this.b$["android.widget.SimpleAdapter"].notifyDataSetInvalidated ();
}}, "CharSequence,android.widget.Filter.FilterResults");
c$ = Clazz.p0p ();
};
Clazz.declareInterface (android.widget.SimpleAdapter, "ViewBinder");
});
