﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.Adapter"], "android.widget.SpinnerAdapter", null, function () {
Clazz.declareInterface (android.widget, "SpinnerAdapter", android.widget.Adapter);
});
