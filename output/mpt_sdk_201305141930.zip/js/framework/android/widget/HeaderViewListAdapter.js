﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.WrapperListAdapter", "java.util.ArrayList"], "android.widget.HeaderViewListAdapter", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.mAdapter = null;
this.mHeaderViewInfos = null;
this.mFooterViewInfos = null;
this.mAreAllFixedViewsSelectable = false;
this.mIsFilterable = false;
Clazz.instantialize (this, arguments);
}, android.widget, "HeaderViewListAdapter", null, android.widget.WrapperListAdapter);
Clazz.makeConstructor (c$, 
function (headerViewInfos, footerViewInfos, adapter) {
this.mAdapter = adapter;
this.mIsFilterable = Clazz.instanceOf (adapter, android.widget.Filterable);
if (headerViewInfos == null) {
this.mHeaderViewInfos = android.widget.HeaderViewListAdapter.EMPTY_INFO_LIST;
} else {
this.mHeaderViewInfos = headerViewInfos;
}if (footerViewInfos == null) {
this.mFooterViewInfos = android.widget.HeaderViewListAdapter.EMPTY_INFO_LIST;
} else {
this.mFooterViewInfos = footerViewInfos;
}this.mAreAllFixedViewsSelectable = this.areAllListInfosSelectable (this.mHeaderViewInfos) && this.areAllListInfosSelectable (this.mFooterViewInfos);
}, "java.util.ArrayList,java.util.ArrayList,android.widget.ListAdapter");
Clazz.defineMethod (c$, "getHeadersCount", 
function () {
return this.mHeaderViewInfos.size ();
});
Clazz.defineMethod (c$, "getFootersCount", 
function () {
return this.mFooterViewInfos.size ();
});
Clazz.defineMethod (c$, "isEmpty", 
function () {
return this.mAdapter == null || this.mAdapter.isEmpty ();
});
Clazz.defineMethod (c$, "areAllListInfosSelectable", 
($fz = function (infos) {
if (infos != null) {
for (var info, $info = infos.iterator (); $info.hasNext () && ((info = $info.next ()) || true);) {
if (!info.isSelectable) {
return false;
}}
}return true;
}, $fz.isPrivate = true, $fz), "java.util.ArrayList");
Clazz.defineMethod (c$, "removeHeader", 
function (v) {
for (var i = 0; i < this.mHeaderViewInfos.size (); i++) {
var info = this.mHeaderViewInfos.get (i);
if (info.view === v) {
this.mHeaderViewInfos.remove (i);
this.mAreAllFixedViewsSelectable = this.areAllListInfosSelectable (this.mHeaderViewInfos) && this.areAllListInfosSelectable (this.mFooterViewInfos);
return true;
}}
return false;
}, "android.view.View");
Clazz.defineMethod (c$, "removeFooter", 
function (v) {
for (var i = 0; i < this.mFooterViewInfos.size (); i++) {
var info = this.mFooterViewInfos.get (i);
if (info.view === v) {
this.mFooterViewInfos.remove (i);
this.mAreAllFixedViewsSelectable = this.areAllListInfosSelectable (this.mHeaderViewInfos) && this.areAllListInfosSelectable (this.mFooterViewInfos);
return true;
}}
return false;
}, "android.view.View");
Clazz.defineMethod (c$, "getCount", 
function () {
if (this.mAdapter != null) {
return this.getFootersCount () + this.getHeadersCount () + this.mAdapter.getCount ();
} else {
return this.getFootersCount () + this.getHeadersCount ();
}});
Clazz.defineMethod (c$, "areAllItemsEnabled", 
function () {
if (this.mAdapter != null) {
return this.mAreAllFixedViewsSelectable && this.mAdapter.areAllItemsEnabled ();
} else {
return true;
}});
Clazz.defineMethod (c$, "isEnabled", 
function (position) {
var numHeaders = this.getHeadersCount ();
if (position < numHeaders) {
return this.mHeaderViewInfos.get (position).isSelectable;
}var adjPosition = position - numHeaders;
var adapterCount = 0;
if (this.mAdapter != null) {
adapterCount = this.mAdapter.getCount ();
if (adjPosition < adapterCount) {
return this.mAdapter.isEnabled (adjPosition);
}}return this.mFooterViewInfos.get (adjPosition - adapterCount).isSelectable;
}, "~N");
Clazz.defineMethod (c$, "getItem", 
function (position) {
var numHeaders = this.getHeadersCount ();
if (position < numHeaders) {
return this.mHeaderViewInfos.get (position).data;
}var adjPosition = position - numHeaders;
var adapterCount = 0;
if (this.mAdapter != null) {
adapterCount = this.mAdapter.getCount ();
if (adjPosition < adapterCount) {
return this.mAdapter.getItem (adjPosition);
}}return this.mFooterViewInfos.get (adjPosition - adapterCount).data;
}, "~N");
Clazz.defineMethod (c$, "getItemId", 
function (position) {
var numHeaders = this.getHeadersCount ();
if (this.mAdapter != null && position >= numHeaders) {
var adjPosition = position - numHeaders;
var adapterCount = this.mAdapter.getCount ();
if (adjPosition < adapterCount) {
return this.mAdapter.getItemId (adjPosition);
}}return -1;
}, "~N");
Clazz.defineMethod (c$, "hasStableIds", 
function () {
if (this.mAdapter != null) {
return this.mAdapter.hasStableIds ();
}return false;
});
Clazz.defineMethod (c$, "getView", 
function (position, convertView, parent) {
var numHeaders = this.getHeadersCount ();
if (position < numHeaders) {
return this.mHeaderViewInfos.get (position).view;
}var adjPosition = position - numHeaders;
var adapterCount = 0;
if (this.mAdapter != null) {
adapterCount = this.mAdapter.getCount ();
if (adjPosition < adapterCount) {
return this.mAdapter.getView (adjPosition, convertView, parent);
}}return this.mFooterViewInfos.get (adjPosition - adapterCount).view;
}, "~N,android.view.View,android.view.ViewGroup");
Clazz.defineMethod (c$, "getItemViewType", 
function (position) {
var numHeaders = this.getHeadersCount ();
if (this.mAdapter != null && position >= numHeaders) {
var adjPosition = position - numHeaders;
var adapterCount = this.mAdapter.getCount ();
if (adjPosition < adapterCount) {
return this.mAdapter.getItemViewType (adjPosition);
}}return -2;
}, "~N");
Clazz.defineMethod (c$, "getViewTypeCount", 
function () {
if (this.mAdapter != null) {
return this.mAdapter.getViewTypeCount ();
}return 1;
});
Clazz.defineMethod (c$, "registerDataSetObserver", 
function (observer) {
if (this.mAdapter != null) {
this.mAdapter.registerDataSetObserver (observer);
}}, "android.database.DataSetObserver");
Clazz.defineMethod (c$, "unregisterDataSetObserver", 
function (observer) {
if (this.mAdapter != null) {
this.mAdapter.unregisterDataSetObserver (observer);
}}, "android.database.DataSetObserver");
Clazz.defineMethod (c$, "getFilter", 
function () {
if (this.mIsFilterable) {
return (this.mAdapter).getFilter ();
}return null;
});
Clazz.overrideMethod (c$, "getWrappedAdapter", 
function () {
return this.mAdapter;
});
c$.EMPTY_INFO_LIST = c$.prototype.EMPTY_INFO_LIST =  new java.util.ArrayList ();
});
