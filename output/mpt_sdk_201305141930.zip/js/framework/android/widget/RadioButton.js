﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.CompoundButton"], "android.widget.RadioButton", null, function () {
c$ = Clazz.declareType (android.widget, "RadioButton", android.widget.CompoundButton);
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842878);
}, "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "toggle", 
function () {
if (!this.isChecked ()) {
Clazz.superCall (this, android.widget.RadioButton, "toggle", []);
}});
});
