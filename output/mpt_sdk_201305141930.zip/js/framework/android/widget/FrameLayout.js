﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.ViewGroup"], "android.widget.FrameLayout", ["com.android.internal.R"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mMeasureAllChildren = false;
this.mForeground = null;
this.mForegroundPaddingLeft = 0;
this.mForegroundPaddingTop = 0;
this.mForegroundPaddingRight = 0;
this.mForegroundPaddingBottom = 0;
this.mForegroundInPadding = true;
this.mForegroundBoundsChanged = false;
Clazz.instantialize (this, arguments);
}, android.widget, "FrameLayout", android.view.ViewGroup);
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 0);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.FrameLayout, [context, attrs, defStyle]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.FrameLayout, defStyle, 0);
if (a.getBoolean (1, false)) {
this.setMeasureAllChildren (true);
}this.mForegroundInPadding = a.getBoolean (3, true);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "verifyDrawable", 
function (who) {
return Clazz.superCall (this, android.widget.FrameLayout, "verifyDrawable", [who]) || (who === this.mForeground);
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "drawableStateChanged", 
function () {
Clazz.superCall (this, android.widget.FrameLayout, "drawableStateChanged", []);
if (this.mForeground != null && this.mForeground.isStateful ()) {
this.mForeground.setState (this.getDrawableState ());
}});
Clazz.overrideMethod (c$, "generateDefaultLayoutParams", 
function () {
return  new android.widget.FrameLayout.LayoutParams (-1, -1);
});
Clazz.defineMethod (c$, "setForeground", 
function (drawable) {
}, "android.graphics.drawable.Drawable");
Clazz.defineMethod (c$, "getForeground", 
function () {
return this.mForeground;
});
Clazz.overrideMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
var count = this.getChildCount ();
var maxHeight = 0;
var maxWidth = 0;
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (child.getVisibility () != 8) {
this.measureChildWithMargins (child, widthMeasureSpec, 0, heightMeasureSpec, 0);
maxWidth = Math.max (maxWidth, child.getMeasuredWidth ());
maxHeight = Math.max (maxHeight, child.getMeasuredHeight ());
}}
maxWidth += this.mPaddingLeft + this.mPaddingRight + this.mForegroundPaddingLeft + this.mForegroundPaddingRight;
maxHeight += this.mPaddingTop + this.mPaddingBottom + this.mForegroundPaddingTop + this.mForegroundPaddingBottom;
maxHeight = Math.max (maxHeight, this.getSuggestedMinimumHeight ());
maxWidth = Math.max (maxWidth, this.getSuggestedMinimumWidth ());
this.setMeasuredDimension (android.view.View.resolveSize (maxWidth, widthMeasureSpec), android.view.View.resolveSize (maxHeight, heightMeasureSpec));
}, "~N,~N");
Clazz.overrideMethod (c$, "onLayout", 
function (changed, left, top, right, bottom) {
var count = this.getChildCount ();
var parentLeft = this.mPaddingLeft + this.mForegroundPaddingLeft;
var parentRight = right - left - this.mPaddingRight - this.mForegroundPaddingRight;
var parentTop = this.mPaddingTop + this.mForegroundPaddingTop;
var parentBottom = bottom - top - this.mPaddingBottom - this.mForegroundPaddingBottom;
this.mForegroundBoundsChanged = true;
for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (child.getVisibility () != 8) {
var lp = child.getLayoutParams ();
if (isNaN(lp.leftMargin))
lp.leftMargin = 0;
if (isNaN(lp.rightMargin))
lp.rightMargin = 0;
if (isNaN(lp.topMargin))
lp.topMargin = 0;
if (isNaN(lp.bottomMargin))
lp.bottomMargin = 0;
var width = child.getMeasuredWidth ();
var height = child.getMeasuredHeight ();
var childLeft = parentLeft;
var childTop = parentTop;
var gravity = lp.gravity;
if (gravity != -1) {
var horizontalGravity = gravity & 7;
var verticalGravity = gravity & 112;
switch (horizontalGravity) {
case 3:
childLeft = parentLeft + lp.leftMargin;
break;
case 1:
childLeft = parentLeft + Math.floor ((parentRight - parentLeft - width) / 2) + lp.leftMargin - lp.rightMargin;
break;
case 5:
childLeft = parentRight - width - lp.rightMargin;
break;
default:
childLeft = parentLeft + lp.leftMargin;
}
switch (verticalGravity) {
case 48:
childTop = parentTop + lp.topMargin;
break;
case 16:
childTop = parentTop + Math.floor ((parentBottom - parentTop - height) / 2) + lp.topMargin - lp.bottomMargin;
break;
case 80:
childTop = parentBottom - height - lp.bottomMargin;
break;
default:
childTop = parentTop + lp.topMargin;
}
}child.layout (childLeft, childTop, childLeft + width, childTop + height);
}}
}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "onSizeChanged", 
function (w, h, oldw, oldh) {
Clazz.superCall (this, android.widget.FrameLayout, "onSizeChanged", [w, h, oldw, oldh]);
this.mForegroundBoundsChanged = true;
}, "~N,~N,~N,~N");
Clazz.defineMethod (c$, "setMeasureAllChildren", 
function (measureAll) {
this.mMeasureAllChildren = measureAll;
}, "~B");
Clazz.defineMethod (c$, "getConsiderGoneChildrenWhenMeasuring", 
function () {
return this.mMeasureAllChildren;
});
Clazz.defineMethod (c$, "generateLayoutParams", 
function (attrs) {
return  new android.widget.FrameLayout.LayoutParams (this.getContext (), attrs);
}, "android.util.AttributeSet");
Clazz.overrideMethod (c$, "checkLayoutParams", 
function (p) {
return Clazz.instanceOf (p, android.widget.FrameLayout.LayoutParams);
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (p) {
return  new android.widget.FrameLayout.LayoutParams (p);
}, "android.view.ViewGroup.LayoutParams");
Clazz.overrideMethod (c$, "childDrawableStateChanged", 
function (child) {
}, "android.view.View");
Clazz.defineMethod (c$, "focusSearch", 
function (v, direction) {
return null;
}, "android.view.View,~N");
Clazz.defineMethod (c$, "addView", 
function (view, params) {
this.addView (view, params, true);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "gatherTransparentRegion", 
function (region) {
console.log("Missing method: gatherTransparentRegion");
}, "android.graphics.Region");
Clazz.defineMethod (c$, "setForegroundGravity", 
function (foregroundGravity) {
console.log("Missing method: setForegroundGravity");
}, "~N");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.gravity = -1;
Clazz.instantialize (this, arguments);
}, android.widget.FrameLayout, "LayoutParams", android.view.ViewGroup.MarginLayoutParams);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.widget.FrameLayout.LayoutParams, [a, b]);
var c = a.obtainStyledAttributes (b, com.android.internal.R.styleable.FrameLayout_Layout);
this.gravity = c.getInt (0, -1);
c.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.widget.FrameLayout.LayoutParams, [a, b]);
this.gravity = c;
}, "~N,~N,~N");
c$ = Clazz.p0p ();
});
