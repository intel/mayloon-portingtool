﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.ViewGroup", "android.widget.AdapterView", "android.graphics.Rect"], "android.widget.AbsListView", ["android.view.ViewConfiguration", "com.android.internal.R", "java.lang.IllegalArgumentException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mLayoutMode = 0;
this.mDataSetObserver = null;
this.mAdapter = null;
this.mDrawSelectorOnTop = false;
this.mSelectionLeftPadding = 0;
this.mSelectionTopPadding = 0;
this.mSelectionRightPadding = 0;
this.mSelectionBottomPadding = 0;
this.mListPadding = null;
this.mWidthMeasureSpec = 0;
this.mCachingStarted = false;
this.mLastY = 0;
this.mMotionCorrection = 0;
this.mSelectedTop = 0;
this.mStackFromBottom = false;
this.mScrollingCacheEnabled = false;
this.mFastScrollEnabled = false;
this.mOnScrollListener = null;
this.mTextFilter = null;
this.mSmoothScrollbarEnabled = true;
this.mResurrectToPosition = -1;
this.mOverscrollMax = 0;
this.mLastScrollState = 0;
this.mOverscrollDistance = 0;
this.mOverflingDistance = 0;
this.mMotionPosition = 0;
this.mMotionViewOriginalTop = 0;
this.mMotionViewNewTop = 0;
this.mMotionX = 0;
this.mMotionY = 0;
this.mTouchMode = -1;
this.mCacheColorHint = 0;
this.mActivePointerId = -1;
this.mContextMenuInfo = null;
Clazz.instantialize (this, arguments);
}, android.widget, "AbsListView", android.widget.AdapterView);
Clazz.prepareFields (c$, function () {
this.mListPadding =  new android.graphics.Rect ();
});
Clazz.makeConstructor (c$, 
function (context) {
Clazz.superConstructor (this, android.widget.AbsListView, [context]);
this.initAbsListView ();
this.setVerticalScrollBarEnabled (true);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842858);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.AbsListView, [context, attrs, defStyle]);
this.initAbsListView ();
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.AbsListView, defStyle, 0);
this.mDrawSelectorOnTop = a.getBoolean (1, false);
var stackFromBottom = a.getBoolean (2, false);
this.setStackFromBottom (stackFromBottom);
var smoothScrollbar = a.getBoolean (8, true);
this.setSmoothScrollbarEnabled (smoothScrollbar);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "initAbsListView", 
($fz = function () {
this.setClickable (true);
this.setFocusableInTouchMode (true);
this.setWillNotDraw (false);
var configuration = android.view.ViewConfiguration.get (this.mContext);
this.mOverscrollDistance = configuration.getScaledOverscrollDistance ();
this.mOverflingDistance = configuration.getScaledOverflingDistance ();
}, $fz.isPrivate = true, $fz));
Clazz.overrideMethod (c$, "addTouchables", 
function (views) {
var count = this.getChildCount ();
var firstPosition = this.mFirstPosition;
var adapter = this.mAdapter;
if (adapter == null) {
return ;
}for (var i = 0; i < count; i++) {
var child = this.getChildAt (i);
if (adapter.isEnabled (firstPosition + i)) {
views.add (child);
}child.addTouchables (views);
}
}, "java.util.ArrayList");
Clazz.defineMethod (c$, "isFastScrollEnabled", 
function () {
return this.mFastScrollEnabled;
});
Clazz.defineMethod (c$, "setSmoothScrollbarEnabled", 
function (enabled) {
this.mSmoothScrollbarEnabled = enabled;
}, "~B");
Clazz.defineMethod (c$, "isSmoothScrollbarEnabled", 
function () {
return this.mSmoothScrollbarEnabled;
});
Clazz.defineMethod (c$, "setOnScrollListener", 
function (l) {
this.mOnScrollListener = l;
this.invokeOnItemScrollListener ();
}, "android.widget.AbsListView.OnScrollListener");
Clazz.defineMethod (c$, "invokeOnItemScrollListener", 
function () {
if (this.mOnScrollListener != null) {
this.mOnScrollListener.onScroll (this, this.mFirstPosition, this.getChildCount (), this.mItemCount);
}});
Clazz.defineMethod (c$, "getFocusedRect", 
function (r) {
var view = this.getSelectedView ();
if (view != null && view.getParent () === this) {
view.getFocusedRect (r);
this.offsetDescendantRectToMyCoords (view, r);
} else {
Clazz.superCall (this, android.widget.AbsListView, "getFocusedRect", [r]);
}}, "android.graphics.Rect");
Clazz.defineMethod (c$, "isStackFromBottom", 
function () {
return this.mStackFromBottom;
});
Clazz.defineMethod (c$, "setStackFromBottom", 
function (stackFromBottom) {
if (this.mStackFromBottom != stackFromBottom) {
this.mStackFromBottom = stackFromBottom;
this.requestLayoutIfNecessary ();
}}, "~B");
Clazz.defineMethod (c$, "requestLayoutIfNecessary", 
function () {
if (this.getChildCount () > 0) {
this.resetList ();
this.requestLayout ();
this.invalidate ();
}});
Clazz.defineMethod (c$, "requestLayout", 
function () {
if (!this.mBlockLayoutRequests && !this.mInLayout) {
Clazz.superCall (this, android.widget.AbsListView, "requestLayout", []);
}});
Clazz.defineMethod (c$, "resetList", 
function () {
this.removeAllViewsInLayout ();
this.mFirstPosition = 0;
this.mDataChanged = false;
this.mNeedSync = false;
this.mOldSelectedPosition = -1;
this.mOldSelectedRowId = -9223372036854775808;
this.setSelectedPositionInt (-1);
this.setNextSelectedPositionInt (-1);
this.mSelectedTop = 0;
this.invalidate ();
});
Clazz.overrideMethod (c$, "computeVerticalScrollExtent", 
function () {
var count = this.getChildCount ();
if (count > 0) {
if (this.mSmoothScrollbarEnabled) {
var extent = count * 100;
var view = this.getChildAt (0);
var top = view.getTop ();
var height = view.getHeight ();
if (height > 0) {
extent += Math.floor ((top * 100) / height);
}view = this.getChildAt (count - 1);
var bottom = view.getBottom ();
height = view.getHeight ();
if (height > 0) {
extent -= Math.floor (((bottom - this.getHeight ()) * 100) / height);
}return extent;
} else {
return 1;
}}return 0;
});
Clazz.overrideMethod (c$, "computeVerticalScrollOffset", 
function () {
var firstPosition = this.mFirstPosition;
var childCount = this.getChildCount ();
if (firstPosition >= 0 && childCount > 0) {
if (this.mSmoothScrollbarEnabled) {
var view = this.getChildAt (0);
var top = view.getTop ();
var height = view.getHeight ();
if (height > 0) {
return Math.max (firstPosition * 100 - Math.floor ((top * 100) / height) + Math.round ((this.mScrollY / this.getHeight () * this.mItemCount * 100)), 0);
}} else {
var index;
var count = this.mItemCount;
if (firstPosition == 0) {
index = 0;
} else if (firstPosition + childCount == count) {
index = count;
} else {
index = firstPosition + Math.floor (childCount / 2);
}return Math.round ((firstPosition + childCount * (index / count)));
}}return 0;
});
Clazz.overrideMethod (c$, "computeVerticalScrollRange", 
function () {
var result;
if (this.mSmoothScrollbarEnabled) {
result = Math.max (this.mItemCount * 100, 0);
if (this.mScrollY != 0) {
result += Math.abs (Math.round ((this.mScrollY / this.getHeight () * this.mItemCount * 100)));
}} else {
result = this.mItemCount;
}return result;
});
Clazz.overrideMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
var listPadding = this.mListPadding;
listPadding.left = this.mSelectionLeftPadding + this.mPaddingLeft;
listPadding.top = this.mSelectionTopPadding + this.mPaddingTop;
listPadding.right = this.mSelectionRightPadding + this.mPaddingRight;
listPadding.bottom = this.mSelectionBottomPadding + this.mPaddingBottom;
}, "~N,~N");
Clazz.defineMethod (c$, "onLayout", 
function (changed, l, t, r, b) {
Clazz.superCall (this, android.widget.AbsListView, "onLayout", [changed, l, t, r, b]);
this.mInLayout = true;
if (changed) {
var childCount = this.getChildCount ();
for (var i = 0; i < childCount; i++) {
this.getChildAt (i).forceLayout ();
}
}this.layoutChildren ();
this.mInLayout = false;
this.mOverscrollMax = Math.floor ((b - t) / 3);
}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "layoutChildren", 
function () {
});
Clazz.overrideMethod (c$, "getSelectedView", 
function () {
if (this.mItemCount > 0 && this.mSelectedPosition >= 0) {
return this.getChildAt (this.mSelectedPosition - this.mFirstPosition);
} else {
return null;
}});
Clazz.defineMethod (c$, "getListPaddingTop", 
function () {
return this.mListPadding.top;
});
Clazz.defineMethod (c$, "getListPaddingBottom", 
function () {
return this.mListPadding.bottom;
});
Clazz.defineMethod (c$, "getListPaddingLeft", 
function () {
return this.mListPadding.left;
});
Clazz.defineMethod (c$, "getListPaddingRight", 
function () {
return this.mListPadding.right;
});
Clazz.defineMethod (c$, "obtainView", 
function (position) {
return this.mAdapter.getView (position, null, this);
}, "~N");
Clazz.overrideMethod (c$, "onSizeChanged", 
function (w, h, oldw, oldh) {
if (this.getChildCount () > 0) {
this.mDataChanged = true;
this.rememberSyncState ();
}}, "~N,~N,~N,~N");
Clazz.overrideMethod (c$, "onKeyDown", 
function (keyCode, event) {
return false;
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "onKeyUp", 
function (keyCode, event) {
switch (keyCode) {
case 23:
case 13:
if (!this.isEnabled ()) {
return true;
}if (this.isClickable () && this.isPressed () && this.mSelectedPosition >= 0 && this.mAdapter != null && this.mSelectedPosition < this.mAdapter.getCount ()) {
var view = this.getChildAt (this.mSelectedPosition - this.mFirstPosition);
if (view != null) {
this.performItemClick (view, this.mSelectedPosition, this.mSelectedRowId);
view.setPressed (false);
}this.setPressed (false);
return true;
}break;
}
return Clazz.superCall (this, android.widget.AbsListView, "onKeyUp", [keyCode, event]);
}, "~N,android.view.KeyEvent");
Clazz.defineMethod (c$, "reportScrollStateChange", 
function (newState) {
if (newState != this.mLastScrollState) {
if (this.mOnScrollListener != null) {
this.mOnScrollListener.onScrollStateChanged (this, newState);
this.mLastScrollState = newState;
}}}, "~N");
Clazz.defineMethod (c$, "getHeaderViewsCount", 
function () {
return 0;
});
Clazz.defineMethod (c$, "getFooterViewsCount", 
function () {
return 0;
});
Clazz.defineMethod (c$, "hideSelector", 
function () {
if (this.mSelectedPosition != -1) {
if (this.mLayoutMode != 4) {
this.mResurrectToPosition = this.mSelectedPosition;
}if (this.mNextSelectedPosition >= 0 && this.mNextSelectedPosition != this.mSelectedPosition) {
this.mResurrectToPosition = this.mNextSelectedPosition;
}this.setSelectedPositionInt (-1);
this.setNextSelectedPositionInt (-1);
this.mSelectedTop = 0;
}});
Clazz.defineMethod (c$, "reconcileSelectedPosition", 
function () {
var position = this.mSelectedPosition;
if (position < 0) {
position = this.mResurrectToPosition;
}position = Math.max (0, position);
position = Math.min (position, this.mItemCount - 1);
return position;
});
Clazz.defineMethod (c$, "findClosestMotionRow", 
function (y) {
var childCount = this.getChildCount ();
if (childCount == 0) {
return -1;
}var motionRow = this.findMotionRow (y);
return motionRow != -1 ? motionRow : this.mFirstPosition + childCount - 1;
}, "~N");
Clazz.defineMethod (c$, "invalidateViews", 
function () {
this.mDataChanged = true;
this.rememberSyncState ();
this.requestLayout ();
this.invalidate ();
});
Clazz.overrideMethod (c$, "handleDataChanged", 
function () {
var count = this.mItemCount;
if (count > 0) {
var newPos;
var selectablePos;
if (this.mNeedSync) {
this.mNeedSync = false;
switch (this.mSyncMode) {
case 0:
if (this.isInTouchMode ()) {
this.mLayoutMode = 5;
this.mSyncPosition = Math.min (Math.max (0, this.mSyncPosition), count - 1);
return ;
} else {
newPos = this.findSyncPosition ();
if (newPos >= 0) {
selectablePos = this.lookForSelectablePosition (newPos, true);
if (selectablePos == newPos) {
this.mSyncPosition = newPos;
if (this.mSyncHeight == this.getHeight ()) {
this.mLayoutMode = 5;
} else {
this.mLayoutMode = 2;
}this.setNextSelectedPositionInt (newPos);
return ;
}}}break;
case 1:
this.mLayoutMode = 5;
this.mSyncPosition = Math.min (Math.max (0, this.mSyncPosition), count - 1);
return ;
}
}if (!this.isInTouchMode ()) {
newPos = this.getSelectedItemPosition ();
if (newPos >= count) {
newPos = count - 1;
}if (newPos < 0) {
newPos = 0;
}selectablePos = this.lookForSelectablePosition (newPos, true);
if (selectablePos >= 0) {
this.setNextSelectedPositionInt (selectablePos);
return ;
} else {
selectablePos = this.lookForSelectablePosition (newPos, false);
if (selectablePos >= 0) {
this.setNextSelectedPositionInt (selectablePos);
return ;
}}} else {
if (this.mResurrectToPosition >= 0) {
return ;
}}}this.mLayoutMode = this.mStackFromBottom ? 3 : 1;
this.mSelectedPosition = -1;
this.mSelectedRowId = -9223372036854775808;
this.mNextSelectedPosition = -1;
this.mNextSelectedRowId = -9223372036854775808;
this.mNeedSync = false;
this.checkSelectionChanged ();
});
c$.getDistance = Clazz.defineMethod (c$, "getDistance", 
function (source, dest, direction) {
var sX;
var sY;
var dX;
var dY;
switch (direction) {
case 66:
sX = source.right;
sY = source.top + Math.floor (source.height () / 2);
dX = dest.left;
dY = dest.top + Math.floor (dest.height () / 2);
break;
case 130:
sX = source.left + Math.floor (source.width () / 2);
sY = source.bottom;
dX = dest.left + Math.floor (dest.width () / 2);
dY = dest.top;
break;
case 17:
sX = source.left;
sY = source.top + Math.floor (source.height () / 2);
dX = dest.right;
dY = dest.top + Math.floor (dest.height () / 2);
break;
case 33:
sX = source.left + Math.floor (source.width () / 2);
sY = source.top;
dX = dest.left + Math.floor (dest.width () / 2);
dY = dest.bottom;
break;
default:
throw  new IllegalArgumentException ("direction must be one of {FOCUS_UP, FOCUS_DOWN, FOCUS_LEFT, FOCUS_RIGHT}.");
}
var deltaX = dX - sX;
var deltaY = dY - sY;
return deltaY * deltaY + deltaX * deltaX;
}, "android.graphics.Rect,android.graphics.Rect,~N");
Clazz.overrideMethod (c$, "checkInputConnectionProxy", 
function (view) {
return view === this.mTextFilter;
}, "android.view.View");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (p) {
return  new android.widget.AbsListView.LayoutParams (p);
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (attrs) {
return  new android.widget.AbsListView.LayoutParams (this.getContext (), attrs);
}, "android.util.AttributeSet");
Clazz.overrideMethod (c$, "checkLayoutParams", 
function (p) {
return Clazz.instanceOf (p, android.widget.AbsListView.LayoutParams);
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "setCacheColorHint", 
function (color) {
if (color != this.mCacheColorHint) {
this.mCacheColorHint = color;
var count = this.getChildCount ();
for (var i = 0; i < count; i++) {
this.getChildAt (i).setDrawingCacheBackgroundColor (color);
}
}}, "~N");
Clazz.defineMethod (c$, "getCacheColorHint", 
function () {
return this.mCacheColorHint;
});
Clazz.defineMethod (c$, "reclaimViews", 
function (views) {
var childCount = this.getChildCount ();
for (var i = 0; i < childCount; i++) {
var child = this.getChildAt (i);
var lp = child.getLayoutParams ();
if (lp != null) {
views.add (child);
}}
this.removeAllViewsInLayout ();
}, "java.util.List");
Clazz.defineMethod (c$, "pointToPosition", 
function (x, y) {
var frame =  new android.graphics.Rect ();
var count = this.getChildCount ();
for (var i = count - 1; i >= 0; i--) {
var child = this.getChildAt (i);
if (child.getVisibility () == 0) {
child.getHitRect (frame);
if (frame.contains (x, y)) {
return this.mFirstPosition + i;
}}}
return -1;
}, "~N,~N");
Clazz.overrideMethod (c$, "onInterceptTouchEvent", 
function (ev) {
var action = ev.getAction ();
var v;
switch (action & 255) {
case 0:
{
var touchMode = this.mTouchMode;
if (touchMode == 6 || touchMode == 5) {
this.mMotionCorrection = 0;
return true;
}var x = Math.round (ev.getX ());
var y = Math.round (ev.getY ());
this.mActivePointerId = ev.getPointerId (0);
var motionPosition = this.findMotionRow (y);
if (touchMode != 4 && motionPosition >= 0) {
v = this.getChildAt (motionPosition - this.mFirstPosition);
this.mMotionViewOriginalTop = v.getTop ();
this.mMotionX = x;
this.mMotionY = y;
this.mMotionPosition = motionPosition;
this.mTouchMode = 0;
}this.mLastY = -2147483648;
if (touchMode == 4) {
return true;
}break;
}case 2:
{
switch (this.mTouchMode) {
case 0:
var pointerIndex = ev.findPointerIndex (this.mActivePointerId);
var y = Math.round (ev.getY (pointerIndex));
break;
}
break;
}case 1:
{
this.mTouchMode = -1;
this.mActivePointerId = -1;
this.reportScrollStateChange (0);
break;
}}
return false;
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "onTouchEvent", 
function (ev) {
if (!this.isEnabled ()) {
return this.isClickable () || this.isLongClickable ();
}var action = ev.getAction ();
var v;
var deltaY;
switch (action & 255) {
case 0:
{
var x = Math.round (ev.getX ());
var y = Math.round (ev.getY ());
this.mMotionPosition = this.pointToPosition (x, y);
break;
}case 2:
{
var x = Math.round (ev.getX ());
var y = Math.round (ev.getY ());
this.mMotionPosition = this.pointToPosition (x, y);
break;
}case 1:
{
var x = Math.round (ev.getX ());
var y = Math.round (ev.getY ());
this.mMotionPosition = this.pointToPosition (x, y);
var child = this.getChildAt (this.mMotionPosition - this.mFirstPosition);
if (child != null && this.mAdapter != null) {
this.performItemClick (child, this.mMotionPosition, this.mAdapter.getItemId (this.mMotionPosition));
return true;
}break;
}}
return Clazz.superCall (this, android.widget.AbsListView, "onTouchEvent", [ev]);
}, "android.view.MotionEvent");
Clazz.defineMethod (c$, "showContextMenuForChild", 
function (originalView) {
var longPressPosition = this.getPositionForView (originalView);
if (longPressPosition >= 0) {
var longPressId = this.mAdapter.getItemId (longPressPosition);
var handled = false;
if (this.mOnItemLongClickListener != null) {
handled = this.mOnItemLongClickListener.onItemLongClick (this, originalView, longPressPosition, longPressId);
}if (!handled) {
this.mContextMenuInfo = this.createContextMenuInfo (this.getChildAt (longPressPosition - this.mFirstPosition), longPressPosition, longPressId);
handled = Clazz.superCall (this, android.widget.AbsListView, "showContextMenuForChild", [originalView]);
}return handled;
}return false;
}, "android.view.View");
Clazz.defineMethod (c$, "createContextMenuInfo", 
function (view, position, id) {
return  new android.widget.AdapterView.AdapterContextMenuInfo (view, position, id);
}, "android.view.View,~N,~N");
Clazz.defineMethod (c$, "afterTextChanged", 
function (s) {
console.log("Missing method: afterTextChanged");
}, "android.text.Editable");
Clazz.defineMethod (c$, "setRecyclerListener", 
function (listener) {
console.log("Missing method: setRecyclerListener");
}, "~O");
Clazz.defineMethod (c$, "setFilterText", 
function (filterText) {
console.log("Missing method: setFilterText");
}, "~S");
Clazz.defineMethod (c$, "getTranscriptMode", 
function () {
console.log("Missing method: getTranscriptMode");
});
Clazz.defineMethod (c$, "smoothScrollToPosition", 
function (position, boundPosition) {
console.log("Missing method: smoothScrollToPosition");
}, "~N,~N");
Clazz.defineMethod (c$, "setSelector", 
function (resID) {
console.log("Missing method: setSelector");
}, "~N");
Clazz.defineMethod (c$, "setScrollingCacheEnabled", 
function (enabled) {
console.log("Missing method: setScrollingCacheEnabled");
}, "~B");
Clazz.defineMethod (c$, "setFastScrollEnabled", 
function (enabled) {
console.log("Missing method: setFastScrollEnabled");
}, "~B");
Clazz.defineMethod (c$, "onFilterComplete", 
function (count) {
console.log("Missing method: onFilterComplete");
}, "~N");
Clazz.defineMethod (c$, "clearTextFilter", 
function () {
console.log("Missing method: clearTextFilter");
});
Clazz.defineMethod (c$, "onTouchModeChanged", 
function (isInTouchMode) {
console.log("Missing method: onTouchModeChanged");
}, "~B");
Clazz.defineMethod (c$, "isTextFilterEnabled", 
function () {
console.log("Missing method: isTextFilterEnabled");
});
Clazz.defineMethod (c$, "hasTextFilter", 
function () {
console.log("Missing method: hasTextFilter");
});
Clazz.defineMethod (c$, "isScrollingCacheEnabled", 
function () {
console.log("Missing method: isScrollingCacheEnabled");
});
Clazz.defineMethod (c$, "clear", 
function () {
console.log("Missing method: clear");
});
Clazz.defineMethod (c$, "setDrawSelectorOnTop", 
function (onTop) {
console.log("Missing method: setDrawSelectorOnTop");
}, "~B");
Clazz.defineMethod (c$, "setTranscriptMode", 
function (mode) {
console.log("Missing method: setTranscriptMode");
}, "~N");
Clazz.defineMethod (c$, "setTextFilterEnabled", 
function (textFilterEnabled) {
console.log("Missing method: setTextFilterEnabled");
}, "~B");
Clazz.defineMethod (c$, "smoothScrollToPosition", 
function (position) {
console.log("Missing method: smoothScrollToPosition");
}, "~N");
Clazz.defineMethod (c$, "getTextFilter", 
function () {
console.log("Missing method: getTextFilter");
});
Clazz.defineMethod (c$, "onGlobalLayout", 
function () {
console.log("Missing method: onGlobalLayout");
});
Clazz.pu$h ();
c$ = Clazz.declareInterface (android.widget.AbsListView, "OnScrollListener");
Clazz.defineStatics (c$,
"SCROLL_STATE_IDLE", 0,
"SCROLL_STATE_TOUCH_SCROLL", 1,
"SCROLL_STATE_FLING", 2);
c$ = Clazz.p0p ();
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.viewType = 0;
this.recycledHeaderFooter = false;
this.forceAdd = false;
Clazz.instantialize (this, arguments);
}, android.widget.AbsListView, "LayoutParams", android.view.ViewGroup.LayoutParams);
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.widget.AbsListView.LayoutParams, [a, b]);
this.viewType = c;
}, "~N,~N,~N");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"TOUCH_MODE_REST", -1,
"TOUCH_MODE_DOWN", 0,
"TOUCH_MODE_TAP", 1,
"TOUCH_MODE_DONE_WAITING", 2,
"TOUCH_MODE_SCROLL", 3,
"TOUCH_MODE_FLING", 4,
"TOUCH_MODE_OVERSCROLL", 5,
"TOUCH_MODE_OVERFLING", 6,
"LAYOUT_NORMAL", 0,
"LAYOUT_FORCE_TOP", 1,
"LAYOUT_SET_SELECTION", 2,
"LAYOUT_FORCE_BOTTOM", 3,
"LAYOUT_SPECIFIC", 4,
"LAYOUT_SYNC", 5,
"LAYOUT_MOVE_SELECTION", 6,
"OVERSCROLL_LIMIT_DIVISOR", 3,
"INVALID_POINTER", -1);
});
