﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.TextView"], "android.widget.EditText", ["android.text.Selection"], function () {
c$ = Clazz.declareType (android.widget, "EditText", android.widget.TextView);
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.widget.EditText, [context, attrs, 16842862]);
this.setClickable (true);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.EditText, [context, attrs, defStyle]);
this.setClickable (true);
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.overrideMethod (c$, "getDefaultEditable", 
function () {
return true;
});
Clazz.overrideMethod (c$, "getText", 
function () {
var inputValue = "";
var thisView = document.getElementById(this.getUIElementID());
if (thisView != null) {
inputValue = thisView.value;
// Fix bug #644
if (Clazz.instanceOf(this.mText, android.text.Editable)) {
if (!(this.mText.toString()).equals(inputValue)) {
(this.mText).clear();
(this.mText).append(inputValue);
}
} else {
this.setText(inputValue);
}
}
return this.mText;
});
Clazz.defineMethod (c$, "requestFocus", 
function (direction, previouslyFocusedRect) {
var rtn = Clazz.superCall (this, android.widget.EditText, "requestFocus", [direction, previouslyFocusedRect]);
this.performClick ();
return rtn;
}, "~N,android.graphics.Rect");
Clazz.defineMethod (c$, "setText", 
function (text, type) {
var $private = Clazz.checkPrivateMethod (arguments);
if ($private != null) {
return $private.apply (this, arguments);
}
Clazz.superCall (this, android.widget.EditText, "setText", [text, android.widget.TextView.BufferType.EDITABLE]);
}, "CharSequence,android.widget.TextView.BufferType");
Clazz.defineMethod (c$, "setSelection", 
function (start, stop) {
android.text.Selection.setSelection (this.getText (), start, stop);
}, "~N,~N");
Clazz.defineMethod (c$, "setSelection", 
function (index) {
android.text.Selection.setSelection (this.getText (), index);
}, "~N");
Clazz.defineMethod (c$, "onDraw", 
function (canvas) {
Clazz.superCall (this, android.widget.EditText, "onDraw", [canvas]);
if (this.mSingleLine) {
var thisText = document.getElementById(this.getUIElementID());
if (thisText == null)
alert("EditText.onDraw, thisSpan == null");
var inputText = document.createElement("input"),
old_attributes = thisText.attributes;
inputText.type = "text";
for(var i = 0, len = old_attributes.length; i < len; i++) {
inputText.setAttribute(old_attributes[i].name, old_attributes[i].value);
}
inputText.value = thisText.value;
var child = thisText.firstChild;
if (child != null) {
do {
inputText.appendChild(child);
} while (child = child.nextSibling);
}
thisText.parentNode.replaceChild(inputText, thisText);
}}, "android.graphics.Canvas");
Clazz.defineMethod (c$, "performClick", 
function () {
var thisText = document.getElementById(this.getUIElementID());
if (thisText == null)
alert("EditText.performClick, thisSpan == null");
thisText.focus();
//console.log("Edit Text is clicked!");
return Clazz.superCall (this, android.widget.EditText, "performClick", []);
});
Clazz.defineMethod (c$, "selectAll", 
function () {
console.log("Missing method: selectAll");
});
Clazz.defineMethod (c$, "extendSelection", 
function (index) {
console.log("Missing method: extendSelection");
}, "~N");
});
