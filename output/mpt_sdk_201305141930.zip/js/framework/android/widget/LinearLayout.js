﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.view.ViewGroup"], "android.widget.LinearLayout", ["android.view.View", "com.android.internal.R", "java.lang.IllegalArgumentException", "$.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mBaselineAligned = true;
this.mBaselineAlignedChildIndex = -1;
this.mBaselineChildTop = 0;
this.mOrientation = 0;
this.mGravity = 51;
this.mTotalLength = 0;
this.mWeightSum = 0;
this.mUseLargestChild = false;
this.mMaxAscent = null;
this.mMaxDescent = null;
Clazz.instantialize (this, arguments);
}, android.widget, "LinearLayout", android.view.ViewGroup);
Clazz.makeConstructor (c$, 
function (context, attrs) {
Clazz.superConstructor (this, android.widget.LinearLayout, [context, attrs]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.LinearLayout);
var index = a.getInt (1, 0);
this.setOrientation (index);
index = a.getInt (0, -1);
if (index >= 0) {
this.setGravity (index);
}var baselineAligned = a.getBoolean (2, true);
if (!baselineAligned) {
this.setBaselineAligned (baselineAligned);
}this.mWeightSum = a.getFloat (4, -1.0);
this.mBaselineAlignedChildIndex = a.getInt (3, -1);
this.mUseLargestChild = a.getBoolean (5, false);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.defineMethod (c$, "isBaselineAligned", 
function () {
return this.mBaselineAligned;
});
Clazz.defineMethod (c$, "setBaselineAligned", 
function (baselineAligned) {
this.mBaselineAligned = baselineAligned;
}, "~B");
Clazz.defineMethod (c$, "getBaseline", 
function () {
if (this.mBaselineAlignedChildIndex < 0) {
return Clazz.superCall (this, android.widget.LinearLayout, "getBaseline", []);
}if (this.getChildCount () <= this.mBaselineAlignedChildIndex) {
throw  new RuntimeException ("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
}var child = this.getChildAt (this.mBaselineAlignedChildIndex);
var childBaseline = child.getBaseline ();
if (childBaseline == -1) {
if (this.mBaselineAlignedChildIndex == 0) {
return -1;
}throw  new RuntimeException ("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn\'t know how to get its baseline.");
}var childTop = this.mBaselineChildTop;
if (this.mOrientation == 1) {
var majorGravity = this.mGravity & 112;
if (majorGravity != 48) {
switch (majorGravity) {
case 80:
childTop = this.mBottom - this.mTop - this.mPaddingBottom - this.mTotalLength;
break;
case 16:
childTop += Math.floor (((this.mBottom - this.mTop - this.mPaddingTop - this.mPaddingBottom) - this.mTotalLength) / 2);
break;
}
}}var lp = child.getLayoutParams ();
return childTop + lp.topMargin + childBaseline;
});
Clazz.defineMethod (c$, "getBaselineAlignedChildIndex", 
function () {
return this.mBaselineAlignedChildIndex;
});
Clazz.defineMethod (c$, "setBaselineAlignedChildIndex", 
function (i) {
if ((i < 0) || (i >= this.getChildCount ())) {
throw  new IllegalArgumentException ("base aligned child index out of range (0, " + this.getChildCount () + ")");
}this.mBaselineAlignedChildIndex = i;
}, "~N");
Clazz.defineMethod (c$, "getVirtualChildAt", 
function (index) {
return this.getChildAt (index);
}, "~N");
Clazz.defineMethod (c$, "getVirtualChildCount", 
function () {
return this.getChildCount ();
});
Clazz.defineMethod (c$, "getWeightSum", 
function () {
return this.mWeightSum;
});
Clazz.defineMethod (c$, "setWeightSum", 
function (weightSum) {
this.mWeightSum = Math.max (0.0, weightSum);
}, "~N");
Clazz.overrideMethod (c$, "onMeasure", 
function (widthMeasureSpec, heightMeasureSpec) {
if (this.mOrientation == 1) {
this.measureVertical (widthMeasureSpec, heightMeasureSpec);
} else {
this.measureHorizontal (widthMeasureSpec, heightMeasureSpec);
}}, "~N,~N");
Clazz.defineMethod (c$, "measureVertical", 
function (widthMeasureSpec, heightMeasureSpec) {
this.mTotalLength = 0;
var maxWidth = 0;
var alternativeMaxWidth = 0;
var weightedMaxWidth = 0;
var allFillParent = true;
var totalWeight = 0;
var count = this.getVirtualChildCount ();
var widthMode = android.view.View.MeasureSpec.getMode (widthMeasureSpec);
var heightMode = android.view.View.MeasureSpec.getMode (heightMeasureSpec);
var matchWidth = false;
var baselineChildIndex = this.mBaselineAlignedChildIndex;
var useLargestChild = this.mUseLargestChild;
var largestChildHeight = -2147483648;
for (var i = 0; i < count; ++i) {
var child = this.getVirtualChildAt (i);
if (child == null) {
this.mTotalLength += this.measureNullChild (i);
continue ;}if (child.getVisibility () == 8) {
i += this.getChildrenSkipCount (child, i);
continue ;}var lp = child.getLayoutParams ();
totalWeight += lp.weight;
if (heightMode == 1073741824 && lp.height == 0 && lp.weight > 0) {
var totalLength = this.mTotalLength;
this.mTotalLength = Math.max (totalLength, totalLength + lp.topMargin + lp.bottomMargin);
} else {
var oldHeight = -2147483648;
if (lp.height == 0 && lp.weight > 0) {
oldHeight = 0;
lp.height = -2;
}this.measureChildBeforeLayout (child, i, widthMeasureSpec, 0, heightMeasureSpec, totalWeight == 0 ? this.mTotalLength : 0);
if (oldHeight != -2147483648) {
lp.height = oldHeight;
}var childHeight = child.getMeasuredHeight ();
var totalLength = this.mTotalLength;
this.mTotalLength = Math.max (totalLength, totalLength + childHeight + lp.topMargin + lp.bottomMargin + this.getNextLocationOffset (child));
if (useLargestChild) {
largestChildHeight = Math.max (childHeight, largestChildHeight);
}}if ((baselineChildIndex >= 0) && (baselineChildIndex == i + 1)) {
this.mBaselineChildTop = this.mTotalLength;
}if (i < baselineChildIndex && lp.weight > 0) {
throw  new RuntimeException ("A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won\'t work.  Either remove the weight, or don\'t set mBaselineAlignedChildIndex.");
}var matchWidthLocally = false;
if (widthMode != 1073741824 && lp.width == -1) {
matchWidth = true;
matchWidthLocally = true;
}var margin = lp.leftMargin + lp.rightMargin;
var measuredWidth = child.getMeasuredWidth () + margin;
maxWidth = Math.max (maxWidth, measuredWidth);
allFillParent = allFillParent && lp.width == -1;
if (lp.weight > 0) {
weightedMaxWidth = Math.max (weightedMaxWidth, matchWidthLocally ? margin : measuredWidth);
} else {
alternativeMaxWidth = Math.max (alternativeMaxWidth, matchWidthLocally ? margin : measuredWidth);
}i += this.getChildrenSkipCount (child, i);
}
if (useLargestChild && heightMode == -2147483648) {
this.mTotalLength = 0;
for (var i = 0; i < count; ++i) {
var child = this.getVirtualChildAt (i);
if (child == null) {
this.mTotalLength += this.measureNullChild (i);
continue ;}if (child.getVisibility () == 8) {
i += this.getChildrenSkipCount (child, i);
continue ;}var lp = child.getLayoutParams ();
var totalLength = this.mTotalLength;
this.mTotalLength = Math.max (totalLength, totalLength + largestChildHeight + lp.topMargin + lp.bottomMargin + this.getNextLocationOffset (child));
}
}this.mTotalLength += this.mPaddingTop + this.mPaddingBottom;
var heightSize = this.mTotalLength;
heightSize = Math.max (heightSize, this.getSuggestedMinimumHeight ());
heightSize = android.view.View.resolveSize (heightSize, heightMeasureSpec);
var delta = heightSize - this.mTotalLength;
if (delta != 0 && totalWeight > 0.0) {
var weightSum = this.mWeightSum > 0.0 ? this.mWeightSum : totalWeight;
this.mTotalLength = 0;
for (var i = 0; i < count; ++i) {
var child = this.getVirtualChildAt (i);
if (child.getVisibility () == 8) {
continue ;}var lp = child.getLayoutParams ();
var childExtra = lp.weight;
if (childExtra > 0) {
var share = Math.round ((childExtra * delta / weightSum));
weightSum -= childExtra;
delta -= share;
var childWidthMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (widthMeasureSpec, this.mPaddingLeft + this.mPaddingRight + lp.leftMargin + lp.rightMargin, lp.width);
if ((lp.height != 0) || (heightMode != 1073741824)) {
var childHeight = child.getMeasuredHeight () + share;
if (childHeight < 0) {
childHeight = 0;
}child.measure (childWidthMeasureSpec, android.view.View.MeasureSpec.makeMeasureSpec (childHeight, 1073741824));
} else {
child.measure (childWidthMeasureSpec, android.view.View.MeasureSpec.makeMeasureSpec (share > 0 ? share : 0, 1073741824));
}}var margin = lp.leftMargin + lp.rightMargin;
var measuredWidth = child.getMeasuredWidth () + margin;
maxWidth = Math.max (maxWidth, measuredWidth);
var matchWidthLocally = widthMode != 1073741824 && lp.width == -1;
alternativeMaxWidth = Math.max (alternativeMaxWidth, matchWidthLocally ? margin : measuredWidth);
allFillParent = allFillParent && lp.width == -1;
var totalLength = this.mTotalLength;
this.mTotalLength = Math.max (totalLength, totalLength + child.getMeasuredHeight () + lp.topMargin + lp.bottomMargin + this.getNextLocationOffset (child));
}
this.mTotalLength += this.mPaddingTop + this.mPaddingBottom;
} else {
alternativeMaxWidth = Math.max (alternativeMaxWidth, weightedMaxWidth);
}if (!allFillParent && widthMode != 1073741824) {
maxWidth = alternativeMaxWidth;
}maxWidth += this.mPaddingLeft + this.mPaddingRight;
maxWidth = Math.max (maxWidth, this.getSuggestedMinimumWidth ());
this.setMeasuredDimension (android.view.View.resolveSize (maxWidth, widthMeasureSpec), heightSize);
if (matchWidth) {
this.forceUniformWidth (count, heightMeasureSpec);
}}, "~N,~N");
Clazz.defineMethod (c$, "forceUniformWidth", 
($fz = function (count, heightMeasureSpec) {
var uniformMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (this.getMeasuredWidth (), 1073741824);
for (var i = 0; i < count; ++i) {
var child = this.getVirtualChildAt (i);
if (child.getVisibility () != 8) {
var lp = (child.getLayoutParams ());
if (lp.width == -1) {
var oldHeight = lp.height;
lp.height = child.getMeasuredHeight ();
this.measureChildWithMargins (child, uniformMeasureSpec, 0, heightMeasureSpec, 0);
lp.height = oldHeight;
}}}
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "measureHorizontal", 
function (widthMeasureSpec, heightMeasureSpec) {
this.mTotalLength = 0;
var maxHeight = 0;
var alternativeMaxHeight = 0;
var weightedMaxHeight = 0;
var allFillParent = true;
var totalWeight = 0;
var count = this.getVirtualChildCount ();
var widthMode = android.view.View.MeasureSpec.getMode (widthMeasureSpec);
var heightMode = android.view.View.MeasureSpec.getMode (heightMeasureSpec);
var matchHeight = false;
if (this.mMaxAscent == null || this.mMaxDescent == null) {
this.mMaxAscent =  Clazz.newArray (4, 0);
this.mMaxDescent =  Clazz.newArray (4, 0);
}var maxAscent = this.mMaxAscent;
var maxDescent = this.mMaxDescent;
maxAscent[0] = maxAscent[1] = maxAscent[2] = maxAscent[3] = -1;
maxDescent[0] = maxDescent[1] = maxDescent[2] = maxDescent[3] = -1;
var baselineAligned = this.mBaselineAligned;
var useLargestChild = this.mUseLargestChild;
var isExactly = widthMode == 1073741824;
var largestChildWidth = -2147483648;
for (var i = 0; i < count; ++i) {
var child = this.getVirtualChildAt (i);
if (child == null) {
this.mTotalLength += this.measureNullChild (i);
continue ;}if (child.getVisibility () == 8) {
i += this.getChildrenSkipCount (child, i);
continue ;}var lp = child.getLayoutParams ();
totalWeight += lp.weight;
if (widthMode == 1073741824 && lp.width == 0 && lp.weight > 0) {
if (isExactly) {
this.mTotalLength += lp.leftMargin + lp.rightMargin;
} else {
var totalLength = this.mTotalLength;
this.mTotalLength = Math.max (totalLength, totalLength + lp.leftMargin + lp.rightMargin);
}if (baselineAligned) {
var freeSpec = android.view.View.MeasureSpec.makeMeasureSpec (0, 0);
child.measure (freeSpec, freeSpec);
}} else {
var oldWidth = -2147483648;
if (lp.width == 0 && lp.weight > 0) {
oldWidth = 0;
lp.width = -2;
}this.measureChildBeforeLayout (child, i, widthMeasureSpec, totalWeight == 0 ? this.mTotalLength : 0, heightMeasureSpec, 0);
if (oldWidth != -2147483648) {
lp.width = oldWidth;
}var childWidth = child.getMeasuredWidth ();
if (isExactly) {
this.mTotalLength += childWidth + lp.leftMargin + lp.rightMargin + this.getNextLocationOffset (child);
} else {
var totalLength = this.mTotalLength;
this.mTotalLength = Math.max (totalLength, totalLength + childWidth + lp.leftMargin + lp.rightMargin + this.getNextLocationOffset (child));
}if (useLargestChild) {
largestChildWidth = Math.max (childWidth, largestChildWidth);
}}var matchHeightLocally = false;
if (heightMode != 1073741824 && lp.height == -1) {
matchHeight = true;
matchHeightLocally = true;
}var margin = lp.topMargin + lp.bottomMargin;
var childHeight = child.getMeasuredHeight () + margin;
if (baselineAligned) {
var childBaseline = child.getBaseline ();
if (childBaseline != -1) {
var gravity = (lp.gravity < 0 ? this.mGravity : lp.gravity) & 112;
var index = ((gravity >> 4) & -2) >> 1;
maxAscent[index] = Math.max (maxAscent[index], childBaseline);
maxDescent[index] = Math.max (maxDescent[index], childHeight - childBaseline);
}}maxHeight = Math.max (maxHeight, childHeight);
allFillParent = allFillParent && lp.height == -1;
if (lp.weight > 0) {
weightedMaxHeight = Math.max (weightedMaxHeight, matchHeightLocally ? margin : childHeight);
} else {
alternativeMaxHeight = Math.max (alternativeMaxHeight, matchHeightLocally ? margin : childHeight);
}i += this.getChildrenSkipCount (child, i);
}
if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
var ascent = Math.max (maxAscent[3], Math.max (maxAscent[0], Math.max (maxAscent[1], maxAscent[2])));
var descent = Math.max (maxDescent[3], Math.max (maxDescent[0], Math.max (maxDescent[1], maxDescent[2])));
maxHeight = Math.max (maxHeight, ascent + descent);
}if (useLargestChild && widthMode == -2147483648) {
this.mTotalLength = 0;
for (var i = 0; i < count; ++i) {
var child = this.getVirtualChildAt (i);
if (child == null) {
this.mTotalLength += this.measureNullChild (i);
continue ;}if (child.getVisibility () == 8) {
i += this.getChildrenSkipCount (child, i);
continue ;}var lp = child.getLayoutParams ();
if (isExactly) {
this.mTotalLength += largestChildWidth + lp.leftMargin + lp.rightMargin + this.getNextLocationOffset (child);
} else {
var totalLength = this.mTotalLength;
this.mTotalLength = Math.max (totalLength, totalLength + largestChildWidth + lp.leftMargin + lp.rightMargin + this.getNextLocationOffset (child));
}}
}this.mTotalLength += this.mPaddingLeft + this.mPaddingRight;
var widthSize = this.mTotalLength;
widthSize = Math.max (widthSize, this.getSuggestedMinimumWidth ());
widthSize = android.view.View.resolveSize (widthSize, widthMeasureSpec);
var delta = widthSize - this.mTotalLength;
if (delta != 0 && totalWeight > 0.0) {
var weightSum = this.mWeightSum > 0.0 ? this.mWeightSum : totalWeight;
maxAscent[0] = maxAscent[1] = maxAscent[2] = maxAscent[3] = -1;
maxDescent[0] = maxDescent[1] = maxDescent[2] = maxDescent[3] = -1;
maxHeight = -1;
this.mTotalLength = 0;
for (var i = 0; i < count; ++i) {
var child = this.getVirtualChildAt (i);
if (child == null || child.getVisibility () == 8) {
continue ;}var lp = child.getLayoutParams ();
var childExtra = lp.weight;
if (childExtra > 0) {
var share = Math.round ((childExtra * delta / weightSum));
weightSum -= childExtra;
delta -= share;
var childHeightMeasureSpec = android.view.ViewGroup.getChildMeasureSpec (heightMeasureSpec, this.mPaddingTop + this.mPaddingBottom + lp.topMargin + lp.bottomMargin, lp.height);
if ((lp.width != 0) || (widthMode != 1073741824)) {
var childWidth = child.getMeasuredWidth () + share;
if (childWidth < 0) {
childWidth = 0;
}child.measure (android.view.View.MeasureSpec.makeMeasureSpec (childWidth, 1073741824), childHeightMeasureSpec);
} else {
child.measure (android.view.View.MeasureSpec.makeMeasureSpec (share > 0 ? share : 0, 1073741824), childHeightMeasureSpec);
}}if (isExactly) {
this.mTotalLength += child.getMeasuredWidth () + lp.leftMargin + lp.rightMargin + this.getNextLocationOffset (child);
} else {
var totalLength = this.mTotalLength;
this.mTotalLength = Math.max (totalLength, totalLength + child.getMeasuredWidth () + lp.leftMargin + lp.rightMargin + this.getNextLocationOffset (child));
}var matchHeightLocally = heightMode != 1073741824 && lp.height == -1;
var margin = lp.topMargin + lp.bottomMargin;
var childHeight = child.getMeasuredHeight () + margin;
maxHeight = Math.max (maxHeight, childHeight);
alternativeMaxHeight = Math.max (alternativeMaxHeight, matchHeightLocally ? margin : childHeight);
allFillParent = allFillParent && lp.height == -1;
if (baselineAligned) {
var childBaseline = child.getBaseline ();
if (childBaseline != -1) {
var gravity = (lp.gravity < 0 ? this.mGravity : lp.gravity) & 112;
var index = ((gravity >> 4) & -2) >> 1;
maxAscent[index] = Math.max (maxAscent[index], childBaseline);
maxDescent[index] = Math.max (maxDescent[index], childHeight - childBaseline);
}}}
this.mTotalLength += this.mPaddingLeft + this.mPaddingRight;
if (maxAscent[1] != -1 || maxAscent[0] != -1 || maxAscent[2] != -1 || maxAscent[3] != -1) {
var ascent = Math.max (maxAscent[3], Math.max (maxAscent[0], Math.max (maxAscent[1], maxAscent[2])));
var descent = Math.max (maxDescent[3], Math.max (maxDescent[0], Math.max (maxDescent[1], maxDescent[2])));
maxHeight = Math.max (maxHeight, ascent + descent);
}} else {
alternativeMaxHeight = Math.max (alternativeMaxHeight, weightedMaxHeight);
}if (!allFillParent && heightMode != 1073741824) {
maxHeight = alternativeMaxHeight;
}maxHeight += this.mPaddingTop + this.mPaddingBottom;
maxHeight = Math.max (maxHeight, this.getSuggestedMinimumHeight ());
this.setMeasuredDimension (widthSize, android.view.View.resolveSize (maxHeight, heightMeasureSpec));
if (matchHeight) {
this.forceUniformHeight (count, widthMeasureSpec);
}}, "~N,~N");
Clazz.defineMethod (c$, "forceUniformHeight", 
($fz = function (count, widthMeasureSpec) {
var uniformMeasureSpec = android.view.View.MeasureSpec.makeMeasureSpec (this.getMeasuredHeight (), 1073741824);
for (var i = 0; i < count; ++i) {
var child = this.getVirtualChildAt (i);
if (child.getVisibility () != 8) {
var lp = child.getLayoutParams ();
if (lp.height == -1) {
var oldWidth = lp.width;
lp.width = child.getMeasuredWidth ();
this.measureChildWithMargins (child, widthMeasureSpec, 0, uniformMeasureSpec, 0);
lp.width = oldWidth;
}}}
}, $fz.isPrivate = true, $fz), "~N,~N");
Clazz.defineMethod (c$, "getChildrenSkipCount", 
function (child, index) {
return 0;
}, "android.view.View,~N");
Clazz.defineMethod (c$, "measureNullChild", 
function (childIndex) {
return 0;
}, "~N");
Clazz.defineMethod (c$, "measureChildBeforeLayout", 
function (child, childIndex, widthMeasureSpec, totalWidth, heightMeasureSpec, totalHeight) {
this.measureChildWithMargins (child, widthMeasureSpec, totalWidth, heightMeasureSpec, totalHeight);
}, "android.view.View,~N,~N,~N,~N,~N");
Clazz.defineMethod (c$, "getLocationOffset", 
function (child) {
return 0;
}, "android.view.View");
Clazz.defineMethod (c$, "getNextLocationOffset", 
function (child) {
return 0;
}, "android.view.View");
Clazz.overrideMethod (c$, "onLayout", 
function (changed, l, t, r, b) {
if (this.mOrientation == 1) {
this.layoutVertical ();
} else {
this.layoutHorizontal ();
}}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "layoutVertical", 
function () {
var paddingLeft = this.mPaddingLeft;
var childTop = this.mPaddingTop;
var childLeft;
var width = this.mRight - this.mLeft;
var childRight = width - this.mPaddingRight;
var childSpace = width - paddingLeft - this.mPaddingRight;
var count = this.getVirtualChildCount ();
var majorGravity = this.mGravity & 112;
var minorGravity = this.mGravity & 7;
if (majorGravity != 48) {
switch (majorGravity) {
case 80:
childTop = this.mBottom - this.mTop + this.mPaddingTop - this.mTotalLength;
break;
case 16:
childTop += Math.floor (((this.mBottom - this.mTop) - this.mTotalLength) / 2);
break;
}
}for (var i = 0; i < count; i++) {
var child = this.getVirtualChildAt (i);
if (child == null) {
childTop += this.measureNullChild (i);
} else if (child.getVisibility () != 8) {
var childWidth = child.getMeasuredWidth ();
var childHeight = child.getMeasuredHeight ();
var lp = child.getLayoutParams ();
var gravity = lp.gravity;
if (gravity < 0) {
gravity = minorGravity;
}switch (gravity & 7) {
case 3:
childLeft = paddingLeft + lp.leftMargin;
break;
case 1:
childLeft = paddingLeft + (Math.floor ((childSpace - childWidth) / 2)) + lp.leftMargin - lp.rightMargin;
break;
case 5:
childLeft = childRight - childWidth - lp.rightMargin;
break;
default:
childLeft = paddingLeft;
break;
}
childTop += lp.topMargin;
this.setChildFrame (child, childLeft, childTop + this.getLocationOffset (child), childWidth, childHeight);
childTop += childHeight + lp.bottomMargin + this.getNextLocationOffset (child);
i += this.getChildrenSkipCount (child, i);
}}
});
Clazz.defineMethod (c$, "layoutHorizontal", 
function () {
var paddingTop = this.mPaddingTop;
var childTop = 0;
var childLeft = this.mPaddingLeft;
var height = this.mBottom - this.mTop;
var childBottom = height - this.mPaddingBottom;
var childSpace = height - paddingTop - this.mPaddingBottom;
var count = this.getVirtualChildCount ();
var majorGravity = this.mGravity & 7;
var minorGravity = this.mGravity & 112;
var baselineAligned = this.mBaselineAligned;
var maxAscent = this.mMaxAscent;
var maxDescent = this.mMaxDescent;
if (majorGravity != 3) {
switch (majorGravity) {
case 5:
childLeft = this.mRight - this.mLeft + this.mPaddingLeft - this.mTotalLength;
break;
case 1:
childLeft += Math.floor (((this.mRight - this.mLeft) - this.mTotalLength) / 2);
break;
}
}for (var i = 0; i < count; i++) {
var child = this.getVirtualChildAt (i);
if (child == null) {
childLeft += this.measureNullChild (i);
} else if (child.getVisibility () != 8) {
var childWidth = child.getMeasuredWidth ();
var childHeight = child.getMeasuredHeight ();
var childBaseline = -1;
var lp = child.getLayoutParams ();
if (baselineAligned && lp.height != -1) {
childBaseline = child.getBaseline ();
}var gravity = lp.gravity;
if (gravity < 0) {
gravity = minorGravity;
}switch (gravity & 112) {
case 48:
childTop = paddingTop + lp.topMargin;
if (childBaseline != -1) {
childTop += maxAscent[1] - childBaseline;
}break;
case 16:
childTop = paddingTop + (Math.floor ((childSpace - childHeight) / 2)) + lp.topMargin - lp.bottomMargin;
break;
case 80:
childTop = childBottom - childHeight - lp.bottomMargin;
if (childBaseline != -1) {
var descent = child.getMeasuredHeight () - childBaseline;
childTop -= (maxDescent[2] - descent);
}break;
default:
childTop = paddingTop;
break;
}
childLeft += lp.leftMargin;
this.setChildFrame (child, childLeft + this.getLocationOffset (child), childTop, childWidth, childHeight);
childLeft += childWidth + lp.rightMargin + this.getNextLocationOffset (child);
i += this.getChildrenSkipCount (child, i);
}}
});
Clazz.defineMethod (c$, "setChildFrame", 
($fz = function (child, left, top, width, height) {
child.layout (left, top, left + width, top + height);
}, $fz.isPrivate = true, $fz), "android.view.View,~N,~N,~N,~N");
Clazz.defineMethod (c$, "setOrientation", 
function (orientation) {
if (this.mOrientation != orientation) {
this.mOrientation = orientation;
this.requestLayout ();
}}, "~N");
Clazz.defineMethod (c$, "getOrientation", 
function () {
return this.mOrientation;
});
Clazz.defineMethod (c$, "setGravity", 
function (gravity) {
if (this.mGravity != gravity) {
if ((gravity & 7) == 0) {
gravity |= 3;
}if ((gravity & 112) == 0) {
gravity |= 48;
}this.mGravity = gravity;
this.requestLayout ();
}}, "~N");
Clazz.defineMethod (c$, "setHorizontalGravity", 
function (horizontalGravity) {
var gravity = horizontalGravity & 7;
if ((this.mGravity & 7) != gravity) {
this.mGravity = (this.mGravity & -8) | gravity;
this.requestLayout ();
}}, "~N");
Clazz.defineMethod (c$, "setVerticalGravity", 
function (verticalGravity) {
var gravity = verticalGravity & 112;
if ((this.mGravity & 112) != gravity) {
this.mGravity = (this.mGravity & -113) | gravity;
this.requestLayout ();
}}, "~N");
Clazz.defineMethod (c$, "generateLayoutParams", 
function (attrs) {
return  new android.widget.LinearLayout.LayoutParams (this.getContext (), attrs);
}, "android.util.AttributeSet");
Clazz.overrideMethod (c$, "generateDefaultLayoutParams", 
function () {
if (this.mOrientation == 0) {
return  new android.widget.LinearLayout.LayoutParams (-2, -2);
} else if (this.mOrientation == 1) {
return  new android.widget.LinearLayout.LayoutParams (-1, -2);
}return null;
});
Clazz.defineMethod (c$, "generateLayoutParams", 
function (p) {
return  new android.widget.LinearLayout.LayoutParams (p);
}, "android.view.ViewGroup.LayoutParams");
Clazz.overrideMethod (c$, "checkLayoutParams", 
function (p) {
return Clazz.instanceOf (p, android.widget.LinearLayout.LayoutParams);
}, "android.view.ViewGroup.LayoutParams");
Clazz.defineMethod (c$, "focusSearch", 
function (v, direction) {
return null;
}, "android.view.View,~N");
Clazz.overrideMethod (c$, "childDrawableStateChanged", 
function (child) {
}, "android.view.View");
Clazz.defineMethod (c$, "addView", 
function (view, params) {
this.addView (view, params, true);
}, "android.view.View,android.view.ViewGroup.LayoutParams");
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.weight = 0;
this.gravity = -1;
Clazz.instantialize (this, arguments);
}, android.widget.LinearLayout, "LayoutParams", android.view.ViewGroup.MarginLayoutParams);
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.widget.LinearLayout.LayoutParams, [a, b]);
var c = a.obtainStyledAttributes (b, com.android.internal.R.styleable.LinearLayout_Layout);
this.weight = c.getFloat (3, 0);
this.gravity = c.getInt (0, -1);
c.recycle ();
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (a, b) {
Clazz.superConstructor (this, android.widget.LinearLayout.LayoutParams, [a, b]);
this.weight = 0;
}, "~N,~N");
Clazz.makeConstructor (c$, 
function (a, b, c) {
Clazz.superConstructor (this, android.widget.LinearLayout.LayoutParams, [a, b]);
this.weight = c;
}, "~N,~N,~N");
Clazz.overrideMethod (c$, "debug", 
function (a) {
return a + "LinearLayout.LayoutParams={width=" + android.view.ViewGroup.LayoutParams.sizeToString (this.width) + ", height=" + android.view.ViewGroup.LayoutParams.sizeToString (this.height) + " weight=" + this.weight + "}";
}, "~S");
c$ = Clazz.p0p ();
Clazz.defineStatics (c$,
"HORIZONTAL", 0,
"VERTICAL", 1,
"VERTICAL_GRAVITY_COUNT", 4,
"INDEX_CENTER_VERTICAL", 0,
"INDEX_TOP", 1,
"INDEX_BOTTOM", 2,
"INDEX_FILL", 3);
});
