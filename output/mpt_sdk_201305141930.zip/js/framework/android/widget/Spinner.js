﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.content.DialogInterface", "android.widget.AbsSpinner", "$.ListAdapter", "$.SpinnerAdapter"], "android.widget.Spinner", ["android.view.ViewGroup", "com.android.internal.R", "java.lang.RuntimeException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mPrompt = null;
Clazz.instantialize (this, arguments);
}, android.widget, "Spinner", android.widget.AbsSpinner, android.content.DialogInterface.OnClickListener);
Clazz.makeConstructor (c$, 
function (context) {
this.construct (context, null);
}, "android.content.Context");
Clazz.makeConstructor (c$, 
function (context, attrs) {
this.construct (context, attrs, 16842881);
}, "android.content.Context,android.util.AttributeSet");
Clazz.makeConstructor (c$, 
function (context, attrs, defStyle) {
Clazz.superConstructor (this, android.widget.Spinner, [context, attrs, defStyle]);
var a = context.obtainStyledAttributes (attrs, com.android.internal.R.styleable.Spinner, defStyle, 0);
this.mPrompt = a.getString (0);
a.recycle ();
}, "android.content.Context,android.util.AttributeSet,~N");
Clazz.defineMethod (c$, "getBaseline", 
function () {
var child = null;
if (this.getChildCount () > 0) {
child = this.getChildAt (0);
} else if (this.mAdapter != null && this.mAdapter.getCount () > 0) {
child = this.makeAndAddView (0);
}if (child != null) {
return child.getTop () + child.getBaseline ();
} else {
return -1;
}});
Clazz.overrideMethod (c$, "setOnItemClickListener", 
function (l) {
throw  new RuntimeException ("setOnItemClickListener cannot be used with a spinner.");
}, "android.widget.AdapterView.OnItemClickListener");
Clazz.defineMethod (c$, "onLayout", 
function (changed, l, t, r, b) {
Clazz.superCall (this, android.widget.Spinner, "onLayout", [changed, l, t, r, b]);
this.mInLayout = true;
this.layout (0, false);
this.mInLayout = false;
}, "~B,~N,~N,~N,~N");
Clazz.defineMethod (c$, "layout", 
function (delta, animate) {
var childrenLeft = this.mSpinnerPadding.left;
var childrenWidth = this.mRight - this.mLeft - this.mSpinnerPadding.left - this.mSpinnerPadding.right;
if (this.mDataChanged) {
this.handleDataChanged ();
}if (this.mItemCount == 0) {
this.resetList ();
return ;
}if (this.mNextSelectedPosition >= 0) {
this.setSelectedPositionInt (this.mNextSelectedPosition);
}this.recycleAllViews ();
this.removeAllViewsInLayout ();
this.mFirstPosition = this.mSelectedPosition;
var sel = this.makeAndAddView (this.mSelectedPosition);
var width = sel.getMeasuredWidth ();
var selectedOffset = childrenLeft + (Math.floor (childrenWidth / 2)) - (Math.floor (width / 2));
sel.offsetLeftAndRight (selectedOffset);
this.mRecycler.clear ();
this.invalidate ();
this.checkSelectionChanged ();
this.mDataChanged = false;
this.mNeedSync = false;
this.setNextSelectedPositionInt (this.mSelectedPosition);
}, "~N,~B");
Clazz.defineMethod (c$, "makeAndAddView", 
($fz = function (position) {
var child;
if (!this.mDataChanged) {
child = this.mRecycler.get (position);
if (child != null) {
this.setUpChild (child);
return child;
}}child = this.mAdapter.getView (position, null, this);
this.setUpChild (child);
return child;
}, $fz.isPrivate = true, $fz), "~N");
Clazz.defineMethod (c$, "setUpChild", 
($fz = function (child) {
var lp = child.getLayoutParams ();
if (lp == null) {
lp = this.generateDefaultLayoutParams ();
}this.addViewInLayout (child, 0, lp);
child.setSelected (this.hasFocus ());
var childHeightSpec = android.view.ViewGroup.getChildMeasureSpec (this.mHeightMeasureSpec, this.mSpinnerPadding.top + this.mSpinnerPadding.bottom, lp.height);
var childWidthSpec = android.view.ViewGroup.getChildMeasureSpec (this.mWidthMeasureSpec, this.mSpinnerPadding.left + this.mSpinnerPadding.right, lp.width);
child.measure (childWidthSpec, childHeightSpec);
var childLeft;
var childRight;
var childTop = this.mSpinnerPadding.top + (Math.floor ((this.mMeasuredHeight - this.mSpinnerPadding.bottom - this.mSpinnerPadding.top - child.getMeasuredHeight ()) / 2));
var childBottom = childTop + child.getMeasuredHeight ();
var width = child.getMeasuredWidth ();
childLeft = 0;
childRight = childLeft + width;
child.layout (childLeft, childTop, childRight, childBottom);
}, $fz.isPrivate = true, $fz), "android.view.View");
Clazz.defineMethod (c$, "performClick", 
function () {
var handled = Clazz.superCall (this, android.widget.Spinner, "performClick", []);
if (!handled) {
handled = true;
var context = this.getContext ();
var adapter =  new android.widget.Spinner.DropDownAdapter (this.getAdapter ());
}return handled;
});
Clazz.overrideMethod (c$, "onClick", 
function (dialog, which) {
this.setSelection (which);
dialog.dismiss ();
}, "android.content.DialogInterface,~N");
Clazz.defineMethod (c$, "setPrompt", 
function (prompt) {
this.mPrompt = prompt;
}, "CharSequence");
Clazz.defineMethod (c$, "setPromptId", 
function (promptId) {
this.mPrompt = this.getContext ().getText (promptId);
}, "~N");
Clazz.defineMethod (c$, "getPrompt", 
function () {
return this.mPrompt;
});
Clazz.pu$h ();
c$ = Clazz.decorateAsClass (function () {
this.mAdapter = null;
this.mListAdapter = null;
Clazz.instantialize (this, arguments);
}, android.widget.Spinner, "DropDownAdapter", null, [android.widget.ListAdapter, android.widget.SpinnerAdapter]);
Clazz.makeConstructor (c$, 
function (a) {
this.mAdapter = a;
if (Clazz.instanceOf (a, android.widget.ListAdapter)) {
this.mListAdapter = a;
}}, "android.widget.SpinnerAdapter");
Clazz.defineMethod (c$, "getCount", 
function () {
return this.mAdapter == null ? 0 : this.mAdapter.getCount ();
});
Clazz.defineMethod (c$, "getItem", 
function (a) {
return this.mAdapter == null ? null : this.mAdapter.getItem (a);
}, "~N");
Clazz.defineMethod (c$, "getItemId", 
function (a) {
return this.mAdapter == null ? -1 : this.mAdapter.getItemId (a);
}, "~N");
Clazz.overrideMethod (c$, "getView", 
function (a, b, c) {
return this.getDropDownView (a, b, c);
}, "~N,android.view.View,android.view.ViewGroup");
Clazz.defineMethod (c$, "getDropDownView", 
function (a, b, c) {
return this.mAdapter == null ? null : this.mAdapter.getDropDownView (a, b, c);
}, "~N,android.view.View,android.view.ViewGroup");
Clazz.defineMethod (c$, "hasStableIds", 
function () {
return this.mAdapter != null && this.mAdapter.hasStableIds ();
});
Clazz.defineMethod (c$, "registerDataSetObserver", 
function (a) {
if (this.mAdapter != null) {
this.mAdapter.registerDataSetObserver (a);
}}, "android.database.DataSetObserver");
Clazz.defineMethod (c$, "unregisterDataSetObserver", 
function (a) {
if (this.mAdapter != null) {
this.mAdapter.unregisterDataSetObserver (a);
}}, "android.database.DataSetObserver");
Clazz.defineMethod (c$, "areAllItemsEnabled", 
function () {
var a = this.mListAdapter;
if (a != null) {
return a.areAllItemsEnabled ();
} else {
return true;
}});
Clazz.defineMethod (c$, "isEnabled", 
function (a) {
var b = this.mListAdapter;
if (b != null) {
return b.isEnabled (a);
} else {
return true;
}}, "~N");
Clazz.overrideMethod (c$, "getItemViewType", 
function (a) {
return 0;
}, "~N");
Clazz.overrideMethod (c$, "getViewTypeCount", 
function () {
return 1;
});
Clazz.overrideMethod (c$, "isEmpty", 
function () {
return this.getCount () == 0;
});
c$ = Clazz.p0p ();
});
