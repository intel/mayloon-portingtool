﻿Clazz.declarePackage ("android.widget");
Clazz.load (["android.widget.ResourceCursorAdapter"], "android.widget.SimpleCursorAdapter", ["java.lang.IllegalStateException"], function () {
c$ = Clazz.decorateAsClass (function () {
this.mFrom = null;
this.mTo = null;
this.mStringConversionColumn = -1;
this.mCursorToStringConverter = null;
this.mViewBinder = null;
this.mOriginalFrom = null;
Clazz.instantialize (this, arguments);
}, android.widget, "SimpleCursorAdapter", android.widget.ResourceCursorAdapter);
Clazz.makeConstructor (c$, 
function (context, layout, c, from, to) {
Clazz.superConstructor (this, android.widget.SimpleCursorAdapter, [context, layout, c]);
this.mTo = to;
this.mOriginalFrom = from;
this.findColumns (from);
}, "android.content.Context,~N,android.database.Cursor,~A,~A");
Clazz.overrideMethod (c$, "bindView", 
function (view, context, cursor) {
var binder = this.mViewBinder;
var count = this.mTo.length;
var from = this.mFrom;
var to = this.mTo;
for (var i = 0; i < count; i++) {
var v = view.findViewById (to[i]);
if (v != null) {
var bound = false;
if (binder != null) {
bound = binder.setViewValue (v, cursor, from[i]);
}if (!bound) {
var text = cursor.getString (from[i]);
if (text == null) {
text = "";
}if (Clazz.instanceOf (v, android.widget.TextView)) {
this.setViewText (v, text);
} else {
throw  new IllegalStateException (v.getClass ().getName () + " is not a " + " view that can be bounds by this SimpleCursorAdapter");
}}}}
}, "android.view.View,android.content.Context,android.database.Cursor");
Clazz.defineMethod (c$, "getViewBinder", 
function () {
return this.mViewBinder;
});
Clazz.defineMethod (c$, "setViewBinder", 
function (viewBinder) {
this.mViewBinder = viewBinder;
}, "android.widget.SimpleCursorAdapter.ViewBinder");
Clazz.defineMethod (c$, "setViewText", 
function (v, text) {
v.setText (text);
}, "android.widget.TextView,~S");
Clazz.defineMethod (c$, "getStringConversionColumn", 
function () {
return this.mStringConversionColumn;
});
Clazz.defineMethod (c$, "setStringConversionColumn", 
function (stringConversionColumn) {
this.mStringConversionColumn = stringConversionColumn;
}, "~N");
Clazz.defineMethod (c$, "getCursorToStringConverter", 
function () {
return this.mCursorToStringConverter;
});
Clazz.defineMethod (c$, "setCursorToStringConverter", 
function (cursorToStringConverter) {
this.mCursorToStringConverter = cursorToStringConverter;
}, "android.widget.SimpleCursorAdapter.CursorToStringConverter");
Clazz.defineMethod (c$, "convertToString", 
function (cursor) {
if (this.mCursorToStringConverter != null) {
return this.mCursorToStringConverter.convertToString (cursor);
} else if (this.mStringConversionColumn > -1) {
return cursor.getString (this.mStringConversionColumn);
}return Clazz.superCall (this, android.widget.SimpleCursorAdapter, "convertToString", [cursor]);
}, "android.database.Cursor");
Clazz.defineMethod (c$, "findColumns", 
($fz = function (from) {
if (this.mCursor != null) {
var i;
var count = from.length;
if (this.mFrom == null || this.mFrom.length != count) {
this.mFrom =  Clazz.newArray (count, 0);
}for (i = 0; i < count; i++) {
this.mFrom[i] = this.mCursor.getColumnIndexOrThrow (from[i]);
}
} else {
this.mFrom = null;
}}, $fz.isPrivate = true, $fz), "~A");
Clazz.defineMethod (c$, "changeCursor", 
function (c) {
Clazz.superCall (this, android.widget.SimpleCursorAdapter, "changeCursor", [c]);
this.findColumns (this.mOriginalFrom);
}, "android.database.Cursor");
Clazz.defineMethod (c$, "changeCursorAndColumns", 
function (c, from, to) {
this.mOriginalFrom = from;
this.mTo = to;
Clazz.superCall (this, android.widget.SimpleCursorAdapter, "changeCursor", [c]);
this.findColumns (this.mOriginalFrom);
}, "android.database.Cursor,~A,~A");
Clazz.declareInterface (android.widget.SimpleCursorAdapter, "ViewBinder");
Clazz.declareInterface (android.widget.SimpleCursorAdapter, "CursorToStringConverter");
});
