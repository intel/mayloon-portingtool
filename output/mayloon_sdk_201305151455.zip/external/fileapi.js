//*******************************************************************
//  Utilities
//*******************************************************************
function slog(message, e) {
  console.log(message);
  if(e){
      console.log(e);
  }
}

function Notifier() {
}

Notifier.prototype.wait = function() {
  while (this.notifier === undefined) {
    yield();
  }
  return this.notifier;
}

Notifier.prototype.notify = function(notifier) {
  this.notifier = notifier;
}

//*******************************************************************
//  W3C File System
//*******************************************************************
function W3CFileSystemBase(type, size) {
  this.type = type;
  this.size = size;
}

W3CFileSystemBase.prototype.init = function() {
  if (W3CFileSystemBase.prototype.instance.fs) {
    return W3CFileSystemBase.prototype.instance.fs;
  }

  var notifier = new Notifier();
  var func = self.requestFileSystem || self.webkitRequestFileSystem;
  func(this.type, this.size, function(fs){
    notifier.notify(fs);
  }, function(e) {
    slog("Unable to initialize file system, error ", e);
    notifier.notify(null);
  });
  var fs = notifier.wait();
  return (W3CFileSystemBase.prototype.instance.fs = fs);
}

W3CFileSystemBase.prototype.instance = new W3CFileSystemBase(TEMPORARY, 1024);

function W3CFileSystem() {
  W3CFileSystem.prototype.init();
}

W3CFileSystem.prototype = W3CFileSystemBase.prototype.instance;

//*******************************************************************
//  W3C File
//*******************************************************************
function W3CFile(name) {
  this.name = name;
}

W3CFile.prototype = new W3CFileSystem();

W3CFile.prototype.open = function(create, exclusive) {
  if (!this.fs || !this.name) return false;
  
  var notifier = new Notifier();
  this.fs.root.getFile(this.name, {'create': create, 'exclusive': exclusive},  function(entry) {
    notifier.notify(entry);
  }, function(e) {
    slog("Unable to open file, error ", e);
    notifier.notify(null);
  });
  this.entry = notifier.wait();
  return this.entry ? true : false;
};

W3CFile.prototype.exist = function() {
  return this.entry ? true : this.open(false, false);
};

W3CFile.prototype.read = function() {
  if (!this.entry) {
    slog("File is not opened yet");
    return false;
  }
  var notifier = new Notifier();
  this.entry.file(function(file){
    var reader = new FileReader();
    reader.onload = function() {
      notifier.notify(this.result);
    }
    reader.onerror = function(e) {
      slog("Unable to read file, error ", e);
      notifier.notify(null);
    }
    reader.readAsText(file);
  });
  return notifier.wait();
};

W3CFile.prototype.write = function(data, append) {
  if (!this.entry) return false;

  var notifier = new Notifier();
  this.entry.createWriter(function(writer){
    writer.onwriteend = function(e) {
      slog("Write complete");
      notifier.notify(true);
    };
    writer.onerror = function(e) {
      slog("Write failed, error ", e);
      notifier.notify(false);
    };
    
    var builder = new WebKitBlobBuilder();
    builder.append(data);
    if (append) { 
      writer.seek(writer.length);
    }
    writer.write(builder.getBlob("text/plain"));

  },function(e){
    slog("Unable to write file, error ", e);
    notifier.notify(false);
  });
  return notifier.wait();
}

W3CFile.prototype.remove = function() {
  if (!this.entry) return true;

  var notifier = new Notifier();
  this.entry.remove(function(){
    notifier.notify(true);
  }, function(e){
    slog("Unable to remove file, error ",e);
    notifier.notify(false);
  });
  return notifier.wait();
}

W3CFile.prototype.moveTo = function(folder, rename) {
  if (!this.entry) return null;
  if (typeof(folder) == 'string') {
    folder = new W3CFolder(folder);
    if (!folder.open()) return null;
  }
  if (folder instanceof W3CFolder) {
    folder = folder.entry;
  }
  var name = (rename ? rename : this.entry.name);

  var notifier = new Notifier();
  this.entry.moveTo(folder, name, function(entry){
    notifier.notify(entry);
  }, function(e){
    slog("Unable to move file, error ", e);
    notifier.notify(null);
  });
  this.entry = entry;
  this.entry = entry.name;
  return this;
}

W3CFile.prototype.copyTo = function(folder, rename) {
  if (!this.entry) return null;
  if (typeof(folder) == 'string') { 
    folder = new W3CFolder(folder);
    if (!folder.open()) return null;
  }
  if (folder instanceof W3CFolder) {
    folder = folder.entry;
  }
  var notifier = new Notifier();
  var name = (rename ? rename : this.entry.name);
  this.entry.copyTo(folder, name, function(entry){
    notifier.notify(entry);
  }, function(e){
    slog("Unable to copy file, error ", e);
    notifier.notify(null);
  });
  var entry = notifier.wait();
  if (!entry) return null;
  var file = new W3CFile(entry.name);
  file.entry = entry;
  return file;
}

W3CFile.prototype.getParent = function() {
  if (!this.entry) return null;
  var notifier = new Notifier();
  this.entry.getParent(function(parent){
    notifier.notify(parent);
  }, function(e){
    notifier.notify(null);
  });
  var parent = notifier.wait();
  if (!parent) return null;
  var folder = new W3CFolder(parent.name);
  folder.entry = parent;
  return folder;
}

W3CFile.prototype.toString = function() {
  if (this.entry) return this.entry.fullPath;
  return this.name;
}

//*******************************************************************
//  W3C Folder
//*******************************************************************
function W3CFolder(name) {
  this.name = name;
}

W3CFolder.prototype = new W3CFileSystem();

W3CFolder.prototype.open = function(create) {
  if (!this.name || !this.fs) return false;

  var notifier = new Notifier();
  var folders = this.name.split('/');
  var getDirectory = function(folders, entry){
    while (folders.length > 0 
           && (folders[0] == '.'
            || folders[0] == '')) {
      folders = folders.slice(1);
    }
    if (folders.length == 0) {
      notifier.notify(entry);
      return;
    }
    entry.getDirectory(folders[0], {'create': create}, function(entry){
      if (folders.length > 0) {
        getDirectory(folders.slice(1), entry);
      }
    }, function(e){
      slog("Unable to open directory, error ", e);
      notifier.notify(null);
    });
  };

  getDirectory(folders, this.fs.root);

  var entry = notifier.wait();
  if (!entry) return false;
  this.entry = entry;
  this.name = entry.name;
  return this.entry ? true : false;
};

W3CFolder.prototype.exist = function() {
  return this.entry ? true : this.open(false);
};

W3CFolder.prototype.list = function() {
  if (!this.entry) { 
    if (!this.open(false)) 
      return [];
  }
  var result = [];
  var reader = this.entry.createReader();
  var notifier = new Notifier();
  var readEntries = function() {
    reader.readEntries(function(entries){
      if (entries.length == 0) {
        notifier.notify(null);
      } else {
        result = result.concat(Array.prototype.slice.call(entries,0));
        readEntries();
      }
    }, function(e){
      slog("Unable to read entries in directory, error ",e);
      notifier.notify(null);
    });
  };
  readEntries();
  notifier.wait();
  var list = [];
  for (var i=0; i<result.length; i++) {
    list[i] = result[i].name;
  }
  return list;
};

W3CFolder.prototype.createFolder = function(folders) {
  if (!this.entry) return false;
  if (typeof(folders) == 'string') {
    folders = folders.split('/');
  }
  var notifier = new Notifier();
  var makeEntries = function(folders, entry) {
    while (folders.length > 0 && (folders[0] == '.' || folders[0] == '')) {
      folders = folders.slice(1);
    }
    if (folders.length == 0) {
      notifier.notify(entry);
      return;
    }
    entry.getDirectory(folders[0], {'create': true}, function(entry){
      if (folders.length > 0) {
        makeEntries(folders.slice(1), entry);
      }
    }, function(e){
      notifier.notify(null);
    });
  };
  makeEntries(folders, this.entry);
  var entry = notifier.wait();
  if (!entry) return null;
  var folder = new W3CFolder(entry.name);
  folder.entry = entry;
  return folder;
}

W3CFolder.prototype.remove = function(recursive) {
  if (!this.entry) return false;

  var notifier = new Notifier();
  var remove = (!recursive ? this.entry.remove : this.entry.removeRecursively);
  remove.call(this.entry, function(){
    notifier.notify(true);
  }, function(e){
    slog("Unable to remove directory, error ", e);
    notifier.notify(false);
  });
  return notifier.wait();
};

W3CFile.prototype.lastModified = function() {
  if (!this.entry) {
    if (!this.open()) {
      return -1;
    }
  }
  var notifier = new Notifier();
  this.entry.getMetadata(function(meta){
    notifier.notify(meta);
  }, function(e){
    notifier.notify(null);
  });
  var meta = notifier.wait();
  if (!meta) return -1;
  return meta.modificationTime.getTime();
}

W3CFile.prototype.length = function() {
  if (!this.entry) {
    if (!this.open()) {
      return 0;
    }
  }
  var notifier = new Notifier();
  this.entry.getMetadata(function(meta){
    notifier.notify(meta);
  }, function(e){
    notifier.notify(null);
  });
  var meta = notifier.wait();
  if (!meta) return 0;
  return !meta.size ? -1 : meta.size;
}

W3CFolder.prototype.createFile = function(path, create, exclusive) {
  if (!this.entry) return null;
  var notifier = new Notifier();
  this.entry.getFile(path, {'create':create, 'exclusive':exclusive}, function(entry){
    notifier.notify(entry);
  }, function(e){
    slog("Unable to create file, error ",e);
    notifier.notify(null);
  });
  var entry = notifier.wait();
  if (!entry) return null;
  var file = new W3CFile(entry.name);
  file.entry = entry;
  return file;
}

W3CFolder.prototype.lastModified = function() {
  if (!this.entry) {
    if (!this.open()) {
      return -1;
    }
  }
  var notifier = new Notifier();
  this.entry.getMetadata(function(meta){
    notifier.notify(meta);
  }, function(e){
    notifier.notify(null);
  });
  var meta = notifier.wait();
  if (!meta) return -1;
  return meta.modificationTime.getTime();
}

W3CFolder.prototype.getParent = function() {
  if (!this.entry) return null;
  var notifier = new Notifier();
  this.entry.getParent(function(parent){
    notifier.notify(parent);
  }, function(e){
    notifier.notify(null);
  });
  var parent = notifier.wait();
  if (!parent) return null;
  var folder = new W3CFolder(parent.name);
  folder.entry = parent;
  return folder;
}

W3CFolder.prototype.toString = function() {
  if (this.entry) return this.entry.fullPath;
  return this.name;
}


