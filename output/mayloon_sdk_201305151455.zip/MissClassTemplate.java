package android.mayloon.template;

import com.intel.mpt.annotation.MayloonStubAnnotation;

public class MissClassTemplate {
	
	/**
	 * @j2sNative
	 * alert("Missing method: MissClassTemplate");
	 * console.log("Missing method: MissClassTemplate");
	 */
	 @MayloonStubAnnotation()
	public MissClassTemplate() {
		
	}
	
	/**
	 * @j2sNative
	 * alert("Missing method: MissClassTemplate");
	 * console.log("Missing method: MissClassTemplate");
	 */
	 @MayloonStubAnnotation()
	public MissClassTemplate(Object arg) {
		
	}
	
	/**
	 * @j2sNative
	 * alert("Missing method: MissClassTemplate");
	 * console.log("Missing method: MissClassTemplate");
	 */
	 @MayloonStubAnnotation()
	public MissClassTemplate(Object arg1, Object arg2) {
		
	}
}
