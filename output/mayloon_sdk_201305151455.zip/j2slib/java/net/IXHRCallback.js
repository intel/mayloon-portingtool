﻿Clazz.declarePackage ("java.net");
Clazz.declareInterface (java.net, "IXHRCallback");
