﻿$_L(["java.lang.Exception"],"java.lang.RuntimeException",null,function(){
c$=$_T(java.lang,"RuntimeException",Exception);
});
