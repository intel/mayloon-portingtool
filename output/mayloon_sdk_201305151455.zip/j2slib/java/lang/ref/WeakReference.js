﻿$_L(["java.lang.ref.Reference"],"java.lang.ref.WeakReference",null,function(){
c$=$_T(java.lang.ref,"WeakReference",java.lang.ref.Reference);
});
