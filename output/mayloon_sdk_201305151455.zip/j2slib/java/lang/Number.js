﻿c$=$_T(java.lang,"Number",null,java.io.Serializable);
$_K(c$,
function(){
});
$_M(c$,"byteValue",
function(){
return this.intValue();
});
$_M(c$,"shortValue",
function(){
return this.intValue();
});
