﻿$_L(["java.security.BasicPermission"],"java.io.SerializablePermission",null,function(){
c$=$_C(function(){
this.actions=null;
$_Z(this,arguments);
},java.io,"SerializablePermission",java.security.BasicPermission);
});
