﻿$_L(["java.io.DataOutput"],"java.io.ObjectOutput",null,function(){
$_I(java.io,"ObjectOutput",java.io.DataOutput);
});
