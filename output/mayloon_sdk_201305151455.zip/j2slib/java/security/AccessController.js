﻿$_J("java.security");
c$=$_T(java.security,"AccessController");
c$.doPrivileged=$_M(c$,"doPrivileged",
function(privilegedAction){
return null;
},"java.security.PrivilegedAction");
