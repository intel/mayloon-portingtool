﻿$_J("java.security");
c$=$_T(java.security,"PrivilegedExceptionAction");
