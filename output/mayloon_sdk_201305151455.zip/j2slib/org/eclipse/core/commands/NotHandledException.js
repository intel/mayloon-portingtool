﻿Clazz.declarePackage ("org.eclipse.core.commands");
Clazz.load (["org.eclipse.core.commands.common.CommandException"], "org.eclipse.core.commands.NotHandledException", null, function () {
c$ = Clazz.declareType (org.eclipse.core.commands, "NotHandledException", org.eclipse.core.commands.common.CommandException);
});
