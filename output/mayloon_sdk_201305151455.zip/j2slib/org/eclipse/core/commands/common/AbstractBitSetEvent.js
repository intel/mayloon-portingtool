﻿Clazz.declarePackage ("org.eclipse.core.commands.common");
c$ = Clazz.decorateAsClass (function () {
this.changedValues = 0;
Clazz.instantialize (this, arguments);
}, org.eclipse.core.commands.common, "AbstractBitSetEvent");
