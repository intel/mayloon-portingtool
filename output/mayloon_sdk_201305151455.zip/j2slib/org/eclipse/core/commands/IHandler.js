﻿Clazz.declarePackage ("org.eclipse.core.commands");
Clazz.declareInterface (org.eclipse.core.commands, "IHandler");
