﻿Clazz.declarePackage ("org.eclipse.core.commands.operations");
Clazz.declareInterface (org.eclipse.core.commands.operations, "IAdvancedUndoableOperation");
