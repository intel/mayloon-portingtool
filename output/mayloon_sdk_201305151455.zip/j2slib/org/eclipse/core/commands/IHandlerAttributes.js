﻿Clazz.declarePackage ("org.eclipse.core.commands");
c$ = Clazz.declareInterface (org.eclipse.core.commands, "IHandlerAttributes");
Clazz.defineStatics (c$,
"ATTRIBUTE_HANDLED", "handled");
